/**
 * Created by Administrator on 2017/4/18.
 */
$(function(){
    //统一，复选框，全选操作
    //全选
	$("input.checkAllBox").click(function(){
		 var ids = "";
    	if($(this).prop("checked")){
    		$("input.subCheckBox").attr("checked", true);
    		$("input.subCheckBox").each(function(){
    			if(ids==""){
    				ids=$(this).val();
    			}else{
    			 	ids += ","+$(this).val();
    			}
    		})
    		$(this).next("span:first").text("全不选");
    	}else{
    		$("input.subCheckBox").attr("checked", false);
    		$(this).next("span:first").text("全选");
    	}
    	$("#selectedId").val(ids);
    })
        	
	//单选
	$("input.subCheckBox").click(function(){
		var ids = $("#selectedId").val().split(",");
        var id = $(this).val();
        if($(this).prop("checked")){
	       	 if ($("#selectedId").val() == null || $("#selectedId").val() == ''){
	                $("#selectedId").val(id);
	         } else {
	                $("#selectedId").val($("#selectedId").val() + "," + id);
	         }
        }else{
	       	 	for(var i =0; i<ids.length; i++){
	                if (ids[i] == id){
	                    ids.splice($.inArray(id,ids),1);//数组移除该元素
	                }
	            }
            $("#selectedId").val(ids.join(","));
        }
    })
})