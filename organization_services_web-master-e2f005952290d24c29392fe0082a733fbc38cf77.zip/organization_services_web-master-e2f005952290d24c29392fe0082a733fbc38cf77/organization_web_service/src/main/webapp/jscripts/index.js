$(function() {
	var a = document.body.offsetWidth;
	var b = $('.kabao_left').width();
	var c = $('.layout-panel').width();
	c = a - b;

	//标题栏
	$(".subNav").click(function() {
		$(this).toggleClass("currentDd").siblings(".subNav").removeClass("currentDd")
		$(this).toggleClass("currentDt").siblings(".subNav").removeClass("currentDt")

		// 修改数字控制速度，slideUp(300)控制卷起速度
		$(this).next(".navContent").slideToggle(300).siblings(".navContent").slideUp(300);
	})

	$(".tabs li").click(function() {
		$(this).addClass('active');
		$(this).siblings().removeClass('active');
		var item = $(".tabs-inner");
		$(this).find(item).addClass('active1');
		$(this).siblings().find(item).removeClass('active1');
	})

	//左边折叠导航栏
	$(document).ready(function() {
		$("#firstpane .menu_body:eq(0)").show();
		$("#firstpane .menu_head").click(function() {
			$(this).addClass("current").next("div.menu_body").slideToggle(300).siblings("div.menu_body").slideUp("slow");
			$(this).siblings().removeClass("current");
		});
		$("#secondpane .menu_body:eq(0)").show();
		$("#secondpane .menu_head").mouseover(function() {
			$(this).addClass("current").next("div.menu_body").slideDown(500).siblings("div.menu_body").slideUp("slow");
			$(this).siblings().removeClass("current");
		});

	});
})