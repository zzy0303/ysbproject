/*
	Toggles a menu on & off (using cookies
*/
var showText = '';
var showTitle = '';

var hideText = '';
var hideTitle = '';


function initPinComments(showText1, showTitle1, hideText1, hideTitle1) 
{
    showText = showText1;
    showTitle = showTitle1;

    hideText = hideText1;
    hideTitle = hideTitle1;
}

function toggleMenu(sSectionID, eSectionIcon)
{
	var eSection = document.getElementById(sSectionID);
	if (readCookie(sSectionID) == "on")
	{
		eSectionIcon.innerHTML = showText;
		eSectionIcon.setAttribute("title", showTitle);
		saveCookie(sSectionID, "off", 365);
	}
	else
	{
		eSectionIcon.innerHTML = hideText;
		eSectionIcon.setAttribute("title", hideTitle);
		saveCookie(sSectionID, "on", 365);
	}

}
/*
	Restiores a state of a menu
*/

function restoreMenu(sSectionID, sSectionIcon)
{
	var eSection = document.getElementById(sSectionID);
	var eSectionIcon = document.getElementById(sSectionIcon);
	if (readCookie(sSectionID) == "on")
	{
		eSection.style.display = "block";
		eSectionIcon.innerHTML = hideText;
		eSectionIcon.setAttribute("title", hideTitle);
		saveCookie(sSectionID, "on", 365);
	}
    else
    {
		eSectionIcon.innerHTML = showText;
		eSectionIcon.setAttribute("title",showTitle);        
    }

}