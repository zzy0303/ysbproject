This file contains the original calendar-*.js files from
http://www.dynarch.com/projects/calendar/ in (for the most part) their
native encoding.  A script converts them to unicode-escaped files in ../
