http://script.aculo.us/

Version info:
Prototype framework 1.4.0_pre2,
scriptaculous-js-1.5_pre2