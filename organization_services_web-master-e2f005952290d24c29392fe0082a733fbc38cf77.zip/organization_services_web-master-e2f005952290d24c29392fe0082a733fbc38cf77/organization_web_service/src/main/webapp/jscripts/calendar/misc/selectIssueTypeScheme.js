var lastIdDisplayed = '';
function handleSchemeChange()
{
    var selectList = $('schemeId_select');

    hide();
    show();
    changeDescription0(selectList);

    $('issueTypeSchemeLabel').innerHTML = selectList.options[selectList.selectedIndex].innerHTML;
}



function handleSectionChange()
{
    if ($('createType_chooseScheme').checked)
    {
        $('chooseScheme').style.display = '';
    }
    else
    {
        $('chooseScheme').style.display = 'none';
    }

    if ($('createType_chooseProject') && $('createType_chooseProject').checked)
    {
        $('chooseProject').style.display = '';
    }
    else
    {
        $('chooseProject').style.display = 'none';
    }

    if ($('createType_createScheme').checked)
    {
        $('optionsForScheme').style.display = 'none';
        $('createScheme').style.display = '';
    }
    else
    {
        $('createScheme').style.display = 'none';
        $('optionsForScheme').style.display = '';                
    }

    return true;
}

function hide()
{
    if (lastIdDisplayed && lastIdDisplayed != '')
        $(lastIdDisplayed).style.display = 'none';
//            Effect.Fade(lastIdDisplayed,
//                        { duration: 1
//                        });

}

function show()
{
    var selectList = $('schemeId_select');

    lastIdDisplayed = selectList.value;
    $(selectList.value).style.display = '';
}


function selectIssueTypeScheme(projectSelect)
{
    if (projectSelect.value && projectSelect.value != '')
    {
        changeDescription2(projectSelect);

        if ($('schemeId_select').value != projectSelect.value)
        {
            $('schemeId_select').value = projectSelect.value;
            handleSchemeChange();
        }
    }
}