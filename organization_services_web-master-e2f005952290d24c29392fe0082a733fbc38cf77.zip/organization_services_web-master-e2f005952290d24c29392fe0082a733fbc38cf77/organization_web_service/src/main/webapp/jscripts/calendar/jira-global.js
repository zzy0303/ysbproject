window.onload = function () 
{
    var textAreas = xGetElementsByTagName('textarea');
    for (var i = 0; i < textAreas.length; i++) 
    {
        xAddEventListener(textAreas[i], 'keypress', submitOnCtrlEnter);
    }
}

/*
Submits an element's form if the enter key is pressed
*/
function submitOnEnter(e) 
{
    var xe = new xEvent(e);
    var targetObject = xe.target;
    if (xe.keyCode  == 13 && targetObject.form)
    {
        targetObject.form.submit();
    }
}

/*
Submits an element's form if the enter key and the control key is pressed
*/

function submitOnCtrlEnter(e) 
{
    var xe = new xEvent(e);
    var targetObject = xe.target;
    if (xe.ctrlKey && (xe.keyCode  == 13 || xe.keyCode == 10 ) && targetObject.form)
    {
        targetObject.form.submit();
        return false;
    }
    return true;
}


/** A bunch of useful utilitiy javascript methods available to all jira pages **/

/*
Returns a space delimited value of a select list. There's strangely no in-built way of doing this for multi-selects
*/
function getMultiSelectValues(selectObject) 
{
    var selectedValues = '';
    for (var i = 0; i < selectObject.length; i++)
    {
        if(selectObject.options[i].selected)
        {
            if (selectObject.options[i].value && selectObject.options[i].value.length > 0)
                selectedValues = selectedValues + ' ' + selectObject.options[i].value;
        }
    }

    return selectedValues;
}

function getMultiSelectValuesAsArray(selectObject)
{
    var selectedValues = new Array();
    for (var i = 0; i < selectObject.length; i++)
    {
        if(selectObject.options[i].selected)
        {
            if (selectObject.options[i].value && selectObject.options[i].value.length > 0)
                selectedValues[selectedValues.length] = selectObject.options[i].value;
        }
    }
    return selectedValues;
}

/*
  Returns true if the value is the array
*/
function arrayContains(array, value)
{
    for (var i = 0; i < array.length; i++)
    {
        if (array[i] == value)
        {
            return true;
        }
    }

    return false;
}

/*
Adds a class name to the given element
*/
function addClassName(elementId, classNameToAdd) 
{
    var elem = document.getElementById(elementId);
    if (elem)
    {
        elem.className = elem.className + ' ' + classNameToAdd;
    }
}

/*
 Removes all class names to from the given element
 */
function removeClassName(elementId, classNameToRemove) 
{
    var elem = document.getElementById(elementId);
    if (elem)
    {
        elem.className = (' ' + elem.className + ' ').replace(' ' + classNameToRemove + ' ', ' ');
    }
}

/*
    Returns the field as an encoded string (assuming that the id == the field name
*/
function getEscapedFieldValue(id)
{

    var e = document.getElementById(id);

    if (e.value)
    {
        return id + '=' + encodeURIComponent(e.value);
    }
    else
    {
        return '';
    }
}

/*
    Returns a concatenated version of getEscapedFieldValue
*/
function getEscapedFieldValues(ids)
{
    var s = '';
    for (i = 0; i < ids.length; i++)
    {
        s = s + '&' + getEscapedFieldValue(ids[i]);
    }
    return s;
}

/*
 Toggles hide / unhide an element. Also attemots to change the "elementId + header" element to have the headerOpened / headerClosed class.
 Also saves the state in a cookie
*/
function toggle(elementId) 
{
    var elem = document.getElementById(elementId);
    if (elem)
    {
        if (readCookie(elementId, 'sectionOpened') == 'sectionOpened')
        {
            elem.style.display = "none";
            removeClassName(elementId + 'header', 'headerOpened');
            addClassName(elementId + 'header', 'headerClosed')
            saveCookie(elementId, 'sectionClosed', 365);
        }
        else
        {
            elem.style.display = "";
            removeClassName(elementId + 'header', 'headerClosed');
            addClassName(elementId + 'header', 'headerOpened')
            saveCookie(elementId, 'sectionOpened', 365);
        }
    }
}

/*
 Similar to toggle. Run this on page load.
*/
function restore(elementId) 
{
    var elem = document.getElementById(elementId);
    if (elem)
    {
        if (readCookie(elementId, 'sectionOpened') != 'sectionOpened')
        {
            elem.style.display = "none";
            removeClassName(elementId + 'header', 'headerOpened');
            addClassName(elementId + 'header', 'headerClosed')
        }
        else
        {
            elem.style.display = "";
            removeClassName(elementId + 'header', 'headerClosed');
            addClassName(elementId + 'header', 'headerOpened')
        }
    }
}




// Cookie handling functions
function saveCookie(name,value,days)
{
  var ex;
  if (days) {
    var d = new Date();
    d.setTime(d.getTime()+(days*24*60*60*1000));
    ex = "; expires="+d.toGMTString();
  }
  else {
    ex = "";
  }
  document.cookie = name+"="+value+ex+"; path=/";
}

/*
Reads a cookie. If none exists, then it returns and 
*/
function readCookie(name, defaultValue)
{
  var eq = name + "=";
  var ca = document.cookie.split(';');
  for(var i=0;i<ca.length;i++) {
    var c = ca[i];
    while (c.charAt(0)==' ') c = c.substring(1,c.length);
    if (c.indexOf(eq) == 0) return c.substring(eq.length,c.length);
  }

  // No cookie found, then save a new one as on!
  if (defaultValue)
  {
      saveCookie(name, defaultValue, 365);
      return defaultValue;
  }
  else
  {
      return null;
  }
}

function eraseCookie(name)
{
  saveCookie(name,"",-1);
}
