/*
	Toggles the admin menu on & off (using cookies)
*/

var areAllMenusOpen = true;

function openMenu(sSectionID) 
{
	var eHeader = document.getElementById(sSectionID);
	var eSection = document.getElementById(sSectionID + "_body");

    eHeader.className = "headerOpen";
    eSection.style.display = "";
    saveCookie(sSectionID, "on", 365);
}

function closeMenu(sSectionID) 
{
	var eHeader = document.getElementById(sSectionID);
	var eSection = document.getElementById(sSectionID + "_body");

    eHeader.className = "headerClosed";
    eSection.style.display = "none";
    saveCookie(sSectionID, "off", 365);

    areAllMenusOpen = false;
}

function toggleMenu(sSectionID)
{
	if (readCookie(sSectionID, 'on') == "on")
	{
        closeMenu(sSectionID);
        restoreShowHideAllMenu();
	}
	else
	{
        openMenu(sSectionID);
	}
}

/*
	Restores a state of a menu
*/

function restoreMenu(sSectionID)
{
	if (readCookie(sSectionID, 'on') == "on")
	{
        openMenu(sSectionID);
	}
    else
    {
        closeMenu(sSectionID);
    }
}

function restoreShowHideAllMenu()
{
    if (areAllMenusOpen)
    {
        var eHideAll = document.getElementById("hideAllMenu");
        eHideAll.style.display = "";

        var eShowAll = document.getElementById("showAllMenu");
        eShowAll.style.display = "none";
    }
    else
    {
        var eHideAll = document.getElementById("hideAllMenu");
        eHideAll.style.display = "none";

        var eShowAll = document.getElementById("showAllMenu");
        eShowAll.style.display = "";
    }
}