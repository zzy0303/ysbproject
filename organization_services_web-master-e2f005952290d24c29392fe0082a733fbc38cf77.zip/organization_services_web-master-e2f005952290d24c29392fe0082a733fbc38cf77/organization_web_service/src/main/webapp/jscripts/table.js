
Object.prototype.attachEvent = function(method,func){
	if(!this[method]){
		this[method]=func;
	}
//	else{
//		this[method]=this[method].attach(func);
//	}
}

Function.prototype.attach=function(func){
	var f=this;
	return function(){
		f();
		func();
	}
}

function addEventListener1(obj,method){
		if(window.addEventListener){
			obj.addEventListener("click",method,false);//firefox,谷歌浏览器
		}else{
			obj.attachEvent('onclick', method); //IE (IE不支持addEventListener)
		}
}

// Table行样式
var Rows=new Array();
var tableRows = new Array();
var ie = "\v"=="v";
function initpage() {
	// 初始化一般table样式
	var tbl = document.getElementById("listTable") ;
	initTableEvent(tbl) ;

	// 初始化checkbox table样式
	var tbl = document.getElementById("listCheckTable") ;
	initCheckTableEvent(tbl);
}

// 一般table初始化
function initTableEvent(tableObj) {
	if(tableObj != null){
		for(var i=0; i<tableObj.rows.length; i++){
			tableRows[i] = tableObj.rows[i];
			//相邻记录行之间使用不同的样式区分
			if((tableObj.rows[i].className != "tableTitleBg")){
				if(i%2 == 0)	tableObj.rows[i].className = "tableConBg2";			
				else			tableObj.rows[i].className = "tableConBg";
				addEventListener1(tableObj.rows[i],onfocusit); //火狐和谷歌不支持attachEvent这个方法
				// tableObj.rows[i].attachEvent("onclick",onfocusit);
			}
		}
	}
}

// checkbox table初始化
function initCheckTableEvent(tableObj) {
	if(tableObj != null){
		for(var i=0; i<tableObj.rows.length; i++){
			tableRows[i] = tableObj.rows[i];
			//相邻记录行之间使用不同的样式区分
			if((tableObj.rows[i].className != "tableTitleBg")){
				if(i%2 == 0)	tableObj.rows[i].className = "tableConBg2";			
				else			tableObj.rows[i].className = "tableConBg";

				// tableObj.rows[i].attachEvent("onclick",onfocuscheck);
				addEventListener1(tableObj.rows[i],onfocuscheck);
			}
			else {
				// 设置标题行checkbox事件
				for(var n=0;n<tableObj.rows[i].childNodes.length;n++){			
					for(var k=0;k<tableObj.rows[i].childNodes[n].childNodes.length;k++){
						if(tableObj.rows[i].childNodes[n].childNodes[k].className == "titleCheckBox")
							addEventListener1(tableObj.rows[i].childNodes[n].childNodes[k],clickTitleCheck);
							// tableObj.rows[i].childNodes[n].childNodes[k].attachEvent("onclick",clickTitleCheck);
					}
				}
			}
		}
		
	}
}

function clickTitleCheck(evn) {
	var oCheckBox = ie?evn.srcElement:evn.target;
	var oTable = oCheckBox;
	do{
		oTable=oTable.parentNode;
	}while(oTable.tagName!='TABLE')

	if(oCheckBox.checked == true) {
		selectAllBox(oTable);
	}
	else {
		clearAllBox(oTable);
	}
}

// 重新设置表格样式
function reloadTableItem(tableObj,multi){
	if(tableObj != null){
		var oTableTitle;
		var bolSelected = false;
		var bolNotSelected = false;
		for(var i=0; i<tableObj.rows.length; i++){
			//相邻记录行之间使用不同的样式区分
			if(tableObj.rows[i].className != "tableTitleBg"){
				if(multi == true) {
					// 多行选择的不对已经选中的行重新reload
					if(tableObj.rows[i].className != "tableConBgSelected") {
						bolNotSelected = true;
						if(i%2 == 0)	tableObj.rows[i].className = "tableConBg2";			
						else			tableObj.rows[i].className = "tableConBg";
					}
					else {
						bolSelected = true;
					}
				}
				else {
					if(i%2 == 0)	tableObj.rows[i].className = "tableConBg2";			
					else			tableObj.rows[i].className = "tableConBg";
				}
			}
			else {
				oTableTitle = tableObj.rows[i];
			}
		}
		if(multi == true) {
			// 设置标题行checkbox状态
			for(var n=0;n<oTableTitle.childNodes.length;n++){			
				for(var k=0;k<oTableTitle.childNodes[n].childNodes.length;k++){
					if(oTableTitle.childNodes[n].childNodes[k].className == "titleCheckBox") {
						if(bolNotSelected && bolSelected) {
							// 选中不选中都存在，半选状态
							oTableTitle.childNodes[k].childNodes[k].indeterminate=true;
						}
						if(!bolNotSelected && bolSelected) {
							// 全部选中
							oTableTitle.childNodes[k].childNodes[k].indeterminate=false;
							oTableTitle.childNodes[n].childNodes[k].checked = "true";
						}
						if(bolNotSelected && !bolSelected) {
							// 全部不选中
							oTableTitle.childNodes[k].childNodes[k].indeterminate=false;
							oTableTitle.childNodes[n].childNodes[k].checked = "";
						}
					}
				}
			}
			
		}
	}
}


// 取得选中行
function onfocusit(evn){
    iRow = ie?evn.srcElement:evn.target;
	while(iRow.tagName!='TR') {
		iRow=iRow.parentNode;
	}
	Rows.length=1;
	Rows[0]=iRow;
	changeStyle(iRow,'list');
}

// 取得checkbox table选中行
function onfocuscheck(evn){
    iRow = ie?evn.srcElement:evn.target;
	while(iRow.tagName!='TR') {
		iRow=iRow.parentNode;
	}

	Rows.length=1;
	Rows[0]=iRow;
	changeStyle(iRow,'checkbox');
}


//选中行变色
function changeStyle(E,tableType){

	var trEle = E;
	var i = i || E.sectionRowIndex;

	while((trEle!=null)&&(trEle.tagName!="TABLE")){
		trEle = trEle.parentNode;
	}
	
	// 判断当前选中行以前是否为选中状态
	var iRow = Rows[0];
	var bolSelected = false;
	if(tableRows[i].className == "tableConBgSelected") {
		bolSelected = true;
	}

	if(tableType == "list") {
		reloadTableItem(trEle,false);//还原css style
		if(!bolSelected) {
			tableRows[i].className = "tableConBgSelected";
			// 设置选中值
			setSelectedId(tableRows[i]);
		}
		else {
			// 清除选中值
			clearSelectedId();
		}
	}
	if(tableType == "checkbox") {
		// 可以多行选择的情况下，如果原记录已经被选中，则取消选择
		if(bolSelected) {
			tableRows[i].className = "tableConBg";
			for(var n=0;n<tableRows[i].childNodes.length;n++){			
				for(var k=0;k<tableRows[i].childNodes[n].childNodes.length;k++){
					if(tableRows[i].childNodes[n].childNodes[k].className == "tableCheckBox")
						tableRows[i].childNodes[n].childNodes[k].checked = "";
				}
			}
		}
		else {
			tableRows[i].className = "tableConBgSelected";
			for(var n=0;n<tableRows[i].childNodes.length;n++){			
				for(var k=0;k<tableRows[i].childNodes[n].childNodes.length;k++){
					if(tableRows[i].childNodes[n].childNodes[k].className == "tableCheckBox")
						tableRows[i].childNodes[n].childNodes[k].checked = "true";
				}
			}
		}
		reloadTableItem(trEle,true);//还原css style
	}
}

// 选中所有checkbox的选择
function selectAllBox(trEle){

	for(var i=1;i<trEle.rows.length;i++){
	    if((trEle.rows[i].className != "listNull")&&(trEle.rows[i].className != "tableTitleBg")){
			trEle.rows[i].className = "tableConBgSelected";			
	        for(var n=0;n<trEle.rows[i].childNodes.length;n++){        	
	        	var otd = trEle.rows[i].childNodes[n];	        	
	        	for(var k=0;k<otd.childNodes.length;k++){	        	
	        		if(otd.childNodes[k].className == "tableCheckBox")	
						otd.childNodes[k].checked = "true";
	        	}
			}

	    }
	}
}

//取消所有的checkbox的选择
function clearAllBox(trEle){
	for(var i=1;i<trEle.rows.length;i++){
	    if((trEle.rows[i].className != "listNull")&&(trEle.rows[i].className != "tableTitleBg")){
			if(i%2 == 0)
				trEle.rows[i].className = "tableConBg2";			
			else
				trEle.rows[i].className = "tableConBg";
	        for(var n=0;n<trEle.rows[i].childNodes.length;n++){        	
	        	var otd = trEle.rows[i].childNodes[n];	        	
	        	for(var k=0;k<otd.childNodes.length;k++){	        	
	        		if(otd.childNodes[k].className == "tableCheckBox")	
						otd.childNodes[k].checked = "";
	        	}
			}

	    }
	}
}

// 设置选中行id,仅用于单行选择
function setSelectedId(oRow) {
	var oSelectedId = document.getElementById("selectedId");
	for(var n=0;n<oRow.childNodes.length;n++){			
		for(var k=0;k<oRow.childNodes[n].childNodes.length;k++){
			if(oRow.childNodes[n].childNodes[k].id == "hiddenId") {
				if(oSelectedId != null) {
					oSelectedId.value = oRow.childNodes[n].childNodes[k].value;
				}
			}
		}
	}
}

// 清除选中行id，仅用于单行选择
function clearSelectedId() {
	var oSelectedId = document.getElementById("selectedId");
	if(oSelectedId != null) {
		oSelectedId.value = "";
	}
}

	function thisDetail(tableName,url) {
		var flag = amend(tableName);
		if(flag == -1) {
			return false;
		} else {
			document.getElementById('operateId').value = flag;
			document.forms(0).action = url;
			document.forms(0).submit();
		}
	}

	function amend(tableName) {
		var temptable;
    	temptable = document.getElementById(tableName);
    	var i=0,checkedNum=0;
    	var checked;
    
    	for(i=0;i<temptable.rows.length;i++) {
	 		if(temptable.rows(i).className == "tableConBgSelected") {
	    		checkedNum++;
	    		checked = temptable.rows(i).cells(0).firstChild;
	    		break;
	  		}
    	}

    	if(checkedNum==0) {
      		alert("请选择一栏后执行此操作!");
      		return -1;
   		} else {
    		var id = checked.value;
    		return id;
    	}
	}
	
function remove(tableName) {
	var temptable;  
    temptable = document.getElementById(tableName);
    var i=0,j=0,checkedNum=0;
    var checkedArray = new Array();
    for(i=0;i<temptable.rows.length;i++){
	  if(temptable.rows(i).className == "tableConBgSelected") {
	    checkedNum++;
	    checkedArray[j++] = temptable.rows(i).cells(0).firstChild.value;
	  }
    }
    if(checkedNum==0) {
      	alert("请选择一栏或多栏后执行此操作!");
      	return -1;
    } else {
    	if(confirm("确定要删除吗?")) {
    		return checkedArray.join(",");
    	} else {
    		return -1;
    	}
    }
	
}
function multiAmend(tableName) {
	var temptable;  
    temptable = document.getElementById(tableName);
    var i=0,j=0,checkedNum=0;
    var checkedArray = new Array();
    for(i=0;i<temptable.rows.length;i++){
	  if(temptable.rows(i).className == "tableConBgSelected") {
	    checkedNum++;
	    checkedArray[j++] = temptable.rows(i).cells(0).firstChild.value;
	  }
    }
    if(checkedNum==0) {
      	alert("请选择一栏或多栏后执行此操作!");
      	return -1;
    } else {
    	
    	return checkedArray.join(",");
    	
    }	
}
function thisQuery(form,methodName,methodValue,url) {
	methodName.value = methodValue;
	form.action = url;
	form.submit();
}
function thisAdd(form,methodName,methodValue,url) {
	thisQuery(form,methodName,methodValue,url);
}
function thisModify(form,tableName,operateId,methodName,methodValue,url) {
		var flag = amend(tableName);
		if(flag == -1) {
			return false;
		} else {
			methodName.value = methodValue;
			operateId.value = flag;
			form.action = url;
			form.submit();
		}
}

function thisMultiModify(form,tableName,operateId,methodName,methodValue,url) {
		
		var flag = multiAmend(tableName);
		if(flag == -1) {
			return false;
		} else {
			methodName.value = methodValue;
			operateId.value = flag;
			form.action = url;
			form.submit();
		}
}

function thisRemove(form,tableName,operateId,methodName,methodValue,url) {
		var flag = remove(tableName);
		if(flag == -1) {
			return false;
		} else {
			methodName.value = methodValue;
			operateId.value = flag;
			form.action = url;
			form.submit();
		}
}

function checkSelected(name) {
	var objs = document.getElementsByName(name);
	for(var i = 0; i < objs.length; i++) {
		if(objs[i].checked == true) {
			return true;
		}
	}

	return false;
}
