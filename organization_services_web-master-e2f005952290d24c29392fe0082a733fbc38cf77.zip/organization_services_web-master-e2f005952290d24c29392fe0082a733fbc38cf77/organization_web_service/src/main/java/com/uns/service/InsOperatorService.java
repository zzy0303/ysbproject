package com.uns.service;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uns.dao.SysConfigMapper;
import com.uns.model.SysConfig;
import com.uns.util.*;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSONObject;
import com.uns.common.Constants;
import com.uns.common.page.PageContext;
import com.uns.dao.InsOperatorMapper;
import com.uns.dao.InstitutionMapper;
import com.uns.model.InsOperator;
import com.uns.model.Institution;
import com.uns.web.form.InsOperatorForm;


@Service
public class InsOperatorService extends BaseService{

	@Autowired
	private  InsOperatorMapper insOperatorMapper;
	
	@Autowired
	private InstitutionMapper institutionMapper;

	@Autowired
	private SysConfigMapper sysConfigMapper;

	@Autowired
	private AcmsMapUtils acmsMapUtils;
	
	
	public InsOperator findInsOperatorByTel(String loginName) {
		return insOperatorMapper.findInsOperatorByTel(loginName);
	}


	public void updateInsoperator(InsOperator insoperator) {
		insOperatorMapper.updateByPrimaryKeySelective(insoperator);
	}


	public List<InsOperator> findInsOperatorList(InsOperatorForm insoperatorform) {
		PageContext.initPageSize(Constants.FIND_PAGE_LIST);
		return insOperatorMapper.findInsOperatorList(insoperatorform);
	}


	public boolean findInsOperatorByLoginName(String loginname) {
		InsOperator insOperator=insOperatorMapper.findInsOperatorByTel(loginname);
		boolean isExist = false;
		if(insOperator!=null){
			isExist = true;
		}
		return isExist;
	}


	public void saveInsOperator(InsOperator operator1, InsOperator operator) {
		operator.setPassword(Md5Encrypt.md5(operator.getPassword()));
		operator.setInsNo(operator1.getInsNo());
		operator.setCreateUser(operator1.getId().toString());
		operator.setCreateDate(new Date());
		insOperatorMapper.insertSelective(operator);
	}


	public InsOperator findInsOperator(String insOperatorId) {
		return insOperatorMapper.selectByPrimaryKey(new BigDecimal(insOperatorId));
	}


	public void updateInsOperator(InsOperator operator1, InsOperator operator) {
		operator.setUpdateDate(new Date());
		operator.setUpdateUser(operator1.getId().toString());
		insOperatorMapper.updateByPrimaryKeySelective(operator);
	}


	public boolean checkPassword(String oldpassword, InsOperator operator) {
		String oldpassword1=Md5Encrypt.md5(oldpassword);
		boolean isExist = false;
		if(oldpassword1.equals(operator.getPassword())){
			isExist = true;
		}
		return isExist;
	}


	public void updatePassWord(InsOperator operator1, InsOperator operator) throws IllegalAccessException, InvocationTargetException {
		operator.setPassword(Md5Encrypt.md5(operator.getPassword()));
		operator.setUpdateDate(new Date());
		operator.setUpdateUser(operator1.getId().toString());
		operator.setId(operator1.getId());
		insOperatorMapper.updateByPrimaryKeySelective(operator);
	}


	public void downInsPubkeyFile(HttpServletRequest request, HttpServletResponse response) throws Exception {
		SysConfig sysConfig = sysConfigMapper.selectByKey(Constants.YSB_PUB_KEY);
		FileUtils.downStreamFile(request, response, sysConfig.getKeyValue(),acmsMapUtils.getAcmsMap().get(Constants.YSB_PUB_KEY));
	}


	public void uploadInsPubkey(InsOperator operator, InsOperatorForm mbform) throws IOException {
		// 获得文件
		MultipartFile file = mbform.getInsPubKey();
		// 获取输出流
		InputStream in = file.getInputStream();
		String insPubKey=FileUtils.readInputStream(in);
		JSONObject insPubKeyMap=(JSONObject)FastJson.fromObject(insPubKey);
		
		log.info("公钥："+insPubKeyMap.getString("pubKey"));
		Institution institution=new Institution();
		institution.setInsPubKey(insPubKeyMap.getString("pubKey"));
		institution.setInsNo(operator.getInsNo());
		institutionMapper.updateByPrimaryKeySelective(institution);
	}

}
