package com.uns.web.form;

import org.apache.commons.lang3.StringUtils;


//提现记录查询form
public class WithdrawForm {
	
	private String insNo;//当前登录机构号
	private String customerNo;//商户id
	private String smallMerchNo;//商户编号
	private String tranFlag;//提现状态
	private String customerName;//商户名称
	private String withdrawOrderId;//提现编号
	private String orderId;//订单编号
	private String d0tranTimeStart;//d0交易时间下限
	private String d0tranTimeEnd;//d0交易时间上限
	private String amountStart;//交易金额下限
	private String amountEnd;//交易金额上限
	private String tranTimeStart;//交易时间下限
	private String tranTimeEnd;//交易时间上限
	
	//getter and setter
	public String getInsNo() {
		return insNo;
	}
	public void setInsNo(String insNo) {
		this.insNo = insNo;
	}
	public String getSmallMerchNo() {
		return smallMerchNo;
	}
	public void setSmallMerchNo(String smallMerchNo) {
		this.smallMerchNo = smallMerchNo == null ? "" : smallMerchNo.trim();
	}
	public String getTranFlag() {
		return tranFlag;
	}
	public void setTranFlag(String tranFlag) {
		this.tranFlag = tranFlag;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName == null ? "" : customerName.trim();
	}
	public String getWithdrawOrderId() {
		return withdrawOrderId;
	}
	public void setWithdrawOrderId(String withdrawOrderId) {
		this.withdrawOrderId = withdrawOrderId == null ? "" : withdrawOrderId.trim();
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId == null ? "" : orderId.trim();
	}
	public String getD0tranTimeStart() {
		return d0tranTimeStart;
	}
	public void setD0tranTimeStart(String d0tranTimeStart) {
		this.d0tranTimeStart = d0tranTimeStart;
	}
	public String getD0tranTimeEnd() {
		return d0tranTimeEnd;
	}
	public void setD0tranTimeEnd(String d0tranTimeEnd) {
		this.d0tranTimeEnd = d0tranTimeEnd;
	}
	public String getAmountStart() {
		return amountStart;
	}
	public void setAmountStart(String amountStart) {
		this.amountStart = amountStart == null?"":amountStart.trim();
	}
	public String getAmountEnd() {
		return amountEnd;
	}
	public void setAmountEnd(String amountEnd) {
		this.amountEnd = amountEnd == null?"":amountEnd.trim();
	}
	public String getTranTimeStart() {
		return tranTimeStart;
	}
	public void setTranTimeStart(String tranTimeStart) {
		this.tranTimeStart = tranTimeStart;
	}
	public String getTranTimeEnd() {
		return tranTimeEnd;
	}
	public void setTranTimeEnd(String tranTimeEnd) {
		this.tranTimeEnd = tranTimeEnd;
	}
	public String getCustomerNo() {
		return customerNo;
	}
	public void setCustomerNo(String customerNo) {
		this.customerNo = customerNo;
	}
}
