package com.uns.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import java.util.Map;

import com.squareup.okhttp.FormEncodingBuilder;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import com.uns.common.exception.BusinessException;
import com.uns.common.exception.InnerException;
import org.springframework.web.bind.annotation.RequestBody;


public class HttpClientUtils {
	private static Log log = LogFactory.getLog(HttpClientUtils.class);

	public static <T> T postRequest(String url, Object request,Class<T> clazz) throws Exception {
		log.info("start post request url:" + url);
		HttpPost put = new HttpPost(url);
		HttpResponse httpRes = null;
		try {
			log.info("request params :" + JSONUtil.toJSONString(request));
			StringEntity entity = new StringEntity(JSONUtil.toJSONString(request),"UTF-8");
			entity.setContentType("application/json");
			put.setEntity(entity);
			
			HttpClient client = new DefaultHttpClient();
			httpRes = client.execute(put);
			int statusCode = httpRes.getStatusLine().getStatusCode();
			
			log.info("request end,status : " + statusCode );
			
			if(statusCode == 500)
				throw new BusinessException("服务器问题");
			if(statusCode != 200){
				throw new BusinessException("业务出错");
			}
			
			return JSONUtil.readValue(httpRes.getEntity().getContent(), clazz);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException("内部问题,业务出错");
		}
	}
	
	public static <T> T postRequestStr(String url, String request,Class<T> clazz) throws Exception {
		log.info("start post request url:" + url);
		HttpPost put = new HttpPost(url);
		int statusCode = 200;
		try {
			StringEntity entity = new StringEntity(request,"UTF-8");
			entity.setContentType("application/x-www-form-urlencoded");
			put.setEntity(entity);
			HttpClient client = new DefaultHttpClient();
			
			HttpResponse httpRes = client.execute(put);
			statusCode = httpRes.getStatusLine().getStatusCode();
			log.info("request end,status : " + statusCode);
			if(statusCode != 200)
				log.info("网络请求应答状态错误："+statusCode);
			return JSONUtil.readValue(httpRes.getEntity().getContent(), clazz);
		} catch (Exception e) {
			e.printStackTrace();
			log.info("网络连接错误："+e.getMessage());
			throw new InnerException("0099","网络连接错误：" + e.getMessage());
		}
	}

	public static <T> T postRequestStr1(String url, String request,Class<T> clazz) throws Exception {
		log.info("start post request url:" + url);
		HttpPost put = new HttpPost(url);
		int statusCode = 200;
		try {
			StringEntity entity = new StringEntity(request,"UTF-8");
			entity.setContentType("application/x-www-form-urlencoded");
			put.setEntity(entity);
			HttpClient client = new DefaultHttpClient();

			HttpResponse httpRes = client.execute(put);
			statusCode = httpRes.getStatusLine().getStatusCode();

			log.info("request end,status : " + statusCode);
			if(statusCode != 200)
				log.info("网络请求应答状态错误："+statusCode);
			log.info(httpRes.getEntity().getContent());

			return JSONUtil.readValue(httpRes.getEntity().getContent(), clazz);
		} catch (Exception e) {
			log.info("网络连接错误："+e.getMessage());
			throw new BusinessException("0099","网络连接错误：" + e.getMessage());
		}
	}

	public static <T> T postRequestMap(String url,Map<String,?> reqMap,Class<T> clazz) throws Exception{
		StringBuffer str = new StringBuffer();
		
		Iterator<String> ite = reqMap.keySet().iterator();
		String mKey = null;
		
		while(ite.hasNext()){
			mKey = ite.next();
			str.append(mKey).append("=").append(reqMap.get(mKey)).append("&");
		}
		
		str = str.deleteCharAt(str.lastIndexOf("&"));
		log.info("请求："+url+str.toString());
		return postRequestStr(url, str.toString(),clazz);
		
	}

	public static <T> T postRequestMap2(String url,Map<String,?> reqMap,Class<T> clazz) throws Exception{
		StringBuffer str = new StringBuffer();
		Iterator<String> ite = reqMap.keySet().iterator();
		String mKey = null;

		while(ite.hasNext()){
			mKey = ite.next();
			str.append(mKey).append("=").append(reqMap.get(mKey)).append("&");
		}
		str = str.deleteCharAt(str.lastIndexOf("&"));
		System.out.println(str);
		return postRequestStr1(url, str.toString(),clazz);
	}
	
	public static Integer postRequestUrl(String url){
		int result = 0;
		try {
			URL u = new URL(url);
			try {
				HttpURLConnection uConnection = (HttpURLConnection) u.openConnection();
				try {
					uConnection.connect();
					result = uConnection.getResponseCode();
					System.out.println(uConnection.getResponseCode());
					InputStream is = uConnection.getInputStream();
					BufferedReader br = new BufferedReader(new InputStreamReader(is));
					StringBuilder sb = new StringBuilder();
					while(br.read() != -1){
						sb.append(br.readLine());
					}
					String content = new String(sb);
					content = new String(content.getBytes("GBK"), "ISO-8859-1");
					System.out.println(content);
					br.close();
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println("connect failed");
				}
				
			} catch (IOException e) {
				System.out.println("build failed");
				e.printStackTrace();
			}
			
		} catch (MalformedURLException e) {
			System.out.println("build url failed");
			e.printStackTrace();
		}
		
		return result;
	}
	
	public static String postRequestXml(String url, String xml) throws Exception {
		log.info("start post request url:" + url);
		HttpPost put = new HttpPost(url);
		try {
			log.info("request params :" + xml);
			StringEntity entity = new StringEntity(xml,"UTF-8");
			entity.setContentType("text/plain");
			put.setEntity(entity);
			
			HttpClient client = new DefaultHttpClient();
			
			HttpResponse httpRes = client.execute(put);
			int statusCode = httpRes.getStatusLine().getStatusCode();
			
			log.info("request end,status : " + statusCode);
			if(statusCode != 200)
				throw new BusinessException("0098","网络请求应答状态错误：" + statusCode);
			
			String result = EntityUtils.toString(httpRes.getEntity(),"UTF-8");
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException("0099","网络连接错误：" + e.getMessage());
		}
	}
	

	public static String REpostRequestStr(String url, String request) throws Exception{
		log.info("start post request url:" + url);
		HttpPost put = new HttpPost(url);
		int statusCode = 200;
		try {
			StringEntity entity = new StringEntity(request,"UTF-8");
			entity.setContentType("application/x-www-form-urlencoded");
			put.setEntity(entity);
			HttpClient client = new DefaultHttpClient();
			
			HttpResponse httpRes = client.execute(put);
			statusCode = httpRes.getStatusLine().getStatusCode();
					
			log.info("request end,status : " + statusCode);
			if(statusCode != 200)
				throw new BusinessException("0098","网络请求应答状态错误：" + statusCode);
			
			String result = EntityUtils.toString(httpRes.getEntity(),"UTF-8");
			return result;
		} catch (Exception e) {
			log.info("网络连接错误："+e.getMessage());
			throw new BusinessException("0099","网络连接错误：" + e.getMessage());
		}
	}
	
	public static String getRequestUrl(String url) {  
		log.info("start get request url:"+url);
        HttpPost put = new HttpPost(url);
        int statusCode = 200;
        String result = "";
        try{
        	HttpClient client = new DefaultHttpClient();
        	HttpResponse httpRes = client.execute(put);  
        	statusCode = httpRes.getStatusLine().getStatusCode();
        	
            if (statusCode == 200) {  
                result = EntityUtils.toString(httpRes.getEntity(),"UTF-8");  
                return result;
            }  
        } catch (Exception e) {  
            log.info("网络连接错误："+e.getMessage());
        }  
        return result;
    }  
	
	
	

	public static <T> String postRequestString(String url,Map<String,?> reqMap,Class<T> clazz) throws Exception{
		StringBuffer str = new StringBuffer();
		
		Iterator<String> ite = reqMap.keySet().iterator();
		String mKey = null;
		
		while(ite.hasNext()){
			mKey = ite.next();
			str.append(mKey).append("=").append(reqMap.get(mKey)).append("&");
		}
		
		str = str.deleteCharAt(str.lastIndexOf("&"));
		log.info("请求："+url+str.toString());
		return REpostRequestStr(url,str.toString());
		
	}

	public static String REpostRequestStrJson(String url, String request) throws BusinessException{
		log.info("start post request url:" + url +",request param:" + request);
		HttpPost put = new HttpPost(url);
		int statusCode = 200;
		try {
			StringEntity entity = new StringEntity(request,"UTF-8");
			entity.setContentType("application/json");
			put.setEntity(entity);
			HttpClient client = new DefaultHttpClient();

			HttpResponse httpRes = client.execute(put);
			statusCode = httpRes.getStatusLine().getStatusCode();

			log.info("request end,status : " + statusCode);
			if(statusCode != 200)
				throw new BusinessException("0098","网络请求应答状态错误：" + statusCode);

			String result = EntityUtils.toString(httpRes.getEntity(),"UTF-8");
			return result;
		} catch (Exception e) {
			log.info("网络连接错误："+e.getMessage());
		}
		return null;
	}
	
}
