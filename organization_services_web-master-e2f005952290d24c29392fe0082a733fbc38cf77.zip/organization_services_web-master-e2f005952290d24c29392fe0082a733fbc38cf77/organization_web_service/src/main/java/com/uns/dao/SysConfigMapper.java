package com.uns.dao;

import com.uns.model.SysConfig;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

@Repository
public interface SysConfigMapper {

    int deleteByPrimaryKey(BigDecimal id);

    int insert(SysConfig record);

    int insertSelective(SysConfig record);

    SysConfig selectByPrimaryKey(BigDecimal id);

    int updateByPrimaryKeySelective(SysConfig record);

    int updateByPrimaryKey(SysConfig record);

    SysConfig selectByKey(String key);
}