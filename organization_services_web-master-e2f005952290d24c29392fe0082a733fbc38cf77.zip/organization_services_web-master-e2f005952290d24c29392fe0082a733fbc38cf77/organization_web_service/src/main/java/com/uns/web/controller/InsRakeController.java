package com.uns.web.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.model.InsOperator;
import com.uns.model.InsRake;
import com.uns.model.RakeWithdraw;
import com.uns.service.InsRakeService;
import com.uns.util.ExcelUtils;
import com.uns.util.StringUtils;

/**
 * 抽成管理
 * @author yang.cheng
 *
 */
@Controller
@RequestMapping(value = "/percentag.htm")
public class InsRakeController extends BaseController {
	
	@Autowired
	InsRakeService insRakeService;

	
	/**
	 * 查询抽成列表
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params="method=findPercentagList")
	public String findPercentagList(HttpServletRequest request, HttpServletResponse response, InsRake insRake) throws BusinessException{
		try {
			//处理抽成批次送过来的时间
			if(null != insRake.getPercentageTime()){
				String percentageTime= insRake.getPercentageTime();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = sdf.parse(percentageTime);
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(date);
				calendar.add(Calendar.DAY_OF_MONTH, -1);
				sdf = new SimpleDateFormat("yyyy-MM-dd");
				insRake.settranTimeStart(sdf.format(calendar.getTime()));
				insRake.settranTimeEnd(sdf.format(calendar.getTime()));
			}
			InsOperator operator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			insRake.setInsNo(operator.getInsNo());
			List insRakeList = insRakeService.findInsRakeList(insRake,false);
			request.setAttribute("insRake", insRake);
			request.setAttribute("insRakeList", insRakeList);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException("查询抽成列表失败");
		}
		return "insrake/insRakeList";
	}
	
	/**
	 * 跳转到导出excel界面
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params="method=exportInsRakeList")
	public String exportInsRakeList(HttpServletRequest request, HttpServletResponse response, InsRake insRake) throws BusinessException{
		try {
			InsOperator operator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			insRake.setInsNo(operator.getInsNo());
			Page page  = new Page();
			page.setPageSize(Constants.EXCEL_SIZE);
			PageContext context = PageContext.getContext();
			BeanUtils.copyProperties(context, page);
			context.setPagination(true);
			insRakeService.findInsRakeList(insRake,true);
			
			BeanUtils.copyProperties(page, context);
			request.setAttribute("page",page);
			request.setAttribute("insRake", insRake);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException("跳转抽成导出页面失败");
		}
		return "insrake/insRakeExportPage";
	}
	
	/**
	 * 交易数据导出下载
	 * @param request
	 * @param response
	 * @param modelMap
	 * @param tQrCodeTransForm
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params="method=downExportInsRakeList")
	public String downExportInsRakeList(HttpServletRequest request, HttpServletResponse response, InsRake insRake) throws BusinessException{
		try{
			InsOperator operator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			insRake.setInsNo(operator.getInsNo());
			String tPage = request.getParameter("page");
			if (StringUtils.isEmpty(tPage) || !org.apache.commons.lang3.StringUtils.isNumeric(tPage)){
				tPage = "1";
			}
			int currentPage = Integer.valueOf(tPage);
			Page page  = new Page();
			page.setPageSize(Constants.EXCEL_SIZE);
			PageContext context = PageContext.getContext();
			BeanUtils.copyProperties(context, page);
			context.setPagination(true);
			context.setCurrentPage(currentPage);
			List insRakeList = insRakeService.findInsRakeList(insRake,true);
			//标题
			Map<String, String> mapField = new LinkedHashMap<String, String>();
			mapField.put("CUSTOMERNO","商户编号");              
			mapField.put("SCOMPANY","商户名称");          
			mapField.put("ORDERID","订单编号");              
			mapField.put("AMOUNT","交易金额");          
			mapField.put("TRANTIME","交易时间");     
			mapField.put("PERCENTAG","抽成比例(%)");         
			mapField.put("PERCENTAGAMOUNT","抽成金额");
			String fileNames="insRakeExport";
			String sheetNames="抽成汇总";
			ExcelUtils.downExcel(insRakeList, response, mapField, fileNames, sheetNames);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException("抽成导出失败");
		}
		return null;
	}
	
	
	
	/**
	 * 查询抽成批次列表
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params="method=findPercentagTxList")
	public String findPercentagTxList(HttpServletRequest request, HttpServletResponse response, RakeWithdraw rakeWithdraw) throws BusinessException{
		try {
			InsOperator operator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			rakeWithdraw.setInsNo(operator.getInsNo());
			List rakeWithdrawList = insRakeService.findRakeWithdrawList(rakeWithdraw,false);
			request.setAttribute("rakeWithdrawList", rakeWithdrawList);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException("抽成提现查询失败");
		}
		return "insrake/rakeWithdrawList";
	}
	
	/**
	 * 跳转到导出excel界面
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params="method=exportRakeWithdrawList")
	public String exportRakeWithdrawList(HttpServletRequest request, HttpServletResponse response, RakeWithdraw rakeWithdraw) throws BusinessException{
		try {
			InsOperator operator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			rakeWithdraw.setInsNo(operator.getInsNo());
			Page page  = new Page();
			page.setPageSize(Constants.EXCEL_SIZE);
			PageContext context = PageContext.getContext();
			BeanUtils.copyProperties(context, page);
			context.setPagination(true);
			insRakeService.findRakeWithdrawList(rakeWithdraw,true);
			BeanUtils.copyProperties(page, context);
			request.setAttribute("page",page);
			request.setAttribute("rakeWithdraw", rakeWithdraw);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException("跳转抽成提现页面失败");
		}
		return "insrake/rakeWithdrawExportPage";
	}
	
	/**
	 * 交易数据导出下载
	 * @param request
	 * @param response
	 * @param modelMap
	 * @param tQrCodeTransForm
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params="method=downExportRakeWithdrawList")
	public String downExportRakeWithdrawList(HttpServletRequest request, HttpServletResponse response, RakeWithdraw rakeWithdraw) throws BusinessException{
		try{
			InsOperator operator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			rakeWithdraw.setInsNo(operator.getInsNo());
			String tPage = request.getParameter("page");
			if (StringUtils.isEmpty(tPage) || !org.apache.commons.lang3.StringUtils.isNumeric(tPage)){
				tPage = "1";
			}
			int currentPage = Integer.valueOf(tPage);
			Page page  = new Page();
			page.setPageSize(Constants.EXCEL_SIZE);
			PageContext context = PageContext.getContext();
			BeanUtils.copyProperties(context, page);
			context.setPagination(true);
			context.setCurrentPage(currentPage);
			List rakeWithdrawList = insRakeService.findRakeWithdrawList(rakeWithdraw,true);
			//标题
			Map<String, String> mapField = new LinkedHashMap<String, String>();
			mapField.put("BATCHNO","批次号");              
			mapField.put("TRANTIME","批次生成时间");     
			mapField.put("AMOUNT","抽成金额");
			mapField.put("TRANFLAG","批次状态");         
			String fileNames="rakeWithdrawExport";
			String sheetNames="抽成提现导出";
			ExcelUtils.downExcel(rakeWithdrawList, response, mapField, fileNames, sheetNames);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException("抽成提现导出失败");
		}
		return null;
	}
}
