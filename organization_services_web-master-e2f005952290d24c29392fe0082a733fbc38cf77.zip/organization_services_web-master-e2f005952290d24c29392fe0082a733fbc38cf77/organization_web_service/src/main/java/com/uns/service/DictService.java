package com.uns.service;

import com.uns.dao.B2cDictMapper;
import com.uns.dao.DictMapper;
import com.uns.model.B2cDict;
import com.uns.model.Dict;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/2/27
 * @Modifyed By:
 */
@Service
public class DictService {

    @Autowired
    DictMapper dictMapper;

    @Autowired
    B2cDictMapper b2cDictMapper;

    public List<Dict> findByType(String industry_type) {

        return dictMapper.findByType(industry_type);
    }

    public List<B2cDict> findAllBank() {
        return b2cDictMapper.findAllBank();
    }
}
