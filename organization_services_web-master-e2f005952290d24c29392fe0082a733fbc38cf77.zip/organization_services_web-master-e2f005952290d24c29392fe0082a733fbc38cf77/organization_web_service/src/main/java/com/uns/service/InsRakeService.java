package com.uns.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.common.page.PageContext;
import com.uns.dao.InsRakeMapper;
import com.uns.dao.TQrCodeTransMapper;
import com.uns.model.InsRake;
import com.uns.model.RakeWithdraw;
import com.uns.web.form.TQrCodeTransForm;
import com.uns.web.form.WithdrawForm;

@Service
public class InsRakeService  extends BaseService {
	
	@Autowired
	InsRakeMapper  insRakeMapper;
	/**
	 * 机构抽成查询
	 * @param insRake  查询条件
	 * @param isExport 是否是导出查询
	 * @return
	 */
	public List findInsRakeList(InsRake insRake,boolean isExport){
		if(isExport){//导出
			PageContext.initPageSize(Constants.EXCEL_SIZE);
		}else{
			PageContext.initPageSize(Constants.FIND_PAGE_LIST);
		}
		return insRakeMapper.findInsRakeList(insRake);
	}
	
	/**
	 * 
	 * @param percentag  查询条件
	 * @param isExport 是否是导出查询
	 * @return
	 */
	public List findRakeWithdrawList(RakeWithdraw rakeWithdraw,boolean isExport){
		if(isExport){//导出
			PageContext.initPageSize(Constants.EXCEL_SIZE);
		}else{
			PageContext.initPageSize(Constants.FIND_PAGE_LIST);
		}
		return insRakeMapper.findRakeWithdrawList(rakeWithdraw);
	}
}
