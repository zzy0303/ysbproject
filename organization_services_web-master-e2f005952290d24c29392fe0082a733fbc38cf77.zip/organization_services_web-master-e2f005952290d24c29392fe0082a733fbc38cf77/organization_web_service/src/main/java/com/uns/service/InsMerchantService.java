package com.uns.service;

import com.alibaba.fastjson.JSONObject;
import com.uns.bean.BankCardValBean;
import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.PageContext;
import com.uns.dao.*;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.model.*;
import com.uns.util.*;
import com.uns.web.form.CommissionForm;
import com.uns.web.form.CustomerForm;
import org.apache.commons.lang3.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sun.misc.BASE64Encoder;

import java.io.FileInputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.*;

@Service
public class InsMerchantService extends BaseService {

    private Logger log = LoggerFactory.getLogger(this.getClass());

    @Autowired
    CustomerMapper customerMapper;

    @Autowired
    InstitutionMapper institutionMapper;

    @Autowired
    CommissionpolicyMapper commissionpolicyMapper;

    @Autowired
    SysAreaMapper sysAreaMapper;

    @Autowired
    MposPhotoTmpMapper mposPhotoTmpMapper;

    @Autowired
    B2cDictMapper b2cDictMapper;

    public String findInsMerchantCount(String insNo) {
        return customerMapper.findInsMerchantCount(insNo);
    }

    public List findInsCustomerList(CustomerForm customerForm) {
        PageContext.initPageSize(Constants.FIND_PAGE_LIST);
        return customerMapper.findInsCustomerList(customerForm);
    }

    public Customer findInsCustomerDetail(Long thisCustomerId) {
        return customerMapper.findInsCustomerDetail(thisCustomerId);
    }

    //查询到所属机构
    public Institution findBelongIns(Customer thisCustomer) {
        return institutionMapper.findInstitution(thisCustomer.getInsNo());
    }

    //查询当前商户费率
    public List findCommissionpolicy(Long thisCustomerId) {
        return commissionpolicyMapper.findCommissionpolicy(thisCustomerId);
    }

    //字段加星号处理
    public Customer asteriskSolution(Customer thisCustomer) throws BusinessException {
        //处理身份证号
        String tmpstr;
        if (null != (tmpstr = thisCustomer.getCertId())) {
            thisCustomer.setScertid(StringUtils.asteriskStr(tmpstr, Constants.ASTERISK_CERTID));
        }

        //处理银行卡号
        if (null != (tmpstr = thisCustomer.getBankcardno())) {
            thisCustomer.setSbankcardno(StringUtils.asteriskStr(tmpstr, Constants.ASTERISK_BANKCARDNO));
        }

        //处理姓名
        if (null != (tmpstr = thisCustomer.getName())) {
            thisCustomer.setSname(StringUtils.asteriskStr(tmpstr, Constants.ASTERISK_NAME));
        }

        //处理联系人姓名
        if (null != (tmpstr = thisCustomer.getLinkman())) {
            thisCustomer.setSlinkman(StringUtils.asteriskStr(tmpstr, Constants.ASTERISK_NAME));
        }

        //处理手机号
        if (null != (tmpstr = thisCustomer.getPhone())) {
            thisCustomer.setSphone(StringUtils.asteriskStr(tmpstr, Constants.ASTERISK_PHONE));
        }
        return null;
    }

    public SysArea findOpeningBankArea(Customer thisCustomer) {
        return sysAreaMapper.findAreaByYsb(thisCustomer);
    }

    /**
     * 验证身份证号是否已被注册
     *
     * @param idCard
     * @param operator
     * @return
     */
    public boolean checkIdCard(String idCard, InsOperator operator) {
        Map map = new HashMap(2);
        map.put("idCard", idCard);
        map.put("insNo", operator.getInsNo());
        Customer customer = customerMapper.checkIdCard(map);
        if (null == customer) {
            return false;
        }
        return true;
    }

    /**
     * 机构商户注册
     * 1：图片上传
     * 2：三要素鉴权
     * 3：调用业务系统接口注册商户
     * 4：保存商户信息
     * 5：保存费率信息
     *
     * @param customer
     * @throws Exception
     */
    @Transactional(rollbackFor = Exception.class)
    public void insCustomerReg(Customer customer) throws Exception {
        //图片上传
        MposPhotoTmp mposPhotoTmp = uploadImage(customer);
        //初始化商户信息
        customer.setPhotoId(mposPhotoTmp.getPhotoId().longValue());
        initCustomer(customer);

        Map<String, String> result;
        if (Constants.BIG_SHORT_1.equals(customer.getCustomertype())) {
            //三要素鉴权
            authentication(customer);
            //注册个人
            result = insRegisterPersonal(customer);
        } else {
            //注册企业
            result = insRegisterCompany(customer);
        }
        //保存商户信息
        saveCustomer(result, customer);
    }

    /**
     * 保存商户费率信息
     *
     * @param customer
     */
    protected void saveCommission(Customer customer) {
        CommissionForm commissionForm = customer.getCommissionForm();
        //扫码费率
        if (customer.getIndustryType().indexOf(Constants.STATUS_0) != -1) {
            //微信费率
            Commissionpolicy wxCommissionpolicy = new Commissionpolicy();
            wxCommissionpolicy.setCustomerid(customer.getCustomerid());
            wxCommissionpolicy.setCommissiontype(new Short(Constants.STATUS_0));
            wxCommissionpolicy.setFeever(Constants.STATUS_0);
            wxCommissionpolicy.setCommissionRate(commissionForm.getWxT1Fee().multiply(new BigDecimal(100)).longValue());
            wxCommissionpolicy.setD0CommissionRate(commissionForm.getWxD0Fee().multiply(new BigDecimal(100)).longValue());
            wxCommissionpolicy.setCardtype(new Short(Constants.STATUS_2));
            commissionpolicyMapper.insertSelective(wxCommissionpolicy);
            commissionpolicyMapper.insertHisSelective(wxCommissionpolicy);
            //支付宝费率
            Commissionpolicy zfbCommissionpolicy = new Commissionpolicy();
            zfbCommissionpolicy.setCustomerid(customer.getCustomerid());
            zfbCommissionpolicy.setCommissiontype(new Short(Constants.STATUS_0));
            zfbCommissionpolicy.setFeever(Constants.STATUS_0);
            zfbCommissionpolicy.setCommissionRate(commissionForm.getZfbT1Fee().multiply(new BigDecimal(100)).longValue());
            zfbCommissionpolicy.setD0CommissionRate(commissionForm.getZfbD0Fee().multiply(new BigDecimal(100)).longValue());
            zfbCommissionpolicy.setCardtype(new Short(Constants.STATUS_3));
            commissionpolicyMapper.insertSelective(zfbCommissionpolicy);
            commissionpolicyMapper.insertHisSelective(zfbCommissionpolicy);
        }
        if (customer.getIndustryType().indexOf(Constants.STATUS_1) != -1) {
            //速惠快捷
            Commissionpolicy shCommissionpolicy = new Commissionpolicy();
            shCommissionpolicy.setCustomerid(customer.getCustomerid());
            shCommissionpolicy.setCommissiontype(new Short(Constants.STATUS_0));
            shCommissionpolicy.setFeever(Constants.STATUS_0);
            shCommissionpolicy.setCommissionRate(0L);
            shCommissionpolicy.setD0CommissionRate(commissionForm.getKjShD0Fee().multiply(new BigDecimal(100)).longValue());
            shCommissionpolicy.setCardtype(new Short(Constants.STATUS_7));
            commissionpolicyMapper.insertSelective(shCommissionpolicy);
            commissionpolicyMapper.insertHisSelective(shCommissionpolicy);
        }
    }

    /**
     * 保存商户信息
     *
     * @param result
     * @param customer
     */
    protected void saveCustomer(Map<String, String> result, Customer customer) {
        customer.setCascustomid(Long.valueOf(result.get("userId")));
        customer.setYsbuserid(Long.valueOf(result.get("ysbUserId")));
        customer.setAccountBankId(Long.valueOf(result.get("accountBankId")));
        customerMapper.insertSelective(customer);
        customerMapper.insertHisSelective(customer);

        //保存商户费率信息
        saveCommission(customer);
    }

    /**
     * 机构商户个人注册
     *
     * @param customer
     * @return
     * @throws Exception
     */
    protected Map<String, String> insRegisterPersonal(Customer customer) throws Exception {
        Map<String, String> params = new HashMap<String, String>();
        params.put("merchantKey", DynamicConfigLoader.getByEnv("merchantKey"));
        params.put("merchantId", DynamicConfigLoader.getByEnv("merchantId"));
        params.put("insNo", customer.getInsNo());
        params.put("orderId", DateUtils.getCurrentDateStr());
        params.put("orderTime", DateUtils.getCurrentDateStr() + DateUtils.randomSixLength());
        params.put("name", customer.getName());
        params.put("idNum", customer.getCertId());
        params.put("mobilePhoneNum", customer.getPhone());
        params.put("bankCode", customer.getBankCode());
        params.put("bankNo", customer.getBankcardno());
        params.put("bankName", customer.getBankName());
        params.put("prov", customer.getProvince());
        params.put("city", customer.getCity());
        params.put("userType", Constants.REGISTER_CUSTOMER_USERTYPE_P);
        params.put("merchantNo", customer.getSmallMerchNo());
        //默认支持D0和T1
        params.put("issupportt0", customer.getDynCodeType().toString());
        params.put("scompany", customer.getScompany());
        //默认支持D0和T1
        params.put("settleType", customer.getFixCodeType().toString());
        params.put("creditLines", customer.getCreditLines().toString());
        params.put("activeStatus", customer.getActivestatus().toString());
        log.info("注册机构个人商户请求参数：{}", FastJson.toJson(params));
        Map<String, String> result = HttpClientUtils.postRequest(ConstantsEnv.CUSTOMER_REG_P_URL, params, Map.class);
        log.info("注册机构个人商户返回参数：{}", FastJson.toJson(result));
        if (null == result) {
            throw new BusinessException(ExceptionDefine.机构商户注册失败);
        }
        if (!Constants.STATUS_0000.equals(result.get("rspCode"))) {
            throw new BusinessException(ExceptionDefine.机构商户注册失败);
        }
        return result;
    }

    /**
     * 机构商户企业注册
     *
     * @param customer
     * @return
     * @throws Exception
     */
    protected Map<String, String> insRegisterCompany(Customer customer) throws Exception {
        Map<String, String> params = new HashMap<String, String>();
        params.put("merchantKey", DynamicConfigLoader.getByEnv("merchantKey"));
        params.put("merchantId", DynamicConfigLoader.getByEnv("merchantId"));
        params.put("insNo", customer.getInsNo());
        params.put("orderId", DateUtils.getCurrentDateStr());
        params.put("orderTime", DateUtils.getCurrentDateStr() + DateUtils.randomSixLength());
        params.put("userType", Constants.REGISTER_CUSTOMER_USERTYPE_C);
        params.put("idNum", customer.getCertId());
        params.put("register_corpTel", customer.getPhone());
        params.put("register_prinName", customer.getName());
        params.put("prov", customer.getProvince());
        params.put("city", customer.getCity());
        params.put("bankCode", customer.getBankCode());
        params.put("bankNo", customer.getBankcardno());
        params.put("bankName", customer.getBankName());
        params.put("merchantNo", getMerchantNo(customer.getCity(), Constants.CON_MCC));
        params.put("issupportt0", "0");
        params.put("settleType", "0");
        params.put("creditLines", new BigDecimal("50000").toString());
        params.put("register_corpFinanceName", customer.getName());
        params.put("register_corpName", customer.getName());
        params.put("register_email", "");
        params.put("register_corpAccountLicenceNo", customer.getBusinessLicenseNo());
        params.put("register_corpOrganizeNo", customer.getBusinessLicenseNo());
        params.put("register_corpTaxId", customer.getBusinessLicenseNo());
        params.put("register_corpAddr", customer.getMerchAddress());
        params.put("register_corpZip", "");
        params.put("linkMan", customer.getLinkman());
        params.put("register_corpLicenceNo", customer.getBusinessLicenseNo());
        params.put("activeStatus", "1");
        log.info("注册机构企业商户请求参数：{}", FastJson.toJson(params));
        Map<String, String> result = HttpClientUtils.postRequest(ConstantsEnv.CUSTOMER_REG_C_URL, params, Map.class);
        log.info("注册机构企业商户返回参数：{}", FastJson.toJson(result));
        if (null == result) {
            throw new BusinessException(ExceptionDefine.机构商户注册失败);
        }
        if (!Constants.STATUS_0000.equals(result.get("rspCode"))) {
            throw new BusinessException(ExceptionDefine.机构商户注册失败);
        }
        return result;
    }

    protected void initCustomer(Customer customer) throws Exception {
        customer.setBankName(b2cDictMapper.findBankByDictId(customer.getBankCode()));
        customer.setSmallMerchNo(getMerchantNo(customer.getCity(), Constants.CON_MCC));
        customer.setStatus(Constants.SHORT_1);
        customer.setActivestatus(Constants.SHORT_1);
        customer.setDynCodeType(Constants.SHORT_0);
        customer.setFixCodeType(Constants.SHORT_0);
        customer.setCertType(Constants.STATUS_0);
        customer.setCreditLines(new BigDecimal("50000"));
        customer.setCreatedate(new Date());
        customer.setUpdatedate(new Date());
        customer.setCheckstatus(Constants.STATUS_0);
        customer.setPayType(Constants.STATUS_1);
        customer.setFeever(Constants.SHORT_0);
        customer.setProtocolNum(DateUtils.getCurrentDateStr() + DateUtils.randomFourLength());
    }

    /**
     * 生成编码
     *
     * @param area 自定义的城市编码
     * @param mcc
     * @return
     * @throws Exception
     */
    public String getMerchantNo(String area, String mcc) throws Exception {
        String organization = "600";
        String areacold = "";
        if (area.length() > 4) {
            areacold = area.substring(0, 4);
        } else {
            areacold = area;
        }
        String mcccold = String.format("%1$04d", Integer.parseInt(mcc));
        String merchantRadom = RandomStringUtils.randomNumeric(4);
        String smallMerchNo = organization + areacold + mcccold + merchantRadom;
        int flag = customerMapper.getBySmallMerchNo(smallMerchNo);
        if (flag < 1) {
            return smallMerchNo;
        }
        return getMerchantNo(area, mcc);
    }

    /**
     * 请求CardBin获取卡信息
     *
     * @param bankCardNo
     * @return
     * @throws Exception
     */
    protected String getBankCode(String bankCardNo) throws Exception {
        Map<String, String> reqMap = new HashMap<String, String>();
        reqMap.put("cardNo", bankCardNo);
        String cardBinUrl = DynamicConfigLoader.getByEnv("cardBin_url");
        log.info("请求CardBin获取bankCode 请求参数：{}", FastJson.toJson(reqMap));
        Map<String, String> resultMap = HttpClientUtils.postRequestMap(cardBinUrl, reqMap, Map.class);
        if (null == resultMap) {
            throw new BusinessException(ExceptionDefine.获取卡信息失败);
        }
        log.info("请求CardBin获取bankCode 返回参数：{}", FastJson.toJson(resultMap));
        if (!"Y".equals(resultMap.get("retCode"))) {
            throw new BusinessException(ExceptionDefine.获取卡信息失败);
        }
        String data = FastJson.toJson(resultMap.get("data"));
        JSONObject object = JSONObject.parseObject(data);
        return object.getString("issCode");
    }

    /**
     * 商户三要素鉴权
     *
     * @param customer
     * @throws Exception
     */
    protected void authentication(Customer customer) throws Exception {
        String result = AuthenticAtionUtils.authentication(customer.getBankcardno(), customer.getName(), customer.getCertId());
        if (null == result) {
            throw new BusinessException(ExceptionDefine.机构商户注册失败);
        }
        BankCardValBean bankCardValBean = JSONObject.parseObject(result, BankCardValBean.class);
        if (Constants.STATUS_1111.equals(bankCardValBean.getResult_code()) || Constants.STATUS_2033.equals(bankCardValBean.getResult_code())) {
            throw new BusinessException(ExceptionDefine.机构商户注册失败);
        } else if (Constants.STATUS_1005.equals(bankCardValBean.getResult_code())) {
            throw new BusinessException(ExceptionDefine.身份证号格式不正确);
        } else if (Constants.STATUS_0000.equals(bankCardValBean.getResult_code()) && Constants.STATUS_20.equals(bankCardValBean.getStatus())) {
            throw new BusinessException(ExceptionDefine.信息不匹配);
        }
    }

    /**
     * 商户图片信息上传
     *
     * @param customer
     * @throws Exception
     */
    protected MposPhotoTmp uploadImage(Customer customer) throws Exception {
        //插入图片信息
        MposPhotoTmp mposPhotoTmp = insertInsImage(customer);

        //调用image_pos接口 上传图片
        Map<String, String> map = new HashMap(13);
        CommissionForm commissionForm = customer.getCommissionForm();
        map.put("idCard", customer.getCertId());
        map.put("faceIdCard", encodeBase64(new FileInputStream(CompressPic.compressPic(commissionForm.getFaceIdCard()))));
        map.put("backIdCard", encodeBase64(new FileInputStream(CompressPic.compressPic(commissionForm.getBackIdCard()))));
        map.put("handIdCard", encodeBase64(new FileInputStream(CompressPic.compressPic(commissionForm.getHandIdCard()))));
        map.put("debitCard", encodeBase64(new FileInputStream(CompressPic.compressPic(commissionForm.getDebitCard()))));
        if (Constants.SHORT_2 == customer.getCustomertype()) {
            map.put("businessLicence", encodeBase64(new FileInputStream(CompressPic.compressPic(commissionForm.getBusinessLicence()))));
            map.put("accountOpenPermit", encodeBase64(new FileInputStream(CompressPic.compressPic(commissionForm.getAccountOpenPermit()))));
        }
        map.put("faceIdCardUUID", mposPhotoTmp.getFaceIdcardPhoto());
        map.put("backIdCardUUID", mposPhotoTmp.getBackIdcardPhoto());
        map.put("handIdCardUUID", mposPhotoTmp.getHandIdcardPhoto());
        map.put("debitCardUUID", mposPhotoTmp.getDebitPhoto());
        if (Constants.SHORT_2 == customer.getCustomertype()) {
            map.put("businessLicenceUUID", mposPhotoTmp.getLicensePhoto());
            map.put("accountOpenPermitUUID", mposPhotoTmp.getOpenpermitPhoto());
        }
        String result = OkHttpUtil.post(DynamicConfigLoader.getByEnv("upload_image_url"), map);
        if (null == result) {
            throw new BusinessException(ExceptionDefine.图片上传失败);
        }
        Map resultMap = JSONObject.parseObject(result);
        if (!Constants.STATUS_0000.equals(resultMap.get("rspCode"))) {
            throw new BusinessException(ExceptionDefine.图片上传失败);
        }
        return mposPhotoTmp;
    }

    /**
     * Base64 图片加密
     *
     * @param inputStream
     * @return
     * @throws Exception
     */
    protected String encodeBase64(InputStream inputStream) throws Exception {
        try {
            byte[] data = new byte[inputStream.available()];
            inputStream.read(data);
            inputStream.close();
            String encodeBase64String = new BASE64Encoder().encode(data);
            return encodeBase64String;
        } finally {
            if (null != inputStream) {
                inputStream.close();
            }
        }
    }

    public MposPhotoTmp insertInsImage(Customer customer) throws Exception {

        Map<String, String> map = new HashMap<>(2);
        map.put("idCard", customer.getCertId());
        map.put("insNo", customer.getInsNo());
        mposPhotoTmpMapper.deleteByParam(map);

        MposPhotoTmp mposPhotoTmp = new MposPhotoTmp();
        mposPhotoTmp.setFaceIdcardPhoto(getUUID());
        mposPhotoTmp.setBackIdcardPhoto(getUUID());
        mposPhotoTmp.setHandIdcardPhoto(getUUID());
        mposPhotoTmp.setDebitPhoto(getUUID());
        if (Constants.SHORT_2 == customer.getCustomertype()) {
            mposPhotoTmp.setLicensePhoto(getUUID());
            mposPhotoTmp.setOpenpermitPhoto(getUUID());
        }
        mposPhotoTmp.setIdCardNo(customer.getCertId());
        mposPhotoTmp.setInsNo(customer.getInsNo());
        mposPhotoTmpMapper.insertSelective(mposPhotoTmp);
        return mposPhotoTmp;
    }

    protected String getUUID() throws Exception {
        UUID uuid = UUID.randomUUID();
        String str = uuid.toString();
        String uuidStr = str.replace("-", "");
        return uuidStr.toUpperCase();
    }

    public MposPhotoTmp findInsPhoto(Long photoId) {
        return mposPhotoTmpMapper.selectByPrimaryKey(new BigDecimal(photoId));
    }
}
