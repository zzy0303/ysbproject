package com.uns.web.form;

import org.springframework.web.multipart.MultipartFile;

public class InsOperatorForm {
	
	private String loginNameq;
	private String statusq;
	private String usernameq;
	private String startTime;
	private String endTime;
	private String insRoleSeq;
	private String lastStartTime;
	private String lastEndTime;
	private String insNo;
	private MultipartFile insPubKey;
	
	
	
	public MultipartFile getInsPubKey() {
		return insPubKey;
	}
	public void setInsPubKey(MultipartFile insPubKey) {
		this.insPubKey = insPubKey;
	}
	public String getInsNo() {
		return insNo;
	}
	public void setInsNo(String insNo) {
		this.insNo = insNo;
	}
	public String getLoginNameq() {
		return loginNameq;
	}
	public void setLoginNameq(String loginNameq) {
		this.loginNameq = loginNameq;
	}
	public String getStatusq() {
		return statusq;
	}
	public void setStatusq(String statusq) {
		this.statusq = statusq;
	}
	public String getUsernameq() {
		return usernameq;
	}
	public void setUsernameq(String usernameq) {
		this.usernameq = usernameq;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getInsRoleSeq() {
		return insRoleSeq;
	}
	public void setInsRoleSeq(String insRoleSeq) {
		this.insRoleSeq = insRoleSeq;
	}
	public String getLastStartTime() {
		return lastStartTime;
	}
	public void setLastStartTime(String lastStartTime) {
		this.lastStartTime = lastStartTime;
	}
	public String getLastEndTime() {
		return lastEndTime;
	}
	public void setLastEndTime(String lastEndTime) {
		this.lastEndTime = lastEndTime;
	}
	
	
	
}
