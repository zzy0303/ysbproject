package com.uns.dao;

import org.springframework.stereotype.Repository;

import com.uns.model.Customer;
import com.uns.model.SysArea;

import java.util.List;

@Repository
public interface SysAreaMapper {

    int insert(SysArea record);

    int insertSelective(SysArea record);

    public SysArea findAreaByYsb(Customer thisCustomer);

    List<SysArea> findAllProvince();

    List<SysArea> provinceAllCity(String level);

    List<SysArea> selectCityByProvince(String level);
}