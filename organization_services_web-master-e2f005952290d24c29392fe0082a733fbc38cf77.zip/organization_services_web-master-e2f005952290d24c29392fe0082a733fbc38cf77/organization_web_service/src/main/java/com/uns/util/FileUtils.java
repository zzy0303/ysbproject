package com.uns.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 文件处理
 * 
 *
 */
public class FileUtils {
	
	private static Log log = LogFactory.getLog(FileUtils.class);
	
	/**
	 * 下载模板文件
	 * @param request
	 * @param response
	 * @param filename
	 * @param insNo
	 */
public static void downFile(HttpServletRequest request,HttpServletResponse response,String filename) {
		
		String filePath =request.getSession().getServletContext().getRealPath("/")+
				"upload"+File.separator+filename ;
		
    	String fileName = "";
    	//从文件完整路径中提取文件名，并进行编码转换，防止不能正确显示中文名
    	try {
        	if(filePath.lastIndexOf("/") > 0) {
        		fileName = new String(filePath.substring(filePath.lastIndexOf("/")+1, filePath.length()).getBytes("GB2312"), "ISO8859_1");
        	}else if(filePath.lastIndexOf("\\") > 0) {
        		fileName = new String(filePath.substring(filePath.lastIndexOf("\\")+1, filePath.length()).getBytes("GB2312"), "ISO8859_1");
        	}
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    	//打开指定文件的流信息
    	InputStream fs = null;
    	try {
    		fs = new FileInputStream(new File(filePath));
    		
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    	//设置响应头和保存文件名 
    	response.setCharacterEncoding("ISO-8859-1");
    	response.setContentType("APPLICATION/OCTET-STREAM"); 
    	response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
    	//写出流信息
    	int b = 0;
    	try {
        	PrintWriter out = response.getWriter();
        	while((b=fs.read())!=-1) {
        		out.write(b);
        	}
        	out.flush();
        	fs.close();
        	out.close();
        	log.debug("文件下载完毕");
    	}catch(Exception e) {
        	e.printStackTrace();
        	log.debug("下载文件失败!");
    	}
		
	}
	/**
	 * 将String转成 输入流，并下载
	 * @param request
	 * @param response
	 * @param insPubkeyStream
	 * @throws Exception
	 */
	public static void downStreamFile(HttpServletRequest request, HttpServletResponse response,
			String insPubkeyStream, String fileName) throws Exception {
		ByteArrayInputStream fs = null;
    	PrintWriter out=null;
    	try {
			//设置头信息
    		response.setCharacterEncoding("ISO-8859-1");
	    	response.setContentType("APPLICATION/OCTET-STREAM"); 
	    	response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
    		
	    	fs = new ByteArrayInputStream(insPubkeyStream.getBytes());
	    	
	    	int b = 0;
        	out = response.getWriter();
        	while((b=fs.read())!=-1) {
        		out.write(b);
        	}
        	log.info("公钥下载成功!");
		} catch (Exception e) {
			e.printStackTrace();
			log.info("下载公钥失败!");
		}finally {
			fs.close();
			out.flush();
        	out.close();
		}
		
	}
	
	
	/**
	 * 将输入流转成 String
	 * @param is
	 * @return
	 */
	public static String readInputStream(InputStream is){
		try {
			ByteArrayOutputStream baos=new ByteArrayOutputStream();
			int length=0;
			byte[] buffer=new byte[1024];
			while((length=is.read(buffer))!=-1){
				baos.write(buffer, 0, length);
			}
			is.close();
			baos.close();
			//或者用这种方法
			//byte[] result=baos.toByteArray();
			//return new String(result);
			return baos.toString();
		} catch (Exception e) {
			e.printStackTrace();
			return "获取失败";
		}
	}
	
}
