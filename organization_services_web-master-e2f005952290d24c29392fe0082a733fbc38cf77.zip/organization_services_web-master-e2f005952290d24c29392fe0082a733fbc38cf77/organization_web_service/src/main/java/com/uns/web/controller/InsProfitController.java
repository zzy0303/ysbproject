package com.uns.web.controller;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.Page;
import com.uns.model.InsOperator;
import com.uns.model.InsSplitBatchSm;
import com.uns.model.InsSplitProfitSm;
import com.uns.service.InsProfitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

/**
 * @Author: KaiFeng
 * @Description: 机构分润管理
 * @Date: 2017/11/24
 * @Modifyed By:
 */
@Controller
@RequestMapping(value = "/insProfit.htm")
public class InsProfitController extends BaseController {

    @Autowired
    private InsProfitService insProfitService;

    /**
     * 查询机构分润批次列表
     *
     * @param insSplitBatchSm
     * @param request
     * @return
     */
    @RequestMapping(params = "method=findProfitBatchList")
    public String findProfitBatchList(HttpServletRequest request, InsSplitBatchSm insSplitBatchSm) {
        try {
            InsOperator insOperator = ((InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER));
            insSplitBatchSm.setInsNo(insOperator.getInsNo());
            List<Map<String,Object>> insSplitBatchSms = insProfitService.findProfitBatchList(insSplitBatchSm);
            request.setAttribute("insSplitBatchSm", insSplitBatchSm);
            request.setAttribute("insSplitBatchSms", insSplitBatchSms);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "insprofit/insProfitBatchList";
    }

    /**
     * 跳转导出机构分润批次页面
     * @param request
     * @param insSplitBatchSm
     * @return
     */
    @RequestMapping(params = "method=preExportProfitBatchList")
    public String preExportProfitBatchList(HttpServletRequest request, InsSplitBatchSm insSplitBatchSm) {
        try {
            InsOperator insOperator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
            insSplitBatchSm.setInsNo(insOperator.getInsNo());
            Page page = insProfitService.preExportProfitBatchList(insSplitBatchSm);
            request.setAttribute("page", page);
            request.setAttribute("insSplitBatchSm", insSplitBatchSm);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "insprofit/insProfitBatchListPage";
    }

    /**
     * 机构分润批次列表导出
     * @param request
     * @param response
     * @param insSplitBatchSm
     */
    @RequestMapping(params = "method=exportProfitBatchList")
    public void exportProfitBatchList(HttpServletRequest request, HttpServletResponse response, InsSplitBatchSm insSplitBatchSm) {
        try {
            InsOperator insOperator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
            insSplitBatchSm.setInsNo(insOperator.getInsNo());
            insProfitService.exportProfitBatchList(insSplitBatchSm, request, response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 查询机构分润详情
     *
     * @param insSplitProfitSm
     * @param request
     * @param model
     * @return
     */
    @RequestMapping(params = "method=findProfitBatchInfoList")
    public String findProfitBatchInfoList(InsSplitProfitSm insSplitProfitSm, HttpServletRequest request, Model model) {
        try {
            InsOperator insOperator = ((InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER));
            insSplitProfitSm.setInsNo(insOperator.getInsNo());
            List<Map<String, Object>> insSplitProfitSms = insProfitService.findProfitBatchInfoList(insSplitProfitSm);
            model.addAttribute("insSplitProfitSm", insSplitProfitSm);
            model.addAttribute("insSplitProfitSms" ,insSplitProfitSms);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "insprofit/insProfitBatchInfo";
    }

    /**
     * 跳转导出机构分润详情页面
     * @param request
     * @param insSplitProfitSm
     * @return
     */
    @RequestMapping(params = "method=preExportProfitInfoList")
    public String preExportProfitInfoList(HttpServletRequest request, InsSplitProfitSm insSplitProfitSm) {
        try {
            InsOperator insOperator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
            insSplitProfitSm.setInsNo(insOperator.getInsNo());
            Page page = insProfitService.preExportProfitInfoList(insSplitProfitSm);
            request.setAttribute("page", page);
            request.setAttribute("insSplitProfitSm", insSplitProfitSm);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "insprofit/insProfitInfoListPage";
    }

    /**
     * 机构分润详情列表导出
     * @param request
     * @param response
     * @param insSplitProfitSm
     */
    @RequestMapping(params = "method=exportProfitInfoList")
    public void exportProfitInfoList(HttpServletRequest request, HttpServletResponse response, InsSplitProfitSm insSplitProfitSm) {
        try {
            InsOperator insOperator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
            insSplitProfitSm.setInsNo(insOperator.getInsNo());
            insProfitService.exportProfitInfoList(insSplitProfitSm, request, response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 机构分润确认
     *
     * @param insSplitBatchSm
     * @return
     */
    @RequestMapping(params = "method=profitAudit")
    public String profitAudit(InsSplitBatchSm insSplitBatchSm, HttpServletRequest request) throws BusinessException {
        try {
            insProfitService.profitAudit(insSplitBatchSm);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.机构分润确认失败);
        }
        return "redirect:" + "/insProfit.htm?method=findProfitBatchList";
    }
}
