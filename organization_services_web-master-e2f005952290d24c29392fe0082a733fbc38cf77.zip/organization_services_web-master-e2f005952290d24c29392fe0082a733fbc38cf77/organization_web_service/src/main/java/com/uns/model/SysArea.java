package com.uns.model;

import java.math.BigDecimal;

public class SysArea {
    private String provincial;

    private String provincialname;

    private String city;

    private String cityname;

    private String ysbCity;

    private String ysbProv;

    private BigDecimal id;

    public String getProvincial() {
        return provincial;
    }

    public void setProvincial(String provincial) {
        this.provincial = provincial == null ? null : provincial.trim();
    }

    public String getProvincialname() {
        return provincialname;
    }

    public void setProvincialname(String provincialname) {
        this.provincialname = provincialname == null ? null : provincialname.trim();
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city == null ? null : city.trim();
    }

    public String getCityname() {
        return cityname;
    }

    public void setCityname(String cityname) {
        this.cityname = cityname == null ? null : cityname.trim();
    }

    public String getYsbCity() {
        return ysbCity;
    }

    public void setYsbCity(String ysbCity) {
        this.ysbCity = ysbCity == null ? null : ysbCity.trim();
    }

    public String getYsbProv() {
        return ysbProv;
    }

    public void setYsbProv(String ysbProv) {
        this.ysbProv = ysbProv == null ? null : ysbProv.trim();
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }
}