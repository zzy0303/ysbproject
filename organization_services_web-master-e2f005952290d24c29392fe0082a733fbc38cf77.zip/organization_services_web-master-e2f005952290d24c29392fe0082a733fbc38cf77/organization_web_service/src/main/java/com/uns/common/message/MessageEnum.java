package com.uns.common.message;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/11/25
 * @Modifyed By:
 */
public enum MessageEnum {

    机构分润确认成功("1001","机构分润确认成功！");

    private String code;
    private String text;

    private MessageEnum(String code, String text) {
        this.code = code;
        this.text = text;
    }

    public String getCode() {
        return code;
    }

    public String getText() {
        return text;
    }

}
