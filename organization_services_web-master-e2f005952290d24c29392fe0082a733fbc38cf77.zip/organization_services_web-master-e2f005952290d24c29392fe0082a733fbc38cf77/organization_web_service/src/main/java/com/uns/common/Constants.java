package com.uns.common;

public class Constants {

	//验证码
	public static final String SESSION_VERIFY_CODE="sessionVerifycode";
	//成功信息
	public static final String MESSAGE_KEY="message";
	public static final String MSG_KEY = "msg";
	//错误消息
	public static final String ERROR_MESSAGE = "errMsg";
	//操作员个人信息Session
	public static final String SESSION_KEY_USER="sessionUser";
	//时间格式
	public static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd";

	public static final String STATUS_0 = "0";
	public static final String STATUS_1 = "1";
	public static final String STATUS_2 = "2";
	public static final String STATUS_3 = "3";
	public static final String STATUS_4 = "4";
	public static final String STATUS_7 = "7";
	//查询 页面条数
	public static final int FIND_PAGE_LIST = 20;

	//错误
	public static final String SMALL_MERCH_NO_NOT_EXIST = "商户号不存在";

	/**
	 * 交易流水导出excel,每页50000行
	 */
	public static  int EXCEL_SIZE=50000;
	public static final String CON_YES = "1";
	public static final String CON_NO = "0";


	// 日志类型（1：接入日志；2：错误日志）
	public static final String TYPE_ACCESS = "1";
	public static final String TYPE_EXCEPTION = "2";

	//处理星号隐藏的字段类型
	public static final String ASTERISK_CERTID = "1";//身份证号
	public static final String ASTERISK_BANKCARDNO = "2";//银行卡号
	public static final String ASTERISK_NAME = "3";//姓名
	public static final String ASTERISK_PHONE = "4";//手机号

	public static final String YSB_PUB_KEY = "ysbpubkey";

	/**
	 * 商户鉴权返回码
	 */
	public static final String STATUS_1111 = "1111";
	public static final String STATUS_2033 = "2033";
	public static final String STATUS_1005 = "1005";
	public static final String STATUS_0000 = "0000";
	public static final String STATUS_6012 = "6012";
	public static final String STATUS_20 = "20";
	public static final String STATUS_00 = "00";

	public static final String REGISTER_CUSTOMER_USERTYPE_P="P";
	public static final String REGISTER_CUSTOMER_USERTYPE_C="C";

	public static final String CON_MCC = "1";
	public static short SHORT_0 = 0;
	public static short SHORT_1 = 1;
	public static short SHORT_2 = 2;
	public static Short BIG_SHORT_1 = 1;
}