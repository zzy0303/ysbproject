package com.uns.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class SysAreaExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public SysAreaExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andProvincialIsNull() {
            addCriterion("PROVINCIAL is null");
            return (Criteria) this;
        }

        public Criteria andProvincialIsNotNull() {
            addCriterion("PROVINCIAL is not null");
            return (Criteria) this;
        }

        public Criteria andProvincialEqualTo(String value) {
            addCriterion("PROVINCIAL =", value, "provincial");
            return (Criteria) this;
        }

        public Criteria andProvincialNotEqualTo(String value) {
            addCriterion("PROVINCIAL <>", value, "provincial");
            return (Criteria) this;
        }

        public Criteria andProvincialGreaterThan(String value) {
            addCriterion("PROVINCIAL >", value, "provincial");
            return (Criteria) this;
        }

        public Criteria andProvincialGreaterThanOrEqualTo(String value) {
            addCriterion("PROVINCIAL >=", value, "provincial");
            return (Criteria) this;
        }

        public Criteria andProvincialLessThan(String value) {
            addCriterion("PROVINCIAL <", value, "provincial");
            return (Criteria) this;
        }

        public Criteria andProvincialLessThanOrEqualTo(String value) {
            addCriterion("PROVINCIAL <=", value, "provincial");
            return (Criteria) this;
        }

        public Criteria andProvincialLike(String value) {
            addCriterion("PROVINCIAL like", value, "provincial");
            return (Criteria) this;
        }

        public Criteria andProvincialNotLike(String value) {
            addCriterion("PROVINCIAL not like", value, "provincial");
            return (Criteria) this;
        }

        public Criteria andProvincialIn(List<String> values) {
            addCriterion("PROVINCIAL in", values, "provincial");
            return (Criteria) this;
        }

        public Criteria andProvincialNotIn(List<String> values) {
            addCriterion("PROVINCIAL not in", values, "provincial");
            return (Criteria) this;
        }

        public Criteria andProvincialBetween(String value1, String value2) {
            addCriterion("PROVINCIAL between", value1, value2, "provincial");
            return (Criteria) this;
        }

        public Criteria andProvincialNotBetween(String value1, String value2) {
            addCriterion("PROVINCIAL not between", value1, value2, "provincial");
            return (Criteria) this;
        }

        public Criteria andProvincialnameIsNull() {
            addCriterion("PROVINCIALNAME is null");
            return (Criteria) this;
        }

        public Criteria andProvincialnameIsNotNull() {
            addCriterion("PROVINCIALNAME is not null");
            return (Criteria) this;
        }

        public Criteria andProvincialnameEqualTo(String value) {
            addCriterion("PROVINCIALNAME =", value, "provincialname");
            return (Criteria) this;
        }

        public Criteria andProvincialnameNotEqualTo(String value) {
            addCriterion("PROVINCIALNAME <>", value, "provincialname");
            return (Criteria) this;
        }

        public Criteria andProvincialnameGreaterThan(String value) {
            addCriterion("PROVINCIALNAME >", value, "provincialname");
            return (Criteria) this;
        }

        public Criteria andProvincialnameGreaterThanOrEqualTo(String value) {
            addCriterion("PROVINCIALNAME >=", value, "provincialname");
            return (Criteria) this;
        }

        public Criteria andProvincialnameLessThan(String value) {
            addCriterion("PROVINCIALNAME <", value, "provincialname");
            return (Criteria) this;
        }

        public Criteria andProvincialnameLessThanOrEqualTo(String value) {
            addCriterion("PROVINCIALNAME <=", value, "provincialname");
            return (Criteria) this;
        }

        public Criteria andProvincialnameLike(String value) {
            addCriterion("PROVINCIALNAME like", value, "provincialname");
            return (Criteria) this;
        }

        public Criteria andProvincialnameNotLike(String value) {
            addCriterion("PROVINCIALNAME not like", value, "provincialname");
            return (Criteria) this;
        }

        public Criteria andProvincialnameIn(List<String> values) {
            addCriterion("PROVINCIALNAME in", values, "provincialname");
            return (Criteria) this;
        }

        public Criteria andProvincialnameNotIn(List<String> values) {
            addCriterion("PROVINCIALNAME not in", values, "provincialname");
            return (Criteria) this;
        }

        public Criteria andProvincialnameBetween(String value1, String value2) {
            addCriterion("PROVINCIALNAME between", value1, value2, "provincialname");
            return (Criteria) this;
        }

        public Criteria andProvincialnameNotBetween(String value1, String value2) {
            addCriterion("PROVINCIALNAME not between", value1, value2, "provincialname");
            return (Criteria) this;
        }

        public Criteria andCityIsNull() {
            addCriterion("CITY is null");
            return (Criteria) this;
        }

        public Criteria andCityIsNotNull() {
            addCriterion("CITY is not null");
            return (Criteria) this;
        }

        public Criteria andCityEqualTo(String value) {
            addCriterion("CITY =", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityNotEqualTo(String value) {
            addCriterion("CITY <>", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityGreaterThan(String value) {
            addCriterion("CITY >", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityGreaterThanOrEqualTo(String value) {
            addCriterion("CITY >=", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityLessThan(String value) {
            addCriterion("CITY <", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityLessThanOrEqualTo(String value) {
            addCriterion("CITY <=", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityLike(String value) {
            addCriterion("CITY like", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityNotLike(String value) {
            addCriterion("CITY not like", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityIn(List<String> values) {
            addCriterion("CITY in", values, "city");
            return (Criteria) this;
        }

        public Criteria andCityNotIn(List<String> values) {
            addCriterion("CITY not in", values, "city");
            return (Criteria) this;
        }

        public Criteria andCityBetween(String value1, String value2) {
            addCriterion("CITY between", value1, value2, "city");
            return (Criteria) this;
        }

        public Criteria andCityNotBetween(String value1, String value2) {
            addCriterion("CITY not between", value1, value2, "city");
            return (Criteria) this;
        }

        public Criteria andCitynameIsNull() {
            addCriterion("CITYNAME is null");
            return (Criteria) this;
        }

        public Criteria andCitynameIsNotNull() {
            addCriterion("CITYNAME is not null");
            return (Criteria) this;
        }

        public Criteria andCitynameEqualTo(String value) {
            addCriterion("CITYNAME =", value, "cityname");
            return (Criteria) this;
        }

        public Criteria andCitynameNotEqualTo(String value) {
            addCriterion("CITYNAME <>", value, "cityname");
            return (Criteria) this;
        }

        public Criteria andCitynameGreaterThan(String value) {
            addCriterion("CITYNAME >", value, "cityname");
            return (Criteria) this;
        }

        public Criteria andCitynameGreaterThanOrEqualTo(String value) {
            addCriterion("CITYNAME >=", value, "cityname");
            return (Criteria) this;
        }

        public Criteria andCitynameLessThan(String value) {
            addCriterion("CITYNAME <", value, "cityname");
            return (Criteria) this;
        }

        public Criteria andCitynameLessThanOrEqualTo(String value) {
            addCriterion("CITYNAME <=", value, "cityname");
            return (Criteria) this;
        }

        public Criteria andCitynameLike(String value) {
            addCriterion("CITYNAME like", value, "cityname");
            return (Criteria) this;
        }

        public Criteria andCitynameNotLike(String value) {
            addCriterion("CITYNAME not like", value, "cityname");
            return (Criteria) this;
        }

        public Criteria andCitynameIn(List<String> values) {
            addCriterion("CITYNAME in", values, "cityname");
            return (Criteria) this;
        }

        public Criteria andCitynameNotIn(List<String> values) {
            addCriterion("CITYNAME not in", values, "cityname");
            return (Criteria) this;
        }

        public Criteria andCitynameBetween(String value1, String value2) {
            addCriterion("CITYNAME between", value1, value2, "cityname");
            return (Criteria) this;
        }

        public Criteria andCitynameNotBetween(String value1, String value2) {
            addCriterion("CITYNAME not between", value1, value2, "cityname");
            return (Criteria) this;
        }

        public Criteria andYsbCityIsNull() {
            addCriterion("YSB_CITY is null");
            return (Criteria) this;
        }

        public Criteria andYsbCityIsNotNull() {
            addCriterion("YSB_CITY is not null");
            return (Criteria) this;
        }

        public Criteria andYsbCityEqualTo(String value) {
            addCriterion("YSB_CITY =", value, "ysbCity");
            return (Criteria) this;
        }

        public Criteria andYsbCityNotEqualTo(String value) {
            addCriterion("YSB_CITY <>", value, "ysbCity");
            return (Criteria) this;
        }

        public Criteria andYsbCityGreaterThan(String value) {
            addCriterion("YSB_CITY >", value, "ysbCity");
            return (Criteria) this;
        }

        public Criteria andYsbCityGreaterThanOrEqualTo(String value) {
            addCriterion("YSB_CITY >=", value, "ysbCity");
            return (Criteria) this;
        }

        public Criteria andYsbCityLessThan(String value) {
            addCriterion("YSB_CITY <", value, "ysbCity");
            return (Criteria) this;
        }

        public Criteria andYsbCityLessThanOrEqualTo(String value) {
            addCriterion("YSB_CITY <=", value, "ysbCity");
            return (Criteria) this;
        }

        public Criteria andYsbCityLike(String value) {
            addCriterion("YSB_CITY like", value, "ysbCity");
            return (Criteria) this;
        }

        public Criteria andYsbCityNotLike(String value) {
            addCriterion("YSB_CITY not like", value, "ysbCity");
            return (Criteria) this;
        }

        public Criteria andYsbCityIn(List<String> values) {
            addCriterion("YSB_CITY in", values, "ysbCity");
            return (Criteria) this;
        }

        public Criteria andYsbCityNotIn(List<String> values) {
            addCriterion("YSB_CITY not in", values, "ysbCity");
            return (Criteria) this;
        }

        public Criteria andYsbCityBetween(String value1, String value2) {
            addCriterion("YSB_CITY between", value1, value2, "ysbCity");
            return (Criteria) this;
        }

        public Criteria andYsbCityNotBetween(String value1, String value2) {
            addCriterion("YSB_CITY not between", value1, value2, "ysbCity");
            return (Criteria) this;
        }

        public Criteria andYsbProvIsNull() {
            addCriterion("YSB_PROV is null");
            return (Criteria) this;
        }

        public Criteria andYsbProvIsNotNull() {
            addCriterion("YSB_PROV is not null");
            return (Criteria) this;
        }

        public Criteria andYsbProvEqualTo(String value) {
            addCriterion("YSB_PROV =", value, "ysbProv");
            return (Criteria) this;
        }

        public Criteria andYsbProvNotEqualTo(String value) {
            addCriterion("YSB_PROV <>", value, "ysbProv");
            return (Criteria) this;
        }

        public Criteria andYsbProvGreaterThan(String value) {
            addCriterion("YSB_PROV >", value, "ysbProv");
            return (Criteria) this;
        }

        public Criteria andYsbProvGreaterThanOrEqualTo(String value) {
            addCriterion("YSB_PROV >=", value, "ysbProv");
            return (Criteria) this;
        }

        public Criteria andYsbProvLessThan(String value) {
            addCriterion("YSB_PROV <", value, "ysbProv");
            return (Criteria) this;
        }

        public Criteria andYsbProvLessThanOrEqualTo(String value) {
            addCriterion("YSB_PROV <=", value, "ysbProv");
            return (Criteria) this;
        }

        public Criteria andYsbProvLike(String value) {
            addCriterion("YSB_PROV like", value, "ysbProv");
            return (Criteria) this;
        }

        public Criteria andYsbProvNotLike(String value) {
            addCriterion("YSB_PROV not like", value, "ysbProv");
            return (Criteria) this;
        }

        public Criteria andYsbProvIn(List<String> values) {
            addCriterion("YSB_PROV in", values, "ysbProv");
            return (Criteria) this;
        }

        public Criteria andYsbProvNotIn(List<String> values) {
            addCriterion("YSB_PROV not in", values, "ysbProv");
            return (Criteria) this;
        }

        public Criteria andYsbProvBetween(String value1, String value2) {
            addCriterion("YSB_PROV between", value1, value2, "ysbProv");
            return (Criteria) this;
        }

        public Criteria andYsbProvNotBetween(String value1, String value2) {
            addCriterion("YSB_PROV not between", value1, value2, "ysbProv");
            return (Criteria) this;
        }

        public Criteria andIdIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(BigDecimal value) {
            addCriterion("ID =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(BigDecimal value) {
            addCriterion("ID <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(BigDecimal value) {
            addCriterion("ID >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("ID >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(BigDecimal value) {
            addCriterion("ID <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(BigDecimal value) {
            addCriterion("ID <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<BigDecimal> values) {
            addCriterion("ID in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<BigDecimal> values) {
            addCriterion("ID not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ID between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ID not between", value1, value2, "id");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}