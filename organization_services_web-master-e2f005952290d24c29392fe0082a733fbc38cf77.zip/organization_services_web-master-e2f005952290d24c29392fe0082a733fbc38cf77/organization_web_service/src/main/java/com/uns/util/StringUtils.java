/**
 * Copyright (c) 2006-2009 by Shanghai UnuTrip Network Technology Development Co.,Ltd
 * All rights reserved.
 */

package com.uns.util;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringEscapeUtils;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;


/**
 * 
 * @author danson 2009-11-19
 */
public abstract class StringUtils extends org.apache.commons.lang3.StringUtils {

	/**
	 * 将 TEXT 文本转换为 HTML 代码, 已便于网页正确的显示出来.
	 * 
	 * @param input
	 *            输入的文本字符串
	 * @return 转换后的 HTML 代码
	 */
	public static String textToHtml(String input) {
		if (isEmpty(input)) {
			return "";
		}

		input = replace(input, "<", "&#60;");
		input = replace(input, ">", "&#62;");

		input = replace(input, "\n", "<br>\n");
		input = replace(input, "\t", "&nbsp;&nbsp;&nbsp;&nbsp;");
		input = replace(input, "  ", "&nbsp;&nbsp;");

		return input;
	}

	// ------------------------------------ 字符串处理方法
	// ----------------------------------------------

	/**
	 * 将字符串 source 中的 oldStr 替换为 newStr, 并以大小写敏感方式进行查找
	 * 
	 * @param source
	 *            需要替换的源字符串
	 * @param oldStr
	 *            需要被替换的老字符串
	 * @param newStr
	 *            替换为的新字符串
	 */
	public static String replace(String source, String oldStr, String newStr) {
		return replace(source, oldStr, newStr, true);
	}

	/**
	 * 将字符串 source 中的 oldStr 替换为 newStr, matchCase 为是否设置大小写敏感查找
	 * 
	 * @param source
	 *            需要替换的源字符串
	 * @param oldStr
	 *            需要被替换的老字符串
	 * @param newStr
	 *            替换为的新字符串
	 * @param matchCase
	 *            是否需要按照大小写敏感方式查找
	 */
	public static String replace(String source, String oldStr, String newStr,
			boolean matchCase) {
		if (source == null) {
			return null;
		}
		// 首先检查旧字符串是否存在, 不存在就不进行替换
		if (source.toLowerCase().indexOf(oldStr.toLowerCase()) == -1) {
			return source;
		}
		int findStartPos = 0;
		int a = 0;
		while (a > -1) {
			int b = 0;
			String str1, str2, str3, str4, strA, strB;
			str1 = source;
			str2 = str1.toLowerCase();
			str3 = oldStr;
			str4 = str3.toLowerCase();
			if (matchCase) {
				strA = str1;
				strB = str3;
			} else {
				strA = str2;
				strB = str4;
			}
			a = strA.indexOf(strB, findStartPos);
			if (a > -1) {
				b = oldStr.length();
				findStartPos = a + b;
				StringBuffer bbuf = new StringBuffer(source);
				source = bbuf.replace(a, a + b, newStr) + "";
				// 新的查找开始点位于替换后的字符串的结尾
				findStartPos = findStartPos + newStr.length() - b;
			}
		}
		return source;
	}

	/**
	 * 
	 * @param arg
	 * @return
	 */
	public static boolean isTrimNotEmpty(String arg) {
		if (arg != null && !arg.trim().isEmpty()) {
			return true;
		} else {
			return false;
		}
	}

	public static String add(String arg1, String arg2) {
		String result = null;
		if (arg1 != null || arg2 != null) {
			if (arg1 == null) {
				result = arg2;
			} else if (arg2 == null) {
				result = arg1;
			} else {
				result = arg1 + arg2;
			}
		}
		return result;
	}

	/**
	 * 截取从one到two中间的字符
	 * 
	 * @param source
	 * @param one
	 * @param two
	 * @return
	 */
	public static String subStringBychar(String source, String one, String two) {
		int ione = source.lastIndexOf(one);
		int itwo = source.lastIndexOf(two);
		String result = source.substring(ione + 1, itwo);
		return result;
	}

	/**
	 * 判断字符是否为空
	 * 
	 * @param s
	 * @return boolean
	 */
	public static boolean isEmpty(String s) {
		return s == null || "".equals(s);
	}
	
	/**
	 * 数据组装字符串
	 * @param object
	 * @return
	 */
	public static String arrayToString(Object[] object) {
		 String str = "";
		 if(object != null && object.length > 0) {
	    	for(int i=0; i<object.length; i++) {
	    		if(i == object.length-1) {
	    			str+= object[i];
	    		} else {
	    			str+= object[i]+",";
	    		}
		    }
		 }
		 return str;
	}
	
	/**
	 * 正则匹配是否是手机号码格式
	 * @param mobile
	 * @return
	 */
	public static boolean isMobile(String mobile) {
		boolean flag = Pattern.compile("^[0-9]{11}$").matcher(mobile).matches();
		return flag;
	}
	
	public static String[] list4strings(List<String> lists) throws Exception{
		String[] strs = {};
		for(int i=0;i<lists.size();i++){
			strs[i]=lists.get(i);
		}
		return strs;
	}
	/**
	 * 获取24小时制的当前时间
	 * @return
	 */
	public static String getToday(){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		return sdf.format(new Date());
	}
	
	/**
	 * 获取24小时制的当前时间
	 * 格式：yyyy/MM/dd HH:mm:ss
	 * @return
	 * @throws ParseException
	 */
	public static Date getToday1() throws ParseException{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		String date = sdf.format(new Date());
		return sdf.parse(date);
	}
	
	public String dateFormat(String date){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		Date d =null;
		try {
			d = sdf.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return sdf.format(d);
	}
	
   /**
 * @param str
 * @return
 */
	public static boolean isNumeric(String str){ 
	   Pattern pattern = Pattern.compile("^[0-9]+(.[0-9]{1,2})?$"); 
	   Matcher isNum = pattern.matcher(str);
	   if( !isNum.matches() ){
	       return false; 
	   } 
	   return true; 
	}
	/**
	 * 获得用户远程地址
	 */
	public static String getRemoteAddr(HttpServletRequest request){
		String remoteAddr = request.getHeader("X-Real-IP");
        if (org.apache.commons.lang3.StringUtils.isNotBlank(remoteAddr)) {
        	remoteAddr = request.getHeader("X-Forwarded-For");
        }else if (org.apache.commons.lang3.StringUtils.isNotBlank(remoteAddr)) {
        	remoteAddr = request.getHeader("Proxy-Client-IP");
        }else if (org.apache.commons.lang3.StringUtils.isNotBlank(remoteAddr)) {
        	remoteAddr = request.getHeader("WL-Proxy-Client-IP");
        }
        return remoteAddr != null ? remoteAddr : request.getRemoteAddr();
	}
	
	/**
	 * 缩略字符串（不区分中英文字符）
	 * @param str 目标字符串
	 * @param length 截取长度
	 * @return
	 */
	public static String abbr(String str, int length) {
		if (str == null) {
			return "";
		}
		try {
			StringBuilder sb = new StringBuilder();
			int currentLength = 0;
			for (char c : replaceHtml(StringEscapeUtils.unescapeHtml4(str)).toCharArray()) {
				currentLength += String.valueOf(c).getBytes("UTF-8").length;
				if (currentLength <= length - 3) {
					sb.append(c);
				} else {
					sb.append("...");
					break;
				}
			}
			return sb.toString();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return "";
	}
	/**
	 * 替换掉HTML标签方法
	 */
	public static String replaceHtml(String html) {
		if (org.apache.commons.lang3.StringUtils.isBlank(html)){
			return "";
		}
		String regEx = "<.+?>";
		Pattern p = Pattern.compile(regEx);
		Matcher m = p.matcher(html);
		String s = m.replaceAll("");
		return s;
	}
	
	/**
	 * 处理字符串加星号
	 * @throws BusinessException 
	 */
	public static String asteriskStr(String str, String type) throws BusinessException{
		try {
			switch(type){
			case Constants.ASTERISK_CERTID:{
				return str.substring(0, 6) + "****" + str.substring(str.length()-8, str.length());
			}
			case Constants.ASTERISK_BANKCARDNO:{
				return str.substring(0, 6) + "****" + str.substring(str.length()-4, str.length());
			}
			case Constants.ASTERISK_NAME:{
				return "*"+str.substring(1);
			}
			case Constants.ASTERISK_PHONE:{
				return str.substring(0, 3) + "****" + str.substring(str.length()-4, str.length());
			}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.星号隐藏处理出错);
		}
		return null;
	}
	
	 /**
     * 将yyyyMMddHHmmss 转换成 yyyy-MM-dd HH:mm:ss
     * @param str
     * @return
     */
    public static String parseDateString(String str){
		String reg = "(\\d{4})(\\d{2})(\\d{2})(\\d{2})(\\d{2})(\\d{2})";
		str = str.replaceAll(reg, "$1-$2-$3 $4:$5:$6");
		return str;
    }
}
