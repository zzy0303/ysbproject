package com.uns.web.form;

import java.util.Date;

public class CustomerForm {
	
	//商户id
	private Long thisCustomerId;
	//当前登录的机构号
	private String thisInsNo;
	//查询商户列表
    private String smallMerchNo;
    private String checkstatus;
   
	private String name;
    private String linkman;
    private String createDateStart;
    private String createDateEnd;
    private String phone;
    
    
    
    
    
    public String getCreateDateStart() {
		return createDateStart;
	}
	public void setCreateDateStart(String createDateStart) {
		this.createDateStart = createDateStart;
	}
	public String getCreateDateEnd() {
		return createDateEnd;
	}
	public void setCreateDateEnd(String createDateEnd) {
		this.createDateEnd = createDateEnd;
	}
	//getter and setter
    public String getThisInsNo() {
		return thisInsNo;
	}
	public void setThisInsNo(String thisInsNo) {
		this.thisInsNo = thisInsNo;
	}
	public String getSmallMerchNo() {
		return smallMerchNo;
	}
	public void setSmallMerchNo(String smallMerchNo) {
		this.smallMerchNo = smallMerchNo==null?"":smallMerchNo.trim();
	}
	public String getCheckstatus() {
		return checkstatus;
	}
	public void setCheckstatus(String checkstatus) {
		this.checkstatus = checkstatus;
	}
	public Long getThisCustomerId() {
		return thisCustomerId;
	}
	public void setThisCustomerId(Long thisCustomerId) {
		this.thisCustomerId = thisCustomerId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name==null?"":name.trim();
	}
	public String getLinkman() {
		return linkman;
	}
	public void setLinkman(String linkman) {
		this.linkman = linkman==null?"":linkman.trim();
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone==null?"":phone.trim();
	}
}
