package com.uns.model;

import java.math.BigDecimal;

/**
 * 抽成提现
 * @author yang.cheng
 *
 */
public class RakeWithdraw {
	
	private String batchNo;//批次号
	
	private String tranTime;//批次生成时间
	
	private String insNo;//机构编号
	
	private String insName;//机构名称
	
	private String tranFlag;//批次状态
	
	private BigDecimal amount;//抽成金额
	
	private String tranTimeStart;
	private String tranTimeEnd;
	
	
	public String getTranTimeStart() {
		return tranTimeStart;
	}

	public void setTranTimeStart(String tranTimeStart) {
		this.tranTimeStart = tranTimeStart;
	}

	public String getTranTimeEnd() {
		return tranTimeEnd;
	}

	public void setTranTimeEnd(String tranTimeEnd) {
		this.tranTimeEnd = tranTimeEnd;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo==null?null:batchNo.trim();
	}
	
	public void setTranTime(String tranTime) {
		this.tranTime = tranTime;
	}
	
	public void setInsNo(String insNo) {
		this.insNo = insNo;
	}
	
	public void setInsName(String insName) {
		this.insName = insName;
	}
	
	public void setTranFlag(String tranFlag) {
		this.tranFlag = tranFlag;
	}
	
	public String getBatchNo() {
		return batchNo;
	}
	public String getTranTime() {
		return tranTime;
	}
	
	public String getInsNo() {
		return insNo;
	}
	public String getInsName() {
		return insName;
	}
	public String getTranFlag() {
		return tranFlag;
	}
}
