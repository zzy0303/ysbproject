package com.uns.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Map;


import com.alibaba.fastjson.JSON;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JSONUtil {
	
    private static ObjectMapper mapper = new ObjectMapper();
    
    public static String toJSONString(Object o) throws JsonProcessingException {
    	/*return JSONObject.toJSONString(o);*/
    	return mapper.writeValueAsString(o);
    }
//    
//    public static void writeToStream(OutputStream out,Object value) throws JsonGenerationException, JsonMappingException, IOException {
//    	SerializeWriter sw = new SerializeWriter();
//        try {
//            new JSONSerializer(sw).write(value);
//            sw.writeTo(out, "UTF-8");
//        } catch (IOException e) {
//            throw new JSONException(e.getMessage(), e);
//        } finally {
//            out.close();
//        }
//    	
////    	mapper.writeValue(out, value);
//    }
    
    public static <T> T readValue(String url, Class<T> clz) {
    	try {
			URL u = new URL(url);
			return mapper.readValue(u, clz);
			
		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
    	return null;
    }
    
    public static <T> T readValue(String url,String params, Class<T> clz) {
    	try {
			String param = "?params="+params;
			URL u = new URL(url+ param);
			return mapper.readValue(u, clz);
			
		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
    	return null;
    }
    
	public static JavaType getCollectionType(Class<?> collectionClass, Class<?>... elementClasses) {   
		return mapper.getTypeFactory().constructParametricType(collectionClass, elementClasses);   
	}

	public static void writeTo(PrintWriter writer, Object value) {
		try {
			mapper.writeValue(writer, value);
		} catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	
	public static String getCurrentCity(String ip) {
		URL url;
		String location = "";
		try {
			url = new URL("http://opendata.baidu.com/api.php?resource_id=6006&query=" + ip);
			URLConnection conn = url.openConnection();
			InputStream in = conn.getInputStream();
			
			BufferedReader br = new BufferedReader(new InputStreamReader(in,"GBK"));
			
			String str = br.readLine();
			
			Map map = mapper.readValue(str , Map.class);
			if(map !=null){
				ArrayList datas = (ArrayList) map.get("data");
				if(datas != null&&datas.size()>0){
					Map m = (Map) datas.get(0);
					location = (String) m.get("location");
					int pos = location.indexOf(" ");
					if(pos != -1){
						location = location.substring(0, pos);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return location;
	}
	
	public static <T> T readParams(String params, Class<T> clz) {
		try {
			return mapper.readValue(params, clz);
		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * @param jsonStr
	 * @return
	 * json 字符串转换成 Map
	 */
	public static Map jsonStrToMap(String jsonStr){
		Map map = (Map)JSON.parse(jsonStr);
		return map;
	}
	
	
	public static void main(String[] args) {
		
//		Map<String,String> map = new HashMap<String,String>();
//		
//		
//		//"{\"EventID\": \"8\", \"cur_point\":\"100\", \"multiple_point\":\"2\", \"score\": \"200\", \"cur_score\":\"300\", \"multiple_score\":\"3\", \"start_date\":\"2012\"}"
//		
//		map.put("EventID", "8");
//		map.put("cur_point", "100");
//		map.put("multiple_point", "2");
//		map.put("score", "200");
//		map.put("cur_score", "300");
//		map.put("multiple_score", "3");
//		map.put("start_date", "2012");
//		
//		Map result = JSONUtil.readRule(map);
//		System.out.println(result.size() + "," + result.toString());
//		Map map = new HashMap();
//		map.put("ke1", "value1");
//		map.put("key2", "value2");
//		map.put("key3", "value3");
//		
//		try {
//			String jsonStr = JSONUtil.toJSONString(map);
//			
//			Map mp = JSONUtil.jsonStrToMap(jsonStr);
//			System.out.println(mp.get("key2"));
//			System.out.println(jsonStr);
//		} catch (JsonProcessingException e) {
//			e.printStackTrace();
//		}
//		System.out.println(JSONUtil.getCurrentCity("156.25.33.88"));
		
	}

	public static <T> T readValue(InputStream content, Class<T> type) throws Exception {
		return mapper.readValue(content, type);
	}
	
	/**
	 * 将一个对象转换成目标对象
	 * @param src
	 * @param dest
	 * @return
	 */
	public static <T> T copyProperties(Object src,Class<T> dest) throws Exception {
		return mapper.readValue(mapper.writeValueAsString(src), dest);
	}
	
	public static <T> T copyProperties(Object src,JavaType type) throws Exception {
		return mapper.readValue(mapper.writeValueAsString(src), type);
	}

	public static <T> T readValue(String url, JavaType type) {
		try {
			return mapper.readValue(new URL(url), type);
		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	
}
