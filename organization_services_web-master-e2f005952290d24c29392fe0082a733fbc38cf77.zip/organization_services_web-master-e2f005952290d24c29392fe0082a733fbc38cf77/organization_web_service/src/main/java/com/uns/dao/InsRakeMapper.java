package com.uns.dao;

import java.util.List;
import org.springframework.stereotype.Repository;

import com.uns.model.InsRake;
import com.uns.model.RakeWithdraw;
@Repository
public interface InsRakeMapper {
	List findInsRakeList(InsRake insRake);

	List findRakeWithdrawList(RakeWithdraw rakeWithdraw);
}