package com.uns.web.controller;

import java.lang.reflect.InvocationTargetException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.model.InsOperator;
import com.uns.service.InsTransService;
import com.uns.util.ExcelUtils;
import com.uns.util.StringUtils;
import com.uns.web.form.WithdrawForm;

/**
 * 提现管理
 * @author peng.du
 *
 */
@Controller
@RequestMapping(value = "/insWithdraw.htm")
public class InsWithdrawController extends BaseController {
	
	@Autowired
	InsTransService insTransService;
	/**
	 * 查询提现列表
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params="method=findWithdrawList")
	public String findWithdrawList(HttpServletRequest request, HttpServletResponse response, WithdrawForm withdrawForm) throws BusinessException{
		try {
			//设置当前机构号
			InsOperator operator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			withdrawForm.setInsNo(operator.getInsNo());
			//查询提现列表
			List withdrawList = insTransService.findWithdrawList(withdrawForm);
			request.setAttribute("withdrawList", withdrawList);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.提现列表查询出错);
		}
		return "withdraw/d0withdrawList";
	}
	
	/**
	 * 跳转到导出excel界面
	 * @return
	 * @throws InvocationTargetException 
	 * @throws IllegalAccessException 
	 * @throws BusinessException 
	 */
	@RequestMapping(params="method=exportWithdrawList")
	public String exportWithdrawList(HttpServletRequest request, HttpServletResponse response, WithdrawForm withdrawForm) throws IllegalAccessException, InvocationTargetException, BusinessException{
		try {
			InsOperator operator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			withdrawForm.setInsNo(operator.getInsNo());
			Page page  = new Page();
			page.setPageSize(Constants.EXCEL_SIZE);
			PageContext context = PageContext.getContext();
			BeanUtils.copyProperties(context, page);
			context.setPagination(true);
			//设置insNo
			insTransService.findWithdrawForExcelList(withdrawForm);
			BeanUtils.copyProperties(page, context);
			request.setAttribute("page",page);
			request.setAttribute("withdrawForm", withdrawForm);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.提现导出页面出错);
		}
		return "withdraw/d0withdrawExportPage";
	}
	
	/**
	 * 交易数据导出下载
	 * @param request
	 * @param response
	 * @param modelMap
	 * @param tQrCodeTransForm
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params="method=downExportWithdrawList")
	public String downExportWithdrawList(HttpServletRequest request, HttpServletResponse response,  ModelMap modelMap,  WithdrawForm withdrawForm) throws BusinessException{
		try{
			String tPage = request.getParameter("page");
			if (StringUtils.isEmpty(tPage) || !org.apache.commons.lang3.StringUtils.isNumeric(tPage)){
				tPage = "1";
			}
			int currentPage = Integer.valueOf(tPage);
			Page page  = new Page();
			page.setPageSize(Constants.EXCEL_SIZE);
			PageContext context = PageContext.getContext();
			BeanUtils.copyProperties(context, page);
			context.setPagination(true);
			context.setCurrentPage(currentPage);
			//设置insNo
			InsOperator operator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			withdrawForm.setInsNo(operator.getInsNo());
			List excelList = insTransService.findWithdrawForExcelList(withdrawForm);
			//标题
			Map<String, String> mapField = new LinkedHashMap();
			mapField.put("SMALL_MERCH_NO","商户编号");              
			mapField.put("CUSTOMERNAME","商户名称");          
			mapField.put("ORDER_ID","订单编号");              
			mapField.put("QORDERID","提现编号");             
			mapField.put("QAMOUNT","交易金额");                
			mapField.put("TRAN_DATE","交易时间");          
			mapField.put("QTRANTIME","提现时间");          
			mapField.put("QTRANFLAG","提现状态");        
			mapField.put("CPD0COMMISSIONRATE","商户费率(%)");        
			mapField.put("INSCOMMISSION","抽成比例(%)");        
			mapField.put("MINUSAMOUNT","扣除金额");        
			mapField.put("ARRIVAL_AMOUNT","实际到账");        

			String fileNames="withdrawRecords";
			String sheetNames="withdrawRecords";
			ExcelUtils.downExcel(excelList, response, mapField, fileNames, sheetNames);
		} catch (Exception e) {
			log.info("导出数据有误！");
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.提现导出出错);
		}
		return null;
	}
}
