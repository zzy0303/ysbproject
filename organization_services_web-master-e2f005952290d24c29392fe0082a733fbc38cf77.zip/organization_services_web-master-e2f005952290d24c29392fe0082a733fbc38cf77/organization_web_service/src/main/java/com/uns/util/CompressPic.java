package com.uns.util;

import net.coobird.thumbnailator.Thumbnails;
import org.apache.commons.fileupload.disk.DiskFileItem;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;


import java.io.*;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/2/28
 * @Modifyed By:
 */
public class CompressPic {

    public static File compressPic (MultipartFile multipartFile) throws IOException {
        CommonsMultipartFile cf = (CommonsMultipartFile) multipartFile;
        DiskFileItem fi = (DiskFileItem) cf.getFileItem();
        String storeLocation = fi.getStoreLocation().toString();
        File file = null;
        Thumbnails.of(multipartFile.getInputStream()).scale(0.5f).outputQuality(0.5f).outputFormat("jpg").toFile(storeLocation);
        file = new File(storeLocation + ".jpg");
        return file;
    }
}
