package com.uns.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.TQrCodeTrans;
import com.uns.web.form.TQrCodeTransForm;
import com.uns.web.form.WithdrawForm;
@Repository
public interface TQrCodeTransMapper {

    int deleteByPrimaryKey(Long id);

    int insert(TQrCodeTrans record);

    int insertSelective(TQrCodeTrans record);

    TQrCodeTrans selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TQrCodeTrans record);

    int updateByPrimaryKey(TQrCodeTrans record);
    
    List findTransList(TQrCodeTransForm tQrCodeTransForm);
    
    List findExcelTransList(TQrCodeTransForm tQrCodeTransForm);
    
    List findWithdrawList(WithdrawForm withdrawForm);
    
    List findWithdrawExcelList(WithdrawForm withdrawForm);
    
}