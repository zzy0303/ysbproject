package com.uns.dao;


import com.uns.model.InsSplitBatchSm;
import com.uns.web.form.InsProfitForm;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Repository
public interface InsSplitBatchSmMapper {

    int deleteByPrimaryKey(BigDecimal id);

    int insert(InsSplitBatchSm record);

    int insertSelective(InsSplitBatchSm record);

    InsSplitBatchSm selectByPrimaryKey(BigDecimal id);

    int updateByPrimaryKeySelective(InsSplitBatchSm record);

    int updateByPrimaryKey(InsSplitBatchSm record);

    List<Map<String,Object>> findProfitBatchList(InsSplitBatchSm insSplitBatchSm);

    void profitAudit(InsSplitBatchSm insSplitBatchSm);
}