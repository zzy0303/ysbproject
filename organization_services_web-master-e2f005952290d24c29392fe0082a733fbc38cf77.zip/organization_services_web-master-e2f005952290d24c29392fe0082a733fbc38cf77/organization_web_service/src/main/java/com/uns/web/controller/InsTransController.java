package com.uns.web.controller;

import java.lang.reflect.InvocationTargetException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.model.InsOperator;
import com.uns.service.InsTransService;
import com.uns.util.ExcelUtils;
import com.uns.util.StringUtils;
import com.uns.web.form.TQrCodeTransForm;

/**
 * 交易管理
 * 
 *
 */
@Controller
@RequestMapping(value = "/insTrans.htm")
public class InsTransController extends BaseController {
	
	@Autowired
	InsTransService insTransService;

	
	/**
	 * 查询交易列表
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params="method=findTransList")
	public String findTransList(HttpServletRequest request, HttpServletResponse response, TQrCodeTransForm tQrCodeTransForm) throws BusinessException{
		try {
			InsOperator operator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			tQrCodeTransForm.setInsNo(operator.getInsNo());

			List transList = insTransService.findTransList(tQrCodeTransForm);
			request.setAttribute("transList", transList);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.交易查询出错);
		}
		return "trans/transList";
	}
	
	
	/**
	 * 跳转到导出excel界面
	 * @return
	 * @throws InvocationTargetException 
	 * @throws IllegalAccessException 
	 * @throws BusinessException 
	 */
	@RequestMapping(params="method=exportTransList")
	public String exportTransList(HttpServletRequest request, HttpServletResponse response, TQrCodeTransForm tQrCodeTransForm) throws IllegalAccessException, InvocationTargetException, BusinessException{
		try {
			InsOperator operator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			tQrCodeTransForm.setInsNo(operator.getInsNo());
			Page page  = new Page();
			page.setPageSize(Constants.EXCEL_SIZE);
			PageContext context = PageContext.getContext();
			BeanUtils.copyProperties(context, page);
			context.setPagination(true);
			insTransService.findTransForExcelList(tQrCodeTransForm);
			BeanUtils.copyProperties(page, context);
			request.setAttribute("page",page);
			request.setAttribute("tQrCodeTransForm", tQrCodeTransForm);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.提现导出页面出错);
		}
		return "trans/transExportPage";
	}
	
	/**
	 * 交易数据导出下载
	 * @param request
	 * @param response
	 * @param modelMap
	 * @param tQrCodeTransForm
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params="method=downExportTransList")
	public String downExportTransList(HttpServletRequest request, HttpServletResponse response, TQrCodeTransForm tQrCodeTransForm) throws BusinessException{
		try{
			InsOperator operator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			tQrCodeTransForm.setInsNo(operator.getInsNo());
			String tPage = request.getParameter("page");
			if (StringUtils.isEmpty(tPage) || !org.apache.commons.lang3.StringUtils.isNumeric(tPage)){
				tPage = "1";
			}
			int currentPage = Integer.valueOf(tPage);
			Page page  = new Page();
			page.setPageSize(Constants.EXCEL_SIZE);
			PageContext context = PageContext.getContext();
			BeanUtils.copyProperties(context, page);
			context.setPagination(true);
			context.setCurrentPage(currentPage);
			List excelList = insTransService.findTransForExcelList(tQrCodeTransForm);
			//标题
			Map<String, String> mapField = new LinkedHashMap();
			mapField.put("SMALL_MERCH_NO","商户编号");
			mapField.put("SCOMPANY","商户名称");          
			mapField.put("ORDER_ID","订单编号");              
			mapField.put("TRAN_NO","充值编号");             
			mapField.put("CARD_TYPE","收款方式");                
			mapField.put("D0_FLAG","结算方式");          
			mapField.put("AMOUNT","交易金额");          
			mapField.put("TRAN_DATE","交易时间");        
			mapField.put("TRAN_FLAG","交易状态");         

			String fileNames="transRecords";
			String sheetNames="transRecords";
			ExcelUtils.downExcel(excelList, response, mapField, fileNames, sheetNames);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.交易导出出错);
		}
		return null;
	}
	
	
}
