package com.uns.model;

import java.math.BigDecimal;

public class B2cDict {
    private BigDecimal b2cDictId;

    private String dict;

    private String dictclsid;

    private String dictcls;

    private String dictid;

    private String gbid;

    private BigDecimal sort;

    private String note;

    private BigDecimal ifstop;

    public BigDecimal getB2cDictId() {
        return b2cDictId;
    }

    public void setB2cDictId(BigDecimal b2cDictId) {
        this.b2cDictId = b2cDictId;
    }

    public String getDict() {
        return dict;
    }

    public void setDict(String dict) {
        this.dict = dict == null ? null : dict.trim();
    }

    public String getDictclsid() {
        return dictclsid;
    }

    public void setDictclsid(String dictclsid) {
        this.dictclsid = dictclsid == null ? null : dictclsid.trim();
    }

    public String getDictcls() {
        return dictcls;
    }

    public void setDictcls(String dictcls) {
        this.dictcls = dictcls == null ? null : dictcls.trim();
    }

    public String getDictid() {
        return dictid;
    }

    public void setDictid(String dictid) {
        this.dictid = dictid == null ? null : dictid.trim();
    }

    public String getGbid() {
        return gbid;
    }

    public void setGbid(String gbid) {
        this.gbid = gbid == null ? null : gbid.trim();
    }

    public BigDecimal getSort() {
        return sort;
    }

    public void setSort(BigDecimal sort) {
        this.sort = sort;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note == null ? null : note.trim();
    }

    public BigDecimal getIfstop() {
        return ifstop;
    }

    public void setIfstop(BigDecimal ifstop) {
        this.ifstop = ifstop;
    }
}