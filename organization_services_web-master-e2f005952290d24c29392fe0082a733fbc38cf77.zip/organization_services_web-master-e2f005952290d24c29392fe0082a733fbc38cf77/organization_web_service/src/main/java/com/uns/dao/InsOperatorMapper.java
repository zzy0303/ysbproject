package com.uns.dao;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.InsOperator;
import com.uns.web.form.InsOperatorForm;
@Repository
public interface InsOperatorMapper {

    int deleteByPrimaryKey(BigDecimal id);

    int insert(InsOperator record);

    int insertSelective(InsOperator record);

    InsOperator selectByPrimaryKey(BigDecimal id);

    int updateByPrimaryKeySelective(InsOperator record);

    int updateByPrimaryKey(InsOperator record);

	InsOperator findInsOperatorByTel(String loginName);

	List<InsOperator> findInsOperatorList(InsOperatorForm insoperatorform);

	InsOperator findDefaultOperator(String insNo);
}