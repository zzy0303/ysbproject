package com.uns.bean;

import java.io.Serializable;
import java.util.Map;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/3/1
 * @Modifyed By:
 */
public class InsImageBean implements Serializable {

    private Map<String, String> faceIdCardMap;
    private Map<String, String> backIdCardMap;
    private Map<String, String> handIdCardMap;
    private Map<String, String> debitCardMap;
    private Map<String, String> businessLicenceMap;
    private Map<String, String> accountOpenPermitMap;
    private String idCard;

    public Map<String, String> getFaceIdCardMap() {
        return faceIdCardMap;
    }

    public void setFaceIdCardMap(Map<String, String> faceIdCardMap) {
        this.faceIdCardMap = faceIdCardMap;
    }

    public Map<String, String> getBackIdCardMap() {
        return backIdCardMap;
    }

    public void setBackIdCardMap(Map<String, String> backIdCardMap) {
        this.backIdCardMap = backIdCardMap;
    }

    public Map<String, String> getHandIdCardMap() {
        return handIdCardMap;
    }

    public void setHandIdCardMap(Map<String, String> handIdCardMap) {
        this.handIdCardMap = handIdCardMap;
    }

    public Map<String, String> getDebitCardMap() {
        return debitCardMap;
    }

    public void setDebitCardMap(Map<String, String> debitCardMap) {
        this.debitCardMap = debitCardMap;
    }

    public Map<String, String> getBusinessLicenceMap() {
        return businessLicenceMap;
    }

    public void setBusinessLicenceMap(Map<String, String> businessLicenceMap) {
        this.businessLicenceMap = businessLicenceMap;
    }

    public Map<String, String> getAccountOpenPermitMap() {
        return accountOpenPermitMap;
    }

    public void setAccountOpenPermitMap(Map<String, String> accountOpenPermitMap) {
        this.accountOpenPermitMap = accountOpenPermitMap;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }
}
