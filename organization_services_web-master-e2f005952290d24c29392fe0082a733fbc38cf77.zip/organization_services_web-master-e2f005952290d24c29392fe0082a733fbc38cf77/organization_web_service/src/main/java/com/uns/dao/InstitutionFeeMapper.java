package com.uns.dao;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.InstitutionFee;
@Repository
public interface InstitutionFeeMapper {


    int deleteByPrimaryKey(BigDecimal insFeeId);

    int insert(InstitutionFee record);

    int insertSelective(InstitutionFee record);

    InstitutionFee selectByPrimaryKey(BigDecimal insFeeId);

    int updateByPrimaryKeySelective(InstitutionFee record);

    int updateByPrimaryKey(InstitutionFee record);

	List<InstitutionFee> findInstitutionFeeList(String insNo);
}