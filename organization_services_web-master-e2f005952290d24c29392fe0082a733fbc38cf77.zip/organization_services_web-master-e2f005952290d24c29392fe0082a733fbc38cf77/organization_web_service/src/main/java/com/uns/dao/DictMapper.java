package com.uns.dao;

import com.uns.model.Dict;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/2/27
 * @Modifyed By:
 */
@Repository
public interface DictMapper {
    List<Dict> findByType(String industry_type);
}
