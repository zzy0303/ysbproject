package com.uns.dao;

import com.uns.model.Commissionpolicy;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
@Repository
public interface CommissionpolicyMapper {

    int insert(Commissionpolicy record);

    int insertSelective(Commissionpolicy record);
    
    List findCommissionpolicy(Long thisCustomerId);

    void insertBatch(List<Commissionpolicy> list);

    void insertHisSelective(Commissionpolicy wxCommissionpolicy);
}