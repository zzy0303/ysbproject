package com.uns.service;

import com.uns.common.Constants;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.dao.InsSplitBatchSmMapper;
import com.uns.dao.InsSplitProfitSmMapper;
import com.uns.model.InsSplitBatchSm;
import com.uns.model.InsSplitProfitSm;
import com.uns.util.ExcelUtils;
import com.uns.util.StringUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/11/24
 * @Modifyed By:
 */
@Service
public class InsProfitService {

    @Autowired
    private InsSplitBatchSmMapper insSplitBatchSmMapper;

    @Autowired
    private InsSplitProfitSmMapper insSplitProfitSmMapper;

    public List<Map<String,Object>> findProfitBatchList(InsSplitBatchSm insSplitBatchSm) throws Exception {
        PageContext.initPageSize(Constants.FIND_PAGE_LIST);
        return insSplitBatchSmMapper.findProfitBatchList(insSplitBatchSm);
    }

    public List<Map<String, Object>> findProfitBatchInfoList(InsSplitProfitSm insSplitProfitSm) throws Exception {
        PageContext.initPageSize(Constants.FIND_PAGE_LIST);
        return insSplitProfitSmMapper.findProfitBatchInfoList(insSplitProfitSm);
    }

    public void profitAudit(InsSplitBatchSm insSplitBatchSm) throws Exception {
        insSplitBatchSm.setConfimDate(new Date());
    	insSplitBatchSm.setBatchNoArr(insSplitBatchSm.getBatchNos().split(","));
        insSplitBatchSmMapper.profitAudit(insSplitBatchSm);
    }

    public Page preExportProfitBatchList(InsSplitBatchSm insSplitBatchSm) throws Exception {
        Page page  = new Page();
        page.setPageSize(Constants.EXCEL_SIZE);
        PageContext context = PageContext.getContext();
        BeanUtils.copyProperties(context, page);
        context.setPagination(true);
        insSplitBatchSmMapper.findProfitBatchList(insSplitBatchSm);
        BeanUtils.copyProperties(page, context);
        return page;
    }

    public void exportProfitBatchList(InsSplitBatchSm insSplitBatchSm, HttpServletRequest request, HttpServletResponse response) throws Exception {
        String tPage = request.getParameter("page");
        if (StringUtils.isEmpty(tPage) || !org.apache.commons.lang3.StringUtils.isNumeric(tPage)){
            tPage = "1";
        }
        int currentPage = Integer.valueOf(tPage);
        Page page  = new Page();
        page.setPageSize(Constants.EXCEL_SIZE);
        PageContext context = PageContext.getContext();
        BeanUtils.copyProperties(context, page);
        context.setPagination(true);
        context.setCurrentPage(currentPage);
        List<Map<String, Object>> list =  insSplitBatchSmMapper.findProfitBatchList(insSplitBatchSm);
        //标题
        Map<String, String> mapField = new LinkedHashMap();
        mapField.put("CREATE_DATE", "批次生成时间");
        mapField.put("BATCH_NO", "批次号");
        mapField.put("STATUS", "分润状态");
        mapField.put("SUM_PROFIT", "分润金额");
        mapField.put("CONFIM_DATE", "确认时间");
        mapField.put("SETTLE_DATE", "结算时间");

        String fileNames="profitBatchRecords";
        String sheetNames="profitBatchRecords";
        ExcelUtils.downExcel(list, response, mapField, fileNames, sheetNames);
    }

    public Page preExportProfitInfoList(InsSplitProfitSm insSplitProfitSm) throws Exception {
        Page page  = new Page();
        page.setPageSize(Constants.EXCEL_SIZE);
        PageContext context = PageContext.getContext();
        BeanUtils.copyProperties(context, page);
        context.setPagination(true);
        insSplitProfitSmMapper.findProfitBatchInfoList(insSplitProfitSm);
        BeanUtils.copyProperties(page, context);
        return page;
    }

    public void exportProfitInfoList(InsSplitProfitSm insSplitProfitSm, HttpServletRequest request, HttpServletResponse response) throws Exception {
        String tPage = request.getParameter("page");
        if (StringUtils.isEmpty(tPage) || !org.apache.commons.lang3.StringUtils.isNumeric(tPage)){
            tPage = "1";
        }
        int currentPage = Integer.valueOf(tPage);
        Page page  = new Page();
        page.setPageSize(Constants.EXCEL_SIZE);
        PageContext context = PageContext.getContext();
        BeanUtils.copyProperties(context, page);
        context.setPagination(true);
        context.setCurrentPage(currentPage);
        List<Map<String, Object>> list =  insSplitProfitSmMapper.findProfitBatchInfoList(insSplitProfitSm);
        //标题
        Map<String, String> mapField = new LinkedHashMap();
        mapField.put("CREATE_DATE", "交易时间");
        mapField.put("SMALL_MERCH_NO", "商户编号");
        mapField.put("SCOMPANY", "商户名称");
        mapField.put("OUTTRADENO", "订单编号");
        mapField.put("CHANNEL_TYPE", "收款方式");
        mapField.put("FEE_TYPE", "结算方式");
        mapField.put("AMOUNT", "交易金额");
        mapField.put("SM_FEE", "商户费率%");
        mapField.put("CUSFIXFEE", "商户固定值");
        mapField.put("FEE", "底价费率%");
        mapField.put("INSFIXFEE", "底价固定值");
        mapField.put("PROFIT", "分润金额");

        String fileNames="profitInfoRecords";
        String sheetNames="profitInfoRecords";
        ExcelUtils.downExcel(list, response, mapField, fileNames, sheetNames);
    }
}
