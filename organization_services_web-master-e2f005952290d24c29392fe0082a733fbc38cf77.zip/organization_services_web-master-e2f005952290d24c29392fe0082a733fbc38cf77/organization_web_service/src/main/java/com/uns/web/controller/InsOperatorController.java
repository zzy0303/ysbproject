package com.uns.web.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.model.InsOperator;
import com.uns.model.InsRoleInfo;
import com.uns.service.InsOperatorService;
import com.uns.service.InsRoleInfoService;
import com.uns.util.FastJson;
import com.uns.util.FileUtils;
import com.uns.web.form.InsOperatorForm;

/**
 * 用户管理
 * @author peng.du
 *
 */
@Controller
@RequestMapping(value = "/insOperator.htm")
public class InsOperatorController extends BaseController{

	@Autowired
	private InsOperatorService insOperatorService;
	
	@Autowired
	private InsRoleInfoService insRoleInfoService;
	
	
	/**
	 * 用户查询
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=findInsOperatorList")
	public String findInsOperatorList(HttpServletRequest request, HttpServletResponse response,InsOperatorForm insoperatorform)throws Exception {
		try {
			InsOperator operator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			insoperatorform.setInsNo(operator.getInsNo());
			List<InsOperator> insOperatorList=insOperatorService.findInsOperatorList(insoperatorform);
			request.setAttribute("insOperatorList", insOperatorList);
			
			List<InsRoleInfo> insRoleInfoList=insRoleInfoService.findInsRoleInfoByInsNo(operator.getInsNo());
			request.setAttribute("insRoleInfoList", insRoleInfoList);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.操作员查询出错);
		}
		return "operator/operatorList";
	}
	
	/**
	 * 添加操作员
	 * @param request
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=addInsOperator")
	@FormToken(save=true)
	public String addInsOperator(HttpServletRequest request) throws BusinessException {
		try {
			InsOperator operator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			
			List<InsRoleInfo> insRoleInfoList=insRoleInfoService.findInsRoleInfoByInsNo(operator.getInsNo());
			request.setAttribute("insRoleInfoList", insRoleInfoList);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.操作员添加页面出错);
		}
		return "operator/operatorAdd";
	}
	
	/**
	 * 保存操作员
	 * @param request
	 * @param operator
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=saveInsOperator")
	@FormToken(remove=true)
	public String saveInsOperator(HttpServletRequest request, InsOperator operator) throws BusinessException {
	    try {
	    	InsOperator operator1 = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
	    	insOperatorService.saveInsOperator(operator1,operator);
			request.setAttribute(Constants.MESSAGE_KEY, "添加操作员成功!");
			request.setAttribute("url","insOperator.htm?method=findInsOperatorList");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.操作员保存出错);
		}
		return "/returnPage";
	}
	
	
	
	/**
	 * 操作员修改页面
	 * @param request
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=editInsOperator")
	@FormToken(save=true)
	public String editInsOperator(HttpServletRequest request) throws BusinessException {
		try {
			InsOperator operator1 = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			String insOperatorId=request.getParameter("insOperatorId");
			InsOperator operator=insOperatorService.findInsOperator(insOperatorId);
			request.setAttribute("operator", operator);
			
			List<InsRoleInfo> insRoleInfoList=insRoleInfoService.findInsRoleInfoByInsNo(operator1.getInsNo());
			request.setAttribute("insRoleInfoList", insRoleInfoList);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.操作员修改页面出错);
		}
		return "operator/operatorUpdate";
	}
	
	/**
	 * 修改 操作员
	 * @param request
	 * @param operator
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=updateInsOperator")
	@FormToken(remove=true)
	public String updateInsOperator(HttpServletRequest request, InsOperator operator) throws BusinessException {
	    try {
	    	InsOperator operator1 = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
	    	insOperatorService.updateInsOperator(operator1,operator);
			request.setAttribute(Constants.MESSAGE_KEY, "修改操作员成功!");
			request.setAttribute("url","insOperator.htm?method=findInsOperatorList");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.操作员修改出错);
		}
		return "/returnPage";
	}
	
	
	
	/**
	 * 修改密码
	 * @param request
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=editPassWord")
	@FormToken(save=true)
	public String editPassWord(HttpServletRequest request) throws BusinessException {
		try {
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.密码修改页面出错);
		}
		return "operator/updatePassWord";
	}
	
	/**
	 * 修改密码
	 * @param request
	 * @param operator
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=updatePassWord")
	@FormToken(remove=true)
	public String updatePassWord(HttpServletRequest request, InsOperator operator) throws BusinessException {
	    try {
	    	InsOperator operator1 = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
	    	insOperatorService.updatePassWord(operator1,operator);
			request.setAttribute(Constants.MESSAGE_KEY, "密码修改成功!");
			request.setAttribute("url","insOperator.htm?method=editPassWord");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.修改密码出错);
		}
	    return "/returnPage";
	}
	
	/**
	 * 查询账号是否存在
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(params = "method=ajaxInsOperator")
	public String ajaxInsOperator(HttpServletRequest request,HttpServletResponse response) throws Exception{
		try {
			String loginname = request.getParameter("loginname").trim();
			boolean isExist = insOperatorService.findInsOperatorByLoginName(loginname);
			log.info("ajaxInsOperator:"+FastJson.toJson(isExist));
			return FastJson.toJson(isExist);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.查询账号出错);
		}
	}
	
	/**ajax 查询密码是否一致
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(params = "method=ajaxOldPassword")
	public String ajaxOldPassword(HttpServletRequest request,HttpServletResponse response) throws Exception{
		try {
			InsOperator operator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			String oldpassword = request.getParameter("oldpassword").trim();
			boolean isExist = insOperatorService.checkPassword(oldpassword,operator);
			log.info("ajaxOldPassword:"+FastJson.toJson(isExist));
			return FastJson.toJson(isExist);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.密码是否一致);
		}
	}
	
	
	/**上传公钥
	 * @param request
	 * @param response
	 * @param mbform
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=uploadInsPubkey")
	public String uploadInsPubkey(HttpServletRequest request,HttpServletResponse response,InsOperatorForm  mbform) throws Exception{
		try {
			InsOperator operator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			insOperatorService.uploadInsPubkey(operator,mbform);
			
			request.setAttribute(Constants.MESSAGE_KEY, "公钥上传成功!");
			request.setAttribute("url","main.htm?method=home");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.上传公钥出错);
		}
		return "/returnPage";
	}
	
	
	/**
	 * 下载公钥
	 * @param request
	 * @param response
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=downloadInsPubkey")
	public void downloadInsPubkey(HttpServletRequest request,HttpServletResponse response) throws BusinessException {
		try {
			insOperatorService.downInsPubkeyFile(request, response);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.下载公钥出错);
		}
	
	}
	
	
	/**
	 * 下载公钥模板
	 * @param request
	 * @param response
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=downTemplateInsPubkey")
	public void downTemplateInsPubkey(HttpServletRequest request,HttpServletResponse response) throws BusinessException {
		try {
			String filename="insPubkey.txt";
			FileUtils.downFile(request, response,filename);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.下载公钥模板出错);
		}
	
	}
}
