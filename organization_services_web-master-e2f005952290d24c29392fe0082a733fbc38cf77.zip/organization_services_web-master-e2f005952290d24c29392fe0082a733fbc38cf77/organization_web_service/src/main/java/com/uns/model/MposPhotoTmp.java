package com.uns.model;

import java.math.BigDecimal;

public class MposPhotoTmp {
    private BigDecimal photoId;

    private String faceIdcardPhoto;

    private String backIdcardPhoto;

    private String handIdcardPhoto;

    private String debitPhoto;

    private String licensePhoto;

    private String openpermitPhoto;

    private String idCardNo;

    private String insNo;

    public BigDecimal getPhotoId() {
        return photoId;
    }

    public void setPhotoId(BigDecimal photoId) {
        this.photoId = photoId;
    }

    public String getFaceIdcardPhoto() {
        return faceIdcardPhoto;
    }

    public void setFaceIdcardPhoto(String faceIdcardPhoto) {
        this.faceIdcardPhoto = faceIdcardPhoto == null ? null : faceIdcardPhoto.trim();
    }

    public String getBackIdcardPhoto() {
        return backIdcardPhoto;
    }

    public void setBackIdcardPhoto(String backIdcardPhoto) {
        this.backIdcardPhoto = backIdcardPhoto == null ? null : backIdcardPhoto.trim();
    }

    public String getHandIdcardPhoto() {
        return handIdcardPhoto;
    }

    public void setHandIdcardPhoto(String handIdcardPhoto) {
        this.handIdcardPhoto = handIdcardPhoto == null ? null : handIdcardPhoto.trim();
    }

    public String getDebitPhoto() {
        return debitPhoto;
    }

    public void setDebitPhoto(String debitPhoto) {
        this.debitPhoto = debitPhoto == null ? null : debitPhoto.trim();
    }

    public String getLicensePhoto() {
        return licensePhoto;
    }

    public void setLicensePhoto(String licensePhoto) {
        this.licensePhoto = licensePhoto == null ? null : licensePhoto.trim();
    }

    public String getOpenpermitPhoto() {
        return openpermitPhoto;
    }

    public void setOpenpermitPhoto(String openpermitPhoto) {
        this.openpermitPhoto = openpermitPhoto == null ? null : openpermitPhoto.trim();
    }

    public String getIdCardNo() {
        return idCardNo;
    }

    public void setIdCardNo(String idCardNo) {
        this.idCardNo = idCardNo == null ? null : idCardNo.trim();
    }

    public String getInsNo() {
        return insNo;
    }

    public void setInsNo(String insNo) {
        this.insNo = insNo == null ? null : insNo.trim();
    }
}