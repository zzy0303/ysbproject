package com.uns.service;

import com.uns.dao.SysAreaMapper;
import com.uns.model.SysArea;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/2/27
 * @Modifyed By:
 */
@Service
public class SysAreaService {

    @Autowired
    SysAreaMapper sysAreaMapper;

    public List<SysArea> findAllProvince() {
        return sysAreaMapper.findAllProvince();
    }

    public List<SysArea> provinceAllCity(String level) {
        return sysAreaMapper.provinceAllCity(level);
    }

    public List<SysArea> selectCityByProvince(String level) {
        return sysAreaMapper.selectCityByProvince(level);
    }
}
