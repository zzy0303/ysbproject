package com.uns.dao;

import org.springframework.stereotype.Repository;

import com.uns.model.InsRoleFunction;
@Repository
public interface InsRoleFunctionMapper {

    int insert(InsRoleFunction record);

    int insertSelective(InsRoleFunction record);

	void deleteByRoleId(Long roleId);

}