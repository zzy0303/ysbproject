package com.uns.web.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.servlet.ModelAndView;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.model.InsOperator;
import com.uns.model.Institution;
import com.uns.model.InstitutionFee;
import com.uns.service.InsMerchantService;
import com.uns.service.InsOperatorService;
import com.uns.service.InsRoleInfoService;
import com.uns.service.InstitutionService;
import com.uns.util.Md5Encrypt;

@Controller
@RequestMapping(value = "/main.htm")
public class LoginController extends BaseController {


	@Autowired
	private InsOperatorService insOperatorService;
	
	@Autowired
	private InstitutionService institutionService;
	
	@Autowired
	private InsRoleInfoService insRoleInfoService;
	
	@Autowired 
	private InsMerchantService insMerchantService;
	

	@RequestMapping(params = "method=login")
	public ModelAndView login(HttpServletRequest request,HttpServletResponse response,
			String loginName,String password, String verycode) throws Exception {
		try {
			// 判断验证码
		    if(StringUtils.isEmpty(verycode)){
		    	throw new BusinessException(ExceptionDefine.验证码不能为空);
		    }
			if (!verycode.equals( request.getSession().getAttribute(Constants.SESSION_VERIFY_CODE))) {
				throw new BusinessException(ExceptionDefine.验证码错);
			}
			InsOperator	insoperator = insOperatorService.findInsOperatorByTel(loginName);
			Institution institution=null;
			if (insoperator != null) {
				switch (insoperator.getStatus()) {
				// 0正常 1 注销 2 冻结 3 锁定
				case Constants.STATUS_1:
					throw new BusinessException(ExceptionDefine.操作员已注销);
				case Constants.STATUS_2:
					throw new BusinessException(ExceptionDefine.操作员被冻结);
				case Constants.STATUS_3:
					throw new BusinessException(ExceptionDefine.操作员被锁定);
				}
			 institution = institutionService.findInstitution(insoperator.getInsNo());
				if (institution != null) {
					switch (institution.getBusinessSwitch()) {
					// 0正常 1 注销 2 冻结 
					case Constants.STATUS_1:
						throw new BusinessException(ExceptionDefine.机构已注销);
					case Constants.STATUS_2:
						throw new BusinessException(ExceptionDefine.机构被冻结);
					}
				}else{
					throw new BusinessException(ExceptionDefine.机构不存在);
				}
			}else{
				throw new BusinessException(ExceptionDefine.操作员不存在);
			}
			// 判断密码
			if (StringUtils.isNotEmpty(password)) {
				String md5passwd = Md5Encrypt.md5(password.trim());
				if (!insoperator.getPassword().equals(md5passwd)) {
					throw new BusinessException(ExceptionDefine.密码错误);
				}
			}
			insoperator.setLastLoginDate(new Date());
			insOperatorService.updateInsoperator(insoperator);
			request.getSession().setAttribute(Constants.SESSION_KEY_USER,insoperator);
			
		    String counts=insMerchantService.findInsMerchantCount(insoperator.getInsNo());
		    List<InstitutionFee> institutionFeeList=institutionService.findInstitutionFeeList(insoperator.getInsNo());

		    List listFuncSelect = new ArrayList();
			request.getSession().setAttribute("funcSelect", listFuncSelect);
			//判断登录权限
			Map maps=null;
			if(StringUtils.isNotEmpty(insoperator.getInsRoleSeq())){
				maps=insRoleInfoService.findLoginFunction(insoperator);
			}
			request.getSession().setAttribute("functionTree", maps);
			request.getSession().setAttribute("institutionFeeList", institutionFeeList);
			request.getSession().setAttribute("institution", institution);
			request.getSession().setAttribute("counts",counts);
			request.getRequestDispatcher("/main.htm?method=home").forward(request, response);
		} catch (BusinessException ex) {
			Map<String, String> model=new HashMap<String, String>();
			ApplicationContext ctx = WebApplicationContextUtils.getRequiredWebApplicationContext(request.getSession().getServletContext());
			MessageSource messageSource = (MessageSource) ctx.getBean("messageSource");
			BusinessException e = (BusinessException) ex;
			model.put(Constants.ERROR_MESSAGE, e.getErrMessage(messageSource));
			return new ModelAndView("redirect:/", model);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("更新登陆时间出现异常" + e.getMessage());
		}
		return null; 
	}

	/**
	 * 跳转到主界面
	 * 
	 * @return
	 */
	@RequestMapping(params = "method=home")
	public String home() {
		return "home";
	}
	
	/**
	 * 跳转到主界面
	 * 
	 * @return
	 */
	@RequestMapping(params = "method=logout")
	public String logout(HttpServletRequest request) {
		request.getSession().invalidate();
		return "login";
	}
	
	
}
					
