package com.uns.dao;

import org.springframework.stereotype.Repository;

import com.uns.model.SysLog;
import com.uns.model.SysLogWithBLOBs;
@Repository
public interface SysLogMapper {

    int deleteByPrimaryKey(String id);

    int insert(SysLogWithBLOBs record);

    int insertSelective(SysLogWithBLOBs record);

    SysLogWithBLOBs selectByPrimaryKey(String id);
    
    int updateByPrimaryKeySelective(SysLogWithBLOBs record);

    int updateByPrimaryKeyWithBLOBs(SysLogWithBLOBs record);

    int updateByPrimaryKey(SysLog record);
}