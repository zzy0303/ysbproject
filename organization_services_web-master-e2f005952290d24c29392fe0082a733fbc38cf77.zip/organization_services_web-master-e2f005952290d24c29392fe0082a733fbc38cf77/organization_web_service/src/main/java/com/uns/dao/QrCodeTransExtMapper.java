package com.uns.dao;

import org.springframework.stereotype.Repository;

import com.uns.model.QrCodeTransExt;
@Repository
public interface QrCodeTransExtMapper {

    int deleteByPrimaryKey(Long id);

    int insert(QrCodeTransExt record);

    int insertSelective(QrCodeTransExt record);

    QrCodeTransExt selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(QrCodeTransExt record);

    int updateByPrimaryKey(QrCodeTransExt record);
}