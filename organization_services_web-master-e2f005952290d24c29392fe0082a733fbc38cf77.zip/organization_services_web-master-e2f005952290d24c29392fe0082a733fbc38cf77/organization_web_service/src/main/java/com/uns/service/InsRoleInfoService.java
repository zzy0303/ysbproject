package com.uns.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.PageContext;
import com.uns.dao.InsFunctionInfoMapper;
import com.uns.dao.InsOperatorMapper;
import com.uns.dao.InsRoleFunctionMapper;
import com.uns.dao.InsRoleInfoMapper;
import com.uns.model.InsFunctionInfo;
import com.uns.model.InsOperator;
import com.uns.model.InsRoleFunction;
import com.uns.model.InsRoleInfo;
import com.uns.web.form.RoleForm;

@Service
public class InsRoleInfoService extends BaseService {
	
	@Autowired
	private InsFunctionInfoMapper insFunctionInfoMapper;
	
	@Autowired
	private InsRoleInfoMapper insRoleInfoMapper;
	
	@Autowired
	private InsRoleFunctionMapper insRoleFunctionMapper;
	
	@Autowired
	private InsOperatorMapper insOperatorMapper;
	
	/**
	 * 登录权限查询
	 * @param insRoleSeq
	 * @return
	 * @throws BusinessException 
	 */
	public Map findLoginFunction(InsOperator insoperator) throws BusinessException {
		//查询机构默认操作员
		String insNo = insoperator.getInsNo();
		InsOperator defaultOperator = insOperatorMapper.findDefaultOperator(insNo);
		if(defaultOperator==null){
			throw new BusinessException(ExceptionDefine.机构默认操作员不存在); 
		}
		Map<String,Object> param = new HashMap<>();
		param.put("insRoleSeq", insoperator.getInsRoleSeq());
		param.put("defaultRole", defaultOperator.getInsRoleSeq());
		List<InsFunctionInfo> list=insFunctionInfoMapper.findLoginFunction(param);
		
		Map<Long,InsFunctionInfo>  allMap = new HashMap<Long,InsFunctionInfo>();
		Map mapReturn = new HashMap();
		
		/***第一次遍历,取根列表***/
		Long curId = null; 
		Long parId = null;
		Map<InsFunctionInfo,List<InsFunctionInfo> > dataMap = new LinkedHashMap<InsFunctionInfo,List<InsFunctionInfo>>();
		List<InsFunctionInfo> subList = null;
		
		for(Iterator iter = list.iterator(); iter.hasNext();){
			InsFunctionInfo func = (InsFunctionInfo) iter.next();
			curId = func.getId();
			allMap.put(curId, func);
			parId = func.getFunctionId();
			if(parId == null){
				dataMap.put(func, new ArrayList<InsFunctionInfo>());
			}
		}
		
		for(Iterator iter = list.iterator(); iter.hasNext();){
			InsFunctionInfo func = (InsFunctionInfo) iter.next();
			curId = func.getId();
			parId = func.getFunctionId();
			if(parId != null){
				subList = dataMap.get(allMap.get(parId));
				if(subList == null)
					subList = new ArrayList<InsFunctionInfo>();
				subList.add(func);
				dataMap.put(allMap.get(parId), subList);
			}
		}
		
		return dataMap;
	}
	

	/**
	 * 角色查询
	 * @param insRoleInfo
	 * @return
	 */
	public List<InsRoleInfo> findInsRoleList(InsRoleInfo insRoleInfo) {
		PageContext.initPageSize(Constants.FIND_PAGE_LIST);
		return insRoleInfoMapper.findInsRoleList(insRoleInfo);
	}



	/**
	 * 查询当前角色拥有的权限
	 * @param insRoleSeq
	 * @return
	 * @throws BusinessException 
	 */
	public Map findAllFunction(InsOperator insoperator) throws BusinessException {
		//查询机构默认操作员
		String insNo = insoperator.getInsNo();
		InsOperator defaultOperator = insOperatorMapper.findDefaultOperator(insNo);
		if(defaultOperator==null){
			throw new BusinessException(ExceptionDefine.机构默认操作员不存在); 
		}
		Map<String,Object> param = new HashMap<>();
		param.put("insRoleSeq", insoperator.getInsRoleSeq());
		param.put("defaultRole", defaultOperator.getInsRoleSeq());
		List<InsFunctionInfo> list=insFunctionInfoMapper.findLoginFunction(param);
		Map mapReturn = new HashMap();
		
		//循环遍历所有功能，放入map中，key为parentId_Id (上级功能Id和Id)
		for(Iterator iter = list.iterator(); iter.hasNext();){
			InsFunctionInfo func = (InsFunctionInfo) iter.next();
			String strId = String.valueOf(func.getId());         //角色编号
			
			String strParentId = "1";          //初始值设为1
			if(func.getFunctionId()!= null){
				strParentId = String.valueOf(func.getFunctionId());
			}
			String strKey = strParentId + "_" + strId;
			mapReturn.put(strKey, func);
		}
		return mapReturn;
	}



	/**
	 * 新增机构-角色权限
	 * @param operator
	 * @param mbForm
	 */
	public void saveInsRoleFunfion(InsOperator operator, RoleForm mbForm) {
		InsRoleInfo roleInfo = new InsRoleInfo();
		roleInfo.setRoleName(mbForm.getRoleName());
		roleInfo.setRemark(mbForm.getRemark());
		roleInfo.setCreateDate(new Date());
		roleInfo.setCreateUser(operator.getInsNo());
		roleInfo.setStatus(Constants.STATUS_1);
		Long[] ids = mbForm.getIds();
		insRoleInfoMapper.insertSelective(roleInfo);
		InsRoleFunction roleFunction=null;
		//保存角色权限表
		for(int i=0;i<ids.length;i++){
			if(ids[i]!=null){
				roleFunction=new InsRoleFunction();
				roleFunction.setFunctionId(ids[i]);
				roleFunction.setRoleId(roleInfo.getId());
				insRoleFunctionMapper.insertSelective(roleFunction);
			}
		}
		
		
	}



	/**
	 * 名称 机构
	 * @param insNo
	 * @param roleName
	 * @return
	 */
	public boolean findInsRoleInfoByName(String roleName)throws Exception {
		List<InsRoleInfo> insRoleInfoList=insRoleInfoMapper.findInsRoleInfoByName(roleName);
		boolean isExist = false;
		if(insRoleInfoList!=null&&insRoleInfoList.size()>0){
			isExist = true;
		}
		return isExist;
	}


	/**
	 * 当前权限
	 * @param roleId
	 * @return
	 */
	public List getlistFuncSelect(String roleId) {
		List listFuncSelect=new ArrayList();
		List listFunction = insFunctionInfoMapper.findRoleFunctionByRole(Long.valueOf(roleId));
		for (Iterator iter = listFunction.iterator(); iter.hasNext();) {
			InsFunctionInfo func = (InsFunctionInfo) iter.next();
			listFuncSelect.add(func.getId());
		}
		return listFuncSelect;
	}



	public InsRoleInfo findInsRoleInfo(String roleId) {
		return insRoleInfoMapper.selectByPrimaryKey(new BigDecimal(roleId));
	}



	/**
	 * 修改角色
	 * @param operator
	 * @param mbForm
	 */
	public void updateRoleFunction(InsOperator operator, RoleForm mbForm) {
		InsRoleInfo roleInfo = new InsRoleInfo();
		roleInfo.setId(mbForm.getRoleId());
		roleInfo.setRoleName(mbForm.getRoleName());
		roleInfo.setRemark(mbForm.getRemark());
		roleInfo.setUpdateDate(new Date());
		roleInfo.setUpdateUser(operator.getInsNo());
		roleInfo.setStatus(Constants.STATUS_1);
		Long[] ids = mbForm.getIds();
		insRoleInfoMapper.updateByPrimaryKeySelective(roleInfo);
		insRoleFunctionMapper.deleteByRoleId(roleInfo.getId());
		InsRoleFunction roleFunction=null;
		//保存角色权限表
		for(int i=0;i<ids.length;i++){
			if(ids[i]!=null){
				roleFunction=new InsRoleFunction();
				roleFunction.setFunctionId(ids[i]);
				roleFunction.setRoleId(roleInfo.getId());
				insRoleFunctionMapper.insert(roleFunction);
			}
		}
	}



	public List<InsRoleInfo> findInsRoleInfoByInsNo(String insNo) {
		return insRoleInfoMapper.findInsRoleInfoByInsNo(insNo);
	}



	
}
