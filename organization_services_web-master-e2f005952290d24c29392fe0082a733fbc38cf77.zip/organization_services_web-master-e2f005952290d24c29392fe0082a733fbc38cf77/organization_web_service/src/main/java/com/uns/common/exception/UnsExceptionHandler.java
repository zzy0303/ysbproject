package com.uns.common.exception;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

import com.uns.common.Constants;

public class UnsExceptionHandler implements HandlerExceptionResolver {

	private Log log = LogFactory.getLog(this.getClass());
	
	@Override
	public ModelAndView resolveException(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex) {
		ex.printStackTrace();
		log.error(ex.getMessage());
		
		ApplicationContext ctx = WebApplicationContextUtils.getRequiredWebApplicationContext(request.getSession().getServletContext());
		MessageSource messageSource = (MessageSource) ctx.getBean("messageSource");
		Map<String, Object> model = new HashMap<String, Object>();
		if (ex instanceof BusinessException) {
			BusinessException e = (BusinessException) ex;
			model.put(Constants.MESSAGE_KEY, e.getErrMessage(messageSource));
			return new ModelAndView("/error/error-business", model);
		}
		
		if(ex instanceof SystemException){
			SystemException e = (SystemException) ex;
			model.put(Constants.MESSAGE_KEY, e.getMessage());
			return new ModelAndView("/error/500", model);
			
		}
		
		return new ModelAndView("/error/500", model);
	}

}
