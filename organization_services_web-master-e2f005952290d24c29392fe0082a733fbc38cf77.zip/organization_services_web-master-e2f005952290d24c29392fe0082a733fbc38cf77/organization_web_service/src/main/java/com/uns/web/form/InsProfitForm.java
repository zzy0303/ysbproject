package com.uns.web.form;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/11/25
 * @Modifyed By:
 */
public class InsProfitForm {

    private String insNo;

    private String batchNo;

    private String batchNos;

    private String[] batchNoArr;

    private String status;

    private String beginConfimDate;

    private String endConfimDate;

    private BigDecimal beginSumProfit;

    private BigDecimal endSumProfit;

    private String beginSettleDate;

    private String endSettleDate;

    private String beginDate;

    private String endDate;

    private String smallMerchNo;

    private String scompay;

    private BigDecimal beginProfit;

    private BigDecimal endProfit;

    private BigDecimal beginAmount;

    private BigDecimal endAmount;

    private String channelType;

    private String feeType;

    public String getBatchNos() {
        return batchNos;
    }

    public void setBatchNos(String batchNos) {
        this.batchNos = batchNos;
    }

    public String[] getBatchNoArr() {
        return batchNoArr;
    }

    public void setBatchNoArr(String[] batchNoArr) {
        this.batchNoArr = batchNoArr;
    }

    public BigDecimal getBeginProfit() {
        return beginProfit;
    }

    public void setBeginProfit(BigDecimal beginProfit) {
        this.beginProfit = beginProfit;
    }

    public BigDecimal getEndProfit() {
        return endProfit;
    }

    public void setEndProfit(BigDecimal endProfit) {
        this.endProfit = endProfit;
    }

    public BigDecimal getBeginAmount() {
        return beginAmount;
    }

    public void setBeginAmount(BigDecimal beginAmount) {
        this.beginAmount = beginAmount;
    }

    public BigDecimal getEndAmount() {
        return endAmount;
    }

    public void setEndAmount(BigDecimal endAmount) {
        this.endAmount = endAmount;
    }

    public String getChannelType() {
        return channelType;
    }

    public void setChannelType(String channelType) {
        this.channelType = channelType;
    }

    public String getFeeType() {
        return feeType;
    }

    public void setFeeType(String feeType) {
        this.feeType = feeType;
    }

    public String getInsNo() {
        return insNo;
    }

    public void setInsNo(String insNo) {
        this.insNo = insNo;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getBeginConfimDate() {
        return beginConfimDate;
    }

    public void setBeginConfimDate(String beginConfimDate) {
        this.beginConfimDate = beginConfimDate;
    }

    public String getEndConfimDate() {
        return endConfimDate;
    }

    public void setEndConfimDate(String endConfimDate) {
        this.endConfimDate = endConfimDate;
    }

    public BigDecimal getBeginSumProfit() {
        return beginSumProfit;
    }

    public void setBeginSumProfit(BigDecimal beginSumProfit) {
        this.beginSumProfit = beginSumProfit;
    }

    public BigDecimal getEndSumProfit() {
        return endSumProfit;
    }

    public void setEndSumProfit(BigDecimal endSumProfit) {
        this.endSumProfit = endSumProfit;
    }

    public String getBeginSettleDate() {
        return beginSettleDate;
    }

    public void setBeginSettleDate(String beginSettleDate) {
        this.beginSettleDate = beginSettleDate;
    }

    public String getEndSettleDate() {
        return endSettleDate;
    }

    public void setEndSettleDate(String endSettleDate) {
        this.endSettleDate = endSettleDate;
    }

    public String getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(String beginDate) {
        this.beginDate = beginDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getSmallMerchNo() {
        return smallMerchNo;
    }

    public void setSmallMerchNo(String smallMerchNo) {
        this.smallMerchNo = smallMerchNo;
    }

    public String getScompay() {
        return scompay;
    }

    public void setScompay(String scompay) {
        this.scompay = scompay;
    }
}
