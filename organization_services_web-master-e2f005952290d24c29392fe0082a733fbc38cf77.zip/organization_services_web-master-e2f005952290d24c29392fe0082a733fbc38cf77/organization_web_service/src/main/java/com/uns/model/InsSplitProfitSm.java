package com.uns.model;

import java.math.BigDecimal;
import java.util.Date;

public class InsSplitProfitSm {
    private BigDecimal id;

    private Date setDate;

    private String channelType;

    private String feeType;
    
    private String scompany;

    private String outtradeno;

    private String outtradetime;

    private BigDecimal amount;

    private BigDecimal beginAmount;

    private BigDecimal endAmount;

    private BigDecimal commission;

    private BigDecimal arrivalamount;

    private String insNo;

    private BigDecimal smFee;

    private BigDecimal fee;

    private BigDecimal profit;

    private BigDecimal beginProfit;

    private BigDecimal endProfit;

    private Date createDate;

    private String batchNo;

    private BigDecimal customerid;

    private BigDecimal commissionid;

    private String feever;

    private String remark;

    private String shopperid;

    private String smallMerchNo;

    private String scompay;

    private String beginDate;

    private String endDate;

    private BigDecimal cusFixFee;
    private BigDecimal cusD0FixFee;
    private BigDecimal insFixFee;
    private BigDecimal insD0FixFee;

    public BigDecimal getCusFixFee() {
        return cusFixFee;
    }

    public void setCusFixFee(BigDecimal cusFixFee) {
        this.cusFixFee = cusFixFee;
    }

    public BigDecimal getCusD0FixFee() {
        return cusD0FixFee;
    }

    public void setCusD0FixFee(BigDecimal cusD0FixFee) {
        this.cusD0FixFee = cusD0FixFee;
    }

    public BigDecimal getInsFixFee() {
        return insFixFee;
    }

    public void setInsFixFee(BigDecimal insFixFee) {
        this.insFixFee = insFixFee;
    }

    public BigDecimal getInsD0FixFee() {
        return insD0FixFee;
    }

    public void setInsD0FixFee(BigDecimal insD0FixFee) {
        this.insD0FixFee = insD0FixFee;
    }

    public String getScompany() {
		return scompany;
	}

	public void setScompany(String scompany) {
		this.scompany = scompany;
	}

	public BigDecimal getFee() {
        return fee;
    }

    public void setFee(BigDecimal fee) {
        this.fee = fee;
    }

    public String getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(String beginDate) {
        this.beginDate = beginDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getScompay() {
        return scompay;
    }

    public void setScompay(String scompay) {
        this.scompay = scompay;
    }

    public String getSmallMerchNo() {
        return smallMerchNo;
    }

    public void setSmallMerchNo(String smallMerchNo) {
        this.smallMerchNo = smallMerchNo;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public Date getSetDate() {
        return setDate;
    }

    public void setSetDate(Date setDate) {
        this.setDate = setDate;
    }

    public String getChannelType() {
        return channelType;
    }

    public void setChannelType(String channelType) {
        this.channelType = channelType == null ? null : channelType.trim();
    }

    public String getFeeType() {
        return feeType;
    }

    public void setFeeType(String feeType) {
        this.feeType = feeType == null ? null : feeType.trim();
    }

    public String getOuttradeno() {
        return outtradeno;
    }

    public void setOuttradeno(String outtradeno) {
        this.outtradeno = outtradeno == null ? null : outtradeno.trim();
    }

    public String getOuttradetime() {
        return outtradetime;
    }

    public void setOuttradetime(String outtradetime) {
        this.outtradetime = outtradetime == null ? null : outtradetime.trim();
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getCommission() {
        return commission;
    }

    public void setCommission(BigDecimal commission) {
        this.commission = commission;
    }

    public BigDecimal getArrivalamount() {
        return arrivalamount;
    }

    public void setArrivalamount(BigDecimal arrivalamount) {
        this.arrivalamount = arrivalamount;
    }

    public String getInsNo() {
        return insNo;
    }

    public void setInsNo(String insNo) {
        this.insNo = insNo == null ? null : insNo.trim();
    }

    public BigDecimal getSmFee() {
        return smFee;
    }

    public void setSmFee(BigDecimal smFee) {
        this.smFee = smFee;
    }

    public BigDecimal getProfit() {
        return profit;
    }

    public void setProfit(BigDecimal profit) {
        this.profit = profit;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo == null ? null : batchNo.trim();
    }

    public BigDecimal getCustomerid() {
        return customerid;
    }

    public void setCustomerid(BigDecimal customerid) {
        this.customerid = customerid;
    }

    public BigDecimal getCommissionid() {
        return commissionid;
    }

    public void setCommissionid(BigDecimal commissionid) {
        this.commissionid = commissionid;
    }

    public String getFeever() {
        return feever;
    }

    public void setFeever(String feever) {
        this.feever = feever == null ? null : feever.trim();
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getShopperid() {
        return shopperid;
    }

    public void setShopperid(String shopperid) {
        this.shopperid = shopperid == null ? null : shopperid.trim();
    }

    public BigDecimal getBeginAmount() {
        return beginAmount;
    }

    public void setBeginAmount(BigDecimal beginAmount) {
        this.beginAmount = beginAmount;
    }

    public BigDecimal getEndAmount() {
        return endAmount;
    }

    public void setEndAmount(BigDecimal endAmount) {
        this.endAmount = endAmount;
    }

    public BigDecimal getBeginProfit() {
        return beginProfit;
    }

    public void setBeginProfit(BigDecimal beginProfit) {
        this.beginProfit = beginProfit;
    }

    public BigDecimal getEndProfit() {
        return endProfit;
    }

    public void setEndProfit(BigDecimal endProfit) {
        this.endProfit = endProfit;
    }
}