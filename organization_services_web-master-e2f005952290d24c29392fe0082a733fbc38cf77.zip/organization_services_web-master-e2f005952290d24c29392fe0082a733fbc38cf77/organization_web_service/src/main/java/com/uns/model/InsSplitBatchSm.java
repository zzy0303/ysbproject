package com.uns.model;

import java.math.BigDecimal;
import java.util.Date;

public class InsSplitBatchSm {
    private BigDecimal id;

    private Date beginDate;

    private Date endDate;

    private String transType;

    private String batchNo;
    
    private String batchNos;
    
    private String[] batchNoArr;

    private String insNo;

    private BigDecimal sumCount;

    private BigDecimal sumAmount;

    private BigDecimal sumProfit;

    private BigDecimal beginSumProfit;

    private BigDecimal endSumProfit;

    private String status;

    private Date createDate;

    private Date confimDate;

    private String beginConfimDate;

    private String endConfimDate;

    private Date settleDate;

    private String beginSettleDate;

    private String endSettleDate;
    
    private String beginCreateDate;
    
    private String endCreateDate;
    

    public String getBeginCreateDate() {
		return beginCreateDate;
	}

	public void setBeginCreateDate(String beginCreateDate) {
		this.beginCreateDate = beginCreateDate;
	}

	public String getEndCreateDate() {
		return endCreateDate;
	}

	public void setEndCreateDate(String endCreateDate) {
		this.endCreateDate = endCreateDate;
	}

	public String getBatchNos() {
		return batchNos;
	}

	public void setBatchNos(String batchNos) {
		this.batchNos = batchNos;
	}

	public String[] getBatchNoArr() {
		return batchNoArr;
	}

	public void setBatchNoArr(String[] batchNoArr) {
		this.batchNoArr = batchNoArr;
	}

	public BigDecimal getBeginSumProfit() {
        return beginSumProfit;
    }

    public void setBeginSumProfit(BigDecimal beginSumProfit) {
        this.beginSumProfit = beginSumProfit;
    }

    public BigDecimal getEndSumProfit() {
        return endSumProfit;
    }

    public void setEndSumProfit(BigDecimal endSumProfit) {
        this.endSumProfit = endSumProfit;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public Date getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(Date beginDate) {
        this.beginDate = beginDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getTransType() {
        return transType;
    }

    public void setTransType(String transType) {
        this.transType = transType == null ? null : transType.trim();
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo == null ? null : batchNo.trim();
    }

    public String getInsNo() {
        return insNo;
    }

    public void setInsNo(String insNo) {
        this.insNo = insNo == null ? null : insNo.trim();
    }

    public BigDecimal getSumCount() {
        return sumCount;
    }

    public void setSumCount(BigDecimal sumCount) {
        this.sumCount = sumCount;
    }

    public BigDecimal getSumAmount() {
        return sumAmount;
    }

    public void setSumAmount(BigDecimal sumAmount) {
        this.sumAmount = sumAmount;
    }

    public BigDecimal getSumProfit() {
        return sumProfit;
    }

    public void setSumProfit(BigDecimal sumProfit) {
        this.sumProfit = sumProfit;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getConfimDate() {
        return confimDate;
    }

    public void setConfimDate(Date confimDate) {
        this.confimDate = confimDate;
    }

    public Date getSettleDate() {
        return settleDate;
    }

    public void setSettleDate(Date settleDate) {
        this.settleDate = settleDate;
    }

    public String getBeginConfimDate() {
        return beginConfimDate;
    }

    public void setBeginConfimDate(String beginConfimDate) {
        this.beginConfimDate = beginConfimDate;
    }

    public String getEndConfimDate() {
        return endConfimDate;
    }

    public void setEndConfimDate(String endConfimDate) {
        this.endConfimDate = endConfimDate;
    }

    public String getBeginSettleDate() {
        return beginSettleDate;
    }

    public void setBeginSettleDate(String beginSettleDate) {
        this.beginSettleDate = beginSettleDate;
    }

    public String getEndSettleDate() {
        return endSettleDate;
    }

    public void setEndSettleDate(String endSettleDate) {
        this.endSettleDate = endSettleDate;
    }
}