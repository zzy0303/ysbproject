package com.uns.util;

import com.uns.common.ConstantsEnv;
import org.apache.commons.lang.RandomStringUtils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

public class AuthenticAtionUtils {
	
	
	
	/**
	 * 商户鉴权
	 * @param bankNo
	 * @param name
	 * @param idNo
	 * @return
	 */
	public static String authentication(String bankNo, String name, String idNo){
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmssSSS");
			StringBuffer sb = new StringBuffer();
			
			sb.append("K").append(sdf.format(new Date())).append(RandomStringUtils.randomNumeric(3));
			String orderId = sb.toString();
			
			sb = new StringBuffer();
			sb.append(bankNo).append("|").append(name).append("|").append(idNo);
			System.out.println("商户鉴权身份信息："+sb.toString());
			String data = AesEncrypt.encrypt(sb.toString(), ConstantsEnv.AUTHENTICATION_KEY);
			
			sb = new StringBuffer();
			sb.append("accountId=").append(ConstantsEnv.AUTHENTICATION_MERNUM);
			sb.append("&contractId=").append(ConstantsEnv.AUTHENTICATION_MERNUM);
			sb.append("&orderId=").append(orderId);
			sb.append("&data=").append(data);
			sb.append("&key=").append(ConstantsEnv.AUTHENTICATION_KEY);
			System.out.println("商户鉴权商户秘钥信息:"+sb.toString());
			String mac = Md5Encrypt.md5(sb.toString());
			
			Map map = new LinkedHashMap();
			map.put("accountId", ConstantsEnv.AUTHENTICATION_MERNUM);
			map.put("contractId", ConstantsEnv.AUTHENTICATION_MERNUM);
			map.put("orderId", orderId);
			map.put("data", data);
			map.put("mac", mac);
			
			String url = ConstantsEnv.AUTHENTICATION_URL;
			String result = HttpClientUtils.REpostRequestStrJson(url, FastJson.toJson(map));
			System.out.println("商户鉴权返回信息:" + result);
			return result;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}

}
