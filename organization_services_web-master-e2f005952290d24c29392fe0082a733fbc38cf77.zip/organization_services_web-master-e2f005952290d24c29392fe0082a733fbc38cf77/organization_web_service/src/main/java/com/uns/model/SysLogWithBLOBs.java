package com.uns.model;

import java.util.Map;

import com.uns.util.StringUtils;

public class SysLogWithBLOBs extends SysLog {
    private String params;

    private String exception;

    public String getParams() {
        return params;
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
   	public void setParams(String params){
   		/*if (paramMap == null){
   			return;
   		}
   		StringBuilder params = new StringBuilder();
   		for (Map.Entry<String, String[]> param : ((Map<String, String[]>)paramMap).entrySet()){
   			params.append(("".equals(params.toString()) ? "" : "&") + param.getKey() + "=");
   			String paramValue = (param.getValue() != null && param.getValue().length > 0 ? param.getValue()[0] : "");
   			params.append(StringUtils.abbr(org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(param.getKey(), "password") ? "" : paramValue, 100));
   		}
   		this.params = params.toString();*/
   		this.params = params == null ? null : params.trim();
   	}

    public String getException() {
        return exception;
    }

    public void setException(String exception) {
        
    }
}