package com.uns.web.form;

import org.springframework.web.multipart.MultipartFile;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/2/26
 * @Modifyed By:
 */
public class CommissionForm implements Serializable {
    private BigDecimal wxT1Fee;
    private BigDecimal wxT1Amount;
    private BigDecimal wxD0Fee;
    private BigDecimal wxD0Amount;
    private BigDecimal zfbT1Fee;
    private BigDecimal zfbT1Amount;
    private BigDecimal zfbD0Fee;
    private BigDecimal zfbD0Amount;
    private BigDecimal kjShD0Fee;
    private BigDecimal kjD0Fee;
    private BigDecimal kjD0Amount;
    private BigDecimal kjT1Fee;
    private BigDecimal kjT1Amount;
    private BigDecimal mdDebitFee;
    private BigDecimal mdDebitAmount;
    private BigDecimal mdCreditFee;
    private BigDecimal mdCreditAmount;
    private BigDecimal jsDebigFee;
    private BigDecimal jsDebitAmount;
    private BigDecimal jsCreditFee;
    private BigDecimal jsCreditAmount;
    private BigDecimal t1DebitFee;
    private BigDecimal t1DebitAmount;
    private BigDecimal t1CreditFee;
    private BigDecimal t1CreditAmount;

    private MultipartFile faceIdCard;
    private MultipartFile backIdCard;
    private MultipartFile handIdCard;
    private MultipartFile debitCard;
    private MultipartFile businessLicence;
    private MultipartFile accountOpenPermit;

    public BigDecimal getWxT1Fee() {
        return wxT1Fee;
    }

    public void setWxT1Fee(BigDecimal wxT1Fee) {
        this.wxT1Fee = wxT1Fee;
    }

    public BigDecimal getWxT1Amount() {
        return wxT1Amount;
    }

    public void setWxT1Amount(BigDecimal wxT1Amount) {
        this.wxT1Amount = wxT1Amount;
    }

    public BigDecimal getWxD0Fee() {
        return wxD0Fee;
    }

    public void setWxD0Fee(BigDecimal wxD0Fee) {
        this.wxD0Fee = wxD0Fee;
    }

    public BigDecimal getWxD0Amount() {
        return wxD0Amount;
    }

    public void setWxD0Amount(BigDecimal wxD0Amount) {
        this.wxD0Amount = wxD0Amount;
    }

    public BigDecimal getZfbT1Fee() {
        return zfbT1Fee;
    }

    public void setZfbT1Fee(BigDecimal zfbT1Fee) {
        this.zfbT1Fee = zfbT1Fee;
    }

    public BigDecimal getZfbT1Amount() {
        return zfbT1Amount;
    }

    public void setZfbT1Amount(BigDecimal zfbT1Amount) {
        this.zfbT1Amount = zfbT1Amount;
    }

    public BigDecimal getZfbD0Fee() {
        return zfbD0Fee;
    }

    public void setZfbD0Fee(BigDecimal zfbD0Fee) {
        this.zfbD0Fee = zfbD0Fee;
    }

    public BigDecimal getZfbD0Amount() {
        return zfbD0Amount;
    }

    public void setZfbD0Amount(BigDecimal zfbD0Amount) {
        this.zfbD0Amount = zfbD0Amount;
    }

    public BigDecimal getKjShD0Fee() {
        return kjShD0Fee;
    }

    public void setKjShD0Fee(BigDecimal kjShD0Fee) {
        this.kjShD0Fee = kjShD0Fee;
    }

    public BigDecimal getKjD0Fee() {
        return kjD0Fee;
    }

    public void setKjD0Fee(BigDecimal kjD0Fee) {
        this.kjD0Fee = kjD0Fee;
    }

    public BigDecimal getKjD0Amount() {
        return kjD0Amount;
    }

    public void setKjD0Amount(BigDecimal kjD0Amount) {
        this.kjD0Amount = kjD0Amount;
    }

    public BigDecimal getKjT1Fee() {
        return kjT1Fee;
    }

    public void setKjT1Fee(BigDecimal kjT1Fee) {
        this.kjT1Fee = kjT1Fee;
    }

    public BigDecimal getKjT1Amount() {
        return kjT1Amount;
    }

    public void setKjT1Amount(BigDecimal kjT1Amount) {
        this.kjT1Amount = kjT1Amount;
    }

    public BigDecimal getMdDebitFee() {
        return mdDebitFee;
    }

    public void setMdDebitFee(BigDecimal mdDebitFee) {
        this.mdDebitFee = mdDebitFee;
    }

    public BigDecimal getMdDebitAmount() {
        return mdDebitAmount;
    }

    public void setMdDebitAmount(BigDecimal mdDebitAmount) {
        this.mdDebitAmount = mdDebitAmount;
    }

    public BigDecimal getMdCreditFee() {
        return mdCreditFee;
    }

    public void setMdCreditFee(BigDecimal mdCreditFee) {
        this.mdCreditFee = mdCreditFee;
    }

    public BigDecimal getMdCreditAmount() {
        return mdCreditAmount;
    }

    public void setMdCreditAmount(BigDecimal mdCreditAmount) {
        this.mdCreditAmount = mdCreditAmount;
    }

    public BigDecimal getJsDebigFee() {
        return jsDebigFee;
    }

    public void setJsDebigFee(BigDecimal jsDebigFee) {
        this.jsDebigFee = jsDebigFee;
    }

    public BigDecimal getJsDebitAmount() {
        return jsDebitAmount;
    }

    public void setJsDebitAmount(BigDecimal jsDebitAmount) {
        this.jsDebitAmount = jsDebitAmount;
    }

    public BigDecimal getJsCreditFee() {
        return jsCreditFee;
    }

    public void setJsCreditFee(BigDecimal jsCreditFee) {
        this.jsCreditFee = jsCreditFee;
    }

    public BigDecimal getJsCreditAmount() {
        return jsCreditAmount;
    }

    public void setJsCreditAmount(BigDecimal jsCreditAmount) {
        this.jsCreditAmount = jsCreditAmount;
    }

    public BigDecimal getT1DebitFee() {
        return t1DebitFee;
    }

    public void setT1DebitFee(BigDecimal t1DebitFee) {
        this.t1DebitFee = t1DebitFee;
    }

    public BigDecimal getT1DebitAmount() {
        return t1DebitAmount;
    }

    public void setT1DebitAmount(BigDecimal t1DebitAmount) {
        this.t1DebitAmount = t1DebitAmount;
    }

    public BigDecimal getT1CreditFee() {
        return t1CreditFee;
    }

    public void setT1CreditFee(BigDecimal t1CreditFee) {
        this.t1CreditFee = t1CreditFee;
    }

    public BigDecimal getT1CreditAmount() {
        return t1CreditAmount;
    }

    public void setT1CreditAmount(BigDecimal t1CreditAmount) {
        this.t1CreditAmount = t1CreditAmount;
    }

    public MultipartFile getFaceIdCard() {
        return faceIdCard;
    }

    public void setFaceIdCard(MultipartFile faceIdCard) {
        this.faceIdCard = faceIdCard;
    }

    public MultipartFile getBackIdCard() {
        return backIdCard;
    }

    public void setBackIdCard(MultipartFile backIdCard) {
        this.backIdCard = backIdCard;
    }

    public MultipartFile getHandIdCard() {
        return handIdCard;
    }

    public void setHandIdCard(MultipartFile handIdCard) {
        this.handIdCard = handIdCard;
    }

    public MultipartFile getDebitCard() {
        return debitCard;
    }

    public void setDebitCard(MultipartFile debitCard) {
        this.debitCard = debitCard;
    }

    public MultipartFile getBusinessLicence() {
        return businessLicence;
    }

    public void setBusinessLicence(MultipartFile businessLicence) {
        this.businessLicence = businessLicence;
    }

    public MultipartFile getAccountOpenPermit() {
        return accountOpenPermit;
    }

    public void setAccountOpenPermit(MultipartFile accountOpenPermit) {
        this.accountOpenPermit = accountOpenPermit;
    }
}
