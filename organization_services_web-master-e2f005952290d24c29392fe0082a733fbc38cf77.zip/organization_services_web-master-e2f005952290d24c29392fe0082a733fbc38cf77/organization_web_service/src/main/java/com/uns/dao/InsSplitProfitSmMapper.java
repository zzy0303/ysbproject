package com.uns.dao;

import com.uns.model.InsSplitProfitSm;
import com.uns.web.form.InsProfitForm;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Repository
public interface InsSplitProfitSmMapper {

    int deleteByPrimaryKey(BigDecimal id);

    int insert(InsSplitProfitSm record);

    int insertSelective(InsSplitProfitSm record);

    InsSplitProfitSm selectByPrimaryKey(BigDecimal id);

    int updateByPrimaryKeySelective(InsSplitProfitSm record);

    int updateByPrimaryKey(InsSplitProfitSm record);

    List<Map<String, Object>> findProfitBatchInfoList(InsSplitProfitSm insSplitProfitSm);
}