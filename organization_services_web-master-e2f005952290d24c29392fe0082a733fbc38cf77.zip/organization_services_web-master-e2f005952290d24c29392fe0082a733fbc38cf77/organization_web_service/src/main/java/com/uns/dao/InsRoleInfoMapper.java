package com.uns.dao;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.InsRoleInfo;
@Repository
public interface InsRoleInfoMapper {


    int deleteByPrimaryKey(BigDecimal id);

    int insert(InsRoleInfo record);

    int insertSelective(InsRoleInfo record);

    InsRoleInfo selectByPrimaryKey(BigDecimal id);

    int updateByPrimaryKeySelective(InsRoleInfo record);

    int updateByPrimaryKey(InsRoleInfo record);

	List<InsRoleInfo> findInsRoleList(InsRoleInfo record);
	
	List<InsRoleInfo> findInsRoleInfoByName(String roleName);

	List<InsRoleInfo> findInsRoleInfoByInsNo(String insNo);
}