package com.uns.service;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.dao.SysLogMapper;
import com.uns.model.InsOperator;
import com.uns.model.SysLogWithBLOBs;
import com.uns.util.StringUtils;

@Service
public class LogService {

	
	@Autowired
	private static SysLogMapper sysLogMapper;
	
	/**
	 * 保存日志
	 * @param request
	 * @param handler
	 * @param ex
	 * @param object
	 */
	public void saveLog(HttpServletRequest request) {
		InsOperator operator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
		if(operator!=null && StringUtils.isTrimNotEmpty(operator.getInsNo())){
			SysLogWithBLOBs log=new SysLogWithBLOBs();
			log.setTitle("注销");
			log.setType("1");
			log.setRemoteAddr(StringUtils.getRemoteAddr(request));
			log.setUserAgent(request.getHeader("user-agent"));
			log.setRequestUri(request.getRequestURI());
			log.setParams(request.getParameterMap().toString());
			log.setMethod(request.getMethod());
			sysLogMapper.insertSelective(log);
		}
	}
	
}
