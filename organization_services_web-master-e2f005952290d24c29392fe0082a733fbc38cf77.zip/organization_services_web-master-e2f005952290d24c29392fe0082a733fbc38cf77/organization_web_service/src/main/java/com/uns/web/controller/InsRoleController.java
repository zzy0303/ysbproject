package com.uns.web.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.model.InsOperator;
import com.uns.model.InsRoleInfo;
import com.uns.service.InsRoleInfoService;
import com.uns.util.FastJson;
import com.uns.web.form.RoleForm;

/**
 * 角色管理
 * @author peng.du
 *
 */
@Controller
@RequestMapping(value = "/insRole.htm")
public class InsRoleController extends BaseController {

	@Autowired
	private InsRoleInfoService insRoleInfoService;
	
	/**
	 * 角色查询
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=findInsRoleList")
	public String findInsRoleList(HttpServletRequest request, HttpServletResponse response,InsRoleInfo insRoleInfo)throws Exception {
		try {
			InsOperator operator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			insRoleInfo.setCreateUser(operator.getInsNo());
			List<InsRoleInfo>  roleList=insRoleInfoService.findInsRoleList(insRoleInfo);
			request.setAttribute("roleList", roleList);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.角色查询出错);
		}
		return "role/roleList";
	}
	
	/**
	 * 角色添加
	 * @param request
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=toAddRole")
	@FormToken(save=true)
	public String toAddRole(HttpServletRequest request) throws BusinessException {
		try {
			InsOperator operator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			List listFuncSelect = new ArrayList();
			request.setAttribute("funcSelect", listFuncSelect);
			// 查询返回功能树
			Map map = insRoleInfoService.findAllFunction(operator);
			request.setAttribute("functionTree", map);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.角色添加页面出错);
		}
		return "role/roleAdd";
	}
	
	
	
	/**
	 * 机构-角色添加
	 * @param request
	 * @param mbForm
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=saveInsRoleFunfion")
	@FormToken(remove=true)
	public String saveInsRoleFunfion(HttpServletRequest request, RoleForm mbForm) throws BusinessException {
	    try {
	    	InsOperator operator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
	    	insRoleInfoService.saveInsRoleFunfion(operator, mbForm);
			request.setAttribute(Constants.MESSAGE_KEY, "角色添加成功!");
			request.setAttribute("url","insRole.htm?method=findInsRoleList");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.角色保存出错);
		}
		return "/returnPage";
	}
	
	/**
	 * 修改页面
	 * @param request
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=toUpdateRole")
	@FormToken(save=true)
	public String toUpdateRole(HttpServletRequest request) throws BusinessException {
		try {
			InsOperator operator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			String roleId=request.getParameter("roleId");
			//角色拥有的权限
			List listFuncSelect = insRoleInfoService.getlistFuncSelect(roleId);
			request.setAttribute("funcSelect", listFuncSelect);
			// 查询返回功能树
			Map map = insRoleInfoService.findAllFunction(operator);
			request.setAttribute("functionTree", map);
			//当前角色
			InsRoleInfo roleInfo=insRoleInfoService.findInsRoleInfo(roleId);
			request.setAttribute("roleInfo", roleInfo);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.角色修改页面出错);
		}
		return "role/roleUpdate";
	}
	
	/**
	 * 
	 * @param request
	 * @param mbForm
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=updateRoleFunction")
	@FormToken(remove=true)
	public String updateRoleFunction(HttpServletRequest request, RoleForm mbForm) throws BusinessException {
	    try {
	    	InsOperator operator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
	    	insRoleInfoService.updateRoleFunction(operator, mbForm);
			request.setAttribute(Constants.MESSAGE_KEY, "角色修改!");
			request.setAttribute("url","insRole.htm?method=findInsRoleList");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.角色修改出错);
		}
		return "/returnPage";
	}
	
	/**
	 * ajax 机构-查询角色名称是否重复
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	
	@ResponseBody
	@RequestMapping(params = "method=ajaxRoleName")
	public String ajaxRoleName(HttpServletRequest request,HttpServletResponse response) throws Exception{
		try {
			String roleName = request.getParameter("roleName").trim();
			boolean isExist = insRoleInfoService.findInsRoleInfoByName(roleName);
			log.info("ajaxJson:"+FastJson.toJson(isExist));
			return FastJson.toJson(isExist);
		} catch (IOException e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.查询机构名称是否存在);
		}
	}
}
