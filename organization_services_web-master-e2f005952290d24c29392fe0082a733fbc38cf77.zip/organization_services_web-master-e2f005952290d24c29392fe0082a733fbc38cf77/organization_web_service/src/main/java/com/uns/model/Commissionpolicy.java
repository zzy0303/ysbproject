package com.uns.model;

import java.math.BigDecimal;

public class Commissionpolicy {
    private Long commissionid;

    private String commissionname;

    private Long commissionRate;

    private Long topfee;

    private Long customerid;

    private Short commissiontype;

    private String feever;

    private Short cardtype;

    private Long d0CommissionRate;

    private BigDecimal fixedRate;

    private BigDecimal d0FixedRate;

    public BigDecimal getFixedRate() {
        return fixedRate;
    }

    public void setFixedRate(BigDecimal fixedRate) {
        this.fixedRate = fixedRate;
    }

    public BigDecimal getD0FixedRate() {
        return d0FixedRate;
    }

    public void setD0FixedRate(BigDecimal d0FixedRate) {
        this.d0FixedRate = d0FixedRate;
    }

    public Long getCommissionid() {
        return commissionid;
    }

    public void setCommissionid(Long commissionid) {
        this.commissionid = commissionid;
    }

    public String getCommissionname() {
        return commissionname;
    }

    public void setCommissionname(String commissionname) {
        this.commissionname = commissionname == null ? null : commissionname.trim();
    }

    public Long getCommissionRate() {
        return commissionRate;
    }

    public void setCommissionRate(Long commissionRate) {
        this.commissionRate = commissionRate;
    }

    public Long getTopfee() {
        return topfee;
    }

    public void setTopfee(Long topfee) {
        this.topfee = topfee;
    }

    public Long getCustomerid() {
        return customerid;
    }

    public void setCustomerid(Long customerid) {
        this.customerid = customerid;
    }

    public Short getCommissiontype() {
        return commissiontype;
    }

    public void setCommissiontype(Short commissiontype) {
        this.commissiontype = commissiontype;
    }

    public String getFeever() {
        return feever;
    }

    public void setFeever(String feever) {
        this.feever = feever == null ? null : feever.trim();
    }

    public Short getCardtype() {
        return cardtype;
    }

    public void setCardtype(Short cardtype) {
        this.cardtype = cardtype;
    }

    public Long getD0CommissionRate() {
        return d0CommissionRate;
    }

    public void setD0CommissionRate(Long d0CommissionRate) {
        this.d0CommissionRate = d0CommissionRate;
    }
}