package com.uns.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.uns.model.InsFunctionInfo;
@Repository
public interface InsFunctionInfoMapper {


    int deleteByPrimaryKey(BigDecimal id);

    int insert(InsFunctionInfo record);

    int insertSelective(InsFunctionInfo record);

    InsFunctionInfo selectByPrimaryKey(BigDecimal id);

    int updateByPrimaryKeySelective(InsFunctionInfo record);

    int updateByPrimaryKey(InsFunctionInfo record);

	//List<InsFunctionInfo> findLoginFunction1(String insRoleSeq);
	
	List<InsFunctionInfo> findLoginFunction(Map<String,Object> param);
	
	List findRoleFunctionByRole(Long roleId);
}