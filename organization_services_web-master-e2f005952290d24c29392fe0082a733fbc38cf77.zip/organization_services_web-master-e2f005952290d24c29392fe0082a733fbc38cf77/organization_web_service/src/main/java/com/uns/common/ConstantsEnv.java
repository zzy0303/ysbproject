package com.uns.common;

import com.uns.inf.acms.client.DynamicConfigLoader;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/3/1
 * @Modifyed By:
 */
public class ConstantsEnv {
    /**
     * 商户鉴权参数
     */
    public static final String AUTHENTICATION_MERNUM = DynamicConfigLoader.getByEnv("authentication_mernum");
    public static final String AUTHENTICATION_KEY = DynamicConfigLoader.getByEnv("authentication_key");
    public static final String AUTHENTICATION_URL = DynamicConfigLoader.getByEnv("authentication_url");

    /**
     * 机构商户注册接口参数
     */
    public static final String CUSTOMER_REG_P_URL = DynamicConfigLoader.getByEnv("customer_reg_p_url");
    public static final String CUSTOMER_REG_C_URL = DynamicConfigLoader.getByEnv("customer_reg_c_url");
}
