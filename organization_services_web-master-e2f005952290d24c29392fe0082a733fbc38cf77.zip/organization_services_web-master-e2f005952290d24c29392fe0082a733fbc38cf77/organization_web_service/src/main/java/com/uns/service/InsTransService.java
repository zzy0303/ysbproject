package com.uns.service;

import java.util.List;

import com.uns.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.common.page.PageContext;
import com.uns.dao.TQrCodeTransMapper;
import com.uns.web.form.TQrCodeTransForm;
import com.uns.web.form.WithdrawForm;

@Service
public class InsTransService  extends BaseService {
	
	@Autowired
	TQrCodeTransMapper  tQrCodeTransMapper;
	
	public List findTransList(TQrCodeTransForm tQrCodeTransForm){
		PageContext.initPageSize(Constants.FIND_PAGE_LIST);
		return tQrCodeTransMapper.findTransList(tQrCodeTransForm);
	}
	
	public List findTransForExcelList(TQrCodeTransForm tQrCodeTransForm){
		PageContext.initPageSize(Constants.EXCEL_SIZE);
		return tQrCodeTransMapper.findExcelTransList(tQrCodeTransForm);
	}
	
	
	public List findWithdrawList(WithdrawForm withdrawForm){
		PageContext.initPageSize(Constants.FIND_PAGE_LIST);
		return tQrCodeTransMapper.findWithdrawList(withdrawForm);
	}
	public List findWithdrawForExcelList(WithdrawForm withdrawForm){
		PageContext.initPageSize(Constants.EXCEL_SIZE);
		return tQrCodeTransMapper.findWithdrawExcelList(withdrawForm);
	}
	
}
