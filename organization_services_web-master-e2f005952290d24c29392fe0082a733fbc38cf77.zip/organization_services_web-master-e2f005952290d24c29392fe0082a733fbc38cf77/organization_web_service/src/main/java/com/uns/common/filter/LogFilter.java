package com.uns.common.filter;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.core.NamedThreadLocal;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.uns.service.LogService;
import com.uns.util.DateUtils;

public class LogFilter implements Filter {
	
	protected Logger logger = LoggerFactory.getLogger(getClass());
	
	private static final ThreadLocal<Long> startTimeThreadLocal =
			new NamedThreadLocal<Long>("ThreadLocal StartTime");
	
	LogService logService;
	List list=new ArrayList<>();

	@Override
	public void init(FilterConfig fc) throws ServletException {
		ApplicationContext ctx = WebApplicationContextUtils
				.getRequiredWebApplicationContext(fc.getServletContext());
			logService = (LogService) ctx.getBean("logService");
	}
	
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res,
			FilterChain fc) throws IOException, ServletException {
		final HttpServletRequest request = (HttpServletRequest) req;
		logService.saveLog(request);
		fc.doFilter(req, res);
		return;
	}
}
