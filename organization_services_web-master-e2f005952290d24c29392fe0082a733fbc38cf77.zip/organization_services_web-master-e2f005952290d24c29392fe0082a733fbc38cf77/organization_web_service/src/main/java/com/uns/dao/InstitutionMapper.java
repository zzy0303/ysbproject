package com.uns.dao;

import org.springframework.stereotype.Repository;

import com.uns.model.Institution;
@Repository
public interface InstitutionMapper {

    int deleteByPrimaryKey(Long insId);

    int insert(Institution record);

    int insertSelective(Institution record);

    Institution selectByPrimaryKey(Long insId);

    int updateByPrimaryKeySelective(Institution record);

    int updateByPrimaryKey(Institution record);

	Institution findInstitution(String insNo);
	
}