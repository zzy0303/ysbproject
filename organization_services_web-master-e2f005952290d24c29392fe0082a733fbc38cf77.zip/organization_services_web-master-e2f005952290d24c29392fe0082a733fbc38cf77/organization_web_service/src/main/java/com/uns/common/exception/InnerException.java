package com.uns.common.exception;

/*
 * 系统内部需要捕获的异常（Controll中catch）
 */
public class InnerException extends Exception {
	private String returnCode ;
	private String resultCode;
	
	public InnerException (String rtnCode, Throwable reason) {
		super (rtnCode, reason) ;
		this.returnCode = rtnCode ;
	}
	
	public InnerException (String rtnCode, String strReasonCode) {
		super (rtnCode, null) ;
		this.returnCode = rtnCode ;
		this.resultCode=strReasonCode;
	}
	
	public InnerException (String rtnCode) {
		this (rtnCode, "A001") ;
	}

	public String getReturnCode() {
		return returnCode;
	}
	
	public String getResultCode() {
		return resultCode;
	}
}
