package com.uns.common.interceptor;

import java.io.OutputStreamWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.uns.common.Constants;



public class LoginInterceptor implements HandlerInterceptor {

	private List<String> excludedUrls;

	public void setExcludedUrls(List<String> excludedUrls) {
		this.excludedUrls = excludedUrls;
	}

	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object arg2) throws Exception {
		String param=request.getQueryString();
		for (String url : excludedUrls) {
			if (param.endsWith(url)) {
				return true;
			}
		}
		// intercept
		HttpSession session = request.getSession();
		if (session.getAttribute(Constants.SESSION_KEY_USER) == null) {
			/*String path=request.getContextPath();
			response.sendRedirect(path);*/
			toRedirect(request,response); 
			return false;
		}
		
		return true;
	}

	
	public void toRedirect(HttpServletRequest request,HttpServletResponse response) throws Exception{
			  OutputStreamWriter out=null; 
		try {
	          response.setContentType("text/html;charset=UTF-8");
	          response.setCharacterEncoding("UTF-8");
	          out=new OutputStreamWriter(response.getOutputStream());   
	          
	          String msg="由于您长时间没有操作，session已过期，请重新登录！";
	          msg=new String(msg.getBytes("UTF-8"));
	          
	          out.write("<meta http-equiv='Content-Type' content='text/html';charset='UTF-8'>");
	          out.write("<script>");
	          out.write("alert('"+msg+"');");
	          out.write("top.location.href = '/organization_web_service'; ");
	          out.write("</script>");
	          out.flush();
	          out.close();
	     } catch (Exception e) {
	         e.printStackTrace();
	         
	     }finally {
	    	 out.flush();
	         out.close();
		}
	}
	
	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse respose, Object arg2, ModelAndView arg3)
			throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object arg2, Exception arg3)
			throws Exception {
		// TODO Auto-generated method stub

	}

}
