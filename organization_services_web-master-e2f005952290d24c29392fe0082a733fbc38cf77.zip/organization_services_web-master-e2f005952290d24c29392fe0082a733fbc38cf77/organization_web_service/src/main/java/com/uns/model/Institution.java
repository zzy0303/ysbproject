package com.uns.model;

import java.util.Date;
import java.util.List;

public class Institution {
    private Long insId;

    private String insNo;

    private String insName;

    private String insPubKey;

    private Long accountBankId;

    private Date createTime;

    private Date updateTime;

    private String businessSwitch;

    private String supportD0Switch;

    private String zfbAppId;

    private String zfbPubKey;

    private String zfbPriKey;

    private String wxAppSecret;

    private String insShortName;

    private String insTel;

    private String insProvince;

    private String insProvinceName;

    private String insCity;

    private String insCityName;

    private String insSrelation;

    private String insFax;

    private String insEmail;

    private String insZip;

    private String insAddress;

    private String insYnum;

    private String insBankCode;

    private String insBankName;

    private String insSubBankName;

    private String insBankClientName;

    private String insBankCardNo;

    private Long ysbuserid;

    private Long cascustomid;

    private String businessType;

    private List<String> businessTypeList;

    private String commissionType;

    public String getCommissionType() {
        return commissionType;
    }

    public void setCommissionType(String commissionType) {
        this.commissionType = commissionType;
    }

    public Long getInsId() {
        return insId;
    }

    public void setInsId(Long insId) {
        this.insId = insId;
    }

    public String getInsNo() {
        return insNo;
    }

    public void setInsNo(String insNo) {
        this.insNo = insNo == null ? null : insNo.trim();
    }

    public String getInsName() {
        return insName;
    }

    public void setInsName(String insName) {
        this.insName = insName == null ? null : insName.trim();
    }

    public String getInsPubKey() {
        return insPubKey;
    }

    public void setInsPubKey(String insPubKey) {
        this.insPubKey = insPubKey == null ? null : insPubKey.trim();
    }

    public Long getAccountBankId() {
        return accountBankId;
    }

    public void setAccountBankId(Long accountBankId) {
        this.accountBankId = accountBankId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getBusinessSwitch() {
        return businessSwitch;
    }

    public void setBusinessSwitch(String businessSwitch) {
        this.businessSwitch = businessSwitch == null ? null : businessSwitch.trim();
    }

    public String getSupportD0Switch() {
        return supportD0Switch;
    }

    public void setSupportD0Switch(String supportD0Switch) {
        this.supportD0Switch = supportD0Switch == null ? null : supportD0Switch.trim();
    }

    public String getZfbAppId() {
        return zfbAppId;
    }

    public void setZfbAppId(String zfbAppId) {
        this.zfbAppId = zfbAppId == null ? null : zfbAppId.trim();
    }

    public String getZfbPubKey() {
        return zfbPubKey;
    }

    public void setZfbPubKey(String zfbPubKey) {
        this.zfbPubKey = zfbPubKey == null ? null : zfbPubKey.trim();
    }

    public String getZfbPriKey() {
        return zfbPriKey;
    }

    public void setZfbPriKey(String zfbPriKey) {
        this.zfbPriKey = zfbPriKey == null ? null : zfbPriKey.trim();
    }

    public String getWxAppSecret() {
        return wxAppSecret;
    }

    public void setWxAppSecret(String wxAppSecret) {
        this.wxAppSecret = wxAppSecret == null ? null : wxAppSecret.trim();
    }

    public String getInsShortName() {
        return insShortName;
    }

    public void setInsShortName(String insShortName) {
        this.insShortName = insShortName == null ? null : insShortName.trim();
    }

    public String getInsTel() {
        return insTel;
    }

    public void setInsTel(String insTel) {
        this.insTel = insTel == null ? null : insTel.trim();
    }

    public String getInsProvince() {
        return insProvince;
    }

    public void setInsProvince(String insProvince) {
        this.insProvince = insProvince == null ? null : insProvince.trim();
    }

    public String getInsProvinceName() {
        return insProvinceName;
    }

    public void setInsProvinceName(String insProvinceName) {
        this.insProvinceName = insProvinceName == null ? null : insProvinceName.trim();
    }

    public String getInsCity() {
        return insCity;
    }

    public void setInsCity(String insCity) {
        this.insCity = insCity == null ? null : insCity.trim();
    }

    public String getInsCityName() {
        return insCityName;
    }

    public void setInsCityName(String insCityName) {
        this.insCityName = insCityName == null ? null : insCityName.trim();
    }

    public String getInsSrelation() {
        return insSrelation;
    }

    public void setInsSrelation(String insSrelation) {
        this.insSrelation = insSrelation == null ? null : insSrelation.trim();
    }

    public String getInsFax() {
        return insFax;
    }

    public void setInsFax(String insFax) {
        this.insFax = insFax == null ? null : insFax.trim();
    }

    public String getInsEmail() {
        return insEmail;
    }

    public void setInsEmail(String insEmail) {
        this.insEmail = insEmail == null ? null : insEmail.trim();
    }

    public String getInsZip() {
        return insZip;
    }

    public void setInsZip(String insZip) {
        this.insZip = insZip == null ? null : insZip.trim();
    }

    public String getInsAddress() {
        return insAddress;
    }

    public void setInsAddress(String insAddress) {
        this.insAddress = insAddress == null ? null : insAddress.trim();
    }

    public String getInsYnum() {
        return insYnum;
    }

    public void setInsYnum(String insYnum) {
        this.insYnum = insYnum == null ? null : insYnum.trim();
    }

    public String getInsBankCode() {
        return insBankCode;
    }

    public void setInsBankCode(String insBankCode) {
        this.insBankCode = insBankCode == null ? null : insBankCode.trim();
    }

    public String getInsBankName() {
        return insBankName;
    }

    public void setInsBankName(String insBankName) {
        this.insBankName = insBankName == null ? null : insBankName.trim();
    }

    public String getInsSubBankName() {
        return insSubBankName;
    }

    public void setInsSubBankName(String insSubBankName) {
        this.insSubBankName = insSubBankName == null ? null : insSubBankName.trim();
    }

    public String getInsBankClientName() {
        return insBankClientName;
    }

    public void setInsBankClientName(String insBankClientName) {
        this.insBankClientName = insBankClientName == null ? null : insBankClientName.trim();
    }

    public String getInsBankCardNo() {
        return insBankCardNo;
    }

    public void setInsBankCardNo(String insBankCardNo) {
        this.insBankCardNo = insBankCardNo == null ? null : insBankCardNo.trim();
    }

    public Long getYsbuserid() {
        return ysbuserid;
    }

    public void setYsbuserid(Long ysbuserid) {
        this.ysbuserid = ysbuserid;
    }

    public Long getCascustomid() {
        return cascustomid;
    }

    public void setCascustomid(Long cascustomid) {
        this.cascustomid = cascustomid;
    }

    public String getBusinessType() {
        return businessType;
    }

    public void setBusinessType(String businessType) {
        this.businessType = businessType == null ? null : businessType.trim();
    }

    public List<String> getBusinessTypeList() {
        return businessTypeList;
    }

    public void setBusinessTypeList(List<String> businessTypeList) {
        this.businessTypeList = businessTypeList;
    }
}