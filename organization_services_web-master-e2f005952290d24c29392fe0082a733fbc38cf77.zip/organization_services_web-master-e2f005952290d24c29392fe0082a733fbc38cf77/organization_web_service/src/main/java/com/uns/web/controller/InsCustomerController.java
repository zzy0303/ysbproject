package com.uns.web.controller;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.model.*;
import com.uns.service.DictService;
import com.uns.service.InsMerchantService;
import com.uns.service.InstitutionService;
import com.uns.service.SysAreaService;
import com.uns.web.form.CustomerForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Arrays;
import java.util.List;

/**
 * 商户管理
 */
@Controller
@RequestMapping(value = "/insCustomer.htm")
public class InsCustomerController extends BaseController {

    @Autowired
    private MessageSource messageSource;

    @Autowired
    private InsMerchantService insMerchantService;

    @Autowired
    private SysAreaService sysAreaService;

    @Autowired
    private DictService dictService;

    @Autowired
    private InstitutionService institutionService;

    /**
     * 商户注册
     *
     * @param request
     * @param customer
     * @return
     */
    @RequestMapping(params = "method=insCustomerReg")
    public String insCustomerReg(HttpServletRequest request, Customer customer) throws Exception {
        try {
            InsOperator operator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
            customer.setInsNo(operator.getInsNo());
            insMerchantService.insCustomerReg(customer);
            request.setAttribute(Constants.MSG_KEY, "商户注册成功!");
            request.setAttribute("title", "商户注册");
            request.setAttribute("closeTitle", "商户查询");
            request.setAttribute("url", "insCustomer.htm?method=findInsCustomerList");
        } catch (BusinessException be) {
            request.setAttribute(Constants.ERROR_MESSAGE, be.getErrMessage(messageSource));
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute(Constants.ERROR_MESSAGE, "系统错误,请稍后再试！");
        }
        return "common/message";
    }

    /**
     * 跳转商户注册页面
     *
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(params = "method=preInsCustomerReg")
    public String preInsCustomerReg(HttpServletRequest request, HttpServletResponse response) {
        InsOperator operator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
        Institution institution = institutionService.findInstitution(operator.getInsNo());
        institution.setBusinessTypeList(Arrays.asList(institution.getBusinessType().split(",")));

        if (!institution.getBusinessTypeList().contains(Constants.STATUS_0)) {
            request.setAttribute(Constants.ERROR_MESSAGE, "机构未添加扫码业务类型，请先添加再进行商户注册！");
            return "common/message";
        }
        request.setAttribute("institution", institution);
        // 查询所有省
        List<SysArea> allProvince = sysAreaService.findAllProvince();
        //查询行业list
        List<Dict> dictList = dictService.findByType("industry_type");
        //查询银行列表
        List<B2cDict> dicts = dictService.findAllBank();
        request.setAttribute("bankList", dicts);
        request.setAttribute("allProvince", allProvince);
        request.setAttribute("dictList", dictList);
        return "customer/customerReg2";
    }

    /**
     * 查询商户列表
     *
     * @param request
     * @param response
     * @return
     * @throws BusinessException
     * @throws Exception
     */
    @RequestMapping(params = "method=findInsCustomerList")
    public String findInsCustomerList(HttpServletRequest request, HttpServletResponse response, CustomerForm customerForm) throws BusinessException {
        try {
            //获取当前登录机构号
            InsOperator insOperator = ((InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER));
            customerForm.setThisInsNo(insOperator.getInsNo());
            //获取商户列表
            List customerList = insMerchantService.findInsCustomerList(customerForm);
            request.setAttribute("customerList", customerList);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.商户查询出错);
        }
        return "customer/customerList";
    }


    /**
     * 单个商户详情
     *
     * @param request
     * @param response
     * @param
     * @param customerForm
     * @return
     * @throws BusinessException
     */
    @RequestMapping(params = "method=findInsCustomerDetail")
    public String findInsCustomerDetail(HttpServletRequest request, HttpServletResponse response, CustomerForm customerForm) throws BusinessException {
        Long thisCustomerId = customerForm.getThisCustomerId();
        try {
            if (null != thisCustomerId) {
                Customer thisCustomer = insMerchantService.findInsCustomerDetail(thisCustomerId);
                //查询开户行省市名称
                SysArea openingBankArea = insMerchantService.findOpeningBankArea(thisCustomer);
                thisCustomer.setOpeningBankProvince(openingBankArea.getProvincialname());
                thisCustomer.setOpeningBankCity(openingBankArea.getCityname());
                //加星号处理
                insMerchantService.asteriskSolution(thisCustomer);
                request.setAttribute("thisCustomer", thisCustomer);
                //查询到所属机构的名字
                Institution institution = insMerchantService.findBelongIns(thisCustomer);
                request.setAttribute("institution", institution);
                //查询商户费率
                List commissionpolicyList = insMerchantService.findCommissionpolicy(Long.valueOf(thisCustomerId));
                request.setAttribute("commissionpolicyList", commissionpolicyList);

                Long photoId = thisCustomer.getPhotoId();
                if (null != photoId) {
                    MposPhotoTmp mposPhotoTmp = insMerchantService.findInsPhoto(photoId);
                    request.setAttribute("photo", mposPhotoTmp);
                    request.setAttribute("image_get_url", DynamicConfigLoader.getByEnv("showInsImage_url"));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.商户详情查询出错);
        }
        return "customer/customerDetails";
    }

    /**
     * 查询省的下属市
     *
     * @param level
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(params = "method=selectProvinceAllCity")
    @ResponseBody
    public List<SysArea> selectProvinceAllCity(HttpServletRequest request, HttpServletResponse response, String level) {
        List<SysArea> allCity = sysAreaService.provinceAllCity(level);// 异步联动查询城市
        return allCity;
    }

    @ResponseBody
    @RequestMapping(params = "method=selectCityByProvince")
    public List<SysArea> selectCityByProvince(HttpServletRequest request, HttpServletResponse response, String level) {
        List<SysArea> allCity = sysAreaService.selectCityByProvince(level);
        return allCity;
    }

    /**
     * 验证身份证号是否已被注册
     *
     * @param request
     * @param idCard
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=checkIdCard")
    public @ResponseBody
    boolean checkIdCard(HttpServletRequest request, String idCard) throws Exception {
        InsOperator operator = (InsOperator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
        return insMerchantService.checkIdCard(idCard, operator);
    }
}
