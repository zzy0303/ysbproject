package com.uns.web.form;

import org.apache.commons.lang3.StringUtils;

//交易记录查询表单
public class TQrCodeTransForm {
	//当前登录机构号
	public String insNo;
	//交易记录列表查询（导出excel）
	public String customerNo;//商户编号
	public String customerName;//商户名称
	public String cardType;//收款方式
	public String orderId;//订单编号
	public String chargeId;//充值编号
	public String d0Flag;//结算方式
	public String amountStart;//交易金额下限
	public String amountEnd;//交易金额上限
	public String tranFlag;//交易状态(交易行为表中的tranFlag)
	public String tranTimeStart;//交易时间下限
	public String tranTimeEnd;//交易时间上限
	public String smallMerchNo;

	public String getSmallMerchNo() {
		return smallMerchNo;
	}

	public void setSmallMerchNo(String smallMerchNo) {
		this.smallMerchNo = smallMerchNo;
	}

	public String getTranTimeStart() {
		return tranTimeStart;
	}
	public void setTranTimeStart(String tranTimeStart) {
		this.tranTimeStart = tranTimeStart;
	}
	public String getTranTimeEnd() {
		return tranTimeEnd;
	}
	public void setTranTimeEnd(String tranTimeEnd) {
		this.tranTimeEnd = tranTimeEnd;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public String getInsNo() {
		return insNo;
	}
	public void setInsNo(String insNo) {
		this.insNo = insNo;
	}
	//getter and setter
	public String getCustomerNo() {
		return customerNo;
	}
	public void setCustomerNo(String customerNo) {
		this.customerNo = customerNo==null?"":customerNo.trim();
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName==null?"":customerName.trim();
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId==null?"":orderId.trim();
	}
	public String getChargeId() {
		return chargeId;
	}
	public void setChargeId(String chargeId) {
		this.chargeId = chargeId==null?"":chargeId.trim();
	}
	public String getD0Flag() {
		return d0Flag;
	}
	public void setD0Flag(String d0Flag) {
		this.d0Flag = d0Flag;
	}
	public String getTranFlag() {
		return tranFlag;
	}
	public void setTranFlag(String tranFlag) {
		this.tranFlag = tranFlag;
	}
	public String getAmountStart() {
		return amountStart;
	}
	public void setAmountStart(String amountStart) {
		if(StringUtils.isNumeric(amountStart.trim())){
			this.amountStart = amountStart.trim();
		}else{
			this.amountStart =null;
		}
		
	}
	public String getAmountEnd() {
		return amountEnd;
	}
	public void setAmountEnd(String amountEnd) {
		if(StringUtils.isNumeric(amountEnd.trim())){
			this.amountEnd = amountEnd.trim();
		}else{
			this.amountEnd =null;
		}
	}
	
}
