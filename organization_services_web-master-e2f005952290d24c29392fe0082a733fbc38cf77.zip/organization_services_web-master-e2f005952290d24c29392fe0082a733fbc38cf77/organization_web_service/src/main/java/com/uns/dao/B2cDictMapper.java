package com.uns.dao;

import com.uns.model.B2cDict;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface B2cDictMapper {

    int deleteByPrimaryKey(BigDecimal b2cDictId);

    int insert(B2cDict record);

    int insertSelective(B2cDict record);

    B2cDict selectByPrimaryKey(BigDecimal b2cDictId);

    int updateByPrimaryKeySelective(B2cDict record);

    int updateByPrimaryKey(B2cDict record);

    List<B2cDict> findAllBank();

    String findBankByDictId(String bankCode);
}