package com.uns.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.dao.InstitutionFeeMapper;
import com.uns.dao.InstitutionMapper;
import com.uns.model.Institution;
import com.uns.model.InstitutionFee;

@Service
public class InstitutionService extends BaseService {

	@Autowired
	private InstitutionMapper institutionMapper;
	
	@Autowired
	private InstitutionFeeMapper institutionFeeMapper;
	
	public Institution findInstitution(String insNo) {
		return institutionMapper.findInstitution(insNo);
	}

	public List<InstitutionFee> findInstitutionFeeList(String insNo) {
		return institutionFeeMapper.findInstitutionFeeList(insNo);
	}

}
