package com.uns.inf.mpos.job;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:context/**/*.xml"})
public class InfomationJobTest {

	@Autowired
	InfomationJob infomationJob;
	
	@Autowired
	MposRemoteInvitationJob mposRemoteInvitationJob;
	
	@Autowired
	MposFenRunJob mposFenRunJob;
	
	@Autowired
	MposQrcodeFenRunJob mposQrcodeFenRunJob;

	@Autowired
	InsProfitRunJob insProfitRunJob;

	@Autowired
	MerchantFeeMsgPushJob merchantFeeMsgPushJob;

	@Autowired
	MposQrcodeMerchantFRJob mposQrcodeMerchantFRJob;
	
//	@Test
	public void simpleJob() throws InterruptedException{
		infomationJob.handleJavaJob(null, null, null, null);
	}

//	@Test
	public void mposRemoteInvitationJob() throws InterruptedException{
		mposRemoteInvitationJob.handleJavaJob(null, null, null, null);
	}
	
//	@Test
	public void mposFenRunJob() throws InterruptedException{
		mposFenRunJob.handleJavaJob(null, null, null, null);
	}
	
	@Test
	public void mposQrcodeFenRunJob() throws InterruptedException{
		mposQrcodeFenRunJob.handleJavaJob(null, null, null, null);
	}

	@Test
	public void insProfitRunJob() throws InterruptedException {
		insProfitRunJob.handleJavaJob(null, null, null, null);
	}

	@Test
	public void merchantFeeMsgPushJob() throws InterruptedException {
		merchantFeeMsgPushJob.handleJavaJob(null, null, null, null);
	}
	
	/*@Test
	public void mposScanAutoCheckJob() throws InterruptedException{
		mposScanAutoCheckJob.handleJavaJob(null, null, null, null);
	}*/

	@Test
	public void mposQrcodeMerchantFRJob() throws InterruptedException{
		mposQrcodeMerchantFRJob.handleJavaJob(null,null,null,null);
	}
}
