package com.uns.inf.mpos.service;

import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.inf.mpos.common.Constants;
import com.uns.inf.mpos.entry.B2cShopperbiTemp;
import com.uns.inf.notify.api.Notify;
import com.uns.inf.notify.request.NotifyResult;
import com.uns.inf.notify.request.SmsNotifyRequest;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@Service
public class SendMessageService {
	private Logger log = Logger.getLogger(SendMessageService.class);
	
	@Autowired
	private Notify notify;
	
	/**
	 * 发送短信消息
	 * @param mobile 手机号
	 * @param content 发送内容
	 * @return 
	 */
	public NotifyResult sendSmsMessage(String mobile, String content){
		NotifyResult notifyResult = null;
		try {
			String serialNumber = System.currentTimeMillis()+RandomStringUtils.randomNumeric(4);
			SmsNotifyRequest smsNotifyRequest = new SmsNotifyRequest();
			smsNotifyRequest.addMobile(mobile);//手机号
			smsNotifyRequest.setSerialNumber(serialNumber);
			smsNotifyRequest.setTemplateId(21000021L);//设置一个已存在的模板，但不会读取模板内容 以Content内容为准
			smsNotifyRequest.setAppid("small_mgr");
			Map<String, String> data = new HashMap<String,String>();
			data.put("content", content);
			smsNotifyRequest.setData(data);
			notifyResult = notify.sendSms(smsNotifyRequest);
			if (null == notifyResult || !"success".equals(notifyResult.getState() + "")) {
				log.info("调用发送短信接口返回失败！"+ notifyResult.toString());
			}else{
				log.info("短信已发送到：" + notifyResult.toString());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return notifyResult;
	}
	
	/**
	 * 发送短信
	 * @param b2cShopperbi
	 */
	public void sendMessageOCR(B2cShopperbiTemp b2cShopperbi){
		String content = getContentOCR(Constants.SMS_CONTENT_OCR, b2cShopperbi);
		String mobile = b2cShopperbi.getStel();
		sendSmsMessage(mobile, content);
	}

	private String getContentOCR(String smsContent,  B2cShopperbiTemp b2cShopperbi) {
		Map map = getOCRSmsMap(b2cShopperbi);
		return this.replaceValues(smsContent, map);
	}

	private Map<String, String> getOCRSmsMap(B2cShopperbiTemp b2cShopperbi){

		Map<String, String> map = new HashMap<String, String>();
		map.put("${name}", b2cShopperbi.getName() + "");
		return map;
	}
	
	private String getContentCheckMsg(String smsContent,B2cShopperbiTemp b2cShopperbi) {
		Map map=getCheckMsgValuesapp(b2cShopperbi);
		return this.replaceValues(smsContent, map);
	}

	private Map getCheckMsgValuesapp(B2cShopperbiTemp b2cShopperbi) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("${mercahntName}",b2cShopperbi.getName()+ "");
		return map;
	}

	private String getContentNotPassMsg(String smsContentNotPass,B2cShopperbiTemp b2cShopperbi) {
		Map map=getContentNotPass(b2cShopperbi);
		return this.replaceValues(smsContentNotPass, map);
	}

	private Map getContentNotPass(B2cShopperbiTemp b2cShopperbi) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("${mercahntName}",b2cShopperbi.getName()+ "");
		return map;
	}
	
	private String replaceValues(String mailContent, Map<String, String> values) {
		Set<String> set = values.keySet();
		for (String key : set){
			if(key.indexOf("${") != -1)
				mailContent = mailContent.replace(key, values.get(key) + "");
		}
		return mailContent;
	}
}
