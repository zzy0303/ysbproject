package com.uns.inf.mpos.job;

import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.inf.mpos.common.DataSourceType;
import com.uns.inf.mpos.dao.MposFenRunMapper;
import com.uns.inf.mpos.mutidatasource.DataSourceSwitch;
import com.vip.saturn.job.SaturnJobExecutionContext;
import com.vip.saturn.job.SaturnJobReturn;
import com.vip.saturn.job.SaturnSpringJob;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @Author: KaiFeng
 * @Description: 机构分润定时任务
 * @Date: 2017/11/27
 * @Modifyed By:
 */
@Component
public class InsProfitRunJob extends SaturnSpringJob<InsProfitRunJob> {

    private Logger log = LoggerFactory.getLogger(getClass());

    @Autowired
    MposFenRunMapper mposFenRunMapper;

    @Override
    public SaturnJobReturn handleJavaJob(String jobName, Integer shardItem, String shardParam, SaturnJobExecutionContext shardingContext) throws InterruptedException {
        log.info("机构分润定时任务 跑批 开始执行==================");
        try {
            DataSourceSwitch.setDataSourceType(DataSourceType.DATASOURCE_INSTANCE.INS.name());
            mposFenRunMapper.InsProfitRunJobWeek();
        } finally{
            DataSourceSwitch.clearDataSourceType();
        }
        log.info("机构分润定时任务 跑批 结束执行==================");
        return new SaturnJobReturn("机构 分润定时任务：InsProfitRunJob 执行完成!");
    }
}
