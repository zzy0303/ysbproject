package com.uns.inf.mpos.dao;


import com.uns.inf.mpos.entry.MerchantBean;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface MerchantProfitBatchFissionMapper {

	MerchantBean findPassMerchantProfit(Long merchantProfitId);

	void updateMerchantProfitPass();

	void updateMerchantProfitNotPass(Long merchantProfitId);

	Map findPassMerchantProfitById(Long merchantProfitId);

	List<MerchantBean> findPassMerchantProfitBatch(Map param);

	void updateMerchantProfitPassBatch(Map param);

	List<MerchantBean> findWaitPassProfit(@Param("checkAudit") String checkAudit);

	int updateMsgFlag(String batchNo);

	Long findMerchantProfitByBatch(String batchNo);

	String checkSysConfig();

    List<MerchantBean> findMposWaitPassProfit(@Param("checkAudit") String checkAudit);

    Map findMposPassMerchantProfitById(Long merchantProfitId);
}
