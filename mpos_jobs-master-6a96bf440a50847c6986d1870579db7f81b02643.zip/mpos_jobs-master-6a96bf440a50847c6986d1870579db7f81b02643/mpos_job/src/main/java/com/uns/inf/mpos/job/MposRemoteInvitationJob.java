package com.uns.inf.mpos.job;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.uns.inf.mpos.dao.MposRemoteInvitationMapper;
import com.vip.saturn.job.SaturnJobExecutionContext;
import com.vip.saturn.job.SaturnJobReturn;
import com.vip.saturn.job.SaturnSpringJob;
@Component
public class MposRemoteInvitationJob extends SaturnSpringJob<MposRemoteInvitationJob> {
	protected final Logger log = LoggerFactory.getLogger(MposRemoteInvitationJob.class);
	
	@Autowired
	MposRemoteInvitationMapper mposRemoteInvitationMapper;
	
	/**
	 *u3_small:检测远程邀请有效期
	 */
	@Override
	public SaturnJobReturn handleJavaJob(String jobName, Integer shardItem, String shardParam,
			SaturnJobExecutionContext shardingContext) throws InterruptedException {
		
		log.info("远程邀请定时任务：MposRemoteInvitationJob 开始执行==============");
		mposRemoteInvitationMapper.updateData();
		log.info("远程邀请定时任务：MposRemoteInvitationJob 结束执行==============");
		return new SaturnJobReturn("远程邀请定时任务：MposRemoteInvitationJob 执行成功！");
	}

}
