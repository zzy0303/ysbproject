package com.uns.inf.mpos.common;

import com.uns.inf.acms.client.DynamicConfigLoader;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/12/24
 * @Modifyed By:
 */
public class Constants {
    public static final String RERURNCODE = "0000";


    public static String MERCHANT_WITHDRAW_URL=DynamicConfigLoader.getByEnv("merchant_withdraw_url");

    /**
     * 分润消息发送
     */
    public static String SEND_PROFIT_MSG_URL = DynamicConfigLoader.getByEnv("send_profit_msg_url");

    public static final String STATUS_0 = "0";
    public static final String STATUS_1 = "1";

    public static final String RESPONSE_CODE="0000";
    public static final String NOT_PASS_STEP_ALL_PASS = "2,2,2,2,2,2";
    public static final String NOT_PASS_STEP_ALL_PASS_NO_CREDIT_CARD = "2,2,3,2,2,2";
    public static final long NOT_AUTOCHECK_TIME = 300000;//不进行自动审核的时间间隔（5分钟）
    public static final String TYPE_1 = "1";
    public static final String TYPE_2 = "2";
    public static final String CON_YES = "1";
    public static final String CON_NO = "0";
    public static final String SMS_CONTENT_OCR = DynamicConfigLoader.getByEnv("sms.content.url.ocr");

}
