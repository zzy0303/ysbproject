package com.uns.inf.mpos.service;

import com.uns.inf.mpos.common.Constants;
import com.uns.inf.mpos.common.DataSourceType;
import com.uns.inf.mpos.common.FastJson;
import com.uns.inf.mpos.common.HttpClientUtils;
import com.uns.inf.mpos.dao.MerchantProfitBatchFissionMapper;
import com.uns.inf.mpos.entry.MerchantBean;
import com.uns.inf.mpos.mutidatasource.DataSourceSwitch;
import net.sf.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/12/24
 * @Modifyed By:
 */
@Service
public class MerchantFeeMsgPushService {

    protected Logger log = LoggerFactory.getLogger(getClass());

    @Autowired
    MerchantProfitBatchFissionMapper merchantProfitBatchFissionMapper;

    /**
     * 扫码分润消息推送
     *
     * @throws Exception
     */
    @Async
    public void mposQrcodeMsgPush() {
        try {
            try {
                DataSourceSwitch.setDataSourceType(DataSourceType.DATASOURCE_INSTANCE.MPOS_QRCODE.name());
                //查询商户分润是否需审核  0:不需审核  1:需要审核
                String checkAudit = merchantProfitBatchFissionMapper.checkSysConfig();
                if (Constants.STATUS_0.equals(checkAudit)) {
                    profitManager(checkAudit);
                    //待结算分润记录修改为已结算状态
                    merchantProfitBatchFissionMapper.updateMerchantProfitPass();
                }
            } finally {
                DataSourceSwitch.clearDataSourceType();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 刷卡分润消息推送
     *
     * @throws Exception
     */
    @Async
    public void mposMsgPush() {
        try {
            String checkAudit;
            try {
                DataSourceSwitch.setDataSourceType(DataSourceType.DATASOURCE_INSTANCE.MPOS_QRCODE.name());
                //查询商户分润是否需审核  0:不需审核  1:需要审核
                checkAudit = merchantProfitBatchFissionMapper.checkSysConfig();
            } finally {
                DataSourceSwitch.clearDataSourceType();
            }
            if (Constants.STATUS_0.equals(checkAudit)) {
                try {
                    DataSourceSwitch.setDataSourceType(DataSourceType.DATASOURCE_INSTANCE.MPOS.name());
                    profitManager(checkAudit);
                    //待结算分润记录修改为已结算状态
                    merchantProfitBatchFissionMapper.updateMerchantProfitPass();
                } finally {
                    DataSourceSwitch.clearDataSourceType();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void profitManager(String checkAudit) throws Exception {
        List<Long> idList = new ArrayList<>();
        //查询审核通过 未推送分润消息记录
        List<MerchantBean> list;
        String sourceType;
        if (DataSourceType.DATASOURCE_INSTANCE.MPOS_QRCODE.name().equals(DataSourceSwitch.getDataSourceType())){
            sourceType = DataSourceType.DATASOURCE_INSTANCE.MPOS_QRCODE.name();
            list = merchantProfitBatchFissionMapper.findWaitPassProfit(checkAudit);
        } else {
            sourceType = DataSourceType.DATASOURCE_INSTANCE.MPOS.name();
            list = merchantProfitBatchFissionMapper.findMposWaitPassProfit(checkAudit);
        }
        Long id;
        for (MerchantBean merchantBean : list) {
            log.info("MPOS_QRCODE审核通过调用 分润汇总表 请求参数：" + FastJson.toJson(merchantBean));
            Map returnMap = HttpClientUtils.postRequest(Constants.MERCHANT_WITHDRAW_URL, merchantBean, Map.class);
            log.info("MPOS_QRCODE审核通过调用 分润汇总表 返回结果：" + returnMap.toString());
            net.sf.json.JSONObject ob = net.sf.json.JSONObject.fromObject(returnMap);
            String rspCode = ob.get("rspCode") == null ? "" : ob.get("rspCode").toString();

            if (Constants.RERURNCODE.equals(rspCode)) {
                //修改分润记录状态
                merchantProfitBatchFissionMapper.updateMsgFlag(merchantBean.getBatchNo());
                id = merchantProfitBatchFissionMapper.findMerchantProfitByBatch(merchantBean.getBatchNo());
                idList.add(id);
            }
        }
        if (null != idList && idList.size() > 0) {
            new SendThread(idList, sourceType).start();
        }
    }

    public class SendThread extends Thread {
        private List<Long> merchantProfitIdList;

        private String sourceType;

        public SendThread(List<Long> merchantProfitIdList, String sourceType) {
            this.merchantProfitIdList = merchantProfitIdList;
            this.sourceType = sourceType;
        }

        @Override
        public void run() {
            for (Long merchantProfitId : merchantProfitIdList) {
                try {
                    sendMerProfit(merchantProfitId, sourceType);
                } catch (Exception e) {
                    log.info("裂变分润 消息推送 失败 merchantProfitId:" + merchantProfitId);
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 商户裂变分润消息推送
     *
     * @param merchantProfitId
     */
    private void sendMerProfit(Long merchantProfitId, String sourceType) throws Exception {
        Map map;
        try {
            if (DataSourceType.DATASOURCE_INSTANCE.MPOS_QRCODE.name().equals(sourceType)){
                DataSourceSwitch.setDataSourceType(DataSourceType.DATASOURCE_INSTANCE.MPOS_QRCODE.name());
                map = merchantProfitBatchFissionMapper.findPassMerchantProfitById(merchantProfitId);
            } else {
                DataSourceSwitch.setDataSourceType(DataSourceType.DATASOURCE_INSTANCE.MPOS.name());
                map = merchantProfitBatchFissionMapper.findMposPassMerchantProfitById(merchantProfitId);
            }
        } finally {
            DataSourceSwitch.clearDataSourceType();
        }
        Map<String, Object> paramMap = new HashMap<String, Object>();
        Map<String, Object> pushListMap = new HashMap<String, Object>();
        List pushList = new ArrayList();
        JSONObject json = new JSONObject();
        paramMap.put("infoid", map.get("INFOID") + "");

        pushListMap.put("smallMerchantNo", map.get("SMALLMERCHANTNO") + "");
        pushListMap.put("amount", map.get("PROFITAMOUNT") + "");
        pushListMap.put("tranTime", map.get("TRANTIME") + "");
        pushListMap.put("msgType", map.get("MSGTYPE") + "");
        pushListMap.put("customerType", map.get("CUSTOMERTYPE") + "");
        pushListMap.put("content", "您的裂变商户为您贡献" + map.get("PROFITAMOUNT") + "元的裂变分润，请点击查看");

        json.put("customerName", map.get("CUSTOMERNAME") + "");
        json.put("tranTime", map.get("TRANTIME") + "");
        json.put("amount", map.get("AMOUNT") + "");
        json.put("profitAmount", map.get("PROFITAMOUNT") + "");
        json.put("payWay", map.get("PAYWAY") + "");
        json.put("tranFlag", map.get("TRANFLAG") + "");
        json.put("dataSource", map.get("DATASOURCE") + "");
        json.put("orderId", map.get("ORDERID") + "");
        pushListMap.put("msgInfo", json.toString());
        pushList.add(pushListMap);
        paramMap.put("pushList", pushList);

        JSONObject obs = JSONObject.fromObject(paramMap);
        log.info("商户裂变分润消息推送 请求：" + Constants.SEND_PROFIT_MSG_URL + obs.toString());
        String resultMapString = HttpClientUtils.postRequestJsonStr(Constants.SEND_PROFIT_MSG_URL, obs.toString());
        log.info("商户裂变分润消息推送 返回值：" + resultMapString.toString());
    }
}
