package com.uns.inf.mpos.entry;

public class MerchantBean {

	private String customerNo;
	private String operAmount;
	private String operType;
	private String batchNo;
	private String orderId;
	private String shopperid;

	public String getShopperid() {
		return shopperid;
	}
	public void setShopperid(String shopperid) {
		this.shopperid = shopperid;
	}
	public String getCustomerNo() {
		return customerNo;
	}
	public void setCustomerNo(String customerNo) {
		this.customerNo = customerNo;
	}
	public String getOperAmount() {
		return operAmount;
	}
	public void setOperAmount(String operAmount) {
		this.operAmount = operAmount;
	}
	public String getOperType() {
		return operType;
	}
	public void setOperType(String operType) {
		this.operType = operType;
	}
	public String getBatchNo() {
		return batchNo;
	}
	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	 
	
}
