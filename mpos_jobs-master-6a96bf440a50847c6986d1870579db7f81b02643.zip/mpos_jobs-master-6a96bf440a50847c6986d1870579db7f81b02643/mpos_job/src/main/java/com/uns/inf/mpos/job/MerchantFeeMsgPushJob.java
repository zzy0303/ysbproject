package com.uns.inf.mpos.job;

import com.uns.inf.mpos.service.MerchantFeeMsgPushService;
import com.vip.saturn.job.SaturnJobExecutionContext;
import com.vip.saturn.job.SaturnJobReturn;
import com.vip.saturn.job.SaturnSpringJob;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/12/24
 * @Modifyed By:
 */
@Component
public class MerchantFeeMsgPushJob extends SaturnSpringJob<MerchantFeeMsgPushJob> {

    protected final Logger log = LoggerFactory.getLogger(getClass());

    @Autowired
    private MerchantFeeMsgPushService merchantFeeMsgPushService;

    @Override
    public SaturnJobReturn handleJavaJob(String jobName, Integer shardItem, String shardParam, SaturnJobExecutionContext shardingContext) throws InterruptedException {
        try {
            log.info("商户分润消息推送 跑批 开始执行==================");
            //扫码商户分润消息推送
            merchantFeeMsgPushService.mposQrcodeMsgPush();
            //刷卡分润消息推送
            merchantFeeMsgPushService.mposMsgPush();
            log.info("商户分润消息推送 跑批 结束执行==================");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new SaturnJobReturn("商户分润消息推送：MerchantFeeMsgPushJob 执行完成!");
    }
}
