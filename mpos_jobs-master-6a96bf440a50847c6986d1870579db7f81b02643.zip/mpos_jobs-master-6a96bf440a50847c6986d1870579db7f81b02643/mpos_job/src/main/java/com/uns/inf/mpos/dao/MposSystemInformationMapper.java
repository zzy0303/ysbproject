package com.uns.inf.mpos.dao;

public interface MposSystemInformationMapper {

	void updateinformationCrontab();

}