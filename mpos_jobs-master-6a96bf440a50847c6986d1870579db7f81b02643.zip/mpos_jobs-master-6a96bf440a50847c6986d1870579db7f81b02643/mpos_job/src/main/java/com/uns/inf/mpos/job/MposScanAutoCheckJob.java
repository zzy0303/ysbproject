package com.uns.inf.mpos.job;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.uns.inf.mpos.service.ActivateMerchantService;
import com.vip.saturn.job.SaturnJobExecutionContext;
import com.vip.saturn.job.SaturnJobReturn;
import com.vip.saturn.job.SaturnSpringJob;




/**
 * 自动扫描注册商户进行自动审核
 * @author Administrator
 *
 */
@Component
public class MposScanAutoCheckJob  extends SaturnSpringJob<MposScanAutoCheckJob> {
	

	protected final Logger log = LoggerFactory.getLogger(MposScanAutoCheckJob.class);

	@Autowired
	ActivateMerchantService activateMerchantService;

	@Override
	public SaturnJobReturn handleJavaJob(String jobName, Integer shardItem, String shardParam,
			SaturnJobExecutionContext shardingContext) throws InterruptedException {
		log.info("自动审核扫描定时任务：MposScanAutoCheckJob 开始执行==============");
		activateMerchantService.activateMerchant();
		log.info("自动审核扫描定时任务：MposScanAutoCheckJob 结束执行==============");
		return new SaturnJobReturn("自动审核扫描定时任务：MposScanAutoCheckJob 执行成功！");
	}
}


