package com.uns.inf.mpos.job;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.uns.inf.mpos.dao.MposSystemInformationMapper;
import com.vip.saturn.job.SaturnJobExecutionContext;
import com.vip.saturn.job.SaturnJobReturn;
import com.vip.saturn.job.SaturnSpringJob;

@Component
public class InfomationJob extends SaturnSpringJob<InfomationJob> {
	
	protected final Logger log = LoggerFactory.getLogger(getClass());
	
	@Autowired
	MposSystemInformationMapper mposSystemInformationMapper;

	/**
	 * u3_small:消息管理：检测消息有效期
	 */
	@Override
	public SaturnJobReturn handleJavaJob(String jobName, Integer shardItem, String shardParam,
			SaturnJobExecutionContext shardingContext) throws InterruptedException {
		log.info("消息管理定时任务开始执行============");
		mposSystemInformationMapper.updateinformationCrontab();
		log.info("消息管理定时任务执行结束============");
		return new SaturnJobReturn("消息管理:InfomationJob 执行完成!");
	}

}
