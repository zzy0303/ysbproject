package com.uns.inf.mpos.job;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.uns.inf.mpos.common.DataSourceType;
import com.uns.inf.mpos.dao.MposFenRunMapper;
import com.uns.inf.mpos.mutidatasource.DataSourceSwitch;
import com.vip.saturn.job.SaturnJobExecutionContext;
import com.vip.saturn.job.SaturnJobReturn;
import com.vip.saturn.job.SaturnSpringJob;
@Component
public class MposFenRunJob extends SaturnSpringJob<MposFenRunJob> {
	
	protected final Logger log = LoggerFactory.getLogger(getClass());
	
	@Autowired
	MposFenRunMapper mposFenRunMapper;

	/**
	 * mpos:mpos分润定时任务 跑批
	 */
	@Override
	public SaturnJobReturn handleJavaJob(String jobName, Integer shardItem, String shardParam,
			SaturnJobExecutionContext shardingContext) throws InterruptedException {
		log.info("mpos分润定时任务 跑批 开始执行==================");
		DataSourceSwitch.setDataSourceType(DataSourceType.DATASOURCE_INSTANCE.MPOS.name());
		mposFenRunMapper.mposFenRunJobWeek();
		DataSourceSwitch.clearDataSourceType();
		log.info("mpos分润定时任务 跑批 结束执行==================");
		return new SaturnJobReturn("mpos 分润定时任务：MposFenRunJob 执行完成!");
	}

}
