package com.uns.inf.mpos.dao;

import org.springframework.stereotype.Repository;

@Repository
public interface MposQrcodeFenRunMapper {


	void mposQrcodeFeeRunJob();

	void MposQRMerchantFenRunJob();

	void mposQrcodeMerchantFRJob();
	
	
}
