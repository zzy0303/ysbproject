package com.uns.inf.mpos.common;

public class DataSourceType {

	public static enum DATASOURCE_INSTANCE{
		U3_SMALL,
		MPOS_QRCODE,
		MPOS,
		INS
	}
}
