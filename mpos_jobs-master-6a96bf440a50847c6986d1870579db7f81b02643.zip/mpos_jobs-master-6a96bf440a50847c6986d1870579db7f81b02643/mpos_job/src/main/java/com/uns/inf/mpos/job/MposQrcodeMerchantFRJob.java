package com.uns.inf.mpos.job;

import com.uns.inf.mpos.common.DataSourceType;
import com.uns.inf.mpos.dao.MposQrcodeFenRunMapper;
import com.uns.inf.mpos.mutidatasource.DataSourceSwitch;
import com.vip.saturn.job.SaturnJobExecutionContext;
import com.vip.saturn.job.SaturnJobReturn;
import com.vip.saturn.job.SaturnSpringJob;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MposQrcodeMerchantFRJob extends SaturnSpringJob<MposQrcodeMerchantFRJob> {
    protected final Logger log = LoggerFactory.getLogger(getClass());

    @Autowired
    MposQrcodeFenRunMapper mposQrcodeFeeRunMapper;

    /**
     *mpos_qrcode 定时任务：商户服务商扫码分润跑批
     */
    @Override
    public SaturnJobReturn handleJavaJob(String jobName, Integer shardItem, String shardParam,
                                         SaturnJobExecutionContext shardingContext) throws InterruptedException {
        log.info("商户服务商扫码分润扣除退款交易定时任务 开始执行=============");
        DataSourceSwitch.setDataSourceType(DataSourceType.DATASOURCE_INSTANCE.MPOS_QRCODE.name());
        mposQrcodeFeeRunMapper.mposQrcodeMerchantFRJob();
        DataSourceSwitch.clearDataSourceType();
        log.info("商户服务商扫码分润扣除退款交易定时任务 结束执行=============");
        return new SaturnJobReturn("mpos 分润定时任务：MposMerchantFRJob 执行完成!");

    }
}
