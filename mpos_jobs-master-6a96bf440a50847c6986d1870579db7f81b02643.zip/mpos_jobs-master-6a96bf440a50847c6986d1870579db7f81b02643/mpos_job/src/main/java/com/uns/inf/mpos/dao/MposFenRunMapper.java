package com.uns.inf.mpos.dao;

import org.springframework.stereotype.Repository;

@Repository
public interface MposFenRunMapper {


	void mposFenRunJobWeek();

	void MposMerchantFenRunJob();

	void InsProfitRunJobWeek();
}
