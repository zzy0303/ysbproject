package com.uns.inf.mpos.dao;

import org.springframework.stereotype.Repository;
@Repository
public interface MposRemoteInvitationMapper {
   
	void updateData();
	
}