package com.uns.inf.mpos.job;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.uns.inf.mpos.common.DataSourceType;
import com.uns.inf.mpos.dao.MposQrcodeFenRunMapper;
import com.uns.inf.mpos.mutidatasource.DataSourceSwitch;
import com.vip.saturn.job.SaturnJobExecutionContext;
import com.vip.saturn.job.SaturnJobReturn;
import com.vip.saturn.job.SaturnSpringJob;
/**
 * 扫码商户裂变分润
 *
 */
@Component
public class MposQRMerchantFenRunJob extends SaturnSpringJob<MposQRMerchantFenRunJob> {

	protected final Logger log = LoggerFactory.getLogger(getClass());
	
	@Autowired
	MposQrcodeFenRunMapper mposQrcodeFeeRunMapper;
	
	/**
	 *mpos_qrcode 定时任务：扫码 商户裂变分润
	 */
	@Override
	public SaturnJobReturn handleJavaJob(String jobName, Integer shardItem, String shardParam,
			SaturnJobExecutionContext shardingContext) throws InterruptedException {
		log.info("扫码裂变分润定时任务 开始执行=============");
		DataSourceSwitch.setDataSourceType(DataSourceType.DATASOURCE_INSTANCE.MPOS_QRCODE.name());
		mposQrcodeFeeRunMapper.MposQRMerchantFenRunJob();
		DataSourceSwitch.clearDataSourceType();
		log.info("扫码裂变分润定时任务 结束执行=============");
		return new SaturnJobReturn("qrcode 裂变分润定时任务：MposQRMerchantFenRunJob 执行完成!");

	}

}
