package com.uns.inf.mpos.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.uns.inf.mpos.util.StringUtils;
import net.sf.json.JSONObject;

import oracle.jdbc.driver.Const;
import org.apache.commons.lang.RandomStringUtils;
import org.aspectj.apache.bcel.classfile.Constant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.inf.mpos.common.Constants;
import com.uns.inf.mpos.dao.B2cShopperbiTempMapper;
import com.uns.inf.mpos.entry.B2cShopperbiTemp;
import com.uns.inf.mpos.util.DateUtils;
import com.uns.inf.mpos.util.HttpClientUtils;
import com.uns.inf.mpos.util.JsonUtil;
import com.uns.inf.notify.api.Notify;
import com.uns.inf.notify.request.NotifyResult;
import com.uns.inf.notify.request.SmsNotifyRequest;

@Service
public class ActivateMerchantService {

	@Autowired
	B2cShopperbiTempMapper b2cShopperbiTempMapper;

	@Autowired
	Notify notify;
	
	@Autowired
	SendMessageService sendMessageService;

	protected final Logger log = LoggerFactory.getLogger(getClass());

	/**
	 * 激活商户和发送短信
	 * @return
	 * @throws Exception
	 */
	public void activateMerchant() {
		//查询待审核商户列表
		List<B2cShopperbiTemp> b2cShopperbiTempList = b2cShopperbiTempMapper.findCheckingShopperbi();

		//循环激活商户
		for(B2cShopperbiTemp b2cShopperbiTemp : b2cShopperbiTempList){
			//如果商户注册成功五分钟之内，则跳过自动审核
			long createDate = b2cShopperbiTemp.getCreated().getTime();
			long nowDate = new Date().getTime();
			long gap = nowDate - createDate;
			if(gap < Constants.NOT_AUTOCHECK_TIME){//五分钟（300000微秒）
				continue;
			}
			//激活商户
			try {
				
				if(null != b2cShopperbiTemp.getShopperidP() && 
						null == b2cShopperbiTemp.getIfactivated()){//如果商户没有激活
					//激活MPOS
					Map activateMposResultMap = activateMerchantPort(b2cShopperbiTemp);
					JSONObject ob= JSONObject.fromObject(activateMposResultMap);
					String rspCode=(String)ob.get("rspCode");
					String rspMsg=(String)ob.get("rspMsg");
					log.info("激活MPOS结果：" + rspMsg);

					//激活扫码
					Map activateQrPayResultMap = activateQrPayMerchantPort(b2cShopperbiTemp);
					JSONObject qrpay= JSONObject.fromObject(activateQrPayResultMap);
					String qrpayRspCode=(String)qrpay.get("rspCode");
					log.info("激活扫码结果：" + qrpayRspCode);
					//MPOS和扫码全部成功
					if (!Constants.RESPONSE_CODE.equals(rspCode) || !Constants.RESPONSE_CODE.equals(qrpayRspCode)) {
						log.info("自动审核失败！");
						return;
					}
					b2cShopperbiTemp.setTransact(Constants.TYPE_2);
				}
				//修改商户审核状态
				b2cShopperbiTemp.setCheckstatus(Constants.TYPE_2);//审核通过
				b2cShopperbiTemp.setRecheckdate(new Date());//审核时间
				b2cShopperbiTemp.setIfvalid(Short.valueOf(Constants.CON_YES));//初审通过（老商户）
				b2cShopperbiTemp.setIsformal(Short.valueOf(Constants.TYPE_1));//正式商户
				//如果没有贷记卡信息，OCR贷记卡状态设置为3（未提交通过）
				if (StringUtils.isEmpty(b2cShopperbiTemp.getCreditBankNo())) {
					b2cShopperbiTemp.setNotPassStep(Constants.NOT_PASS_STEP_ALL_PASS_NO_CREDIT_CARD);
				} else {
					b2cShopperbiTemp.setNotPassStep(Constants.NOT_PASS_STEP_ALL_PASS);
				}
				b2cShopperbiTemp.setNotPassReason(null);
				b2cShopperbiTemp.setIfactivated(Constants.CON_YES);
				b2cShopperbiTemp.setIfactivadate(new Date());
				b2cShopperbiTempMapper.updateByAutoScanInfo(b2cShopperbiTemp);
				b2cShopperbiTempMapper.updateFormalByAutoScanInfo(b2cShopperbiTemp);
				sendMessageService.sendMessageOCR(b2cShopperbiTemp);
			} catch (Exception e) {
				e.printStackTrace();
				log.info("自动审核失败！");
			}
		}
	}

	/**
	 * 激活MPOS
	 * @throws Exception 
	 */
	private Map activateMerchantPort(B2cShopperbiTemp b2cShopperbiTemp) throws Exception {
		HashMap params=new HashMap();

		Date dates = new Date();
		String mradom = RandomStringUtils.randomNumeric(6);
		String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbiTemp.getB2cShopperbiId();
		String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");

		params.put("orderId", orderId);	
		params.put("userId", b2cShopperbiTemp.getYsbNo());
		params.put("activeStatus", Constants.TYPE_2);//已激活

		JSONObject obs = JSONObject.fromObject(params);
		String request = "activeStatus=" + Constants.TYPE_2 + "&orderId="+orderId+"&userId="+ b2cShopperbiTemp.getYsbNo() ;
		log.info("请求激活银生宝账号请求参数："+request);
		log.info("请求激活银生宝账号："+DynamicConfigLoader.getByEnv("update_user_status_url")+request);
		String result = HttpClientUtils.REpostRequestStrNormal(DynamicConfigLoader.getByEnv("update_user_status_url"), request);	  
		Map resultMap = JsonUtil.jsonStrToMap(result);

		return resultMap;

	}


	/**激活扫码
	 * @param b2cShopperbi
	 * @return
	 * @throws Exception 
	 */
	private Map activateQrPayMerchantPort(B2cShopperbiTemp b2cShopperbi) throws Exception {

		HashMap params=new HashMap();

		Date dates = new Date();
		String mradom = RandomStringUtils.randomNumeric(6);
		String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbi.getB2cShopperbiId();
		String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");

		params.put("orderId", orderId);	    
		params.put("userId", b2cShopperbi.getQrPayNo());
		params.put("activeStatus", Constants.TYPE_2);//已激活

		JSONObject obs = JSONObject.fromObject(params);
		String request = "activeStatus=" + Constants.TYPE_2 + "&orderId="+orderId+"&userId="+ b2cShopperbi.getQrPayNo();
		log.info("请求激活扫码支付账号："+DynamicConfigLoader.getByEnv("update_qrpay_user_status_url")+request.toString());
		String result = HttpClientUtils.REpostRequestStrNormal(DynamicConfigLoader.getByEnv("update_qrpay_user_status_url"), request);

		Map resultMap = JsonUtil.jsonStrToMap(result);
		log.info("请求激活扫码支付账号返回码："+resultMap.toString());
		return resultMap;
	}


	/**
	 * 发送短信
	 */
	public void sendSms(B2cShopperbiTemp b2cShopperbiTemp){
		SmsNotifyRequest smsNotifyRequest = new SmsNotifyRequest();
		//发送参数
		Map<String, String> data = new HashMap<String, String>();
		//获取商户的姓名
		String merchantName = b2cShopperbiTemp.getName();
		data.put("merchantName", merchantName);
		//应用名称
		smsNotifyRequest.setAppid("mpos-job");
		//业务序列号
		smsNotifyRequest.setSerialNumber("");
		//模板id
		smsNotifyRequest.setTemplateId(30000011L);
		smsNotifyRequest.addMobile(b2cShopperbiTemp.getStel());
		smsNotifyRequest.setData(data);
		log.info("调用短信发送接口参数：" + data);
		try {
			NotifyResult notifyResult = notify.sendSms(smsNotifyRequest);
			if(null == notifyResult || !"success".equals(notifyResult.getState()+"")){
				log.error("调用发送短信接口出错" + b2cShopperbiTemp.getStel());
			} else {
				log.info(com.alibaba.fastjson.JSONObject.toJSONString(notifyResult));
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}
