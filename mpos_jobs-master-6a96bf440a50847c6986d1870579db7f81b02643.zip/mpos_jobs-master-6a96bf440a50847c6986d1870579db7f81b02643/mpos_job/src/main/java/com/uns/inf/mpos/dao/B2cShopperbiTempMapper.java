package com.uns.inf.mpos.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.inf.mpos.entry.B2cShopperbiTemp;

@Repository
public interface B2cShopperbiTempMapper {

    //查询注册后待自动审核的商户
    List<B2cShopperbiTemp> findCheckingShopperbi();
    
	void updateByAutoScanInfo(B2cShopperbiTemp b2cShopperbiTemp);
	
	void updateFormalByAutoScanInfo(B2cShopperbiTemp b2cShopperbiTemp);
}