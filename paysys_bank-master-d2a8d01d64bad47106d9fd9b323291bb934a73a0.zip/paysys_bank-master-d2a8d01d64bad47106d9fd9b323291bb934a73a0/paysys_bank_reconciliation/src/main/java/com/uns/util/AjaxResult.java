package com.uns.util;

public class AjaxResult {

    public static final String STATUS_OK = "0000";
    public static final String STATUS_ERROR = "ERROR";


    public AjaxResult(Object data) {
        this.data = data;
        this.status = STATUS_OK;
    }

    public AjaxResult(String status, String message) {
        this.status = status;
        this.message = message;
    }

    public AjaxResult(ErrorCodeEnum errorCodeEnum) {
        this.status = errorCodeEnum.getCode();
        this.message = errorCodeEnum.getText();
    }

    public AjaxResult() {
        this.status = STATUS_OK;
    }

    /**
     * 返回状态
     */
    private String status;
    /**
     * 异常提示
     */
    private String message;
    /**
     * 业务数据
     */
    private Object data;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public <T> T getData() {
        return (T) data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
