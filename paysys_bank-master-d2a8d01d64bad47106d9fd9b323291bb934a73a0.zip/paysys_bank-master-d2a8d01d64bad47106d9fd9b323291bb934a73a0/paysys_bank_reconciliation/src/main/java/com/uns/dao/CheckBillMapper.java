package com.uns.dao;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.apache.zookeeper.Op;
import org.springframework.stereotype.Repository;

import com.uns.model.CheckBill;
import com.uns.model.CheckBillTransDetail;
import com.uns.model.FileUploadRecord;
import com.uns.web.form.CheckBillForm;

@Repository
public interface CheckBillMapper {

	int deleteByPrimaryKey(BigDecimal id);

	int insert(CheckBill record);

	int insertSelective(CheckBill record);

	CheckBill selectByPrimaryKey(long id);

	CheckBill selectByChannel(Map map);

	List<CheckBill> selectByChannelBatch(Map map);

	int updateByPrimaryKeySelective(CheckBill record);

	int updateByPrimaryKey(CheckBill record);

	String getBankIdByChannel(String channel);

	Double getSumAmount(String channel);

	Double getSumAmount2(String channel);

	List<CheckBill> getCheckList(CheckBillForm checkBillForm);

	void updateCheckStatus(Map map);

	void updateEpccCheckStatus(Map map);

	List<Map<String, Object>> getLocalTrans(Integer id);

	CheckBill getCheckBillByChannelCheckDate(FileUploadRecord record);

	CheckBill getCheckBillByBatch(FileUploadRecord record);

	CheckBill getCheckBillByNullBatch(FileUploadRecord record);

	void updateCheckStatusByRecordId(Map<String, String> map);

	void updateNetsUnionCheckStatus(CheckBillForm checkBillForm);

	CheckBill getCheckBillById(String transId);
	

	CheckBill getCheckBillByBankTransId(String applyId);

	CheckBill getLastCheckBill(Integer id);

	List<Map<String, Object>> getLocalAuthTrans(Map map);
	List<Map<String, Object>> getLocalAllAuthTrans(Map map);
	
	List<Map<String, Object>> getlocalNewDkTrans(Map map);
	
	List<Map<String, Object>> getcmbctrans(Map<String, Object> pareMap);
	
	List<Map<String, Object>> getcmbcKjtrans(Map<String, Object> pareMap);

	List<Map<String, Object>> getAllB2c(Map map);

	List<Map<String, Object>> getUnionpayTrans(Map map);
	
	List<Map<String, Object>> getUnionpayB2BTrans(Map map);
	

	List<Map<String, Object>> getcmbxmctrans(Integer id);

	List<Map<String, Object>> getwstrans(Integer id);

	List<Map<String, Object>> getUnionPaytrans(Integer id);

	List<Map<String, Object>> getCmbcXmTrans(Map map);
	
	List<Map<String, Object>> getUnionpayB2c(Map map);
	
	List<Map<String, Object>> getCebKjTrans(Map map);

	List<Map<String, Object>> getKjTrans(Map map);

	List<Map<String, Object>> getCncbTrans(Map map);

	List<Map<String, Object>> getBoshTrans(Map map);

	List<Map<String, Object>> getUnionpayWlTrans(Map map);

	List<Map<String, Object>> getDkTtrans(Map map);

	List<Map<String, Object>> getLocalTransNew(Map map);

	List<Map<String, Object>> getUnionpayTransNew(Map map);

	List<Map<String, Object>> getLocalAuthTransNew(Map map);

	List<Map<String, Object>> getCmbcXmTransMapNew(Map map);

	List<Map<String, Object>> getTransMapNew(Map<String, Object> map);

	List<Map<String, Object>> getOutTransNew(Map<String, Object> map);

    List<Map<String,Object>> getSmTrans(Map<String, Object> pareMap);

    List<Map<String,Object>> getCMBCSMTrans(Map<String, Object> pareMap);

    List<Map<String,Object>> getNyTrans(Map<String, Object> pareMap);

    List<Map<String,Object>> getUpopSmTrans(Map<String, Object> pareMap);
    
    List<Map<String,Object>> getCmbSmTrans(Map<String, Object> pareMap);//招商扫码获取本地交易
    
    List<Map<String,Object>> getSpecialKjTrans(Map<String, Object> pareMap);
    
    
    List<Map<String,Object>> getB2BTrans(Map<String, Object> pareMap);

    void updateRecoder(Map<String, Object> map);

    void updateNetsUnionRecoder(CheckBillForm checkBillForm);

    CheckBill selectByMap(Map map);

    List<Map<String,Object>> getAllDkTtrans(Map<String, Object> pareMap);

	CheckBill selectByChannelDate(Map map);

	CheckBill selectByChannelDateBatch(Map map);

    void updateBatch(@Param("checkBills") List<CheckBill> checkBills);

    CheckBill getBillByBankTransId(String applyId);

	CheckBill getNetsUnionCheckBillByApplyNo(String applyId);

    List<Map<String, Object>> getBocKjTrans(Map<String, Object> pareMap); //中国银行快捷获取本地交易

    List<Map<String, Object>> getCibSmTrans(Map<String, Object> pareMap);

	List<Map<String, Object>> getYinlianKjTrans(Map<String, Object> pareMap); //银联快捷交易

	List<Map<String, Object>> getPsbcDKjTrans(Map<String, Object> pareMap); //邮储快捷交易


    String getBillType(Integer id); //获取对账类型

    List<Map<String, Object>> getUnionpayXmNewDf(Map<String, Object> pareMap);

    List<Map<String, Object>> getUnionpayXmTrans(Map<String, Object> pareMap);

	List<Map<String, Object>> getOutNewDf(Map<String, Object> pareMap);//出金新代付交易

	List<Map<String, Object>> getOutTrans(Map<String, Object> pareMap); //出金银生宝交易

	Collection<? extends Map<String, Object>> getHfqdTransYsb(Map<String, Object> pareMap);

	List<Map<String, Object>> getHfqdTrans(Map<String, Object> pareMap);

	List<Map<String, Object>> getPinganKjTrans(Map<String, Object> pareMap); //pingan_kj获取本地交易


	List<Map<String, Object>> getNetsUnionTrans(Map<String, Object> pareMap); //网联交易

	CheckBill getNetsUnionToCheck(Map map);

	CheckBill getCheckBillByBatchLastDate(Map<String, Object> paramMap);

	List<String> getAllBatch(String checkdate);

	CheckBill getNullCheckBill(String checkdate);

	void delCheckBillById(Long id);

	CheckBill getCheckBillByFileBatch(CheckBillForm checkBillForm);

	List<Map<String, Object>> getUnionpayXmNewTX(Map<String, Object> pareMap);

	CheckBill searchByCheckBillId(Map<String, Object> pareMap);

	String searchActionType(String actionSeq);

	String searchAccountName(String debitSeq);

	List<Map<String, Object>> getChinapayTrans(Map map);

	Map<String, Object> searchTransDetails(Map<String, Object> map2);

	Map<String, Object> searchApplyUpadjust(Map<String, Object> map2);

	List<Map<String, Object>> getNewTXTrans(Map<String, Object> pareMap);//新提现交易

	List<Map<String, Object>> getDkTransAll(Map map);

	List<Map<String, Object>> getUnionpayWgTrans(Map pareMap);

	List<Map<String,Object>> getUnionpayXmDpTrans(Map pareMap);

	List<Map<String,Object>> getUnionpayAtSmTrans(Map<String, Object> pareMap);//银联AT扫码获取本地交易
}