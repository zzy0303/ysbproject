package com.uns.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.AuditOperation;

@Repository
public interface AuditOperationMapper {

	int deleteByPrimaryKey(BigDecimal id);

	int insert(AuditOperation record);

	int insertSelective(AuditOperation record);

	AuditOperation selectByPrimaryKey(BigDecimal id);

	int updateByPrimaryKeySelective(AuditOperation record);

	int updateByPrimaryKey(AuditOperation record);

	AuditOperation getAuditOperation(Map<String, Object> map);

	List<AuditOperation> getAllAuditOperation(Map<String, Object> map);

	int deleteByAuditOperandId(Map<String, List<Long>> map);
}