package com.uns.web.controller;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uns.model.TransDetail;
import com.uns.util.AcmsMapUtils;
import com.uns.util.PoiUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.model.CheckBillTransDetail;
import com.uns.service.DealTransService;
import com.uns.util.StringUtils;
import com.uns.web.form.AdjustAuditForm;
import com.uns.web.form.TransDetailForm;
import com.uns.web.form.TransRefForm;

@Controller
@RequestMapping(value = "/alreadyDealTransDetail.htm")
public class AlreadyDealTransDetailControl {
	@Autowired
	private DealTransService dealTrandService;

	@Autowired
	private AcmsMapUtils acmsMapUtils;

	/**
	 * 挂起申请明细
	 * 
	 * @param request
	 * @param adjustAuditForm
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=toAlreadyDealList")
	@FormToken(save = true)
	public String toAlreadyDealList(HttpServletRequest request, TransDetailForm transDetailForm)
			throws BusinessException {
	    if(null==transDetailForm.getStartDate()){transDetailForm.setStartDate(StringUtils.getBeforDate());}
	    if(null==transDetailForm.getEndDate()){transDetailForm.setEndDate(StringUtils.getBeforDate());}
	    transDetailForm.setBillType(Constants.CHECK_BILL_0);
		List<Object>  checkBillTransDetailList = dealTrandService.getDealTransDetail(transDetailForm);
		request.setAttribute("list", checkBillTransDetailList);
		//动态获取参数
		Map<String,String> dynamicParam = acmsMapUtils.getAcmsMap();
		// 获取直连间连银行数据
		String[] directChannel = dynamicParam.get("CHECK_BILL_CHANNEL_DIRECT").split(",");
		String[] inDirectChannel = dynamicParam.get("CHECK_BILL_CHANNEL_INDIRECT").split(",");
		String[] pattern =  dynamicParam.get("CHECK_BILL_CHANNEL_PATTERN").split(",");
		String[] inParrert = dynamicParam.get("CHECK_BILL_CHANNEL_INPATTERN").split(",");
		request.setAttribute("transDetailForm", transDetailForm);
		request.setAttribute("directChannel", directChannel);
		request.setAttribute("inDirectChannel", inDirectChannel);
		request.setAttribute("pattern", pattern);
		request.setAttribute("inPattern", inParrert);
		return "checkbill/dealTransList";

	}

	/**
	 * 下载明细
	 *
	 * @param request
	 * @param transDetailForm
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=toExport")
	@FormToken(save = true)
	public void toExport(HttpServletRequest request, HttpServletResponse response, TransDetailForm transDetailForm)
			throws BusinessException {
		// 获取下载类容
		List<Object>  checkBillTransDetailList = dealTrandService.getDealTransDetail(transDetailForm);
		try {
			OutputStream out = response.getOutputStream();
			response.reset();
			response.setHeader("content-disposition",
					"attachment;filename=" + new String((Constants.hang_title).getBytes("gb2312"), "ISO8859-1") + ".xls");
			response.setContentType("APPLICATION/msexcel");
			PoiUtils.exportHangExcel(Constants.hang_title, Constants.hang_colnum, checkBillTransDetailList, out, Constants.DEFAULT_DATE_FORMAT);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	/**
	 * 下载明细
	 *
	 * @param request
	 * @param transDetailForm
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=toNetsUnionExport")
	@FormToken(save = true)
	public void toNetsUnionExport(HttpServletRequest request, HttpServletResponse response, TransDetailForm transDetailForm)
			throws BusinessException {
		// 获取下载类容
		List<Object>  checkBillTransDetailList = dealTrandService.getNetsUnionDealTransDetailExport(transDetailForm);
		try {
			OutputStream out = response.getOutputStream();
			response.reset();
			response.setHeader("content-disposition",
					"attachment;filename=" + new String((Constants.hang_title).getBytes("gb2312"), "ISO8859-1") + ".xls");
			response.setContentType("APPLICATION/msexcel");
			PoiUtils.exportNetsUnionHangExcel(Constants.hang_title, Constants.hang_colnum, checkBillTransDetailList, out, Constants.DEFAULT_DATE_FORMAT);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	/**
	 * 调整申请明细
	 * 
	 * @param request
	 * @param transDetailForm
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=toAlreadyApplyList")
	@FormToken(save = true)
	public String toAlreadyApplyList(HttpServletRequest request, TransDetailForm transDetailForm)
			throws BusinessException {
	    if(null==transDetailForm.getStartDate()){transDetailForm.setStartDate(StringUtils.getBeforDate());}
	    if(null==transDetailForm.getEndDate()){transDetailForm.setEndDate(StringUtils.getBeforDate());}
		List<Object> adjustApplyList = dealTrandService.getDealApplyList(transDetailForm);
		request.setAttribute("list", adjustApplyList);
		//动态获取参数
		Map<String,String> dynamicParam = acmsMapUtils.getAcmsMap();
		// 获取直连间连银行数据
		String[] directChannel = dynamicParam.get("CHECK_BILL_CHANNEL_DIRECT").split(",");
		String[] inDirectChannel = dynamicParam.get("CHECK_BILL_CHANNEL_INDIRECT").split(",");
		String[] pattern =  dynamicParam.get("CHECK_BILL_CHANNEL_PATTERN").split(",");
		String[] inParrert = dynamicParam.get("CHECK_BILL_CHANNEL_INPATTERN").split(",");
		request.setAttribute("directChannel", directChannel);
		request.setAttribute("inDirectChannel", inDirectChannel);
		request.setAttribute("pattern", pattern);
		request.setAttribute("inPattern", inParrert);
		return "checkbill/alreadyApplyList";
	}

	/**
	 * 出金挂起申请明细
	 *
	 * @param request
	 * @param adjustAuditForm
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=toOutAlreadyDealList")
	@FormToken(save = true)
	public String toOutAlreadyDealList(HttpServletRequest request, TransDetailForm transDetailForm)
			throws BusinessException {
	    if(null==transDetailForm.getStartDate()){transDetailForm.setStartDate(StringUtils.getBeforDate());}
	    if(null==transDetailForm.getEndDate()){transDetailForm.setEndDate(StringUtils.getBeforDate());}
	    String[] outChannel = Constants.OUT_CHECK_BILL_CHANNEL.split(",");
	    //查询出金的挂起交易
	    List<Object>  checkBillOutTransDetailList = dealTrandService.getOutDealTransDetail(transDetailForm);
		// 获取出金通道信息传值到页面
		request.setAttribute("outChannel", outChannel);
		request.setAttribute("list", checkBillOutTransDetailList);
		request.setAttribute("transDetailForm", transDetailForm);
		return "outcheckbill/dealTransList";

	}

	/**
	 * 网联挂起申请明细
	 *
	 * @param request
	 * @param adjustAuditForm
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=toNetsUnionAlreadyDealList")
	@FormToken(save = true)
	public String toNetsUnionAlreadyDealList(HttpServletRequest request, TransDetailForm transDetailForm)
			throws BusinessException {
		if(null==transDetailForm.getStartDate()){transDetailForm.setStartDate(StringUtils.getBeforDate());}
		if(null==transDetailForm.getEndDate()){transDetailForm.setEndDate(StringUtils.getBeforDate());}
		String[] netsUnionChannel = Constants.NETS_UNION_CHECK_BILL_CHANNEL.split(",");
		List<Map>  checkBillNetsUnionTransDetailList = dealTrandService.getNetsUnionDealTransDetail(transDetailForm);
		request.setAttribute("netsUnionChannel", netsUnionChannel);
		request.setAttribute("list", checkBillNetsUnionTransDetailList);
		request.setAttribute("transDetailForm", transDetailForm);
		return "netsUnionCheckbill/dealTransList";

	}
	
	/**
	 * 网联交易查询
	 *
	 * @param request
	 * @param adjustAuditForm
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=toSearchCheckDetilList")
	@FormToken(save = true)
	public String toSearchCheckDetil(HttpServletRequest request, TransRefForm transRefForm)
			throws BusinessException {
		Calendar calendar = Calendar.getInstance();//此时打印它获取的是系统当前时间
        calendar.add(Calendar.DATE, -7);    //得到前7天 
        String  yestedayDate= new SimpleDateFormat("yyyy-MM-dd").format(calendar.getTime());
		if(null==transRefForm.getStartDate()){transRefForm.setStartDate(yestedayDate);}
		if(null==transRefForm.getEndDate()){transRefForm.setEndDate(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));}
		List<Map>  searchNetsUnionTransList = dealTrandService.getNetsUnionTransList(transRefForm);
		request.setAttribute("list", searchNetsUnionTransList);
		request.setAttribute("transRefForm", transRefForm);
		return "netsUnionCheckbill/netsUnionTransList";

	}
	
	/**
	 * 导出网联交易数据
	 * @param request
	 * @param response
	 * @param transDetailForm
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=toExportTransDate")
	@FormToken(save = true)
	public void toExportTransDate(HttpServletRequest request, HttpServletResponse response, TransRefForm transRefForm)
			throws BusinessException {
		// 获取下载类容
		List<Object>  netsUnionTransDateList = dealTrandService.getNetsUnionTransDateExport(transRefForm);
		try {
			OutputStream out = response.getOutputStream();
			response.reset();
			response.setHeader("content-disposition",
					"attachment;filename=" + new String((Constants.netsUnion_title).getBytes("gb2312"), "ISO8859-1") + ".xls");
			response.setContentType("APPLICATION/msexcel");
			PoiUtils.exportNetsUnionTransDateExcel(Constants.netsUnion_title, Constants.netsUnion_colnum, netsUnionTransDateList, out, Constants.DEFAULT_DATE_FORMAT);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}


}
