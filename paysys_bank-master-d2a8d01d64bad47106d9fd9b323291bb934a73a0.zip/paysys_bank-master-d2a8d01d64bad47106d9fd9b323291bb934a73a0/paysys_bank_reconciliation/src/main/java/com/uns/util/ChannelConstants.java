package com.uns.util;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/11/3
 * @Modifyed By:
 */
public class ChannelConstants {
    //直连
    public static final String CHANNEL_CMBC_XM_B2C = "cmbc_xm_b2c";
    public static final String CHANNEL_BOSH_DK = "bosh_dk";
    public static final String CHANNEL_CMBC_CD = "cmbc_cd";
    public static final String CHANNEL_ICBC_B2C = "icbc_b2c";
    public static final String CHANNEL_BOSH_B2C = "bosh_b2c";
    public static final String CHANNEL_PIINGAN_B2C = "pingan_b2c";
    public static final String CHANNEL_GDB_B2C = "gdb_b2c";
    public static final String CHANNEL_ABC_B2C = "abc_b2c";
    public static final String CHANNEL_CMB_B2C = "cmb_b2c";
    public static final String CHANNEL_CCB_B2C = "ccb_b2c";
    public static final String CHANNEL_PSBC_B2C = "psbc_b2c";
    public static final String CHANNEL_SPDB_B2C = "spdb_b2c";
    public static final String CHANNEL_HXB_B2C = "hxb_b2c";
    public static final String CHANNEL_CNCB_B2C = "cncb_b2c";
    public static final String CHANNEL_CIB_B2C = "cib_b2c";
    public static final String CHANNEL_CMBC_B2C = "cmbc_b2c";
    public static final String CHANNEL_CEB_B2C = "ceb_b2c";
    public static final String CHANNEL_BOC_B2C = "boc_b2c";
    public static final String CHANNEL_HXB_KJ = "hxb_kj";
    public static final String CHANNEL_SPDB_KJ = "spdb_kj";
    public static final String CHANNEL_CEB_KJ = "ceb_kj";
    public static final String CHANNEL_BOSH_KJ = "bosh_kj";
    public static final String CHANNEL_CMBC_XM_KJ = "cmbc_xm_kj";
    public static final String CHANNEL_CMBC_XM_SM = "cmbc_xm_sm";
    public static final String CHANNEL_SPDB_DK = "spdb_dk";
    public static final String CHANNEL_PINGAN_DK = "pingan_dk";
    public static final String CHANNEL_CCB_KJ = "ccb_kj";
    public static final String CHANNEL_ICBC_B2B = "icbc_b2b";
    public static final String CHANNEL_CMB_SM = "cmb_sm";
    public static final String CHANNEL_BOC_KJ = "boc_kj";
    public static final String CHANNEL_CIB_SM = "cib_sm";
    public static final String CHANNEL_CEB_B2B = "ceb_b2b";
    public static final String CHANNEL_YINLIAN_KJ = "yinlian_kj";//银联无卡快捷
    public static final String CHANNEL_PSBC_D_KJ = "psbc_d_kj";//邮储快捷
    public static final String CHANNEL_YILIAN_DK = "yilian_dk";
    public static final String CHANNEL_UNIONPAY_BH = "unionpay_bh";
    public static final String CHANNEL_UNIONPAY_BHT0 = "unionpay_bht0";

    //间连
    public static final String CHANNEL_UNIONPAY_TD = "unionpay_td";
    public static final String CHANNEL_UNIONPAY_TD2 = "unionpay_td2";
    public static final String CHANNEL_UNIONPAY_WL = "unionpay_wl";
    public static final String CHANNEL_EGB = "egb";
    public static final String CHANNEL_EGB_PROB = "egb_prob";
    public static final String CHANNEL_EGB_PROC = "egb_proc";
    public static final String CHANNEL_YS = "ys";
    public static final String CHANNEL_WS = "ws";
    public static final String CHANNEL_CMBC_XM_DK = "cmbc_xm_dk";
    public static final String CHANNEL_UNIONPAY = "unionpay";
    public static final String CHANNEL_BESTPAY = "bestpay";
    public static final String CHANNEL_YILIAN_KJ = "yilian_kj";
    public static final String CHANNEL_UPOP_B2C = "upop_b2c";
    public static final String CHANNEL_UPOP_D_DC_B2C = "upop_d_dc_b2c";
    public static final String CHANNEL_UNIONPAY_CQ = "unionpay_cq";
    public static final String CHANNEL_UNIONPAY_XM = "unionpay_xm";
    public static final String CHANNEL_NY = "ny";
    public static final String CHANNEL_UMPAY = "umpay";
    public static final String CHANNEL_UPOP_SM = "upop_sm";
    public static final String CHANNEL_UNIONPAY_XM_DK = "unionpay_xm_dk";
    public static final String CHANNEL_BFBPAY_DK = "bfbpay_dk";
    public static final String CHANNEL_EPAY_DK = "epay_dk";
    public static final String CHANNEL_YIFUBAO = "yifubao";
	public static final String CHANNEL_PINGAN_XM_DK ="pingan_xm_dk";
    public static final String CHANNEL_SPDB_CROSSBANK_DK = "spdb_crossBank_dk";
    public static final String CHANNEL_CHINAPAY = "chinapay";
    public static final String CHANNEL_UNIONPAY_AT_SM = "unionpay_at_sm";

    //出金
    public static final String CHANNEL_HFQD = "hfqd";
    public static final String CHANNEL_PINGAN_KJ = "pingan_kj";//平安快捷
    public static final String CHANNEL_OUT_UNIONPAY_XM = "out_unionpay_xm";
    public static final String CHANNEL_UNIONPAY_XM_DP = "unionpay_xm_dp";
    public static final String CHANNEL_CCB_B2B = "ccb_b2b";

    public static final String CHANNEL_TJ_UNIONPAY = "unionpay_tj_t1";
    public static final String CHANNEL_TJ_UNIONPAY_T0 = "unionpay_tj_t0";
    public static final String CHANNEL_YLZ_DO = "ylz";


    //出金
    public static final String CHANNEL_BOSH = "bosh";


    //网联
    public static final String CHANNEL_NETS_UNION = "epcc";

    public static final String CHANNEL_UNIONPAY_WG = "unionpay_wg";
}
