package com.uns.dao;

import com.uns.model.EpccAuthpayTransRef;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface EpccAuthpayTransRefMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(EpccAuthpayTransRef record);

    int insertSelective(EpccAuthpayTransRef record);

    EpccAuthpayTransRef selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(EpccAuthpayTransRef record);

    int updateByPrimaryKey(EpccAuthpayTransRef record);

    List<EpccAuthpayTransRef> getNetsUnionCheckTrans(Map paramMap);

    String getNetsUnionCheckTransCount(String checkdate);

}