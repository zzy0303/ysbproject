package com.uns.channel;

import com.uns.common.Constants;
import com.uns.dao.CheckBillMapper;
import com.uns.model.BankTrans;
import com.uns.service.CheckBillService;
import com.uns.util.AnalyExcel;
import com.uns.util.ExcelUtils;
import com.uns.web.form.CheckBillForm;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/11/3
 * @Modifyed By:
 */
@Component
public class ChannelHandleUnionpayAtSm extends ChannelHandleDefault implements ChannelHandleInterface {

    private Map<String, Object> pareMap = new HashMap<String, Object>();
    @Override
    public List<BankTrans> loadDate(InputStream inputStream, CheckBillForm checkBillForm) throws Exception {
        return ExcelUtils.loadUnionpayAtSmCsv(inputStream, checkBillForm);
    }


    @Override
    public Map<String, Object> getLocalAmount(String channel, String checkDate) {
        return null;
    }

    @Override
    public List<Map<String, Object>> getLocalTrans(Integer id) throws Exception {
        pareMap.put("id", id);
        pareMap.put("channel", Constants.UPLOAD_UNIONPAY_AT_SM);
        pareMap.put("actionType", Constants.UPLOAD_UNIONPAY_AT_SM_ACTIONTYPE);
        return checkBillMapper.getUnionpayAtSmTrans(pareMap);
    }

    @Override
    public List<String> getChannelList() throws Exception {
        return null;
    }
}
