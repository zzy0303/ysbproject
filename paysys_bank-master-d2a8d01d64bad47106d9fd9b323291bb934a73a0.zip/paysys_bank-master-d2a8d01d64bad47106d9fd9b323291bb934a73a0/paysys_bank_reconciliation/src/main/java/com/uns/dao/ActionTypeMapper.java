package com.uns.dao;


import com.uns.model.ActionType;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface ActionTypeMapper {

    int deleteByPrimaryKey(BigDecimal id);

    int insert(ActionType record);

    int insertSelective(ActionType record);

    ActionType selectByPrimaryKey(BigDecimal id);

    int updateByPrimaryKeySelective(ActionType record);

    int updateByPrimaryKey(ActionType record);

    List<ActionType> selectAllAction();
}