package com.uns.channel;

import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.uns.common.Constants;
import com.uns.model.BankTrans;
import com.uns.util.AnalyExcel;
import com.uns.web.form.CheckBillForm;

/**
 * 通道已关停
 */
public class ChannelHandleHfqd extends ChannelHandleDefault implements ChannelHandleInterface {
    @Override
    public List<BankTrans> loadDate(InputStream inputStream, CheckBillForm checkBillForm) throws Exception {
        return AnalyExcel.loadAllShell(inputStream, checkBillForm, Constants.UPLOAD_HFQD_SHELL);
    }

    @Override
    public List<Map<String, Object>> getLocalTrans(Integer id) throws Exception {
        pareMap.put("id", id);
        pareMap.put("channel", Constants.UPLOAD_HFQD_CHANNEL);
        //获取出金新代付交易
        localTrans = checkBillMapper.getHfqdTrans(pareMap);
        //获取银生宝交易
        localTrans.addAll(checkBillMapper.getHfqdTransYsb(pareMap));
        return localTrans;
    }

    @Override
    public Map<String, Object> getLocalAmount(String channel, String checkDate) {
        Map<String, Object> map = new HashMap<>();
        map.put("channel", channel);
        map.put("dealDate", checkDate);
        Map<String, Object> recordMap = checkBillAmountMapper.getOutHfqdNewDfAmount(map);
        Map<String, Object> newDfMap = checkBillAmountMapper.getOutHfqdAmount(map);
        recordMap.put("AMOUNT", Double.parseDouble(recordMap.get("AMOUNT").toString())
                + Double.parseDouble(newDfMap.get("AMOUNT").toString()));
        return recordMap;
    }

    @Override
    public List<String> getChannelList() throws Exception {
        return null;
    }
}
