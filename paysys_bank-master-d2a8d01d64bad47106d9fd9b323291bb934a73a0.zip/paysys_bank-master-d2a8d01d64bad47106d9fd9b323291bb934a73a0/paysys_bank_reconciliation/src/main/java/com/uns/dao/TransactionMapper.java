package com.uns.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.Transaction;

@Repository
public interface TransactionMapper {

	int deleteByPrimaryKey(BigDecimal id);

	int insert(Transaction record);

	int insertSelective(Transaction record);

	Transaction selectByPrimaryKey(BigDecimal id);

	int updateByPrimaryKeySelective(Transaction record);

	int updateByPrimaryKey(Transaction record);

	Long getIdByTransId(String transId);

	Transaction getTrans(String applyNo);

    List<Transaction> getTransByTransId(Map transIds);

    List<Transaction> getTransByNewTransId(Map transIds);

	List<Transaction> getNewTXtransByTransId(Map transIds);
}