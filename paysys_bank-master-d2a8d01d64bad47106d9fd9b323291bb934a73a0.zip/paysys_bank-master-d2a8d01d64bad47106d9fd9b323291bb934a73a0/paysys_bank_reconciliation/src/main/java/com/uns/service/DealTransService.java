package com.uns.service;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.dao.DealTransMapper;
import com.uns.web.form.TransDetailForm;
import com.uns.web.form.TransRefForm;

@Service
public class DealTransService {
	@Autowired
	private DealTransMapper dealTransMapper;

	/**
	 * 获取挂起处理交易
	 * 
	 * @param transDetailForm
	 * @return
	 */
	public List<Object>  getDealTransDetail(TransDetailForm transDetailForm) {
		List<Object>  DealTransList;
		transDetailForm.setBillType(Constants.CHECK_BILL_0);
		if(null!=transDetailForm.getOperationType()&&transDetailForm.getOperationType().equals("2")){
			DealTransList =dealTransMapper.getDealApplyList(transDetailForm);
		}
		else {DealTransList = dealTransMapper.getDealLocalTransList(transDetailForm);}
		return DealTransList;
	}

	/**
	 * 获取调账申请处理交易
	 * 
	 * @param transDetailForm
	 * @return
	 */

	public List<Object> getDealApplyList(TransDetailForm transDetailForm) {
		List<Object> adjustApplyList;
		if(null!=transDetailForm.getOperationType()&&transDetailForm.getOperationType().equals("3")){
			 adjustApplyList =dealTransMapper.getDealLocalTransList(transDetailForm);
		}
		else {
            adjustApplyList = dealTransMapper.getDealApplyList(transDetailForm);
        }
		return adjustApplyList;
	}

	/**
	 * 获取出金的挂起处理交易
	 * @param transDetailForm
	 * @return
	 */
	public List<Object> getOutDealTransDetail(TransDetailForm transDetailForm) {
		List<Object> DealTransList = dealTransMapper.getOutDealLocalTransList(transDetailForm);
		return DealTransList;
	}

	/**
	 * 获取网联的挂起交易
	 * @param transDetailForm
	 * @return
	 */
	public List<Map> getNetsUnionDealTransDetail(TransDetailForm transDetailForm) {
		List<Map> DealTransList = dealTransMapper.getNetsUnionDealLocalTransList(transDetailForm);
		return DealTransList;
	}

	/**
	 * 获取网联的挂起交易
	 * @param transDetailForm
	 * @return
	 */
	public List<Object> getNetsUnionDealTransDetailExport(TransDetailForm transDetailForm) {
		List<Object> DealTransList = dealTransMapper.getNetsUnionDealLocalTransListExport(transDetailForm);
		return DealTransList;
	}
	/**
	 * 网联交易查询
	 * @param transDetailForm
	 * @return
	 */
	public List<Map> getNetsUnionTransList(TransRefForm transRefForm) {
		List<Map> netsUnionTransList = dealTransMapper.getNetsUnionTransList(transRefForm);
		return netsUnionTransList;
	}

	public List<Object> getNetsUnionTransDateExport(TransRefForm transRefForm) {
		List<Object> netsUnionTransList = dealTransMapper.getNetsUnionTransDateExport(transRefForm);
		return netsUnionTransList;
	}

}
