package com.uns.util;

import java.util.HashMap;
import java.util.Map;

import com.uns.common.Constants;

public class ChannelModel {
     public Map<String,String> getChannl(){
    	Map<String,String> map=new HashMap<String,String>();
    	map.put(Constants.UPLOAD_SPDB_KJ, Constants.UPLOAD_SPDB_KJ_CHANNEL);
    	map.put(Constants.UPLOAD_HXB_KJ, Constants.UPLOAD_HXB_KJ_CHANNEL);
    	map.put(Constants.UPLOAD_CEB_KJ_D, Constants.UPLOAD_CEB_KJ_D_CHANNEL);
    	map.put(Constants.UPLOAD_CMBC_XM_SM, Constants.UPLOAD_CMBC_XM_CHANNEL);
    	map.put(Constants.UPLOAD_CCB_CHANNEL, Constants.UPLOAD_CCB_KJ);
    	map.put(Constants.UPLOAD_PINGAN_KJ, Constants.UPLOAD_PINGAN_KJ_CHANNEL);
		return map;    	 
     }
}
