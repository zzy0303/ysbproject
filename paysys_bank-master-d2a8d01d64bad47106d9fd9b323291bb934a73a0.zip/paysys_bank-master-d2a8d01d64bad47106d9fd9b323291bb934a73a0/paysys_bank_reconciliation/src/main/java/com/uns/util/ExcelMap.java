package com.uns.util;

public class ExcelMap {
	// 交易成功标识
	private String success;
	// 交易成功标识sehll
	private int successshell;
	// 交易时间所处excel的shell
	private int transDateshell;
	// 交易金额所处excel的shell
	private int transAmountshell;
	// 交易id所处excel的shell
	private String transIdshell;
	// 标题行数
	private int startline;
	// 其他筛选
	private int sparePlace;
	// 其他筛选
	private String spare;

	public int getSparePlace() {
		return sparePlace;
	}

	public void setSparePlace(int sparePlace) {
		this.sparePlace = sparePlace;
	}

	public String getSpare() {
		return spare;
	}

	public void setSpare(String spare) {
		this.spare = spare;
	}

	public int getStartline() {
		return startline;
	}

	public void setStartline(int startline) {
		this.startline = startline;
	}

	public String getSuccess() {
		return success;
	}

	public void setSuccess(String success) {
		this.success = success;
	}

	public int getTransDateshell() {
		return transDateshell;
	}

	public void setTransDateshell(int transDateshell) {
		this.transDateshell = transDateshell;
	}

	public int getTransAmountshell() {
		return transAmountshell;
	}

	public void setTransAmountshell(int transAmountshell) {
		this.transAmountshell = transAmountshell;
	}

	public String getTransIdshell() {
		return transIdshell;
	}

	public void setTransIdshell(String transIdshell) {
		this.transIdshell = transIdshell;
	}

	public int getSuccessshell() {
		return successshell;
	}

	public void setSuccessshell(int successshell) {
		this.successshell = successshell;
	}

}
