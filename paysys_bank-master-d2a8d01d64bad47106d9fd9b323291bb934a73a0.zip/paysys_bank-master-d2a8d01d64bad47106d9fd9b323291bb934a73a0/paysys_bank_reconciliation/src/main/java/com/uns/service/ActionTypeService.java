package com.uns.service;

import com.uns.common.Constants;
import com.uns.dao.ActionTypeMapper;
import com.uns.model.ActionType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/8/28
 * @Modifyed By:
 */
@Service
public class ActionTypeService {

    @Autowired
    private ActionTypeMapper actionTypeMapper;

    public List<ActionType> selectAllAction() {
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        HttpSession session = request.getSession();
        List<ActionType> actionTypes = (List<ActionType>) session.getAttribute(Constants.ACTIONTYPELIST_SESSIONKEY);
        if (null == actionTypes || actionTypes.size() <= 0) {
            actionTypes = actionTypeMapper.selectAllAction();
        }
        return actionTypes;
    }

}
