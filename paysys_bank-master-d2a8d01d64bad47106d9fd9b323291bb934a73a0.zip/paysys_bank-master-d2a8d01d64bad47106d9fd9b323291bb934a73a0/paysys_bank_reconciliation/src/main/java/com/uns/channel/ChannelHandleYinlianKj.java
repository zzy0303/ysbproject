package com.uns.channel;

import com.uns.common.Constants;
import com.uns.model.BankTrans;
import com.uns.util.AnalyExcel;
import com.uns.web.form.CheckBillForm;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

public class ChannelHandleYinlianKj extends ChannelHandleDefault implements ChannelHandleInterface {

    @Override
    public List<BankTrans> loadDate(InputStream inputStream, CheckBillForm checkBillForm) throws Exception {
        return AnalyExcel.loadYinlianKjText(inputStream, checkBillForm, Constants.UPLOAD_YLWK_KJ_SHELL);
    }

    @Override
    public List<Map<String, Object>> getLocalTrans(Integer id) throws Exception {
        pareMap.put("id", id);
        pareMap.put("actionType", Constants.UPLOAD_KJ_ACTIONTYPE);
        return checkBillMapper.getYinlianKjTrans(pareMap);
    }

    @Override
    public Map<String, Object> getLocalAmount(String channel, String checkDate) {
        return null;
    }

    @Override
    public List<String> getChannelList() throws Exception {
        return null;
    }
}
