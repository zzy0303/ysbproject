package com.uns.dao;

import com.uns.model.XmBank;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface XmBankMapper {

    int deleteByPrimaryKey(String id);

    int insert(XmBank record);

    int insertSelective(XmBank record);

    XmBank selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(XmBank record);

    int updateByPrimaryKey(XmBank record);

    int getXmbankTransCount(String checkdate);

    List<XmBank> getXmbankTrans(Map<String, String> paramMap);

    void insertXmBank(List<XmBank> subList);

    void delXmbankOfCheckdate(String checkdate);
}