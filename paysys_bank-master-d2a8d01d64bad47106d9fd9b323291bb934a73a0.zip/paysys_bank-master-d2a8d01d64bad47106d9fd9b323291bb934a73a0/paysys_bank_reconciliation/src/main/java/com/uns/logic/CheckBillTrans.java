package com.uns.logic;

import java.math.BigDecimal;
import java.util.Date;

/*
 * 对账交易
 * */
public interface CheckBillTrans {
	// 交易编号
	public String getOrderId();

	// 交易日期
	public Date getDate();

	// 交易金额
	public BigDecimal getAmount();

	// 成功标志
	public boolean isSuccessful();

	// 是否银行多交易
	public boolean isBankSurplus();

}
