
package com.uns.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.PropertyUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.dao.AuditHistoryMapper;
import com.uns.dao.AuditOperandTypeMapper;
import com.uns.dao.AuditOperationMapper;
import com.uns.dao.AuditRuleMapper;
import com.uns.dao.AuditStepMapper;
import com.uns.dao.CheckBillMapper;
import com.uns.dao.CheckBillTransDetailMapper;
import com.uns.dao.TransactionMapper;
import com.uns.dao.UpadjustApplyMapper;
import com.uns.model.AuditHistory;
import com.uns.model.AuditOperandType;
import com.uns.model.AuditOperation;
import com.uns.model.AuditRule;
import com.uns.model.AuditStep;
import com.uns.model.CheckBill;
import com.uns.model.CheckBillTransDetail;
import com.uns.model.Transaction;
import com.uns.model.UpadjustApply;
import com.uns.util.StringUtils;
import com.uns.web.form.AdjustAuditForm;

@Service
public class AdjustAuditService {
	@Autowired
	private UpadjustApplyMapper upadjustApplyMapper;
	@Autowired
	private AuditOperandTypeMapper auditOperandTypeMapper;
	@Autowired
	private AuditHistoryMapper auditHistoryMapper;
	@Autowired
	private AuditOperationMapper auditOperationMapper;
	@Autowired
	private AuditRuleMapper auditRuleMapper;
	@Autowired
	private AuditStepMapper auditStepMapper;
	@Autowired
	private TransactionMapper transactionMapper;
	@Autowired
	private CheckBillMapper checkBillMapper;
	@Autowired
	private CheckBillTransDetailMapper checkBillTransDetailMapper;
	@Autowired
	private AdjustApplyService adjustApplyService;
	@Autowired
	private TransSystemService transSystemService;
	

    
	public List<Object> getAdjustAuditList(AdjustAuditForm adjustAuditForm) {
		//查询待审核数据
		adjustAuditForm.setAuditStatus(Constants.AUDIT_FLAG_LOCAL_LACK);
		List<Object> list = upadjustApplyMapper.getAdjustAuditList(adjustAuditForm);
		return list;
	}

    public List<Object> getOutAdjustAuditList(AdjustAuditForm adjustAuditForm) {
        //查询出金待审核数据
        adjustAuditForm.setAuditStatus(Constants.AUDIT_FLAG_LOCAL_LACK);
        List<Object> list = upadjustApplyMapper.getOutAdjustAuditList(adjustAuditForm);
        return list;
    }

	public List<Object> getNetsUnionAdjustAuditList(AdjustAuditForm adjustAuditForm) {
		adjustAuditForm.setAuditStatus(Constants.AUDIT_FLAG_LOCAL_LACK);
		List<Object> list = upadjustApplyMapper.getNetsUnionAdjustAuditList(adjustAuditForm);
		return list;
	}

	public List<Object> getTrandIdList(AdjustAuditForm adjustAuditForm) {
		// 取得审核操作类型：调账
		Map<String, Object> map1 = new HashMap<String, Object>();
		map1.put("systemType", 1);
		map1.put("operandClass", "BILLAUDIT");
		map1.put("actionFlag", 1);
		AuditOperandType auditOperandType = auditOperandTypeMapper.getAuditOperandType(map1);
		adjustAuditForm.setAuditOperandTypeId(auditOperandType.getId().toString());
		List<Object> list = upadjustApplyMapper.getTrandIdList(adjustAuditForm);
		return list;
	}

	public Map<String, Object> getAuditDetail(String transId,String applyNo) throws BusinessException {
		Map<String, Object> map = new HashMap<String, Object>();
		Map<String, Object> params = new HashMap<>();
		params.put("transId",transId);
		params.put("applyNo",applyNo);
		map = upadjustApplyMapper.getAuditDetail(params);
		if (null == map) {
			map = upadjustApplyMapper.getAuditBankDetail(transId);
		}
		if (map == null) {
			throw new BusinessException(ExceptionDefine.审核已拒绝无法再次审核);
		}
		if (map.get("ACTION_NAME") != null && !"-".equals(map.get("ACTION_NAME").toString())) {// 本地交易存在
			// 计算收付款方实际交易金额
			// 付款方费率外扣
			double debitRealAmount = Double.valueOf(map.get("AMOUNT").toString())
					+ Double.valueOf(map.get("DEBIT_FEE").toString());
			// 收款方费率外扣
			double creditRealAmount = Double.valueOf(map.get("AMOUNT").toString())
					- Double.valueOf(map.get("CREDIT_FEE").toString());
			map.put("CREDIT_REAL_AMOUNT", creditRealAmount);
			map.put("DEBIT_REAL_AMOUNT", debitRealAmount);
		}
		return map;
	}

	public Map<String, Object> getNetsUnionAuditDetail(String transId,String applyNo) throws BusinessException {
		Map<String, Object> map;
		Map<String, Object> params = new HashMap<>();
		params.put("transId",transId);
		params.put("applyNo",applyNo);
		map = upadjustApplyMapper.getNetsUnionAuditDetail(params);
		if (map == null) {
			throw new BusinessException(ExceptionDefine.审核已拒绝无法再次审核);
		}
		if (map.get("ACTION_NAME") != null && !"-".equals(map.get("ACTION_NAME").toString())) {// 本地交易存在
			// 计算收付款方实际交易金额
			// 付款方费率外扣
			double debitRealAmount = Double.valueOf(map.get("AMOUNT").toString())
					+ Double.valueOf(map.get("DEBIT_FEE").toString());
			// 收款方费率外扣
			double creditRealAmount = Double.valueOf(map.get("AMOUNT").toString())
					- Double.valueOf(map.get("CREDIT_FEE").toString());
			map.put("CREDIT_REAL_AMOUNT", creditRealAmount);
			map.put("DEBIT_REAL_AMOUNT", debitRealAmount);
		}
		return map;
	}

	public List<Map<String, Object>> getAuditHis(String applyNo) {
		// 取得审核操作类型：调账
		Map<String, Object> map1 = new HashMap<String, Object>();
		map1.put("systemType", 1);
		map1.put("operandClass", "BILLAUDIT");
		map1.put("actionFlag", 1);
		AuditOperandType auditOperandType = auditOperandTypeMapper.getAuditOperandType(map1);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("applyNo", applyNo);
		map.put("auditObjectId", auditOperandType.getId());
		List<Map<String, Object>> hisList = auditHistoryMapper.getAuditHis(map);
		for (int i = 0; i < hisList.size(); i++) {
			getOperationName(hisList.get(i));
		}
		return hisList;
	}

	// 获取操作类型名称
	private void getOperationName(Map<String, Object> map) {
		int previousStatus = Integer.parseInt(map.get("PREVIOUS_STATUS").toString());
		int postStatus = Integer.parseInt(map.get("POST_STATUS").toString());
		if (postStatus == 99) {
			// 后状态为99，当前操作为终审
			map.put("OPERATE_NAME", "终审");
			return;
		} else if (postStatus == 0) {
			// 后状态为0,当前操作为拒绝
			map.put("OPERATE_NAME", "拒绝");
			return;
		} else if (postStatus == -98) {
			// 后状态为-98,当前操作为取消
			map.put("OPERATE_NAME", "取消");
			return;
		}
		if (previousStatus == -1 || previousStatus == 0) {// 前状态为-1或0时，判断后状态
			if (postStatus == -1) {
				// 后状态也为-1,当前操作为创建
				map.put("OPERATE_NAME", "创建");
				return;
			}
			// 后状态为其他时，为提交
			map.put("OPERATE_NAME", "提交");
			return;
		}
		// 前后状态均不为特别状态时，当前操作为同意
		map.put("OPERATE_NAME", "同意");
		return;
	}

	public void agreeRecord(AdjustAuditForm adjustAuditForm, Long userId, String[] allApplayNos) throws Exception {
		Map map = new HashMap();
		map.put("applyNos", allApplayNos);
		List<UpadjustApply> applyList = upadjustApplyMapper.getBatchList(map);
		String reason;
		List<CheckBill> checkBills = new ArrayList<>();
		List<UpadjustApply> upadjustApplies = new ArrayList<>();
		List<Map> dealFlagsmaps = new ArrayList<>();
		for (UpadjustApply apply : applyList) {
			reason = apply.getReason();
			// 复核通过后需修改银生宝金额或银行金额，调账只处理银行有我方不成功的交易
			if (reason.equals(Constants.ADJUST_REASON_TRANS_ADJUST)) {
				// 查询当前交易状态
				Transaction trans = transactionMapper.getTrans(apply.getApplyNo());
				if (null != trans){
					Integer transStatus = Integer.valueOf(trans.getTransStatus());
					// 交易状态为待确认（申请时所有交易状态都为待确认）
					if (transStatus == 0 || transStatus == 11 || transStatus == 12) {
						apply.setAuditStatus(Constants.AUDIT_FLAG_BANK_LACK);
						apply.setUpdateTime(new Date());
						apply.setUpdateUser(userId.toString());
						// 复核通过，调用交易系统确认交易
						// 交易调账时才需要调用交易系统确认交易
						if (reason.equals(Constants.ADJUST_REASON_TRANS_ADJUST)) {
							comfirmTrans(trans, userId);
						}
					} else {// 交易状态已变更
						apply.setAuditStatus("4");
						apply.setUpdateTime(new Date());
						apply.setUpdateUser(userId.toString());
						upadjustApplyMapper.updateByPrimaryKeySelective(apply);// 更新申请表
						throw new BusinessException(ExceptionDefine.交易状态已变更无法通过审核);
					}
				} else {
					apply.setAuditStatus(Constants.AUDIT_FLAG_BANK_LACK);
					apply.setUpdateTime(new Date());
					apply.setUpdateUser(userId.toString());
				}
			} else {// 更新申请记录
				// 审核通过
				apply.setAuditStatus(Constants.AUDIT_FLAG_BANK_LACK);
				apply.setUpdateTime(new Date());
				apply.setUpdateUser(userId.toString());
			}

			if (true) {// FIXME 如果从对账列表发起调账则需修改对账列表

				CheckBill checkBill = checkBillMapper.getBillByBankTransId(apply.getId().toString());
				if (null == checkBill){
					checkBill = checkBillMapper.getCheckBillById(apply.getId().toString());
				}
				if (null == checkBill) {
					checkBill = checkBillMapper.getCheckBillByBankTransId(apply.getId().toString());
				}

				double amount = checkBillTransDetailMapper.getAmount(apply.getTransSeq().toString());
				if (new Double(0).compareTo(amount) >= 0) {
					amount = upadjustApplyMapper.getBankTransAmount(apply.getId().toString());
				}
				// 根据调账申请原因 修改银生宝或银行交易金额
				if (reason.equals(Constants.ADJUST_REASON_TRANS_ADJUST)) {
					// 银生宝金额增加
					checkBill.setLocalAmount(checkBill.getLocalAmount() + amount);
					checkBill.setFlatCount(checkBill.getFlatCount() == null ? 1 : checkBill.getFlatCount() + 1);
				} else if (reason.equals(Constants.ADJUST_REASON_BANK_TRANS_COUNTER)) {
					// 银行金额减少
					checkBill.setBankAmount(checkBill.getBankAmount() - amount);
				} else if (reason.equals(Constants.ADJUST_REASON_TRANS_HANGUP)) {
					// 银生宝金额减少
					checkBill.setLocalAmount(checkBill.getLocalAmount() - amount);
				} else if (reason.equals(Constants.ADJUST_REASON_LOCAL_TRANS_COUNTER)) {
					// 银生宝金额减少
					checkBill.setLocalAmount(checkBill.getLocalAmount() - amount);
				} else if (reason.equals(Constants.ADJUST_REASON_AMOUNT_ERROR)) {
					// 金额不对
					double localAmount = checkBillTransDetailMapper.getAmount(apply.getTransSeq().toString());
					double bankAmount = upadjustApplyMapper.getTransAmount(apply.getTransSeq().toString());
					checkBill.setLocalAmount(checkBill.getLocalAmount() - localAmount);
					checkBill.setBankAmount(checkBill.getBankAmount() - bankAmount);
				} else {// 其他，根据对账状态判断金额加减
					String checkStatus = checkBillTransDetailMapper.getCheckStatus(apply.getId().toString());
					if (Constants.CHECK_STATUS_LOCAL_LACK.equals(checkStatus)) {
						// 银行有我方无
						checkBill.setBankAmount(checkBill.getBankAmount() - amount);
					} else if (Constants.CHECK_STATUS_BANK_LACK.equals(checkStatus)) {// 银行无我方有
						checkBill.setLocalAmount(checkBill.getLocalAmount() - amount);
					}
				}
				checkBill.setInflatCount(checkBill.getInflatCount() == null ? 0 : checkBill.getInflatCount() - 1);
				if (checkBill.getInflatCount() < 0) {
					checkBill.setInflatCount(0);
				}
				checkBillMapper.updateByPrimaryKeySelective(checkBill);
			}
			//更新对账处理标志为已处理差异
			Map<String,String> dealFlagsmap =new HashMap<String,String>();
			String transId;
			dealFlagsmap.put("status", Constants.FLAG_3);
			if(null!=apply.getBankTransId()){
				dealFlagsmap.put("transId", apply.getBankTransId());
				dealFlagsmap.put("type", Constants.FLAG_2);
			}
			else  {
				transId=upadjustApplyMapper.getById(apply.getApplyNo());
				dealFlagsmap.put("transId", transId);
				dealFlagsmap.put("type", Constants.FLAG_1);
			}
			dealFlagsmaps.add(dealFlagsmap);
			upadjustApplies.add(apply);
		}
		upadjustApplyMapper.updateByApplyTransIdBatch(Constants.FLAG_3, dealFlagsmaps);
		upadjustApplyMapper.updateApplyBatch(upadjustApplies);
	}

	public void agreeNetsUnionRecord(Long userId, String[] allApplayNos) throws Exception{
		//网联挂起审核通过
		Map map = new HashMap();
		map.put("applyNos", allApplayNos);
		List<UpadjustApply> applyList = upadjustApplyMapper.getBatchList(map);
		List<UpadjustApply> upadjustApplies = new ArrayList<>();
		List<Map> dealFlagsmaps = new ArrayList<>();
		for (UpadjustApply apply : applyList) {
			// 审核通过
			apply.setAuditStatus(Constants.AUDIT_FLAG_BANK_LACK);
			apply.setUpdateTime(new Date());
			apply.setUpdateUser(userId.toString());

			CheckBill checkBill = checkBillMapper.getNetsUnionCheckBillByApplyNo(apply.getId().toString());
			double amount = Double.valueOf(checkBillTransDetailMapper.getNetsUnionAmount(apply.getTransSeq().toString()));
			// 银生宝金额减少
			checkBill.setLocalAmount(checkBill.getLocalAmount() - amount);
			checkBill.setInflatCount(checkBill.getInflatCount() == null ? 0 : checkBill.getInflatCount() - 1);
			checkBillMapper.updateByPrimaryKeySelective(checkBill);

			//更新对账处理标志为已处理差异
			Map<String,String> dealFlagsmap =new HashMap<String,String>();
			String transId;
			transId=upadjustApplyMapper.getNetsUnionTransId(apply.getApplyNo());
			dealFlagsmap.put("transId", transId);
			dealFlagsmap.put("status", Constants.FLAG_3);
			dealFlagsmap.put("type", Constants.FLAG_1);
			dealFlagsmaps.add(dealFlagsmap);
			upadjustApplies.add(apply);
		}
		upadjustApplyMapper.updateByApplyTransIdBatch(Constants.FLAG_3, dealFlagsmaps);
		upadjustApplyMapper.updateApplyBatch(upadjustApplies);
	}

	// 审核同意
	public void agree(AdjustAuditForm adjustAuditForm, Long userId) throws Exception {
		// 获取调账申请记录
		UpadjustApply apply = upadjustApplyMapper.getByApplyNo(adjustAuditForm.getApplyNo());
		// 取得审核操作类型
		/*Map<String, Object> map1 = new HashMap<String, Object>();
		map1.put("systemType", 1);
		map1.put("operandClass", "BILLAUDIT");
		map1.put("actionFlag", 1);
		AuditOperandType auditOperandType = auditOperandTypeMapper.getAuditOperandType(map1);

		// 审核
		BigDecimal postStatus = adjustApplyService.initAudit(auditOperandType, apply.getId(),
				adjustAuditForm.getAttitude(), userId);

		// 终审通过
		if (postStatus.compareTo(BigDecimal.valueOf(99)) == 0) {*/
			// 查询当前交易状态
			Transaction trans = transactionMapper.getTrans(adjustAuditForm.getApplyNo());
			String reason = apply.getReason();
			// 复核通过后需修改银生宝金额或银行金额，调账只处理银行有我方不成功的交易
			if (reason.equals(Constants.ADJUST_REASON_TRANS_ADJUST)) {
				Integer transStatus = Integer.valueOf(trans.getTransStatus());
				// 交易状态为待确认（申请时所有交易状态都为待确认）
				if (transStatus == 0 || transStatus == 11 || transStatus == 12) {
					apply.setAuditStatus(Constants.AUDIT_FLAG_BANK_LACK);
					apply.setUpdateTime(new Date());
					apply.setUpdateUser(userId.toString());
					// 复核通过，调用交易系统确认交易
					// 交易调账时才需要调用交易系统确认交易
					if (reason.equals(Constants.ADJUST_REASON_TRANS_ADJUST)) {
						comfirmTrans(trans, userId);
					}
				} else {// 交易状态已变更
					apply.setAuditStatus("4");
					apply.setUpdateTime(new Date());
					apply.setUpdateUser(userId.toString());
					upadjustApplyMapper.updateByPrimaryKeySelective(apply);// 更新申请表
					throw new BusinessException(ExceptionDefine.交易状态已变更无法通过审核);
				}
			} else {// 更新申请记录
				// 审核通过
				apply.setAuditStatus(Constants.AUDIT_FLAG_BANK_LACK);
				apply.setUpdateTime(new Date());
				apply.setUpdateUser(userId.toString());
			}

			if (true) {// FIXME 如果从对账列表发起调账则需修改对账列表
				
				CheckBill checkBill = checkBillMapper.getCheckBillByBankTransId(apply.getId().toString());
				if (checkBill == null) {
					checkBill = checkBillMapper.getCheckBillById(adjustAuditForm.getTransId());
				}

				double amount = checkBillTransDetailMapper.getAmount(apply.getTransSeq().toString());
				if (new Double(0).compareTo(amount) >= 0) {
					amount = upadjustApplyMapper.getBankTransAmount(apply.getId().toString());
				}
				// 根据调账申请原因 修改银生宝或银行交易金额
				if (reason.equals(Constants.ADJUST_REASON_TRANS_ADJUST)) {
					// 银生宝金额增加
					checkBill.setLocalAmount(checkBill.getLocalAmount() + amount);
					checkBill.setFlatCount(checkBill.getFlatCount() == null ? 1 : checkBill.getFlatCount() + 1);
				} else if (reason.equals(Constants.ADJUST_REASON_BANK_TRANS_COUNTER)) {
					// 银行金额减少
					checkBill.setBankAmount(checkBill.getBankAmount() - amount);
				} else if (reason.equals(Constants.ADJUST_REASON_TRANS_HANGUP)) {
					// 银生宝金额减少
					checkBill.setLocalAmount(checkBill.getLocalAmount() - amount);
				} else if (reason.equals(Constants.ADJUST_REASON_LOCAL_TRANS_COUNTER)) {
					// 银生宝金额减少
					checkBill.setLocalAmount(checkBill.getLocalAmount() - amount);
				} else if (reason.equals(Constants.ADJUST_REASON_AMOUNT_ERROR)) {
					// 金额不对
					double localAmount = checkBillTransDetailMapper.getAmount(apply.getTransSeq().toString());
					double bankAmount = upadjustApplyMapper.getTransAmount(apply.getTransSeq().toString());
					checkBill.setLocalAmount(checkBill.getLocalAmount() - localAmount);
					checkBill.setBankAmount(checkBill.getBankAmount() - bankAmount);
				} else {// 其他，根据对账状态判断金额加减
					String checkStatus = checkBillTransDetailMapper.getCheckStatus(apply.getId().toString());
					if (Constants.CHECK_STATUS_LOCAL_LACK.equals(checkStatus)) {
						// 银行有我方无
						checkBill.setBankAmount(checkBill.getBankAmount() - amount);
					} else if (Constants.CHECK_STATUS_BANK_LACK.equals(checkStatus)) {// 银行无我方有
						checkBill.setLocalAmount(checkBill.getLocalAmount() - amount);
					}
				}
				checkBill.setInflatCount(checkBill.getInflatCount() == null ? 0 : checkBill.getInflatCount() - 1);
				if (checkBill.getInflatCount() < 0) {
					checkBill.setInflatCount(0);
				}
				checkBillMapper.updateByPrimaryKeySelective(checkBill);
				updateDealFlag(apply,Constants.FLAG_3);
			}

		/*} else {// 不是终审
			updateDealFlag(apply,Constants.FLAG_2);
			apply.setUpdateTime(new Date());
			apply.setUpdateUser(userId.toString());
		}*/
		upadjustApplyMapper.updateByPrimaryKeySelective(apply);// 更新申请表
	}
	
    /**
     * 更新对账状态为已审核
     * @param apply
     */
	public void updateDealFlag(UpadjustApply apply,String Status){
		//更新对账处理标志为已处理差异	
	    Map<String,String> dealFlagsmap =new HashMap<String,String>();
		String transId;
		dealFlagsmap.put("status", Status);
		if(null!=apply.getBankTransId()){
			dealFlagsmap.put("transId", apply.getBankTransId());
			 upadjustApplyMapper.updateByApplyBankTransId(dealFlagsmap);
		}
		else  {
			transId=upadjustApplyMapper.getById(apply.getApplyNo());
		    dealFlagsmap.put("transId", transId);
		    upadjustApplyMapper.updateByApplyTransId(dealFlagsmap);
		}
		
	}

	public void rejectRecord (Long userId, String[] allApplayNos){
		Map map = new HashMap();
		map.put("applyNos", allApplayNos);
		List<UpadjustApply> applyList = upadjustApplyMapper.getBatchList(map);
		List<UpadjustApply> applyLists = new ArrayList<>();
		List<Map> dealFlagsmaps = new ArrayList<>();
		Map<String,String> dealFlagsmap =new HashMap<String,String>();
		String transId;
		for (UpadjustApply apply : applyList) {
			apply.setAuditStatus(Constants.FLAG_3);//审核拒绝
			apply.setUpdateTime(new Date());
			apply.setUpdateUser(String.valueOf(userId));
			transId = upadjustApplyMapper.getById(apply.getApplyNo());
			dealFlagsmap.put("transId", transId);
			dealFlagsmap.put("type", Constants.FLAG_1);
			dealFlagsmaps.add(dealFlagsmap);
			applyLists.add(apply);
		}
		upadjustApplyMapper.updateApplyBatch(applyLists);
		upadjustApplyMapper.updateByApplyTransIdBatch(Constants.FLAG_4_, dealFlagsmaps);
	}

	public void rejectNetsUnionRecord (Long userId, String[] allApplayNos) {
		Map map = new HashMap();
		map.put("applyNos", allApplayNos);
		List<UpadjustApply> applyList = upadjustApplyMapper.getBatchList(map);
		List<UpadjustApply> applyLists = new ArrayList<>();
		List<Map> dealFlagsmaps = new ArrayList<>();
		Map<String,String> dealFlagsmap =new HashMap<String,String>();
		String transId;
		for (UpadjustApply apply : applyList) {
			// 修改调账状态为审核拒绝
			apply.setAuditStatus(Constants.CHECK_STATUS_BANK_LACK);
			apply.setUpdateTime(new Date());
			apply.setUpdateUser(String.valueOf(userId));
			//跟新对账处理状态为为发起处理
			if (null != apply.getBankTransId()){
				dealFlagsmap.put("transId", apply.getBankTransId());
				dealFlagsmap.put("type", Constants.FLAG_2);
			} else {
				transId=upadjustApplyMapper.getNetsUnionById(apply.getApplyNo());
				dealFlagsmap.put("transId", transId);
				dealFlagsmap.put("type", Constants.FLAG_1);
			}
			dealFlagsmaps.add(dealFlagsmap);
			applyLists.add(apply);
		}
		upadjustApplyMapper.updateApplyBatch(applyLists);
		upadjustApplyMapper.updateByApplyTransIdBatch(Constants.FLAG_4_, dealFlagsmaps);
	}

	// 审核拒绝
	public void reject(AdjustAuditForm adjustAuditForm, Long userId)
			throws NumberFormatException, BusinessException, Exception {
		// 获取调账申请记录
		UpadjustApply apply = upadjustApplyMapper.getByApplyNo(adjustAuditForm.getApplyNo());
		// 取得审核操作类型：调账
		Map<String, Object> map1 = new HashMap<String, Object>();
		map1.put("systemType", 1);
		map1.put("operandClass", "BILLAUDIT");
		map1.put("actionFlag", 1);
		AuditOperandType auditOperandType = auditOperandTypeMapper.getAuditOperandType(map1);
		doReject(auditOperandType, Long.valueOf(apply.getId().toString()), userId, adjustAuditForm.getAttitude());
		// 修改调账状态为审核拒绝
		apply.setAuditStatus(Constants.CHECK_STATUS_BANK_LACK);
		apply.setUpdateTime(new Date());
		apply.setUpdateUser(String.valueOf(userId));
		String transId;
		//跟新对账处理状态为为发起处理
		Map<String,String> dealFlagsmap =new HashMap<String,String>();
		dealFlagsmap.put("status", Constants.FLAG_4_);
		if(null!=adjustAuditForm.getTransId()){		    
		    dealFlagsmap.put("transId", adjustAuditForm.getTransId());						   
			}
		else  {
			transId=upadjustApplyMapper.getById(apply.getApplyNo());
		    if(null==transId){
		    	transId=upadjustApplyMapper.getByCncbId(apply.getApplyNo());
		    	transId=new StringBuilder(transId).replace(8,9,"_").toString();
		    }	
		    dealFlagsmap.put("transId", transId);	
		}
		 upadjustApplyMapper.updateByApplyTransId(dealFlagsmap);
		upadjustApplyMapper.updateByPrimaryKeySelective(apply);// 更新申请表
	}

	private void comfirmTrans(Transaction trans, Long userId) throws Exception {
		// 如果当前交易状态为非成功
		if (!Constants.CHECK_STATUS_BANK_LACK.equals(trans.getTransStatus())) {
			trans.setTransStatus(Constants.CHECK_STATUS_BANK_LACK); // 设置交易状态 ：交易成功
			trans.setEndDate(new Date());// 结束日期
			trans.setInsideStatus("Y");// 内部状态改为'Y'
			transSystemService.affirmTrans(trans);
		}
	}

	/**
	 * 审核拒绝
	 * 
	 * @param opType
	 * @param operandId
	 * @param auditorId
	 * @param remark
	 * @throws BusinessException
	 * @throws Exception
	 */
	private void doReject(AuditOperandType opType, Long operandId, Long auditorId, String remark)
			throws BusinessException, Exception {
		// 取得审核操作记录
		Map<String, Object> map3 = new HashMap<String, Object>();
		map3.put("auditOperandTypeId", opType.getId());
		map3.put("auditOperandId", operandId);
		AuditOperation operation = auditOperationMapper.getAuditOperation(map3);
		if (operation == null) {
			// 没有审核记录，系统错误
			throw new BusinessException(ExceptionDefine.未查询到审核记录无法拒绝);
		}
		// 判断审核状态,只有介于0和99之间的状态才可以进行拒绝
		if (!(operation.getPostStatus().compareTo(BigDecimal.valueOf(0)) == 1
				&& (operation.getPostStatus().compareTo(BigDecimal.valueOf(99)) == -1))) {
			// 相关数据状态不为待审核状态，返回错误
			throw new BusinessException(ExceptionDefine.审核状态错误无法拒绝审核);
		}
		BigDecimal preStatus = operation.getPostStatus();
		// 后状态为审核拒绝
		BigDecimal postStatus = new BigDecimal(0);

		// 根据审核操作对象类型查找审核规则
		Map<String, Object> map2 = new HashMap<String, Object>();
		map2.put("auditOperandTypeId", opType.getId());
		map2.put("valid", 1);
		AuditRule rule = auditRuleMapper.getAuditRule(map2);
		// 此处审核规则不应为空，返回错误信息
		if (rule == null) {
			throw new BusinessException(ExceptionDefine.审核规则不存在);
		}
		List<AuditStep> stepList = auditStepMapper.getAuditStep(rule.getId());
		// 获取该次审核后状态
		// 取得当前操作的审核组id
		BigDecimal auditGroupId = getAuditGroupId(stepList, postStatus);
		operation.setPreviousStatus(preStatus); // 前状态
		operation.setPostStatus(postStatus); // 后状态
		operation.setAuditGroupId(auditGroupId); // 当前操作审核组
		operation.setUpdateUser(String.valueOf(auditorId)); // 审核操作人ID
		operation.setUpdateTime(new Date());
		operation.setAttitude(remark);
		auditOperationMapper.updateByPrimaryKeySelective(operation);
		// 保存历史操作记录
		createAuditHistory(operation);
	}

	private void createAuditHistory(AuditOperation operation) {
		AuditHistory history = new AuditHistory();
		try {
			PropertyUtils.copyProperties(history, operation);
		} catch (Exception e) {
			e.printStackTrace();
		}
		history.setCreateUser(operation.getUpdateUser());
		history.setCreateTime(new Date());
		history.setSequenceNo(BigDecimal.valueOf(0));
		history.setUpdateTime(new Date());
		auditHistoryMapper.insertSelective(history);
	}

	// 删除审核记录
	public void deleteAudit(CheckBillTransDetail checkBillTransDetail) {
		// 获取对账文件交易id
		Map<String, List<Long>> applyNomap = new HashMap<String, List<Long>>();
		List<Long> applyNolist = new ArrayList<Long>();
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		List<String> transIdlist = checkBillTransDetailMapper.getTransId(checkBillTransDetail);
		// 获取申请批次号
		if (null != transIdlist && transIdlist.size() > 0) {
			// 因为数据库的列表sql限制，不能超过1000
			List<List> list = StringUtils.getList(transIdlist);
			for (int i = 0; i < list.size(); i++) {
				map.put("list", list.get(i));
				// 银行有 我方无
				applyNolist = upadjustApplyMapper.getApplyByBankId(map);
				// 其他
				applyNolist.addAll(upadjustApplyMapper.getapplyNoByTransSeq(map));
				if (applyNolist.size() > 0) {
					applyNomap.put("list", applyNolist);
				}
			}
			if (applyNomap.size() > 0) {
				// 删除审核记录
				auditOperationMapper.deleteByAuditOperandId(applyNomap);
				// 删除申请历史纪录
				// auditHistoryMapper.deleteAuditHistory(applyNomap);
			}
		}

	}

	private BigDecimal getAuditGroupId(List<AuditStep> stepList, BigDecimal intPreStatus) {
		for (int i = 0; i < stepList.size(); i++) {
			if (stepList.get(i).getAuditLevel().equals(intPreStatus.toString())) {
				return stepList.get(i).getAuditGroupId();
			}
		}
		return null;
	}

}
