package com.uns.web.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.model.CheckBill;
import com.uns.model.CheckBillTransDetail;
import com.uns.model.FileUploadRecord;
import com.uns.model.UserInfo;
import com.uns.service.AdjustApplyService;
import com.uns.service.AdjustAuditService;
import com.uns.service.BankTransService;
import com.uns.service.CheckBillService;
import com.uns.service.CheckBillTransDetailService;
import com.uns.service.FileUploadRecordService;
import com.uns.util.StringUtils;
import com.uns.web.form.CheckBillForm;

@Controller
@RequestMapping(value = "/fileUploadRecord.htm")
public class FileUploadRecordController extends BaseController {
	@Autowired
	private FileUploadRecordService fileUploadRecordService;
	@Autowired
	private CheckBillService checkBillService;

	@Autowired
	private BankTransService bankTransService;

	@Autowired
	private AdjustAuditService adjustAuditService;

	@Autowired
	private AdjustApplyService adjustApplyService;
	@Autowired
	private CheckBillTransDetailService checkBillTransDetailService;

	// 跳转上传页面
	@RequestMapping(params = "method=toUploadRecordList")
	@FormToken(save = true)
	public String toUploadRecordList(HttpServletRequest request, CheckBillForm checkBillForm) throws BusinessException {
		List<FileUploadRecord> list = fileUploadRecordService.getUploadRecordList();
		request.setAttribute("uploadList", list);
		return "checkbill/uploadRecordList";
	}

	// 删除
	@RequestMapping(params = "method=deleteFileList")
	@FormToken(save = true)
	public String deleteFileList(HttpServletRequest request, CheckBillForm checkBillForm) throws BusinessException {

        String[] ids = checkBillForm.getIds().split(",");
        FileUploadRecord fileUploadRecord;
        CheckBillTransDetail checkBillTransDetail = new CheckBillTransDetail();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd");
        for (String id : ids) {
            fileUploadRecord = fileUploadRecordService.findFileUploadRecordById(id);

            checkBillTransDetail.setChannel(fileUploadRecord.getChannel());
            checkBillTransDetail.setCheckDate(fileUploadRecord.getCheckDate());
            checkBillForm.setChannel(fileUploadRecord.getChannel());
            checkBillForm.setCheckdate(simpleDateFormat.format(fileUploadRecord.getCheckDate()));
            if (!StringUtils.isEmpty(fileUploadRecord.getCheckStatus()) && !fileUploadRecord.getCheckStatus().equals(Constants.CHECK_BILL_1)
                    &&!fileUploadRecord.getCheckStatus().equals(Constants.CHECK_BILL_0) && null != fileUploadRecord.getChannel() && null != fileUploadRecord.getCheckDate()){
                // 删除对账申请记录
                adjustApplyService.deleteApplyRecord(checkBillTransDetail);
                // 删除对账交易详情
                checkBillTransDetailService.deletlocaltrans(checkBillTransDetail);
            }
            // 删除上传数据
            bankTransService.deleteBankTrans(Long.valueOf(id));
            // 删除上传记录
            fileUploadRecordService.deleteRecordById(Long.valueOf(id));
            // 更新对账表处理状态
            checkBillService.updateCheckStatus(simpleDateFormat.format(fileUploadRecord.getCheckDate()), fileUploadRecord.getChannel());
            // 更新挂起交易对账明细
            checkBillTransDetailService.updateCheckTransDetail(simpleDateFormat.format(fileUploadRecord.getCheckDate()), fileUploadRecord.getChannel());
        }

        List<FileUploadRecord> list = fileUploadRecordService.getUploadRecordList();
        request.setAttribute("uploadList", list);
        return "checkbill/uploadRecordList";
	}

	/**
	 * 对账
	 */
	@RequestMapping(params = "method=getCheck")
	@FormToken(save = true)
	public String geCheck(HttpServletRequest request, CheckBillForm checkBillForm) throws BusinessException {
		UserInfo user = (UserInfo) (request.getSession().getAttribute(Constants.SESSION_KEY_USER));
		try {
			String checkdate = request.getParameter("checkDate").toString();
			String channel = request.getParameter("channel").toString();
			// 获取对账列表主键id
			checkBillForm.setChannel(channel);
			checkBillForm.setCheckdate(checkdate);
			checkBillForm.setBillType(Constants.CHECK_BILL_0);
			List<CheckBill> list = checkBillService.getToCheck(checkBillForm);
			fileUploadRecordService.toCheck(list, user, Constants.CHECK_BILL_0);
			request.setAttribute("msg", "对账成功！！");
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("errMsg", "对账错误！！");
		}
		request.setAttribute("title", "对账文件上传记录");
		request.setAttribute("closeTitle", "对账列表");
		request.setAttribute("url", "checkBill.htm?method=checkBillList");
		return "common/message";
	}

	/**
	 * 出金文件上传页面
	 * @return
	 */
	@RequestMapping(params = "method=toOutUploadRecordList")
	@FormToken(save = true)
	public String toOutUploadRecordList(HttpServletRequest request,CheckBillForm checkBillForm){
		//出金标识
		checkBillForm.setBillType(Constants.FLAG_1);
		//查询出金对账文件
		List<FileUploadRecord> list = fileUploadRecordService.getOutUploadRecordList(checkBillForm);
		request.setAttribute("uploadList", list);
		return "outcheckbill/uploadOutRecordList";
	}

	/**
	 * 跳转网联文件上传记录页面
	 * @return
	 */
	@RequestMapping(params = "method=toNetsUnionUploadRecordList")
	@FormToken(save = true)
	public String toNetsUnionUploadRecordList(HttpServletRequest request,CheckBillForm checkBillForm){
		checkBillForm.setBillType(Constants.FLAG_2);
		//查询网联对账文件上传记录
		List<FileUploadRecord> list = fileUploadRecordService.getNetsUnionUploadRecordList(checkBillForm);
		request.setAttribute("uploadList", list);
		return "netsUnionCheckbill/netsUnionRecordList";
	}

	/**
	 * 出金对账
	 */
	@RequestMapping(params = "method=getOutCheck")
	@FormToken(save = true)
	public String getOutCheck(HttpServletRequest request, CheckBillForm checkBillForm) throws BusinessException {
		UserInfo user = (UserInfo) (request.getSession().getAttribute(Constants.SESSION_KEY_USER));
		try {
			String checkdate = request.getParameter("checkDate").toString();
			String channel = request.getParameter("channel").toString();
			checkBillForm.setChannel(channel);
			checkBillForm.setCheckdate(checkdate);
			checkBillForm.setBillType(Constants.CHECK_BILL_1);
			List<CheckBill> list = checkBillService.getToCheck(checkBillForm);
			fileUploadRecordService.toCheck(list, user, Constants.CHECK_BILL_1);
			request.setAttribute("msg", "对账成功！！");
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("errMsg", "对账错误！！");
		}
        request.setAttribute("title", "对账文件上传记录");
        request.setAttribute("closeTitle", "出金对账列表");
		request.setAttribute("url", "outCheckBill.htm?method=outCheckBillList");
		return "common/message";
	}

	// 删除出金记录
	@RequestMapping(params = "method=deleteOutFileList")
	@FormToken(save = true)
	public String deleteOutFileList(HttpServletRequest request, CheckBillForm checkBillForm) throws BusinessException {
		Long id = Long.valueOf(request.getParameter("id").toString());
		String checkdate = request.getParameter("checkDate").toString();
		String channel = request.getParameter("channel").toString();
		String status = request.getParameter("status").toString();
		CheckBillTransDetail checkBillTransDetail = new CheckBillTransDetail();
		checkBillTransDetail.setChannel(channel);
		checkBillTransDetail.setCheckDate(StringUtils.gettime(checkdate));
		checkBillForm.setChannel(channel);
		checkBillForm.setCheckdate(checkdate);
		checkBillForm.setBillType(Constants.FLAG_1);
		// 对账完成
		if (!StringUtils.isEmpty(status) && !Constants.CHECK_BILL_1.equals(status)
				&& !Constants.CHECK_BILL_0.equals(status) && null != channel && null != checkdate) {
			// 删除对账申请记录
			adjustApplyService.deleteApplyRecord(checkBillTransDetail);
			// 删除对账交易详情
			checkBillTransDetailService.deletlocaltrans(checkBillTransDetail);
		}
		// 删除上传数据
		bankTransService.deleteBankTrans(id);
		// 删除上传记录
		fileUploadRecordService.deleteRecordById(id);
		// 更新对账表处理状态
		checkBillService.updateCheckStatus(checkdate, channel);
		// 更新挂起交易对账明细
		checkBillTransDetailService.updateCheckTransDetail(checkdate, channel);
		List<FileUploadRecord> list = fileUploadRecordService.getOutUploadRecordList(checkBillForm);
		request.setAttribute("uploadList", list);
		return "outcheckbill/uploadOutRecordList";
	}

	// 删除网联对账文件上传记录
	@RequestMapping(params = "method=deleteNetsUnionFileList")
	@FormToken(save = true)
	public String deleteNetsUnionFileList(HttpServletRequest request, CheckBillForm checkBillForm) throws Exception {
		String[] ids = checkBillForm.getIds().split(",");
		for(int i=0;i<ids.length;i++){
			FileUploadRecord fileUploadRecord = fileUploadRecordService.getNetsUnionUploadRecordById(ids[i]);
			if(fileUploadRecord == null){
				throw new BusinessException("没有相应的记录！");
			}
			checkBillForm.setCheckdate(new SimpleDateFormat(Constants.DEFAULT_DATE_FORMAT).format(fileUploadRecord.getCheckDate()));
			checkBillForm.setChannel(fileUploadRecord.getChannel());
			checkBillForm.setId(String.valueOf(fileUploadRecord.getId()));
			checkBillForm.setStatus(fileUploadRecord.getCheckStatus());
			checkBillForm.setBatchId(fileUploadRecord.getBatchId());
			// 对账完成
			if (!StringUtils.isEmpty(checkBillForm.getStatus()) && !Constants.CHECK_BILL_1.equals(checkBillForm.getStatus())
					&& !Constants.CHECK_BILL_0.equals(checkBillForm.getStatus()) && null != checkBillForm.getChannel() && null != checkBillForm.getCheckdate()) {
				// 删除对账申请记录
				adjustApplyService.deleteNetsUnionApplyRecord(checkBillForm);
				CheckBill checkBill = checkBillService.getEpccRecord(checkBillForm);
				checkBillForm.setFileName(String.valueOf(checkBill.getId()));
				// 删除对账交易详情
				checkBillTransDetailService.deletlocaltransNetsUnion(checkBillForm);
			}
			Long id = Long.valueOf(checkBillForm.getId());
			// 删除上传数据
			bankTransService.deleteBankTrans(id);
			// 删除上传记录
			fileUploadRecordService.deleteRecordById(id);
			// 更新对账表处理状态
			checkBillService.updateNetsUnionCheckStatus(checkBillForm);
			// 更新挂起交易对账明细
			checkBillTransDetailService.updateNetsUnionCheckTransDetail(checkBillForm);
		}
		List<FileUploadRecord> list = fileUploadRecordService.getNetsUnionUploadRecordList(checkBillForm);
		request.setAttribute("uploadList", list);
		return "netsUnionCheckbill/netsUnionRecordList";
	}

	/**
	 * 网联文件上传记录的页面对账
	 */
	@RequestMapping(params = "method=netsUnionCheck")
	@FormToken(save = true)
	public String netsUnionCheck(HttpServletRequest request, CheckBillForm checkBillForm) throws BusinessException {
		UserInfo user = (UserInfo) (request.getSession().getAttribute(Constants.SESSION_KEY_USER));
		try {
			CheckBill checkBill = checkBillService.getNetsUnionToCheck(checkBillForm);
			fileUploadRecordService.netsUnionToCheck(checkBillForm, checkBill, user, Constants.CHECK_BILL_2);//网联bill_type
			request.setAttribute("msg", "对账成功！！");
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("errMsg", "对账错误！！");
		}
		request.setAttribute("title", "对账文件上传记录");
		request.setAttribute("closeTitle", "出金对账列表");
		request.setAttribute("url", "netsUnionCheckBill.htm?method=netsUnionCheckBillList");
		return "common/message";
	}
}
