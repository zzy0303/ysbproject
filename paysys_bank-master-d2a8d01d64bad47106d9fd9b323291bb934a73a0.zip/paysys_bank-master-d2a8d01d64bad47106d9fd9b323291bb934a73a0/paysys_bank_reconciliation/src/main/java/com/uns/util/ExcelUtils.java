package com.uns.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.model.BankTrans;
import com.uns.web.form.CheckBillForm;
import sun.java2d.pipe.SpanShapeRenderer;

public class ExcelUtils {

	private static HSSFSheet sheet;

	public static final String FIELD_SEPARATOR = "#";

	protected static Date loadDateFromTitle() {
		return null;
	}

	/**
	 * 银联对账单文本类型文件解析
	 * 
	 * @param file
	 * @param checkBillForm
	 * @return
	 * @throws BusinessException
	 * @throws IOException
	 */
	public static List<BankTrans> loadAllText(InputStream file, CheckBillForm checkBillForm)
			throws BusinessException, IOException {
		List<BankTrans> list = new ArrayList<BankTrans>();
		if ((Constants.UPLOAD_UNIONPAY_CHANNEL).contains(checkBillForm.getChannel())) {
			try {
				Date transDate = new SimpleDateFormat("yyyyMMdd").parse(checkBillForm.getStartDate());
				BufferedReader reader = new BufferedReader(new InputStreamReader(file, "GBK"));
				for (String line = reader.readLine(); line != null; line = reader.readLine()) {
					if (line.trim().length() == 0) {
                        continue;
                    }
					String[] data = line.split("\\s+");
					if (data.length < 35) {
						throw new BusinessException(ExceptionDefine.对账文件格式错误);
					}
					// 交易时间
					if (data.length > 35&&data[35].length()==15) {
						String fDate = data[35].substring(0, 13);
						Date date = new SimpleDateFormat("yyyyMMddHHmmss").parse(fDate);
						if (date == null) {
							throw new BusinessException(ExceptionDefine.对账文件格式错误);
						}
						// 订单号
						if (data[35].length() < 1) {
							throw new BusinessException(ExceptionDefine.对账文件格式错误);
						}
						// 金额
						BigDecimal transAmount = new BigDecimal(data[5]).divide(new BigDecimal(100)).setScale(2);
						BankTrans trans = new BankTrans();
						trans.setTransId(data[35]);
						trans.setTransDate(transDate);
						trans.setChannel(checkBillForm.getChannel());
						trans.setTransTime(date);
						trans.setAmount(transAmount.doubleValue());
						list.add(trans);
					}
				}
			} catch (IOException e) {
				throw new BusinessException(ExceptionDefine.对账文件格式错误);
			} catch (ParseException e) {
				e.printStackTrace();
			} finally {
				if (null != file){
					file.close();
				}
			}

		} else {
            list = loadTxt(file, checkBillForm);
        }
		return list;

	}

	/**
	 * 对账单TXT文件解析
	 * 
	 * @param file
	 * @param checkBillForm
	 * @return
	 * @throws BusinessException
	 * @throws IOException
	 */
	public static List<BankTrans> loadTxt(InputStream file, CheckBillForm checkBillForm)
			throws BusinessException, IOException {
		List<BankTrans> list = new ArrayList<BankTrans>();
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(file, "GBK"));
			for (String line = reader.readLine(); line != null; line = reader.readLine()) {
				if (line.trim().length() == 0) {
					continue;
				}
				String[] data = line.split("\\s+");
				if (data.length < 24) {
					throw new BusinessException(ExceptionDefine.对账文件格式错误);
				}
				// 交易时间
				String fDate = checkBillForm.getStartDate().substring(0,4) + data[4].substring(0, 4);
				Date date = new SimpleDateFormat("yyyyMMdd").parse(fDate);
				if (date == null) {
					throw new BusinessException(ExceptionDefine.对账文件格式错误);
				}
				// 订单号
				if (data[11].length() < 1) {
					throw new BusinessException(ExceptionDefine.对账文件格式错误);
				}
				// 金额
				BigDecimal transAmount = new BigDecimal(data[6]).divide(new BigDecimal(100)).setScale(2);
				BankTrans trans = new BankTrans();
				trans.setTransId(data[11]);
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
				simpleDateFormat.setLenient(false);
				Date transDate = new SimpleDateFormat("yyyyMMdd")
						.parse(checkBillForm.getStartDate().replace("-", "").trim());
				trans.setTransDate(transDate);
				trans.setChannel(checkBillForm.getChannel());
				trans.setTransTime(date);
				/*if(trans.getTransId().length()>Constants.TRANSiDLENGTH){
					trans.setTransTime(simpleDateFormat.parse(trans.getTransId().substring(Constants.FLAG_4, Constants.FLAG_12)));
				} else {
					trans.setTransTime(simpleDateFormat.parse(trans.getTransId().substring(Constants.FLAG_default, Constants.FLAG_8)));
				}*/
				trans.setAmount(transAmount.doubleValue());
				list.add(trans);
			}
		} catch (IOException e) {
			throw new BusinessException(ExceptionDefine.对账文件格式错误);
		} catch (ParseException e) {
			e.printStackTrace();
		} finally {
			if (null != file){
				file.close();
			}
		}
		return list;
	}

	/**
	 * 对账单Excel文件解析
	 * 
	 * @param file
	 * @param checkBillForm
	 * @return
	 * @throws BusinessException
	 * @throws IOException
	 */
	public static List<BankTrans> loadExcel(InputStream file, CheckBillForm checkBillForm)
			throws BusinessException, IOException {
		List<BankTrans> list = new ArrayList<BankTrans>();
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(file, "GBK"));
			int i = 0;
			for (String line = reader.readLine(); line != null; line = reader.readLine()) {
				if (line.trim().length() == 0) {
                    continue;
                }
				String[] data = line.split("\\s+");
				if (data.length < 24) {
					throw new BusinessException(ExceptionDefine.对账文件格式错误);
				}
				// 交易时间
				String fDate = data[9].substring(0, 13);
				Date date = new SimpleDateFormat("yyyyMMddHHmmss").parse(fDate);
				if (date == null) {
					throw new BusinessException(ExceptionDefine.对账文件格式错误);
				}
				// 订单号
				if (data[11].length() < 1) {
					throw new BusinessException(ExceptionDefine.对账文件格式错误);
				}
				// 金额
				BigDecimal transAmount = new BigDecimal(data[6]).divide(new BigDecimal(100)).setScale(2);
				BankTrans trans = new BankTrans();
				trans.setTransId(data[11]);
				Date transDate = new SimpleDateFormat("yyyyMMdd").parse(data[9].substring(0, 8));
				trans.setTransDate(transDate);
				trans.setChannel(checkBillForm.getChannel());
				trans.setTransTime(date);
				trans.setAmount(transAmount.doubleValue());
				i++;
				list.add(trans);
			}
		} catch (IOException e) {
			throw new BusinessException(ExceptionDefine.对账文件格式错误);
		} catch (ParseException e) {
			e.printStackTrace();
		} finally {
			if (null != file){
				file.close();
			}
		}
		return list;
	}

	/**
	 * 厦门民生对账解析Excel文件
	 * 
	 * @param file
	 * @param checkBillForm
	 * @return
	 * @throws BusinessException
	 * @throws IOException
	 */
	public static List<BankTrans> loadCmbcXm(InputStream file, CheckBillForm checkBillForm)
			throws BusinessException, IOException {
		HSSFSheet sheet;
		List<BankTrans> list = new ArrayList<BankTrans>();
		try {
			HSSFWorkbook workbook = new HSSFWorkbook(file);
			sheet = workbook.getSheetAt(0);// 得到上传Excel文件的第一页
		} catch (IOException e) {
			throw new BusinessException(ExceptionDefine.文件上传失败);
		} finally {
			if (null != file){
				file.close();
			}
		}
		if (sheet != null) {
			try {
				list = load(sheet, checkBillForm);
			} catch (ParseException e) {
				throw new BusinessException(ExceptionDefine.对账文件格式错误);
			}
		}
		return list;
	}

	private static List<BankTrans> load(HSSFSheet sheet, CheckBillForm checkBillForm)
			throws BusinessException, IOException, ParseException {
		List<BankTrans> list = new ArrayList<BankTrans>();
		HSSFRow row = null;
		int index = 0;
		// 获得最后一排数
		int rowNum = sheet.getLastRowNum() + 1;
		for (int i = 1; i <= rowNum; i++) {// 跳过第一行标题
			row = sheet.getRow(i);
			if (null != row) {
				// 排除交易失败数据行
				if (!row.getCell((short) 4).getStringCellValue().equals("E")) {
					// 解析Excel第2列
					String transId = row.getCell((short) 1).getStringCellValue();// 获取列值
					String date = row.getCell((short) 3).getStringCellValue();
					Date sdf = new SimpleDateFormat("yyyyMMdd").parse(date);
					// 判断交易金额类型解析不同格式
					String amount = "";
					BigDecimal transAmount = null;
					HSSFCell cell = row.getCell((short) 2);
					switch (cell.getCellType()) {
					// 数字、日期类型
					case HSSFCell.CELL_TYPE_NUMERIC:
						amount = String.valueOf(cell.getNumericCellValue());
						transAmount = new BigDecimal(amount);
						break;
					// 字符串类型
					case HSSFCell.CELL_TYPE_STRING:
						amount = cell.getStringCellValue();
						transAmount = new BigDecimal(amount);
						break;
					}

					BankTrans trans = new BankTrans();
					trans.setTransId(transId);
					trans.setTransDate(sdf);

					trans.setChannel(checkBillForm.getChannel());
					trans.setTransTime(sdf);
					trans.setAmount(transAmount.doubleValue());
					list.add(trans);
				}
			}
		}
		return list;
	}

	/**
	 * 对账单CSV文件解析
	 * 
	 * @param file
	 * @param checkBillForm
	 * @return
	 * @throws BusinessException
	 * @throws IOException
	 */
	public static List<BankTrans> loadCsv(InputStream file, CheckBillForm checkBillForm)
			throws BusinessException, IOException {
		List<BankTrans> list = new ArrayList<BankTrans>();
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(file, "GBK"));
			int i = 0;
			for (String line = reader.readLine(); line != null; line = reader.readLine()) {
				if (line.trim().length() == 0) {
                    continue;
                }
				String[] data = line.split("\\s+");
				if (data.length < 24) {
					throw new BusinessException(ExceptionDefine.对账文件格式错误);
				}
				// 交易时间
				String fDate = data[9].substring(0, 13);
				Date date = new SimpleDateFormat("yyyyMMddHHmmss").parse(fDate);
				if (date == null) {
					throw new BusinessException(ExceptionDefine.对账文件格式错误);
				}
				// 订单号
				if (data[11].length() < 1) {
					throw new BusinessException(ExceptionDefine.对账文件格式错误);
				}
				// 金额
				BigDecimal transAmount = new BigDecimal(data[6]).divide(new BigDecimal(100)).setScale(2);
				BankTrans trans = new BankTrans();
				trans.setTransId(data[11]);
				Date transDate = new SimpleDateFormat("yyyyMMdd").parse(data[9].substring(0, 8));
				trans.setTransDate(transDate);
				trans.setChannel(checkBillForm.getChannel());
				trans.setTransTime(date);
				trans.setAmount(transAmount.doubleValue());
				i++;
				list.add(trans);
			}
		} catch (IOException e) {
			throw new BusinessException(ExceptionDefine.对账文件格式错误);
		} catch (ParseException e) {
			e.printStackTrace();
		} finally {
			if (null != file) {
				file.close();
			}
		}
		return list;
	}

	public static List<BankTrans> loadxlsNew(InputStream file, CheckBillForm checkBillForm)
			throws BusinessException, IOException, ParseException {
		List<BankTrans> list = new ArrayList<BankTrans>();
		try {
			HSSFWorkbook workbook = new HSSFWorkbook(file);

			sheet = workbook.getSheetAt(0);
			Date date = loadDateFromTitle();
			int rowCount = sheet.getLastRowNum();
			for (int i = 1; i <= rowCount; i++) {
				String line = "";

				if (sheet.getRow(i) == null
						// 跳过无数据行
						|| sheet.getRow(i).getLastCellNum() == 0) {
					break;
				}
				line = getText(i);// 读取每一行

				if (line.length() > 1) {
					line = line.substring(1);
				}
				String[] data = line.split("#+");
				if (Constants.EGB_TYPE.equals(data[7])) {// 交易状态为成功时
					BankTrans trans = new BankTrans();

					// 交易时间
					Date transDate = new SimpleDateFormat("yyyyMMdd").parse(data[1].substring(0, 8));
					trans.setTransDate(transDate);
					trans.setTransTime(transDate);
					// 通道
					trans.setChannel(checkBillForm.getChannel());
					// 交易金额
					BigDecimal transAmount = new BigDecimal(data[4].trim());

					// 订单号 截取交易时间的前三位+订单号的第四个到最后一个
					String transId = data[0].trim().toString();
					trans.setTransId(transId);
					trans.setAmount(transAmount.doubleValue());
					list.add(trans);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
			// 版本错误
		} finally {
			if (null != file){
				file.close();
			}
		}
		return list;
	}

	public static List<BankTrans> loadxls(InputStream file, CheckBillForm checkBillForm)
			throws BusinessException, IOException, ParseException {
		List<BankTrans> list = new ArrayList<BankTrans>();
		try {
			HSSFWorkbook workbook = new HSSFWorkbook(file);

			sheet = workbook.getSheetAt(0);
			Date date = loadDateFromTitle();
			int rowCount = sheet.getLastRowNum();
			for (int i = 1; i <= rowCount; i++) {
				String line = "";

				if (sheet.getRow(i) == null
						// 跳过无数据行
						|| sheet.getRow(i).getLastCellNum() == 0) {
					break;
				}
				line = getText(i);// 读取每一行

				if (line.length() > 1) {
					line = line.substring(1);
				}
				String[] data = line.split("#+");
				if (Constants.EGB_TYPE.equals(data[7])) {// 交易状态为成功时
					BankTrans trans = new BankTrans();

					// 交易时间
					Date transDate = new SimpleDateFormat("yyyyMMdd").parse(data[1].substring(0, 8));
					trans.setTransDate(transDate);
					trans.setTransTime(transDate);
					// 通道
					trans.setChannel(checkBillForm.getChannel());
					// 交易金额
					BigDecimal transAmount = new BigDecimal(data[4].trim());

					// 订单号 截取交易时间的前三位+订单号的第四个到最后一个
					String transId = data[0].trim().toString();
					trans.setTransId(transId);
					trans.setAmount(transAmount.doubleValue());
					list.add(trans);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
			// 版本错误
		} finally {
			if (null != file){
				file.close();
			}
		}
		return list;
	}

	protected static String getText(int row) {

		HSSFRow hssfRow = sheet.getRow(row);
		int intColumnNum = hssfRow.getLastCellNum();

		String strLine = "";

		for (int i = 0; i < intColumnNum; i++) {
			String strValue = "";
			if (hssfRow.getCell((short) i) != null) {
				HSSFCell cell = hssfRow.getCell((short) i);
				// 根据单元格类型进行取值，并全部转换为字符串返回
				switch (cell.getCellType()) {
				// 布尔型
				case HSSFCell.CELL_TYPE_BOOLEAN:
					boolean booleanTemp = cell.getBooleanCellValue();
					strValue = String.valueOf(booleanTemp);
					break;

				// 数字、日期类型
				case HSSFCell.CELL_TYPE_NUMERIC:
					double dbTemp = cell.getNumericCellValue();

					strValue = String.valueOf(dbTemp);
					break;

				// 字符串类型
				case HSSFCell.CELL_TYPE_STRING:
					strValue = cell.getStringCellValue();
					break;

				// 其他类型
				default:
					strValue = cell.getStringCellValue();
				}
			}

			if (strValue.length() == 0) {
				strValue = " ";
			}
			// 如果是科学计数法, 转换成标准格式
			if (null != strValue && strValue.indexOf(".") != -1 && strValue.indexOf("E") != -1) {
				DecimalFormat df = new DecimalFormat();
				try {
					strValue = df.parse(strValue).toString();
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}

			strLine += FIELD_SEPARATOR + strValue;
		}

		return strLine;
	}

	/**
	 * 解析银盛csv文件
	 * 
	 * @param file
	 * @param checkBillForm
	 * @return
	 * @throws BusinessException
	 * @throws IOException
	 */
	public static List<BankTrans> loadyscsv(InputStream file, CheckBillForm checkBillForm)
			throws BusinessException, IOException {
		List<BankTrans> list = new ArrayList<BankTrans>();
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(file, "GBK"));
			String line;
			List<String[]> listdate = new ArrayList<String[]>();
			while ((line = reader.readLine()) != null) {
				String[] record = line.split(",");
				listdate.add(record);
			}
			for (int i = 3; i < listdate.size(); i++) {
				String[] data = listdate.get(i);
				if (data.length < 4) {
					throw new BusinessException(ExceptionDefine.对账文件格式错误);
				}
				// 交易时间
				String fDate = data[12].replace("\"", "").trim();
				Date date = new SimpleDateFormat("yyyyMMddHHmmss").parse(fDate.toString());
				if (date == null) {
					throw new BusinessException(ExceptionDefine.对账文件格式错误);
				}
				// 订单号
				if (data[1].replace("\"", "").trim().length() < 1) {
					throw new BusinessException(ExceptionDefine.对账文件格式错误);
				}
				// 金额
				BigDecimal transAmount = new BigDecimal(data[7].replace("\"", "").trim()).setScale(2,
						BigDecimal.ROUND_HALF_UP);
				if (null != data[10].replace("\"", "").trim() && data[10].replace("\"", "").trim().equals("00")) {
					BankTrans trans = new BankTrans();
					trans.setTransId(data[1].replace("\"", "").trim());
					Date transDate = new SimpleDateFormat("yyyyMMdd")
							.parse(data[11].replace("\"", "").trim().substring(0, 8));
					trans.setTransDate(transDate);
					trans.setChannel(checkBillForm.getChannel());
					trans.setTransTime(date);
					trans.setAmount(transAmount.doubleValue());
					list.add(trans);
				}
			}
		} catch (IOException e) {
			throw new BusinessException(ExceptionDefine.对账文件格式错误);
		} catch (ParseException e) {
			e.printStackTrace();
		} finally {
			if (null != file){
				file.close();
			}
		}
		return list;
	}

	
	/**
	 * 解析平安快捷对账单
	 * 
	 * @param file
	 * @param checkBillForm
	 * @return
	 * @throws BusinessException
	 * @throws IOException
	 */
	public static List<BankTrans> loadPingAnCsv(InputStream file, CheckBillForm checkBillForm)
			throws BusinessException, IOException {
		List<BankTrans> list = new ArrayList<BankTrans>();
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(file, "GBK"));
			String line;
			List<String[]> listdate = new ArrayList<String[]>();
			while ((line = reader.readLine()) != null) {
				String[] record = line.split(",");
				listdate.add(record);
			}
			for (int i = 1; i < listdate.size(); i++) {
				String[] data = listdate.get(i);
				if (data.length < 17) {
					continue;
				}
				// 交易时间
				String fDate = data[6].replace("\"", "").trim();
				Date date = new SimpleDateFormat("yyyyMMddHHmmss").parse(fDate.toString());
				if (date == null) {
					throw new BusinessException(ExceptionDefine.对账文件格式错误);
				}
				// 订单号
				if (data[1].replace("\"", "").trim().length() < 1) {
					throw new BusinessException(ExceptionDefine.对账文件格式错误);
				}
				// 金额
				BigDecimal transAmount = new BigDecimal(data[8].replace("\"", "").trim()).setScale(2,
						BigDecimal.ROUND_HALF_UP);
					BankTrans trans = new BankTrans();
					trans.setTransId(data[1].replace("\"", "").trim());
					Date checkDate = new SimpleDateFormat("yyyyMMdd")
							.parse(checkBillForm.getStartDate().replace("-", "").trim());
					trans.setTransDate(checkDate);
					trans.setChannel(checkBillForm.getChannel());
					trans.setTransTime(date);
					trans.setAmount(transAmount.doubleValue());
					list.add(trans);
			}
		} catch (IOException e) {
			throw new BusinessException(ExceptionDefine.对账文件格式错误);
		} catch (ParseException e) {
			e.printStackTrace();
		} finally {
			if (null != file){
				file.close();
			}
		}
		return list;
	}

	
	/**
	 * 解析民生b2c对账文件
	 * 
	 * @param file
	 * @param checkBillForm
	 * @return
	 * @throws BusinessException
	 * @throws IOException
	 */
	public static List<BankTrans> loadcmbcb2c(InputStream file, CheckBillForm checkBillForm)
			throws BusinessException, IOException {
		List<BankTrans> list = new ArrayList<BankTrans>();
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(file, "GBK"));
			String line;
			String str;
			String ftr="yyyy-MM-dd";
			Date transDate = new SimpleDateFormat("yyyyMMdd")
					.parse(checkBillForm.getStartDate().replace("-", "").trim());
			List<String[]> listdate = new ArrayList<String[]>();
			while ((line = reader.readLine()) != null) {
				String[] record = line.split(",");
				listdate.add(record);
			}
			if(0<listdate.size()&&listdate.get(9).length<7){
				ftr="yyyyMMdd";
				str=Constants.UPLOAD_CMBC_B2C_1;
			}
			else {
                str = Constants.UPLOAD_CMBC_B2C_2;
            }
			for (int i = 8; i < listdate.size(); i++) {
				String[] data = listdate.get(i);
				TxtMap map=getShellMap(str);
				if (data.length >= 6) {
					Date date = new SimpleDateFormat(ftr).parse(data[map.getTransDateshell()]);
					if (date == null) {
						throw new BusinessException(ExceptionDefine.对账文件格式错误);
					}
					// 订单号
					if (data[0].length() < 1) {
						throw new BusinessException(ExceptionDefine.对账文件格式错误);
					}
					// 金额
					BigDecimal transAmount = new BigDecimal(data[map.getTransAmountshell()].trim()).setScale(2, BigDecimal.ROUND_HALF_UP);
					BankTrans trans = new BankTrans();
					trans.setTransId(data[map.getTransIdshell()].trim().substring(6, data[0].trim().length()));

					trans.setTransDate(transDate);
					trans.setChannel(checkBillForm.getChannel());
					trans.setTransTime(date);
					trans.setAmount(transAmount.doubleValue());
					list.add(trans);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.对账文件格式错误);
		} finally {
			if (null != file){
				file.close();
			}
		}
		return list;
	}
	
	/**
	 * 解析获取CMBC_B2C shell字段位子
	 * 
	 * @param str
	 * @return
	 * @throws IOException
	 */
	public static TxtMap getShellMap(String str) throws Exception {
		String[] st = str.split(",");
		TxtMap txtMap = new TxtMap();
		txtMap.setStartLine(Integer.valueOf(st[0]));
		txtMap.setTransAmountshell(Integer.valueOf(st[1]));
		txtMap.setTransDateshell(Integer.valueOf(st[2]));
		txtMap.setTransIdshell(Integer.valueOf(st[3]));
		return txtMap;
	}
	
	/**
	 * 银联AT扫码对账单CSV文件解析
	 * 
	 * @param file
	 * @param checkBillForm
	 * @return
	 * @throws BusinessException
	 * @throws IOException
	 */
	public static List<BankTrans> loadUnionpayAtSmCsv(InputStream file, CheckBillForm checkBillForm)
			throws BusinessException, IOException {
		List<BankTrans> list = new ArrayList<BankTrans>();
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(file, "utf-8"));
			int i = 0;
			for (String line = reader.readLine(); line != null; line = reader.readLine()) {
				if (line.trim().length() == 0) {
                    continue;
                }
				if(i++ < 1){
					continue;
				}
				String[] data = line.split(",`");
				if (data.length < 19) {
					if (data.length == 1 || data.length == 7){
						continue;
					}
					throw new BusinessException(ExceptionDefine.对账文件格式错误);
				}
				// 交易时间
				String fDate = data[0].substring(1, 20);
				Date date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(fDate);
				if (date == null) {
					throw new BusinessException(ExceptionDefine.对账文件格式错误);
				}
				// 订单号
				if (data[6].length() < 1) {
					throw new BusinessException(ExceptionDefine.对账文件格式错误);
				}
				// 金额
				BigDecimal transAmount = new BigDecimal(data[18].trim());
				BankTrans trans = new BankTrans();
				trans.setTransId(data[6].trim());
				Date transDate = new SimpleDateFormat("yyyy-MM-dd").parse(data[0].trim().substring(1, 11));
				trans.setTransDate(transDate);
				trans.setChannel(checkBillForm.getChannel());
				trans.setTransTime(date);
				trans.setAmount(transAmount.doubleValue());
				list.add(trans);
			}
		} catch (IOException e) {
			throw new BusinessException(ExceptionDefine.对账文件格式错误);
		} catch (ParseException e) {
			e.printStackTrace();
		} finally {
			if (null != file) {
				file.close();
			}
		}
		return list;
	}
}
