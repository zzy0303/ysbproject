package com.uns.channel;

import com.uns.common.Constants;
import com.uns.model.BankTrans;
import com.uns.util.AnalyTxt;
import com.uns.web.form.CheckBillForm;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/4/16
 * @Modifyed By:
 */
public class ChannelHandleOutUnionpayXm extends ChannelHandleDefault  implements ChannelHandleInterface {
    @Override
    public List<BankTrans> loadDate(InputStream inputStream, CheckBillForm checkBillForm) throws Exception {
        return AnalyTxt.loadUnionpayXmTxt(inputStream, checkBillForm, Constants.UPLOAD_UNIONPAY_XM_OUT_TXT);
    }
    @Override
    public List<Map<String, Object>> getLocalTrans(Integer id) throws Exception {
        return super.getOutLocalTrans(id, Constants.UPLOAD_UNIONPAY_XM);
    }

    @Override
    public Map<String, Object> getLocalAmount(String channel, String checkDate) {
        return getOutLocalAmount(channel, checkDate);
    }

    @Override
    public List<String> getChannelList() throws Exception {
        return null;
    }
}
