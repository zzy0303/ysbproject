package com.uns.dao;

import java.util.List;
import java.util.Map;

import com.uns.model.CheckBill;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * 
 * 获取银生宝金额总汇
 * @author zhengyan.zhou
 *
 */
@Repository
public interface CheckBillAmountMapper {
		
	    //根据对账时间和通道查询对账记录
		Integer getBychannel(Map<String, String> map);

	//根据对账时间和通道查询对账记录
	List<Map> getByEpccChannel(Map<String, String> map);

		//删除当前时间的数据
		void deleterBySysTime(Map<String,String> map);

	//删除当前时间的数据
	void deleterBySysTimeBatch(Map<String,String> map);


	    Map<String,Object> getChannelCountNew(Map channel);
	    //获取代扣交易
	    Map<String,Object> getAllDkByChannel(Map<String, Object> dkMap);

	    Map<String,Object> getAllAuthDkByChannel(Map<String, Object> map);

	    Map<String,Object> getDkByChannel(Map<String, Object> map);
	    
	    Map<String,Object> getAuthDkByChannel(Map<String, Object> dkMap);

	    Map<String,Object> getNewDkByChannel(Map<String, Object> dkMap);
	    
	    Map<String,Object> getAllKjChannel(Map<String, String> paramMap);

	    Map<String,Object> getB2cTrans(Map<String, Object> paramMap);

	    Map<String,Object> getSmTrans2(Map<String, Object> paramMap);

	    Map<String,Object> getUnionpayKjChannel(Map<String, Object> paramMap);

	    Map<String,Object> getcmbcAmount(Map<String, String> paramMap);

	    Map<String,Object> getCncbB2cAmount(Map<String, String> paramMap);

	    Map<String,Object> getBocB2cCreditAmount(Map<String, String> paramMap);

	    Map<String,Object> getCmbcB2cAmount(Map<String, String> paramMap);

	    Map<String,Object> getB2BAmount(Map<String, String> paramMap);

        Map<String, Object> getYinlianKjAmount(Map<String, Object> paramMap);

        Map<String, Object> getPsbcDKjAmount(Map<String, Object> paramMap);

	    Map<String,Object> getkjAmount(Map<String, Object> paramMap);

	    Map<String, Object> getBocKjAmount(Map<String, Object> paramMap);

	    Map<String,Object> getOutAmount(Map<String, Object> paramMap); //出金银生宝

	    Map<String,Object> getOutNewDfAmount(Map<String, Object> paramMap); //出金新代付

	    Map<String,Object> getOutHfqdNewDfAmount(Map<String, Object> paramMap); //青岛银联新代付

	    Map<String,Object> getOutHfqdAmount(Map<String, Object> paramMap);

		Map<String,Object> getPinganKjAmount(Map<String, Object> paramMap);//pingan_kj

	    List<Map<String,Object>> getNetsUnionAmount(Map map);//网联金额统计

	    Map<String,Object> getOutNewTXAmount(Map<String, Object> map);//获取新提现的交易金额

		Map<String, Object> getChinaPayChannel(Map<String, Object> recordMap);//全渠道

    Map<String,Object> getUnionpayXmDpAmount(Map<String, Object> map);

		Map<String,Object> getUnionpayWgAmount(Map<String, Object> map);

		Map<String, Object> getUnionpayAtSmAmount(Map<String, Object> recordMap);//银联AT扫码
}
