package com.uns.channel;

import com.uns.common.Constants;
import com.uns.dao.CheckBillAmountMapper;
import com.uns.dao.CheckBillMapper;
import com.uns.dao.TransRefMapper;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.service.CheckBillService;
import com.uns.util.ChannelModel;
import com.uns.util.SpringContextHolder;
import com.uns.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/11/3
 * @Modifyed By:
 */

public class ChannelHandleDefault {

    CheckBillService checkBillService = SpringContextHolder.getBean(CheckBillService.class);

    CheckBillMapper checkBillMapper = SpringContextHolder.getBean(CheckBillMapper.class);

    CheckBillAmountMapper checkBillAmountMapper = SpringContextHolder.getBean(CheckBillAmountMapper.class);

    TransRefMapper transRefMapper = SpringContextHolder.getBean(TransRefMapper.class);

    Map<String, Object> pareMap = new HashMap<String, Object>();

    List<Map<String, Object>> localTrans = new ArrayList<>();

    List<String> channelTypeList = new ArrayList<>();

    /**
     * 获取生成记录日期
     *
     * @return
     */
    public String getExecuteTime() throws Exception {
        if (DynamicConfigLoader.getByEnv("UPLOAD_EXECUTE_TIME").equals("sysdate")) {
            return StringUtils.getSysDate();
        } else {
            return DynamicConfigLoader.getByEnv("UPLOAD_EXECUTE_TIME");
        }
    }

    public List<Map<String, Object>> getDkLocalTrans(Integer id, String channel) throws Exception {
        pareMap.put("channelType",
                checkBillService.getChannelType(channel, Constants.PARAM_CHECK_BILL_DK_CHANNEL));
        pareMap.put("id", id);
        localTrans = checkBillMapper.getDkTtrans(pareMap);
        localTrans.addAll(checkBillMapper.getLocalAuthTrans(pareMap));// 实名认证数据
        //新代扣交易
        localTrans.addAll(checkBillMapper.getlocalNewDkTrans(pareMap));
        //获取unionpay_b2b交易
        pareMap.put("actionType", Constants.UPLOAD_B2B_ACTIONTYPE);
        pareMap.put("channel",Constants.UPLOAD_UNIONPAY_B2B);
        localTrans.addAll( checkBillMapper.getUnionpayB2BTrans(pareMap));
        return localTrans;
    }

    public List<Map<String, Object>> getKjLocalTrans(Integer id, String channel) throws Exception {
        ChannelModel kj = new ChannelModel();
        pareMap.put("id", id);
        pareMap.put("channel", kj.getChannl().get(channel));
        pareMap.put("actionType", Constants.UPLOAD_KJ_ACTIONTYPE);
        return checkBillMapper.getKjTrans(pareMap);
    }

    public List<Map<String, Object>> getOutLocalTrans(Integer id, String channel) throws Exception {
        pareMap.put("id", id);
        pareMap.put("channel", channel);
        //获取银生宝代付交易
        localTrans = checkBillMapper.getOutTrans(pareMap);
        //获取分布式代付交易
        localTrans.addAll(checkBillMapper.getOutNewDf(pareMap));
        //获取分布式提现交易
        localTrans.addAll(checkBillMapper.getNewTXTrans(pareMap));
        return localTrans;
    }

    public Map<String, Object> getOutLocalAmount (String channel, String checkDate){
        Map<String, Object> map = new HashMap<>();
        map.put("channel", channel);
        map.put("dealDate", checkDate);
        Map<String, Object> recordMap = checkBillAmountMapper.getOutAmount(map);
        //获取新代付金额
        Map<String, Object> newDfMap = checkBillAmountMapper.getOutNewDfAmount(map);
        //获取新提现的金额
        Map<String, Object> newTXMap = checkBillAmountMapper.getOutNewTXAmount(map);

        recordMap.put("AMOUNT", Double.parseDouble(recordMap.get("AMOUNT").toString())
                + Double.parseDouble(newDfMap.get("AMOUNT").toString())
                + Double.parseDouble(newTXMap.get("AMOUNT").toString()));
        return recordMap;
    }



}
