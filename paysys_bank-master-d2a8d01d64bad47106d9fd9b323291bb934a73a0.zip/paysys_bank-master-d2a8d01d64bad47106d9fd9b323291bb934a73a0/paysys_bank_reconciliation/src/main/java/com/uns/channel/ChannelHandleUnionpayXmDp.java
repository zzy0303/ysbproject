package com.uns.channel;

import com.uns.common.Constants;
import com.uns.model.BankTrans;
import com.uns.util.AnalyExcel;
import com.uns.web.form.CheckBillForm;

import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/9/11
 * @Modifyed By:
 */
public class ChannelHandleUnionpayXmDp extends ChannelHandleDefault implements ChannelHandleInterface {


    @Override
    public List<BankTrans> loadDate(InputStream inputStream, CheckBillForm checkBillForm) throws Exception {
        return AnalyExcel.loadAllShell(inputStream, checkBillForm, Constants.UPLOAD_UNIONPAY_XM_DP_SHELL);
    }

    @Override
    public List<Map<String, Object>> getLocalTrans(Integer id) throws Exception {
        pareMap.put("id", id);
        return checkBillMapper.getUnionpayXmDpTrans(pareMap);
    }

    @Override
    public Map<String, Object> getLocalAmount(String channel, String checkDate) {
        Map<String, Object> map = new HashMap<>();
        map.put("dealDate", checkDate);
        Map<String, Object> recordMap = checkBillAmountMapper.getUnionpayXmDpAmount(map);
        return recordMap;
    }

    @Override
    public List<String> getChannelList() throws Exception {
        return null;
    }
}
