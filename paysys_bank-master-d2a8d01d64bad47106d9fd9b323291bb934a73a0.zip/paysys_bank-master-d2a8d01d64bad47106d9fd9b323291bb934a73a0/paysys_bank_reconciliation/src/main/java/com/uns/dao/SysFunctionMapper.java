package com.uns.dao;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.SysFunction;

@Repository
public interface SysFunctionMapper {

	int deleteByPrimaryKey(BigDecimal id);

	int insert(SysFunction record);

	int insertSelective(SysFunction record);

	SysFunction selectByPrimaryKey(BigDecimal id);

	int updateByPrimaryKeySelective(SysFunction record);

	int updateByPrimaryKey(SysFunction record);

	List getUserMenu(Long id);
}