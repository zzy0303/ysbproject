package com.uns.util;

import com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class JsonMessageConverter extends FastJsonHttpMessageConverter {

    private static final Logger logger = LoggerFactory.getLogger(JsonMessageConverter.class);

    @Override
    protected void writeInternal(Object obj, HttpOutputMessage outputMessage) throws IOException, HttpMessageNotWritableException {
        //响应消息头
//        outputMessage.getHeaders().set(RSCode.RS_NAME, RequestResponseContext.getResultCode());
        outputMessage.getHeaders().add("Content-Type", "application/json");
        //响应消息体
        if (obj == null) {
            return;
        }
        byte[] bytes;
        if (obj instanceof String) {
            bytes = obj.toString().getBytes("UTF-8");
        } else {
            bytes = FastJson.toJson(obj).getBytes("UTF-8");
        }

        OutputStream out = outputMessage.getBody();
        out.write(bytes);
    }

    @Override
    protected Object readInternal(Class<? extends Object> clazz, HttpInputMessage inputMessage) throws IOException, HttpMessageNotReadableException {
        //读取文件流
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        InputStream in = inputMessage.getBody();
        byte[] buf = new byte[1024];
        for (;;) {
            int len = in.read(buf);
            if (len == -1) {
                break;
            }
            if (len > 0) {
                baos.write(buf, 0, len);
            }
        }
        byte[] bytes = baos.toByteArray();

        String requestBody = new String(bytes, "UTF-8");
        Object requestObj = FastJson.fromJson(requestBody, clazz);
        return requestObj;
    }

}
