package com.uns.biz;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.uns.model.BankTrans;
import com.uns.model.CheckBill;
import com.uns.web.form.CheckBillForm;

public class DefaultBiz implements BizBaseInterface {

	@Override
	public List<Map<String, Object>> readBizValue(Integer id, Map<String, Object> maps,
			Map<String, List<String>> setting) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean checkInputData(String[] data, CheckBillForm checkBillForm, BankTrans trans,
			Map<String, List<String>> setting) throws Exception {

		List<String> input = setting.get("INPUT_LOCAL");
		List<String> dateFormat = setting.get("DATE_FORMAT");
		if (setting.containsKey("UNIT_CONV")) {
			double amount = 0.00000000000000000000000000000000000000000001;
			amount = trans.getAmount() / Integer.parseInt(setting.get("UNIT_CONV").get(0));
			trans.setAmount(amount);
		}

		if (!setting.containsKey("SUCCESS_STATUS")
				|| setting.get("SUCCESS_STATUS").contains(data[Integer.valueOf(input.get(6))])) {
			String dateFormatStr = dateFormat.get(1);
			Integer dateFormatIndex = Integer.parseInt(dateFormat.get(0));
			String dateStr = trans.getTransTimeStr().substring(dateFormatIndex, dateFormatStr.length());
			Date date = new SimpleDateFormat(dateFormatStr).parse(dateStr);
			trans.setTransTime(date);
			return true;
		}
		return false;
	}

	@Override
	public List<BankTrans> readBizBank(Map<String, Object> param) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean checkHandUp(BankTrans bankTrans, CheckBill cb) throws Exception {
		Date checkDate = cb.getCheckDate();
		Calendar ca = Calendar.getInstance();
		ca.setTime(checkDate);
		ca.add(Calendar.DAY_OF_MONTH, -1);
		// 上一对账日期
		Date lastDate = ca.getTime();

		String dateformat = "yyyyMMdd";
		String bankDateStr = bankTrans.getTransId().substring(0, dateformat.length());
		Date bankDate = new SimpleDateFormat(dateformat).parse(bankDateStr);

		if (lastDate.getTime() <= bankDate.getTime() && bankDate.getTime() < checkDate.getTime()) {
			return true;
		}

		return false;
	}
}
