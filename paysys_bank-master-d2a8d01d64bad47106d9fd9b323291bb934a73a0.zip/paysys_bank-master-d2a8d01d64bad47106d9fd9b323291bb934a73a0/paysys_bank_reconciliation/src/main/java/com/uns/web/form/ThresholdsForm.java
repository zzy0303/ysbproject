package com.uns.web.form;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/8/31
 * @Modifyed By:
 */
public class ThresholdsForm {

    private BigDecimal id;

    private String accountId;

    private String accountName;

    private String actionName;

    private Integer count;

    private BigDecimal sumAmount;

    private BigDecimal sumFee;

    private BigDecimal sumWaitAmount;

    private BigDecimal sumWaitAmountY;

    private BigDecimal sumWaitAmountT;

    private String checkDate;

    private String beginCheckDate;

    private String endCheckDate;

    private BigDecimal creditSeq;

    private BigDecimal actionSeq;

    private String countParam;

    private List<PreThresholdForm> thresholdFormList;

    public List<PreThresholdForm> getThresholdFormList() {
        return thresholdFormList;
    }

    public void setThresholdFormList(List<PreThresholdForm> thresholdFormList) {
        this.thresholdFormList = thresholdFormList;
    }

    public BigDecimal getSumWaitAmountY() {
        return sumWaitAmountY;
    }

    public void setSumWaitAmountY(BigDecimal sumWaitAmountY) {
        this.sumWaitAmountY = sumWaitAmountY;
    }

    public BigDecimal getSumWaitAmountT() {
        return sumWaitAmountT;
    }

    public void setSumWaitAmountT(BigDecimal sumWaitAmountT) {
        this.sumWaitAmountT = sumWaitAmountT;
    }

    private List<String> countParamList;

    private List<String> waitAmountList;

    private List<String> waitTurnAmountList;

    private String checkUser;

    public List<String> getWaitTurnAmountList() {
        return waitTurnAmountList;
    }

    public void setWaitTurnAmountList(List<String> waitTurnAmountList) {
        this.waitTurnAmountList = waitTurnAmountList;
    }

    public String getCheckUser() {
        return checkUser;
    }

    public void setCheckUser(String checkUser) {
        this.checkUser = checkUser;
    }

    public List<String> getCountParamList() {
        return countParamList;
    }

    public void setCountParamList(List<String> countParamList) {
        this.countParamList = countParamList;
    }

    public List<String> getWaitAmountList() {
        return waitAmountList;
    }

    public void setWaitAmountList(List<String> waitAmountList) {
        this.waitAmountList = waitAmountList;
    }

    public String getCountParam() {
        return countParam;
    }

    public void setCountParam(String countParam) {
        this.countParam = countParam;
    }

    public String getBeginCheckDate() {
        return beginCheckDate;
    }

    public void setBeginCheckDate(String beginCheckDate) {
        this.beginCheckDate = beginCheckDate;
    }

    public String getEndCheckDate() {
        return endCheckDate;
    }

    public void setEndCheckDate(String endCheckDate) {
        this.endCheckDate = endCheckDate;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getActionName() {
        return actionName;
    }

    public void setActionName(String actionName) {
        this.actionName = actionName;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public BigDecimal getSumAmount() {
        return sumAmount;
    }

    public void setSumAmount(BigDecimal sumAmount) {
        this.sumAmount = sumAmount;
    }

    public BigDecimal getSumFee() {
        return sumFee;
    }

    public void setSumFee(BigDecimal sumFee) {
        this.sumFee = sumFee;
    }

    public BigDecimal getSumWaitAmount() {
        return sumWaitAmount;
    }

    public void setSumWaitAmount(BigDecimal sumWaitAmount) {
        this.sumWaitAmount = sumWaitAmount;
    }

    public String getCheckDate() {
        return checkDate;
    }

    public void setCheckDate(String checkDate) {
        this.checkDate = checkDate;
    }

    public BigDecimal getCreditSeq() {
        return creditSeq;
    }

    public void setCreditSeq(BigDecimal creditSeq) {
        this.creditSeq = creditSeq;
    }

    public BigDecimal getActionSeq() {
        return actionSeq;
    }

    public void setActionSeq(BigDecimal actionSeq) {
        this.actionSeq = actionSeq;
    }
}
