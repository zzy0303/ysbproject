package com.uns.biz;

import java.util.List;
import java.util.Map;

import com.uns.model.BankTrans;
import com.uns.web.form.CheckBillForm;

public class BizCmbcB2c extends DefaultBiz {
	@Override
	public boolean checkInputData(String[] data, CheckBillForm checkBillForm, BankTrans trans,
								  Map<String, List<String>> setting) throws Exception {

		trans.setTransId(trans.getTransId().substring(6, trans.getTransId().length()));

		return super.checkInputData(data, checkBillForm, trans, setting);
	}
}
