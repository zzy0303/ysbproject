package com.uns.util;

import com.uns.common.Constants;
import com.uns.dao.AccountMapper;
import com.uns.model.Account;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/8/29
 * @Modifyed By:
 */
public class AccountUtils {

    private static AccountMapper accountMapper = SpringContextHolder.getBean(AccountMapper.class);

    public static List<Account> getAllAccount() {
        try {
            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
            HttpSession session = request.getSession();
            List<Account> accountList = (List<Account>) session.getAttribute(Constants.ACCOUNTLIST_SESSIONKEY);
            if (null == accountList || accountList.size() <= 0){
                accountList = accountMapper.selectAllAccount();
                session.setAttribute(Constants.ACCOUNTLIST_SESSIONKEY, accountList);
            }
            return accountList;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
