package com.uns.util;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONException;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;
import net.sf.json.util.CycleDetectionStrategy;

import org.apache.commons.lang.StringUtils;

import com.alibaba.fastjson.JSON;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uns.common.JsonDateValueProcessor;

/**
 * JSON 工具类
 * 
 * @author Administrator
 * 
 */
public class JsonUtil {
	private static ObjectMapper mapper = new ObjectMapper();

	/**
	 * 从一个JSON 对象字符格式中得到一个java对象
	 * 
	 * @param jsonString
	 * @param pojoCalss
	 * @return
	 */
	public static Object getObject4JsonString(String jsonString, Class pojoCalss) {
		Object pojo;
		JSONObject jsonObject = JSONObject.fromObject(jsonString);
		pojo = JSONObject.toBean(jsonObject, pojoCalss);
		return pojo;
	}

	/**
	 * 从json对象集合表达式中得到一个java对象列表
	 * 
	 * @param jsonString
	 * @param pojoClass
	 * @return
	 */
	public static List getList4Json(String jsonString, Class pojoClass) {
		JSONArray jsonArray = JSONArray.fromObject(jsonString);
		JSONObject jsonObject;
		Object pojoValue;
		List list = new ArrayList();
		for (int i = 0; i < jsonArray.size(); i++) {
			jsonObject = jsonArray.getJSONObject(i);
			pojoValue = JSONObject.toBean(jsonObject, pojoClass);
			list.add(pojoValue);
		}
		return list;
	}

	/**
	 * 将obj转为json字符串
	 * 
	 * @param obj
	 * @return
	 */
	public static String getJsonString4Object(Object obj) {
		JsonConfig jsonConfig = configJson(null, null);
		JSONObject jsonObject = JSONObject.fromObject(obj, jsonConfig);
		return jsonObject.toString();
	}

	/**
	 * 将list转为json字符串
	 * 
	 * @param list
	 * @return
	 */
	public static String getJsonString4List(List list) {
		JsonConfig jsonConfig = configJson(null, null);
		JSONArray jsonArray = JSONArray.fromObject(list, jsonConfig);
		return jsonArray.toString();
	}

	/**
	 * 除去不想生成的字段（特别适合去掉级联的对象）+时间转换
	 * 
	 * @param excludes
	 *            除去不想生成的字段
	 * @param datePattern
	 * @return
	 */
	public static String getJsonString4Object(Object obj, String[] excludes) {
		JsonConfig jsonConfig = configJson(excludes, null);
		JSONObject jsonObject = JSONObject.fromObject(obj, jsonConfig);
		return jsonObject.toString();
	}

	/**
	 * 将list转为json字符串
	 * 
	 * @param list
	 * @return
	 */
	public static String getJsonString4List(List list, String[] excludes) {
		JsonConfig jsonConfig = configJson(excludes, null);
		JSONArray jsonArray = JSONArray.fromObject(list, jsonConfig);
		return jsonArray.toString();
	}

	/**
	 * 除去不想生成的字段（特别适合去掉级联的对象）+时间转换
	 * 
	 * @param excludes
	 *            除去不想生成的字段 为空，则不排除任何字段
	 * @param datePattern
	 *            为空时，则使用默认的yyyy-MM-dd HH:mm:ss格式
	 * @return
	 */
	public static JsonConfig configJson(String[] excludes, String datePattern) {
		JsonConfig jsonConfig = new JsonConfig();

		if (excludes != null && excludes.length > 0) {
			jsonConfig.setExcludes(excludes);
		}

		jsonConfig.setIgnoreDefaultExcludes(true);
		jsonConfig.setCycleDetectionStrategy(CycleDetectionStrategy.LENIENT);

		if (StringUtils.isNotBlank(datePattern)) {
			jsonConfig.registerJsonValueProcessor(Date.class, new JsonDateValueProcessor(datePattern));
		} else {
			jsonConfig.registerJsonValueProcessor(Date.class, new JsonDateValueProcessor());
		}

		return jsonConfig;
	}

	public static List<Map> strToList(String str) throws Exception {
		return mapper.readValue(str, new TypeReference<List<Map>>() {
		});
	}

	/**
	 * 将一个对象转换成目标对象
	 * 
	 * @param src
	 * @param dest
	 * @return
	 */
	public static <T> T copyProperties(Object src, Class<T> dest) throws Exception {
		return mapper.readValue(mapper.writeValueAsString(src), dest);
	}

	public static <T> T copyProperties(Object src, JavaType type) throws Exception {
		return mapper.readValue(mapper.writeValueAsString(src), type);
	}

	public static JavaType getCollectionType(Class<?> collectionClass, Class<?>... elementClasses) {
		return mapper.getTypeFactory().constructParametricType(collectionClass, elementClasses);
	}

	public static <T> T readParams(String params, Class<T> clz) {
		try {
			return mapper.readValue(params, clz);
		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static <T> T readValue(InputStream content, Class<T> type) throws Exception {
		return mapper.readValue(content, type);
	}

	public static <T> T readValue(String url, Class<T> clz) {
		try {
			URL u = new URL(url);
			return mapper.readValue(u, clz);

		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static <T> T readValue(String url, String params, Class<T> clz) {
		try {
			String param = "?params=" + params;
			URL u = new URL(url + param);
			return mapper.readValue(u, clz);

		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static String toJSONString(Object o) throws JSONException {
		/* return JSONObject.toJSONString(o); */
		try {
			return mapper.writeValueAsString(o);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * @param jsonStr
	 * @return json 字符串转换成 Map
	 */
	public static Map jsonStrToMap(String jsonStr) {
		Map map = (Map) JSON.parse(jsonStr);
		return map;
	}

}
