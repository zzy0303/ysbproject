package com.uns.channel;

import com.uns.common.Constants;
import com.uns.util.ChannelConstants;

import java.util.HashMap;
import java.util.Map;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/10/20
 * @Modifyed By:
 */
public class ChannelHandleMapping {

    private Map<String, ChannelHandleInterface> channelMap;
    private static ChannelHandleMapping channelHandleMapping;

    public ChannelHandleMapping (){
        channelMap = new HashMap<>();

        channelMap.put(ChannelConstants.CHANNEL_CMBC_XM_B2C, new ChannelHandleCmbcXmB2c());
        channelMap.put(ChannelConstants.CHANNEL_BOSH_DK, new ChannelHandleBoshDk());
        channelMap.put(ChannelConstants.CHANNEL_CMBC_CD, new ChannelHandleCmbcCd());
        channelMap.put(ChannelConstants.CHANNEL_ICBC_B2C, new ChannelHandleIcbcB2c());
        channelMap.put(ChannelConstants.CHANNEL_BOSH_B2C, new ChannelHandleBoshB2c());
        channelMap.put(ChannelConstants.CHANNEL_PIINGAN_B2C, new ChannelHandlePinganB2c());
        channelMap.put(ChannelConstants.CHANNEL_GDB_B2C, new ChannelHandleGdbB2c());
        channelMap.put(ChannelConstants.CHANNEL_ABC_B2C, new ChannelHandleAbcB2c());
        channelMap.put(ChannelConstants.CHANNEL_CMB_B2C, new ChannelHandleCmbB2c());
        channelMap.put(ChannelConstants.CHANNEL_CCB_B2C, new ChannelHandleCcbB2c());
        channelMap.put(ChannelConstants.CHANNEL_PSBC_B2C, new ChannelHandlePsbcB2c());
        channelMap.put(ChannelConstants.CHANNEL_SPDB_B2C, new ChannelHandleSpdbB2c());
        channelMap.put(ChannelConstants.CHANNEL_HXB_B2C, new ChannelHandleHxbB2c());
        channelMap.put(ChannelConstants.CHANNEL_CNCB_B2C, new ChannelHandleCncbB2c());
        channelMap.put(ChannelConstants.CHANNEL_CIB_B2C, new ChannelHandleCibB2c());
        channelMap.put(ChannelConstants.CHANNEL_CMBC_B2C, new ChannelHandleCmbcB2c());
        channelMap.put(ChannelConstants.CHANNEL_CEB_B2C, new ChannelHandleCebB2c());
        channelMap.put(ChannelConstants.CHANNEL_BOC_B2C, new ChannelHandleBocB2c());
        channelMap.put(ChannelConstants.CHANNEL_HXB_KJ, new ChannelHandleHxbKj());
        channelMap.put(ChannelConstants.CHANNEL_SPDB_KJ, new ChannelHandleSpdbKj());
        channelMap.put(ChannelConstants.CHANNEL_CEB_KJ, new ChannelHandleCebKj());
        channelMap.put(ChannelConstants.CHANNEL_BOSH_KJ, new ChannelHandleBoshKj());
        channelMap.put(ChannelConstants.CHANNEL_CMBC_XM_KJ, new ChannelHandleCmbcXmKj());
        channelMap.put(ChannelConstants.CHANNEL_CMBC_XM_SM, new ChannelHandleCmbcXmSm());
        channelMap.put(ChannelConstants.CHANNEL_SPDB_DK, new ChannelHandleSpdbDk());
        channelMap.put(ChannelConstants.CHANNEL_PINGAN_DK, new ChannelHandlePinganDk());
        channelMap.put(ChannelConstants.CHANNEL_CCB_KJ, new ChannelHandleCcbKj());
        channelMap.put(ChannelConstants.CHANNEL_ICBC_B2B, new ChannelHandleIcbcB2b());
        channelMap.put(ChannelConstants.CHANNEL_CMB_SM, new ChannelHandleCmbSm());
        channelMap.put(ChannelConstants.CHANNEL_UNIONPAY_TD, new ChannelHandleUnionpayTd());
        channelMap.put(ChannelConstants.CHANNEL_UNIONPAY_TD2, new ChannelHandleUnionpayTd2());
        channelMap.put(ChannelConstants.CHANNEL_UNIONPAY_WL, new ChannelHandleUnionpayWl());
        channelMap.put(ChannelConstants.CHANNEL_EGB, new ChannelHandleEgb());
        channelMap.put(ChannelConstants.CHANNEL_EGB_PROB, new ChannelHandleEgbProb());
        channelMap.put(ChannelConstants.CHANNEL_EGB_PROC, new ChannelHandleEgbProc());
        channelMap.put(ChannelConstants.CHANNEL_YS, new ChannelHandleYs());
        channelMap.put(ChannelConstants.CHANNEL_WS, new ChannelHandleWs());
        channelMap.put(ChannelConstants.CHANNEL_CMBC_XM_DK, new ChannelHandleCmbcXmDk());
        channelMap.put(ChannelConstants.CHANNEL_UNIONPAY, new ChannelHandleUnionpay());
        channelMap.put(ChannelConstants.CHANNEL_BESTPAY, new ChannelHandleBestpay());
        channelMap.put(ChannelConstants.CHANNEL_YILIAN_KJ, new ChannelHandleYilianKj());
        channelMap.put(ChannelConstants.CHANNEL_UPOP_B2C, new ChannelHandleUpopB2c());
        channelMap.put(ChannelConstants.CHANNEL_UPOP_D_DC_B2C, new ChannelHandleUpopDDcB2c());
        channelMap.put(ChannelConstants.CHANNEL_UNIONPAY_CQ, new ChannelHandleUnionpayCq());
        channelMap.put(ChannelConstants.CHANNEL_UNIONPAY_XM, new ChannelHandleUnionpayXm());
        channelMap.put(ChannelConstants.CHANNEL_NY, new ChannelHandleNy());
        channelMap.put(ChannelConstants.CHANNEL_UMPAY, new ChannelHandleUmpay());
        channelMap.put(ChannelConstants.CHANNEL_UPOP_SM, new ChannelHandleUpopSm());
        channelMap.put(ChannelConstants.CHANNEL_UNIONPAY_XM_DK, new ChannelHandleUnionpayXmDk());
        channelMap.put(ChannelConstants.CHANNEL_BFBPAY_DK, new ChannelHandleBfbpayDk());
        channelMap.put(ChannelConstants.CHANNEL_EPAY_DK, new ChannelHandleEpayDk());
        channelMap.put(ChannelConstants.CHANNEL_BOC_KJ, new ChannelHandleBocKj());
        channelMap.put(ChannelConstants.CHANNEL_YIFUBAO, new ChannelHandleYifubao());
        channelMap.put(ChannelConstants.CHANNEL_CIB_SM, new ChannelHandleCibSm());
        channelMap.put(ChannelConstants.CHANNEL_PINGAN_XM_DK, new ChannelHandlePingAnXmDk());
        channelMap.put(ChannelConstants.CHANNEL_SPDB_CROSSBANK_DK, new ChannelHandleSpdbCbDk());
        channelMap.put(ChannelConstants.CHANNEL_YINLIAN_KJ, new ChannelHandleYinlianKj());
        channelMap.put(ChannelConstants.CHANNEL_PSBC_D_KJ, new ChannelHandlePsbcDKj());//邮储快捷
        channelMap.put(ChannelConstants.CHANNEL_BOSH, new ChannelHandleBosh());
        channelMap.put(ChannelConstants.CHANNEL_HFQD, new ChannelHandleHfqd());
        channelMap.put(ChannelConstants.CHANNEL_CEB_B2B, new ChannelhandleCebB2B());
        channelMap.put(ChannelConstants.CHANNEL_OUT_UNIONPAY_XM, new ChannelHandleOutUnionpayXm());
        channelMap.put(ChannelConstants.CHANNEL_CCB_B2B, new ChannelHandleCcbB2b());
        channelMap.put(ChannelConstants.CHANNEL_PINGAN_KJ, new ChannelHandlePinganKj());
        channelMap.put(ChannelConstants.CHANNEL_TJ_UNIONPAY, new ChannelHandleTjUnionpay());
        channelMap.put(ChannelConstants.CHANNEL_NETS_UNION, new ChannelHandleNetsUnion());
        channelMap.put(ChannelConstants.CHANNEL_TJ_UNIONPAY_T0, new ChannelHandleTjUnionpayT0());
        channelMap.put(ChannelConstants.CHANNEL_YLZ_DO, new ChannelHandleYLZ());
        channelMap.put(ChannelConstants.CHANNEL_CHINAPAY, new ChannelHandleChinaPay());
        channelMap.put(ChannelConstants.CHANNEL_UNIONPAY_WG, new ChannelHandleUnionpayWg());
        channelMap.put(ChannelConstants.CHANNEL_UNIONPAY_XM_DP, new ChannelHandleUnionpayXmDp());
        channelMap.put(ChannelConstants.CHANNEL_UNIONPAY_AT_SM, new ChannelHandleUnionpayAtSm());
        channelMap.put(ChannelConstants.CHANNEL_YILIAN_DK, new ChannelHandleYilianDk());
        channelMap.put(ChannelConstants.CHANNEL_UNIONPAY_BH, new ChannelHandleUnionpayBh());
        channelMap.put(ChannelConstants.CHANNEL_UNIONPAY_BHT0, new ChannelHandleUnionpayBht0());
    }

    /**
     * 通过对账渠道 获取不同渠道对账单解析类对象
     * @param channel
     * @return
     */
    public static ChannelHandleInterface handleInterface (String channel){
        if (null == channelHandleMapping){
            channelHandleMapping = new ChannelHandleMapping();
        }

        if (channelHandleMapping.channelMap.containsKey(channel)){
            return channelHandleMapping.channelMap.get(channel);
        }

        if (channel.contains("_")) {
            channel = new StringBuffer(channel.substring(0, channel.indexOf("_"))).append("_").append(Constants.DEFAULT).toString();
            if (channelHandleMapping.channelMap.containsKey(channel)){
                return channelHandleMapping.channelMap.get(channel);
            }
        }

        return channelHandleMapping.channelMap.get(Constants.DEFAULT);
    }

    public Map<String, ChannelHandleInterface> getChannelMap() {
        return channelMap;
    }
}
