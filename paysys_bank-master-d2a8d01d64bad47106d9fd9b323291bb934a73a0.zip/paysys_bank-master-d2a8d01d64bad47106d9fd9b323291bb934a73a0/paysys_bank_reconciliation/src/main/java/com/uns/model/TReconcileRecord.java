package com.uns.model;

import java.math.BigDecimal;
import java.util.Date;

public class TReconcileRecord {
	private BigDecimal id;

	private Date reconcileDate;

	private BigDecimal bankInfoSeq;

	private BigDecimal uniformCount;

	private BigDecimal unilateralCount;

	private BigDecimal dubiousCount;

	private BigDecimal dubious2UniformCount;

	private BigDecimal dubious2UnilateralCount;

	private BigDecimal dubiousReasonChangeCount;

	private BigDecimal version;

	private String createUser;

	private Date createTime;

	private String updateUser;

	private Date updateTime;

	private BigDecimal processedCount;

	private BigDecimal channelSeq;

	private byte[] bankFile;

	public BigDecimal getId() {
		return id;
	}

	public void setId(BigDecimal id) {
		this.id = id;
	}

	public Date getReconcileDate() {
		return reconcileDate;
	}

	public void setReconcileDate(Date reconcileDate) {
		this.reconcileDate = reconcileDate;
	}

	public BigDecimal getBankInfoSeq() {
		return bankInfoSeq;
	}

	public void setBankInfoSeq(BigDecimal bankInfoSeq) {
		this.bankInfoSeq = bankInfoSeq;
	}

	public BigDecimal getUniformCount() {
		return uniformCount;
	}

	public void setUniformCount(BigDecimal uniformCount) {
		this.uniformCount = uniformCount;
	}

	public BigDecimal getUnilateralCount() {
		return unilateralCount;
	}

	public void setUnilateralCount(BigDecimal unilateralCount) {
		this.unilateralCount = unilateralCount;
	}

	public BigDecimal getDubiousCount() {
		return dubiousCount;
	}

	public void setDubiousCount(BigDecimal dubiousCount) {
		this.dubiousCount = dubiousCount;
	}

	public BigDecimal getDubious2UniformCount() {
		return dubious2UniformCount;
	}

	public void setDubious2UniformCount(BigDecimal dubious2UniformCount) {
		this.dubious2UniformCount = dubious2UniformCount;
	}

	public BigDecimal getDubious2UnilateralCount() {
		return dubious2UnilateralCount;
	}

	public void setDubious2UnilateralCount(BigDecimal dubious2UnilateralCount) {
		this.dubious2UnilateralCount = dubious2UnilateralCount;
	}

	public BigDecimal getDubiousReasonChangeCount() {
		return dubiousReasonChangeCount;
	}

	public void setDubiousReasonChangeCount(BigDecimal dubiousReasonChangeCount) {
		this.dubiousReasonChangeCount = dubiousReasonChangeCount;
	}

	public BigDecimal getVersion() {
		return version;
	}

	public void setVersion(BigDecimal version) {
		this.version = version;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser == null ? null : createUser.trim();
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser == null ? null : updateUser.trim();
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public BigDecimal getProcessedCount() {
		return processedCount;
	}

	public void setProcessedCount(BigDecimal processedCount) {
		this.processedCount = processedCount;
	}

	public BigDecimal getChannelSeq() {
		return channelSeq;
	}

	public void setChannelSeq(BigDecimal channelSeq) {
		this.channelSeq = channelSeq;
	}

	public byte[] getBankFile() {
		return bankFile;
	}

	public void setBankFile(byte[] bankFile) {
		this.bankFile = bankFile;
	}
}