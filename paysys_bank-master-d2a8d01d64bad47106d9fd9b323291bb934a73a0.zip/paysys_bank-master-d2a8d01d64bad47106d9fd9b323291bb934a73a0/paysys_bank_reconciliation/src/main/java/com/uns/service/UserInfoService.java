package com.uns.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.dao.UserInfoMapper;
import com.uns.model.UserInfo;

@Service
public class UserInfoService {
	@Autowired
	private UserInfoMapper userInfoMapper;

	public UserInfo selectUserInfoByName(String loginName) throws Exception {
		List<UserInfo> list = userInfoMapper.selectUserInfoByName(loginName);
		if (list != null && list.size() > 1) {
            throw new BusinessException(ExceptionDefine.存在同名用户请联系管理员);
        }
		return (list == null || list.size() == 0) ? null : list.get(0);
	}

	public void updateByPrimaryKey(UserInfo ui) throws Exception {
		userInfoMapper.updateByPrimaryKey(ui);

	}

}
