package com.uns.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.CheckBillTransDetail;
import com.uns.web.form.TransDetailForm;
import com.uns.web.form.TransRefForm;

@Repository
public interface DealTransMapper {

	List<Object>  getDealLocalTransList(TransDetailForm transDetailForm);

	List<CheckBillTransDetail> getDealBankTransList(TransDetailForm transDetailForm);

	List<Object> getDealApplyList(TransDetailForm transDetailForm);
	
	List<String> getTransIdList(Map<String, Object> map);

	List<Object> getOutDealLocalTransList(TransDetailForm transDetailForm);

	List<Map> getNetsUnionDealLocalTransList(TransDetailForm transDetailForm);

	List<Object> getNetsUnionDealLocalTransListExport(TransDetailForm transDetailForm);

	List<Map> getNetsUnionTransList(TransRefForm transRefForm);//网联交易查询

	List<Object> getNetsUnionTransDateExport(TransRefForm transRefForm);//网联交易查询导出
	
}
