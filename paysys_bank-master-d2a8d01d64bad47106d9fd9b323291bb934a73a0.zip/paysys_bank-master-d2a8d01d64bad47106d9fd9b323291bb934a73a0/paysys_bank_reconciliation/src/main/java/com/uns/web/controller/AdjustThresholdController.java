package com.uns.web.controller;

import java.io.OutputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.model.AdjustThreshold;
import com.uns.service.ThresholdService;
import com.uns.util.PoiUtils;
import com.uns.web.form.ThresholdForm;

@Controller
@RequestMapping(value = "/adjustThreshold.htm")
public class AdjustThresholdController {
	@Autowired
	private ThresholdService adjustService;
	
	/**
	 * 获取阀值调整列表
	 * @return
	 */
	@RequestMapping(params = "method=ThresholdList")
	@FormToken(save = true)
	public String ThresholdList(HttpServletRequest request,ThresholdForm thresholdForm){
		//获取交易类型
		List<String> actionNameList=adjustService.getActionName();
		List<AdjustThreshold> list=adjustService.getThresholdList(thresholdForm);
		request.setAttribute("actionNameList", actionNameList);
		request.setAttribute("list", list);
		request.setAttribute("thresholdForm", thresholdForm);
		//通道
		request.setAttribute("directChannel", Constants.CHECK_BILL_CHANNEL_DIRECT.split(","));
		request.setAttribute("inDirectChannel",  Constants.CHECK_BILL_CHANNEL_INDIRECT.split(","));
		return "threshold/thresholdList";
		
	}
	
	/**
	 * 导出阈值调整文件
	 * @return
	 */
	@RequestMapping(params = "method=toExport")
	@FormToken(save = true)
	public String toExport(HttpServletRequest request,HttpServletResponse response,ThresholdForm thresholdForm){
		List<AdjustThreshold> list=adjustService.getThresholdList(thresholdForm);
		try {
			OutputStream out = response.getOutputStream();
			response.reset();
			response.setHeader("content-disposition",
					"attachment;filename=" + new String((Constants.thresholdTitle).getBytes("gb2312"), "ISO8859-1") + ".xls");
			response.setContentType("APPLICATION/msexcel");
			PoiUtils.exportThresholdExcel(Constants.thresholdTitle, Constants.thresholdColnum, list, out, Constants.DEFAULT_DATE_FORMAT);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return null;
		
	}
		
	/**
	 * 阀值调整跳转页面
	 * @param request
	 * @param response
	 * @param thresholdForm
	 * @return
	 */
	@RequestMapping(params = "method=adjsutThreshold")
	@FormToken(save = true)
	public String adjsutThreshold(HttpServletRequest request,HttpServletResponse response,ThresholdForm thresholdForm){
		String id=(String)request.getParameter("id");
		try{
			if(!"".equals("id")&&null!=id){
				List<String> accountNameList=adjustService.getAccountList(id);
			}
		}
		catch(Exception e1){
			e1.printStackTrace();
		}
		return null;
		
	}
}
