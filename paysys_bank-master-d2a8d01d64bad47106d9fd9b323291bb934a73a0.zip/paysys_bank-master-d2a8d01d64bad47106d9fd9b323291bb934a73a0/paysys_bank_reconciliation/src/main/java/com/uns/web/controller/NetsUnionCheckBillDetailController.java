package com.uns.web.controller;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.model.CheckBillTransDetail;
import com.uns.service.CheckBillTransDetailService;
import com.uns.service.NetsUnionTransDetailService;
import com.uns.service.OutTransDetailService;
import com.uns.util.StringUtils;
import com.uns.web.form.TransDetailForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping(value = "/netsUnionCheckBillDetail.htm")
public class NetsUnionCheckBillDetailController extends BaseController{

    @Autowired
    private CheckBillTransDetailService checkBillTransDetailService;

    @Autowired
    private NetsUnionTransDetailService netsUnionTransDetailService;
    /**
     * 跳转网联对账交易详情列表
     * @param request
     * @param transDetailForm
     * @return
     * @throws BusinessException
     */
    @RequestMapping(params = "method=toTransDetailList")
    @FormToken(save = true)
    public String toTransDetailList(HttpServletRequest request, TransDetailForm transDetailForm){
        List<CheckBillTransDetail> checkBillTransDetailList = null;
        //条件为空默认前一天时间
        if(null == transDetailForm.getStartDate()){
            transDetailForm.setStartDate(StringUtils.getBeforDate());
        }
        if(null == transDetailForm.getEndDate()){
            transDetailForm.setEndDate(StringUtils.getBeforDate());
        }
        try {
            checkBillTransDetailList = netsUnionTransDetailService.getTransDetailList(transDetailForm);
            String getNumAmount = netsUnionTransDetailService.getNumAmount(transDetailForm);
            request.setAttribute("list", checkBillTransDetailList);
            request.setAttribute("transDetailForm", transDetailForm);
            request.setAttribute("getNumAmount", getNumAmount);
        } catch (Exception e) {
            log.info(e.getMessage());
        }
        String[] netsUnionChannel = Constants.NETS_UNION_CHECK_BILL_CHANNEL.split(",");
        request.setAttribute("netsUnionChannel", netsUnionChannel);
        return "netsUnionCheckbill/netsUnionTransDetailList";
    }

    /**
     * 网联未处理差异列表
     *
     * @return
     */
    @RequestMapping(params = "method=toDealDifferRecord")
    @FormToken(save = true)
    public String toDealDifferRecord(HttpServletRequest request, TransDetailForm transDetailForm)
            throws BusinessException {
        try {
            transDetailForm.setStartDate(StringUtils.getdate(transDetailForm.getCheckdate()));
            transDetailForm.setEndDate(StringUtils.getdate(transDetailForm.getCheckdate()));
            //查询未处理交易
            List<CheckBillTransDetail> checkBillTransDetailList = checkBillTransDetailService.getNetsUnionDifferTransList(transDetailForm);
            request.setAttribute("list", checkBillTransDetailList);
            request.setAttribute("transDetailForm", transDetailForm);
            String[] netsUnionChannel = Constants.NETS_UNION_CHECK_BILL_CHANNEL.split(",");
            request.setAttribute("netsUnionChannel", netsUnionChannel);
            return "netsUnionCheckbill/netsUnionTransDetailList";
        } catch (Exception e) {
            log.info(e.getMessage());
        }
        return null;
    }
}
