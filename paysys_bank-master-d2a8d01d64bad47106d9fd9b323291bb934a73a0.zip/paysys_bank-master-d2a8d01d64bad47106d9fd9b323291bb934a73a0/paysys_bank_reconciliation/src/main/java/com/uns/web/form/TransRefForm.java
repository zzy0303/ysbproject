package com.uns.web.form;

import java.math.BigDecimal;
import java.util.Date;

public class TransRefForm {

    private BigDecimal id;

    private String epccTransId;

    private String transId;

    private String transTime;

    private String transStatus;

    private String serviceType;

    private String payOrgIdSeq;

    private String destOrgIdSeq;

    private String transType;

    private BigDecimal transAmount;

    private String batchId;

    private Date createTime;

    private String creator;

    private Date updateTime;

    private String updator;

    private String source;

    private BigDecimal accountSeq;

    private BigDecimal checkBillTransDetailId;
    
	private String startDate;

	private String endDate;

    public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public BigDecimal getCheckBillTransDetailId() {
        return checkBillTransDetailId;
    }

    public void setCheckBillTransDetailId(BigDecimal checkBillTransDetailId) {
        this.checkBillTransDetailId = checkBillTransDetailId;
    }

    public BigDecimal getAccountSeq() {
        return accountSeq;
    }

    public void setAccountSeq(BigDecimal accountSeq) {
        this.accountSeq = accountSeq;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getTransId() {
        return transId;
    }

    public void setTransId(String transId) {
        this.transId = transId == null ? null : transId.trim();
    }

    public String getTransTime() {
        return transTime;
    }

    public void setTransTime(String transTime) {
        this.transTime = transTime == null ? null : transTime.trim();
    }

    public String getTransStatus() {
        return transStatus;
    }

    public void setTransStatus(String transStatus) {
        this.transStatus = transStatus == null ? null : transStatus.trim();
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType == null ? null : serviceType.trim();
    }

    public String getPayOrgIdSeq() {
        return payOrgIdSeq;
    }

    public void setPayOrgIdSeq(String payOrgIdSeq) {
        this.payOrgIdSeq = payOrgIdSeq == null ? null : payOrgIdSeq.trim();
    }

    public String getDestOrgIdSeq() {
        return destOrgIdSeq;
    }

    public void setDestOrgIdSeq(String destOrgIdSeq) {
        this.destOrgIdSeq = destOrgIdSeq == null ? null : destOrgIdSeq.trim();
    }

    public String getTransType() {
        return transType;
    }

    public void setTransType(String transType) {
        this.transType = transType == null ? null : transType.trim();
    }

    public BigDecimal getTransAmount() {
        return transAmount;
    }

    public void setTransAmount(BigDecimal transAmount) {
        this.transAmount = transAmount;
    }

    public String getBatchId() {
        return batchId;
    }

    public void setBatchId(String batchId) {
        this.batchId = batchId == null ? null : batchId.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdator() {
        return updator;
    }

    public void setUpdator(String updator) {
        this.updator = updator == null ? null : updator.trim();
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source == null ? null : source.trim();
    }

    public String getEpccTransId() {
        return epccTransId;
    }

    public void setEpccTransId(String epccTransId) {
        this.epccTransId = epccTransId == null ? null : epccTransId.trim();
    }
}