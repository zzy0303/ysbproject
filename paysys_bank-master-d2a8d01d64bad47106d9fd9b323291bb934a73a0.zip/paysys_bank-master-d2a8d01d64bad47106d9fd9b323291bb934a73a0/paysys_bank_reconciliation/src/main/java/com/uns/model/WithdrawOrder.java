package com.uns.model;

import java.math.BigDecimal;
import java.util.Date;

public class WithdrawOrder{
    private Long id;

    private String orderId;

    private String transId;

    private Long actionSeq;

    private Long creditSeq;

    private Long debitSeq;

    private BigDecimal amount;

    private String orderStatus;

    private String orderDesc;

    private String bankResponse;

    private BigDecimal debitFee;

    private BigDecimal creditFee;

    private String accountNo;

    private String accountType;

    private String bankName;

    private String depositBankName;

    private Long bankProvSeq;

    private Long bankCitySeq;

    private String accountName;

    private String phoneNo;

    private String remark;

    private String responseUrl;

    private String createUser;

    private Date createTime;

    private String updateUser;

    private Date updateTime;

    private String purpose;

    private String batchNo;

    private String bankSerialNo;
    
    private Account creditAccount;

    private Account debitAccount;

    private Double creditRealAmount;

    private Double debitRealAmount;

    private String innerOrderCode;
    
    private String bankProvName;

    private String bankCityName;

    private String serviceFlag;//手续费扣除方式
    
	private Long  vnvAccountSeq;
	private String   cardType;
	private String channelCode;
	private String accountId;
	private String name;
	private String relevanceInnerorder;
	private String payStatus;
	private String businessType;
	private Long creditFeeratioId;
	private Long debitFeeratioId;
	private Date settlementDate;
    
    public Long getVnvAccountSeq() {
		return vnvAccountSeq;
	}

	public void setVnvAccountSeq(Long vnvAccountSeq) {
		this.vnvAccountSeq = vnvAccountSeq;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRelevanceInnerorder() {
		return relevanceInnerorder;
	}

	public void setRelevanceInnerorder(String relevanceInnerorder) {
		this.relevanceInnerorder = relevanceInnerorder;
	}

	public String getPayStatus() {
		return payStatus;
	}

	public void setPayStatus(String payStatus) {
		this.payStatus = payStatus;
	}

	public String getBusinessType() {
		return businessType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public Long getCreditFeeratioId() {
		return creditFeeratioId;
	}

	public void setCreditFeeratioId(Long creditFeeratioId) {
		this.creditFeeratioId = creditFeeratioId;
	}

	public Long getDebitFeeratioId() {
		return debitFeeratioId;
	}

	public void setDebitFeeratioId(Long debitFeeratioId) {
		this.debitFeeratioId = debitFeeratioId;
	}

	public Date getSettlementDate() {
		return settlementDate;
	}

	public void setSettlementDate(Date settlementDate) {
		this.settlementDate = settlementDate;
	}

	public String getServiceFlag() {
		return serviceFlag;
	}

	public void setServiceFlag(String serviceFlag) {
		this.serviceFlag = serviceFlag;
	}

	public String getBankProvName() {
		return bankProvName;
	}

	public void setBankProvName(String bankProvName) {
		this.bankProvName = bankProvName;
	}

	public String getBankCityName() {
		return bankCityName;
	}

	public void setBankCityName(String bankCityName) {
		this.bankCityName = bankCityName;
	}

	public String getInnerOrderCode() {
        return innerOrderCode;
    }

    public void setInnerOrderCode(String innerOrderCode) {
        this.innerOrderCode = innerOrderCode;
    }

    public Account getCreditAccount() {
		return creditAccount;
	}

	public void setCreditAccount(Account creditAccount) {
		this.creditAccount = creditAccount;
	}

	public Account getDebitAccount() {
		return debitAccount;
	}

	public void setDebitAccount(Account debitAccount) {
		this.debitAccount = debitAccount;
	}

	public Double getCreditRealAmount() {
		return creditRealAmount;
	}

	public void setCreditRealAmount(Double creditRealAmount) {
		this.creditRealAmount = creditRealAmount;
	}

	public Double getDebitRealAmount() {
		return debitRealAmount;
	}

	public void setDebitRealAmount(Double debitRealAmount) {
		this.debitRealAmount = debitRealAmount;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getActionSeq() {
		return actionSeq;
	}

	public void setActionSeq(Long actionSeq) {
		this.actionSeq = actionSeq;
	}

	public Long getCreditSeq() {
		return creditSeq;
	}

	public void setCreditSeq(Long creditSeq) {
		this.creditSeq = creditSeq;
	}

	public Long getDebitSeq() {
		return debitSeq;
	}

	public void setDebitSeq(Long debitSeq) {
		this.debitSeq = debitSeq;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public void setBankProvSeq(Long bankProvSeq) {
		this.bankProvSeq = bankProvSeq;
	}

	public void setBankCitySeq(Long bankCitySeq) {
		this.bankCitySeq = bankCitySeq;
	}

	public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId == null ? null : orderId.trim();
    }

    public String getTransId() {
        return transId;
    }

    public void setTransId(String transId) {
        this.transId = transId == null ? null : transId.trim();
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus == null ? null : orderStatus.trim();
    }

    public String getOrderDesc() {
        return orderDesc;
    }

    public void setOrderDesc(String orderDesc) {
        this.orderDesc = orderDesc == null ? null : orderDesc.trim();
    }

    public String getBankResponse() {
        return bankResponse;
    }

    public void setBankResponse(String bankResponse) {
        this.bankResponse = bankResponse == null ? null : bankResponse.trim();
    }

    public BigDecimal getDebitFee() {
        return debitFee;
    }

    public void setDebitFee(BigDecimal debitFee) {
        this.debitFee = debitFee;
    }

    public BigDecimal getCreditFee() {
        return creditFee;
    }

    public void setCreditFee(BigDecimal creditFee) {
        this.creditFee = creditFee;
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo == null ? null : accountNo.trim();
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType == null ? null : accountType.trim();
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName == null ? null : bankName.trim();
    }

    public String getDepositBankName() {
        return depositBankName;
    }

    public void setDepositBankName(String depositBankName) {
        this.depositBankName = depositBankName == null ? null : depositBankName.trim();
    }

    public Long getBankProvSeq() {
        return bankProvSeq;
    }

    public Long getBankCitySeq() {
        return bankCitySeq;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName == null ? null : accountName.trim();
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo == null ? null : phoneNo.trim();
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getResponseUrl() {
        return responseUrl;
    }

    public void setResponseUrl(String responseUrl) {
        this.responseUrl = responseUrl == null ? null : responseUrl.trim();
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser == null ? null : createUser.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser == null ? null : updateUser.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose == null ? null : purpose.trim();
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo == null ? null : batchNo.trim();
    }

    public String getBankSerialNo() {
        return bankSerialNo;
    }

    public void setBankSerialNo(String bankSerialNo) {
        this.bankSerialNo = bankSerialNo == null ? null : bankSerialNo.trim();
    }
}