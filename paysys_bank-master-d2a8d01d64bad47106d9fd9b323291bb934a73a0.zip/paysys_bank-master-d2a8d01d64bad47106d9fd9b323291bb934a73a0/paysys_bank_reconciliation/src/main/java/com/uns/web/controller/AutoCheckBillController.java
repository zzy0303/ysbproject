package com.uns.web.controller;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.datasourceSwitch.DynamicDataSourceHolder;
import com.uns.model.CheckBill;
import com.uns.model.EpccDpTransRef;
import com.uns.service.CheckBillAmountService;
import com.uns.service.CheckBillService;
import com.uns.util.FastJson;
import com.uns.web.form.CheckBillForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/11/4
 * @Modifyed By:
 */
@Controller(value = "/autoCheckBill.json")
public class AutoCheckBillController {

    @Autowired
    private MessageSource messageSource;

    @Autowired
    private CheckBillService checkBillService;
    
    @Autowired
    private CheckBillAmountService billAmountService;

    private Logger log = LoggerFactory.getLogger(AutoCheckBillController.class);

    /**
     * 自动对账上传对账单\通道对账
     * @return
     */
    @RequestMapping(params = "method=autoUpload", produces={"text/html;charset=UTF-8;","application/json;"})
    @ResponseBody
    public String autoUpload(CheckBillForm checkBillForm) {
        Map resultMap = new HashMap();
        try {
            checkBillService.autoUpload(checkBillForm);
            resultMap.put("rspCode", Constants.STATUS_0000);
        } catch (BusinessException be) {
            log.info("通道{},{}",checkBillForm.getChannel(),be.getErrMessage(messageSource));
            resultMap.put("rspCode", be.getErrCode());
            resultMap.put("rspMsg", be.getErrMessage(messageSource));
        } catch (Exception e) {
            e.printStackTrace();
            resultMap.put("rspCode", Constants.STATUS_9999);
            resultMap.put("rspMsg", "系统错误");
        }
        return FastJson.toJson(resultMap);
    }
    
    /**
     * 自动获取银生宝金额
     * @return
     */
    @RequestMapping(params = "method=autoAmount", produces={"text/html;charset=UTF-8;","application/json;"})
    @ResponseBody
    public String autoAmount(String channel,String checkDate,HttpServletRequest request){
    	Map<String, String> infoMap = new HashMap<>();
    	try {
            String result = "";
    	    if(Constants.UPLOAD_EPCC.equals(channel)){
                result = String.valueOf(billAmountService.checkBillAmountNetsUnion(checkDate));
            }else{
                result = billAmountService.checkBillAmount(channel,checkDate); //获取金额总汇
            }
			log.info(result);
			infoMap.put("channel", channel);
			infoMap.put("amount", result);
		} catch (BusinessException be) {
			log.info("通道{},{}",channel,be.getErrMessage(messageSource));
			infoMap.put("rspCode", be.getErrCode());
			infoMap.put("rspMsg", be.getErrMessage(messageSource));
		} catch (Exception e) {
			e.printStackTrace();
			infoMap.put("rspCode", Constants.STATUS_9999);
			infoMap.put("rspMsg", e.getMessage());
		}
    	return FastJson.toJson(infoMap);
    }

    /**
     * 网联同步交易
     * @return
     */
    @RequestMapping(params = "method=autoSyncTrans", produces={"text/html;charset=UTF-8;","application/json;"})
    @ResponseBody
    public String autoSyncTrans(String checkdate){
        Map resultMap = new HashMap();
        try {
            resultMap = checkBillService.autoSyncTrans(checkdate);
        } catch (Exception e) {
            resultMap.put("rspCode", Constants.STATUS_9999);
            resultMap.put("rspMsg", e.getMessage());
        }
        resultMap.put("rspCode", Constants.STATUS_0000);
        return FastJson.toJson(resultMap);
    }

    /**
     * 网联自动对账
     * @return
     */
    @RequestMapping(params = "method=autoUploadNetsUnion")
    @ResponseBody
    public String autoUploadNetsUnion(HttpServletRequest request, CheckBillForm checkBillForm) {
        Map resultMap = new HashMap();
        try {
            checkBillService.autoUploadNetsUnion(checkBillForm);
            resultMap.put("rspCode", Constants.STATUS_0000);
        } catch (BusinessException be) {
            log.info("网联批次{},{}",checkBillForm.getChannel(),be.getErrMessage(messageSource));
            resultMap.put("rspCode", be.getErrCode());
            resultMap.put("rspMsg", be.getErrMessage(messageSource));
        } catch (Exception e) {
            e.printStackTrace();
            resultMap.put("rspCode", Constants.STATUS_9999);
            resultMap.put("rspMsg", "系统错误");
        }
        return FastJson.toJson(resultMap);
    }
}
