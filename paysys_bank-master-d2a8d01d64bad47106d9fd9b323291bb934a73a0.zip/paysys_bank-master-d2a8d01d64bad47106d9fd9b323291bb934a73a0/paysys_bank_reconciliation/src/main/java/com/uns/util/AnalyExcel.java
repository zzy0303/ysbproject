package com.uns.util;

import com.uns.biz.BizMapping;
import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.dao.*;
import com.uns.model.*;
import com.uns.service.CheckBillService;
import com.uns.web.form.CheckBillForm;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.http.impl.io.SocketOutputBuffer;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.uns.biz.BizMapping;
import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.model.BankTrans;
import com.uns.util.ExcelMap;
import com.uns.web.form.CheckBillForm;

import freemarker.template.SimpleDate;

public class AnalyExcel {
	
	
	/**
	 * 对账单excel文件解析
	 * 
	 * @param sheet
	 * @param checkBillForm
	 * @param excelMap
	 * @return
	 * @throws BusinessException
	 * @throws IOException
	 * @throws ParseException
	 */
	public static List<BankTrans> loadxlsx(XSSFSheet sheet, CheckBillForm checkBillForm, ExcelMap excelMap)
			throws BusinessException, IOException, ParseException {
		List<BankTrans> list = new ArrayList<BankTrans>();
		Double realamount=0.00;
		XSSFRow row = null;
		String spare = null;
		String spareshell = null;
		String successhell = null ;
		// 获得最后一排数
		// int rowNum = sheet.getLastRowNum()+excelMap.getStartline();
		for (int i = excelMap.getStartline(); i <= sheet.getLastRowNum(); i++) {// 跳过第一行标题
			row = sheet.getRow(i);
			if (null != row) {
				// 排除交易失败数据行				
				int mm=row.getPhysicalNumberOfCells();
				// 其他成功限制
				if (null != excelMap.getSpare()) {
					spare = excelMap.getSpare();
					spareshell = row.getCell((short) excelMap.getSparePlace()).getStringCellValue();
				}
				if(null!=row.getCell((short) excelMap.getTransAmountshell())&&!"".equals(row.getCell((short) excelMap.getTransAmountshell()).toString())){
					/* realamount = Double.valueOf(
							row.getCell((short) excelMap.getTransAmountshell()).getStringCellValue().replace(",", ""));*/

					if(row.getCell((short) excelMap.getTransAmountshell())!=null){
						row.getCell((short) excelMap.getTransAmountshell()).setCellType(Cell.CELL_TYPE_STRING);
						realamount = Double.valueOf(
								row.getCell((short) excelMap.getTransAmountshell()).getStringCellValue().replace(",", ""));
					}


				}
				if(null!=row.getCell((short) excelMap.getSuccessshell())&&!"".equals(row.getCell((short) excelMap.getSuccessshell()))){
					successhell = row.getCell((short) excelMap.getSuccessshell()).getStringCellValue();
				}
				// 解析Excel第2列
				String[] transIdArr = excelMap.getTransIdshell().split("\\|");
				String transId = "";
				if (transIdArr.length > 1){
					for (int j = 0; j < transIdArr.length; j++) {
						String s = transIdArr[j];
						if (j == transIdArr.length - 1){
							transId += row.getCell(Short.valueOf(s)).getStringCellValue();
						} else {
							transId += row.getCell(Short.valueOf(s)).getStringCellValue() + "|";
						}
					}
				} else {

					if (null == row.getCell(Short.valueOf(excelMap.getTransIdshell()))){
						continue;
					}

					transId = row.getCell(Short.valueOf(excelMap.getTransIdshell())).getStringCellValue();// 获取列值
					if (transId.length() > 0 && transId.length() < 15){ //判断交易编号长度
						throw new BusinessException(ExceptionDefine.交易编号格式错误请检查对账文件);
					}
				}

				//判断通道cmb_sm的订单编号传入的是否是订单编号
				if(Constants.UPLOAD_CMB_SM.equals(checkBillForm.getChannel())){
					Pattern p = Pattern.compile("[\u4e00-\u9fa5]");
					Matcher m = p.matcher(transId);
					if (m.find()) {
						continue;
					}
				}

				// 2017/08/31
				String date=null;
				//如果是招商扫码transId截取8位  作为交易时间
				if(Constants.UPLOAD_CMB_SM.equals(checkBillForm.getChannel())){
					date=transId.substring(19,27);
				}else{
					String dateOne = row.getCell((short) excelMap.getTransDateshell()).getStringCellValue();
					dateOne = new SimpleDateFormat("yyyy-MM-dd").format(new Date(dateOne));
					date = dateOne.replace("-","");
					if (date.matches("[0-9]+")) {
						date = date.substring(0,8);
					}
				}
				Date sdf = new SimpleDateFormat("yyyyMMdd").parse(date);
				// 判断交易金额类型解析不同格式
				String amount = "";
				BigDecimal transAmount = null;

				XSSFCell cell = row.getCell((short) excelMap.getTransAmountshell());
				switch (cell.getCellType()) {
					// 数字、日期类型
					case HSSFCell.CELL_TYPE_NUMERIC:
						amount = String.valueOf(cell.getNumericCellValue()).replace(",", "");
						if (Constants.UPLOAD_CMBC_CD.equals(checkBillForm.getChannel())) {// 通道
							// cmbc_cd
							// 金额的最后两位为小数
							// 数字
							amount = amount.substring(0, amount.length() - 2) + "."
									+ amount.substring(amount.length() - 2, amount.length());
						}
						transAmount = new BigDecimal(amount);
						break;
					// 字符串类型
					case HSSFCell.CELL_TYPE_STRING:
						amount = cell.getStringCellValue().replace(",", "");
						if (Constants.UPLOAD_CMBC_CD.equals(checkBillForm.getChannel())) {// 通道
							// cmbc_cd
							// 金额的最后两位为小数
							// 数字
							if (amount.length() > Constants.DECIMAL_NUM) {
								amount = amount.substring(0, amount.length() - Constants.DECIMAL_NUM) + "."
										+ amount.substring(amount.length() - Constants.DECIMAL_NUM, amount.length());
							} else {
								int appendNum = Constants.DECIMAL_NUM - amount.length();
								// 要是金额位数 小于 2 ，需要将金额 左边添加0，生成 小数
								for (int j = 0; j < appendNum; j++) {
									amount = "0" + amount;
								}
								amount = "0." + amount;
							}
						}

						if(Constants.UPLOAD_CMB_SM.equals(checkBillForm.getChannel())){//招商扫码通道
							//金额由分为单位的转成以元为单位的
							BigDecimal big = BigDecimal.valueOf(Long.parseLong(amount));
							BigDecimal b = new BigDecimal("0.01");
							amount=big.multiply(b).toString();
						}
						transAmount = new BigDecimal(amount);
						break;
				}

				BankTrans trans = new BankTrans();
				trans.setTransId(transId);
				trans.setTransDate(StringUtils.gettime(checkBillForm.getStartDate()));

				trans.setChannel(checkBillForm.getChannel());
				trans.setTransTime(sdf);
				if(Constants.UPLOAD_UMPAY.equals(checkBillForm.getChannel())){
					transAmount = transAmount.divide(new BigDecimal(100)).setScale(2);
				}
				trans.setAmount(transAmount.doubleValue());
				list.add(trans);
			}
		}
		return list;
	}
	
	/**
	 * 对账单excel文件解析
	 * 
	 * @param sheet
	 * @param checkBillForm
	 * @param excelMap
	 * @return
	 * @throws BusinessException
	 * @throws IOException
	 * @throws ParseException
	 */
	public static List<BankTrans> loadxls(HSSFSheet sheet, CheckBillForm checkBillForm, ExcelMap excelMap)
			throws BusinessException, IOException, ParseException {
		List<BankTrans> list = new ArrayList<BankTrans>();
		Double realamount=0.00;
		HSSFRow row = null;
		String spare = null;
		String spareshell = null;
		String successhell = null ;
		// 获得最后一排数
		// int rowNum = sheet.getLastRowNum()+excelMap.getStartline();
		for (int i = excelMap.getStartline(); i <= sheet.getLastRowNum(); i++) {// 跳过第一行标题
			row = sheet.getRow(i);
			if (null != row) {
				// 排除交易失败数据行				
				int mm=row.getPhysicalNumberOfCells();
				// 其他成功限制
				if (null != excelMap.getSpare()) {
					spare = excelMap.getSpare();
					spareshell = row.getCell((short) excelMap.getSparePlace()).getStringCellValue();
				}
				if(null!=row.getCell((short) excelMap.getTransAmountshell())&&!"".equals(row.getCell((short) excelMap.getTransAmountshell()).toString())){
					 realamount = Double.valueOf(
							row.getCell((short) excelMap.getTransAmountshell()).getStringCellValue().replace(",", ""));
				}
				if(null!=row.getCell((short) excelMap.getSuccessshell())&&!"".equals(row.getCell((short) excelMap.getSuccessshell()))){
					 successhell = row.getCell((short) excelMap.getSuccessshell()).getStringCellValue();
				}
				if ((checkBillForm.getChannel().equals(Constants.UPLOAD_WS) && realamount > 0)
						|| checkBillForm.getChannel().equals(Constants.UPLOAD_EPAY_DK) && realamount > 0
						|| checkBillForm.getChannel().equals(Constants.UPLOAD_SPDB_CROSSBANK_DK) && realamount > 0
						|| checkBillForm.getChannel().equals(Constants.UPLOAD_HFQD) && realamount > 0      //青岛银联
						|| successhell.equals(excelMap.getSuccess()) 
						|| (null != spare && spare.equals(spareshell))) {
					// 解析Excel第2列
					String[] transIdArr = excelMap.getTransIdshell().split("\\|");
					String transId = "";
					if (transIdArr.length > 1){
						for (int j = 0; j < transIdArr.length; j++) {
							String s = transIdArr[j];
							if (j == transIdArr.length - 1){
								transId += row.getCell(Short.valueOf(s)).getStringCellValue();
							} else {
								transId += row.getCell(Short.valueOf(s)).getStringCellValue() + "|";
							}
						}
					} else {
						//兴业银行扫码特殊格式 
						if(checkBillForm.getChannel().equals(Constants.UPLOAD_CIB_SM)){
							if(row.getCell(Short.valueOf(excelMap.getTransIdshell())) != null){
								transId = row.getCell(Short.valueOf(excelMap.getTransIdshell())).getStringCellValue();// 获取列值
							}else{
								continue;
							}
						}else{
							transId = row.getCell(Short.valueOf(excelMap.getTransIdshell())).getStringCellValue();// 获取列值
						}
						
						if (transId.length() < 15){ //判断交易编号长度
							throw new BusinessException(ExceptionDefine.交易编号格式错误请检查对账文件);
						}
					}

					String date = row.getCell((short) excelMap.getTransDateshell()).getStringCellValue().replace("-",
							"");
					  
                 if(Constants.UPLOAD_TJ_UNIONPAY_T0.equals(checkBillForm.getChannel())){
                	 if(date.contains("N")){
     						date = date.substring(1, 9);
                	 }else{
                		 if (date.matches("[0-9]+")) {
     						date = date.substring(0, 8);
     					}
                	 }	
					}else{
						if (date.matches("[0-9]+")) {
							date = date.substring(0, 8);
						}
					}
					Date sdf = new SimpleDateFormat("yyyyMMdd").parse(date);
					// 判断交易金额类型解析不同格式
					String amount = "";
					BigDecimal transAmount = null;
					HSSFCell cell = row.getCell((short) excelMap.getTransAmountshell());
					switch (cell.getCellType()) {
						// 数字、日期类型
						case HSSFCell.CELL_TYPE_NUMERIC:
							amount = String.valueOf(cell.getNumericCellValue()).replace(",", "");
							if (Constants.UPLOAD_CMBC_CD.equals(checkBillForm.getChannel())) {// 通道
								// cmbc_cd
								// 金额的最后两位为小数
								// 数字
								amount = amount.substring(0, amount.length() - 2) + "."
										+ amount.substring(amount.length() - 2, amount.length());
							}

						
						transAmount = new BigDecimal(amount);

						break;
						
					// 字符串类型
					case HSSFCell.CELL_TYPE_STRING:
						amount = cell.getStringCellValue().replace(",", "");
						if (Constants.UPLOAD_CMBC_CD.equals(checkBillForm.getChannel())) {// 通道
																							// cmbc_cd
																							// 金额的最后两位为小数
																							// 数字
							if (amount.length() > Constants.DECIMAL_NUM) {
								amount = amount.substring(0, amount.length() - Constants.DECIMAL_NUM) + "."
										+ amount.substring(amount.length() - Constants.DECIMAL_NUM, amount.length());
							} else {
								int appendNum = Constants.DECIMAL_NUM - amount.length();
								// 要是金额位数 小于 2 ，需要将金额 左边添加0，生成 小数
								for (int j = 0; j < appendNum; j++) {
									amount = "0" + amount;
								}
								amount = "0." + amount;
							}
						}
						
                       if(Constants.UPLOAD_BFBPAY_DK.equals(checkBillForm.getChannel()) //邦付宝通道
                    		   	|| Constants.UPLOAD_BOC_KJ.equals(checkBillForm.getChannel())
                               || Constants.UPLOAD_PSBC_D_KJ.equals(checkBillForm.getChannel())
                               || Constants.UPLOAD_BOC_KJ.equals(checkBillForm.getChannel())
							   || Constants.UPLOAD_HFQD.equals(checkBillForm.getChannel())
					||Constants.UPLOAD_UNIONPAY_XM_DP.equals(checkBillForm.getChannel())){ //中国银行
							
							//金额由分为单位的转成以元为单位的
							BigDecimal big = BigDecimal.valueOf(Long.parseLong(amount));
							BigDecimal b = new BigDecimal("0.01"); 
							amount=big.multiply(b).toString();
						  }
						transAmount = new BigDecimal(amount);
						break;
					}

					BankTrans trans = new BankTrans();
					trans.setTransId(transId);
					trans.setTransDate(new SimpleDateFormat("yyyyMMdd").parse(checkBillForm.getStartDate().replace("-", "").trim()));
					trans.setChannel(checkBillForm.getChannel());
					trans.setTransTime(sdf);
					if(Constants.UPLOAD_UMPAY.equals(checkBillForm.getChannel())||Constants.UPLOAD_UNIONPAY_XM_DK.equals(checkBillForm.getChannel())){
						transAmount = transAmount.divide(new BigDecimal(100)).setScale(2);
					}
					trans.setAmount(transAmount.doubleValue());
					list.add(trans);
				}
			}
		}
		return list;
	}
	
	public static List<BankTrans> getShell(InputStream file, CheckBillForm checkBillForm, String str) throws Exception {
		ExcelMap excelMap = getExcelMap(str);
		List<BankTrans> list = new ArrayList<BankTrans>();
		HSSFWorkbook workbook = new HSSFWorkbook(file);
		HSSFSheet sheet = workbook.getSheetAt(0);
		Double realamount=0.00;
		HSSFRow row = null;
		try {
			for (int i = excelMap.getStartline(); i <= sheet.getLastRowNum(); i++) {// 跳过第一行标题
				row = sheet.getRow(i);
				if (null != row) {
					if(null!=row.getCell((short) excelMap.getTransAmountshell())&&!"".equals(row.getCell((short) excelMap.getTransAmountshell()).toString())){
						realamount = Double.valueOf(
								row.getCell((short) excelMap.getTransAmountshell()).getStringCellValue().replace(",", ""));
					}
					if (realamount > 0){
						// 解析Excel第2列
						String transId = row.getCell(Short.valueOf(excelMap.getTransIdshell())).getStringCellValue();// 获取列值
						String date = row.getCell((short) excelMap.getTransDateshell()).getStringCellValue().replace("-","");
						if (date.matches("[0-9]+")) {
							date = date.substring(0, 8);
						}
						Date sdf = new SimpleDateFormat("yyyyMMdd").parse(date);
						// 判断交易金额类型解析不同格式
						String amount = "";
						BigDecimal transAmount = null;
						HSSFCell cell = row.getCell((short) excelMap.getTransAmountshell());
						switch (cell.getCellType()) {
							// 数字、日期类型
							case HSSFCell.CELL_TYPE_NUMERIC:
								amount = String.valueOf(cell.getNumericCellValue()).replace(",", "");
								transAmount = new BigDecimal(amount);
								break;
							// 字符串类型
							case HSSFCell.CELL_TYPE_STRING:
								amount = cell.getStringCellValue().replace(",", "");
								transAmount = new BigDecimal(amount);
								break;
						}

						BankTrans trans = new BankTrans();
						trans.setTransId(transId);
						trans.setTransDate(StringUtils.gettime(checkBillForm.getStartDate()));
						trans.setChannel(checkBillForm.getChannel());
						trans.setTransTime(sdf);
						trans.setAmount(transAmount.doubleValue());
						list.add(trans);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (null != file){
				file.close();
			}
		}
		return list;
	}
	
	
	

	/**
	 * 解析获取excel文件字段所处位置
	 * 
	 * @param str
	 * @return
	 * @throws IOException
	 */
	public static ExcelMap getExcelMap(String str) throws Exception {
		String[] st = str.split(",");

		ExcelMap excelMap = new ExcelMap();
		excelMap.setStartline(Integer.valueOf(st[0].trim()));
		excelMap.setSuccess(st[1]==null?null:st[1].trim());
		excelMap.setSuccessshell(st[2]==null?null:Integer.valueOf(st[2].trim()));
		excelMap.setTransAmountshell(Integer.valueOf(st[3].trim()));
		excelMap.setTransDateshell(Integer.valueOf(st[4].trim()));
		excelMap.setTransIdshell(st[5].trim());
		if (st.length > 6) {
			excelMap.setSparePlace(Integer.valueOf(st[6]));
			excelMap.setSpare(st[7]);
		}
		return excelMap;
	}

	/**
	 * 对账解析Excel文件
	 * 
	 * @param file
	 * @param checkBillForm
	 * @return
	 * @throws BusinessException
	 * @throws IOException
	 */
	public static List<BankTrans> loadXlsxShell(InputStream file, CheckBillForm checkBillForm, String stringshell)
			throws BusinessException, IOException {
		XSSFSheet sheet;

		List<BankTrans> list = new ArrayList<BankTrans>();
		ExcelMap excelMap = null;
		try {
			excelMap = getExcelMap(stringshell);
		} catch (Exception e1) {
			new BusinessException(ExceptionDefine.错误配置文件格式);
		}
		XSSFWorkbook workbook = null;
		try {
			workbook = new XSSFWorkbook(file);
			sheet = workbook.getSheetAt(0);// 得到上传Excel文件的第一页
		} catch (IOException e) {
			throw new BusinessException(ExceptionDefine.文件上传失败);
		} finally {
			if (null != file){
				file.close();
			}
			if (null != workbook){
				workbook.close();
			}
		}
		if (sheet != null) {
			try {
				list = loadxlsx(sheet, checkBillForm, excelMap);
			} catch (ParseException e) {
				e.printStackTrace();
				throw new BusinessException(ExceptionDefine.对账文件格式错误);
			}
		}
		return list;
	}
	
	/**
	 * 对账解析Excel文件
	 * 
	 * @param file
	 * @param checkBillForm
	 * @return
	 * @throws BusinessException
	 * @throws IOException
	 */
	public static List<BankTrans> loadAllShell(InputStream file, CheckBillForm checkBillForm, String stringshell)
			throws BusinessException, IOException {
		HSSFSheet sheet;

		List<BankTrans> list = new ArrayList<BankTrans>();
		ExcelMap excelMap = null;
		try {
			excelMap = getExcelMap(stringshell);
		} catch (Exception e1) {
			new BusinessException(ExceptionDefine.错误配置文件格式);
		}
		try {
			HSSFWorkbook workbook = new HSSFWorkbook(file);
			sheet = workbook.getSheetAt(0);// 得到上传Excel文件的第一页
		} catch (IOException e) {
			throw new BusinessException(ExceptionDefine.文件上传失败);
		} finally {
			if (null != file){
				file.close();
			}
		}
		if (sheet != null) {
			try {
				list = loadxls(sheet, checkBillForm, excelMap);
			} catch (ParseException e) {
				e.printStackTrace();
				throw new BusinessException(ExceptionDefine.对账文件格式错误);
			}
		}
		return list;
	}

	/**
	 * 添加成功判断标识
	 * 
	 * @param channel
	 * @return
	 */
	public String getSuccess(String channel) {
		String succFlag;
		if (channel.equals(Constants.UPLOAD_WS)) {
			succFlag = "33";
		}
		return channel;
	}

	/**
	 * 对账单TXT文件解析
	 * 
	 * @param file
	 * @param checkBillForm
	 * @return
	 * @throws BusinessException
	 * @throws IOException
	 */
	public static List<BankTrans> loadText(InputStream file, CheckBillForm checkBillForm, String str)
			throws BusinessException, IOException {
		List<BankTrans> list = new ArrayList<BankTrans>();
		TxtMap txtMap = null;
		try {
			txtMap = getTxtMap(str);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(file, "UTF-8"));
			int lineNum = 0;
			for (String line = reader.readLine(); line != null; line = reader.readLine()) {
				if (line.trim().length() == 0) {
					continue;
				}
				if(lineNum++ < txtMap.getStartLine()){
					continue;
				}
				String[] data = line.split(txtMap.getSplitFlag());
				if(Constants.UPLOAD_CCB_B2B.equals(checkBillForm.getChannel())){
					if(data[7].contains(".")){
						continue;
					}
				}
				if(Constants.UPLOAD_YLZ.equals(checkBillForm.getChannel())){//易联众只取成功的交易
					if(!data[8].equals("0")){
						continue;
					}
				}
				if(Constants.UPLOAD_YILIAN_DK.equals(checkBillForm.getChannel())){//亿联代扣只取成功的交易
					if(!data[8].equals("0")){
						continue;
					}
				}
				
				int charge = 0;
				if (data.length > 8) {
					if (checkBillForm.getChannel().equals(Constants.UPLOAD_CMBC_XM_DK) && data[8].equals("E")) {
						charge = 1;
					}
				}
				if (data.length >= txtMap.getLineLength() && charge == 0) {
					// 交易时间
					if (Double.valueOf(data[txtMap.getTransAmountshell()]) > 0) {
						Date date = new SimpleDateFormat("yyyyMMdd")
								.parse(data[txtMap.getTransDateshell()].substring(0, 8));
						if (date == null) {
							throw new BusinessException(ExceptionDefine.对账文件格式错误);
						}
						// 订单号
						if (data[txtMap.getTransIdshell()].length() < 1) {
							throw new BusinessException(ExceptionDefine.对账文件格式错误);
						}
						// 金额
						BigDecimal transAmount = new BigDecimal(data[txtMap.getTransAmountshell()]).setScale(2);

						if (checkBillForm.getChannel().equals(Constants.UPLOAD_UNIONPAY)
								|| checkBillForm.getChannel().equals(Constants.UPLOAD_CMBC_XM_KJ)
								|| checkBillForm.getChannel().equals(Constants.UPLOAD_CMBC_XM_DK)
								|| checkBillForm.getChannel().equals(Constants.UPLOAD_YLZ)) {//易联众
							transAmount = new BigDecimal(data[txtMap.getTransAmountshell()]).divide(new BigDecimal(100))
									.setScale(2);
						}
						BankTrans trans = new BankTrans();

						trans.setTransId(data[txtMap.getTransIdshell()]);
						Date transDate = new SimpleDateFormat("yyyyMMdd")
								.parse(checkBillForm.getStartDate().replace("-", "").trim());
						if (checkBillForm.getChannel().equals(Constants.UPLOAD_SPDB_KJ)) {
							StringBuffer Str = new StringBuffer(checkBillForm.getStartDate().substring(0, 4));
							trans.setTransId(Str.append(data[txtMap.getTransIdshell()].toString()).toString());
						}
						trans.setTransDate(transDate);
						trans.setChannel(checkBillForm.getChannel());
						trans.setTransTime(date);
						trans.setAmount(transAmount.doubleValue());
						list.add(trans);
					}
				}
			}
		} catch (IOException e) {
			throw new BusinessException(ExceptionDefine.对账文件格式错误);
		} catch (ParseException e) {
			e.printStackTrace();
		} finally {
			if (null != file){
				file.close();
			}
		}
		return list;
	}

	/**
	 * YlwkKj银联无卡对账单解析（Txt）
	 */
	public static List<BankTrans> loadYinlianKjText(InputStream file, CheckBillForm checkBillForm, String str) throws Exception {
		List<BankTrans> transList = new ArrayList<>();//解析出来的交易列表
		TxtMap txtMap = null;//txt解析的配置文件
		int lineNum = 0;//当前行数计数器
		//交易相关属性声明
		BankTrans bankTrans = null;//交易
		Double transAmount = null;//交易金额
		String transId = null;//交易流水号
		Date transDate = null;//交易日期
		Date transTime = null;//订单时间
		try {
			txtMap = getTxtMap(str);
			BufferedReader br = new BufferedReader(new InputStreamReader(file));
			String line = null;

			for(line = br.readLine(); null != line; line = br.readLine()){
				bankTrans = new BankTrans();
				if(line.trim().length() == 0){
					continue;
				}
				if(lineNum < txtMap.getStartLine()){
					lineNum ++;
					continue;
				}
				String[] data = line.split(txtMap.getSplitFlag());//匹配一个或者多个空格
				//如果解析的属性数量不等于规定行数
				if(data.length != txtMap.getLineLength()){
					throw new BusinessException(ExceptionDefine.对账文件格式错误);
				}
				//判断交易金额(开头为156，后跟12位数字)
				if(!Constants.YLWK_Kj_AMOUNT_HEAD.equals(data[txtMap.getTransAmountshell()].substring(0, 3)) ||
						data[txtMap.getTransAmountshell()].endsWith(Constants.YLWK_Kj_AMOUNT_BAD_ENDS)){
					throw new BusinessException(ExceptionDefine.对账文件格式错误);
				}
				//判断交易时间是否为空
				SimpleDateFormat sdf = new SimpleDateFormat(Constants.DEFAULT_DATE_FORMAT_NO_UNDERLINE);
				transDate = sdf.parse(data[txtMap.getTransDateshell()]);
				if(null == transDate){
					throw new BusinessException(ExceptionDefine.对账文件格式错误);
				}
				transAmount = getYinlianKjTransAmount(data[txtMap.getTransAmountshell()]);//格式化获取银联无卡快捷交易金额
				transId = data[txtMap.getTransIdshell()];//交易流水号
				transTime = getYinlianKjTransTime(data[txtMap.getTransIdshell()]);
				bankTrans.setTransId(transId);
				bankTrans.setAmount(transAmount);
				bankTrans.setTransDate(transDate);
				bankTrans.setTransTime(transTime);
				bankTrans.setChannel(checkBillForm.getChannel());
				transList.add(bankTrans);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.文件上传失败);
		}finally {
			if(null != file){
				file.close();
			}
		}
		return transList;
	}

	/**
	 * 获取银联无卡快捷文件中的交易金额
	 * @param oriAmount
	 * @return
	 */
	private static Double getYinlianKjTransAmount(String oriAmount){
		String oriAmountReal = oriAmount.substring(3);
		return Double.valueOf(oriAmountReal.substring(0, 10) + "." + oriAmountReal.substring(10));
	}

	/**
	 * 获取银联无卡快捷文件中的交易时间（transTime）
	 * @param transId
	 * @return
	 */
	private static Date getYinlianKjTransTime(String transId) throws ParseException {
		String timeStr = transId.substring(0, 8) + transId.substring(9);
		SimpleDateFormat sdf = new SimpleDateFormat(Constants.DEFAULT_DATETIME_FORMAT_NO_UNDERLINE);
		return sdf.parse(timeStr);
	}

	/**
	 * 中信银行做特殊处理
	 *
	 * @param file
	 * @param checkBillForm
	 * @param str
	 * @return
	 * @throws BusinessException
	 * @throws IOException
	 */
	public static List<BankTrans> loadCncbText(InputStream file, CheckBillForm checkBillForm, String str)
			throws BusinessException, IOException {
		List<BankTrans> list = new ArrayList<BankTrans>();
		TxtMap txtMap = null;
		try {
			txtMap = getTxtMap(str);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		try {
			int index = 0;
			BufferedReader reader = new BufferedReader(new InputStreamReader(file, "gbk"));
			for (String line = reader.readLine(); line != null; line = reader.readLine()) {
				if (index++ <= txtMap.getStartLine()) {
					continue;
				}
				String[] data = line.split(txtMap.getSplitFlag());
				if (data.length >= txtMap.getLineLength()) {
					// 交易时间
					if (Double.valueOf(data[txtMap.getTransAmountshell()]) > 0) {
						Date date = new SimpleDateFormat("yyyyMMdd")
								.parse(data[txtMap.getTransDateshell()].replace("-", "").trim());
						if (date == null) {
							throw new BusinessException(ExceptionDefine.对账文件格式错误);
						}
						// 订单号
						if (data[txtMap.getTransIdshell()].length() < 1) {
							throw new BusinessException(ExceptionDefine.对账文件格式错误);
						}
						// 金额
						BigDecimal transAmount = new BigDecimal(data[txtMap.getTransAmountshell()]).setScale(2);
						if(checkBillForm.getChannel().equals(Constants.UPLOAD_ICBC_B2B)){
							transAmount=transAmount.divide(new BigDecimal(100)).setScale(2);
						}
						BankTrans trans = new BankTrans();
						trans.setTransId(data[txtMap.getTransIdshell()]);
						Date transDate = new SimpleDateFormat("yyyyMMdd")
								.parse(checkBillForm.getStartDate().replace("-", "").trim());
						trans.setTransDate(transDate);
						trans.setChannel(checkBillForm.getChannel());
						trans.setTransTime(date);
						trans.setAmount(transAmount.doubleValue());
						list.add(trans);
					}
				}
			}
		} catch (IOException e) {
			throw new BusinessException(ExceptionDefine.对账文件格式错误);
		} catch (ParseException e) {
			e.printStackTrace();
		} finally {
			if (null != file){
				file.close();
			}
		}
		return list;
	}

	/**
	 * 中国银行做特殊处理
	 * 
	 * @param file
	 * @param checkBillForm
	 * @param str
	 * @return
	 * @throws BusinessException
	 * @throws IOException
	 */
	public static List<BankTrans> loadBocbText(InputStream file, CheckBillForm checkBillForm, String str)
			throws BusinessException, IOException {
		List<BankTrans> list = new ArrayList<BankTrans>();
		TxtMap txtMap = null;
		try {
			txtMap = getTxtMap(str);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		try {
			int index = 0;
			BufferedReader reader = new BufferedReader(new InputStreamReader(file, "gbk"));
			BankTrans trans = new BankTrans();
			for (String line = reader.readLine(); line != null; line = reader.readLine()) {
				if (index++ <= txtMap.getStartLine()) {
					continue;
				}
				String[] data = line.split(txtMap.getSplitFlag());
				if (data[txtMap.getTransIdshell()].length() == 8) {
					// 交易时间
					if (Double.valueOf(data[txtMap.getTransAmountshell()].replace(",", "")) > 0) {
						Date date = new SimpleDateFormat("yyyyMMdd")
								.parse(data[txtMap.getTransDateshell()].replace("/", "").trim());
						if (date == null) {
							throw new BusinessException(ExceptionDefine.对账文件格式错误);
						}
						// 金额
						BigDecimal transAmount = new BigDecimal(data[txtMap.getTransAmountshell()].replace(",", ""))
								.setScale(2);
						Date transDate = new SimpleDateFormat("yyyyMMdd")
								.parse(checkBillForm.getStartDate().replace("-", "").trim());
						trans.setTransDate(transDate);
						trans.setChannel(checkBillForm.getChannel());
						trans.setAmount(transAmount.doubleValue());
					}
				}
				if (data[txtMap.getTransIdshell()].length() == 15) {
					BankTrans tran = new BankTrans();
					try {
						PropertyUtils.copyProperties(tran, trans);
					} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
						e.printStackTrace();
					}
					tran.setTransId(data[txtMap.getTransIdshell()].trim());
					tran.setTransTime( new SimpleDateFormat("yyyyMMdd").parse(data[txtMap.getTransIdshell()].substring(0,8)));
					list.add(tran);
				}
			}
		} catch (IOException e) {
			throw new BusinessException(ExceptionDefine.对账文件格式错误);
		} catch (ParseException e) {
			e.printStackTrace();
		} finally {
			if (null != file){
				file.close();
			}
		}
		return list;
	}
	
	/**
	 * 易付宝代扣txt做特殊处理
	 * @param file
	 * @param checkBillForm
	 * @param str
	 * @return
	 * @throws BusinessException
	 * @throws IOException
	 */
	public static List<BankTrans> loadYifubaoText(InputStream file, CheckBillForm checkBillForm, String str)
			throws BusinessException, IOException {
		List<BankTrans> list = new ArrayList<BankTrans>();
		TxtMap txtMap = null;
		try {
			txtMap = getTxtMap(str);
		}  catch (Exception e) {
			throw new BusinessException(ExceptionDefine.错误配置文件格式);
		}
		try {
			int index = 0;
			BufferedReader reader = new BufferedReader(new InputStreamReader(file, "UTF-8"));
			for (String line = reader.readLine(); line != null; line = reader.readLine()) {
				String[] data = line.split(txtMap.getSplitFlag());
				// 数据起始行 || 解析是否为有效列   
				if (index++ <= txtMap.getStartLine() || true == line.contains(Constants.ACTION_YIFUBAO_DK_FLAG)) {
					continue;
				}
				String amountStr = data[txtMap.getTransAmountshell()].trim();
				int index1 = amountStr.indexOf(",");
				int index2 = amountStr.indexOf(",",index1+1);
				//截取金额
				Double amount = Double.valueOf(amountStr.substring(index1+1,index2));
				String transId = data[txtMap.getTransIdshell()].replace(",", "");
				if (transId.length() == Constants.TRANSiDLENGTH || transId.indexOf("N") != -1) {
					if (amount > 0) {
						// 交易时间
						Date date = new SimpleDateFormat("yyyyMMdd")
								.parse(data[txtMap.getTransDateshell()].replace("-", "").trim());
						if (null == date) {
							throw new BusinessException(ExceptionDefine.对账文件格式错误);
						}
						// 金额
						BigDecimal transAmount = new BigDecimal(amount).setScale(2,BigDecimal.ROUND_HALF_UP); //进行四舍五入
						BankTrans trans = new BankTrans();
						trans.setTransDate(date);
						trans.setChannel(checkBillForm.getChannel());
						trans.setAmount(transAmount.doubleValue());
						trans.setTransId(transId.trim());
						trans.setTransTime(date);
						list.add(trans);
					}
				}
			}
		} catch (IOException e) {
			throw new BusinessException(ExceptionDefine.对账文件格式错误);
		} catch (ParseException e) {
			e.printStackTrace();
		} finally {
			if (null != file){
				file.close();
			}
		}
		return list;
	}

	/**
	 * 对账单华夏银行按#分割特殊处理txt文件
	 * 
	 * @param file
	 * @param checkBillForm
	 * @return
	 * @throws BusinessException
	 * @throws IOException
	 */
	public static List<BankTrans> loadHxText(InputStream file, CheckBillForm checkBillForm, String str)
			throws BusinessException, IOException {
		List<BankTrans> list = new ArrayList<BankTrans>();
		TxtMap txtMap = null;
		try {
			txtMap = getTxtMap(str);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(file, "UTF-8"));
			for (String line = reader.readLine(); line != null; line = reader.readLine()) {
				if (line.trim().length() == 0) {
					continue;
				}
				String[] lineData = line.split("#");
				for (int i = 0; i < lineData.length; i++) {
					String[] data = lineData[i].split(txtMap.getSplitFlag());
					int charge = 0;
					if (data.length >= txtMap.getLineLength() && charge == 0) {
						// 交易时间
						if (Double.valueOf(data[txtMap.getTransAmountshell()]) > 0) {
							Date date = new SimpleDateFormat("yyyyMMdd")
									.parse(data[txtMap.getTransDateshell()].substring(0, 8));
							if (date == null) {
								throw new BusinessException(ExceptionDefine.对账文件格式错误);
							}
							// 订单号
							if (data[txtMap.getTransIdshell()].length() < 1) {
								throw new BusinessException(ExceptionDefine.对账文件格式错误);
							}
							//华夏对账单区分hxb_kj 04和hxb_b2c  01数据
							
							if(!data[4].equals("04") || data[5].equals(Constants.FLAG_1)){
								 continue;
							}
							
							
							// 金额
							BigDecimal transAmount = new BigDecimal(data[txtMap.getTransAmountshell()])
									.divide(new BigDecimal(100)).setScale(2);

							BankTrans trans = new BankTrans();

							trans.setTransId(data[txtMap.getTransIdshell()]);

							Date transDate = new SimpleDateFormat("yyyyMMdd")
									.parse(checkBillForm.getStartDate().replace("-", "").trim());
							if (checkBillForm.getChannel().equals(Constants.UPLOAD_SPDB_KJ)) {
								StringBuffer Str = new StringBuffer(transDate.toString().substring(0, 3));
								trans.setTransId(Str.append(data[txtMap.getTransIdshell()].toString()).toString());
							}
							trans.setTransDate(transDate);
							trans.setChannel(checkBillForm.getChannel());
							trans.setTransTime(date);
							trans.setAmount(transAmount.doubleValue());
							list.add(trans);
						}
					}
				}
			}
		} catch (IOException e) {
			throw new BusinessException(ExceptionDefine.对账文件格式错误);
		} catch (ParseException e) {
			e.printStackTrace();
		} finally {
			if (null != file){
				file.close();
			}
		}
		return list;
	}

	
	public static List<BankTrans> loadTextNew(InputStream file, CheckBillForm checkBillForm, String str)
			throws BusinessException, IOException {
		List<BankTrans> list = new ArrayList<BankTrans>();
		TxtMap txtMap = null;
		String[] st = str.split(",");
		try {
			txtMap = getTxtMap(st);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(file, "UTF-8"));
			for (String line = reader.readLine(); line != null; line = reader.readLine()) {
				if (line.trim().length() == 0) {
					continue;
				}
				String[] data = line.split(txtMap.getSplitFlag());
				int charge = 0;
				if (data.length > 8) {
					if (checkBillForm.getChannel().equals(Constants.UPLOAD_CMBC_XM_DK) && data[8].equals("E")) {
						charge = 1;
					}
				}
				if (data.length >= txtMap.getLineLength() && charge == 0) {
					// 交易时间
					if (Double.valueOf(data[txtMap.getTransAmountshell()]) > Constants.FLAG_default) {
						// 订单号
						if (data[txtMap.getTransIdshell()].length() < Constants.FLAG_1_) {
							throw new BusinessException(ExceptionDefine.对账文件格式错误);
						}
						// 金额
						BigDecimal transAmount = new BigDecimal(data[txtMap.getTransAmountshell()]).setScale(2);

						if (checkBillForm.getChannel().equals(Constants.UPLOAD_UNIONPAY)
								|| checkBillForm.getChannel().equals(Constants.UPLOAD_CMBC_XM_KJ)
								|| checkBillForm.getChannel().equals(Constants.UPLOAD_CMBC_XM_DK)
								|| checkBillForm.getChannel().equals(Constants.UPLOAD_CHINAPAY)) {
							transAmount = new BigDecimal(data[txtMap.getTransAmountshell()]).divide(new BigDecimal(100))
									.setScale(2);
						}
						if(((checkBillForm.getChannel().equals(Constants.UPLOAD_UNIONPAY)&&
								!Constants.UPLOAD_UNIONPAY_TD2_CODE.contains(data[Constants.FLAG_12].toString())))){
							BankTrans trans = new BankTrans();
							trans.setTransId(data[txtMap.getTransIdshell()]);
							if(0<data[txtMap.getTransIdshell()].length()&&data[txtMap.getTransIdshell()].length()<Constants.TRANSiDLENGTH){
								trans.setTransId(data[txtMap.getTransIdshell()-1]);
							}
							Date transDate = new SimpleDateFormat("yyyyMMdd")
									.parse(checkBillForm.getStartDate().replace("-", "").trim());
							String bankDate = checkBillForm.getStartDate().substring(0,4) + data[txtMap.getTransDateshell()].substring(0,4);
							trans.setTransDate(transDate);
							trans.setChannel(checkBillForm.getChannel());
							trans.setTransTimeStr(bankDate);
							trans.setAmount(transAmount.doubleValue());
							trans.setMerchantCode(data[Integer.parseInt(st[Constants.FLAG_6])]);
							trans.setTransTime(new SimpleDateFormat("yyyyMMdd").parse(bankDate));
							list.add(trans);
						}
						if (checkBillForm.getChannel().equals(Constants.UPLOAD_CHINAPAY)){
							BankTrans trans = new BankTrans();
							trans.setTransId(data[txtMap.getTransIdshell()]);
							if(0<data[txtMap.getTransIdshell()].length()&&data[txtMap.getTransIdshell()].length()<Constants.TRANSiDLENGTH){
								trans.setTransId(data[txtMap.getTransIdshell()-1]);
							}
							Date transDate = new SimpleDateFormat("yyyyMMdd")
									.parse(checkBillForm.getStartDate().replace("-", "").trim());
							String bankDate = checkBillForm.getStartDate().substring(0,4) + data[txtMap.getTransDateshell()].substring(0,4);
							trans.setTransDate(transDate);
							trans.setChannel(checkBillForm.getChannel());
							trans.setTransTimeStr(bankDate);
							trans.setAmount(transAmount.doubleValue());
							trans.setMerchantCode(data[Integer.parseInt(st[Constants.FLAG_6])]);
							trans.setTransTime(new SimpleDateFormat("yyyyMMdd").parse(bankDate));
							list.add(trans);
						}
						if(Constants.UPLOAD_UNIONPAY_B2C.contains(checkBillForm.getChannel())&&!checkBillForm.getChannel().equals(Constants.UPLOAD_UNIONPAY)){
							BankTrans trans = new BankTrans();
							trans.setTransId(data[txtMap.getTransIdshell()]);
							Date transDate = new SimpleDateFormat("yyyyMMdd")
									.parse(checkBillForm.getStartDate().replace("-", "").trim());
							String bankDate = checkBillForm.getStartDate().substring(0,4) + data[txtMap.getTransDateshell()].substring(0,4);
							trans.setTransDate(transDate);
							trans.setChannel(checkBillForm.getChannel());
							trans.setTransTimeStr(bankDate);
							transAmount = new BigDecimal(data[txtMap.getTransAmountshell()]).divide(new BigDecimal(100))
									.setScale(2);
							trans.setAmount(transAmount.doubleValue());
							trans.setMerchantCode(data[Integer.parseInt(st[Constants.FLAG_6])]);
							trans.setTransTime(new SimpleDateFormat("yyyyMMdd").parse(bankDate));
						    list.add(trans);
						}
						if (Constants.UPLOAD_UNIONPAY_WG.equals(checkBillForm.getChannel()) && data[Constants.FLAG_12].toString().equals(Constants.UPLOAD_UNIONPAY_WG_CODE)){
							BankTrans trans = new BankTrans();
							trans.setTransId(data[txtMap.getTransIdshell()]);
							Date transDate = new SimpleDateFormat("yyyyMMdd")
									.parse(checkBillForm.getStartDate().replace("-", "").trim());
							String bankDate = checkBillForm.getStartDate().substring(0,4) + data[txtMap.getTransDateshell()].substring(0,4);
							trans.setTransDate(transDate);
							trans.setChannel(checkBillForm.getChannel());
							trans.setTransTimeStr(bankDate);
							transAmount = new BigDecimal(data[txtMap.getTransAmountshell()]).divide(new BigDecimal(100))
									.setScale(2);
							trans.setAmount(transAmount.doubleValue());
							trans.setMerchantCode(data[Integer.parseInt(st[Constants.FLAG_6])]);
							trans.setTransTime(new SimpleDateFormat("yyyyMMdd").parse(bankDate));
							list.add(trans);
						}
					}
				}
			}
		} catch (IOException e) {
			throw new BusinessException(ExceptionDefine.对账文件格式错误);
		} catch (ParseException e) {
			e.printStackTrace();
		} finally {
			if (null != file){
				file.close();
			}
		}
		return list;
	}

	/**网联对账单解析
	 * @param inputStream
	 * @param checkBillForm
	 * @param pattern
	 * @return
	 */
	public static List<BankTrans> loadNetsUnion(InputStream inputStream, CheckBillForm checkBillForm, String pattern) throws Exception {
		List<BankTrans> bankTransList = new ArrayList<>();
		TxtMap patternMap = null;
		SimpleDateFormat sdf1 = new SimpleDateFormat(Constants.DEFAULT_DATE_FORMAT_NO_UNDERLINE);
		SimpleDateFormat sdf2 = new SimpleDateFormat(Constants.DEFAULT_DATE_FORMAT);
		String[] patternArr = pattern.split(",");
		try {
			patternMap = getTxtMap(patternArr);//获取文件解析配置
		} catch (Exception e) {
			e.printStackTrace();
		}

		BufferedReader br = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
		Date date;
		String transDate;
		String transId;
		//网联新增字段
        String bankBusiType;//银行交易类别
        String bankBusiStatus;//交易状态
        String payOrgIdSeq;//付款行所属机构
        String destOrgIdSeq;//收款行所属机构编码
		String batchId;//网联交易批次号
		try {
			for (String line = br.readLine(); line != null; line = br.readLine()) {
				if(line.trim().length() == 0){
					continue;
				}
				String[] data = line.split(patternMap.getSplitFlag());
				if(data.length >= patternMap.getLineLength()){
					//获取交易金额
					String amount = data[patternMap.getTransAmountshell()];
					amount = amount.substring(3);
					//交易成功、推定成功或者交易金额大于0
					if(Constants.NETS_UNION_SUCCESS_CODE.contains(data[4]) && Double.valueOf(amount) > Constants.FLAG_default){
						if(data[patternMap.getTransIdshell()].length() != Constants.NETS_UNION_ID_LEN){//订单号不对
							throw new BusinessException(ExceptionDefine.对账文件格式错误);
						}
						transId = data[patternMap.getTransIdshell()];
                        bankBusiType = data[3];//银行交易类别
                        bankBusiStatus = data[4];//交易状态
                        payOrgIdSeq = data[5];//付款行所属机构
                        destOrgIdSeq = data[6];//收款行所属机构编码
						batchId = data[0];//网联交易批次号
						if(transId == null){
							throw new BusinessException(ExceptionDefine.对账文件格式错误);
						}
						//交易时间
						transDate = data[patternMap.getTransDateshell()].substring(0,8);
						date = sdf1.parse(transDate);
						if(null == date){
							throw new BusinessException(ExceptionDefine.对账文件格式错误);
						}
						BankTrans bankTrans = new BankTrans();
						bankTrans.setTransId(transId);
						bankTrans.setAmount(Double.valueOf(amount));
						bankTrans.setTransTime(date);
						bankTrans.setTransDate(sdf2.parse(checkBillForm.getStartDate()));
						bankTrans.setChannel(checkBillForm.getChannel());
						//网联新增字段
                        bankTrans.setBankBusiType(bankBusiType);
                        bankTrans.setBankBusiStatus(bankBusiStatus);
                        bankTrans.setPayOrgIdSeq(payOrgIdSeq);
                        bankTrans.setDestOrgIdSeq(destOrgIdSeq);
						bankTrans.setBatchId(batchId);

						bankTransList.add(bankTrans);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(null != inputStream){
				inputStream.close();
			}
		}
		return bankTransList;
	}

	public static List<BankTrans> loadUpopText(InputStream file, CheckBillForm checkBillForm, String str)
			throws BusinessException, IOException {
		List<BankTrans> list = new ArrayList<BankTrans>();
		TxtMap txtMap = null;
		String[] st = str.split(",");
		try {
			txtMap = getTxtMap(st);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(file, "UTF-8"));
			for (String line = reader.readLine(); line != null; line = reader.readLine()) {
				if (line.trim().length() == 0) {
					continue;
				}
				String[] data = line.split(txtMap.getSplitFlag());
				int charge = 0;

				if (data.length >= txtMap.getLineLength() && charge == 0) {
					// 交易时间
					if (Double.valueOf(data[txtMap.getTransAmountshell()]) > Constants.FLAG_default) {
						// 订单号
						if (data[txtMap.getTransIdshell()].length() < Constants.FLAG_1_) {
							throw new BusinessException(ExceptionDefine.对账文件格式错误);
						}
						if (data[txtMap.getTransIdshell()].length() < 15){
							throw new BusinessException(ExceptionDefine.交易编号格式错误请检查对账文件);
						}
						// 金额
						BigDecimal transAmount = new BigDecimal(data[txtMap.getTransAmountshell()]).divide(new BigDecimal(100)).setScale(2);

						BankTrans trans = new BankTrans();
						trans.setTransId(data[txtMap.getTransIdshell()]);
						Date transDate = new SimpleDateFormat("yyyyMMdd")
								.parse(checkBillForm.getStartDate().replace("-", "").trim());
						trans.setTransDate(transDate);
						trans.setChannel(checkBillForm.getChannel());
						trans.setTransTimeStr(data[txtMap.getTransDateshell()]);
						trans.setAmount(transAmount.doubleValue());
						trans.setTransTime(new SimpleDateFormat("yyyyMMdd").parse(trans.getTransId().substring(Constants.FLAG_default, Constants.FLAG_8)));
						list.add(trans);
					}
				}
			}
		} catch (IOException e) {
			throw new BusinessException(ExceptionDefine.对账文件格式错误);
		} catch (ParseException e) {
			e.printStackTrace();
		} finally {
			if (null != file){
				file.close();
			}
		}
		return list;
	}

	public static List<BankTrans> newLoadText(InputStream file, CheckBillForm checkBillForm,
			Map<String, List<String>> setting) throws BusinessException, IOException {
		List<BankTrans> list = new ArrayList<BankTrans>();
		String channel = checkBillForm.getChannel();
		TxtMap txtMap = null;

		if (!setting.containsKey("INPUT_LOCAL")) {
			throw new BusinessException(ExceptionDefine.错误配置文件格式);
		}

		List<String> st = setting.get("INPUT_LOCAL");
		try {
			txtMap = getTxtMap(st);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		try {
			//BufferedReader reader = new BufferedReader(new InputStreamReader(file, "UTF-8"));
			BufferedReader reader = new BufferedReader(new InputStreamReader(file, setting.get("CHARSET_CODE").get(0)));
			int startRow = txtMap.getStartLine();
			int index = 0;
			for (String line = reader.readLine(); line != null; line = reader.readLine()) {
				if (line.trim().length() == 0 || index++ < startRow) {
					continue;
				}

				String[] data = line.split(txtMap.getSplitFlag());
				/*String[] data = line.split(txtMap.getSplitFlag());*/
				/*String[] data = line.split("\");*/
				
				//华夏对账单区分hxb_kj 04和hxb_b2c  01数据
				if (Constants.UPLOAD_HXB_B2C.equals(checkBillForm.getChannel())){
					if(!data[4].equals("01")){
						 continue;
					}
					//区分成功失败交易  (0成功、1失败)
					if(!data[5].equals(Constants.HXB_FLAG0)){
						 continue;
					}
					}

				//区分CCB_B2B和CCB_B2C
				if(Constants.UPLOAD_CCB_B2C.equals(checkBillForm.getChannel())){
					if(!data[7].contains(".")){
						continue;
					}
				}

				if(Constants.UPLOAD_ABC_B2C.equals(checkBillForm.getChannel())){
					if(Constants.ABC_B2C_FAILED.equals(data[11])){
						continue;
					}
				}
				

				if (data.length >= txtMap.getLineLength()) {
					// 交易时间
					data[txtMap.getTransAmountshell()] = data[txtMap.getTransAmountshell()].replace(",", "");
					if (Double.valueOf(data[txtMap.getTransAmountshell()]) > 0) {
						// 订单号
						BankTrans trans = createTrans(data, txtMap, checkBillForm);
						if (StringUtils.isEmpty(trans.getTransId())) {
							continue;
						}
						if (BizMapping.findBizBaseInterface(channel).checkInputData(data, checkBillForm, trans, setting)) {
							list.add(trans);
						}
					}
				}
			}
		} catch (IOException e) {
			throw new BusinessException(ExceptionDefine.对账文件格式错误);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (null != file){
				file.close();
			}
		}
		return list;
	}

	
	protected static BankTrans createTrans(String[] data, TxtMap txtMap, CheckBillForm checkBillForm) throws Exception {
		// 金额
		BigDecimal transAmount;
		//ccb_b2c通道金额特殊处理
		if (Constants.UPLOAD_CCB_B2C.equals(checkBillForm.getChannel())) {
			if (data[txtMap.getTransIdshell()].trim().length() < 15){
				transAmount = new BigDecimal(data[txtMap.getTransAmountshell() + 1].replace(",", "")).setScale(2);
			} else {
				transAmount = new BigDecimal(data[txtMap.getTransAmountshell()].replace(",", "")).setScale(2);
			}
		} else {
			transAmount = new BigDecimal(data[txtMap.getTransAmountshell()].replace(",", "")).setScale(2);
		}

		BankTrans trans = new BankTrans();
		//ccb_b2c通道交易编号特殊处理
		if (Constants.UPLOAD_CCB_B2C.equals(checkBillForm.getChannel())){
			if (data[txtMap.getTransIdshell()].trim().length() < 15){
				trans.setTransId(data[txtMap.getTransIdshell() + 1]);
			} else {
				trans.setTransId(data[txtMap.getTransIdshell()].trim());
			}
		} else {
			trans.setTransId(data[txtMap.getTransIdshell()].trim());
		}
		Date transDate = new SimpleDateFormat("yyyyMMdd").parse(checkBillForm.getStartDate().replace("-", "").trim());
		trans.setTransDate(transDate);
		trans.setChannel(checkBillForm.getChannel());
		trans.setTransTimeStr(data[txtMap.getTransDateshell()].trim());
		trans.setAmount(transAmount.doubleValue());

		return trans;
	}

	public static List<BankTrans> loadxlsNew(InputStream file, CheckBillForm checkBillForm,
			Map<String, List<String>> setting) throws Exception {
		List<BankTrans> list = new ArrayList<BankTrans>();
		String channel = checkBillForm.getChannel();
		List<String> input = setting.get("INPUT_LOCAL");
		TxtMap txtMap = getTxtMap(input);
		try {
			HSSFWorkbook workbook = new HSSFWorkbook(file);
			HSSFSheet st = workbook.getSheetAt(0);
			int startRow = txtMap.getStartLine();
			int rowCount = st.getLastRowNum();
			for (int i = startRow; i <= rowCount; i++) {
				String line = "";

				if (st.getRow(i) == null
						// 跳过无数据行
						|| st.getRow(i).getLastCellNum() == 0) {
					break;
				}
				line = getText(i, st);// 读取每一行

				if (line.length() > 1) {
					line = line.substring(1);
				}
				String[] data = line.split("#+");
				//bosh_b2c不抓取对账单中的退款交易
				if(Constants.UPLOAD_BOSH_B2C.equals(channel)){
					if((data[9]).equals("隔日退款")){
						continue;
					}
				}
				if (data.length >= txtMap.getLineLength()) {
					BankTrans trans = createTrans(data, txtMap, checkBillForm);
					if (StringUtils.isEmpty(trans.getTransId())) {
						continue;
					}
					if (BizMapping.findBizBaseInterface(channel).checkInputData(data, checkBillForm, trans, setting)) {
						list.add(trans);
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
			// 版本错误
		} finally {
			if (null != file){
				file.close();
			}
		}
		return list;
	}

	protected static String getText(int row, HSSFSheet sheet) {

		HSSFRow hssfRow = sheet.getRow(row);
		int intColumnNum = hssfRow.getLastCellNum();

		String strLine = "";

		for (int i = 0; i < intColumnNum; i++) {
			String strValue = "";
			if (hssfRow.getCell((short) i) != null) {
				HSSFCell cell = hssfRow.getCell((short) i);
				// 根据单元格类型进行取值，并全部转换为字符串返回
				switch (cell.getCellType()) {
				// 布尔型
				case HSSFCell.CELL_TYPE_BOOLEAN:
					boolean booleanTemp = cell.getBooleanCellValue();
					strValue = String.valueOf(booleanTemp);
					break;

				// 数字、日期类型
				case HSSFCell.CELL_TYPE_NUMERIC:
					double dbTemp = cell.getNumericCellValue();

					strValue = String.valueOf(dbTemp);
					break;

				// 字符串类型
				case HSSFCell.CELL_TYPE_STRING:
					strValue = cell.getStringCellValue();
					break;

				// 其他类型
				default:
					strValue = cell.getStringCellValue();
				}
			}

			if (strValue.length() == 0) {
				strValue = " ";
			}
			// 如果是科学计数法, 转换成标准格式
			if (null != strValue && strValue.indexOf(".") != -1 && strValue.indexOf("E") != -1) {
				DecimalFormat df = new DecimalFormat();
				try {
					String regex = "^([1-9]\\d*\\.\\d*|0\\.\\d*[1-9]\\d*|^-[1-9]\\d*\\.\\d*|-0\\.\\d*[1-9]\\d*)$";
					if (strValue.matches(regex)) {
						strValue = df.parse(strValue).toString();
					}
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}

			strLine += "#" + strValue;
		}

		return strLine;
	}

    /**
     * 上海银行出金文件格式解析
     * @param file
     * @param checkBillForm
     * @param stringshell
     * @return
     * @throws BusinessException
     * @throws IOException
     * @throws ParseException
     */
    public static List<BankTrans> loadBoshxlsx(HSSFSheet hssfSheet, XSSFSheet xssfSheet, CheckBillForm checkBillForm, String stringshell)
            throws BusinessException, IOException, ParseException {
        List<BankTrans> list = new ArrayList<BankTrans>();
        ExcelMap excelMap = null;
        try {
            excelMap = getExcelMap(stringshell);
        } catch (Exception e1) {
            new BusinessException(ExceptionDefine.错误配置文件格式);
        }
		//执行Xlsx文件
		if(null != xssfSheet){
			try {
				Double realamount = 0.00;
				XSSFRow row = null;
				String spare = null;
				String spareshell = null;
				String successhell = null;
				String transId = "";
				// 获得最后一排数
				// int rowNum = sheet.getLastRowNum()+excelMap.getStartline();
				for (int i = excelMap.getStartline(); i <= xssfSheet.getLastRowNum(); i++) {// 跳过第一行标题
					row = xssfSheet.getRow(i);
					transId = row.getCell(Short.valueOf(excelMap.getTransIdshell())).getStringCellValue();// 获取列值
					if(null!=row.getCell((short) excelMap.getSuccessshell())&&!"".equals(row.getCell((short) excelMap.getSuccessshell()))){
						successhell = row.getCell((short) excelMap.getSuccessshell()).getStringCellValue();
					}
					if (null != row && successhell.equals(excelMap.getSuccess()) && !transId.equals("")) {
						// 排除交易失败数据行
						int mm = row.getPhysicalNumberOfCells();
						// 其他成功限制
						if (null != excelMap.getSpare()) {
							spare = excelMap.getSpare();
							spareshell = row.getCell((short) excelMap.getSparePlace()).getStringCellValue();
						}
						if(null!=row.getCell((short) excelMap.getTransAmountshell())&&!"".equals(row.getCell((short) excelMap.getTransAmountshell()).toString())){

							if(row.getCell((short) excelMap.getTransAmountshell())!=null){
								row.getCell((short) excelMap.getTransAmountshell()).setCellType(Cell.CELL_TYPE_STRING);
								realamount = Double.valueOf(
										row.getCell((short) excelMap.getTransAmountshell()).getStringCellValue().replace(",", ""));
							}

						}

						// 解析Excel第2列
						String[] transIdArr = excelMap.getTransIdshell().split("\\|");
						if (transIdArr.length > 1){
							for (int j = 0; j < transIdArr.length; j++) {
								String s = transIdArr[j];
								if (j == transIdArr.length - 1){
									transId += row.getCell(Short.valueOf(s)).getStringCellValue();
								} else {
									transId += row.getCell(Short.valueOf(s)).getStringCellValue() + "|";
								}
							}
						} else {
							if (null == row.getCell(Short.valueOf(excelMap.getTransIdshell()))){
								continue;
							}

							if (transId.length() > 0 && transId.length() < 15){ //判断交易编号长度
								throw new BusinessException(ExceptionDefine.交易编号格式错误请检查对账文件);
							}
						}
						//解析日期
						String date = null;
						String dateOne = row.getCell((short) excelMap.getTransDateshell()).getStringCellValue();
						//				dateOne = new SimpleDateFormat("yyyy-MM-dd").format(new Date(dateOne));
						date = dateOne.replace("-","");
						if (date.matches("[0-9]+")) {
							date = date.substring(0,8);
						}
						Date sdf = new SimpleDateFormat("yyyyMMdd").parse(date);
						// 判断交易金额类型解析不同格式
						String amount = "";
						BigDecimal transAmount = null;

						XSSFCell cell = row.getCell((short) excelMap.getTransAmountshell());
						// 字符串类型金额
						amount = cell.getStringCellValue().replace(",", "");
						transAmount = new BigDecimal(amount);
						BankTrans trans = new BankTrans();
						trans.setTransId(transId);
						trans.setTransDate(StringUtils.gettime(checkBillForm.getStartDate()));
						trans.setChannel(checkBillForm.getChannel());
						trans.setTransTime(sdf);
						trans.setAmount(transAmount.doubleValue());
						list.add(trans);
					}
				}
			}catch (ParseException e) {
				throw new BusinessException(ExceptionDefine.对账文件格式错误);
			}
		} else { //执行xls
			try {
				Double realamount = 0.00;
				HSSFRow row = null;
				String spare = null;
				String spareshell = null;
				String successhell = null;
				String transId = "";
				// 获得最后一排数
				// int rowNum = sheet.getLastRowNum()+excelMap.getStartline();
				for (int i = excelMap.getStartline(); i <= hssfSheet.getLastRowNum(); i++) {// 跳过第一行标题
					row = hssfSheet.getRow(i);
					transId = row.getCell(Short.valueOf(excelMap.getTransIdshell())).getStringCellValue();// 获取列值
					if(null!=row.getCell((short) excelMap.getSuccessshell())&&!"".equals(row.getCell((short) excelMap.getSuccessshell()))){
						successhell = row.getCell((short) excelMap.getSuccessshell()).getStringCellValue();
					}
                    if (null != row && (successhell.equals(Constants.CHANNEL_BOSH_FLAG) || successhell.equals(Constants.CHANNEL_BOSH_IB_FLAG)) && !transId.equals("")) {
						// 排除交易失败数据行
						int mm = row.getPhysicalNumberOfCells();
						// 其他成功限制
						if (null != excelMap.getSpare()) {
							spare = excelMap.getSpare();
							spareshell = row.getCell((short) excelMap.getSparePlace()).getStringCellValue();
						}
						if(null!=row.getCell((short) excelMap.getTransAmountshell())&&!"".equals(row.getCell((short) excelMap.getTransAmountshell()).toString())){

							if(row.getCell((short) excelMap.getTransAmountshell())!=null){
								row.getCell((short) excelMap.getTransAmountshell()).setCellType(Cell.CELL_TYPE_STRING);
								realamount = Double.valueOf(
										row.getCell((short) excelMap.getTransAmountshell()).getStringCellValue().replace(",", ""));
							}

						}

						// 解析Excel第2列
						String[] transIdArr = excelMap.getTransIdshell().split("\\|");
						if (transIdArr.length > 1){
							for (int j = 0; j < transIdArr.length; j++) {
								String s = transIdArr[j];
								if (j == transIdArr.length - 1){
									transId += row.getCell(Short.valueOf(s)).getStringCellValue();
								} else {
									transId += row.getCell(Short.valueOf(s)).getStringCellValue() + "|";
								}
							}
						} else {
							if (null == row.getCell(Short.valueOf(excelMap.getTransIdshell()))){
								continue;
							}

							if (transId.length() > 0 && transId.length() < 15){ //判断交易编号长度
								throw new BusinessException(ExceptionDefine.交易编号格式错误请检查对账文件);
							}
						}
						//解析日期
						String date = null;
						String dateOne = row.getCell((short) excelMap.getTransDateshell()).getStringCellValue();
						//				dateOne = new SimpleDateFormat("yyyy-MM-dd").format(new Date(dateOne));
						date = dateOne.replace("-","");
						if (date.matches("[0-9]+")) {
							date = date.substring(0,8);
						}
						Date sdf = new SimpleDateFormat("yyyyMMdd").parse(date);
						// 判断交易金额类型解析不同格式
						String amount = "";
						BigDecimal transAmount = null;

						HSSFCell cell = row.getCell((short) excelMap.getTransAmountshell());
						// 字符串类型金额
						amount = cell.getStringCellValue().replace(",", "");
						transAmount = new BigDecimal(amount);
						BankTrans trans = new BankTrans();
						trans.setTransId(transId);
						trans.setTransDate(StringUtils.gettime(checkBillForm.getStartDate()));
						trans.setChannel(checkBillForm.getChannel());
						trans.setTransTime(sdf);
						trans.setAmount(transAmount.doubleValue());
						list.add(trans);
					}
				}
			}catch (ParseException e) {
				throw new BusinessException(ExceptionDefine.对账文件格式错误);
			}
		}
		return list;
    }

    /**
	 * 解析获取TXT文件字段所处位置
	 * 
	 * @param str
	 * @return
	 * @throws IOException
	 */
	public static TxtMap getTxtMap(String str) throws Exception {
		String[] st = str.split(",");
		TxtMap txtMap = new TxtMap();
		txtMap.setStartLine(Integer.valueOf(st[0]));
		txtMap.setTransAmountshell(Integer.valueOf(st[1]));
		txtMap.setTransDateshell(Integer.valueOf(st[2]));
		txtMap.setTransIdshell(Integer.valueOf(st[3]));
		txtMap.setLineLength(Integer.valueOf(st[4]));
		txtMap.setSplitFlag(st[5].toString());
		return txtMap;
	}

	public static TxtMap getTxtMap(List<String> str) throws Exception {
		TxtMap txtMap = new TxtMap();
		txtMap.setStartLine(Integer.valueOf(str.get(0)));
		txtMap.setTransAmountshell(Integer.valueOf(str.get(1)));
		txtMap.setTransDateshell(Integer.valueOf(str.get(2)));
		txtMap.setTransIdshell(Integer.valueOf(str.get(3)));
		txtMap.setLineLength(Integer.valueOf(str.get(4)));
		txtMap.setSplitFlag(str.get(5));
		return txtMap;
	}

	public static TxtMap getTxtMap(String[] st) throws Exception {
		TxtMap txtMap = new TxtMap();
		txtMap.setStartLine(Integer.valueOf(st[0]));
		txtMap.setTransAmountshell(Integer.valueOf(st[1]));
		txtMap.setTransDateshell(Integer.valueOf(st[2]));
		txtMap.setTransIdshell(Integer.valueOf(st[3]));
		txtMap.setLineLength(Integer.valueOf(st[4]));
		txtMap.setSplitFlag(st[5].toString());
		return txtMap;
	}
}
