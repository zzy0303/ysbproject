package com.uns.model;

import java.math.BigDecimal;
import java.util.Date;

public class EpccQpTransRef {
    private Integer id;

    private String transId;

    private String epccTransId;

    private Date createTime;

    private Date updateTime;

    private String dbtrBankId;

    private String serviceType;

    private String oriTrxDtTm;

    private String transStatus;

    private String pyerAcctIssrId;

    private String pyeeAcctIssrId;

    private String transType;

    private BigDecimal transAmount;

    private String bathchId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTransId() {
        return transId;
    }

    public void setTransId(String transId) {
        this.transId = transId == null ? null : transId.trim();
    }

    public String getEpccTransId() {
        return epccTransId;
    }

    public void setEpccTransId(String epccTransId) {
        this.epccTransId = epccTransId == null ? null : epccTransId.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getDbtrBankId() {
        return dbtrBankId;
    }

    public void setDbtrBankId(String dbtrBankId) {
        this.dbtrBankId = dbtrBankId == null ? null : dbtrBankId.trim();
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType == null ? null : serviceType.trim();
    }

    public String getOriTrxDtTm() {
        return oriTrxDtTm;
    }

    public void setOriTrxDtTm(String oriTrxDtTm) {
        this.oriTrxDtTm = oriTrxDtTm == null ? null : oriTrxDtTm.trim();
    }

    public String getTransStatus() {
        return transStatus;
    }

    public void setTransStatus(String transStatus) {
        this.transStatus = transStatus == null ? null : transStatus.trim();
    }

    public String getPyerAcctIssrId() {
        return pyerAcctIssrId;
    }

    public void setPyerAcctIssrId(String pyerAcctIssrId) {
        this.pyerAcctIssrId = pyerAcctIssrId == null ? null : pyerAcctIssrId.trim();
    }

    public String getPyeeAcctIssrId() {
        return pyeeAcctIssrId;
    }

    public void setPyeeAcctIssrId(String pyeeAcctIssrId) {
        this.pyeeAcctIssrId = pyeeAcctIssrId == null ? null : pyeeAcctIssrId.trim();
    }

    public String getTransType() {
        return transType;
    }

    public void setTransType(String transType) {
        this.transType = transType == null ? null : transType.trim();
    }

    public BigDecimal getTransAmount() {
        return transAmount;
    }

    public void setTransAmount(BigDecimal transAmount) {
        this.transAmount = transAmount;
    }

    public String getBathchId() {
        return bathchId;
    }

    public void setBathchId(String bathchId) {
        this.bathchId = bathchId == null ? null : bathchId.trim();
    }
}