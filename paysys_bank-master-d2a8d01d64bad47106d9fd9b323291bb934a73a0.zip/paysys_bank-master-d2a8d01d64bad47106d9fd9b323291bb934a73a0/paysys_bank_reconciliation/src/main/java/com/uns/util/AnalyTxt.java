package com.uns.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.model.BankTrans;
import com.uns.web.form.CheckBillForm;
import org.apache.commons.lang.time.DateUtils;

public class AnalyTxt {
	/**
	 * 解析txt文件
	 *
	 * @param file
	 * @param checkBillForm
	 * @param str
	 * @return
	 */
	public static List<BankTrans> LoadTxt(InputStream file, CheckBillForm checkBillForm, String str)
			throws BusinessException, IOException {

		List<BankTrans> list = new ArrayList<BankTrans>();
		ExcelMap txtMap = getTxt(str);
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(file, "utf-8"));
			for (String line = reader.readLine(); line != null; line = reader.readLine()) {
				if (line.trim().length() == 0) {
                    continue;
                }
				String[] data = line.split("\\|");
				// 交易时间
				if (data.length > 3 && data[txtMap.getSuccessshell()].trim().equals(txtMap.getSuccess())) {
					String fDate = data[txtMap.getTransDateshell()].substring(0, 13);
					Date date = new SimpleDateFormat("yyyyMMddHHmmss").parse(fDate);
					if (date == null) {
						throw new BusinessException(ExceptionDefine.对账文件格式错误);
					}
					// 订单号
					if (data[Integer.valueOf(txtMap.getTransIdshell())].length() < 1) {
						throw new BusinessException(ExceptionDefine.对账文件格式错误);
					}
					// 金额
					BigDecimal transAmount = new BigDecimal(data[txtMap.getTransAmountshell()])
							.divide(new BigDecimal(100)).setScale(2);
					BankTrans trans = new BankTrans();
					trans.setTransId(data[Integer.valueOf(txtMap.getTransIdshell())]);
					Date transDate = new SimpleDateFormat("yyyyMMdd")
							.parse(data[txtMap.getTransDateshell()].substring(0, 8));
					trans.setTransDate(transDate);
					trans.setChannel(checkBillForm.getChannel());
					trans.setTransTime(date);
					trans.setAmount(transAmount.doubleValue());
					list.add(trans);
				}
			}
		} catch (IOException e) {
			throw new BusinessException(ExceptionDefine.对账文件格式错误);
		} catch (ParseException e) {
			e.printStackTrace();
		} finally {
			if (null != file){
				file.close();
			}
		}
		return list;

	}

	/**
	 * 解析文件中字段所处位置
	 *
	 * @param str
	 * @return
	 */
	public static ExcelMap getTxt(String str) {
		String[] arayStr = str.split(",");
		ExcelMap excelMap = new ExcelMap();
		excelMap.setStartline(Integer.valueOf(arayStr[0]));
		excelMap.setSuccess(arayStr[1]);
		excelMap.setSuccessshell(Integer.valueOf(arayStr[2]));
		excelMap.setTransAmountshell(Integer.valueOf(arayStr[3]));
		excelMap.setTransDateshell(Integer.valueOf(arayStr[4]));
		excelMap.setTransIdshell(arayStr[5]);
		return excelMap;
	}
	
	/**
	 * 厦门银联对账
	 * @param file
	 * @param checkBillForm
	 * @param str
	 * @return
	 * @throws Exception
	 */
    public static List<BankTrans> loadUnionpayXmTxt(InputStream file, CheckBillForm checkBillForm, String str) throws Exception {
        List<BankTrans> list = new ArrayList<>();
        try {
            String[] st = str.split(",");
            TxtMap txtMap = getTxtMap(st);
            BufferedReader reader = new BufferedReader(new InputStreamReader(file, "utf-8"));
            for (String line = reader.readLine(); line != null; line = reader.readLine()) {
                if (line.trim().length() == Constants.FLAG_INT_0) {
                    continue;
                }
                String[] data = line.split(txtMap.getSplitFlag());
                if (data.length >= Constants.UNIONPAYXMOUTLENGTH) {
                	//拼接日期为2017年份
					//TODO 提交时改回：DateUtil.getDateType(new Date(), "yyyy")
                   // String fDate =  DateUtil.getDateType(new Date(), "yyyy") + data[txtMap.getTransDateshell()].substring(0, 4);
                   // Date date = new SimpleDateFormat("yyyyMMdd").parse(fDate);
                	String fDate=null;
                	if(data[txtMap.getTransDateshell()].contains("N")){
                		fDate=data[txtMap.getTransDateshell()].substring(2, 10);
                	}else{
                		fDate=data[txtMap.getTransDateshell()].substring(0, 8);	
                	}
                	Date date = new SimpleDateFormat("yyyyMMdd").parse(fDate);
                    if (null == date) {
                        throw new BusinessException(ExceptionDefine.对账文件格式错误);
                    }
                    // 订单号
                    if (data[Integer.valueOf(txtMap.getTransIdshell())].length() < 1) {
                        throw new BusinessException(ExceptionDefine.对账文件格式错误);
                    }
                    // 金额
                    BigDecimal transAmount = new BigDecimal(data[txtMap.getTransAmountshell()])
                            .divide(new BigDecimal(100)).setScale(2);
                    BankTrans trans = new BankTrans();
                    trans.setTransId(data[Integer.valueOf(txtMap.getTransIdshell())]);
                    trans.setTransDate(date);
                    trans.setChannel(checkBillForm.getChannel());
                    trans.setTransTime(date);
                    trans.setAmount(transAmount.doubleValue());
                    list.add(trans);
                }
            }
        } catch (IOException e) {
            throw new BusinessException(ExceptionDefine.对账文件格式错误);
        } catch (ParseException e) {
            e.printStackTrace();
        } finally {
            if (null != file) {
                file.close();
            }
        }
        return list;
    }

    public static TxtMap getTxtMap(String[] st) throws Exception {
        TxtMap txtMap = new TxtMap();
        txtMap.setStartLine(Integer.valueOf(st[0]));
        txtMap.setTransAmountshell(Integer.valueOf(st[1]));
        txtMap.setTransDateshell(Integer.valueOf(st[2]));
        txtMap.setTransIdshell(Integer.valueOf(st[3]));
        txtMap.setLineLength(Integer.valueOf(st[4]));
        txtMap.setSplitFlag(st[5].toString());
        return txtMap;
    }
}
