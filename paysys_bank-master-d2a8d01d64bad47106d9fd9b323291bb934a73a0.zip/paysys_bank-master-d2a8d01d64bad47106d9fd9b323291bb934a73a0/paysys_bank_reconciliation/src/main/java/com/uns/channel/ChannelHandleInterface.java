package com.uns.channel;

import com.uns.model.BankTrans;
import com.uns.web.form.CheckBillForm;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/10/20
 * @Modifyed By:
 */
public interface ChannelHandleInterface {

    /**
     * 获取对账单数据
     * @param inputStream  上传的对账单
     * @param checkBillForm  表单
     * @return
     */
    List<BankTrans> loadDate(InputStream inputStream, CheckBillForm checkBillForm) throws Exception;

    /**
     * 获取本地交易
     * @param id 对账记录ID
     * @return
     * @throws Exception
     */
    List<Map<String, Object>> getLocalTrans(Integer id) throws Exception;

    /**
     * 汇总对账通道金额
     * @param channel
     * @param checkDate
     * @return
     */
    Map<String, Object> getLocalAmount(String channel, String checkDate);

    List<String> getChannelList() throws Exception;

}
