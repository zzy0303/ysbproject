package com.uns.web.form;

import java.util.List;

public class AdjustApplyForm {

	private String transId;
	private String nameEmailPhone;
	private String bankSeq;
	private String actionSeq;
	private String startDate;
	private String endDate;

	private String[] record;
	private String transSeqs;
	private String applyReason;
	private String applyRemark;
	private String checkStatus;
	private String allRecord;
	private String billType;
	private String detailId;

	private String localTransId;

	public String getLocalTransId() {
		return localTransId;
	}

	public void setLocalTransId(String localTransId) {
		this.localTransId = localTransId;
	}

	public String getDetailId() {
		return detailId;
	}

	public void setDetailId(String detailId) {
		this.detailId = detailId;
	}

	public String getBillType() {
		return billType;
	}

	public void setBillType(String billType) {
		this.billType = billType;
	}

	public String getTransSeqs() {
		return transSeqs;
	}

	public void setTransSeqs(String transSeqs) {
		this.transSeqs = transSeqs;
	}

	public String[] getRecord() {
		return record;
	}

	public void setRecord(String[] record) {
		this.record = record;
	}

	public String getAllRecord() {
		return allRecord;
	}

	public void setAllRecord(String allRecord) {
		this.allRecord = allRecord;
	}

	public String getCheckStatus() {
		return checkStatus;
	}

	public void setCheckStatus(String checkStatus) {
		this.checkStatus = checkStatus;
	}

	public String getApplyReason() {
		return applyReason;
	}

	public void setApplyReason(String applyReason) {
		this.applyReason = applyReason;
	}

	public String getApplyRemark() {
		return applyRemark;
	}

	public void setApplyRemark(String applyRemark) {
		this.applyRemark = applyRemark;
	}

	public String getTransId() {
		return transId;
	}

	public void setTransId(String transId) {
		this.transId = transId;
	}

	public String getNameEmailPhone() {
		return nameEmailPhone;
	}

	public void setNameEmailPhone(String nameEmailPhone) {
		this.nameEmailPhone = nameEmailPhone;
	}

	public String getBankSeq() {
		return bankSeq;
	}

	public void setBankSeq(String bankSeq) {
		this.bankSeq = bankSeq;
	}

	public String getActionSeq() {
		return actionSeq;
	}

	public void setActionSeq(String actionSeq) {
		this.actionSeq = actionSeq;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

}
