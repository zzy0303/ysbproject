package com.uns.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {

	public static String YYYY_MM_DD = "yyyy-MM-dd";

	public static String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
	
	/**
	 * @param date：日期
	 * @param type：格式
	 * @return
	 */
	public static String getDateType(Date date, String type) {
		SimpleDateFormat str = new SimpleDateFormat(type);
		String strDates = str.format(date);
		return strDates;
	}
	
	/**
	 * @param datess
	 * @param type
	 * @return
	 */
	public static String getTypeDate(Date datess, String type) {
		SimpleDateFormat str = new SimpleDateFormat(type);
		String strDates = str.format(datess);
		return strDates;
	}
}
