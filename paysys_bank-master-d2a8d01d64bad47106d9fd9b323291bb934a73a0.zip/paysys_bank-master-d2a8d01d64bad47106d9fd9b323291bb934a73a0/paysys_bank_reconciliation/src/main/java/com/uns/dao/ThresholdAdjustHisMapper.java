package com.uns.dao;

import com.uns.model.ThresholdAdjustHis;
import com.uns.web.form.ThresholdHisForm;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Repository
public interface ThresholdAdjustHisMapper {

    int deleteByPrimaryKey(BigDecimal id);

    int insert(ThresholdAdjustHis record);

    int insertSelective(ThresholdAdjustHis record);

    ThresholdAdjustHis selectByPrimaryKey(BigDecimal id);

    int updateByPrimaryKeySelective(ThresholdAdjustHis record);

    int updateByPrimaryKey(ThresholdAdjustHis record);

    List<ThresholdAdjustHis> getThresholdHisList(ThresholdHisForm thresholdHisForm);

    Map<String,Object> sumThresholdHisAmountFee(ThresholdHisForm thresholdHisForm);
}