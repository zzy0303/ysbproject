package com.uns.dao;

import java.math.BigDecimal;
import org.springframework.stereotype.Repository;
import com.uns.model.TReconcileRecord;

@Repository
public interface TReconcileRecordMapper {

	int deleteByPrimaryKey(BigDecimal id);

	int insert(TReconcileRecord record);

	int insertSelective(TReconcileRecord record);

	TReconcileRecord selectByPrimaryKey(BigDecimal id);

	int updateByPrimaryKeySelective(TReconcileRecord record);

	int updateByPrimaryKeyWithBLOBs(TReconcileRecord record);

	int updateByPrimaryKey(TReconcileRecord record);
}