package com.uns.service;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.Page;
import com.uns.dao.AccountMapper;
import com.uns.dao.WhiteAccountMapper;
import com.uns.model.Account;
import com.uns.model.UserInfo;
import com.uns.model.WhiteAccount;
import com.uns.web.form.WhiteAccountForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/8/28
 * @Modifyed By:
 */
@Service
public class WhiteAccountService {

    @Autowired
    private WhiteAccountMapper whiteAccountMapper;

    @Autowired
    private AccountMapper accountMapper;

    public List<WhiteAccount> queryWhiteAccountList(WhiteAccountForm whiteAccountForm) throws Exception {
        Page page = new Page();
        page.setPageSize(3);
        List<WhiteAccount> whiteAccounts = whiteAccountMapper.queryWhiteAccountList(whiteAccountForm);
        return whiteAccounts;
    }

    @Transactional
    public void saveWhiteAccount(WhiteAccount whiteAccount, HttpServletRequest request) throws Exception {

        WhiteAccount whiteAccountnew = whiteAccountMapper.queryWhiteAccountByParam(whiteAccount);
        if (null != whiteAccountnew) {
            throw  new BusinessException(ExceptionDefine.该商户此交易类型已添加);
        }
        UserInfo userInfo = (UserInfo) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
        whiteAccount.setReason(whiteAccount.getReason());
        whiteAccount.setOperUserId(new BigDecimal(userInfo.getId()));
        whiteAccount.setOperTime(new Date());
        whiteAccount.setStatus(Constants.WHITE_ACCOUNT_STATUS_1); //已启用
        whiteAccountMapper.insertSelective(whiteAccount);
    }

    @Transactional
    public void editWhiteAccount(WhiteAccount whiteAccount) throws Exception {
        WhiteAccount whiteAccountNew = whiteAccountMapper.queryWhiteAccountByParam(whiteAccount);
        if (null == whiteAccountNew){
            throw  new BusinessException(ExceptionDefine.此白名单商户不存在);
        }
        whiteAccountMapper.updateByPrimaryKeySelective(whiteAccount);
    }

    public String queryAccountByDefaultSeq(String defaultSeq) {
        Account account = accountMapper.queryAccountByDefaultSeq(defaultSeq);
        return account.getAccountId();
    }
}
