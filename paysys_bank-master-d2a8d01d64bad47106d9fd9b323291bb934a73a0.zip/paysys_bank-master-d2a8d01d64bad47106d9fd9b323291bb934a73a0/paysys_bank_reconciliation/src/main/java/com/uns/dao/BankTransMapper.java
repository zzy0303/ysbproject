package com.uns.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.BankTrans;

@Repository
public interface BankTransMapper {

	int deleteByPrimaryKey(BigDecimal id);

	int insert(BankTrans record);

	int insertList(List<BankTrans> list);

	int insertSelective(BankTrans record);

	BankTrans selectByPrimaryKey(BigDecimal id);

	int updateByPrimaryKeySelective(BankTrans record);

	int updateByPrimaryKey(BankTrans record);

	void deleteBankTrans(Long id);

	List<BankTrans> getBankTrans(Integer id);

	Map<String, Object> getTransDetail(String transId);

	List<String> getAllTransDetail(Map<String, Object> map);

	Map<String, Object> getTotalBankInfo(Map<String, Object> map);

	Map<String, Object> getTotalLocalInfo(Map<String, Object> map);

	List<BankTrans> getBankTransInActTypes(Map<String, Object> params);

	List<BankTrans> getBankTransInActListVal(Map<String, Object> params);

	List<BankTrans> getCnbcB2cBankTrans(Integer id);

	List<BankTrans> getNetsUnionBankTrans(Map<String, Object> maps);

	List<BankTrans> getNetsUnionHungUpBankTrans(String checkdate);

    List<BankTrans> getUnionpayXmDpTrans(Integer id);
}