package com.uns.channel;

import com.uns.common.Constants;
import com.uns.dao.CheckBillMapper;
import com.uns.model.BankTrans;
import com.uns.service.CheckBillService;
import com.uns.util.AnalyExcel;
import com.uns.web.form.CheckBillForm;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/11/3
 * @Modifyed By:
 */
public class ChannelHandleBocB2c extends ChannelHandleDefault implements ChannelHandleInterface {

    @Override
    public List<BankTrans> loadDate(InputStream inputStream, CheckBillForm checkBillForm) throws Exception {
        return AnalyExcel.loadBocbText(inputStream, checkBillForm, Constants.UPLOAD_BOC_B2C_TXT);
    }

    @Override
    public List<Map<String, Object>> getLocalTrans(Integer id) throws Exception {
        pareMap.put("id", id);
        pareMap.put("channel", Constants.UPLOAD_BOC_B2C_CHANNEL);
        pareMap.put("actionType", Constants.UPLOAD_B2C_ACTIONTYPE);
        return checkBillMapper.getBoshTrans(pareMap);
    }

    @Override
    public Map<String, Object> getLocalAmount(String channel, String checkDate) {
        return null;
    }

    @Override
    public List<String> getChannelList() throws Exception {
        return null;
    }
}
