package com.uns.web.form;

import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.List;

public class CheckBillForm {

	private MultipartFile[] checkBillFile;

	private List<InputStream> fileList;

	private String fileName;

	private String id;

	private String ids;

	private String channel;

	private String startDate;

	private String endDate;

	private String checkStatus;

	private String connType;

	private String dealRemark;

	private String checkdate;

	private String channel1;

	private String channel2;

	//处理时间
	private String checkTime;
	//处理人
	private String checkUser;

	private String billType;

	private String batchId;

	private String status;

	private String bankBatchId;

	public String getBankBatchId() {
		return bankBatchId;
	}

	public void setBankBatchId(String bankBatchId) {
		this.bankBatchId = bankBatchId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	public String getIds() {
		return ids;
	}

	public void setIds(String ids) {
		this.ids = ids;
	}

	public String getCheckTime() {
		return checkTime;
	}

	public void setCheckTime(String checkTime) {
		this.checkTime = checkTime;
	}

	public String getCheckUser() {
		return checkUser;
	}

	public void setCheckUser(String checkUser) {
		this.checkUser = checkUser;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	private String checkType; //0 手动对账 1 自动对账

	public List<InputStream> getFileList() {
		return fileList;
	}

	public void setFileList(List<InputStream> fileList) {
		this.fileList = fileList;
	}

	public String getCheckType() {
		return checkType;
	}

	public void setCheckType(String checkType) {
		this.checkType = checkType;
	}

	public String getChannel1() {
		return channel1;
	}

	public void setChannel1(String channel1) {
		this.channel1 = channel1;
	}

	public String getChannel2() {
		return channel2;
	}

	public void setChannel2(String channel2) {
		this.channel2 = channel2;
	}

	public String getCheckdate() {
		return checkdate;
	}

	public void setCheckdate(String checkdate) {
		this.checkdate = checkdate;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDealRemark() {
		return dealRemark;
	}

	public void setDealRemark(String dealRemark) {
		this.dealRemark = dealRemark;
	}

	public String getConnType() {
		return connType;
	}

	public void setConnType(String connType) {
		this.connType = connType;
	}

	public String getCheckStatus() {
		return checkStatus;
	}

	public void setCheckStatus(String checkStatus) {
		this.checkStatus = checkStatus;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public MultipartFile[] getCheckBillFile() {
		return checkBillFile;
	}

	public void setCheckBillFile(MultipartFile[] checkBillFile) {
		this.checkBillFile = checkBillFile;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getBillType() {
		return billType;
	}

	public void setBillType(String billType) {
		this.billType = billType;
	}
}
