package com.uns.web.controller;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.model.CheckBill;
import com.uns.model.FileUploadRecord;
import com.uns.model.UserInfo;
import com.uns.service.CheckBillService;
import com.uns.service.FileUploadRecordService;
import com.uns.util.StringUtils;
import com.uns.web.form.CheckBillForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/1/3
 * @Modifyed By:
 */
@Controller
@RequestMapping(value = "/outCheckBill.htm")
public class OutCheckBillController {

    @Autowired
    private CheckBillService checkBillService;

    @Autowired
    private FileUploadRecordService fileUploadRecordService;

    @Autowired
    private MessageSource messageSource;

    /**
     * 查询出金对账列表
     * @param request
     * @param checkBillForm
     * @return
     * @throws BusinessException
     */
    @RequestMapping(params = "method=outCheckBillList")
    @FormToken(save = true)
    public String checkBillList(HttpServletRequest request, CheckBillForm checkBillForm) throws BusinessException {
        //获取出金对账通道
        String[] outChannel = Constants.OUT_CHECK_BILL_CHANNEL.split(",");
        checkBillForm.setBillType(Constants.CHECK_BILL_1);
        List<CheckBill> checkList = checkBillService.getCheckList(checkBillForm);
        request.setAttribute("outChannel", outChannel);
        request.setAttribute("checkList", checkList);
        request.setAttribute("checkBillForm", checkBillForm);
        return "outcheckbill/checkBillList";
    }

    /**
     * 跳转对账单上传页面
     * @param request
     * @param checkBillForm
     * @return
     * @throws BusinessException
     */
    @RequestMapping(params = "method=toUploadList")
    @FormToken(save = true)
    public String toUploadList(HttpServletRequest request, CheckBillForm checkBillForm) throws BusinessException {
        //获取出金对账通道
        String[] outChannel = Constants.OUT_CHECK_BILL_CHANNEL.split(",");
        checkBillForm.setBillType(Constants.CHECK_BILL_1);
        String getChannel = request.getParameter("channel").toString();
        String getCheckDate = request.getParameter("checkdate").toString();
        request.setAttribute("getChannel", getChannel);
        request.setAttribute("getCheckDate", getCheckDate);
        request.setAttribute("outChannel", outChannel);
        return "outcheckbill/upload";
    }

    /**
     * 上传对账文件
     * @param request
     * @param checkBillForm
     * @return
     * @throws BusinessException
     * @throws IOException
     */
    @RequestMapping(params = "method=upload")
    @FormToken(save = true)
    public String upload(HttpServletRequest request, CheckBillForm checkBillForm)
            throws BusinessException, IOException {
        String path = "checkbill/upload";
        UserInfo user = (UserInfo) (request.getSession().getAttribute(Constants.SESSION_KEY_USER));
        try {
            checkBillForm.setBillType(Constants.FLAG_1);
            checkBillService.checkBill(checkBillForm, user.getUserName());
            //查询对账　记录列表　回显
            List<FileUploadRecord> list = fileUploadRecordService.getOutUploadRecordList(checkBillForm);
            request.setAttribute("uploadList", list);
            request.setAttribute("accountForm", null);
            path = "outcheckbill/uploadOutRecordList";
        } catch (BusinessException be) {
            request.setAttribute("errMsg", be.getErrMessage(messageSource));
        } catch (Exception e) {
            request.setAttribute("errMsg", "保存出错！");
            e.printStackTrace();
        }
        // 获取通道信息传值到页面
        if (!path.equals("outcheckbill/uploadOutRecordList")) {
            String[] outChannel = Constants.OUT_CHECK_BILL_CHANNEL.split(",");
            request.setAttribute("outChannel", outChannel);
            path = "outcheckbill/upload";
        }
        return path;
    }

}
