package com.uns.biz;

import com.uns.model.BankTrans;
import com.uns.web.form.CheckBillForm;

import java.text.SimpleDateFormat;
import java.util.*;

public class BizAbcB2c extends DefaultBiz {
    @Override
    public boolean checkInputData(String[] data, CheckBillForm checkBillForm, BankTrans trans,
                                  Map<String, List<String>> setting) throws Exception {

        Calendar calendar = new GregorianCalendar();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        calendar.setTime(sdf.parse(checkBillForm.getStartDate()));
        calendar.add(Calendar.DATE, 1);
        Date standardDate = calendar.getTime();//比对账日期多一天
        
        sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        Date thisTransDate = sdf.parse(trans.getTransTimeStr());//对账文件上面的日期
        if(thisTransDate.getTime() >= standardDate.getTime()){
            return false;
        }
        
        boolean rtn = super.checkInputData(data, checkBillForm, trans, setting);
        return rtn;
    }
}
