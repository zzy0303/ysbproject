package com.uns.dao;

import java.math.BigDecimal;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.AuditRule;

@Repository
public interface AuditRuleMapper {

	int deleteByPrimaryKey(BigDecimal id);

	int insert(AuditRule record);

	int insertSelective(AuditRule record);

	AuditRule selectByPrimaryKey(BigDecimal id);

	int updateByPrimaryKeySelective(AuditRule record);

	int updateByPrimaryKey(AuditRule record);

	AuditRule getAuditRule(Map<String, Object> map);
}