package com.uns.web.controller;

import com.alibaba.fastjson.JSONObject;
import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.page.PageContext;
import com.uns.logic.CheckBillTrans;
import com.uns.model.CheckBillTransDetail;
import com.uns.model.ThresholdAdjustHis;
import com.uns.model.UserInfo;
import com.uns.model.WhiteAccount;
import com.uns.service.ThresholdService;
import com.uns.util.PoiUtils;
import com.uns.web.form.PreThresholdForm;
import com.uns.web.form.ThresholdHisForm;
import com.uns.web.form.ThresholdsForm;
import com.uns.web.form.WhiteAccountForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/8/31
 * @Modifyed By:
 */
@Controller
@RequestMapping(value = "/threshold.htm")
public class ThresholdController {

    @Autowired
    private ThresholdService thresholdService;

    @RequestMapping(params = "method=preThresholdListPage")
    public String preThresholdListPage(HttpServletRequest request,ThresholdsForm thresholdsForm){
        request.setAttribute("thresholdsForm", thresholdsForm);
        return "/threshold/waitThresholdList";
    }

    /**
     * 查询未调整阀值列表
     *
     * @param thresholdsForm
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(params = "method=queryThresholdList")
    public String queryThresholdList(ThresholdsForm thresholdsForm, HttpServletRequest request, HttpServletResponse response) {
        try {
            List<ThresholdsForm> thresholdsFormList = thresholdService.queryThresholdList(thresholdsForm);
            request.setAttribute("thresholdsFormList", thresholdsFormList);
            request.setAttribute("thresholdsForm", thresholdsForm);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "/threshold/waitThresholdList";
    }

    /**
     * 导出未调阀值列表Page页
     * @param thresholdsForm
     * @param request
     * @param response
     */
    @RequestMapping(params = "method=exportThresholdPageList")
    public String exportThresholdPageList(ThresholdsForm thresholdsForm, HttpServletRequest request, HttpServletResponse response){
        try {
            PageContext context = PageContext.getContext();
            context.setPageSize(Constants.EXCEL_SIZE);
            thresholdService.queryThresholdList(thresholdsForm);
            request.setAttribute("thresholdsForm", thresholdsForm);
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        return "threshold/exportThresholdPage";
    }

    /**
     * 导出未调阀值列表
     * @param request
     * @param response
     */
    @RequestMapping(params = "method=exportThresholdList")
    public void exportThresholdList(ThresholdsForm thresholdsForm, HttpServletRequest request, HttpServletResponse response){
        try {
            PageContext context = PageContext.getContext();
            context.setPageSize(Constants.EXCEL_SIZE);
            List<ThresholdsForm> thresholdsFormList = thresholdService.queryThresholdList(thresholdsForm);
            OutputStream out = response.getOutputStream();
            response.reset();
            response.setHeader("content-disposition",
                    "attachment;filename=" + new String((Constants.thresholdListTitle).getBytes("gb2312"), "ISO8859-1") + ".xls");
            response.setContentType("APPLICATION/msexcel");
            PoiUtils.exportThresholdListExcel(Constants.thresholdListTitle, Constants.thresholdListColunm, thresholdsFormList, out, Constants.DEFAULT_DATETIME_FORMAT);
        } catch (Exception e1) {
            e1.printStackTrace();
        }
    }

    /**
     * 查看待调阀值交易明细
     * @param thresholdsForm
     * @param request
     * @return
     */
    @RequestMapping(params = "method=preThresholdInfoList")
    public String preThresholdInfo(ThresholdsForm thresholdsForm, HttpServletRequest request) {
        try {
            List<CheckBillTransDetail> checkBillTransDetails = thresholdService.queryThresholdInfoList(thresholdsForm);
            request.setAttribute("checkBillTransDetails", checkBillTransDetails);
            request.setAttribute("thresholdsForm", thresholdsForm);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "/threshold/preThresholdInfo";
    }

    /**
     * 导出待调阀值交易明细Page
     * @param thresholdsForm
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(params = "method=exportThresholdInfoPageList")
    public String exportThresholdPageInfo(ThresholdsForm thresholdsForm, HttpServletRequest request, HttpServletResponse response) {
        try {
            PageContext context = PageContext.getContext();
            context.setPageSize(Constants.EXCEL_SIZE);
            thresholdService.queryThresholdInfoList(thresholdsForm);
            request.setAttribute("thresholdsForm", thresholdsForm);
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        return "threshold/exportThresholdInfoPage";
    }

    /**
     * 导出待调阀值交易明细
     * @param thresholdsForm
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(params = "method=exportThresholdInfoList")
    public void exportThresholdInfo(ThresholdsForm thresholdsForm, HttpServletRequest request, HttpServletResponse response) {
        try {
            PageContext context = PageContext.getContext();
            context.setPageSize(Constants.EXCEL_SIZE);
            List<CheckBillTransDetail> checkBillTransDetails = thresholdService.queryThresholdInfoList(thresholdsForm);
            OutputStream out = response.getOutputStream();
            response.reset();
            response.setHeader("content-disposition",
                    "attachment;filename=" + new String((Constants.thresholdInfoTitle).getBytes("gb2312"), "ISO8859-1") + ".xls");
            response.setContentType("APPLICATION/msexcel");
            PoiUtils.exportThresholdInfoExcel(Constants.thresholdInfoTitle, Constants.thresholdInfoColumn, checkBillTransDetails, out, Constants.DEFAULT_DATETIME_FORMAT);
        } catch (Exception e1) {
            e1.printStackTrace();
        }
    }

    /**
     * 跳转调整阀值页面
     * @param thresholdsForm
     * @param request
     * @return
     */
    @RequestMapping(params = "method=preThresholdList")
    public String preThresholdList(ThresholdsForm thresholdsForm, HttpServletRequest request) {
        try {
            List<PreThresholdForm> thresholdsFormList = thresholdService.queryPreThreshold(thresholdsForm.getThresholdFormList());
            Map<String, Object> sumMap = thresholdService.sumPreAmountFee(thresholdsFormList);
            request.setAttribute("thresholdsFormList", thresholdsFormList);
            request.setAttribute("sumMap", sumMap);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "/threshold/preThresholdList";
    }

    /**
     * 阀值调整
     * @param thresholdsForm
     * @param request
     * @return
     */
    @FormToken
    @RequestMapping(params = "method=amountThreshold")
    public String amountThreshold(ThresholdsForm thresholdsForm, HttpServletRequest request) {
        try {
            thresholdService.amountThreshold(thresholdsForm, (UserInfo) request.getSession().getAttribute(Constants.SESSION_KEY_USER));
            request.setAttribute("msg", "阀值调整成功");
        } catch (BusinessException be) {
            request.setAttribute("errMsg", be.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errMsg", "阀值调整失败!");
        }
        request.setAttribute("title", "阀值调整");
        request.setAttribute("closeTitle", "阀值调整列表");
        request.setAttribute("url", "threshold.htm?method=queryThresholdList");
        return "common/message";
    }

    /**
     * 查询阀值调整历史列表
     * @param thresholdHisForm
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(params = "method=queryThresholdHisList")
    public String queryThresholdHis(ThresholdHisForm thresholdHisForm, HttpServletRequest request, HttpServletResponse response) {
        try {
            List<ThresholdAdjustHis> thresholdAdjustHisList = thresholdService.queryThresholdHisList(thresholdHisForm);
            Map<String, Object> sumMap = thresholdService.sumThresholdHisAmountFee(thresholdHisForm);
            request.setAttribute("sumMap", sumMap);
            request.setAttribute("thresholdAdjustHisList", thresholdAdjustHisList);
            request.setAttribute("thresholdHisForm", thresholdHisForm);
        } catch (Exception e){
            e.printStackTrace();
        }
        return "/threshold/thresholdHisList";
    }

    /**
     * 导出阀值调整历史Page
     * @param thresholdHisForm
     * @param request
     * @param response
     */
    @RequestMapping(params = "method=exportThresholdHisPageList")
    public String exportThresholdPageHis(ThresholdHisForm thresholdHisForm, HttpServletRequest request, HttpServletResponse response) {
        try {
            PageContext context = PageContext.getContext();
            context.setPageSize(Constants.EXCEL_SIZE);
            thresholdService.queryThresholdHisList(thresholdHisForm);
            request.setAttribute("thresholdHisForm", thresholdHisForm);
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        return "threshold/exportThresholdHisPage";
    }
    /**
     * 导出阀值调整历史
     * @param thresholdHisForm
     * @param request
     * @param response
     */
    @RequestMapping(params = "method=exportThresholdHisList")
    public void exportThresholdHis(ThresholdHisForm thresholdHisForm, HttpServletRequest request, HttpServletResponse response) {
        try {
            PageContext context = PageContext.getContext();
            context.setPageSize(Constants.EXCEL_SIZE);
            List<ThresholdAdjustHis> thresholdAdjustHisList = thresholdService.queryThresholdHisList(thresholdHisForm);
            OutputStream out = response.getOutputStream();
            response.reset();
            response.setHeader("content-disposition",
                    "attachment;filename=" + new String((Constants.thresholdHisTitle).getBytes("gb2312"), "ISO8859-1") + ".xls");
            response.setContentType("APPLICATION/msexcel");
            PoiUtils.exportThresholdHisExcel(Constants.thresholdHisTitle, Constants.thresholdHisColumn, thresholdAdjustHisList, out, Constants.DEFAULT_DATETIME_FORMAT);
        } catch (Exception e1) {
            e1.printStackTrace();
        }
    }


}
