package com.uns.util;

public class TxtMap {
	private int startLine;

	private int transDateshell;

	private int transAmountshell;

	private int transIdshell;

	private int lineLength;

	private String splitFlag;

	public String getSplitFlag() {
		return splitFlag;
	}

	public void setSplitFlag(String splitFlag) {
		this.splitFlag = splitFlag;
	}

	public int getStartLine() {
		return startLine;
	}

	public void setStartLine(int startLine) {
		this.startLine = startLine;
	}

	public int getTransDateshell() {
		return transDateshell;
	}

	public void setTransDateshell(int transDateshell) {
		this.transDateshell = transDateshell;
	}

	public int getTransAmountshell() {
		return transAmountshell;
	}

	public void setTransAmountshell(int transAmountshell) {
		this.transAmountshell = transAmountshell;
	}

	public int getTransIdshell() {
		return transIdshell;
	}

	public void setTransIdshell(int transIdshell) {
		this.transIdshell = transIdshell;
	}

	public int getLineLength() {
		return lineLength;
	}

	public void setLineLength(int lineLength) {
		this.lineLength = lineLength;
	}

}
