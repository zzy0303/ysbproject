package com.uns.logic;

import java.io.InputStream;
import java.math.BigDecimal;
import java.util.Date;

import com.uns.common.exception.BusinessException;

/*
 * 对账文件
 * */
public interface CheckBillFile {
	/**
	 * @return 银行代码
	 */
	public String getBankCode();

	/**
	 * 判断文件是否准备好可以读取对账交易
	 * 
	 * @return true if 文件已准备好可以读取对账交易
	 */
	public boolean ready();

	/**
	 * 从指定对账文件输入流中加载对账交易数据
	 * 
	 * @param file
	 *            对账文件输入流
	 * @throws CheckBillException
	 *             如果加载对账文件时发现文件内容格式错误
	 */
	public void load(InputStream file) throws BusinessException;

	/**
	 * 获取对账日期，精确到天
	 * 
	 * @return 对账日期
	 */
	public Date getDate();

	/**
	 * 获取总对账金额
	 * 
	 * @return 总对账金额
	 */
	public BigDecimal getTotalAmount();

	/**
	 * @return 对账交易总数量
	 */
	public long count();

	/**
	 * 获取指定索引处的对账交易
	 * 
	 * @param index
	 * @return 指定索引处的对账交易
	 */
	public CheckBillTrans get(long index);

	/**
	 * 移除指定索引处的对账交易
	 * 
	 * @param index
	 * @return 被移除的对账交易
	 */
	public CheckBillTrans remove(long index);
}
