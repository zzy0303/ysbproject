package com.uns.web.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.model.CheckBillTransDetail;
import com.uns.service.CheckBillTransDetailService;
import com.uns.service.OutTransDetailService;
import com.uns.util.StringUtils;
import com.uns.web.form.TransDetailForm;

@Controller
@RequestMapping(value = "/outTransDetai.htm")
public class OutTransDetaiController {
	
	@Autowired
	private CheckBillTransDetailService checkBillTransDetailService;
	
	@Autowired
	private OutTransDetailService OutTransDetailService;
	/**
	 * 出金对账交易详情
	 * @param request
	 * @param transDetailForm
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=toTransDetailList")
	@FormToken(save = true)
	public String toTransDetailList(HttpServletRequest request, TransDetailForm transDetailForm)
			throws BusinessException{
		List<CheckBillTransDetail> checkBillTransDetailList = null;
		//条件为空默认前一天时间
		if(null == transDetailForm.getStartDate()){
			transDetailForm.setStartDate(StringUtils.getBeforDate());
		}
		if(null == transDetailForm.getEndDate()){
			transDetailForm.setEndDate(StringUtils.getBeforDate());
		}
		try {
			checkBillTransDetailList = OutTransDetailService.getTransDetailList(transDetailForm);
			String getNumAmount = OutTransDetailService.getNumAmount(transDetailForm);
			request.setAttribute("list", checkBillTransDetailList);
			request.setAttribute("transDetailForm", transDetailForm); 
			request.setAttribute("getNumAmount", getNumAmount);
		} catch (Exception e) {
			e.printStackTrace();
		}
		//获取出金对账通道
		String[] outChannel = Constants.OUT_CHECK_BILL_CHANNEL.split(",");
		request.setAttribute("outChannel", outChannel);
		return "outcheckbill/transDetailList";
	}
	
	/**
	 * 跳转到未处理差异
	 * 
	 * @return
	 */
	@RequestMapping(params = "method=toDealDifferRecord")
	@FormToken(save = true)
	public String toDealDifferRecord(HttpServletRequest request, TransDetailForm transDetailForm)
			throws BusinessException {
		try {
			String channel = request.getParameter("channel").toString();
			String dealFlag = request.getParameter("dealFlag").toString();
			String checkdate = request.getParameter("checkdate").toString();
			transDetailForm.setChannel(channel);
			transDetailForm.setStartDate(StringUtils.getdate(checkdate));
			transDetailForm.setEndDate(StringUtils.getdate(checkdate));
			transDetailForm.setDealFlag(dealFlag);
			//查询未处理交易
			List<CheckBillTransDetail> checkBillTransDetailList = checkBillTransDetailService
				   .getDifferTransList(transDetailForm);
			request.setAttribute("list", checkBillTransDetailList);
			request.setAttribute("transDetailForm", transDetailForm);
			String[] outChannel = Constants.OUT_CHECK_BILL_CHANNEL.split(",");
			request.setAttribute("outChannel", outChannel);
			return "outcheckbill/transDetailList";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
