package com.uns.web.controller;

import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uns.paysys.service.BailBalanceService;
import com.uns.util.AcmsMapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.model.CheckBillTransDetail;
import com.uns.model.TransDetail;
import com.uns.model.UserInfo;
import com.uns.paysys.entity.BailBalance;
import com.uns.service.CheckBillTransDetailService;
import com.uns.util.PoiUtils;
import com.uns.util.StringUtils;
import com.uns.web.form.MergentForm;
import com.uns.web.form.TransDetailForm;

@Controller
@RequestMapping(value = "/checkBillTransDetail.htm")
public class CheckBillTransDetailController extends BaseController {
	@Autowired
	private CheckBillTransDetailService checkBillTransDetailService;

	/*@Autowired
	private BailBalanceService bailBalanceServiceImpl;*/

	@Autowired
	private AcmsMapUtils acmsMapUtils;
	/**
	 * 对账列表
	 * 
	 * @param request
	 * @param transDetailForm
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=toTransDetailList")
	@FormToken(save = true)
	public String toTransDetailList(HttpServletRequest request, TransDetailForm transDetailForm)
			throws BusinessException {
		List<CheckBillTransDetail> checkBillTransDetailList = null;
	    if(null==transDetailForm.getStartDate()){transDetailForm.setStartDate(StringUtils.getBeforDate());}
	    if(null==transDetailForm.getEndDate()){transDetailForm.setEndDate(StringUtils.getBeforDate());}
		checkBillTransDetailList = checkBillTransDetailService.getTransDetailList(transDetailForm);
		String getNumAmount = checkBillTransDetailService.getNumAmount(transDetailForm);
		List<Map<String, Object>> actionNameList = checkBillTransDetailService.getActionName();// 获取交易类型
		request.setAttribute("actionNameList", actionNameList);
		request.setAttribute("list", checkBillTransDetailList);
		request.setAttribute("transDetailForm", transDetailForm);
		request.setAttribute("getNumAmount", getNumAmount);
		//动态获取参数
		Map<String,String> dynamicParam = acmsMapUtils.getAcmsMap();
		// 获取直连间连银行数据
		String[] directChannel = dynamicParam.get("CHECK_BILL_CHANNEL_DIRECT").split(",");
		String[] inDirectChannel = dynamicParam.get("CHECK_BILL_CHANNEL_INDIRECT").split(",");
		String[] pattern =  dynamicParam.get("CHECK_BILL_CHANNEL_PATTERN").split(",");
		String[] inParrert = dynamicParam.get("CHECK_BILL_CHANNEL_INPATTERN").split(",");
		request.setAttribute("directChannel", directChannel);
		request.setAttribute("inDirectChannel", inDirectChannel);
		request.setAttribute("pattern", pattern);
		request.setAttribute("inPattern", inParrert);

		return "checkbill/transDetailList";
	}

	@RequestMapping(params = "method=preTransDetailList")
	public String preTransDetailList(HttpServletRequest request,TransDetailForm transDetailForm){
		//动态获取参数
		Map<String,String> dynamicParam = acmsMapUtils.getAcmsMap();
		// 获取直连间连银行数据
		String[] directChannel = dynamicParam.get("CHECK_BILL_CHANNEL_DIRECT").split(",");
		String[] inDirectChannel = dynamicParam.get("CHECK_BILL_CHANNEL_INDIRECT").split(",");
		String[] pattern =  dynamicParam.get("CHECK_BILL_CHANNEL_PATTERN").split(",");
		String[] inParrert = dynamicParam.get("CHECK_BILL_CHANNEL_INPATTERN").split(",");
		request.setAttribute("directChannel", directChannel);
		request.setAttribute("inDirectChannel", inDirectChannel);
		request.setAttribute("pattern", pattern);
		request.setAttribute("inPattern", inParrert);
		request.setAttribute("transDetailForm", transDetailForm);
		return "checkbill/queryTransDetailList";
	}

	/**
	 * 对账列表
	 *
	 * @param request
	 * @param transDetailForm
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=queryTransDetailList")
	@FormToken(save = true)
	public String queryTransDetailList(HttpServletRequest request, TransDetailForm transDetailForm)
			throws BusinessException {
		List<CheckBillTransDetail> checkBillTransDetailList = null;
		if(null==transDetailForm.getStartDate()){transDetailForm.setStartDate(StringUtils.getBeforDate());}
		if(null==transDetailForm.getEndDate()){transDetailForm.setEndDate(StringUtils.getBeforDate());}
		checkBillTransDetailList = checkBillTransDetailService.getTransDetailList(transDetailForm);
		String getNumAmount = checkBillTransDetailService.getNumAmount(transDetailForm);
		List<Map<String, Object>> actionNameList = checkBillTransDetailService.getActionName();// 获取交易类型
		request.setAttribute("actionNameList", actionNameList);
		request.setAttribute("list", checkBillTransDetailList);
		request.setAttribute("transDetailForm", transDetailForm);
		request.setAttribute("getNumAmount", getNumAmount);
		//动态获取参数
		Map<String,String> dynamicParam = acmsMapUtils.getAcmsMap();
		// 获取直连间连银行数据
		String[] directChannel = dynamicParam.get("CHECK_BILL_CHANNEL_DIRECT").split(",");
		String[] inDirectChannel = dynamicParam.get("CHECK_BILL_CHANNEL_INDIRECT").split(",");
		String[] pattern =  dynamicParam.get("CHECK_BILL_CHANNEL_PATTERN").split(",");
		String[] inParrert = dynamicParam.get("CHECK_BILL_CHANNEL_INPATTERN").split(",");
		request.setAttribute("directChannel", directChannel);
		request.setAttribute("inDirectChannel", inDirectChannel);
		request.setAttribute("pattern", pattern);
		request.setAttribute("inPattern", inParrert);
		return "checkbill/queryTransDetailList";
	}

	/**
	 * 跳转到未处理差异
	 * 
	 * @return
	 */
	@RequestMapping(params = "method=toDealDifferRecord")
	@FormToken(save = true)
	public String toDealDifferRecord(HttpServletRequest request, TransDetailForm transDetailForm)
			throws BusinessException {
		try {
			String channel = request.getParameter("channel").toString();
			String dealFlag = request.getParameter("dealFlag").toString();
			String checkdate = request.getParameter("checkdate").toString();
			transDetailForm.setChannel(channel);
			transDetailForm.setStartDate(StringUtils.getdate(checkdate));
			transDetailForm.setEndDate(StringUtils.getdate(checkdate));
			transDetailForm.setDealFlag(dealFlag);

			List<CheckBillTransDetail> checkBillTransDetailList = checkBillTransDetailService
					.getDifferTransList(transDetailForm);
			request.setAttribute("list", checkBillTransDetailList);
			request.setAttribute("transDetailForm", transDetailForm);
			//动态获取参数
			Map<String,String> dynamicParam = acmsMapUtils.getAcmsMap();
			/*if(Constants.CHECK_BILL_CHANNEL_INDIRECT.contains(transDetailForm.getChannel())){
				transDetailForm.setConnType(Constants.CONNTYPE_1);
			}*/
			if (dynamicParam.get("CHECK_BILL_CHANNEL_INDIRECT").contains(transDetailForm.getChannel())){
				transDetailForm.setConnType(Constants.CONNTYPE_1);
			}
			// 获取直连间连银行数据
			String[] directChannel = dynamicParam.get("CHECK_BILL_CHANNEL_DIRECT").split(",");
			String[] inDirectChannel = dynamicParam.get("CHECK_BILL_CHANNEL_INDIRECT").split(",");
			String[] pattern =  dynamicParam.get("CHECK_BILL_CHANNEL_PATTERN").split(",");
			String[] inParrert = dynamicParam.get("CHECK_BILL_CHANNEL_INPATTERN").split(",");
			request.setAttribute("directChannel", directChannel);
			request.setAttribute("inDirectChannel", inDirectChannel);
			request.setAttribute("pattern", pattern);
			request.setAttribute("inPattern", inParrert);
			return "checkbill/transDetailList";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 跳转到余额阀值调整页面
	 * 
	 * @param request
	 * @param transDetailForm
	 * @return
	 * @throws BusinessException
	 * @throws UnsupportedEncodingException
	 */
	@RequestMapping(params = "method=adjustBalance")
	@FormToken(save = true)
	public String adjustBalance(HttpServletRequest request, TransDetailForm transDetailForm)
			throws BusinessException, UnsupportedEncodingException {
		String actionIdString = transDetailForm.getChecktypeId();
		String accountName = transDetailForm.getAccountName().toString();
		String[] arrayId = actionIdString.split(",");
		List<String> IdList = new ArrayList<String>();
		for (int i = 0; i < arrayId.length; i++) {
			IdList.add(arrayId[i].toString());
		}

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("list", IdList);
		map.put("accountName", accountName);
		map.put("startDate", transDetailForm.getStartDate());
		map.put("endDate", transDetailForm.getEndDate());
		map.put("channel", transDetailForm.getChannel());
		// 获取商户id
		List<String> merchantSeq = checkBillTransDetailService.getMerchantId(accountName);
		// 获取总金额
		double amount = checkBillTransDetailService.getamountById(map);
		BigDecimal mergentAmoount = new BigDecimal(String.valueOf(amount)).setScale(2);

		request.setAttribute("title", Constants.MERGENT_TITLE);
		request.setAttribute("amount", mergentAmoount);
		request.setAttribute("accountName", accountName);
		request.setAttribute("merchantSeq", merchantSeq.get(0));
		request.setAttribute("actionSeq", 207);
		return "checkbill/merchabt";
	}

	/**
	 * 调用接口阀值调整
	 * 
	 * @param request
	 * @param transDetailForm
	 * @return
	 * @throws BusinessException
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 */
	@RequestMapping(params = "method=getMergentAdjust")
	@FormToken(save = true)
	private String getMergentAdjust(HttpServletRequest request, MergentForm MergentForm)
			throws BusinessException, IllegalAccessException, InvocationTargetException {

		BailBalance bailBalance = new BailBalance();
		bailBalance.setMerchantSeq(MergentForm.getMerchantSeq());
		bailBalance.setAmount(MergentForm.getAmount());
		bailBalance.setUpdateUser(
				((UserInfo) (request.getSession().getAttribute(Constants.SESSION_KEY_USER))).getId().toString());
		bailBalance.setActionSeq(MergentForm.getActionSeq());
		/*BailBalance bailBalances = bailBalanceServiceImpl.modifyBailBalance(bailBalance);
		if (bailBalances.isSuccessFlag()) {
			request.setAttribute("msg", bailBalances.getMessage());
		} else {
            request.setAttribute("errMsg", bailBalances.getMessage());
        }*/
		request.setAttribute("title", Constants.MERGENT_TITLE);

		request.setAttribute("MergentForm", MergentForm);
		return "checkbill/merchabt";
	}

	/**
	 * 下载明细
	 * 
	 * @param request
	 * @param transDetailForm
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=toExport")
	@FormToken(save = true)
	public String toExport(HttpServletRequest request, HttpServletResponse response, TransDetailForm transDetailForm)
			throws BusinessException {
		// 获取下载类容
		List<TransDetail> transList = checkBillTransDetailService.getExportDetail(transDetailForm);
		try {
			OutputStream out = response.getOutputStream();
			response.reset();
			response.setHeader("content-disposition",
					"attachment;filename=" + new String((Constants.title).getBytes("gb2312"), "ISO8859-1") + ".xls");
			response.setContentType("APPLICATION/msexcel");
			PoiUtils.exportExcel(Constants.title, Constants.colnum, transList, out, Constants.DEFAULT_DATE_FORMAT);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		List<CheckBillTransDetail> checkBillTransDetailList = checkBillTransDetailService
				.getTransDetailList(transDetailForm);
		request.setAttribute("list", checkBillTransDetailList);
		return "checkbill/transDetailList";
	}

	/**
	 * 出金下载明细
	 *
	 * @param request
	 * @param transDetailForm
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=toOutExport")
	@FormToken(save = true)
	public String toOutExport(HttpServletRequest request, HttpServletResponse response, TransDetailForm transDetailForm)
			throws BusinessException {
		// 获取下载类容
		List<TransDetail> transList = checkBillTransDetailService.getOutExportDetail(transDetailForm);
		try {
			OutputStream out = response.getOutputStream();
			response.reset();
			response.setHeader("content-disposition",
					"attachment;filename=" + new String((Constants.title).getBytes("gb2312"), "ISO8859-1") + ".xls");
			response.setContentType("APPLICATION/msexcel");
			PoiUtils.exportExcel(Constants.title, Constants.colnum, transList, out, Constants.DEFAULT_DATE_FORMAT);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		List<CheckBillTransDetail> checkBillTransDetailList = checkBillTransDetailService
				.getTransDetailList(transDetailForm);
		request.setAttribute("list", checkBillTransDetailList);
		return "checkbill/transDetailList";
	}

	/**
	 * 网联下载明细
	 *
	 * @param request
	 * @param transDetailForm
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=toNetsUnionExport")
	@FormToken(save = true)
	public String toNetsUnionExport(HttpServletRequest request, HttpServletResponse response, TransDetailForm transDetailForm)
			throws BusinessException {
		// 获取下载类容
		List<TransDetail> transList = checkBillTransDetailService.getNetsUnionExportDetail(transDetailForm);
		try {
			OutputStream out = response.getOutputStream();
			response.reset();
			response.setHeader("content-disposition",
					"attachment;filename=" + new String((Constants.title).getBytes("gb2312"), "ISO8859-1") + ".xls");
			response.setContentType("APPLICATION/msexcel");
			PoiUtils.exportNetsUnionExcel(Constants.title, Constants.colnum, transList, out, Constants.DEFAULT_DATE_FORMAT);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		List<CheckBillTransDetail> checkBillTransDetailList = checkBillTransDetailService
				.getTransDetailList(transDetailForm);
		request.setAttribute("list", checkBillTransDetailList);
		return "checkbill/transDetailList";
	}
}
