package com.uns.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.page.PageContext;
import com.uns.dao.CheckBillMapper;
import com.uns.dao.CheckBillTransDetailMapper;
import com.uns.dao.ExportDetailMapper;
import com.uns.model.CheckBillTransDetail;
import com.uns.model.TransDetail;
import com.uns.util.StringUtils;
import com.uns.web.form.CheckBillForm;
import com.uns.web.form.TransDetailForm;

@Service
public class CheckBillTransDetailService {
	@Autowired
	private CheckBillTransDetailMapper checkBillTransDetailMapper;
	@Autowired
	private CheckBillMapper checkBillMapper;
	@Autowired
	private ExportDetailMapper exportDetailMapper;

	public List<CheckBillTransDetail> getTransDetailList(TransDetailForm transDetailForm) {
		List<CheckBillTransDetail> transList = checkBillTransDetailMapper.getDefaultDetailList(transDetailForm);
		return transList;
	}

	/**
	 * 查询未处理差异交易
	 * 
	 * @param transDetailForm
	 * @return
	 */
	public List<CheckBillTransDetail> getDifferTransList(TransDetailForm transDetailForm) throws Exception {
		PageContext page = new PageContext();
		page.setPageSize(20);
		List<CheckBillTransDetail> transList = checkBillTransDetailMapper.getDifferTransList(transDetailForm);
		return transList;

	}

	/**
	 * 查询未处理差异交易
	 *
	 * @param transDetailForm
	 * @return
	 */
	public List<CheckBillTransDetail> getNetsUnionDifferTransList(TransDetailForm transDetailForm) throws Exception {
		PageContext page = new PageContext();
		page.setPageSize(20);
		List<CheckBillTransDetail> transList = checkBillTransDetailMapper.getNetsUnionDifferTransList(transDetailForm);
		return transList;

	}

	/**
	 * 获取对账明细金额
	 * @param transDetailForm
	 * @return
	 */
	public String getNumAmount(TransDetailForm transDetailForm) {
		String amount = "0";
		amount = checkBillTransDetailMapper.getNumAmount(transDetailForm);
		return StringUtils.getDecimal(amount, 2);
	}

	public int deleteByPrimaryKey(int id) {
		BigDecimal bigDecimal = new BigDecimal(id);
		return checkBillTransDetailMapper.deleteByPrimaryKey(bigDecimal);
	}

	public int delettransdetaile(Long id) {
		return checkBillTransDetailMapper.delettransdetaile(id);
	}

	public int deletlocaltrans(CheckBillTransDetail checkBilldetail) {
		return checkBillTransDetailMapper.deletlocaltrans(checkBilldetail);
	}

	public int deletlocaltransNetsUnion(CheckBillForm checkBillForm) {
		return checkBillTransDetailMapper.deletlocaltransNetsUnion(checkBillForm);
	}

	public List<String> getTransDetailIdList(CheckBillForm checkBillForm) {
		return checkBillTransDetailMapper.getTransDetailIdList(checkBillForm);
	}

	public List<Map<String, Object>> getActionName() {
		List<Map<String, Object>> actionNameList = checkBillTransDetailMapper.getActionName();
		List<Map<String, Object>> actionList = new ArrayList<Map<String, Object>>();
		Map<String, Object> actionMap = new HashMap<String, Object>();
		if (null != actionNameList && actionNameList.size() > 0) {
			for (int i = 0; i < actionNameList.size(); i++) {
				actionMap.put(actionNameList.get(i).get("ACTION_NAME").toString(), actionNameList.get(i).get("ID"));
			}
			actionList.add(actionMap);
		}
		return actionList;
	}

	public List<String> getMerchantId(String actionName) {
		return checkBillTransDetailMapper.getMerchantId(actionName);
	}

	public double getamountById(Map<String, Object> map) {
		return checkBillTransDetailMapper.getamountById(map);
	}

	public List<TransDetail> getExportDetail(TransDetailForm transDetailForm) {
		return exportDetailMapper.getExportDetail(transDetailForm);
	}

	public List<TransDetail> getOutExportDetail(TransDetailForm transDetailForm) {
		return exportDetailMapper.getOutExportDetail(transDetailForm);
	}

	public List<TransDetail> getNetsUnionExportDetail(TransDetailForm transDetailForm) {
		return exportDetailMapper.getNetsUnionExportDetail(transDetailForm);
	}

	public void updateCheckTransDetail(String checkDate, String channel){
		//查询是否存在挂起交易对账
		Map<String, Object> map=new HashMap<String, Object>();
		map.put("checkDate", checkDate);
		map.put("channel", channel);
		Integer a=checkBillTransDetailMapper.gethungupTrans(map);
		if(a>0){
			//去掉处理完成的不平账记录
			map.put("num", a);
			checkBillMapper.updateRecoder(map);
			//更新对账详情
			checkBillTransDetailMapper.updateHungupTrans(map);
		}
	}

	public void updateNetsUnionCheckTransDetail(CheckBillForm checkBillForm){
		//查询是否存在挂起交易对账
		Integer sum = checkBillTransDetailMapper.getNetsUnionhungupTrans(checkBillForm);
		if(sum > 0){
			checkBillForm.setId(String.valueOf(sum));
			checkBillMapper.updateNetsUnionRecoder(checkBillForm);
			//更新对账详情
			checkBillTransDetailMapper.updateNetsUnionHungupTrans(checkBillForm);
		}
	}
}
