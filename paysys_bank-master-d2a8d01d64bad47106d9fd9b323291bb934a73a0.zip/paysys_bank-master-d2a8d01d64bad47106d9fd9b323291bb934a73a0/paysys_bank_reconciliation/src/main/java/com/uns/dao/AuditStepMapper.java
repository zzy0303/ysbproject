package com.uns.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.AuditStep;

@Repository
public interface AuditStepMapper {

	int deleteByPrimaryKey(BigDecimal id);

	int insert(AuditStep record);

	int insertSelective(AuditStep record);

	AuditStep selectByPrimaryKey(BigDecimal id);

	int updateByPrimaryKeySelective(AuditStep record);

	int updateByPrimaryKey(AuditStep record);

	List<AuditStep> getAuditStep(BigDecimal auditRuleId);
}