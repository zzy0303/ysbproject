package com.uns.web.form;

import java.util.Date;

import com.uns.common.Constants;
import com.uns.util.StringUtils;

public class TransDetailForm {

	private String channel;

	private String startDate;

	private String endDate;

	private String localTransId;

	private String bankTransId;

	private String checkTransStatus;

	private String connType;

	private String accountName;

	private String checktypeId;
	
	private String operationType;
	
	private String auditStatus;
		
	private String reason;
	
	private String channelType;
	
	private String actionType;
	
	private String merchantCode;

	private String billType;

	private String batchId;

	private String checkdate;

	public String getCheckdate() {
		return checkdate;
	}

	public void setCheckdate(String checkdate) {
		this.checkdate = checkdate;
	}

	public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	public String getBillType() {
		return billType;
	}

	public void setBillType(String billType) {
		this.billType = billType;
	}

	public String getMerchantCode() {
		return merchantCode;
	}

	public void setMerchantCode(String merchantCode) {
		this.merchantCode = merchantCode;
	}

	public String getChannelType() {
		return channelType;
	}

	public void setChannelType(String channelType) {
		this.channelType = channelType;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public String getReason() {
		return Constants.ADJUST_REASON_TRANS_HANGUP;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getAuditStatus() {
		return auditStatus;
	}

	public void setAuditStatus(String auditStatus) {
		this.auditStatus = auditStatus;
	}

	public String getOperationType() {
		return operationType;
	}

	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}

	public String getChecktypeId() {
		return checktypeId;
	}

	public void setChecktypeId(String checktypeId) {
		this.checktypeId = checktypeId;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	private String dealFlag;

	public String getDealFlag() {
		return dealFlag;
	}

	public void setDealFlag(String dealFlag) {
		this.dealFlag = dealFlag;
	}

	public String getConnType() {
		return connType;
	}

	public void setConnType(String connType) {
		this.connType = connType;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
         this.startDate = startDate;
	}

	public String getEndDate() {		
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getLocalTransId() {
		return localTransId;
	}

	public void setLocalTransId(String localTransId) {
		this.localTransId = localTransId;
	}

	public String getBankTransId() {
		return bankTransId;
	}

	public void setBankTransId(String bankTransId) {
		this.bankTransId = bankTransId;
	}

	public String getCheckTransStatus() {
		return checkTransStatus;
	}

	public void setCheckTransStatus(String checkTransStatus) {
		this.checkTransStatus = checkTransStatus;
	}

}
