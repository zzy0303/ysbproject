package com.uns.common;

import com.uns.inf.acms.client.DynamicConfigLoader;
import org.apache.poi.hssf.util.HSSFColor;

public class Constants {

	/**
	 * 统一错误消息KEY
	 */
	public static final String MESSAGE_KEY = "message";

	public static final String ERROR_MESSAGE = "errMsg";

	public static final String SESSION_VERIFY_CODE = "sessionVerifycode";
	// 操作员个人信息Session
	public static final String SESSION_KEY_USER = "sessionUser";
	// 提示信息
	public static final String SAVE_MESSAGE = "保存成功!";
	// 提示信息
	public static final String DEL_MESSAGE = "删除成功!";

	// 提示信息
	public static final String MERGENT_TITLE = "阀值调整";

	public static final String PASSWORD_FOR_SHOW = "unspay";

	public static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd";
	public static final String DEFAULT_DATE_FORMAT_NO_UNDERLINE = "yyyyMMdd";

	public static final String DEFAULT_DATETIME_FORMAT = "yyyy-MM-dd hh:mm:ss";
	public static final String DEFAULT_DATETIME_FORMAT_NO_UNDERLINE = "yyyyMMddhhmmss";

	public static final String DATE_TYPE = "yyyy/MM/dd HH:mm:ss";
	// 对账服务名称
	public static final String CHECK_BILL_SERVICE = "checkBillService";

	public static final String CHECK_BILL_B2C = "b2c";
	public static final String CHECK_BILL_B2C_D = "B2C";
	public static final String CHECK_BILL_KJ = "spdb_kj,hxb_kj,ceb_kj,ccb_kj,pingan_kj";
	public static final String CHECK_BILL_KJ_D = "KJ";
	public static final String CHECK_BILL_DK = "dk";

	public static final String FTP_URL = DynamicConfigLoader.getByEnv("FTP_URL");

	public static final String FTP_USERNAME = DynamicConfigLoader.getByEnv("FTP_USERNAME");

	public static final String FTP_PASSWORD = DynamicConfigLoader.getByEnv("FTP_PASSWORD");

	public static final String FTP_PATH = DynamicConfigLoader.getByEnv("FTP_PATH");
	public static final String CK_DATA_SOURCE = "CK_DATA_SOURCE";// 提现订单数据库

	public static final String UNSPAY_MAX_PAGE_SIZE = DynamicConfigLoader.getByEnv("UNSPAY_MAX_PAGE_SIZE");//最大分页记录数
	
	
	public static final String UNSPAY_TRANS_CREATE_URL = DynamicConfigLoader.getByEnv("UNSPAY_TRANS_CREATE_URL");// 交易系统创建交易接口
	public static final String UNSPAY_TRANS_UPDATE_URL = DynamicConfigLoader.getByEnv("UNSPAY_TRANS_UPDATE_URL");// 交易系统更新交易接口
	public static final String UNSPAY_TRANS_AFFIRM_URL = DynamicConfigLoader.getByEnv("UNSPAY_TRANS_AFFIRM_URL");// 交易系统确认交易接口
	public static final String UNSPAY_TRANS_CANCEL_URL = DynamicConfigLoader.getByEnv("UNSPAY_TRANS_CANCEL_URL");// 交易系统取消交易接口

	public static final String PARAM_CHECK_BILL_DK_CHANNEL = DynamicConfigLoader.getByEnv("CHECK_BILL_DK_CHANNEL");// 代扣处理通道
	public static final String PARAM_CHECK_BILL_CHANNEL = DynamicConfigLoader.getByEnv("CHECK_BILL_CHANNEL");// 定时任务处理通道
	public static final String CHECK_BILL_CHANNEL_INDIRECT = DynamicConfigLoader.getByEnv("CHECK_BILL_CHANNEL_INDIRECT");// 间连通道
	public static final String CHECK_BILL_CHANNEL_DIRECT = DynamicConfigLoader.getByEnv("CHECK_BILL_CHANNEL_DIRECT");// 直连通道
	public static final String CHECK_BILL_CHANNEL_PATTERN = DynamicConfigLoader.getByEnv("CHECK_BILL_CHANNEL_PATTERN");// 定时任务处理通道
	public static final String CHECK_BILL_CHANNEL_INPATTERN = DynamicConfigLoader.getByEnv("CHECK_BILL_CHANNEL_INPATTERN");// 定时任务处理通道

	//出金对账通道
	public static final String OUT_CHECK_BILL_CHANNEL = DynamicConfigLoader.getByEnv("OUT_CHECK_BILL_CHANNEL");
	//网联对账通道
	public static final String NETS_UNION_CHECK_BILL_CHANNEL = DynamicConfigLoader.getByEnv("NETS_UNION_CHECK_BILL_CHANNEL");

	// 交易类型
	public static final String UPLOAD_B2B_ACTIONTYPE = "24,17";
	public static final String UPLOAD_KJ_ACTIONTYPE = DynamicConfigLoader.getByEnv("UPLOAD_KJ_actionType");// 快捷交易类型
	public static final String UPLOAD_B2C_ACTIONTYPE = DynamicConfigLoader.getByEnv("UPLOAD_B2C_actionType");// b2c交易类型

	public static final String UPLOAD_SPDB_KJ_ACTIONTYPE = DynamicConfigLoader.getByEnv("UPLOAD_SPDB_KJ_actionType");// 华夏银行快捷交易类型
	public static final String UPLOAD_HXB_KJ_ACTIONTYPE = DynamicConfigLoader.getByEnv("UPLOAD_HXB_KJ_actionType");// 华夏银行快捷交易类型
	public static final String UPLOAD_CNCB_B2C_ACTIONTYPE = DynamicConfigLoader.getByEnv("UPLOAD_CNCB_B2C_actionType");//  中信银行快捷交易类型
	public static final String UPLOAD_BOC_CREDIT_ACTIONTYPE = DynamicConfigLoader.getByEnv("UPLOAD_CNCB_B2C_actionType");// 中信银行快捷交易类型
	public static final String UPLOAD_BOC_DEBIT_ACTIONTYPE = DynamicConfigLoader.getByEnv("UPLOAD_CNCB_B2C_actionType");//  中信银行快捷交易类型
	public static final String UPLOAD_CMBC_XM_SM_ACTIONTYPE = DynamicConfigLoader.getByEnv("UPLOAD_CMBC_XM_SM_ACTIONTYPE"); //厦门民生扫码交易类型
	public static final String UPLOAD_NY_ACTIONTYPE = DynamicConfigLoader.getByEnv("UPLOAD_NY_ACTIONTYPE"); //南粤银行交易类型
	public static final String UPLOAD_UPOP_SM_ACTIONTYPE = DynamicConfigLoader.getByEnv("UPLOAD_UPOP_SM_ACTIONTYPE"); //银联二维码交易类型
	public static final String UPLOAD_UPOP_B2B_ACTIONTYPE = DynamicConfigLoader.getByEnv("UPLOAD_UPOP_B2B_ACTIONTYPE"); //银联二维码交易类型
	
	public static final String UPLOAD_CMB_SM_ACTIONTYPE = DynamicConfigLoader.getByEnv("UPLOAD_CMB_SM_ACTIONTYPE");//招商扫码交易类型
	public static final String UPLOAD_CIB_SM_ACTIONTYPE = DynamicConfigLoader.getByEnv("UPLOAD_CIB_SM_ACTIONTYPE");//兴业扫码交易类型
	public static final String UPLOAD_CIB_SM_CHANNEL = DynamicConfigLoader.getByEnv("UPLOAD_CIB_SM_CHANNEL"); //兴业银行扫码交易通道
	public static final String UPLOAD_UNIONPAY_AT_SM_ACTIONTYPE = DynamicConfigLoader.getByEnv("UPLOAD_UNIONPAY_AT_SM_ACTIONTYPE");// 银联AT扫码交易类型

	public static final String UPLOAD_CMBC_B2C_ACTIONTYPE = DynamicConfigLoader.getByEnv("UPLOAD_CMBC_B2C_ACTIONTYPE");// 民生b2c交易类型
	public static final String UPLOAD_CMBC_B2C_CHANNEL = DynamicConfigLoader.getByEnv("UPLOAD_CMBC_B2C_CHANNEL");// 民生b2c通道名称
	public static final String UPLOAD_CNCB_B2C_CHANNEL = DynamicConfigLoader.getByEnv("UPLOAD_CNCB_B2C_CHANNEL");// 中信
	public static final String UPLOAD_NY_CHANNEL = DynamicConfigLoader.getByEnv("UPLOAD_NY_CHANNEL"); //南粤银行交易通道
	public static final String UPLOAD_UPOP_SM_CHANNEL = DynamicConfigLoader.getByEnv("UPLOAD_UPOP_SM_CHANNEL"); //银联二维码交易通道
	public static final String UPLOAD_CMBC_XM_CHANNEL = DynamicConfigLoader.getByEnv("UPLOAD_CMBC_XM_CHANNEL"); //厦门民生交易通道
	public static final String UPLOAD_CMBC_KJ_CHANNEL  = DynamicConfigLoader.getByEnv("UPLOAD_CMBC_KJ_CHANNEL");// 民生快捷交易通道
	public static final String UPLOAD_SPDB_KJ_CHANNEL = DynamicConfigLoader.getByEnv("UPLOAD_SPDB_KJ_CHANNEL");// 浦发快捷交易通道
	public static final String UPLOAD_HXB_KJ_CHANNEL  = DynamicConfigLoader.getByEnv("UPLOAD_HXB_KJ_CHANNEL");// 华夏快捷交易通道
	public static final String UPLOAD_CEB_KJ_D_CHANNEL  = DynamicConfigLoader.getByEnv("UPLOAD_CEB_KJ_CHANNEL");// 光大快捷交易通道
	public static final String UPLOAD_UNIONPAY_CHANNEL=DynamicConfigLoader.getByEnv("UPLOAD_UNIONPAY_CHANNEL");// 光大快捷交易通道
	public static final String UPLOAD_UNIONPAY_KJ = DynamicConfigLoader.getByEnv("UPLOAD_UNIONPAY_KJ");// 光大快捷交易通道
	public static final String UPLOAD_CHINAPAY_KJ = DynamicConfigLoader.getByEnv("UPLOAD_CHINAPAY_KJ");// 全渠道快捷交易通道
	public static final String UPLOAD_CCB_KJ = DynamicConfigLoader.getByEnv("UPLOAD_CCB_KJ");//
	public static final String UPLOAD_YILIAN_KJ_CHANNEL = DynamicConfigLoader.getByEnv("UPLOAD_YILIAN_KJ_CHANNEL");//yilian_kj
	public static final String UPLOAD_PINGAN_KJ_CHANNEL = DynamicConfigLoader.getByEnv("UPLOAD_PINGAN_KJ_CHANNEL");//
	
	//***********新增加**************
	public static final String UPLOAD_CMB_SM_CHANNEL = DynamicConfigLoader.getByEnv("UPLOAD_CMB_SM_CHANNEL"); //招商扫码交易通道
	public static final String UPLOAD_CMB_SM_CHANNEL2 = "cmb,cmb_sm_alipay,cmb_sm_wechatpay";//招商扫码
	public static final String UPLOAD_CMBC_XM_KJ_CHANNEL = DynamicConfigLoader.getByEnv("UPLOAD_CMBC_XM_KJ_CHANNEL");//厦门民生快捷通道类型
	public static final String UPLOAD_BOSH_KJ_CHANNEL = DynamicConfigLoader.getByEnv("UPLOAD_BOSH_KJ_CHANNEL");// 上海银行快捷通道类型
	public static final String channel_CCB_Kj_CHANNEL ="'ccb_c_q','ccb_d_q'";
	public static final String DKCHANNEL="unionpay_td,unionpay_td2,unionpay_wl,egb,egb_prob,egb_proc,ws,ws_yy,ws_yf,ws_uns,cmbc_cd_cfca_3,cmbc_cd_4,cmbc_cd_cfca_4,cmbc_cd_3,bestpay_cfca_4,bestpay,wl,ys,cmbc_xm_dk,cmbc_xm_cfca_3,spdb_dk,bosh_dk,bosh,ny,ny_3,ny_4,pingan_dk,unionpay_xm_dk,bfbpay_dk,epay_dk,yifubao,chinapay,yilian_dk";
	public static final String dk="dk";
	public static final String UNIONPAYCHANNEL="unionpay_zy,unionpay_nfq,unionpay_ysb,unionpay_zdpk,unionpay_zd,unionpay_yf,unionpay_kazd,unionpay_yy,unionpay_yc,rz_order,order,unionpay_b2b,upmp";
	public static final String CHINACHANNEL="chinapay_d,chinapay_c,chinapay_ec,chinapay_ec_d";//银联全渠道
	public static final String channelBoshKj ="bosh_kj";

	public static final String channelEgb_3 = "egb_cfca_3,egb_cfca_4";// 恒丰egb银行代扣
	public static final String channelEgbProb_3 = "egb_3_b,egb_4_b";// 恒丰prob银行代扣
	public static final String KJCHANNEL="bosh_kj,ceb_kj,hxb_kj,spdb_kj,cmbc_xm_kj,ceb_cmbc_xm_d,boc_cmbc_xm_d,abc_cmbc_xm_d,hxb_cmbc_xm,icbc_cmbc_xm_d,ccb_cmbc_xm_d,ccb_kj";
	public static final String UPLOAD_SM_CHANNEL = "upop_sm,cmbc_xm_sm,cmb_sm";// 银联B2C对账文件
	public static final String UNIONPAYKJCHANNEL="order,upmp";
	public static final String channelcmbcB2cD = "cmbc";// 厦门民生快捷
	public static final String CHANNELCIBSM = "cib"; //兴业扫码
	public static final String CHINAPAYCHANNEL="chinapay";//全渠道


	
	// 调账原因
	public static final String ADJUST_REASON_TRANS_ADJUST = "银行有我方不成功(交易调账)";
	public static final String ADJUST_REASON_BANK_TRANS_COUNTER = "银行有我方无(银行冲正)";
	public static final String ADJUST_REASON_TRANS_HANGUP = "我方有银行无(交易挂起)";
	public static final String ADJUST_REASON_LOCAL_TRANS_COUNTER = "我方有银行无(交易冲正)";
	public static final String ADJUST_REASON_AMOUNT_ERROR = "金额不对";
	public static final String ADJUST_REASON_OTHER = "其他";
	
	public static final String FLAG_0= "0";
	public static final String FLAG_1= "1";
	public static final String FLAG_2= "2";
	public static final String FLAG_3= "3";
	public static final String FLAG_4_= "4";
	public static final int FLAG_default= 0;
	public static final int FLAG_1_= 0;
	public static final int FLAG_4= 4;
	public static final int FLAG_6= 6;
	public static final int FLAG_8= 8;
	public static final int FLAG_12= 12;

	public static final String FLAG_0110= "0110";
	public static final String FLAG_0112= "0112";
	public static final String FLAG_0113= "0113";
	public static final String FLAG_0114= "0114";
	public static final String FLAG_0120= "0120";

	public static final String FLAG_00= "00";
	public static final String FLAG_01= "01";
	public static final String FLAG_02= "02";
	public static final String FLAG_03= "03";
	public static final String FLAG_04= "04";





	public static final String CONNECTTYPE = "0";// 未处理
	public static final int TRANSiDLENGTH = 15;// 交易编号长度
	public static final int UNIONPAYXMOUTLENGTH = 10; //厦门银联出金数据长度
	public static final int FLAG_INT_0 = 0;

	// 交易对账状态
	public static final String CHECK_STATUS_DEFAULT = "0";// 未处理
	public static final String CHECK_STATUS_NORMAL = "1";// 正常对账
	public static final String CHECK_STATUS_LOCAL_LACK = "2";// 银行有我方无
	public static final String CHECK_STATUS_BANK_LACK = "3";// 银行无我方有
	public static final String CHECK_STATUS_AMOUNT_ERROR = "4";// 金额不对

	// 审核标识
	public static final String AUDIT_FLAG_LOCAL_LACK = "1";// 银行有我方无
	public static final String AUDIT_FLAG_BANK_LACK = "2";// 银行无我方有
	public static final String AUDIT_FLAG_AMOUNT_ERROR = "3";// 金额不对
	// 0,未处理;1,已上传;2,对账中;3,对账完成;4无差额;5,正常差额;6,异常差额
	// 对账列表对账状态
	public static final String CHECK_BILL_0 = "0";// 未处理
	public static final String CHECK_BILL_1 = "1";// 已上传
	public static final String CHECK_BILL_2 = "2";// 对账中
	public static final String CHECK_BILL_3 = "3";// 对账完成
	public static final String CHECK_BILL_4 = "4";// 无差额
	public static final String CHECK_BILL_5 = "5";// 正常差额
	public static final String CHECK_BILL_6 = "6"; // 异常差额

	public static final String TRANS_STATUS_SUCCESS = "3";// 交易状态成功

	public static final String TRANS_STATUS_SUCCESS_EPCC = "00";// 网联交易成功
	public static final String TRANS_STATUS_PRE_SUCCESS_EPCC = "03";// 网联交易推定成功

	public static final String DEFAULT = "default";
	public static final String UPLOAD_EGB = "egb";
	public static final String UPLOAD_CHANNEL = "egb";// 恒丰银行通道
	public static final String UPLOAD_EGB_CHANNEL = "egb_cfca_3,egb_cfca_4";
	public static final String UPLOAD_CHANNEL_B = "egb_prob";// 恒丰银行通道egb_prob
	public static final String UPLOAD_EGB_CHANNEL_B = "egb_4_b,egb_3_b";
	public static final String UPLOAD_CHANNEL_C = "egb_proc";// 恒丰银行通道egb_proC
	public static final String CONNTYPE_1 = "1";// 间连
	public static final String EGB_TYPE = "0";// 交易成功

	public static final String UPLOAD_UNIONPAY_TD = "unionpay_td";//
	public static final String UPLOAD_UNIONPAY_TD2 = "unionpay_td2";//
	public static final String UPLOAD_UNIONPAY_WL = "'unionpay_wl'";//
	public static final String UPLOAD_UNIONPAY_AT_SM = "unionpay_at_sm";//银联AT扫码

	public static final String UPLOAD_ICBC= "icbc"; //
	public static final String UPLOAD_ICBC_CHANNEL= "'icbc'"; //
	public static final String UPLOAD_ICBC_B2B= "icbc_b2b"; //
	public static final String UPLOAD_CCB= "ccb"; //
	public static final String UPLOAD_CCB_B2C = "ccb_b2c";
	public static final String UPLOAD_CCB_B2B = "ccb_b2b";
	public static final String UPLOAD_CCB_CHANNEL= "ccb_kj"; //
	public static final String UPLOAD_NY = "ny"; //南粤银行
	public static final String UPLOAD_UPOP_SM = "upop_sm"; //银联二维码
	public static final String UPLOAD_UPOP = "upop"; //银联
	public static final String UPLOAD_CMBC_XM_SM = "cmbc_xm_sm"; //厦门民生扫码
	public static final String UPLOAD_PINGAN_KJ = "pingan_kj"; //
	public static final String UPLOAD_CMBC_DEFAULT = "cmbc_default";
	public static final String UPLOAD_CMBC = "cmbc";// 厦门民生对账解析Excel文件
	public static final String UPLOAD_CMBC_XM_B2C = "cmbc_xm_b2c";
	public static final String UPLOAD_CMBC_B2C = "cmbc_b2c";// 厦门民生对账解析Excel文件
	public static final String UPLOAD_CMBC_XM_DK = "cmbc_xm_dk";// 厦门民生对账解析txt文件
	public static final String UPLOAD_CMBC_XM = "cmbc_xm";// 厦门民生对账解析txt文件
	public static final String UPLOAD_CMBC_XM_KJ = "cmbc_xm_kj";
	public static final String UPLOAD_CMBC_KJ = "cmbc_xm_kj";// 厦门民生快捷对账解析txt文件
	public static final String UPLOAD_CMBC_CD = "cmbc_cd";// 成都民生快捷对账解析txt文件
	public static final String UPLOAD_CMBC_CD_CFCA_3 = "cmbc_cd_cfca_3";
	public static final String UPLOAD_CMBC_B2C_D = "cmbc_b2c";// 成都民生快捷对账解析txt文件
	public static final String UPLOAD_DEFAULT = "default";
	public static final String UPLOAD_ICBC_B2C = "icbc_b2c";
	public static final String UPLOAD_SPDB_B2C = "spdb_b2c";
	public static final String UPLOAD_SPDB_DK = "spdb_dk";
	public static final String UPLOAD_YILIAN_KJ = "yilian_kj";
	public static final String UPLOAD_BESTPAY= "bestpay";
	public static final String UPLOAD_ABC_B2C= "abc_b2c";

	public static final String UPLOAD_YS = "ys";// 银盛对账文件
	public static final String UPLOAD_PINGAN = "pingan";
	public static final String UPLOAD_BOSH_DK = "bosh_dk";// 上海银行直连文件
	public static final String UPLOAD_BOSH_B2C = "bosh_b2c";// 上海银行b2c
	public static final String UPLOAD_BOSH = "bosh";// 上海银行直连文件
	public static final String UPLOAD_TJ_UNIONPAY = "unionpay_tj_t1";// 天津银联
	public static final String UPLOAD_TJ_UNIONPAY_T0 = "unionpay_tj_t0";// 天津银联t0
	public static final String UPLOAD_YLZ = "ylz";//易联众 
	public static final String UPLOAD_CNCB = "cncb";//
	public static final String UPLOAD_UMPAY = "umpay";//
	public static final String UPLOAD_UMPAY_CHANNEL = "umpay_d,umpay_c";//

	public static final String UPLOAD_UNIONPAY_DEFAULT = "unionpay_default";
	public static final String UPLOAD_UNIONPAY = "unionpay";// 银联对账文件
	public static final String UPLOAD_CHINAPAY = "chinapay";// 全渠道对账文件
	public static final String UPLOAD_UNIONPAY_WG = "unionpay_wg"; //银联网关
	public static final String UPLOAD_UNIONPAY_B2B = "unionpay_b2b";// 银联对账文件
	public static final String UPLOAD_UNIONPAY_B2C = "unionpay_xm,unionpay_cq";// 银联B2C对账文件
	public static final String UPLOAD_UNIONPAY_XM = "unionpay_xm";//
	public static final String UPLOAD_UNIONPAY_XM_DK = "unionpay_xm_dk";//
	public static final String UPLOAD_UNIONPAY_XM_DK_CHANNEL = "xmunion_l_d,xmunion_r_d";//
	public static final String UPLOAD_UNIONPAY_XM_CHANNEL = "unionpay_xm_d,unionpay_xm_c";
	public static final String UPLOAD_UNIONPAY_CQ = "unionpay_cq";// 银联B2C对账文件
	public static final String UPLOAD_UNIONPAY_CQ_CHANNEL = "unionpay_cq_d,unionpay_cq_c";// 银联B2C对账文件
	public static final String UPLOAD_UNIONPAY_TD2_CODE = "876310042140001,876290047220102";// 银联对账文件
	public static final String UPLOAD_UNIONPAY_WG_CODE = "876290047220102";
	public static final String UPLOAD_HFQD_CHANNEL = "hfqd";//出金,青岛银联

	public static final String UPLOAD_WS = "ws";// 深圳结算中心
	public static final String UPLOAD_WS_UNS = "ws_uns";// 深圳结算中心

	public static final String UPLOAD_CEB_KJ = "ceb";// 光大银行快捷
	public static final String UPLOAD_CEB_KJ_D = "ceb_kj";// 光大银行快捷
	public static final String UPLOAD_SPDB = "spdb";// 浦发银行
	public static final String UPLOAD_SPDB_KJ = "spdb_kj";// 浦发银行
	public static final String UPLOAD_HXB = "hxb";// 华夏银行
	public static final String UPLOAD_HXB_KJ = "hxb_kj";// 华夏银行
	public static final String UPLOAD_HXB_B2C = "hxb_b2c";// 华夏银行
	public static final String UPLOAD_BFBPAY = "bfbpay" ;//绑付宝对账通道
	public static final String UPLOAD_BFBPAY_DK = "bfbpay_dk";//绑付宝对账通道
	public static final String UPLOAD_CMB = "cmb";//招商银行扫码
	public static final String UPLOAD_CMB_SM = "cmb_sm";//招商银行扫码
	public static final String UPLOAD_EPAY_DK = "epay_dk"; //epay_dk对账通道
	public static final String UPLOAD_BOC_KJ = "boc_kj"; //boc_kj中国银行快捷通道
	public static final String UPLOAD_YIFUBAO = "yifubao"; //yifubao_dk
	public static final String UPLOAD_YINLIAN_KJ = "yinlian_kj"; //yinlian_kj
	public static final String UPLOAD_YINLIAN = "yinlian"; //yinlian
	public static final String UPLOAD_PSBC_D= "psbc_d";// 邮储快捷
	public static final String UPLOAD_PSBC_D_KJ= "psbc_d_kj";// 邮储快捷


	public static final String UPLOAD_CIB_SM = "cib_sm"; //cib_sm
	public static final String UPLOAD_PINGAN_XM = "pingan_xm" ;//平安银行扫码对账通道
	public static final String UPLOAD_PINGAN_XM_DK = "pingan_xm_dk";//平安银行扫码对账通道
	public static final String UPLOAD_SPDB_CROSSBANK_DK = "spdb_crossBank_dk"; //spdb_crossBank_dk对账通道
	public static final String UPLOAD_HFQD = "hfqd";//出金青岛银联
	public static final String UPLOAD_UNIONPAY_XM_DP = "unionpay_xm_dp";
	public static final String UPLOAD_CEB_B2B = "ceb_b2b"; //中行b2b对账通道

	public static final String UPLOAD_EPCC = "epcc"; //网联对账通道

	public static final String UPLOAD_CNCB_error = "'cncb_upop','cncb_cmbc_xm_d','cncb_cmbc_xm'";// 华夏银行
	public static final String UPLOAD_CNCB_B2C = "cncb_b2c";// 华夏银行
	public static final String UPLOAD_BOC_B2C= "boc_b2c";// 中国银行信用卡借记卡
	public static final String UPLOAD_BOC= "boc";// 中国银行信用卡借记卡
	public static final String UPLOAD_PINGAN_D= "pingan_d";// pingan_kj bank_code
	public static final String UPLOAD_BOC_B2C_CHANNEL = "'boc','boc_d'";// 中国银行信用卡借记卡
	public static final String UPLOAD_SPDB_CHANNEL= "spdb,spdb_cfca_3,spdb_cfca_4";//
	public static final String UPLOAD_SPECIAL_CHANNEL = "bestpay,spdb_dk,pingan_dk,yilian_kj";//
	public static final String UPLOAD_PINGAN_DK = "pingan_dk";//
	public static final String UPLOAD_PINGAN_CHANEL= "pingan,pingan_3,pingan_4";//
	public static final String UPLOAD_YILIAN_DK_CHANEL= "_dc_i_yilian_d";//亿联 对账通道
	public static final String UPLOAD_YILIAN_DK= "yilian_dk";//亿联代扣

	public static final String UPLOAD_UNIONPAY_BH = "unionpay_bht0,unionpay_bh";

	// 字符串中所处位置
	// 0：文件开始行所处字段位置1
	// 1;文件成功标识所处字段状态2
	// 2;文件成功标识所处字段位置3
	// 3;文件中金额所处文件位置4
	// 4;文件中时间所处字段5
	// 5;文件中交易id所处字段位置6
	// 6：字符最大长度7
	// 7：行最短长度8
	public static final String UPLOAD_NY_SHELL = "5,SUCCESS,7,8,4,2"; //南粤银行上传文件格式
	public static final String UPLOAD_CMBC_SM_SHELL = "1,000000,7,4,5,2|3"; //华夏民生上传文件格式
	public static final String UPLOAD_BOSH_SHELL = "2,成功,5,2,3,1";// 上海银行直连文件格式
	public static final String UPLOAD_WS_SHELL = "5,处理成功,28,15,0,3,16,33";// 文件格式
	public static final String UPLOAD_CMBC_CD_SHELL = "1,000000,11,4,5,1";// 民生成都快捷文件格式s
	public static final String UPLOAD_UMPAY_B2C_SHELL = "5,1,11,6,4,3";// UMPAYb2c文件格式s
	public static final String UPLOAD_CCB_KJ_SHELL = "1,null,0,7,2,4,13,2"; //CCB_KJ
	public static final String UPLOAD_UNIONPAY_XM_DK_SHELL = "2,1,17,10,4,12"; //CCB_KJ
	public static final String UPLOAD_BFBPAY_DK_SHELL="1,S,8,5,2,3";//绑付宝通道文件格式

	public static final String UPLOAD_CMB_SM_SHELL="1,null,1,8,6,2|1";//招商银行扫码文件格式

	public static final String UPLOAD_EPAY_DK_SHELL = "4,null,0,7,4,5"; //epay_dk文件格式

	public static final String UPLOAD_BOC_KJ_SHELL = "4,1,6,5,7,1"; //boc_kj文件格式

	public static final String UPLOAD_YLWK_KJ_SHELL = "1,2,4,7,21,\\s+"; //ylwk_kj文件格式（银联无卡快捷）
	public static final String UPLOAD_PSBC_D_KJ_SHELL = "5,Y,9,5,1,0"; //ylwk_kj文件格式（银联无卡快捷）

	public static final String UPLOAD_CIB_SM_SHELL = "1,支付成功,11,14,0,8";//cib_sm兴业扫码格式
	public static final String UPLOAD_PINGAN_XM_DK_SHELL="5,20,10,8,9,3";//平安银行扫码文件格式
    public static final String UPLOAD_SPDB_CROSSBANK_SHELL = "1,null,0,14,5,6";//spdb_crossBank_dk文件格式

	public static final String UPLOAD_BOSH_OUT_SHELL = "7,借,3,4,1,11"; //上海银行出金文件格式
	public static final String UPLOAD_BOSH_OUT_IB_SHELL = "8,交易成功,11,5,1,13"; //上海银行超级网银出金文件格式
	public static final String UPLOAD_HFQD_SHELL = "2,0000,10,8,0,2";//出金青岛银联对账文件格式
	public static final String UPLOAD_PINGAN_KJ_SHELL = "5,Y,9,5,1,0"; //pingan_kj文件格式
	public static final String UPLOAD_TJ_UNIONPAY_SHELL = "1,成功-成功,9,4,10,7";//出金天津银联t1对账文件格式
	public static final String UPLOAD_TJ_UNIONPAY_T0_SHELL = "1,成功-成功,9,4,7,7";//出金天津银联t0对账文件格式
	public static final String UPLOAD_UNIONPAY_XM_DP_SHELL = "1,交易成功,8,7,9,1"; //出金厦门银联代付对账文件格式
	public static final String UPLOAD_UNIONPAY_BH_SHELL = "1,00,8,4,10,7"; //出金 渤海银联 对账文件格式
	public static final String UPLOAD_UNIONPAY_BHT0_SHELL = "1,00,8,4,10,7"; //出金 渤海银联t0 对账文件格式
	// 数据起始行
	// 金额
	// 时间
	// 交易编号
	// 数据最短长度
	// 分割标识
	public static final String UPLOAD_UPOP_SM_TXT = "0,5,34,34,35,\\s+"; //银联二维码上传文件格式
	public static final String UPLOAD_CMBC_TXT = "0,5,1,1,11,\\|";// 厦门民生银生宝A
	public static final String UPLOAD_CMBC_KJ_TXT = "0,10,2,1,12,\\|";// 厦门民生快捷
	public static final String UPLOAD_CEB_TXT = "0,9,3,3,11,\\|";// 光大银行直连文件格式
	public static final String UPLOAD_SPDB_TXT = "0,7,1,3,11,\\|";// 浦发银行直连文件格式
	public static final String UPLOAD_HXB_TXT = "0,3,0,0,6,\\|";// 华夏银行直连文件格式
	public static final String UPLOAD_UNIONPAY_TXT = "0,5,35,35,36,\\s+";// 银联对账文件格式
	public static final String UPLOAD_UNIONPAY_TXT_NEW = "0,5,3,35,36,\\s+,12";// 银联对账文件格式
	public static final String UPLOAD_CNCB_B2C_TXT = "5,5,1,0,6,\\|";// 中信对账文件格式
	public static final String UPLOAD_BOC_B2C_TXT = "9,6,4,1,11,\\s+";// 中信对账文件格式
	public static final String UPLOAD_ICBC_B2B_TXT = "3,3,5,1,6,\\s+";// 工商银行对账格式
	public static final String UPLOAD_CMBC_B2C_1 = "1,1,2,0"; //CMBC_B2C
	public static final String UPLOAD_CMBC_B2C_2 = "1,2,4,0"; //CMBC_B2C
	public static final String UPLOAD_YIFUBAO_DK_TXT = "4,11,5,4,15,\\s+";  //yifubao_dk 易付宝代扣通道
	public static final String UPLOAD_NETS_UNION_TXT = "1,2,1,1,7,\\|";// 银联对账文件格式
	public static final String UPLOAD_UNIONPAY_XM_OUT_TXT = "0,5,9,9,10,\\s+"; //厦门银联出金对账文件格式
	public static final String UPLOAD_CEB_B2B_TXT = "0,7,1,3,10,\\|"; //ceb_b2b 中行B2B通道
	public static final String UPLOAD_CCB_B2B_TXT = "2,9,4,4,12,\\s+";//ccb_b2b通道
	public static final String UPLOAD_YLZ_TXT = "1,3,2,1,9,\\|"; //易联众上传文件格式
	public static final String UPLOAD_CHAINPAY_TXT = "0,5,3,35,36,\\s+,12";// 全渠道的对账文件格式
	public static final String UPLOAD_YILIAN_DK_TXT = "0,4,9,1,13,\\|";  //yilian_dk 亿联代扣通道
	
	
	

	public static final String[] colnum = { "对账日期", "交易时间", "对账银行通道", "对账银行", "交易类型", "银生宝交易编号", "交易商户名", "银生宝交易金额",
			"银行交易编号", "银行交易金额", "对账文件名称", "对账状态" };
	public static final String[] hang_colnum = { "对账日期", "交易时间", "对账银行通道", "对账银行", "交易类型", "银生宝交易编号", "交易商户名", "银生宝交易金额",
			"银行交易编号", "银行交易金额", "对账文件名称", "对账状态", "审核状态" };
	public static final String[] netsUnion_colnum = { "银生宝交易编号", "交易时间", "银行交易批次号", "银行交易编号", "银行交易金额", "银行交易类别", "银行交易状态", "银行交易时间"};
	public static final String title = "对账明细";
	public static final String hang_title = "挂起申请明细";
	public static final String netsUnion_title = "网联交易明细";
	public static final String thresholdTitle = "阀值调整明细";
	public static final String[] thresholdColnum = { "对账日期", "交易时间", "对账银行通道", "对账银行", "交易类型", "银生宝交易编号", "交易商户名", "银生宝交易金额",
			"银行交易编号", "银行交易金额", "对账文件名称", "对账状态","调整状态","操作人","操作时间" };
	public static final String whiteAccountTitle = "商户白名单";
	public static final String[] whiteAccountColnum = {"编号", "商户编号", "商户名称", "交易类型", "备注", "操作员", "操作时间", "状态"};

	public static final String thresholdListTitle = "阀值调整列表";
	public static final String[] thresholdListColunm = {"商户编号", "商户名称", "交易类型", "对账总数目", "对账总金额", "手续费", "可调阀值总金额", "对账时间"};

	public static final String thresholdInfoTitle = "阀值调整明细";
	public static final String[] thresholdInfoColumn = {"对账银行通道", "对账银行", "交易类型", "交易编号", "商户名称", "交易金额", "手续费", "银行交易编号", "银行交易金额", "对账文件名称", "对账状态", "调整状态", "对账人员", "对账时间"};

	public static final String thresholdHisTitle = "阀值调整历史";
	public static final String[] thresholdHisColumn = {"商户编号", "商户名称", "对账总数目", "对账总金额", "手续费", "可调阀值总金额", "已调阀值总金额", "操作员", "调整时间"};

	// 民生成都的对账金额 小数位数 处理
	public static final int DECIMAL_NUM = 2;

	public static final String XLS = "xls";
	public static final String TXT = "txt";
	public static final String CSV = "csv";

	public static final String ACCOUNTLIST_SESSIONKEY = "accountList";
	public static final String ACTIONTYPELIST_SESSIONKEY = "actionTypeList";

	/**
	 * 商户白名单状态
	 */
	public static final String WHITE_ACCOUNT_STATUS_0 = "0"; //停用
	public static final String WHITE_ACCOUNT_STATUS_1 = "1"; //启用
	public static final String WHITE_ACCOUNT_STATUS_2 = "2"; //删除

	public static final String ACTION_TYPE_207 = "207";

	//易付宝有效列标识
	public static final String ACTION_YIFUBAO_DK_FLAG = "#";

	//华夏成功标识
	public static final String HXB_FLAG0 = "0"; //0成功标识


	public static final String CHANNEL_BOSH_FLAG = "借"; // 中国银行文件标识
	public static final String CHANNEL_BOSH_IB_FLAG = "交易成功"; // 上海银行超级网银文件标识
	//下载条数
	public static final int EXCEL_SIZE = 10000;

	public static final String STATUS_0000 = "0000";
	public static final String STATUS_9999 = "9999";
	public static final String AUTO_USER_NAME = "自动对账";
	public static final String CHECK_FLAG = "checkFlag";
	
	public static final String UPLOAD_EXECUTE_TIME=DynamicConfigLoader.getByEnv("UPLOAD_EXECUTE_TIME");// 定时任务产生对账记录日期

	public static final String YLWK_Kj_AMOUNT_HEAD = "156";
	public static final String YLWK_Kj_AMOUNT_BAD_ENDS = "000000000000";

	public static final String ABC_B2C_FAILED = "交易失败";

	public static final int NETS_UNION_ID_LEN = 31;

	public static final String NETS_UNION_SUCCESS_CODE = "00,03";

	public static final Integer NETSUNION_PAGENUM = Integer.valueOf(DynamicConfigLoader.getByEnv("NETSUNION_PAGENUM"));// 网联同步交易分页数
	public enum DATASOURCE_INSTANCE{
		DK_VNV,
		WL_DF,
		GATEWAY,
		CK_DATA_SOURCE
	}

}
