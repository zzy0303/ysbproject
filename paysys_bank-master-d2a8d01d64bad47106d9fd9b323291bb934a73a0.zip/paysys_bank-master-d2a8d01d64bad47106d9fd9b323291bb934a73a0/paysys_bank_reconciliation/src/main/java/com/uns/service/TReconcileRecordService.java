package com.uns.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.dao.TReconcileRecordMapper;

@Service
public class TReconcileRecordService {
	@Autowired
	private TReconcileRecordMapper tReconcileRecordMapper;

	// 定时生成本地对账数据
	public void insertSelective() {

	}
}
