package com.uns.service;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.common.JSONUtil;
import com.uns.common.exception.BusinessException;
import com.uns.dao.TransactionMapper;
import com.uns.model.Transaction;
import com.uns.unspay.tx.ServiceParameter;
import com.uns.unspay.tx.request.ServiceRequestResult;
import com.uns.util.HttpClientUtils;

@Service
public class TransSystemService {
	@Autowired
	private TransactionMapper transactionMapper;
	private static Log log = LogFactory.getLog(HttpClientUtils.class);

	// 请求交易系统
	public Transaction sendTrans(ServiceParameter request, String url) throws BusinessException, IOException {
		ServiceRequestResult result;
		try {
			result = HttpClientUtils.postRequest(url, request, ServiceRequestResult.class);
		} catch (Exception e) {
			log.error("请求交易系统失败:" + e.getMessage() + ",URL:+" + url + ",请求参数:" + JSONUtil.toJSONString(request));
			throw new BusinessException("error.trans.system.request.fail.io");
		}

		if (result == null || result.getCode() == null || !"0000".equals(result.getCode())) {
			log.error("请求交易系统失败:" + result + ",URL:+" + url + ",请求参数:" + JSONUtil.toJSONString(request));
			throw new BusinessException("error.trans.system.request.fail.result");
		}

		Long transSeq = Long.parseLong("" + result.getData());
		log.info("请求交易系统成功，transSeq:" + transSeq);

		Transaction savedTrans = transactionMapper.selectByPrimaryKey(BigDecimal.valueOf(transSeq));
		if (savedTrans == null) {
			log.error("交易系统操作失败，未取到保存交易。transSeq:" + transSeq);
			throw new BusinessException("error.trans.load.fail");
		}

		return savedTrans;
	}

	private Transaction sendTrans(Map<String, Object> data, String url) throws Exception {
		ServiceParameter request = new ServiceParameter();
		request.setData(data);
		String date = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		request.setRequestTime(date);
		request.setServiceType("default");
		return sendTrans(request, url);
	}

	/**
	 * 确认完成交易 只适用于交易完成时
	 * 
	 * @param trans
	 * @return
	 * @throws Exception
	 * @throws IPBAppException
	 */
	public Transaction affirmTrans(Transaction trans) throws Exception {
		// 日志
		log.info("确认交易，交易编号：" + trans.getTransId());
		trans = sendTrans(parseAffirmData(trans), Constants.UNSPAY_TRANS_AFFIRM_URL);
		return trans;
	}

	// 创建即确认交易
	private Transaction sendImmediateTrans(Map<String, Object> data, String url) throws Exception {
		ServiceParameter request = new ServiceParameter();
		request.setData(data);
		String date = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		request.setRequestTime(date);
		request.setServiceType("immediate");

		return sendTrans(request, url);
	}

	// 复制交易数据
	public void copyTransaction(Transaction th, Transaction tran) {
		th.setAccountBankSeq(tran.getAccountBankSeq());
		th.setAmount(tran.getAmount());
		th.setAuditTrans(tran.getAuditTrans());
		th.setBankCitySeq(tran.getBankCitySeq());
		th.setBankInfoSeq(tran.getBankInfoSeq());
		th.setBankName(tran.getBankName());
		th.setBankProvSeq(tran.getBankProvSeq());
		th.setBankResponse(tran.getBankResponse());
		th.setBankSeq(tran.getBankSeq());
		th.setBarcode(tran.getBarcode());
		th.setBatchNo(tran.getBatchNo());
		th.setBeginDate(tran.getBeginDate());
		th.setCardNo(tran.getCardNo());
		th.setCommodityInfo(tran.getCommodityInfo());
		th.setCreateTime(tran.getCreateTime());
		th.setCreateUser(tran.getCreateUser());
		th.setCreditFee(tran.getCreditFee());
		th.setCreditRatioSeq(tran.getCreditRatioSeq());
		th.setDebitFee(tran.getDebitFee());
		th.setDebitRatioSeq(tran.getDebitRatioSeq());
		th.setDesFlag(tran.getDesFlag());
		th.setEndDate(tran.getEndDate());
		th.setExchangeRate(tran.getExchangeRate());
		th.setInsideStatus(tran.getInsideStatus());
		th.setMac(tran.getMac());
		th.setOperatorSeq(tran.getOperatorSeq());
		th.setOperSource(tran.getOperSource());
		th.setOrderId(tran.getOrderId());
		th.setPersonMail(tran.getPersonMail());
		th.setPersonMobile(tran.getPersonMobile());
		th.setPersonName(tran.getPersonName());
		th.setPersonPhone(tran.getPersonPhone());
		th.setPurpose(tran.getPurpose());
		th.setRemark(tran.getRemark());
		th.setSellerParam(tran.getSellerParam());
		th.setSellerUrl(tran.getSellerUrl());
		th.setTradeType(tran.getTradeType());
		th.setTransId(tran.getTransId());
		th.setTransStatus(tran.getTransStatus());
		th.setUpdateTime(tran.getUpdateTime());
		th.setUpdateUser(tran.getUpdateUser());
		th.setUpdateUserSystem(tran.getUpdateUserSystem());
		th.setVoucherCode(tran.getVoucherCode());
		th.setId(tran.getId());
		th.setRelatingSeq(tran.getRelatingSeq());
		th.setOperSource(tran.getOperSource());
		th.setAuditTrans(tran.getAuditTrans());
		th.setEncryptcode(tran.getEncryptcode());
	}

	public Map<String, Object> parseUpdateData(Transaction trans) {
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("id", trans.getId());
		data.put("transId", trans.getTransId());
		data.put("transStatus", trans.getTransStatus());
		data.put("updateUser", trans.getUpdateUser());
		data.put("bankSeq", trans.getBankSeq());
		data.put("debitSeq", trans.getDebitSeq());
		data.put("creditSeq", trans.getCreditSeq());
		data.put("actionSeq", trans.getActionSeq());
		data.put("insideStatus", trans.getInsideStatus());
		data.put("amount", trans.getAmount());
		data.put("bankResponse", trans.getBankResponse());
		data.put("auditTrans", trans.getAuditTrans());
		data.put("verifyCode", trans.getVerifyCode());

		return data;
	}

	private Map<String, Object> parseAffirmData(Transaction trans) {
		Map<String, Object> data = new HashMap<String, Object>();

		data.put("id", trans.getId());
		data.put("transId", trans.getTransId());
		data.put("actionSeq", trans.getActionSeq());
		data.put("creditSeq", trans.getCreditSeq());
		data.put("debitSeq", trans.getDebitSeq());
		data.put("insideStatus", trans.getInsideStatus());
		data.put("amount", trans.getAmount());
		data.put("creditFee", trans.getCreditFee());
		data.put("debitFee", trans.getDebitFee());
		data.put("transStatus", trans.getTransStatus());
		data.put("bankSeq", trans.getBankSeq());
		data.put("bankResponse", trans.getBankResponse());
		data.put("updateUser", trans.getUpdateUser());
		data.put("relatingSeq", trans.getRelatingSeq());
		data.put("tradeType", trans.getTradeType());
		return data;
	}

	private Map<String, Object> parseCreateData(Transaction trans) {
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("orderId", trans.getOrderId());
		data.put("actionSeq", trans.getActionSeq());
		data.put("creditSeq", trans.getCreditSeq());
		data.put("debitSeq", trans.getDebitSeq());
		data.put("creditFee", trans.getCreditFee());
		data.put("debitFee", trans.getDebitFee());
		data.put("amount", trans.getAmount());
		data.put("currency", trans.getCurrency());
		data.put("exchangeRate", trans.getExchangeRate());
		data.put("tradeType", trans.getTradeType());
		data.put("transStatus", trans.getTransStatus());
		data.put("insideStatus", trans.getInsideStatus());
		data.put("bankSeq", trans.getBankSeq());
		data.put("accountBankSeq", trans.getAccountBankSeq());
		data.put("cardNo", trans.getCardNo());
		data.put("bankName", trans.getBankName());
		data.put("bankProvSeq", trans.getBankProvSeq());
		data.put("bankCitySeq", trans.getBankCitySeq());
		data.put("personName", trans.getPersonName());
		data.put("personMail", trans.getPersonMail());
		data.put("personPhone", trans.getPersonPhone());
		data.put("personMobile", trans.getPersonMobile());
		data.put("remark", trans.getRemark());
		data.put("sellerUrl", trans.getSellerUrl());
		data.put("commodityInfo", trans.getCommodityInfo());
		data.put("sellerParam", trans.getSellerParam());
		data.put("desFlag", trans.getDesFlag());
		data.put("mac", trans.getMac());
		data.put("relatingSeq", trans.getRelatingSeq());
		data.put("barcode", trans.getBarcode());
		data.put("operSource", trans.getOperSource());
		data.put("createUser", trans.getCreateUser());
		data.put("updateUser", trans.getUpdateUser());
		data.put("auditTrans", trans.getAuditTrans());
		data.put("voucherCode", trans.getVoucherCode());
		data.put("operatorSeq", trans.getOperatorSeq());
		data.put("bankInfoSeq", trans.getBankInfoSeq());
		data.put("purpose", trans.getPurpose());
		data.put("batchNo", trans.getBatchNo());
		data.put("verifyCode", trans.getVerifyCode());
		return data;
	}

}
