package com.uns.channel;

import com.uns.common.Constants;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.model.BankTrans;
import com.uns.util.AnalyExcel;
import com.uns.util.ChannelConstants;
import com.uns.web.form.CheckBillForm;

import java.io.InputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/8/28
 * @Modifyed By:
 */
public class ChannelHandleUnionpayWg extends ChannelHandleDefault implements ChannelHandleInterface {
    @Override
    public List<BankTrans> loadDate(InputStream inputStream, CheckBillForm checkBillForm) throws Exception {
        return AnalyExcel.loadTextNew(inputStream, checkBillForm, Constants.UPLOAD_UNIONPAY_TXT_NEW);
    }

    @Override
    public List<Map<String, Object>> getLocalTrans(Integer id) throws Exception {
        List<String> unionpayWgChannel = Arrays.asList(DynamicConfigLoader.getByEnv("UNIONPAY_WG_CHANNEL"));
        String unionpayWgActionType = DynamicConfigLoader.getByEnv("UNIONPAY_WG_ACTIONTYPE");
        pareMap.clear();
        pareMap.put("id", id);
        pareMap.put("actionType", unionpayWgActionType);
        pareMap.put("channel",unionpayWgChannel);
        localTrans = checkBillMapper.getUnionpayWgTrans(pareMap);
        return localTrans;
    }

    @Override
    public Map<String, Object> getLocalAmount(String channel, String checkDate) {
        return null;
    }

    @Override
    public List<String> getChannelList() throws Exception {
        return null;
    }
}
