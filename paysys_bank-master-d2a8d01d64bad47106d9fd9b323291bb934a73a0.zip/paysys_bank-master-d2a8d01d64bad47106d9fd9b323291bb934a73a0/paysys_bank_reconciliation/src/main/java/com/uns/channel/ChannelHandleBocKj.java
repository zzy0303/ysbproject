package com.uns.channel;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

import com.uns.common.Constants;
import com.uns.model.BankTrans;
import com.uns.util.AnalyExcel;
import com.uns.web.form.CheckBillForm;

public class ChannelHandleBocKj extends ChannelHandleDefault implements ChannelHandleInterface{

	@Override
	public List<BankTrans> loadDate(InputStream inputStream, CheckBillForm checkBillForm) throws Exception {
		return AnalyExcel.loadAllShell(inputStream, checkBillForm, Constants.UPLOAD_BOC_KJ_SHELL);
	}

	@Override
	public List<Map<String, Object>> getLocalTrans(Integer id) throws Exception {
		pareMap.put("id", id);
		pareMap.put("actionType", Constants.UPLOAD_KJ_ACTIONTYPE);
		return checkBillMapper.getBocKjTrans(pareMap);
	}

	@Override
	public Map<String, Object> getLocalAmount(String channel, String checkDate) {
		return null;
	}

	@Override
	public List<String> getChannelList() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
}
