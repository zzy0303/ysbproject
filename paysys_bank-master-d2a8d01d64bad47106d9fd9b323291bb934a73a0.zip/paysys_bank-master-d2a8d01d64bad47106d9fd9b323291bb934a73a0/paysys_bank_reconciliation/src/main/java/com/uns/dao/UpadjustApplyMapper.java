package com.uns.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.uns.web.form.TransDetailForm;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.uns.model.UpadjustApply;
import com.uns.web.form.AdjustApplyForm;
import com.uns.web.form.AdjustAuditForm;

@Repository
public interface UpadjustApplyMapper {

	int deleteByPrimaryKey(BigDecimal id);

	void delectbyBankTransId(Map<String, List<String>> map);

	void delectbyTransSeq(Map<String, List<String>> map);

	void delectbyTransSeqNetsUnion(Map<String, List<String>> map);

	void deleteByCncb(Map<String, Object> pareMap);	
	
	void updateByTransId(String transId);
	
	void updateByApplyTransId(Map<String,String> map);

	void updateByApplyBankTransId(Map<String,String> map);
	
	int insert(UpadjustApply record);

	int insertSelective(UpadjustApply record);

	int insertIntoALLRecord(List<UpadjustApply> UpadjustApply);

	UpadjustApply selectByPrimaryKey(BigDecimal id);

	int updateByPrimaryKeySelective(UpadjustApply record);

	int updateByPrimaryKey(UpadjustApply record);

	List<Object> getAdjustApplyList(AdjustApplyForm adjustApplyForm);

	Map<String, Object> getTransDetail(String transId);

	List<Object> getAdjustAuditList(AdjustAuditForm adjustAuditForm);

	List<Object> getTrandIdList(AdjustAuditForm adjustAuditForm);

	Map<String, Object> getAuditDetail(Map<String,Object> params);

	Map<String, Object> getNetsUnionAuditDetail(Map<String,Object> params);

	Map<String, Object> getAuditBankDetail(String transId);

	UpadjustApply getByApplyNo(String applyNo);

	Integer getTransStatus(String applyNo);

	Integer checkApplied(String transId);

	Integer checkApply(String transId);

	List<Map<String, Object>> getHandUpTrans(Map<String, Object> map);

	List<Map<String, Object>> getNestUnionHungUpTrans(Map<String, Object> map);

	Double getBankTransAmount(String id);

	Double getTransAmount(String id);
	
	List<String> getAllTransDetail(Map<String, List<String>> map);

	List<Long> getApplyByBankId(Map<String, List<String>> map);

	List<Long> getapplyNoByTransSeq(Map<String, List<String>> map);
	
	List<Long> getApplyByCncb(Map<String, Object> pareMap);
	
	String getById(String applyNo);

	String getNetsUnionById(String applyNo);

	String getNetsUnionTransId(String applyNo);
	
	String getByCncbId(String applyNo);

	Integer checkApplyed(Map transIds);

	Integer checkEpccApplyed(Map transIds);

	void insertBatch(List<UpadjustApply> list);

	void updateBatch(Map transIds);

	List<UpadjustApply> getBatchList(Map applyNos);

	void updateByApplyTransIdBatch(@Param("status") String status, @Param("dealFlagsmaps") List<Map> dealFlagsmaps);

	void updateApplyBatch(@Param("upadjustApplies") List<UpadjustApply> upadjustApplies);

    List<String> getWaitAuditList(TransDetailForm transDetailForm);

	List<Object> getOutAdjustAuditList(AdjustAuditForm adjustAuditForm);

	List<Object> getNetsUnionAdjustAuditList(AdjustAuditForm adjustAuditForm);

	List<String> getNetsUnionWaitAuditList(TransDetailForm transDetailForm);

	UpadjustApply getNetsUnionByTransSeq(Map paramMap);
}