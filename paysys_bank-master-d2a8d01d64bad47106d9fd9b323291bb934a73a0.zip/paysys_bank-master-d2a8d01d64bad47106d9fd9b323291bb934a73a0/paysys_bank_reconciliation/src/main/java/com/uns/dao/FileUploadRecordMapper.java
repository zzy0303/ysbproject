package com.uns.dao;

import java.math.BigDecimal;
import java.util.List;

import com.uns.web.form.CheckBillForm;
import org.springframework.stereotype.Repository;

import com.uns.model.CheckBill;
import com.uns.model.FileUploadRecord;

@Repository
public interface FileUploadRecordMapper {

	int deleteByPrimaryKey(Long id);

	int insert(FileUploadRecord record);

	int insertSelective(FileUploadRecord record);

	FileUploadRecord selectByPrimaryKey(BigDecimal id);

	int updateByPrimaryKeySelective(FileUploadRecord record);

	int updateByPrimaryKey(FileUploadRecord record);

	void insertList(List<FileUploadRecord> list);

	List<FileUploadRecord> getUploadList();

	List<FileUploadRecord> getOutUploadList(CheckBillForm checkBillForm);

	List<FileUploadRecord> getNetsUnionUploadList(CheckBillForm checkBillForm);

	FileUploadRecord getRecordByChannelCheckDate(FileUploadRecord record);

	FileUploadRecord getRecordByBatchId(FileUploadRecord record);

	void updateCheckStatus(CheckBill checkBill);

	void updateNetsUnionCheckStatus(CheckBill checkBill);

	FileUploadRecord getByCheckBill(CheckBill checkBill);
	FileUploadRecord getByCheckBillBatch(CheckBill checkBill);

}