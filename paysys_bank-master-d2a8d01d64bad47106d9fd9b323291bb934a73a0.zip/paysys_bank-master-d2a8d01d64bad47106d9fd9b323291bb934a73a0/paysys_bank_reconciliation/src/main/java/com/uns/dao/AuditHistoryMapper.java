package com.uns.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.AuditHistory;

@Repository
public interface AuditHistoryMapper {

	int deleteByPrimaryKey(BigDecimal id);

	int insert(AuditHistory record);

	int insertSelective(AuditHistory record);

	AuditHistory selectByPrimaryKey(BigDecimal id);

	int updateByPrimaryKeySelective(AuditHistory record);

	int updateByPrimaryKey(AuditHistory record);

	List<Map<String, Object>> getAuditHis(Map<String, Object> map);

	int deleteAuditHistory(Map<String, List<Long>> map);
}