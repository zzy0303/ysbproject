package com.uns.channel;

import com.uns.common.Constants;
import com.uns.model.BankTrans;
import com.uns.util.AnalyExcel;
import com.uns.web.form.CheckBillForm;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

public class ChannelHandleCcbB2b extends ChannelHandleDefault implements ChannelHandleInterface{

    @Override
    public List<BankTrans> loadDate(InputStream inputStream, CheckBillForm checkBillForm) throws Exception {
        return AnalyExcel.loadText(inputStream, checkBillForm, Constants.UPLOAD_CCB_B2B_TXT);
    }

    @Override
    public List<Map<String, Object>> getLocalTrans(Integer id) throws Exception {
        pareMap.put("id", id);
        pareMap.put("channel", Constants.UPLOAD_CCB_B2B.split(","));
        pareMap.put("actionType", Constants.UPLOAD_UPOP_B2B_ACTIONTYPE);
        return checkBillMapper.getB2BTrans(pareMap);
    }

    @Override
    public Map<String, Object> getLocalAmount(String channel, String checkDate) {
        return null;
    }

    @Override
    public List<String> getChannelList() throws Exception {
        return null;
    }
}
