package com.uns.dao;

import java.math.BigDecimal;

import org.springframework.stereotype.Repository;

import com.uns.model.AuditGroup;

@Repository
public interface AuditGroupMapper {

	int deleteByPrimaryKey(BigDecimal id);

	int insert(AuditGroup record);

	int insertSelective(AuditGroup record);

	AuditGroup selectByPrimaryKey(BigDecimal id);

	int updateByPrimaryKeySelective(AuditGroup record);

	int updateByPrimaryKey(AuditGroup record);
}