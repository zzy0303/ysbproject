package com.uns.util;

import org.apache.commons.lang3.StringUtils;


public enum ErrorCodeEnum {

    成功("0000", "成功"),
    出错("2222", "系统错误"),
    该商户此交易类型已添加("1001","该商户此交易类型已添加"),
    此白名单商户不存在("1002","此白名单商户不存在");

    ErrorCodeEnum(String code, String text) {
        this.code = code;
        this.text = text;
    }

    private String code;
    private String text;

    public String getText() {
        return text;
    }

    public String getCode() {
        return code;
    }

    public static ErrorCodeEnum fromCode(String code) {
        for (ErrorCodeEnum messageEnum : ErrorCodeEnum.values()) {
            if (StringUtils.equals(code, messageEnum.getCode())) {
                return messageEnum;
            }
        }
        return null;
    }

}
