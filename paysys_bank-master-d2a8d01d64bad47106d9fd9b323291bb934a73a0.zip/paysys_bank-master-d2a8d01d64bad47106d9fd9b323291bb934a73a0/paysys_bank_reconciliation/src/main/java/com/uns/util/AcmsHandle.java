package com.uns.util;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import com.uns.inf.acms.client.config.ConfigInitLoadingConfigurer;
import com.uns.inf.acms.client.core.ChangeHandler;
import com.uns.inf.acms.client.core.ChangedConfig;
import com.uns.inf.acms.client.core.ConfigOperation;


/**
 * 参数平台修改回调
 * The type Acms handle.
 */
@Component
public class AcmsHandle implements ChangeHandler, ApplicationContextAware {
	private static final Log logger = LogFactory.getLog(AcmsHandle.class);

	private AcmsMapUtils acmsMapUtils;

	private static final String PRIX_KEY = ConfigInitLoadingConfigurer.getAppEnv() + ".";

	public void handle(List<ChangedConfig> configs) {
		for (ChangedConfig config : configs) {
			String key = config.getConfigKey();
			String value = config.getConfigValue();

			ConfigOperation op = config.getOp();
			logger.info("DC : acms event=" + op.name() + ", key=" + key + ", value=" + value);

			String urlKey = key.substring(PRIX_KEY.length());
			logger.info("DC : Send urlKey[" + urlKey + "] has changed.");

			if ((ConfigOperation.Add.equals(op)) || (ConfigOperation.Update.equals(op))) {
				try {
					acmsMapUtils.getAcmsMap().put(urlKey, value);
					logger.info("map:"+FastJson.toJson(acmsMapUtils.getAcmsMap()));
					logger.info("DC : Add or update urlKey[" + urlKey + "=" + value +"].");
				} catch (Exception e) {
					logger.error("DC : Failed to set " + urlKey + "Sender property. key=" + key + ", value=" + value, e);
				}

			} else if (ConfigOperation.Delete.equals(op)){
				try {
					acmsMapUtils.getAcmsMap().remove(urlKey);
					logger.info("map:"+FastJson.toJson(acmsMapUtils.getAcmsMap()));
					logger.info("DC : Delete urlKey[" + urlKey + "=" + value +"].");
				} catch (Exception e) {
					logger.error("DC : Failed to set " + urlKey + "Sender property. key=" + key + ", value=" + value, e);
				}
			}
		}
	}

	@Override
	public void setApplicationContext(ApplicationContext arg0) throws BeansException {
		this.acmsMapUtils = (AcmsMapUtils) arg0.getBean("acmsMapUtils");
		if (this.acmsMapUtils == null)
			logger.error("DC : acmsMapUtils is null");

	}

}
