package com.uns.channel;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

import com.uns.common.Constants;
import com.uns.model.BankTrans;
import com.uns.util.AnalyExcel;
import com.uns.util.ChannelConstants;
import com.uns.web.form.CheckBillForm;

public class ChannelHandleUnionpayBht0 extends ChannelHandleDefault implements ChannelHandleInterface {

	@Override
	public List<BankTrans> loadDate(InputStream inputStream, CheckBillForm checkBillForm) throws Exception {
		return AnalyExcel.loadAllShell(inputStream, checkBillForm, Constants.UPLOAD_UNIONPAY_BHT0_SHELL);
	}

	@Override
	public List<Map<String, Object>> getLocalTrans(Integer id) throws Exception {
		return super.getOutLocalTrans(id, ChannelConstants.CHANNEL_UNIONPAY_BHT0);		
	}

	@Override
	public Map<String, Object> getLocalAmount(String channel, String checkDate) {
		return super.getOutLocalAmount(channel, checkDate);
	}

	@Override
	public List<String> getChannelList() throws Exception {
		return null;
	}

}
