package com.uns.channel;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.model.BankTrans;
import com.uns.util.AnalyExcel;
import com.uns.web.form.CheckBillForm;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ChannelHandleBosh extends ChannelHandleDefault implements ChannelHandleInterface {

	@Override
	public List<BankTrans> loadDate(InputStream inputStream, CheckBillForm checkBillForm) throws Exception {
        HSSFSheet hssfSheet = null;
	    XSSFSheet xssfSheet = null;
        HSSFWorkbook hssfWorkbook = null;
        XSSFWorkbook xssfWorkbook = null;
		String fileType;
		String ext;
		try {
			fileType = checkBillForm.getCheckBillFile()[0].getOriginalFilename();
			ext = fileType.substring(fileType.lastIndexOf("."));
			if(ext.equals(".xls")){
                hssfWorkbook = new HSSFWorkbook(inputStream);
                hssfSheet = hssfWorkbook.getSheetAt(0);// 得到上传Excel文件的第一页
			}else{
                xssfWorkbook = new XSSFWorkbook(inputStream);
                xssfSheet = xssfWorkbook.getSheetAt(0);
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.文件上传失败);
		}
		finally {
			if (null != hssfWorkbook){
                hssfWorkbook.close();
			}
            if (null != xssfWorkbook){
                xssfWorkbook.close();
            }
			if(null != inputStream){
				inputStream.close();
			}
		}
        List<BankTrans> list = AnalyExcel.loadBoshxlsx(hssfSheet, xssfSheet, checkBillForm, Constants.UPLOAD_BOSH_OUT_SHELL);
		if(list == null || list.size() == 0){
			list = AnalyExcel.loadBoshxlsx(hssfSheet, xssfSheet, checkBillForm, Constants.UPLOAD_BOSH_OUT_IB_SHELL);
		}
		return list;
	}

	@Override
	public List<Map<String, Object>> getLocalTrans(Integer id) throws Exception {
		return super.getOutLocalTrans(id , Constants.UPLOAD_BOSH);
	}

	@Override
	public Map<String, Object> getLocalAmount(String channel, String checkDate) {
		return super.getOutLocalAmount(channel, checkDate);
	}

	@Override
	public List<String> getChannelList() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
