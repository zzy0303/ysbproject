package com.uns.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * zip文件工具
 */
public class ZipUtils {

    protected static Log log = LogFactory.getLog(ZipUtils.class);

    //解压缩文件
    public static InputStream getTxtInputStream(InputStream inputStream) throws IOException {
        try {

            ZipInputStream zis = new ZipInputStream(inputStream);
            ZipEntry zipEntry = null;
            while ((zipEntry = zis.getNextEntry()) != null) {
                byte[] data = getByte(zis); // 获取当前条目的字节数组
                inputStream = new ByteArrayInputStream(data);
                return inputStream;
            }
        } catch (Exception e) {
            log.info(e.getMessage());
            throw new RuntimeException("文件解压失败!");
        }
        return null;
    }

    public static byte[] getByte(InputStream zis) {
        try {
            ByteArrayOutputStream bout = new ByteArrayOutputStream();
            byte[] temp = new byte[1024];
            byte[] buf = null;
            int length = 0;

            while ((length = zis.read(temp, 0, 1024)) != -1) {
                bout.write(temp, 0, length);
            }

            buf = bout.toByteArray();
            bout.close();
            return buf;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
