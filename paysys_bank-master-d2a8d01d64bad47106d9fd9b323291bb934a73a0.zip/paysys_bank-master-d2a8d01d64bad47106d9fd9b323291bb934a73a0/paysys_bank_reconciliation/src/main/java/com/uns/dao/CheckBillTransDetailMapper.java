package com.uns.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.CheckBillTransDetail;
import com.uns.web.form.CheckBillForm;
import com.uns.web.form.TransDetailForm;

@Repository
public interface CheckBillTransDetailMapper {

	int deleteByPrimaryKey(BigDecimal id);

	int insert(CheckBillTransDetail record);

	int insertSelective(CheckBillTransDetail record);

	CheckBillTransDetail selectByPrimaryKey(BigDecimal id);

	int updateByPrimaryKeySelective(CheckBillTransDetail record);

	int updateByPrimaryKey(CheckBillTransDetail record);

	void insertList(List<CheckBillTransDetail> list);

	List<CheckBillTransDetail> getTransDetailList(TransDetailForm transDetailForm);

	List<CheckBillTransDetail> getDefaultDetailList(TransDetailForm transDetailForm);

	List<CheckBillTransDetail> getDifferTransList(TransDetailForm transDetailForm);

	List<CheckBillTransDetail> getNetsUnionDifferTransList(TransDetailForm transDetailForm);

	String getNumAmount(TransDetailForm transDetailForm);

	String getNormalNumAmount(TransDetailForm transDetailForm);

	List<String> getRecord(TransDetailForm transDetailForm);

	double getAmount(String id);

	String getNetsUnionAmount(String id);

	public CheckBillTransDetail getDetailByLocalTransId(String transId);

	public String getCheckStatus(String id);

	public List<String> getChannel();

	void insertListSingle(CheckBillTransDetail cbt);

	int delettransdetaile(Long id);

	int deletlocaltrans(CheckBillTransDetail checkBilldetail);

	int deletlocaltransNetsUnion(CheckBillForm checkBillForm);

	List<String> getTransDetailIdList(CheckBillForm checkBillForm);

	List<Map<String, Object>> getActionName();

	List<String> getTransId(CheckBillTransDetail checkBillTransDetail);

	List<String> getNetsUnionTransIds(CheckBillForm checkBillForm);

	List<String> getMerchantId(String accountName);

	double getamountById(Map<String, Object> map);

    List<CheckBillTransDetail> queryThresholdInfoList(Map<String, String> map);

    void updateByParam(Map<String, Object> map);

    Integer gethungupTrans(Map<String, Object> map);

	Integer getNetsUnionhungupTrans(CheckBillForm checkBillForm);
    
    void updateHungupTrans(Map<String, Object> map);

	void updateNetsUnionHungupTrans(CheckBillForm checkBillForm);

    CheckBillTransDetail getDetailByLocalOrderId(String localTransId);

    List<String> getDealTrans(TransDetailForm transDetailForm);

	List<String> getNetsUnionDealTrans(TransDetailForm transDetailForm);

    List<CheckBillTransDetail> getOutDetailList(TransDetailForm transDetailForm);

	List<CheckBillTransDetail> getNetsUnionDetailList(TransDetailForm transDetailForm);
    
    String getOutNumAmount(TransDetailForm transDetailForm);

	String getNetsUnionNumAmount(TransDetailForm transDetailForm);

	void updateOldEpccDetail(Map<String, Object> paramMap);
}