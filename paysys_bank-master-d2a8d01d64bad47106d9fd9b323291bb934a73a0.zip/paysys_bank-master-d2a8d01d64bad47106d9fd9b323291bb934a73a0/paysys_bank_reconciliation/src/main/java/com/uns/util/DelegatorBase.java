package com.uns.util;

public class DelegatorBase<T> {
	public boolean delegatorFilter(T obj) {
		return true;
	}

	public boolean delegatorCompareFilter(T obj, Object cf) {
		return true;
	}
}
