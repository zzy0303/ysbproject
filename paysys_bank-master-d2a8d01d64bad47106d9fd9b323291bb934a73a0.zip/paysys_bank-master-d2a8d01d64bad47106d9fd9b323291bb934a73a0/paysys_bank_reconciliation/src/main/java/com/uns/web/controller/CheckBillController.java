package com.uns.web.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.servlet.http.HttpServletRequest;

import com.uns.common.cache.CacheManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.cache.CacheManager;
import com.uns.common.exception.BusinessException;
import com.uns.model.CheckBill;
import com.uns.model.FileUploadRecord;
import com.uns.model.UserInfo;
import com.uns.service.CheckBillService;
import com.uns.service.FileUploadRecordService;
import com.uns.util.AcmsMapUtils;
import com.uns.util.StringUtils;
import com.uns.web.form.CheckBillForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

@Controller
@RequestMapping(value = "/checkBill.htm")
public class CheckBillController extends BaseController {
	@Autowired
	private CheckBillService checkBillService;
	@Autowired
	private MessageSource messageSource;
	@Autowired
	private FileUploadRecordService fileUploadRecordService;

	private Logger log = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private AcmsMapUtils acmsMapUtils;


	@RequestMapping(params = "method=checkBillList")
	@FormToken(save = true)
	// 跳转对账列表页面
	public String checkBillList(HttpServletRequest request, CheckBillForm checkBillForm) throws BusinessException {
		// 获取直连通道
		String[] directChannel = acmsMapUtils.getAcmsMap().get("CHECK_BILL_CHANNEL_DIRECT").split(",");
		// 获取间连通道
		String[] inDirectChannel = acmsMapUtils.getAcmsMap().get("CHECK_BILL_CHANNEL_INDIRECT").split(",");
		if (Constants.CHECK_BILL_0.equals(checkBillForm.getConnType())) {
			checkBillForm.setChannel(checkBillForm.getChannel1());
		} else {
			checkBillForm.setChannel(checkBillForm.getChannel2());
		}
		checkBillForm.setBillType(Constants.CHECK_BILL_0);
		List<CheckBill> checkList = checkBillService.getCheckList(checkBillForm);
		request.setAttribute("checkList", checkList);
		request.setAttribute("checkBillForm", checkBillForm);
		request.setAttribute("directChannel", directChannel);
		request.setAttribute("inDirectChannel", inDirectChannel);
		return "checkbill/checkBillList";
	}

	@RequestMapping(params = "method=toUploadList")
	@FormToken(save = true)
	// 跳转上传页面
	public String toUploadList(HttpServletRequest request, CheckBillForm checkBillForm) throws BusinessException {
		//动态获取参数
		Map<String,String> dynamicParam = acmsMapUtils.getAcmsMap();
		// 获取直连间连银行数据
		String[] directChannel = dynamicParam.get("CHECK_BILL_CHANNEL_DIRECT").split(",");
		String[] inDirectChannel = dynamicParam.get("CHECK_BILL_CHANNEL_INDIRECT").split(",");
		String[] pattern =  dynamicParam.get("CHECK_BILL_CHANNEL_PATTERN").split(",");
		String[] inParrert = dynamicParam.get("CHECK_BILL_CHANNEL_INPATTERN").split(",");
		String getChannel = request.getParameter("channel").toString();
		String getCheckDate = request.getParameter("checkdate").toString();
		String directFlag = "1";
		List<String> list = new ArrayList<String>(Arrays.asList(directChannel));
		if (null != getChannel && list.contains(getChannel)) {
			directFlag = "0";
		}
		getCheckDate = StringUtils.getdate(getCheckDate);
		request.setAttribute("directChannel", directChannel);
		request.setAttribute("inDirectChannel", inDirectChannel);
		request.setAttribute("pattern", pattern);
		request.setAttribute("inPattern", inParrert);
		request.setAttribute("getChannel", getChannel);
		request.setAttribute("getCheckDate", getCheckDate);
		request.setAttribute("directFlag", directFlag);
		return "checkbill/upload";
	}

	@RequestMapping(params = "method=upload")
	@FormToken(save = true)
	// 上传对账文件
	public String upload(HttpServletRequest request, CheckBillForm checkBillForm)
			throws BusinessException, IOException {
		String path = "checkbill/upload";
		UserInfo user = (UserInfo) (request.getSession().getAttribute(Constants.SESSION_KEY_USER));
		try {
			checkBillService.checkBill(checkBillForm, user.getUserName());
			/*List<FileUploadRecord> list = fileUploadRecordService.getUploadRecordList();
			request.setAttribute("uploadList", list);
			*/
			request.setAttribute("accountForm", null);
			path = "redirect:/fileUploadRecord.htm?method=toUploadRecordList";
		} catch (BusinessException be) {
			request.setAttribute("errMsg", be.getErrMessage(messageSource));
		} catch (Exception e) {
			request.setAttribute("errMsg", "保存出错！");
			e.printStackTrace();
		}
		// 获取通道信息传值到页面
		if (!path.equals("redirect:/fileUploadRecord.htm?method=toUploadRecordList")) {
			String[] directChannel = acmsMapUtils.getAcmsMap().get("CHECK_BILL_CHANNEL_DIRECT").split(",");
			String[] inDirectChannel = acmsMapUtils.getAcmsMap().get("CHECK_BILL_CHANNEL_INDIRECT").split(",");
			String[] pattern = acmsMapUtils.getAcmsMap().get("CHECK_BILL_CHANNEL_PATTERN").split(",");
			String[] inParrert = acmsMapUtils.getAcmsMap().get("CHECK_BILL_CHANNEL_INPATTERN").split(",");
			request.setAttribute("directChannel", directChannel);
			request.setAttribute("inDirectChannel", inDirectChannel);
			request.setAttribute("pattern", pattern);
			request.setAttribute("inPattern", inParrert);
		}
		return path;
	}

	@RequestMapping(params = "method=checkBill")
	@FormToken(save = true)
	// 对账
	public String checkBill(HttpServletRequest request, CheckBillForm checkBillForm) {
		try {
			UserInfo user = (UserInfo) (request.getSession().getAttribute(Constants.SESSION_KEY_USER));
			// 获取对账列表主键id
			Integer checkBillId = Integer.valueOf(request.getParameter("id"));
			// 获取对账通道
			String channel = request.getParameter("channel").toString();
			// 获取对账日期
			String checkdate = request.getParameter("checkdate").toString();
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("checkDate", StringUtils.getdate(checkdate));
			map.put("channel", channel);
			map.put("billType", checkBillForm.getBillType());
			checkBillService.compareTrans(checkBillId, user.getUserName(), map, checkBillForm);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(Constants.FLAG_2.equals(checkBillForm.getBillType())){
			return "redirect:/netsUnionCheckBill.htm?method=netsUnionCheckBillList";
		}
		return "redirect:/checkBill.htm?method=checkBillList";
	}

	@RequestMapping(params = "method=viewDetail")
	@FormToken(save = true)
	// 对账
	public String viewDetail(HttpServletRequest request, CheckBillForm checkBillForm) throws BusinessException {
		Long id = Long.valueOf(request.getParameter("id"));
		CheckBill checkBill = checkBillService.getDetailById(id);

		request.setAttribute("checkBill", checkBill);
		return "checkbill/checkDetail";
	}

	@RequestMapping(params = "method=toDeal")
	@FormToken(save = true)
	// 处理
	public String toDeal(HttpServletRequest request, CheckBillForm checkBillForm) throws BusinessException {

		Long id = Long.valueOf(checkBillForm.getId());
		CheckBill checkBill = checkBillService.getDetailById(id);
		request.setAttribute("checkBill", checkBill);
		return "checkbill/checkDetail";
	}

	@RequestMapping(params = "method=deal")
	@FormToken(save = true)
	// 处理
	public String deal(HttpServletRequest request, CheckBillForm checkBillForm) throws BusinessException {
		UserInfo user = (UserInfo) (request.getSession().getAttribute(Constants.SESSION_KEY_USER));
		Long id = Long.valueOf(checkBillForm.getId());
		CheckBill checkBill = checkBillService.getDetailById(id);
		checkBill.setCheckStatus(checkBillForm.getCheckStatus());
		checkBill.setDealRemark(checkBillForm.getDealRemark());
		checkBill.setHandler(user.getUserName());
		checkBill.setHandlingTime(new Date());

		checkBillService.updateRemark(checkBill);
		request.setAttribute("checkBill", checkBill);
		return "checkbill/checkDetail";
	}

	@RequestMapping(params = "method=preAutoBill")
	public String preAutoBill(HttpServletRequest request, CheckBillForm checkBillForm) {
		request.setAttribute("checkBillForm", checkBillForm);
		return "checkbill/preAutoBill";
	}

	@RequestMapping(params = "method=autoBill")
	public String autoBill(CheckBillForm checkBillForm, HttpServletRequest request) {
		if (!CacheManager.getSimpleFlag(Constants.CHECK_FLAG)){
			CacheManager.setSimpleFlag(Constants.CHECK_FLAG, true);
			ExecutorService pool = null;
			try {
				//获取所有对账通道
				String[] channel = Constants.PARAM_CHECK_BILL_CHANNEL.split(",");
				String checkDate = checkBillForm.getCheckdate();
				int taskSize = 10;
				// 创建线程池  线程数=通道数量
				pool = Executors.newFixedThreadPool(taskSize);
				// 创建多个有返回值的任务
				List<Future> futureList = new ArrayList<Future>();

				Future future;
				Callable callable;
				for (int i = 0; i < channel.length; i++) {
					callable = new AutoBillCallable(channel[i], checkDate);
					// 执行任务并获取Future对象
					future = pool.submit(callable);
					futureList.add(future);
				}

				// 获取所有并发任务的运行结果
				for (Future f : futureList) {
					// 从Future对象上获取任务的返回值
					log.info(f.get().toString());
				}
				request.setAttribute("msg", "自动对账完成");
			} catch (Exception e) {
				e.printStackTrace();
				request.setAttribute("msg", "自动对账出错!");
			} finally {
				//关闭线程池
				if (null != pool) {
					pool.shutdown();
				}
				CacheManager.setSimpleFlag(Constants.CHECK_FLAG, false);
			}
		} else {
			request.setAttribute("errMsg", "对账中，请稍后!");
		}
		request.setAttribute("title", "自动对账");
		request.setAttribute("closeTitle", "对账列表");
		request.setAttribute("url", "checkBill.htm?method=checkBillList");
		return "common/message";
	}

	public class AutoBillCallable implements Callable<Object> {
		private String channel;

		private String checkDate;
		public AutoBillCallable (String channel, String checkDate) {
			this.channel = channel;
			this.checkDate = checkDate;
		}
		@Override
		public Object call() throws Exception {
			try {
				log.info("{}通道:{}对账开始", channel, checkDate);
				long startTime = System.currentTimeMillis();

				CheckBillForm checkBillForm = new CheckBillForm();
				checkBillForm.setChannel(channel);
				checkBillForm.setCheckdate(checkDate);
				checkBillForm.setBillType(Constants.CHECK_BILL_0);
				checkBillService.autoUpload(checkBillForm);

				long endTime = System.currentTimeMillis();
				long time = endTime - startTime;
				log.info("{}通道:{}对账结束,对账完成时间【{}】",channel,checkDate,time);
				return channel + "对账完成，对账结果" + Constants.STATUS_0000;
			} catch (BusinessException be) {
				return channel + "对账完成，对账结果" + be.getErrMessage(messageSource);
			} catch (Exception e) {
				e.printStackTrace();
				return channel + "对账完成，对账结果" + e.getMessage();
			}
		}
	}
}
