package com.uns.biz;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import com.uns.model.BankTrans;
import com.uns.web.form.CheckBillForm;

public class BizIcbc extends DefaultBiz {
	@Override
	public boolean checkInputData(String[] data, CheckBillForm checkBillForm, BankTrans trans,
			Map<String, List<String>> setting) throws Exception {

		Calendar calendar = new GregorianCalendar();
		calendar.setTime(trans.getTransDate());
		calendar.add(Calendar.DATE, 1);
		Date nextDate = calendar.getTime();

		boolean rtn = super.checkInputData(data, checkBillForm, trans, setting);

		if (trans.getTransTime().getTime() >= nextDate.getTime()) {
			return false;
		}

		return rtn;
	}
}
