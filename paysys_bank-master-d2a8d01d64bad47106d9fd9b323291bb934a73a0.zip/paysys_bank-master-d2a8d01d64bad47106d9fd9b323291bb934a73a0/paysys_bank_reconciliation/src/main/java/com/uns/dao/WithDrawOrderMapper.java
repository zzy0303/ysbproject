package com.uns.dao;


import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.WithdrawOrder;


/**
 * Created by Administrator on 2017/4/24.
 */
@Repository
public interface WithDrawOrderMapper extends BaseMapper<Object>{

	List<WithdrawOrder> getTxTrans(Map<String, String> paramMap);//查询提现交易数据

	void insertTxTable(List<WithdrawOrder> txTransList);//插入数据到对账库的提现表中




}
