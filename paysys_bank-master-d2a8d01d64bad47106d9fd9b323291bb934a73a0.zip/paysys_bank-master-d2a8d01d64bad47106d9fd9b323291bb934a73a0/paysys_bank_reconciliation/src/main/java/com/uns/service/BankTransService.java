package com.uns.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.dao.BankTransMapper;

@Service
public class BankTransService {

	@Autowired
	private BankTransMapper bankTransMapper;

	public void deleteBankTrans(Long id) {
		bankTransMapper.deleteBankTrans(id);
	}

	public Map<String, Object> getApplyDetail(String transId) {
		if(transId.contains("_")){
			transId=transId.replace("_", "000000");
		}
		Map<String, Object> map = bankTransMapper.getTransDetail(transId);
		return map;
	}

	// 获取银行交易总金额
	public Map<String, Object> getTotalBankInfo(String[] bankTransId) {

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("bankTransId", bankTransId);
		Map<String, Object> map = bankTransMapper.getTotalBankInfo(paramMap);
		map.put("num", bankTransId.length);
		return map;
	}

	// 获取银生宝交易总金额
	public Map<String, Object> getTotalLocalInfo(String[] localTransId) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("localTransId", localTransId);
		Map<String, Object> map = bankTransMapper.getTotalLocalInfo(paramMap);
		map.put("num", localTransId.length);
		return map;
	}

	// 根据银生宝交易id集合获取交易详情
	public List<String> getTransIdDetailList(List<String> list) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("bankTransList", list);
		List<String> DetailList = bankTransMapper.getAllTransDetail(map);
		return DetailList;

	}

}
