package com.uns.service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.uns.dao.*;
import com.uns.datasourceSwitch.DynamicDataSourceHolder;
import com.uns.model.*;
import com.uns.web.form.CheckBillForm;
import org.apache.commons.beanutils.PropertyUtils;
import org.aspectj.apache.bcel.classfile.Constant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.util.StringUtils;
import com.uns.web.form.AdjustApplyForm;

@Service
public class AdjustApplyService {

	@Autowired
	private UpadjustApplyMapper upAdjustApplyMapper;
	@Autowired
	private TransactionMapper transactionMapper;
	@Autowired
	private AuditOperandTypeMapper auditOperandTypeMapper;
	@Autowired
	private AuditRuleMapper auditRuleMapper;
	@Autowired
	private AuditOperationMapper auditOperationMapper;
	@Autowired
	private AuditHistoryMapper auditHistoryMapper;
	@Autowired
	private AuditStepMapper auditStepMapper;
	@Autowired
	private CheckBillTransDetailMapper checkBillTransDetailMapper;
	@Autowired
	private TransRefMapper transRefMapper;

	public List<Object> getAdjustApplyList(AdjustApplyForm adjustApplyForm) {
		List<Object> list = upAdjustApplyMapper.getAdjustApplyList(adjustApplyForm);
		return list;
	}

	// 获取银行交易详情
	public List<String> getTransIdDetailList(List<String> LocalTransList) {
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		map.put("LocalTransList", LocalTransList);
		List<String> IdList = upAdjustApplyMapper.getAllTransDetail(map);
		return IdList;

	}

	// 删除调账申请记录
	public void deleteApplyRecord(CheckBillTransDetail checkBillTransDetail) {
		// 获取对账文件交易id
		List<String> list = checkBillTransDetailMapper.getTransId(checkBillTransDetail);
		// 获取银生宝对账交易
		if (null != list && list.size() > 0) {
			List<List> allList = StringUtils.getList(list);
			Map<String, List<String>> map = new HashMap<String, List<String>>();
			for (int i = 0; i < allList.size(); i++) {
				map.put("list", allList.get(i));
				// 删除银行有我方无的调账申请
				upAdjustApplyMapper.delectbyBankTransId(map);
				// 删除其他调账申请记录
				upAdjustApplyMapper.delectbyTransSeq(map);
			}
		}
	}

	// 删除网联调账申请记录
	public void deleteNetsUnionApplyRecord(CheckBillForm checkBillForm) {
		// 获取对账文件交易id
		List<String> list = checkBillTransDetailMapper.getNetsUnionTransIds(checkBillForm);
		// 获取银生宝对账交易
		if (null != list && list.size() > 0) {
			List<List> allList = StringUtils.getList(list);
			Map<String, List<String>> map = new HashMap<String, List<String>>();
			for (int i = 0; i < allList.size(); i++) {
				map.put("list", allList.get(i));
				// 删除bank_trans交易对应数据
				upAdjustApplyMapper.delectbyBankTransId(map);
				// 删除trans_ref交易对应数据
				upAdjustApplyMapper.delectbyTransSeqNetsUnion(map);
			}
		}
	}

	public Map<String, Object> getApplyDetail(String transId) {
		Map<String, Object> map = upAdjustApplyMapper.getTransDetail(transId);
		// 计算收付款方实际交易金额
		// 付款方费率外扣
		double debitRealAmount = Double.valueOf(map.get("AMOUNT").toString())
				+ Double.valueOf(map.get("DEBIT_FEE").toString());
		// 收款方费率外扣
		double creditRealAmount = Double.valueOf(map.get("AMOUNT").toString())
				- Double.valueOf(map.get("CREDIT_FEE").toString());
		map.put("CREDIT_REAL_AMOUNT", creditRealAmount);
		map.put("DEBIT_REAL_AMOUNT", debitRealAmount);
		return map;
	}

	// 批量申请
	public List<String> allApply(AdjustApplyForm adjustApplyForm, Long userId, String[] record) throws Exception {
		List<String> idlist = Arrays.asList(record);
		List<String> list = new ArrayList<String>();

		for (int i = 0; i < idlist.size(); i++) {
			adjustApplyForm.setTransId(idlist.get(i));
			String applyNo = this.apply(adjustApplyForm, userId);
			list.add(applyNo);
		}
		return list;
	}

	public String applyRecord(AdjustApplyForm adjustApplyForm, Long userId, String[] record) throws Exception {
		Map param = new HashMap();
		param.put("transIds", record);
		Integer applied = upAdjustApplyMapper.checkApplyed(param);
		if (null != applied && applied > 0){
			throw new BusinessException(ExceptionDefine.存在交易已发起过调账申请);
		}
		UpadjustApply apply;
		List<UpadjustApply> applyList = new ArrayList<>();
		List<Transaction> transactions = transactionMapper.getTransByTransId(param);
		if (transactions.size() == 0){
            transactions = transactionMapper.getTransByNewTransId(param);
        }
		for (Transaction transaction : transactions) {
			apply = new UpadjustApply();
			apply.setApplyNo(getApplyNo());
			apply.setAuditStatus(Constants.AUDIT_FLAG_LOCAL_LACK);// 审核中
			apply.setApplyTime(new Date());
			apply.setReason(adjustApplyForm.getApplyReason());
			apply.setRemark(adjustApplyForm.getApplyRemark());
			String transId = transaction.getTransId();
			Long transSeq = transaction.getId().longValue();
			if(transId.length()>15){
				adjustApplyForm.setTransId(transId.replace("000000", "_"));
			}
			if (Constants.ADJUST_REASON_BANK_TRANS_COUNTER.equals(adjustApplyForm.getApplyReason())) {// 银行交易冲正调账申请
				apply.setApplyFlag(Constants.AUDIT_FLAG_LOCAL_LACK);
				apply.setBankTransId(transId);
				apply.setTransSeq(BigDecimal.valueOf(99));
			} else {
				if (Constants.ADJUST_REASON_OTHER.equals(adjustApplyForm.getApplyReason())) {// 调账原因：其他
					if (adjustApplyForm.getCheckStatus().equals(Constants.CHECK_STATUS_LOCAL_LACK)) {// 银行有我方无
						apply.setApplyFlag(Constants.AUDIT_FLAG_LOCAL_LACK);
						apply.setTransSeq(BigDecimal.valueOf(99));
						apply.setBankTransId(transId);

					} else if (adjustApplyForm.getCheckStatus().equals(Constants.CHECK_STATUS_BANK_LACK)) {// 银行无我方有
						apply.setApplyFlag(Constants.AUDIT_FLAG_BANK_LACK);
						apply.setTransSeq(BigDecimal.valueOf(transSeq));
					} else {// 金额不对
						apply.setApplyFlag(Constants.AUDIT_FLAG_AMOUNT_ERROR);
						apply.setTransSeq(BigDecimal.valueOf(transSeq));
						apply.setBankTransId(transId);
					}
				} else if (Constants.ADJUST_REASON_AMOUNT_ERROR.equals(adjustApplyForm.getApplyReason())) {// 调账原因：金额不对
					apply.setTransSeq(BigDecimal.valueOf(transSeq));
					apply.setApplyFlag(Constants.AUDIT_FLAG_AMOUNT_ERROR);
					apply.setBankTransId(transId);
				} else {
					if (null != transSeq) {
						apply.setTransSeq(BigDecimal.valueOf(transSeq));
						apply.setApplyFlag(Constants.AUDIT_FLAG_BANK_LACK);
					} else {
						apply.setTransSeq(BigDecimal.valueOf(99));
						apply.setBankTransId(transId);
						apply.setApplyFlag(Constants.AUDIT_FLAG_LOCAL_LACK);
					}
				}
			}
			apply.setApplyUserSeq(BigDecimal.valueOf(userId));
			apply.setCreateUser(userId + "");
			apply.setUpdateUser(userId + "");
			apply.setCreateTime(new Date());
			apply.setUpdateTime(new Date());
			apply.setVersion(BigDecimal.valueOf(0));
			apply.setTransType(transaction.getTransType());
			apply.setBillType(adjustApplyForm.getBillType());
			apply.setCheckBillTransDetailId(transaction.getCheckBillTransDetailId());
			applyList.add(apply);
		}
		String applyNo = applyList.get(0).getApplyNo();

		upAdjustApplyMapper.insertBatch(applyList);
		upAdjustApplyMapper.updateBatch(param);
		return applyNo;
	}

    /**
     * 出金挂起
     * @param adjustApplyForm
     * @param userId
     * @param record
     * @return
     * @throws Exception
     */
    public String outApplyRecord(AdjustApplyForm adjustApplyForm, Long userId, String[] record, String channel) throws Exception {
        Map param = new HashMap();
        param.put("transIds", record);
        Integer applied = upAdjustApplyMapper.checkApplyed(param);
        if (null != applied && applied > 0){
            throw new BusinessException(ExceptionDefine.存在交易已发起过调账申请);
        }
        UpadjustApply apply;
        List<UpadjustApply> applyList = new ArrayList<>();
        List<Transaction> transactions = null;
        //包含分布式交易查询
        if(channel != null && Constants.UPLOAD_UNIONPAY_BH.contains(channel)){
            transactions = transactionMapper.getTransByTransId(param);
            transactions.addAll(transactionMapper.getTransByNewTransId(param));
            transactions.addAll(transactionMapper.getNewTXtransByTransId(param));
        } else {
            transactions = transactionMapper.getTransByTransId(param);
            if (transactions.size() == 0){
                transactions = transactionMapper.getTransByNewTransId(param);
                if(transactions.size() == 0){
                    //查询提现订单库
                    transactions = transactionMapper.getNewTXtransByTransId(param);
                }
            }
        }

        for (Transaction transaction : transactions) {
            apply = new UpadjustApply();
            apply.setApplyNo(getApplyNo());
            apply.setAuditStatus(Constants.AUDIT_FLAG_LOCAL_LACK);// 审核中
            apply.setApplyTime(new Date());
            apply.setReason(adjustApplyForm.getApplyReason());
            apply.setRemark(adjustApplyForm.getApplyRemark());
            String transId = transaction.getTransId();
            Long transSeq = transaction.getId().longValue();
            if(transId.length()>15){
                adjustApplyForm.setTransId(transId.replace("000000", "_"));
            }
            if (Constants.ADJUST_REASON_BANK_TRANS_COUNTER.equals(adjustApplyForm.getApplyReason())) {// 银行交易冲正调账申请
                apply.setApplyFlag(Constants.AUDIT_FLAG_LOCAL_LACK);
                apply.setBankTransId(transId);
                apply.setTransSeq(BigDecimal.valueOf(99));
            } else {
                if (Constants.ADJUST_REASON_OTHER.equals(adjustApplyForm.getApplyReason())) {// 调账原因：其他
                    if (adjustApplyForm.getCheckStatus().equals(Constants.CHECK_STATUS_LOCAL_LACK)) {// 银行有我方无
                        apply.setApplyFlag(Constants.AUDIT_FLAG_LOCAL_LACK);
                        apply.setTransSeq(BigDecimal.valueOf(99));
                        apply.setBankTransId(transId);

                    } else if (adjustApplyForm.getCheckStatus().equals(Constants.CHECK_STATUS_BANK_LACK)) {// 银行无我方有
                        apply.setApplyFlag(Constants.AUDIT_FLAG_BANK_LACK);
                        apply.setTransSeq(BigDecimal.valueOf(transSeq));
                    } else {// 金额不对
                        apply.setApplyFlag(Constants.AUDIT_FLAG_AMOUNT_ERROR);
                        apply.setTransSeq(BigDecimal.valueOf(transSeq));
                        apply.setBankTransId(transId);
                    }
                } else if (Constants.ADJUST_REASON_AMOUNT_ERROR.equals(adjustApplyForm.getApplyReason())) {// 调账原因：金额不对
                    apply.setTransSeq(BigDecimal.valueOf(transSeq));
                    apply.setApplyFlag(Constants.AUDIT_FLAG_AMOUNT_ERROR);
                    apply.setBankTransId(transId);
                } else {
                    if (null != transSeq) {
                        apply.setTransSeq(BigDecimal.valueOf(transSeq));
                        apply.setApplyFlag(Constants.AUDIT_FLAG_BANK_LACK);
                    } else {
                        apply.setTransSeq(BigDecimal.valueOf(99));
                        apply.setApplyFlag(Constants.AUDIT_FLAG_LOCAL_LACK);
                    }
                }
            }
            apply.setApplyUserSeq(BigDecimal.valueOf(userId));
            apply.setCreateUser(userId + "");
            apply.setUpdateUser(userId + "");
            apply.setCreateTime(new Date());
            apply.setUpdateTime(new Date());
            apply.setVersion(BigDecimal.valueOf(0));
            apply.setBankTransId(transId);
            apply.setTransType(transaction.getTransType());
            apply.setBillType(adjustApplyForm.getBillType());
            apply.setCheckBillTransDetailId(transaction.getCheckBillTransDetailId());
            applyList.add(apply);
        }
        String applyNo = applyList.get(0).getApplyNo();

        upAdjustApplyMapper.insertBatch(applyList);
        upAdjustApplyMapper.updateBatch(param);
        return applyNo;
    }

	/**
	 * 网联挂起
	 * @param adjustApplyForm
	 * @param userId
	 * @param record
	 * @return
	 * @throws Exception
	 */
	public String netsUnionApplyRecord(AdjustApplyForm adjustApplyForm, Long userId, String[] allid) throws Exception {
		Map params = new HashMap();
		params.put("transIds", allid);
		Integer applied = upAdjustApplyMapper.checkEpccApplyed(params);
		if (null != applied && applied > 0){
			throw new BusinessException(ExceptionDefine.存在交易已发起过调账申请);
		}
		UpadjustApply apply;
		List<UpadjustApply> applyList = new ArrayList<>();

		List<TransRef> transRefs = transRefMapper.getTransRefByDetail(params);
		for(TransRef transRef : transRefs){
			apply = new UpadjustApply();
			apply.setApplyNo(getApplyNo());
			apply.setAuditStatus(Constants.AUDIT_FLAG_LOCAL_LACK);// 审核中
			apply.setApplyTime(new Date());
			apply.setReason(adjustApplyForm.getApplyReason());
			apply.setRemark(adjustApplyForm.getApplyRemark());
			BigDecimal transRefId = transRef.getId();
			Long transSeq = transRef.getId().longValue();
			if (null != transSeq) {
				apply.setTransSeq(BigDecimal.valueOf(transSeq));
				apply.setApplyFlag(Constants.AUDIT_FLAG_BANK_LACK);
			}
			apply.setApplyUserSeq(BigDecimal.valueOf(userId));
			apply.setCreateUser(userId + "");
			apply.setUpdateUser(userId + "");
			apply.setCreateTime(new Date());
			apply.setUpdateTime(new Date());
			apply.setVersion(BigDecimal.valueOf(0));
			apply.setTransSeq(transRefId);
			apply.setBillType(adjustApplyForm.getBillType());
			apply.setCheckBillTransDetailId(transRef.getCheckBillTransDetailId());
			applyList.add(apply);
		}

		String applyNo = applyList.get(0).getApplyNo();

		upAdjustApplyMapper.insertBatch(applyList);
		upAdjustApplyMapper.updateBatch(params);
		return applyNo;
	}

	public String apply(AdjustApplyForm adjustApplyForm, Long userId) throws Exception {
		// 查询该交易是否存在正在审核的调账申请
		Integer applied = upAdjustApplyMapper.checkApplied(adjustApplyForm.getTransId());
		StringBuffer transId = new StringBuffer(adjustApplyForm.getTransId());
		applied = upAdjustApplyMapper.checkApplied(transId.toString());
		if (Constants.ADJUST_REASON_BANK_TRANS_COUNTER.equals(adjustApplyForm.getApplyReason())) {
			applied = upAdjustApplyMapper.checkApply(adjustApplyForm.getTransId());
		}
		if (applied != null && 0 != applied) {
			throw new BusinessException(ExceptionDefine.存在交易已发起过调账申请);
		}
		UpadjustApply apply = new UpadjustApply();
		String applyNo = getApplyNo();
		apply.setApplyNo(applyNo);
		apply.setAuditStatus(Constants.AUDIT_FLAG_LOCAL_LACK);// 审核中
		apply.setApplyTime(new Date());
		apply.setReason(adjustApplyForm.getApplyReason());
		apply.setRemark(adjustApplyForm.getApplyRemark());
		if(adjustApplyForm.getTransId().length()>15){
			adjustApplyForm.setTransId(adjustApplyForm.getTransId().replace("000000", "_"));
		}
		if (Constants.ADJUST_REASON_BANK_TRANS_COUNTER.equals(adjustApplyForm.getApplyReason())) {// 银行交易冲正调账申请
			apply.setApplyFlag(Constants.AUDIT_FLAG_LOCAL_LACK);
			apply.setBankTransId(adjustApplyForm.getTransId());		 
			apply.setTransSeq(BigDecimal.valueOf(99));
		} else {
			Long transSeq = transactionMapper.getIdByTransId(transId.toString());
			if (Constants.ADJUST_REASON_OTHER.equals(adjustApplyForm.getApplyReason())) {// 调账原因：其他
				if (adjustApplyForm.getCheckStatus().equals(Constants.CHECK_STATUS_LOCAL_LACK)) {// 银行有我方无
					apply.setApplyFlag(Constants.AUDIT_FLAG_LOCAL_LACK);
					apply.setTransSeq(BigDecimal.valueOf(99));
					apply.setBankTransId(adjustApplyForm.getTransId());

				} else if (adjustApplyForm.getCheckStatus().equals(Constants.CHECK_STATUS_BANK_LACK)) {// 银行无我方有
					apply.setApplyFlag(Constants.AUDIT_FLAG_BANK_LACK);
					apply.setTransSeq(BigDecimal.valueOf(transSeq));
				} else {// 金额不对
					apply.setApplyFlag(Constants.AUDIT_FLAG_AMOUNT_ERROR);
					apply.setTransSeq(BigDecimal.valueOf(transSeq));
					apply.setBankTransId(adjustApplyForm.getTransId());
				}
			} else if (Constants.ADJUST_REASON_AMOUNT_ERROR.equals(adjustApplyForm.getApplyReason())) {// 调账原因：金额不对
				apply.setTransSeq(BigDecimal.valueOf(transSeq));
				apply.setApplyFlag(Constants.AUDIT_FLAG_AMOUNT_ERROR);
				apply.setBankTransId(adjustApplyForm.getTransId());
			} else {
				if (null != transSeq) {
					apply.setTransSeq(BigDecimal.valueOf(transSeq));
					apply.setApplyFlag(Constants.AUDIT_FLAG_BANK_LACK);
				} else {
					apply.setTransSeq(BigDecimal.valueOf(99));
					apply.setBankTransId(adjustApplyForm.getTransId());
					apply.setApplyFlag(Constants.AUDIT_FLAG_LOCAL_LACK);
				}
			}
		}
		apply.setApplyUserSeq(BigDecimal.valueOf(userId));
		apply.setCreateUser(userId + "");
		apply.setUpdateUser(userId + "");
		apply.setCreateTime(new Date());
		apply.setUpdateTime(new Date());
		apply.setVersion(BigDecimal.valueOf(0));
		// 保存调账申请记录
		upAdjustApplyMapper.insertSelective(apply);
		/*// 提交审核（创建）
		AuditOperandType auditOperandType = submitApply(apply.getId(), userId + "", adjustApplyForm.getApplyRemark());
		// 初始化审核（提交）
		initAudit(auditOperandType, apply.getId(), apply.getReason(), userId);*/
		//跟新对账状态
		upAdjustApplyMapper.updateByTransId(adjustApplyForm.getTransId());
		return applyNo;
	}
	private String getApplyNo() {
		SimpleDateFormat sf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		StringBuffer timestamp = new StringBuffer(sf.format(new Date()));
		timestamp.append(String.valueOf((int) (Math.random() * 1000)));
		// 查询是否存在重复的apply_no
		UpadjustApply InfluenceNum = upAdjustApplyMapper.getByApplyNo(timestamp.toString());
		if (null != InfluenceNum) {
			getApplyNo();
		}
		return timestamp.toString();
	}

	public List<AuditOperation> submitTotleApply(List<Object> applyIdList, String userId, String remark) {
		Map<String, Object> map1 = new HashMap<String, Object>();
		map1.put("systemType", 1);
		map1.put("operandClass", "BILLAUDIT");
		map1.put("actionFlag", 1);
		AuditOperandType auditOperandType = auditOperandTypeMapper.getAuditOperandType(map1);
		// 根据审核操作对象类型查找审核规则
		Map<String, Object> map2 = new HashMap<String, Object>();
		map2.put("auditOperandTypeId", auditOperandType.getId());
		map2.put("valid", 1);
		AuditRule rule = auditRuleMapper.getAuditRule(map2);
		List<Map> applyAllList = new ArrayList<Map>();
		// 查询审核操作记录
		Map<String, Object> map3 = new HashMap<String, Object>();
		map3.put("auditOperandTypeId", auditOperandType.getId());
		map3.put("auditOperandId", applyIdList);
		return null;
	}

	public AuditOperandType submitApply(BigDecimal applyId, String userId, String remark) throws Exception {
		// 取得审核操作类型
		Map<String, Object> map1 = new HashMap<String, Object>();
		map1.put("systemType", 1);
		map1.put("operandClass", "BILLAUDIT");
		map1.put("actionFlag", 1);
		AuditOperandType auditOperandType = auditOperandTypeMapper.getAuditOperandType(map1);
		// 根据审核操作对象类型查找审核规则
		Map<String, Object> map2 = new HashMap<String, Object>();
		map2.put("auditOperandTypeId", auditOperandType.getId());
		map2.put("valid", 1);
		AuditRule rule = auditRuleMapper.getAuditRule(map2);
		// 查询审核操作记录
		Map<String, Object> map3 = new HashMap<String, Object>();
		map3.put("auditOperandTypeId", auditOperandType.getId());
		map3.put("auditOperandId", applyId);
		AuditOperation operation = auditOperationMapper.getAuditOperation(map3);
		if (operation == null) {// 创建审核操作记录
			operation = new AuditOperation();
			operation.setCreateUser(userId);// 操作人ID
			operation.setCreateTime(new Date());
			// 新建时，审核前、后状态均为-1
			operation.setPreviousStatus(BigDecimal.valueOf(-1)); // 前状态
			operation.setPostStatus(BigDecimal.valueOf(-1)); // 后状态
			operation.setAuditOperandId(applyId); // 审核对象ID
			operation.setAuditRuleId(rule.getId()); // 审核规则
			operation.setAuditGroupId(null); // 清空审核组
			operation.setUpdateUser(userId); // 审核操作人IDs
			operation.setUpdateTime(new Date());
			operation.setAttitude(remark);
			// 保存审核操作记录
			auditOperationMapper.insertSelective(operation);
		} else {// 已经有审核操作记录，则可能为重新提交审核
			operation.setPostStatus(BigDecimal.valueOf(-1)); // 后状态
			operation.setAuditOperandId(applyId); // 审核对象ID
			operation.setAuditRuleId(rule.getId()); // 审核规则
			operation.setPreviousStatus(operation.getPostStatus()); // 前状态
			operation.setPostStatus(BigDecimal.valueOf(-1)); // 后状态
			operation.setAuditGroupId(null); // 清空审核组
			operation.setUpdateUser(userId); // 审核操作人IDs
			operation.setUpdateTime(new Date());
			operation.setAttitude(remark);
			// 更新审核操作记录
			auditOperationMapper.updateByPrimaryKeySelective(operation);
		}
		// 保存历史操作记录
		createAuditHistory(operation);
		return auditOperandType;
	}

	private void createAuditHistory(AuditOperation operation) {
		AuditHistory history = new AuditHistory();
		try {
			PropertyUtils.copyProperties(history, operation);
		} catch (Exception e) {
			e.printStackTrace();
		}
		history.setCreateUser(operation.getUpdateUser());
		history.setCreateTime(new Date());
		history.setSequenceNo(BigDecimal.valueOf(0));
		history.setUpdateTime(new Date());
		auditHistoryMapper.insertSelective(history);
	}

	public BigDecimal initAudit(AuditOperandType opType, BigDecimal applyId, String reason, Long userId)
			throws BusinessException {
		// 查询审核操作记录
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("auditOperandTypeId", opType.getId());
		map.put("auditOperandId", applyId);
		AuditOperation operation = auditOperationMapper.getAuditOperation(map);
		if (operation == null) {
			// 没有审核记录，系统错误
			throw new BusinessException(ExceptionDefine.未查询到审核记录申请出错);
		}
		if (operation.getPostStatus().compareTo(BigDecimal.valueOf(99)) == 0) {
			// 已经终审
			throw new BusinessException(ExceptionDefine.终审已通过无需再审核);
		}
		// 根据审核操作对象类型查找审核规则
		Map<String, Object> map2 = new HashMap<String, Object>();
		map2.put("auditOperandTypeId", opType.getId());
		map2.put("valid", 1);
		AuditRule rule = auditRuleMapper.getAuditRule(map2);
		// 此处审核规则不应为空，返回错误信息
		if (rule == null) {
			throw new BusinessException(ExceptionDefine.审核规则不存在);
		}
		List<AuditStep> stepList = auditStepMapper.getAuditStep(rule.getId());
		// 获取该次审核后状态
		BigDecimal postStatus = getPostStatus(stepList, operation.getPostStatus());
		// 取得当前操作的审核组id
		BigDecimal auditGroupId = getAuditGroupId(stepList, postStatus);
		operation.setPreviousStatus(operation.getPostStatus()); // 前状态
		operation.setPostStatus(postStatus); // 后状态
		operation.setAuditGroupId(auditGroupId); // 当前操作审核组
		operation.setUpdateUser(String.valueOf(userId)); // 审核操作人ID
		operation.setUpdateTime(new Date());
		operation.setAttitude(reason);
		auditOperationMapper.updateByPrimaryKeySelective(operation);
		// 保存历史操作记录
		createAuditHistory(operation);

		return postStatus;
	}

	private BigDecimal getPostStatus(List<AuditStep> list, BigDecimal previousStatus) throws BusinessException {

		if (previousStatus.compareTo(BigDecimal.valueOf(-1)) == 0 && list.size() > 0) {
			// 如果为初始状态，下一状态为一级审核
			return BigDecimal.valueOf(Long.valueOf(list.get(0).getAuditLevel()));
		}
		// 循环遍历取出下一审核状态
		boolean flag = false;
		for (int i = 0; i < list.size(); i++) {
			if (flag) {
				return BigDecimal.valueOf(Long.valueOf(list.get(i).getAuditLevel()));
			}
			if (list.get(i).getAuditLevel().equals(previousStatus.toString())) {
				flag = true;
			}
		}
		if (!flag) {
			throw new BusinessException(ExceptionDefine.未找到对应审核步骤);
		}
		return BigDecimal.valueOf(99);
	}

	private BigDecimal getAuditGroupId(List<AuditStep> stepList, BigDecimal intPreStatus) {
		for (int i = 0; i < stepList.size(); i++) {
			if (stepList.get(i).getAuditLevel().equals(intPreStatus.toString())) {
				return stepList.get(i).getAuditGroupId();
			}
		}
		return null;
	}

}
