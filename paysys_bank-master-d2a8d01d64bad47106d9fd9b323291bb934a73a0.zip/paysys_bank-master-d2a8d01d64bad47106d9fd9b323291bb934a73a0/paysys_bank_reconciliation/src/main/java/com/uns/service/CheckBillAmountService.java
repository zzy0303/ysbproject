package com.uns.service;

import com.alibaba.dubbo.common.logger.Logger;
import com.alibaba.dubbo.common.logger.LoggerFactory;
import com.uns.channel.ChannelHandleMapping;
import com.uns.common.Constants;
import com.uns.dao.CheckBillAmountMapper;
import com.uns.dao.CheckBillMapper;
import com.uns.datasourceSwitch.DynamicDataSourceHolder;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.model.CheckBill;
import com.uns.util.ChannelConstants;
import com.uns.util.MapSources;
import com.uns.util.StringUtils;
import org.apache.poi.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class CheckBillAmountService {

	@Autowired
	private CheckBillMapper checkBillMapper;
	@Autowired
	private CheckBillAmountMapper cBillAmountMapper;

	protected final Logger log = LoggerFactory.getLogger(getClass());


	/**
	 * 定时任务自动获取银生宝金额总汇
	 * 
	 * @return
	 * @throws Exception
	 */
	public String checkBillAmount(String channel, String checkDate) throws Exception {
		checkDate = getExecuteTime();
		//初始化金额
		String amount = null;
		Map map = new HashMap<>();
		int status = chargeStatus(channel);
		if (status == 0) {
			map.put("channel", channel);
			map.put("dealDate", checkDate);
			cBillAmountMapper.deleterBySysTime(map);
		}
		if (status == 0 || status == 2) {
			Map<String, List<String>> setting = transSetting(channel);
			Map<String, Object> recordMap = null;
			CheckBill checkBill = new CheckBill();
			if (setting.containsKey("NEW_FUNC")) {
				if(channel.equals(ChannelConstants.CHANNEL_BOSH_KJ)  || channel.equals(ChannelConstants.CHANNEL_PINGAN_DK) 
					|| channel.equals(ChannelConstants.CHANNEL_SPDB_DK) || channel.equals(ChannelConstants.CHANNEL_YILIAN_KJ)){
					//执行老代扣   
					recordMap = getRecordMapOld(channel);
				}else{
					recordMap = getRecordMapNew(channel);
				}
				checkBill.setChannel(channel);
			  //执行出金
			} else if (Arrays.asList(DynamicConfigLoader.getByEnv("OUT_CHECK_BILL_CHANNEL").split(",")).contains(channel)){
				checkBill.setBillType(Constants.CHECK_BILL_1);
				recordMap = ChannelHandleMapping.handleInterface(channel).getLocalAmount(channel, checkDate);
			} else {
				recordMap = getRecordMapOld(channel);
			}
			checkBill.setChannel(channel);
			// 获取昨天日期
			checkBill.setCheckDate(new SimpleDateFormat("yyyy-MM-dd").parse(getExecuteTime()));
			// 判断是否获取到总金额
			if (recordMap.get("AMOUNT") != null) {
				amount = recordMap.get("AMOUNT").toString();
				//把字符串转变成为一个双精度数
				double dAmount = Double.parseDouble(amount);
				checkBill.setLocalAmount(dAmount);

			} else {
				checkBill.setLocalAmount(0.00);
				amount = "0";
			}
			checkBill.setCheckStatus(Constants.CHECK_STATUS_DEFAULT);
			checkBillMapper.insertSelective(checkBill);
		}
		return amount;
	}

    public Double checkBillAmountNetsUnion(String checkDate) throws Exception {
		//初始化金额
		checkDate = getExecuteTime();
		String amount;
		Double sumAmount = new Double(0);
		Map map = new HashMap<>();
		List<Map> checkStatus = chargeStatusEpcc();
		List<Map> checkStatusNew = new ArrayList<>();
		if(null != checkStatus && checkStatus.size() != 0){
			checkStatusNew.addAll(checkStatus);
			for(int i = 0; i<checkStatus.size();i++){
				Map status = checkStatus.get(i);
				if(status == null){
					continue;
				}
				String sta = status.get("CHECK_STATUS") == null ? "" : status.get("CHECK_STATUS").toString();
				if (sta.equals(Constants.FLAG_0) || sta.equals("")) {
					map.put("batchId", status.get("BATCH_ID"));
					map.put("dealDate", checkDate);
					cBillAmountMapper.deleterBySysTimeBatch(map);
				}else{
					checkStatusNew.remove(status);
				}
			}
		}else{
			CheckBill checkBill = getNullCheckBill();
			if(checkBill != null && Constants.CHECK_BILL_0.equals(checkBill.getCheckStatus())){
				checkBillMapper.delCheckBillById(checkBill.getId());
			}
		}
		List<Map<String, Object>> recordMap = null;
		CheckBill checkBill = new CheckBill();
		if (!checkStatusNew.isEmpty()){
			recordMap = getNetsUnionRecordMap(checkStatusNew);
		}
		checkBill.setChannel(Constants.UPLOAD_EPCC);
		checkBill.setCheckDate(new SimpleDateFormat("yyyy-MM-dd").parse(getExecuteTime()));
		if (null != recordMap && recordMap.size() != 0) {
			for (Map<String, Object> record : recordMap) {
				checkBill.setBatchId((String) record.get("BATCH_ID"));
				if ((amount = String.valueOf(((BigDecimal) record.get("AMOUNT")).doubleValue())) != null) {
					Double dAmount = Double.parseDouble(amount);
					sumAmount += dAmount;
					checkBill.setLocalAmount(dAmount);
				} else {
					checkBill.setLocalAmount(0.00);
				}
				checkBill.setBillType(Constants.CHECK_BILL_2);
				checkBill.setCheckStatus(Constants.CHECK_STATUS_DEFAULT);
				checkBillMapper.insertSelective(checkBill);
			}
		} else {
			if (checkStatus.isEmpty()){
				checkBill.setLocalAmount(0.00);
				checkBill.setBillType(Constants.CHECK_BILL_2);
				checkBill.setCheckStatus(Constants.CHECK_STATUS_DEFAULT);
				checkBillMapper.insertSelective(checkBill);
			}
		}
		return sumAmount;
	}

	public Map<String, Object> getRecordMapNew(String channel) throws Exception {
		Map<String, Object> recordMap = new HashMap<String, Object>();
		Map<String, Object> p = CreateSearchMap(channel, 0);
		p.put("dealDate", getExecuteTime());
		Map<String, Object> recordUnionpayMap = cBillAmountMapper.getChannelCountNew(p);
		recordMap.put("AMOUNT", Double.parseDouble(recordUnionpayMap.get("AMOUNT").toString()));
		recordMap.put("COUNTMUN", Integer.valueOf(recordUnionpayMap.get("COUNTNUM").toString()));

		return recordMap;
	}

	public List<Map<String, Object>> getNetsUnionRecordMap(List<Map> checkStatus) throws Exception {
		List<Map<String, Object>> recordMap;
		Map map = new HashMap();
		map.put("checkdate", getExecuteTime());
		map.put("list",checkStatus);
		recordMap = cBillAmountMapper.getNetsUnionAmount(map);
		return recordMap;
	}

	/**
	 * 获取相应的金额
	 * 
	 * @param channel
	 * @return
	 */
	public Map<String, Object> getRecordMapOld(String channel) throws Exception {
		Map<String, String> kjchannel = getKjChannelType();
		MapSources b2cMapSources = new MapSources();
		Map<String, Object> recordMap = new HashMap<String, Object>();
		Map<String, String> paramMap = new HashMap<String, String>();
		Map<String, Object> Map = new HashMap<String, Object>();
		if (Constants.DKCHANNEL.contains(channel)) {
			Map.put("channelType", getChannelType(channel, Constants.DKCHANNEL));
			Map.put("dealDate", getExecuteTime());
			// 查询实名认证
			Map<String, Object> dkAuthMap;
			// 邦付宝通道特殊处理
			if (Constants.UPLOAD_BFBPAY_DK.equals(channel)) {
				// 查询代扣交易
				recordMap = cBillAmountMapper.getAllDkByChannel(Map);
				dkAuthMap = cBillAmountMapper.getAllAuthDkByChannel(Map);
			} else {
				// 查询代扣交易
				recordMap = cBillAmountMapper.getDkByChannel(Map);
				dkAuthMap = cBillAmountMapper.getAuthDkByChannel(Map);
			}

			// 查询新代扣的数据
			Map<String, Object> dkNewMap = cBillAmountMapper.getNewDkByChannel(Map);
			recordMap.put("AMOUNT",
					Double.parseDouble(recordMap.get("AMOUNT").toString())
							+ Double.parseDouble(dkAuthMap.get("AMOUNT").toString())
							+ Double.parseDouble(dkNewMap.get("AMOUNT").toString()));
		}
		if (Constants.KJCHANNEL.contains(channel)) {
			paramMap.put("channel", kjchannel.get(channel));
			paramMap.put("dealDate", getExecuteTime());
			paramMap.put("actionType", Constants.UPLOAD_KJ_ACTIONTYPE);
			recordMap = cBillAmountMapper.getAllKjChannel(paramMap);
		}
		if (Constants.UPLOAD_UNIONPAY_B2C.contains(channel) && !channel.equals(Constants.UPLOAD_UNIONPAY)) {
			Map.put("channel", b2cMapSources.b2cMap().get(channel));
			Map.put("dealDate", getExecuteTime());
			Map.put("actionType", Constants.UPLOAD_B2C_ACTIONTYPE);
			recordMap = cBillAmountMapper.getB2cTrans(Map);
		}
		// 扫码交易
		if (Constants.UPLOAD_SM_CHANNEL.contains(channel)) {
			Map.put("channel", b2cMapSources.smMap().get(channel));
			Map.put("dealDate", getExecuteTime());
			recordMap = cBillAmountMapper.getSmTrans2(Map);
		}
		switch (channel) {
		case Constants.UPLOAD_UNIONPAY_WL:
			// 添加快捷支付的
			paramMap.put("channel", Constants.UPLOAD_UNIONPAY_WL);
			paramMap.put("dealDate", getExecuteTime());
			paramMap.put("actionType", Constants.UPLOAD_KJ_ACTIONTYPE);
			Map<String, Object> wlMap = cBillAmountMapper.getAllKjChannel(paramMap);
			recordMap.put("AMOUNT", Double.parseDouble(recordMap.get("AMOUNT").toString())
					+ Double.parseDouble(wlMap.get("AMOUNT").toString()));
			break;
		case Constants.UPLOAD_UNIONPAY:
			List<String> unionpayKj = Arrays.asList(Constants.UNIONPAYKJCHANNEL.split(","));
			recordMap.put("channel", unionpayKj);
			recordMap.put("dealDate", getExecuteTime());
			recordMap.put("actionType", Constants.UPLOAD_KJ_ACTIONTYPE);
			Map<String, Object> unionpayKjList = cBillAmountMapper.getUnionpayKjChannel(recordMap);
			recordMap.put("AMOUNT", Double.parseDouble(recordMap.get("AMOUNT").toString())
					+ Double.parseDouble(unionpayKjList.get("AMOUNT").toString()));
			break;
		case Constants.UPLOAD_CHINAPAY://银联全渠道
			List<String> chinaPay = Arrays.asList(Constants.CHINAPAYCHANNEL.split(","));
			recordMap.put("channel", chinaPay);
			recordMap.put("dealDate", getExecuteTime());
			recordMap.put("actionType", Constants.UPLOAD_KJ_ACTIONTYPE);
			Map<String, Object> chinaPayList = cBillAmountMapper.getChinaPayChannel(recordMap);
			recordMap.put("AMOUNT", Double.parseDouble(recordMap.get("AMOUNT").toString())
					+ Double.parseDouble(chinaPayList.get("AMOUNT").toString()));
			break;
		case Constants.UPLOAD_WS:
			paramMap.put("channel", Constants.UPLOAD_UNIONPAY_WL);
			paramMap.put("dealDate", getExecuteTime());
			paramMap.put("actionType", Constants.UPLOAD_KJ_ACTIONTYPE);
			Map<String, Object> localTransWs = cBillAmountMapper.getAllKjChannel(paramMap);
			recordMap.put("AMOUNT", Double.parseDouble(recordMap.get("AMOUNT").toString())
					+ Double.parseDouble(localTransWs.get("AMOUNT").toString()));
			break;
		case Constants.UPLOAD_CMBC_XM_B2C:
			paramMap.put("dealDate", getExecuteTime());
			paramMap.put("actionType", Constants.UPLOAD_B2C_ACTIONTYPE);
			recordMap = cBillAmountMapper.getcmbcAmount(paramMap);
			break;
		case Constants.UPLOAD_CNCB_B2C:
			paramMap.put("dealDate", getExecuteTime());
			paramMap.put("actionType", Constants.UPLOAD_B2C_ACTIONTYPE);
			paramMap.put("bankCodeList", Constants.UPLOAD_CNCB_B2C_CHANNEL);
			recordMap = cBillAmountMapper.getCncbB2cAmount(paramMap);
			break;
		case Constants.UPLOAD_BOC_B2C:
			paramMap.put("dealDate", getExecuteTime());
			paramMap.put("actionType", Constants.UPLOAD_B2C_ACTIONTYPE);
			recordMap = cBillAmountMapper.getBocB2cCreditAmount(paramMap);
			break;
		case Constants.UPLOAD_CMBC_B2C:
			paramMap.put("dealDate", getExecuteTime());
			paramMap.put("channel", Constants.channelcmbcB2cD);
			paramMap.put("actionType", Constants.UPLOAD_B2C_ACTIONTYPE);
			recordMap = cBillAmountMapper.getCmbcB2cAmount(paramMap);
			break;
		case Constants.UPLOAD_ICBC_B2B:
			paramMap.put("dealDate", getExecuteTime());
			paramMap.put("channel", Constants.UPLOAD_ICBC);
			recordMap = cBillAmountMapper.getB2BAmount(paramMap);
			break;
		case Constants.UPLOAD_YILIAN_KJ:
			Map.put("dealDate", getExecuteTime());
			Map.put("channel", Constants.UPLOAD_YILIAN_KJ_CHANNEL.split(","));
			Map.put("actionType", Constants.UPLOAD_KJ_ACTIONTYPE);
			recordMap = cBillAmountMapper.getkjAmount(Map);
			break;
		case Constants.UPLOAD_BOC_KJ:
			Map.put("dealDate", getExecuteTime());
			Map.put("channel", Constants.UPLOAD_BOC);
			Map.put("actionType", Constants.UPLOAD_KJ_ACTIONTYPE);
			recordMap = cBillAmountMapper.getBocKjAmount(Map);
			break;
		case Constants.UPLOAD_CEB_B2B:
			paramMap.put("dealDate", getExecuteTime());
			paramMap.put("channel", Constants.UPLOAD_CEB_KJ);
			recordMap = cBillAmountMapper.getB2BAmount(paramMap);
			break;
		case Constants.UPLOAD_CCB_B2B:
		    paramMap.put("dealDate", getExecuteTime());
		    paramMap.put("channel", Constants.UPLOAD_CCB_B2B);
		    recordMap = cBillAmountMapper.getB2BAmount(paramMap);
		    break;
		case Constants.UPLOAD_PINGAN_KJ:
		    Map.put("dealDate", getExecuteTime());
		    Map.put("channel", Constants.UPLOAD_PINGAN_D);
		    recordMap = cBillAmountMapper.getPinganKjAmount(Map);
		    break;
		case Constants.UPLOAD_UNIONPAY_WG:
			List<String> unionpayWgChannel = Arrays.asList(DynamicConfigLoader.getByEnv("UNIONPAY_WG_CHANNEL"));
			Map.put("dealDate", getExecuteTime());
			Map.put("channel", unionpayWgChannel);
			Map.put("actionType", DynamicConfigLoader.getByEnv("UNIONPAY_WG_ACTIONTYPE"));
			recordMap = cBillAmountMapper.getUnionpayWgAmount(Map);
			break;
		case Constants.UPLOAD_UNIONPAY_AT_SM:
			Map.put("dealDate", getExecuteTime());
			Map.put("actionType", Constants.UPLOAD_UNIONPAY_AT_SM_ACTIONTYPE);
			recordMap = cBillAmountMapper.getUnionpayAtSmAmount(Map);
			break;  

	}
		return recordMap;
	}

	private Map<String, Object> CreateSearchMap(String channelName, int id) throws Exception {
		String actionStr = DynamicConfigLoader
				.getByEnv(String.format("UNSPAY_TRANS_%s_ACTION_LIST", channelName.toUpperCase()));
		String channelStr = DynamicConfigLoader
				.getByEnv(String.format("UNSPAY_TRANS_%s_CHANNEL_LIST", channelName.toUpperCase()));

		if (null == actionStr && null == channelStr) {
			return null;
		}

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("id", id);
		params.put("actionTypes", null);
		params.put("channelTypes", null);

		if (null != actionStr) {
			List<String> actionTypes = getSplit2List(actionStr, "\\|");
			params.put("actionTypes", actionTypes);
		}

		if (null != channelStr) {
			List<String> channelTypes = getSplit2List(channelStr, "\\|");
			params.put("channelTypes", channelTypes);
		}

		return params;
	}

	protected Map<String, List<String>> transSetting(String channel) throws Exception{
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		String transfunctionName = String.format("UNSPAY_TRANS_%s_NEW_FUNC", channel);

		String actionName = String.format("UNSPAY_TRANS_%s_ACTION_LIST", channel);
		String channelName = String.format("UNSPAY_TRANS_%s_CHANNEL_LIST", channel);
		//执行出金
		String outChannel = String.format("UNSPAY_TRANS_%s_OUT_FUNC", channel); 
		String transfunctionStr = DynamicConfigLoader.getByEnv(transfunctionName);

		String actionStr = DynamicConfigLoader.getByEnv(actionName);
		String channelStr = DynamicConfigLoader.getByEnv(channelName);
		String outChannelStr = DynamicConfigLoader.getByEnv(outChannel);
		if (null != transfunctionStr) {
			map.put("NEW_FUNC", StringUtils.getSplit2List(transfunctionStr, "\\|"));
		}
		if (null != actionStr) {
			map.put("ACTION_LIST", StringUtils.getSplit2List(actionStr, "\\|"));
		}

		if (null != channelStr) {
			map.put("CHANNEL_LIST", StringUtils.getSplit2List(channelStr, "\\|"));
		}
		if (null != outChannelStr) {
			map.put("OUT_FUNC", StringUtils.getSplit2List(outChannelStr, "\\|"));
		}
		log.info(String.format("channel:%s setting ok", channel));
		return map;
	}

	/**
	 * 获取代扣通道类型
	 * 
	 * @param channel
	 * @param str
	 * @return
	 */
	public List<String> getChannelType(String channel, String str) throws Exception{
		List<String> channelType = Arrays.asList(str.split(","));
		List<String> channelList = new ArrayList<String>();
		String channels;
		for (int i = 0; i < channelType.size(); i++) {
			if (channelType.get(i).contains(channel)) {
				channels = channelType.get(i);
				if (channels.contains(Constants.dk)) {
					channels = channelType.get(i).substring(0, channel.length() - 3);
				}
				channelList.add(channels);
			}
		}
		if (channel.equals(Constants.UPLOAD_UNIONPAY_XM_DK)) {
			channelList = Arrays.asList(Constants.UPLOAD_UNIONPAY_XM_DK_CHANNEL.split(","));
		}
		if (channel.equals(Constants.UPLOAD_PINGAN_DK)) {
			channelList = Arrays.asList(Constants.UPLOAD_PINGAN_CHANEL.split(","));
		}
		if (channel.equals(Constants.UPLOAD_SPDB_DK)) {
			channelList = Arrays.asList(Constants.UPLOAD_SPDB_CHANNEL.split(","));
		}
		if (channel.equals(Constants.UPLOAD_UNIONPAY_TD)) {
			channelList.remove(Constants.UPLOAD_UNIONPAY_TD2);
		}
		if (channel.equals(Constants.UPLOAD_UNIONPAY)) {
			channelList = Arrays.asList(Constants.UNIONPAYCHANNEL.split(","));
		}
		if (channel.equals(Constants.UPLOAD_CHINAPAY)) {
			channelList = Arrays.asList(Constants.CHINACHANNEL.split(","));
		}
		if (channel.equals(Constants.UPLOAD_EGB)) {
			channelList.clear();
			channelList = Arrays.asList(Constants.channelEgb_3.split(","));
		}
		if (channel.equals(Constants.UPLOAD_CHANNEL_B)) {
			channelList.clear();
			channelList = Arrays.asList(Constants.channelEgbProb_3.split(","));
		}
		if (channel.equals(Constants.UPLOAD_CHANNEL_C)) {
			channelList.clear();
			channelList.add(channel);
		}
		if (channel.equals(Constants.UPLOAD_YILIAN_DK)) {
			channelList.clear();
			channelList = Arrays.asList(Constants.UPLOAD_YILIAN_DK_CHANEL.split(","));
		}
		return channelList;
	}

	/**
	 * 获取快捷通道类型
	 * 
	 * @return
	 */
	public Map<String, String> getKjChannelType() throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		map.put(Constants.UPLOAD_CEB_KJ_D, Constants.UPLOAD_CEB_KJ_D_CHANNEL);
		map.put(Constants.UPLOAD_SPDB_KJ, Constants.UPLOAD_SPDB_KJ_CHANNEL);
		map.put(Constants.UPLOAD_HXB_KJ, Constants.UPLOAD_HXB_KJ_CHANNEL);
		map.put(Constants.UPLOAD_CMBC_XM_KJ, Constants.UPLOAD_CMBC_XM_KJ_CHANNEL);
		map.put(Constants.channelBoshKj, Constants.UPLOAD_BOSH_KJ_CHANNEL);
		map.put(Constants.UPLOAD_CCB_CHANNEL, Constants.UPLOAD_CCB_KJ);

		return map;
	}

	/**
	 * 判断生成的数据是否存在对账
	 * 
	 * @param channel
	 * @return
	 */
	public int chargeStatus(String channel) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		map.put("checkDate", getExecuteTime());
		map.put("channel", channel);
		Integer checkStatus = cBillAmountMapper.getBychannel(map);
		if (null == checkStatus) {
			checkStatus = 2;
		} else if (checkStatus > 0) {
			checkStatus = 1;
		}
		return checkStatus;
	}

	/**
	 * 判断生成的数据是否存在对账
	 * @return
	 */
	public List<Map> chargeStatusEpcc() throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		map.put("checkDate", getExecuteTime());
		List<Map> checkStatus = cBillAmountMapper.getByEpccChannel(map);
		return checkStatus;
	}

	public CheckBill getNullCheckBill() throws Exception {
		CheckBill checkBill = checkBillMapper.getNullCheckBill(getExecuteTime());
		return checkBill;
	}

	public List<String> getSplit2List(String str, String regex) throws Exception {
		List<String> list = new ArrayList<String>();
		String[] strs = str.split(regex);
		for (String item : strs) {
			list.add(item);
		}
		return list;
	}

	/**
	 * 获取生成记录日期
	 * 
	 * @return
	 */
	private String getExecuteTime() throws Exception {
		if (DynamicConfigLoader.getByEnv("UPLOAD_EXECUTE_TIME").equals("sysdate")) {
			return StringUtils.getSysDate();
		} else {
			return DynamicConfigLoader.getByEnv("UPLOAD_EXECUTE_TIME");
		}
	}
	
	/**
	 * 获取出金交易金额
	 * @param channel
	 * @return
	 */
	public Map<String, Object> getOutAmount(String channel) throws Exception{
		//TODO 获取出金交易金额完善异常处理等
		Map<String, Object> map = new HashMap<>();
		Map<String, Object> recordMap = new HashMap<>();
		Map<String, Object> newDfMap = new HashMap<>();
		Map<String, Object> newTXMap = new HashMap<>();
		if(Constants.OUT_CHECK_BILL_CHANNEL.contains(channel)){
			map.put("channel", channel);
			map.put("dealDate", getExecuteTime());
			if(Constants.UPLOAD_HFQD.equals(channel)){  //青岛银联
				recordMap = cBillAmountMapper.getOutHfqdNewDfAmount(map);
				newDfMap = cBillAmountMapper.getOutHfqdAmount(map);
				recordMap.put("AMOUNT", Double.parseDouble(recordMap.get("AMOUNT").toString())
							+ Double.parseDouble(newDfMap.get("AMOUNT").toString()));
			}else{
				recordMap = cBillAmountMapper.getOutAmount(map);
				newDfMap = cBillAmountMapper.getOutNewDfAmount(map);
				//获取新提现的金额
			        newTXMap = cBillAmountMapper.getOutNewTXAmount(map);

				recordMap.put("AMOUNT", Double.parseDouble(recordMap.get("AMOUNT").toString())
						+ Double.parseDouble(newDfMap.get("AMOUNT").toString())
						+ Double.parseDouble(newTXMap.get("AMOUNT").toString()));
			}
		}
		return recordMap;
	}
	
}
