package com.uns.dao;

import com.uns.model.EpccDcTransRef;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface EpccDcTransRefMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(EpccDcTransRef record);

    int insertSelective(EpccDcTransRef record);

    EpccDcTransRef selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(EpccDcTransRef record);

    int updateByPrimaryKey(EpccDcTransRef record);

    List<EpccDcTransRef> getNetsUnionCheckTrans(Map paramMap);

    String getNetsUnionCheckTransCount(String checkdate);
}