package com.uns.web.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.model.UserInfo;
import com.uns.service.AdjustApplyService;
import com.uns.service.BankTransService;
import com.uns.util.StringUtils;
import com.uns.web.form.AdjustApplyForm;

@Controller
@RequestMapping(value = "/adjustApply.htm")
public class AdjustApplyController extends BaseController {
	@Autowired
	private AdjustApplyService adjustApplyService;
	@Autowired
	private BankTransService bankTransService;

	@RequestMapping(params = "method=adjustApplyList")
	@FormToken(save = true)
	public String adjustApplyList(HttpServletRequest request, AdjustApplyForm adjustApplyForm)
			throws BusinessException {
		// 调账申请列表
		List<Object> adjustApplyList = adjustApplyService.getAdjustApplyList(adjustApplyForm);
		request.setAttribute("adList", adjustApplyList);
		request.setAttribute("adjustApplyForm", adjustApplyForm);
		return "adjust/adjustApplyList";
	}

	@RequestMapping(params = "method=toApply")
	@FormToken(save = true)
	public String toApply(HttpServletRequest request, AdjustApplyForm adjustApplyForm) throws BusinessException {
		// 跳转调账申请页面
		String[] localTransId = request.getParameter("localTransId").split(",");
		String[] bankTransId = request.getParameter("bankTransId").split(",");
		String checkStatus = request.getParameter("checkStatus");
		Map<String, Object> transDetail = new HashMap<String, Object>();
		Map<String, Object> batchDetail = null;
		if (Constants.CHECK_STATUS_LOCAL_LACK.equals(checkStatus) && localTransId.length == 0
				&& bankTransId.length > 0) {// 银行有我方无时，交易数据取银行数据
			if (bankTransId.length == 1)// 单笔
            {
                transDetail = bankTransService.getApplyDetail(bankTransId[0]);
            } else {// 批量
				batchDetail = bankTransService.getTotalBankInfo(bankTransId);
				batchDetail.put("idList", request.getParameter("bankTransId"));
			}
		} else {// 取银生宝数据
			if (localTransId.length == 1) {// 单笔
				transDetail = adjustApplyService.getApplyDetail(localTransId[0]);
			} else {// 批量
				batchDetail = bankTransService.getTotalLocalInfo(localTransId);
				batchDetail.put("idList", request.getParameter("localTransId"));
			}
		}
		request.setAttribute("detail", transDetail);
		request.setAttribute("batchDetail", batchDetail);
		request.setAttribute("checkStatus", checkStatus);
		return "adjust/applyDetail";
	}

	@RequestMapping(params = "method=apply")
	@FormToken(save = true)
	public String apply(HttpServletRequest request, AdjustApplyForm adjustApplyForm) throws Exception {
		// 提交调账申请
		UserInfo user = (UserInfo) (request.getSession().getAttribute(Constants.SESSION_KEY_USER));
		String msg = null;
		try {
			String[] allId = adjustApplyForm.getAllRecord().split(",");
			if (StringUtils.isEmpty(adjustApplyForm.getApplyRemark())) {
				throw new BusinessException(ExceptionDefine.调账备注为必输);
			}
			if (!StringUtils.isEmpty(adjustApplyForm.getAllRecord())) {
				// 批量调账
				adjustApplyService.applyRecord(adjustApplyForm, user.getId(), allId);
				msg = "批量调账申请成功,申请条数为：" + allId.length;
			} else {
				String applyNo = adjustApplyService.applyRecord(adjustApplyForm, user.getId(), allId);
				msg = "调账申请成功，申请编号：" + applyNo;
			}
			/*if (!StringUtils.isEmpty(adjustApplyForm.getAllRecord())) {
				// 批量调账
				String[] allId = adjustApplyForm.getAllRecord().split(",");
				List<String> applyNoList = adjustApplyService.allApply(adjustApplyForm, user.getId(), allId);
				msg = "批量调账申请成功,申请条数为：" + applyNoList.size();
			} else {
				String applyNo = adjustApplyService.apply(adjustApplyForm, user.getId());
				msg = "调账申请成功，申请编号：" + applyNo;
			}*/
			request.setAttribute("msg", msg);
		} catch (BusinessException be) {
			ApplicationContext ctx = WebApplicationContextUtils
					.getRequiredWebApplicationContext(request.getSession().getServletContext());
			MessageSource messageSource = (MessageSource) ctx.getBean("messageSource");
			request.setAttribute("errMsg", be.getErrMessage(messageSource));
		} catch (Exception e) {
			request.setAttribute("errMsg", "申请出错！");
			e.printStackTrace();
		}
		request.setAttribute("title", "调账申请详情");
		return "common/message";
	}

	/**
	 * 交易挂起
	 * @param request
	 * @param adjustApplyForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=hungup")
	@FormToken(save = true)
	public String hungup(HttpServletRequest request, AdjustApplyForm adjustApplyForm) throws Exception {
		UserInfo user = (UserInfo) (request.getSession().getAttribute(Constants.SESSION_KEY_USER));
		String checkStatus = request.getParameter("checkStatus");
		adjustApplyForm.setCheckStatus(checkStatus);
		adjustApplyForm.setApplyReason(Constants.ADJUST_REASON_TRANS_HANGUP);
		adjustApplyForm.setApplyRemark(Constants.ADJUST_REASON_TRANS_HANGUP);
		//入金标识
		adjustApplyForm.setBillType(Constants.CHECK_BILL_0);
		String[] allid = request.getParameter("localTransId").split(",");
		String msg = null;
		try {
			if (1 < allid.length){
				adjustApplyService.applyRecord(adjustApplyForm, user.getId(), allid);
				msg = "挂起交易申请成功,申请条数为：" + allid.length;
			} else {
				String applyNo = adjustApplyService.applyRecord(adjustApplyForm, user.getId(), allid);
				msg = "挂起交易申请成功，申请编号：" + applyNo;
			}
			request.setAttribute("msg", msg);
		} catch (BusinessException be) {
			ApplicationContext ctx = WebApplicationContextUtils
					.getRequiredWebApplicationContext(request.getSession().getServletContext());
			MessageSource messageSource = (MessageSource) ctx.getBean("messageSource");
			request.setAttribute("errMsg", be.getErrMessage(messageSource));
		} catch (Exception e) {
			request.setAttribute("errMsg", "申请出错！");
			e.printStackTrace();
		}
		request.setAttribute("title", "挂起申请详情");
		return "common/message";
	}


    /**
     * 出金交易挂起
     * @param request
     * @param adjustApplyForm
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=outHungup")
    @FormToken(save = true)
    public String outHungup(HttpServletRequest request, AdjustApplyForm adjustApplyForm) throws Exception {
        UserInfo user = (UserInfo) (request.getSession().getAttribute(Constants.SESSION_KEY_USER));
        String checkStatus = request.getParameter("checkStatus");
        adjustApplyForm.setCheckStatus(checkStatus);
        adjustApplyForm.setApplyReason(Constants.ADJUST_REASON_TRANS_HANGUP);
        adjustApplyForm.setApplyRemark(Constants.ADJUST_REASON_TRANS_HANGUP);
        //出金标识
        adjustApplyForm.setBillType(Constants.CHECK_BILL_1);
        String[] allid = request.getParameter("localTransId").split(",");
        String channel = request.getParameter("channel");
        String msg = null;
        try {
            if (1 < allid.length){
                adjustApplyService.outApplyRecord(adjustApplyForm, user.getId(), allid, channel);
                msg = "挂起交易申请成功,申请条数为：" + allid.length;
            } else {
                String applyNo = adjustApplyService.outApplyRecord(adjustApplyForm, user.getId(), allid, channel);
                msg = "挂起交易申请成功，申请编号：" + applyNo;
            }
            request.setAttribute("msg", msg);
        } catch (BusinessException be) {
            ApplicationContext ctx = WebApplicationContextUtils
                    .getRequiredWebApplicationContext(request.getSession().getServletContext());
            MessageSource messageSource = (MessageSource) ctx.getBean("messageSource");
            request.setAttribute("errMsg", be.getErrMessage(messageSource));
        } catch (Exception e) {
            request.setAttribute("errMsg", "申请出错！");
            e.printStackTrace();
        }
        request.setAttribute("title", "挂起申请详情");
        return "common/message";
    }

	/**
	 * 网联交易挂起
	 * @param request
	 * @param adjustApplyForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=netsUnionHungup")
	@FormToken(save = true)
	public String netsUnionHungup(HttpServletRequest request, AdjustApplyForm adjustApplyForm) throws Exception {
		UserInfo user = (UserInfo) (request.getSession().getAttribute(Constants.SESSION_KEY_USER));
		adjustApplyForm.setApplyReason(Constants.ADJUST_REASON_TRANS_HANGUP);
		adjustApplyForm.setApplyRemark(Constants.ADJUST_REASON_TRANS_HANGUP);
		//网联标识
		adjustApplyForm.setBillType(Constants.CHECK_BILL_2);
		String[] allid = request.getParameter("localTransId").split(",");
		String msg = null;
		try {
			if (1 < allid.length){
				adjustApplyService.netsUnionApplyRecord(adjustApplyForm, user.getId(), allid);
				msg = "挂起交易申请成功,申请条数为：" + allid.length;
			} else {
				String applyNo = adjustApplyService.netsUnionApplyRecord(adjustApplyForm, user.getId(), allid);
				msg = "挂起交易申请成功，申请编号：" + applyNo;
			}
			request.setAttribute("msg", msg);
		} catch (BusinessException be) {
			ApplicationContext ctx = WebApplicationContextUtils
					.getRequiredWebApplicationContext(request.getSession().getServletContext());
			MessageSource messageSource = (MessageSource) ctx.getBean("messageSource");
			request.setAttribute("errMsg", be.getErrMessage(messageSource));
		} catch (Exception e) {
			request.setAttribute("errMsg", "申请出错！");
			e.printStackTrace();
		}
		request.setAttribute("title", "挂起申请详情");
		return "common/message";
	}
}
