package com.uns.model;

import java.math.BigDecimal;
import java.util.Date;

public class TransDetail {
	private String checkDate;
	private String transDate;
	private String channel;
	private String bankName;
	private String actionName;
	private String localTransId;
	private String accountName;
	private BigDecimal localAmount;
	private String bankTransId;
	private BigDecimal bankAmount;
	private String fileName;
	private String checkTransStatus;
	private String batchId;
	private String bankBusiType;
	private String bankBusiStatus;
	private String payOrgIdSeq;
	private String destOrgIdSeq;

	public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	public String getBankBusiType() {
		return bankBusiType;
	}

	public void setBankBusiType(String bankBusiType) {
		this.bankBusiType = bankBusiType;
	}

	public String getBankBusiStatus() {
		return bankBusiStatus;
	}

	public void setBankBusiStatus(String bankBusiStatus) {
		this.bankBusiStatus = bankBusiStatus;
	}

	public String getPayOrgIdSeq() {
		return payOrgIdSeq;
	}

	public void setPayOrgIdSeq(String payOrgIdSeq) {
		this.payOrgIdSeq = payOrgIdSeq;
	}

	public String getDestOrgIdSeq() {
		return destOrgIdSeq;
	}

	public void setDestOrgIdSeq(String destOrgIdSeq) {
		this.destOrgIdSeq = destOrgIdSeq;
	}

	public String getCheckDate() {
		return checkDate;
	}

	public void setCheckDate(String checkDate) {
		this.checkDate = checkDate;
	}

	public String getTransDate() {
		return transDate;
	}

	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getActionName() {
		return actionName;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	public String getLocalTransId() {
		return localTransId;
	}

	public void setLocalTransId(String localTransId) {
		this.localTransId = localTransId;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public BigDecimal getLocalAmount() {
		return localAmount;
	}

	public void setLocalAmount(BigDecimal localAmount) {
		this.localAmount = localAmount;
	}

	public String getBankTransId() {
		return bankTransId;
	}

	public void setBankTransId(String bankTransId) {
		this.bankTransId = bankTransId;
	}

	public BigDecimal getBankAmount() {
		return bankAmount;
	}

	public void setBankAmount(BigDecimal bankAmount) {
		this.bankAmount = bankAmount;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getCheckTransStatus() {
		return checkTransStatus;
	}

	public void setCheckTransStatus(String checkTransStatus) {
		this.checkTransStatus = checkTransStatus;
	}

}
