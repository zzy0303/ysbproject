package com.uns.web.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.servlet.ModelAndView;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.model.Role;
import com.uns.model.UserInfo;
import com.uns.service.RoleService;
import com.uns.service.SysFunctionService;
import com.uns.service.UserInfoService;
import com.uns.util.Md5Encrypt;

@Controller
@RequestMapping(value = "/main.htm")
public class LoginController extends BaseController {

	@Autowired
	private UserInfoService userInfoService;

	@Autowired
	private RoleService roleService;

	@Autowired
	private SysFunctionService sysFunctionService;

	@RequestMapping(params = "method=login")
	public ModelAndView login(HttpServletRequest request, HttpServletResponse response, String username,
			String password, String verycode) throws Exception {
		try {
			// 判断验证码
			if (StringUtils.isEmpty(verycode)) {
				throw new BusinessException(ExceptionDefine.验证码错);
			}
			if (!verycode.equals(request.getSession().getAttribute(Constants.SESSION_VERIFY_CODE))) {
				throw new BusinessException(ExceptionDefine.验证码错);
			}

			// 判断用户是否存在
			if (StringUtils.isEmpty(username)) {
				throw new BusinessException(ExceptionDefine.字段不允许为空, new String[] { "用户名" });
			}
			if (StringUtils.isEmpty(password)) {
				throw new BusinessException(ExceptionDefine.字段不允许为空, new String[] { "密码" });
			}
			UserInfo ui = (UserInfo) userInfoService.selectUserInfoByName(username.trim());

			if (ui == null) {
				throw new BusinessException(ExceptionDefine.用户名不存在);
			} else {// 用户存在
				String md5passwd = Md5Encrypt.md5(password.trim());
				if (!ui.getPassword().equals(md5passwd)) {// 密码错误
					Integer attemptTimes = ui.getAttemptTimes() == null ? 0 : ui.getAttemptTimes();
					if (attemptTimes > 5) {// 密码错误超过5次，锁定用户
						ui.setStatus(4);
					} else {// 未超过5次，增加错误次数
						ui.setAttemptTimes(attemptTimes + 1);
					}
					userInfoService.updateByPrimaryKey(ui);
					throw new BusinessException(ExceptionDefine.密码错);
				} else {// 密码正确，校验用户状态
					if (ui.getStatus() != 3) {
                        throw new BusinessException(ExceptionDefine.密码错误次数过多用户被冻锁定);
                    }
				}
			}

			// 查询用户的角色
			Long roleId = ui.getRoleId() == null ? 0 : ui.getRoleId();
			Role role = roleService.selectByPrimaryKey(roleId);

			if (null != role && !role.getStatus().equals("3")) {
				throw new BusinessException(ExceptionDefine.用户所属角色未通过审核);
			}

			// 用户登录成功
			/*
			 * Map funcMap = sysFunctionService.getUserMenu(role.getId());
			 * request.getSession().setAttribute("funcMap", funcMap);
			 */
			request.getSession().setAttribute(Constants.SESSION_KEY_USER, ui);
			request.getRequestDispatcher("/main.htm?method=home").forward(request, response);

		} catch (BusinessException ex) {
			Map<String, String> model = new HashMap<String, String>();
			ApplicationContext ctx = WebApplicationContextUtils
					.getRequiredWebApplicationContext(request.getSession().getServletContext());
			MessageSource messageSource = (MessageSource) ctx.getBean("messageSource");
			BusinessException e = (BusinessException) ex;
			model.put(Constants.ERROR_MESSAGE, e.getErrMessage(messageSource));
			return new ModelAndView("redirect:/", model);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("更新登陆时间出现异常" + e.getMessage());
		}
		return null;
	}

	/**
	 * 跳转到主界面
	 * 
	 * @return
	 */
	@RequestMapping(params = "method=home")
	public String home() {
		return "/home";
	}

	/**
	 * 跳转到主界面
	 * 
	 * @return
	 */
	@RequestMapping(params = "method=logout")
	public String logout(HttpServletRequest request) {
		request.getSession().invalidate();
		return "redirect:/";
	}

}
