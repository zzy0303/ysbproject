package com.uns.model;

import java.math.BigDecimal;
import java.util.Date;

public class BankInfo {
	private BigDecimal id;

	private String bankId;

	private String bankName;

	private String bankDesc;

	private String bankAddress;

	private String netBankUrl;

	private String validFlag;

	private String remark;

	private BigDecimal version;

	private String createUser;

	private Date createTime;

	private String updateUser;

	private Date updateTime;

	private String bankCode;

	private String telBankUrl;

	private String telBankNo;

	private String mobileBankUrl;

	private BigDecimal supported;

	private BigDecimal exceptional;

	private BigDecimal bankGroup;

	private Short pri;

	private String linkCode;

	private String drawBank;

	private String settlementTime;

	private String cardType;

	public BigDecimal getId() {
		return id;
	}

	public void setId(BigDecimal id) {
		this.id = id;
	}

	public String getBankId() {
		return bankId;
	}

	public void setBankId(String bankId) {
		this.bankId = bankId == null ? null : bankId.trim();
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName == null ? null : bankName.trim();
	}

	public String getBankDesc() {
		return bankDesc;
	}

	public void setBankDesc(String bankDesc) {
		this.bankDesc = bankDesc == null ? null : bankDesc.trim();
	}

	public String getBankAddress() {
		return bankAddress;
	}

	public void setBankAddress(String bankAddress) {
		this.bankAddress = bankAddress == null ? null : bankAddress.trim();
	}

	public String getNetBankUrl() {
		return netBankUrl;
	}

	public void setNetBankUrl(String netBankUrl) {
		this.netBankUrl = netBankUrl == null ? null : netBankUrl.trim();
	}

	public String getValidFlag() {
		return validFlag;
	}

	public void setValidFlag(String validFlag) {
		this.validFlag = validFlag == null ? null : validFlag.trim();
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark == null ? null : remark.trim();
	}

	public BigDecimal getVersion() {
		return version;
	}

	public void setVersion(BigDecimal version) {
		this.version = version;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser == null ? null : createUser.trim();
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser == null ? null : updateUser.trim();
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode == null ? null : bankCode.trim();
	}

	public String getTelBankUrl() {
		return telBankUrl;
	}

	public void setTelBankUrl(String telBankUrl) {
		this.telBankUrl = telBankUrl == null ? null : telBankUrl.trim();
	}

	public String getTelBankNo() {
		return telBankNo;
	}

	public void setTelBankNo(String telBankNo) {
		this.telBankNo = telBankNo == null ? null : telBankNo.trim();
	}

	public String getMobileBankUrl() {
		return mobileBankUrl;
	}

	public void setMobileBankUrl(String mobileBankUrl) {
		this.mobileBankUrl = mobileBankUrl == null ? null : mobileBankUrl.trim();
	}

	public BigDecimal getSupported() {
		return supported;
	}

	public void setSupported(BigDecimal supported) {
		this.supported = supported;
	}

	public BigDecimal getExceptional() {
		return exceptional;
	}

	public void setExceptional(BigDecimal exceptional) {
		this.exceptional = exceptional;
	}

	public BigDecimal getBankGroup() {
		return bankGroup;
	}

	public void setBankGroup(BigDecimal bankGroup) {
		this.bankGroup = bankGroup;
	}

	public Short getPri() {
		return pri;
	}

	public void setPri(Short pri) {
		this.pri = pri;
	}

	public String getLinkCode() {
		return linkCode;
	}

	public void setLinkCode(String linkCode) {
		this.linkCode = linkCode == null ? null : linkCode.trim();
	}

	public String getDrawBank() {
		return drawBank;
	}

	public void setDrawBank(String drawBank) {
		this.drawBank = drawBank == null ? null : drawBank.trim();
	}

	public String getSettlementTime() {
		return settlementTime;
	}

	public void setSettlementTime(String settlementTime) {
		this.settlementTime = settlementTime == null ? null : settlementTime.trim();
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType == null ? null : cardType.trim();
	}
}