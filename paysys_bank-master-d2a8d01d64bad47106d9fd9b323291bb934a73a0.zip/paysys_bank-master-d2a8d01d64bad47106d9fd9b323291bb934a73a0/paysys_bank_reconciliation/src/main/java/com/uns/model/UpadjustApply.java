package com.uns.model;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.Date;

public class UpadjustApply {
	private BigDecimal id;

	private String applyNo;

	private BigDecimal transSeq;

	private BigDecimal applyUserSeq;

	private Date applyTime;

	private String auditStatus;

	private String reason;

	private Date createTime;

	private BigDecimal version;

	private String createUser;

	private String updateUser;

	private Date updateTime;

	private String remark;

	private String bankTransId;

	private String applyFlag;

	private Integer transType;

	private BigDecimal checkBillTransDetailId;

	private String billType;

	public String getBillType() {
		return billType;
	}

	public void setBillType(String billType) {
		this.billType = billType == null ? "0" : billType;
	}

	public BigDecimal getCheckBillTransDetailId() {
		return checkBillTransDetailId;
	}

	public void setCheckBillTransDetailId(BigDecimal checkBillTransDetailId) {
		this.checkBillTransDetailId = checkBillTransDetailId;
	}

	public Integer getTransType() {
		return transType;
	}

	public void setTransType(Integer transType) {
		this.transType = transType;
	}

	public String getApplyFlag() {
		return applyFlag;
	}

	public void setApplyFlag(String applyFlag) {
		this.applyFlag = applyFlag;
	}

	public String getBankTransId() {
		return bankTransId;
	}

	public void setBankTransId(String bankTransId) {
		this.bankTransId = bankTransId;
	}

	public BigDecimal getId() {
		return id;
	}

	public void setId(BigDecimal id) {
		this.id = id;
	}

	public String getApplyNo() {
		return applyNo;
	}

	public void setApplyNo(String applyNo) {
		this.applyNo = applyNo == null ? null : applyNo.trim();
	}

	public BigDecimal getTransSeq() {
		return transSeq;
	}

	public void setTransSeq(BigDecimal transSeq) {
		this.transSeq = transSeq;
	}

	public BigDecimal getApplyUserSeq() {
		return applyUserSeq;
	}

	public void setApplyUserSeq(BigDecimal applyUserSeq) {
		this.applyUserSeq = applyUserSeq;
	}

	public Date getApplyTime() {
		return applyTime;
	}

	public void setApplyTime(Date applyTime) {
		this.applyTime = applyTime;
	}

	public String getAuditStatus() {
		return auditStatus;
	}

	public void setAuditStatus(String auditStatus) {
		this.auditStatus = auditStatus == null ? null : auditStatus.trim();
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason == null ? null : reason.trim();
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public BigDecimal getVersion() {
		return version;
	}

	public void setVersion(BigDecimal version) {
		this.version = version;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser == null ? null : createUser.trim();
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser == null ? null : updateUser.trim();
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

}