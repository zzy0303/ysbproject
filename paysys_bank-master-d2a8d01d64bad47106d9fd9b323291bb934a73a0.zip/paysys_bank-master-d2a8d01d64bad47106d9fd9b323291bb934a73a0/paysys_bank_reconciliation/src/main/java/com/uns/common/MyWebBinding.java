package com.uns.common;

import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.springframework.beans.propertyeditors.CustomCollectionEditor;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.beans.propertyeditors.CustomNumberEditor;
import org.springframework.beans.propertyeditors.StringArrayPropertyEditor;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.support.WebBindingInitializer;
import org.springframework.web.context.request.WebRequest;

/**
 * 解决特殊类型绑定的问题
 * 
 * @author Administrator
 *
 */
public class MyWebBinding implements WebBindingInitializer {

	@Override
    public void initBinder(WebDataBinder binder, WebRequest req) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DEFAULT_DATE_FORMAT);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
		binder.registerCustomEditor(Long.class, new CustomNumberEditor(Long.class, true));

		binder.registerCustomEditor(Collection.class, new CustomCollectionEditor(Collection.class, true));
		binder.registerCustomEditor(List.class, new CustomCollectionEditor(List.class, true));
		binder.registerCustomEditor(String[].class, new StringArrayPropertyEditor());
		binder.registerCustomEditor(Double[].class, new StringArrayPropertyEditor());
		binder.registerCustomEditor(Integer[].class, new StringArrayPropertyEditor());

	}
}
