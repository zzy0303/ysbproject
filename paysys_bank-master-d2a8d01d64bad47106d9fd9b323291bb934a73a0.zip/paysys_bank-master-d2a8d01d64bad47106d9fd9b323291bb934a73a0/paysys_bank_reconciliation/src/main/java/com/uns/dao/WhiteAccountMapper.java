package com.uns.dao;

import com.uns.model.WhiteAccount;
import com.uns.web.form.WhiteAccountForm;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface WhiteAccountMapper {

    int deleteByPrimaryKey(BigDecimal id);

    int insert(WhiteAccount record);

    int insertSelective(WhiteAccount record);

    WhiteAccount selectByPrimaryKey(BigDecimal id);

    int updateByPrimaryKeySelective(WhiteAccount record);

    int updateByPrimaryKey(WhiteAccount record);

    List<WhiteAccount> queryWhiteAccountList(WhiteAccountForm whiteAccountForm);

    WhiteAccount queryWhiteAccountByParam(WhiteAccount whiteAccount);

    List<String> queryActionSeqByAccountId(String s);
}