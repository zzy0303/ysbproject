package com.uns.channel;

import com.uns.model.BankTrans;
import com.uns.util.ChannelConstants;
import com.uns.util.ExcelUtils;
import com.uns.web.form.CheckBillForm;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/11/3
 * @Modifyed By:
 */
public class ChannelHandleEgbProb extends ChannelHandleDefault implements ChannelHandleInterface {
    @Override
    public List<BankTrans> loadDate(InputStream inputStream, CheckBillForm checkBillForm) throws Exception {
        return ExcelUtils.loadxls(inputStream, checkBillForm);
    }

    @Override
    public List<Map<String, Object>> getLocalTrans(Integer id) throws Exception {
        return getDkLocalTrans(id, ChannelConstants.CHANNEL_EGB_PROB);
    }

    @Override
    public Map<String, Object> getLocalAmount(String channel, String checkDate) {
        return null;
    }

    @Override
    public List<String> getChannelList() throws Exception {
        return null;
    }
}
