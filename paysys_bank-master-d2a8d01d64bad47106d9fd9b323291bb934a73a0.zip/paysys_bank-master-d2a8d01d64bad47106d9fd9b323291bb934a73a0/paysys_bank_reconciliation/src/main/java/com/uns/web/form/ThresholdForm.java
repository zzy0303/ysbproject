package com.uns.web.form;

import java.util.Date;

public class ThresholdForm {
	private  String channel;	
	
	private String connType;
	
	private String checkStatus;
	
	private Date checkStart;
	
	private Date checkEnd;
	
	private String localTransId;
	
	private String bankTransId;
	
	private String accountName;
	
	private String actionName;
	
	private String feeValueStatus;
	
	private Date  operationStart;
	
	private Date  operationEnd;
	
	private String operator;
	
	

	public String getConnType() {
		return connType;
	}

	public void setConnType(String connType) {
		this.connType = connType;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getCheckStatus() {
		return checkStatus;
	}

	public void setCheckStatus(String checkStatus) {
		this.checkStatus = checkStatus;
	}


	public String getLocalTransId() {
		return localTransId;
	}

	public void setLocalTransId(String localTransId) {
		this.localTransId = localTransId;
	}

	public String getBankTransId() {
		return bankTransId;
	}

	public void setBankTransId(String bankTransId) {
		this.bankTransId = bankTransId;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getActionName() {
		return actionName;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}


	public String getFeeValueStatus() {
		return feeValueStatus;
	}

	public void setFeeValueStatus(String feeValueStatus) {
		this.feeValueStatus = feeValueStatus;
	}


	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public Date getCheckStart() {
		return checkStart;
	}

	public void setCheckStart(Date checkStart) {
		this.checkStart = checkStart;
	}

	public Date getCheckEnd() {
		return checkEnd;
	}

	public void setCheckEnd(Date checkEnd) {
		this.checkEnd = checkEnd;
	}

	public Date getOperationStart() {
		return operationStart;
	}

	public void setOperationStart(Date operationStart) {
		this.operationStart = operationStart;
	}

	public Date getOperationEnd() {
		return operationEnd;
	}

	public void setOperationEnd(Date operationEnd) {
		this.operationEnd = operationEnd;
	}
	
	
}
