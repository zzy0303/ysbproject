package com.uns.web.form;

import com.uns.common.Constants;

public class AdjustAuditForm {

	private String userId;
	private String applyNo;
	private String transId;
	private String startDate;
	private String endDate;
	private String attitude;
	private String auditOperandTypeId;
	private String operationType;
	private String reason;
	private String auditStatus;
	private String amount;

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getAuditStatus() {
		return auditStatus;
	}

	public void setAuditStatus(String auditStatus) {
		this.auditStatus = auditStatus;
	}

	public String getReason() {
		return Constants.ADJUST_REASON_TRANS_HANGUP;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getOperationType() {
		return operationType;
	}

	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}

	public String getAuditOperandTypeId() {
		return auditOperandTypeId;
	}

	public void setAuditOperandTypeId(String auditOperandTypeId) {
		this.auditOperandTypeId = auditOperandTypeId;
	}

	public String getAttitude() {
		return attitude;
	}

	public void setAttitude(String attitude) {
		this.attitude = attitude;
	}

	public String getApplyNo() {
		return applyNo;
	}

	public void setApplyNo(String applyNo) {
		this.applyNo = applyNo;
	}

	public String getTransId() {
		return transId;
	}

	public void setTransId(String transId) {
		this.transId = transId;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}
