package com.uns.util;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import com.uns.common.Constants;

public class MapSources {
	public Map<String,Object> b2cMap(){
		Map<String,Object> map=new HashMap<String,Object>();
		map.put(Constants.UPLOAD_UNIONPAY_XM, Arrays.asList(Constants.UPLOAD_UNIONPAY_XM_CHANNEL.split(",")));
		map.put(Constants.UPLOAD_UNIONPAY_CQ, Arrays.asList(Constants.UPLOAD_UNIONPAY_CQ_CHANNEL.split(",")));
		map.put(Constants.UPLOAD_UMPAY, Arrays.asList(Constants.UPLOAD_UMPAY_CHANNEL.split(",")));
		return map;			
	}
	
	public Map<String,Object> smMap(){
		Map<String,Object> map=new HashMap<String,Object>();
		map.put(Constants.UPLOAD_CMBC_XM_SM, Arrays.asList(Constants.UPLOAD_CMBC_XM.split(",")));
		map.put(Constants.UPLOAD_UPOP_SM, Arrays.asList(Constants.UPLOAD_UPOP_SM.split(",")));
		map.put(Constants.UPLOAD_CMB_SM, Arrays.asList(Constants.UPLOAD_CMB_SM_CHANNEL2.split(",")));
		map.put(Constants.UPLOAD_CIB_SM, Arrays.asList(Constants.CHANNELCIBSM.split(",")));
		return map;		
	}
}
