package com.uns.dao;

import com.uns.model.Account;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface AccountMapper {
    List<Account> selectByPrimaryKey(BigDecimal id);
    List<Account> selectAllAccount();

    Account queryAccountByDefaultSeq(String defaultSeq);
}