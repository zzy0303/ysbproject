package com.uns.biz;

import java.util.List;
import java.util.Map;

import com.uns.model.BankTrans;
import com.uns.web.form.CheckBillForm;

public class BizCcbB2c extends DefaultBiz   {
	protected final static String transStatus = "成功";

	@Override
	public boolean checkInputData(String[] data, CheckBillForm checkBillForm, BankTrans trans,
			Map<String, List<String>> setting) throws Exception {

		if (!transStatus.equals(data[5])) {
			if (transStatus.equals(data[6])){
				return true;
			}
		} else {
			if (transStatus.equals(data[5])){
				return true;
			}
		}

		return super.checkInputData(data, checkBillForm, trans, setting);
	}
}
