package com.uns.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.dao.RoleMapper;
import com.uns.model.Role;

@Service
public class RoleService {

	@Autowired
	private RoleMapper roleMapper;

	public Role selectByPrimaryKey(Long id) throws Exception {

		return roleMapper.selectByPrimaryKey(id);
	}

}
