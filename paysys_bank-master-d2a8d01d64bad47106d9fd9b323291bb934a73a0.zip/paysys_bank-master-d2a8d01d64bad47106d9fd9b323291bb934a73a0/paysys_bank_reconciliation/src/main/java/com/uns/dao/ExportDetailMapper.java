package com.uns.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.CheckBillTransDetail;
import com.uns.model.TransDetail;
import com.uns.web.form.TransDetailForm;

@Repository
public interface ExportDetailMapper {
	List<TransDetail> getExportDetail(TransDetailForm transDetailForm);

	List<TransDetail> getOutExportDetail(TransDetailForm transDetailForm);

	List<TransDetail> getNetsUnionExportDetail(TransDetailForm transDetailForm);
}
