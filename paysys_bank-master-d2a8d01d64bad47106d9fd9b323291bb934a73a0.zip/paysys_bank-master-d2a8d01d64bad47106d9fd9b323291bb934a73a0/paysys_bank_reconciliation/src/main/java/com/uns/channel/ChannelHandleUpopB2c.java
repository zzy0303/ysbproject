package com.uns.channel;

import com.uns.model.BankTrans;
import com.uns.web.form.CheckBillForm;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/11/3
 * @Modifyed By:
 */
public class ChannelHandleUpopB2c implements ChannelHandleInterface {
    @Override
    public List<BankTrans> loadDate(InputStream inputStream, CheckBillForm checkBillForm) throws Exception {
        return null;
    }

    @Override
    public List<Map<String, Object>> getLocalTrans(Integer id) throws Exception {
        return null;
    }

    @Override
    public Map<String, Object> getLocalAmount(String channel, String checkDate) {
        return null;
    }

    @Override
    public List<String> getChannelList() throws Exception {
        return null;
    }
}
