package com.uns.web.form;

import java.math.BigDecimal;

public class MergentForm {
	private long merchantSeq;

	private long actionSeq;

	private BigDecimal amount;

	private String UpdateUser;

	public long getMerchantSeq() {
		return merchantSeq;
	}

	public void setMerchantSeq(long merchantSeq) {
		this.merchantSeq = merchantSeq;
	}

	public long getActionSeq() {
		return actionSeq;
	}

	public void setActionSeq(long actionSeq) {
		this.actionSeq = actionSeq;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getUpdateUser() {
		return UpdateUser;
	}

	public void setUpdateUser(String updateUser) {
		UpdateUser = updateUser;
	}

}
