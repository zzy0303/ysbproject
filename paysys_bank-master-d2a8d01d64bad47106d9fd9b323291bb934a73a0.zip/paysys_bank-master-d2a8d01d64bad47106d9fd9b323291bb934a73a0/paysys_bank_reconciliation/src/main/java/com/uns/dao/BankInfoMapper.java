package com.uns.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.BankInfo;

@Repository
public interface BankInfoMapper {

	int deleteByPrimaryKey(BigDecimal id);

	int insert(BankInfo record);

	int insertSelective(BankInfo record);

	BankInfo selectByPrimaryKey(BigDecimal id);

	int updateByPrimaryKeySelective(BankInfo record);

	int updateByPrimaryKey(BankInfo record);

    List<String> getBankCodeAll(Map<String, Object> pareMap);

	List<String> getBankCodeLeft(Map<String, Object> pareMap);

	List<String> getBankCodeRight(Map<String, Object> pareMap);
}