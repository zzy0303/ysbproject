package com.uns.model;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.Date;

import com.uns.util.StringUtils;

public class CheckBillTransDetail {
	private Long id;

	private Date checkDate;

	private String channel;

	private String bankName;

	private String actionName;

	private String channelNo;

	private String localTransId;

	private String bankTransId;

	private String accountName;

	private Integer checkBillId;

	private BigDecimal localAmount;

	private BigDecimal bankAmount;

	private String fileName;

	private String checkTransStatus;

	private String transDate;

	private String dealFlag;

	private String feeValueStatus;

	private String name;		//商户名称

	private BigDecimal creditFee;	//手续费

	private String operStatus;

	private String checkUser;

	private Integer transType;

	private String merchantCode;
	
	private String billType;   //交易类型

	private String batchId;

	private String bankBusiType;
	private String payOrgIdSeq;
	private String destOrgIdSeq;
	private String bankBusiStatus;

	public String getBankBusiType() {
		return bankBusiType;
	}

	public void setBankBusiType(String bankBusiType) {
		this.bankBusiType = bankBusiType;
	}

	public String getPayOrgIdSeq() {
		return payOrgIdSeq;
	}

	public void setPayOrgIdSeq(String payOrgIdSeq) {
		this.payOrgIdSeq = payOrgIdSeq;
	}

	public String getDestOrgIdSeq() {
		return destOrgIdSeq;
	}

	public void setDestOrgIdSeq(String destOrgIdSeq) {
		this.destOrgIdSeq = destOrgIdSeq;
	}

	public String getBankBusiStatus() {
		return bankBusiStatus;
	}

	public void setBankBusiStatus(String bankBusiStatus) {
		this.bankBusiStatus = bankBusiStatus;
	}

	public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	public String getBillType() {
		return billType;
	}

	public void setBillType(String billType) {
		this.billType = billType;
	}

	public String getMerchantCode() {
		return merchantCode;
	}

	public void setMerchantCode(String merchantCode) {
		this.merchantCode = merchantCode;
	}

	public Integer getTransType() {
		return transType;
	}

	public void setTransType(Integer transType) {
		this.transType = transType;
	}

	public String getOperStatus() {
		return operStatus;
	}

	public void setOperStatus(String operStatus) {
		this.operStatus = operStatus;
	}

	public String getCheckUser() {
		return checkUser;
	}

	public void setCheckUser(String checkUser) {
		this.checkUser = checkUser;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BigDecimal getCreditFee() {
		return creditFee;
	}

	public void setCreditFee(BigDecimal creditFee) {
		this.creditFee = creditFee;
	}

	public String getFeeValueStatus() {
		return feeValueStatus;
	}

	public void setFeeValueStatus(String feeValueStatus) {
		this.feeValueStatus = feeValueStatus;
	}

	public String getDealFlag() {
		return dealFlag;
	}

	public void setDealFlag(String dealFlag) {
		this.dealFlag = dealFlag;
	}

	public String getTransDate() {
		return transDate;
	}

	public void setTransDate(String transDate) {
		if (transDate.indexOf(".") > 0) {
			this.transDate = transDate.substring(0, transDate.indexOf("."));
		} else {
            this.transDate = transDate;
        }
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getCheckDate() {
		return checkDate;
	}

	public void setCheckDate(Date checkDate) {
		this.checkDate = checkDate;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel == null ? null : channel.trim();
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getActionName() {
		return actionName;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	public String getChannelNo() {
		return channelNo;
	}

	public void setChannelNo(String channelNo) {
		this.channelNo = channelNo;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public Integer getCheckBillId() {
		return checkBillId;
	}

	public void setCheckBillId(Integer checkBillId) {
		this.checkBillId = checkBillId;
	}

	public String getLocalTransId() {
		return localTransId;
	}

	public void setLocalTransId(String localTransId) {
		this.localTransId = localTransId == null ? null : localTransId.trim();
	}

	public String getBankTransId() {
		return bankTransId;
	}

	public void setBankTransId(String bankTransId) {
		this.bankTransId = bankTransId == null ? null : bankTransId.trim();
	}

	public BigDecimal getLocalAmount() {
		return localAmount;
	}

	public void setLocalAmount(Double localAmount) {
		this.localAmount = new BigDecimal(localAmount.toString()).setScale(2);
	}

	public BigDecimal getBankAmount() {
		return bankAmount;
	}

	public void setBankAmount(Double bankAmount) {
		this.bankAmount = new BigDecimal(bankAmount.toString()).setScale(2);
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName == null ? null : fileName.trim();
	}

	public String getCheckTransStatus() {
		return checkTransStatus;
	}

	public void setCheckTransStatus(String checkTransStatus) {
		this.checkTransStatus = checkTransStatus == null ? null : checkTransStatus.trim();
	}
}