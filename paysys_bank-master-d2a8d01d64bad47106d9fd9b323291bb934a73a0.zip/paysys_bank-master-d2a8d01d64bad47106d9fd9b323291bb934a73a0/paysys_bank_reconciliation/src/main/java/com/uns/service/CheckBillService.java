package com.uns.service;

import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.uns.channel.ChannelHandleMapping;
import com.uns.dao.*;
import com.uns.dao.EpccAuthpayTransRefMapper;
import com.uns.dao.EpccDcTransRefMapper;
import com.uns.dao.EpccGatewayTransRefMapper;
import com.uns.dao.EpccQpTransRefMapper;
import com.uns.dao.EpccDpTransRefMapper;
import com.uns.datasourceSwitch.DynamicDataSourceHolder;
import com.uns.model.*;
import com.uns.util.*;
import com.uns.web.form.AdjustApplyForm;
import com.uns.web.form.TransDetailForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.uns.biz.BizMapping;
import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.PageContext;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.web.form.CheckBillForm;

@Service
public class CheckBillService {

    private Logger log = LoggerFactory.getLogger(getClass());

    @Autowired
    EpccDpTransRefMapper epccDpTransRefMapper;

    @Autowired
    EpccAuthpayTransRefMapper epccAuthpayTransRefMapper;

    @Autowired
    EpccDcTransRefMapper epccDcTransRefMapper;

    @Autowired
    EpccGatewayTransRefMapper epccGatewayTransRefMapper;

    @Autowired
    EpccQpTransRefMapper epccQpTransRefMapper;

    @Autowired
    private XmBankMapper xmBankMapper;

    @Autowired
    private BankTransMapper bankTransMapper;
    @Autowired
    private FileUploadRecordMapper fileUploadRecordMapper;
    @Autowired
    private CheckBillMapper checkBillMapper;
    @Autowired
    private CheckBillTransDetailMapper checkBillTransDetailMapper;
    @Autowired
    private UpadjustApplyMapper upadjustApplyMapper;
    @Autowired
    private AdjustApplyService adjustApplyService;

    @Autowired
    private AdjustAuditService adjustAuditService;

    @Autowired
    private AcmsMapUtils acmsMapUtils;

    @Autowired
    private TransRefMapper transRefMapper;
    @Autowired
    private WithDrawOrderMapper withDrawOrderMapper;

    /**
     * 自动对账(根据通道上传对账单、通道对账)
     *
     * @param checkBillForm
     * @throws BusinessException
     * @throws Exception
     */
    public void autoUpload(CheckBillForm checkBillForm) throws Exception {
        //从ftp获取需对账的对账单
        log.info("自动对账==========上传begin==========");
        String checkDate = checkBillForm.getCheckdate().replace("-", "");
        String fileName = checkDate;
        List<InputStream> inputStreams = new FTPManager().getFiles(checkBillForm.getChannel(), fileName);
        if (null == inputStreams || inputStreams.size() < 1) {
            throw new BusinessException(ExceptionDefine.通道无对账文件);
        }
        checkBillForm.setFileList(inputStreams);
        checkBillForm.setStartDate(checkBillForm.getCheckdate());
        checkBillForm.setEndDate(checkBillForm.getCheckdate());
        checkBillForm.setBillType(Constants.CHECK_BILL_0);
        //动态获取直连通道
        String directChannel = acmsMapUtils.getAcmsMap().get("CHECK_BILL_CHANNEL_DIRECT");

        //判断对账通道直连或间连
        if (directChannel.contains(checkBillForm.getChannel())) {
            checkBillForm.setConnType(Constants.FLAG_0);
        } else {
            checkBillForm.setConnType(Constants.FLAG_1);
        }
        checkBillForm.setFileName(fileName);
        checkBillForm.setCheckType(Constants.FLAG_1);
        //上传对账文件
        this.checkBill(checkBillForm, Constants.AUTO_USER_NAME);
        log.info("自动对账==========上传end==========");

        //对账
        log.info("自动对账==========对账begin==========");
        Map map = new HashMap();
        map.put("checkDate", checkBillForm.getCheckdate());
        map.put("channel", checkBillForm.getChannel());
        map.put("billType", Constants.CHECK_BILL_0);
        CheckBill checkBill = checkBillMapper.selectByChannelDate(map);
        this.compareTrans(checkBill.getId().intValue(), Constants.AUTO_USER_NAME, map, null);
        log.info("自动对账==========对账end==========");
        /**
         * 挂起
         * 查询对账完成后是否有我方有银行无的日切交易
         * 如果有则进行挂起操作
         */
        log.info("自动对账==========挂起begin==========");
        TransDetailForm transDetailForm = new TransDetailForm();
        transDetailForm.setChannel(checkBillForm.getChannel());
        transDetailForm.setStartDate(checkBillForm.getCheckdate());
        List<String> transIds = checkBillTransDetailMapper.getDealTrans(transDetailForm);
        if (null != transIds && transIds.size() > 0) {
            String[] transIdArr = transIds.toArray(new String[transIds.size()]);
            AdjustApplyForm adjustApplyForm = new AdjustApplyForm();
            //交易挂起
            adjustApplyForm.setCheckStatus(Constants.FLAG_3);
            adjustApplyForm.setApplyReason(Constants.ADJUST_REASON_TRANS_HANGUP);
            adjustApplyForm.setApplyRemark(Constants.ADJUST_REASON_TRANS_HANGUP);
            adjustApplyService.applyRecord(adjustApplyForm, Long.valueOf(Constants.FLAG_0), transIdArr);
        }
        log.info("自动对账==========挂起end==========");
        /**
         * 审核
         */
        log.info("自动对账==========审核begin==========");
        if (null != transIds && transIds.size() > 0) {
            //查询待审核的挂起记录
            List<String> applyNos = upadjustApplyMapper.getWaitAuditList(transDetailForm);
            if (null != applyNos && applyNos.size() > 0) {
                String[] applyNoArr = applyNos.toArray(new String[applyNos.size()]);
                //审核
                adjustAuditService.agreeRecord(null, Long.valueOf(Constants.FLAG_0), applyNoArr);
            }
        }
        log.info("自动对账==========审核end==========");
    }

    /**
     * 网联自动对账
     *
     * @param checkBillForm
     * @throws BusinessException
     * @throws Exception
     */
    public void autoUploadNetsUnion(CheckBillForm checkBillForm) throws Exception {
        //从ftp获取需对账的对账单
        log.info("自动对账==========上传begin==========");
        String checkDate = checkBillForm.getCheckdate().replace("-", "");
        checkBillForm.setBatchId("null".equals(checkBillForm.getBatchId()) ? "" : checkBillForm.getBatchId());
        String batchId = checkBillForm.getBatchId();
        String fileName = checkDate;
        List<InputStream> inputStreams = new FTPManager().getNetsUnionFiles(Constants.UPLOAD_EPCC, fileName);

        if (null == inputStreams || inputStreams.size() < 1) {
            throw new BusinessException(ExceptionDefine.通道无对账文件);
        }
        checkBillForm.setFileList(inputStreams);
        checkBillForm.setStartDate(checkBillForm.getCheckdate());
        checkBillForm.setEndDate(checkBillForm.getCheckdate());
        checkBillForm.setBillType(Constants.CHECK_BILL_2);
        checkBillForm.setFileName(fileName);
        checkBillForm.setCheckType(Constants.FLAG_1);
        checkBillForm.setChannel(Constants.UPLOAD_EPCC);
        //上传对账文件
        this.netsUnionUploadFile(checkBillForm, Constants.AUTO_USER_NAME);
        log.info("自动对账==========上传end==========");

        //对账
        log.info("自动对账==========对账begin==========");
        Map map = new HashMap();
        map.put("checkDate", checkBillForm.getCheckdate());
        map.put("channel", checkBillForm.getChannel());
        map.put("billType", Constants.CHECK_BILL_2);
        map.put("batchId", batchId);
        CheckBill checkBill = checkBillMapper.selectByChannelDateBatch(map);
        this.compareTrans(checkBill.getId().intValue(), Constants.AUTO_USER_NAME, map, checkBillForm);
        log.info("自动对账==========对账end==========");
        /**
         * 挂起
         * 查询对账完成后是否有我方有银行无的日切交易
         * 如果有则进行挂起操作
         */
        log.info("自动对账==========挂起begin==========");
        TransDetailForm transDetailForm = new TransDetailForm();
        transDetailForm.setChannel(checkBillForm.getChannel());
        transDetailForm.setStartDate(checkBillForm.getCheckdate());
        transDetailForm.setBatchId(batchId);
        List<String> transIds = checkBillTransDetailMapper.getNetsUnionDealTrans(transDetailForm);
        if (null != transIds && transIds.size() > 0) {
            String[] transIdArr = transIds.toArray(new String[transIds.size()]);
            AdjustApplyForm adjustApplyForm = new AdjustApplyForm();
            //交易挂起
            adjustApplyForm.setCheckStatus(Constants.FLAG_3);
            adjustApplyForm.setApplyReason(Constants.ADJUST_REASON_TRANS_HANGUP);
            adjustApplyForm.setApplyRemark(Constants.ADJUST_REASON_TRANS_HANGUP);
            adjustApplyForm.setBillType(Constants.CHECK_BILL_2);
            adjustApplyService.netsUnionApplyRecord(adjustApplyForm, Long.valueOf(Constants.FLAG_0), transIdArr);
        }
        log.info("自动对账==========挂起end==========");
        /**
         * 审核
         */
        log.info("自动对账==========审核begin==========");
        if (null != transIds && transIds.size() > 0) {
            //查询待审核的挂起记录
            List<String> applyNos = upadjustApplyMapper.getNetsUnionWaitAuditList(transDetailForm);
            if (null != applyNos && applyNos.size() > 0) {
                String[] applyNoArr = applyNos.toArray(new String[applyNos.size()]);
                //审核
                adjustAuditService.agreeNetsUnionRecord(Long.valueOf(Constants.FLAG_0), applyNoArr);
            }
        }
        log.info("自动对账==========审核end==========");
    }

    /**
     * 对账文件解析　上传保存等
     * @param checkBillForm
     * @param userName
     * @throws Exception
     */
    public void checkBill(CheckBillForm checkBillForm, String userName)
            throws Exception {

        // 生成文件上传历史fileUploadRecord
        List<FileUploadRecord> fileList = getFileList(checkBillForm, userName);
        // 获取对账表是否已生成对账日期的对账记录,对账文件是否已上传
        isGeneratedRecord(fileList);
        //银行交易列表
        List<BankTrans> list; // = new ArrayList<BankTrans>();
        //未使用
        String channel = checkBillForm.getChannel();
        if (channel.contains("_")) {
            channel = channel.substring(0, channel.indexOf("_"));
        }
        Map<String, List<String>> setting = transSetting(checkBillForm.getChannel().toUpperCase());
        //以前处理方式
        if (setting.containsKey("NEW_FUNC")) {
            list = InputB2cList(checkBillForm, setting);
        } else {//现在处理方式
            list = InputOtherList(channel, checkBillForm);//解析银行对账单文件，获取银行交易
        }

        //保存文件上传历史fileUploadRecord
        for (int i = 0; i < fileList.size(); i++) {
            fileUploadRecordMapper.insertSelective(fileList.get(i));
            Long id = Long.valueOf(fileList.get(i).getId().toString());
            if (i == 0) {// 对账文件包含昨天交易的算到第一天的对账文件中
                for (int j = 0; j < list.size(); j++) {
                    if (list.get(j).getTransDate().getTime() <= fileList.get(i).getCheckDate().getTime()) {
                        list.get(j).setUploadId(id);// 设置银行对账交易外键
                    }
                }
            } else {
                for (int j = 0; j < list.size(); j++) {
                    if (list.get(j).getTransDate().getTime() == fileList.get(i).getCheckDate().getTime()) {
                        list.get(j).setUploadId(id);// 设置银行对账交易外键
                    }
                }
            }
        }
        // 保存银行交易
        try {
            if (setting.containsKey("NEW_FUNC")) {
                newAddTrans(list, checkBillForm.getChannel().toLowerCase(), setting);
            } else {
                oldAddTrans(list, checkBillForm.getChannel().toUpperCase());
            }
        } catch (Exception e) {
            String mess = e.getMessage();
            if (mess.indexOf("ORA-00001") != -1) {
                e.printStackTrace();
                throw new BusinessException(ExceptionDefine.对账文件交易重复);
            }
            if (mess.indexOf("ORA-00903") != -1) {
                throw new BusinessException(ExceptionDefine.对账文件没有相应的记录);
            } else {
                e.printStackTrace();
            }
        }
        // 更新对账表处理状态
        updateCheckStatus(fileList);
    }

    public void netsUnionUploadFile(CheckBillForm checkBillForm, String userName)
            throws Exception {

        // 生成文件上传历史fileUploadRecord
        List<FileUploadRecord> fileList = getNetsUnionFileList(checkBillForm, userName);
        // 获取对账表是否已生成对账日期的对账记录,对账文件是否已上传
        isGeneratedEpccRecord(fileList);

        List<BankTrans> list;
        String channel = checkBillForm.getChannel();

        list = InputOtherList(channel, checkBillForm);

        //保存文件上传历史fileUploadRecord
        for (int i = 0; i < fileList.size(); i++) {
            fileUploadRecordMapper.insertSelective(fileList.get(i));
            Long id = Long.valueOf(fileList.get(i).getId().toString());
            if (i == 0) {// 对账文件包含昨天交易的算到第一天的对账文件中
                for (int j = 0; j < list.size(); j++) {
                    if (list.get(j).getTransDate().getTime() <= fileList.get(i).getCheckDate().getTime()) {
                        list.get(j).setUploadId(id);// 设置银行对账交易外键
                    }
                }
            } else {
                for (int j = 0; j < list.size(); j++) {
                    if (list.get(j).getTransDate().getTime() == fileList.get(i).getCheckDate().getTime()) {
                        list.get(j).setUploadId(id);// 设置银行对账交易外键
                    }
                }
            }
        }
        // 保存银行交易
        try {
            if(list.size() != 0){
                oldAddTrans(list, checkBillForm.getChannel().toUpperCase());
            }
        } catch (Exception e) {
            if(!Constants.AUTO_USER_NAME.equals(userName)){
                String mess = e.getMessage();
                if (mess.indexOf("ORA-00001") != -1) {
                    e.printStackTrace();
                    throw new BusinessException(ExceptionDefine.对账文件交易重复);
                }
                if (mess.indexOf("ORA-00903") != -1) {
                    throw new BusinessException(ExceptionDefine.对账文件没有相应的记录);
                } else {
                    e.printStackTrace();
                }
            }
        }
        updateEpccCheckStatus(fileList);
    }

    protected void newAddTrans(List<BankTrans> list, String channel, Map<String, List<String>> setting)
            throws ParseException {
        List<List> allList = StringUtils.getList(list);

        for (int i = 0; i < allList.size(); i++) {
            bankTransMapper.insertList(allList.get(i));
        }
    }

    protected void oldAddTrans(List<BankTrans> list, String channel) throws ParseException {
        List<String> merchantList = null;
        List<List> allList = StringUtils.getList(list);
        String merchantStr = DynamicConfigLoader.getByEnv(String.format("UNSPAY_TRANS_%s_MERCHANT_LIST", channel));
        for (int i = 0; i < allList.size(); i++) {
            if (null != merchantStr) {
                List<BankTrans> lc = new ArrayList<BankTrans>();
                if (null == merchantList) {
                    merchantList = StringUtils.getSplit2List(merchantStr, "\\|");
                }
                for (BankTrans bt : (List<BankTrans>) allList.get(i)) {
                    if (merchantList.contains(bt.getMerchantCode())) {
                        Date date = new SimpleDateFormat("yyyyMMdd").parse(bt.getTransTimeStr().substring(0, 8));
                        bt.setTransTime(date);
                        lc.add(bt);
                    }
                }
                if (lc.size() > 0) {
                    bankTransMapper.insertList(lc);
                }
            } else {
                bankTransMapper.insertList(allList.get(i));
            }
        }
    }

    /**
     * 获取通道对应的参数记录
     *
     * @param channel
     * @return
     */
    protected Map<String, List<String>> transSetting(String channel) {
        Map<String, List<String>> map = new HashMap<String, List<String>>();
        String transfunctionName = String.format("UNSPAY_TRANS_%s_NEW_FUNC", channel);
        String merchantName = String.format("UNSPAY_TRANS_%s_MERCHANT_LIST", channel);
        String actionName = String.format("UNSPAY_TRANS_%s_ACTION_LIST", channel);
        String channelName = String.format("UNSPAY_TRANS_%s_CHANNEL_LIST", channel);
        String inputName = String.format("UNSPAY_TRANS_%s_INPUT_LOCAL", channel);
        String succName = String.format("UNSPAY_TRANS_%s_SUCCESS_STATUS", channel);
        String dateFormatName = String.format("UNSPAY_TRANS_%s_DATE_FORMAT", channel);
        String unitConvName = String.format("UNSPAY_TRANS_%s_UNIT_CONV", channel);
        String charsetName = String.format("UNSPAY_TRANS_%s_CHARSET_CODE", channel);

        String transfunctionStr = DynamicConfigLoader.getByEnv(transfunctionName);
        String merchantStr = DynamicConfigLoader.getByEnv(merchantName);
        String actionStr = DynamicConfigLoader.getByEnv(actionName);
        String channelStr = DynamicConfigLoader.getByEnv(channelName);
        String inputStr = DynamicConfigLoader.getByEnv(inputName);
        String succStr = DynamicConfigLoader.getByEnv(succName);
        String dateFormatStr = DynamicConfigLoader.getByEnv(dateFormatName);
        String unitConvStr = DynamicConfigLoader.getByEnv(unitConvName);
        String charsetCodeStr = DynamicConfigLoader.getByEnv(charsetName);

        map.put("CHANNEL_INDIRECT", StringUtils.getSplit2List(acmsMapUtils.getAcmsMap().get("CHECK_BILL_CHANNEL_INDIRECT"), ","));
        map.put("CHANNEL_PATTERN", StringUtils.getSplit2List(acmsMapUtils.getAcmsMap().get("CHECK_BILL_CHANNEL_PATTERN"), ","));

        map.put("CHANNEL_DIRECT", StringUtils.getSplit2List(acmsMapUtils.getAcmsMap().get("CHECK_BILL_CHANNEL_DIRECT"), ","));
        map.put("CHANNEL_INPATTERN", StringUtils.getSplit2List(acmsMapUtils.getAcmsMap().get("CHECK_BILL_CHANNEL_INPATTERN"), ","));

        map.put("CHARSET_CODE", StringUtils.getSplit2List(null == charsetCodeStr ? "UTF-8" : charsetCodeStr, "\\|"));

        if (null != unitConvStr) {
            map.put("UNIT_CONV", StringUtils.getSplit2List(unitConvStr, "\\|"));
        }

        if (null != dateFormatStr) {
            map.put("DATE_FORMAT", StringUtils.getSplit2List(dateFormatStr, "\\|"));
        }

        if (null != succStr) {
            map.put("SUCCESS_STATUS", StringUtils.getSplit2List(succStr, "\\|"));
        }

        if (null != transfunctionStr) {
            map.put("NEW_FUNC", StringUtils.getSplit2List(transfunctionStr, "\\|"));
        }

        if (null != merchantStr) {
            map.put("MERCHANT_LIST", StringUtils.getSplit2List(merchantStr, "\\|"));
        }

        if (null != actionStr) {
            if (channel.contains(Constants.CHECK_BILL_B2C) || channel.contains(Constants.CHECK_BILL_B2C_D)) {
                map.put("ACTION_LIST", java.util.Arrays.asList(Constants.UPLOAD_B2C_ACTIONTYPE.split(",")));
            }
            if (channel.contains(Constants.CHECK_BILL_KJ) || channel.contains(Constants.CHECK_BILL_KJ_D)) {
                map.put("ACTION_LIST", java.util.Arrays.asList(Constants.UPLOAD_KJ_ACTIONTYPE.split(",")));
            }
//			else {
//				map.put("ACTION_LIST", StringUtils.getSplit2List(merchantStr, "\\|"));
//			}

        }

        if (null != channelStr) {
            map.put("CHANNEL_LIST", StringUtils.getSplit2List(channelStr, "\\|"));
        }

        if (null != inputStr) {
            map.put("INPUT_LOCAL", StringUtils.getSplit2List(inputStr, "\\|"));
        }

        return map;
    }

    /**
     * 上传文件
     *
     * @param checkBillForm
     * @param setting
     * @return
     * @throws Exception
     */
    protected List<BankTrans> InputB2cList(CheckBillForm checkBillForm, Map<String, List<String>> setting)
            throws Exception {
        List<BankTrans> List = new ArrayList<BankTrans>();
        //自动对账
        if (Constants.FLAG_1.equals(checkBillForm.getCheckType())) {
            for (InputStream inputStream : checkBillForm.getFileList()) {
                List.addAll(uploadFile(checkBillForm, setting, inputStream));
            }
        } else {
            MultipartFile[] checkBillFile = checkBillForm.getCheckBillFile();
            for (int i = 0; i < checkBillFile.length; i++) {
                InputStream inputStreams = checkBillFile[i].getInputStream();
                List.addAll(uploadFile(checkBillForm, setting, inputStreams));
            }
        }
        return List;
    }

    public List<BankTrans> uploadFile(CheckBillForm checkBillForm, Map<String, List<String>> setting,
                                      InputStream inputStream) throws Exception {
        List<String> cd = null;
        List<String> cp = null;

        if (checkBillForm.getConnType().equals(Constants.CONNECTTYPE)) {
            cd = setting.get("CHANNEL_DIRECT");
            cp = setting.get("CHANNEL_INPATTERN");
        } else {
            cd = setting.get("CHANNEL_INDIRECT");
            cp = setting.get("CHANNEL_PATTERN");
        }

        for (int i = 0; i < cd.size(); i++) {
            if (cd.get(i).equals(checkBillForm.getChannel())) {
                if (Constants.XLS.equals(cp.get(i)) || Constants.CSV.equals(cp.get(i))) {
                    return AnalyExcel.loadxlsNew(inputStream, checkBillForm, setting);
                } else {
                    return AnalyExcel.newLoadText(inputStream, checkBillForm, setting);
                }
            }
        }
        return null;
    }

    /**
     * 特殊文件解析
     *
     * @param checkBillForm
     * @return
     * @throws Exception
     */

    public List<BankTrans> getBankList(String channel, InputStream inputStream, CheckBillForm checkBillForm)
            throws Exception {
        //解析对账文件
        List<BankTrans> list = ChannelHandleMapping.handleInterface(checkBillForm.getChannel()).loadDate(inputStream, checkBillForm);
        return list;
    }

    /**
     * 上传文件
     *
     * @param checkBillForm
     * @return
     * @throws Exception
     */
    protected List<BankTrans> InputOtherList(String channel, CheckBillForm checkBillForm) throws Exception {
        List<BankTrans> list = new ArrayList<BankTrans>();
        //自动对账
        if (Constants.FLAG_1.equals(checkBillForm.getCheckType())) {
            for (InputStream inputStream : checkBillForm.getFileList()) {
                list.addAll(getBankList(channel, inputStream, checkBillForm));
            }
        } else {
            MultipartFile[] checkBillFile = checkBillForm.getCheckBillFile();
            for (int i = 0; i < checkBillFile.length; i++) {
                list.addAll(getBankList(channel, checkBillFile[i].getInputStream(), checkBillForm));//解析对账单文件
            }
        }
        return list;
    }

    public List<FileUploadRecord> getFileList(CheckBillForm checkBillForm, String userName) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Date startDate = format.parse(checkBillForm.getStartDate());
        Date endDate = format.parse(checkBillForm.getEndDate());
        String batchId = checkBillForm.getBatchId();
        Calendar ca = Calendar.getInstance();
        List<FileUploadRecord> list = new ArrayList<FileUploadRecord>();
        while (startDate.compareTo(endDate) <= 0) {
            ca.setTime(startDate);
            FileUploadRecord file = new FileUploadRecord();
            file.setChannel(checkBillForm.getChannel());
            file.setCheckDate(startDate);
            file.setCheckStatus(Constants.CHECK_STATUS_NORMAL);
            //自动对账
            if (Constants.FLAG_1.equals(checkBillForm.getCheckType())) {
                file.setFileName(checkBillForm.getFileName());
            } else {
                file.setFileName(checkBillForm.getCheckBillFile()[Constants.FLAG_default].getOriginalFilename());
            }
            //判读出金入金 1:出金 0:入金 2:网联
            if (Constants.FLAG_1.equals(checkBillForm.getBillType())) {
                file.setBillType(Constants.FLAG_1);
            } else if (Constants.FLAG_2.equals(checkBillForm.getBillType())) {
                file.setBillType(Constants.FLAG_0);
            }
            file.setUploader(userName);
            file.setUploadTime(new Date());
            list.add(file);
            ca.add(Calendar.DATE, 1);
            startDate = ca.getTime();
        }
        return list;
    }

    public List<FileUploadRecord> getNetsUnionFileList(CheckBillForm checkBillForm, String userName) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Date startDate = format.parse(checkBillForm.getStartDate());
        Date endDate = format.parse(checkBillForm.getEndDate());
        String batchId = checkBillForm.getBatchId();
        Calendar ca = Calendar.getInstance();
        List<FileUploadRecord> list = new ArrayList<FileUploadRecord>();
        while (startDate.compareTo(endDate) <= 0) {
            ca.setTime(startDate);
            FileUploadRecord file = new FileUploadRecord();
            file.setChannel(checkBillForm.getChannel());
            file.setCheckDate(startDate);
            file.setCheckStatus(Constants.CHECK_STATUS_NORMAL);
            //自动对账
            if (Constants.FLAG_1.equals(checkBillForm.getCheckType())) {
                file.setFileName(checkBillForm.getFileName());
            } else {
                file.setFileName(checkBillForm.getCheckBillFile()[Constants.FLAG_default].getOriginalFilename());
            }
            file.setBillType(Constants.FLAG_2);
            file.setUploader(userName);
            file.setUploadTime(new Date());
            file.setBatchId(batchId);
            list.add(file);
            ca.add(Calendar.DATE, 1);
            startDate = ca.getTime();
        }
        return list;
    }

    public List<CheckBill> getCheckList(CheckBillForm checkBillForm) {
        PageContext pg = new PageContext();
        pg.setPageSize(50);
        return checkBillMapper.getCheckList(checkBillForm);
    }

    public List<CheckBill> getToCheck(CheckBillForm CheckBillForm) {
        FileUploadRecord fileUploadRecord = new FileUploadRecord();
        fileUploadRecord.setChannel(CheckBillForm.getChannel());
        fileUploadRecord.setCheckDate(StringUtils.gettime(CheckBillForm.getCheckdate()));
        fileUploadRecord.setBillType(CheckBillForm.getBillType());
        CheckBill checkBill = checkBillMapper.getCheckBillByChannelCheckDate(fileUploadRecord);
        List<CheckBill> checkBillList = new ArrayList<CheckBill>();
        checkBillList.add(checkBill);
        return checkBillList;
    }

    public CheckBill getNetsUnionToCheck(CheckBillForm CheckBillForm) {
        Map map = new HashMap();
        map.put("checkdate", CheckBillForm.getCheckdate());
        map.put("batchId", CheckBillForm.getBatchId());
        CheckBill checkBill = checkBillMapper.getNetsUnionToCheck(map);
        return checkBill;
    }

    public void updateCheckStatus(List<FileUploadRecord> list) {
        for (int i = 0; i < list.size(); i++) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("toStatus", 1);
            map.put("checkDate", list.get(i).getCheckDate());
            map.put("channel", list.get(i).getChannel());
            map.put("billType", list.get(i).getBillType());
            checkBillMapper.updateCheckStatus(map);
        }
    }

    public void updateEpccCheckStatus(List<FileUploadRecord> list) {
        for (int i = 0; i < list.size(); i++) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("toStatus", 1);
            map.put("checkDate", list.get(i).getCheckDate());
            map.put("channel", list.get(i).getChannel());
            map.put("billType", list.get(i).getBillType());
            map.put("batchId", list.get(i).getBatchId());
            checkBillMapper.updateEpccCheckStatus(map);
        }
    }

    public void compareTrans(Integer id, String userName, Map<String, Object> maps, CheckBillForm checkBillForm) throws Exception {
        String channelName = maps.get("channel").toString();

        Map<String, List<String>> setting = transSetting(channelName.toUpperCase());
        if (setting.containsKey("NEW_FUNC") && !Constants.UPLOAD_SPECIAL_CHANNEL.contains(channelName)) {
            compareTransNew(id, userName, maps, setting);
        } else if (Constants.UPLOAD_EPCC.equals(channelName)) {
            maps.put("batchId", checkBillForm.getBatchId());
            compareTransNetsUnion(id, userName, maps);
        } else {
            compareTransOld(id, userName, maps);
        }
    }

    public void compareTransNetsUnion(Integer id, String userName, Map<String, Object> maps) throws Exception {
        //获取网联本地交易
        List<Map<String, Object>> localTrans = getLocalTransList(id, maps);
        //获取银行交易
        List<BankTrans> bankTrans;
        int inflatCount = 0;//不平账数量
        FileUploadRecord fileUploadRecord = new FileUploadRecord();
        fileUploadRecord.setBatchId(maps.get("batchId") == null ? "" : maps.get("batchId").toString());
        fileUploadRecord.setChannel(maps.get("channel") == null ? "" : maps.get("channel").toString());
        fileUploadRecord.setCheckDate(new SimpleDateFormat("yyyy-MM-dd").parse(maps.get("checkDate").toString()));
        fileUploadRecord = fileUploadRecordMapper.getRecordByBatchId(fileUploadRecord);
        maps.put("id", id);
        if(!Constants.AUTO_USER_NAME.equals(userName)){
            maps.put("uploadId", fileUploadRecord.getId());
        }
        bankTrans = bankTransMapper.getNetsUnionBankTrans(maps);

        // 查询上一对账日期的对账记录
        List<CheckBill> lastCheckBill = checkBillMapper.selectByChannelBatch(maps);
        if (lastCheckBill != null && lastCheckBill.size() > 0) {
            List<BankTrans> lastBankList;
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("id", id);
            map.put("reason", Constants.ADJUST_REASON_TRANS_HANGUP);
            map.put("channel", maps.get("channel"));
            List<Map<String, Object>> lastLocalList = getNetsUnionHungTrans(map);
            if (lastLocalList.size() > 0) {
                lastBankList = getNetsUnionHungUpBankTrans(maps);//获取网联挂起对账单交易
                if (lastBankList.size() > 0) {
                    // 挂起交易对账
                    inflatCount = compareNetsUnionHungUp(lastLocalList, lastBankList, id);
                }
            }
        }

        CheckBill checkBill = compareNetsUnion(localTrans, bankTrans, id);
        inflatCount = inflatCount + (checkBill.getInflatCount() == null ? 0 : checkBill.getInflatCount());
        checkBill.setInflatCount(inflatCount);
        // 单边账数目为0且银生宝金额等于银行金额，则无差额
        if (inflatCount == 0 && (Math.abs(checkBill.getLocalAmount() - checkBill.getBankAmount()) < 0.001)) {
            checkBill.setCheckStatus(Constants.CHECK_BILL_4);
        } else {// 对账完成
            checkBill.setCheckStatus(Constants.CHECK_BILL_3);
        }
        checkBill.setCheckUser(userName);
        checkBill.setCheckTime(new Date());
        fileUploadRecordMapper.updateNetsUnionCheckStatus(checkBill);
        checkBillMapper.updateByPrimaryKeySelective(checkBill);
    }

    private List<BankTrans> getNetsUnionHungUpBankTrans(Map maps){
        String checkdate = (String)maps.get("checkDate");
        List<BankTrans> bankTransList = bankTransMapper.getNetsUnionHungUpBankTrans(checkdate);
        return bankTransList;
    }

    /**
     * 网联交易正常对账
     *
     * @param localTransList
     * @param bankTransList
     * @param id
     */
    public CheckBill compareNetsUnion(List<Map<String, Object>> localTransList, List<BankTrans> bankTransList, Integer id) throws Exception {
        CheckBill checkBill = checkBillMapper.selectByPrimaryKey(Long.valueOf(id));
        FileUploadRecord fileUploadRecord = fileUploadRecordMapper.getByCheckBillBatch(checkBill);
        Double localAmount = getNetsUnionLocalAmount(localTransList);
        Double bankAmount = getNetsUnionBankAmount(bankTransList);
        checkBill.setLocalAmount(localAmount);
        checkBill.setBankAmount(bankAmount);
        List<CheckBillTransDetail> checkBillTransDetailList = new ArrayList<CheckBillTransDetail>();
        if (null == localTransList) {
            throw new Exception("本地无交易");
        }
        if (localTransList.size() > 0 && bankTransList.size() > 0) {
            checkBillTransDetailList = compareNetsUnionNormal(localTransList, bankTransList, checkBill,
                    fileUploadRecord.getFileName());
        }
        for (int i = 0; i < localTransList.size(); i++) {
            Map<String, Object> localTrans = localTransList.get(i);
            if (Constants.TRANS_STATUS_SUCCESS_EPCC.equals(localTrans.get("TRANS_STATUS"))
                    || Constants.TRANS_STATUS_PRE_SUCCESS_EPCC.equals(localTrans.get("TRANS_STATUS"))) {// 只统计我方成功银行无的交易
                CheckBillTransDetail checkBillTransDetail = new CheckBillTransDetail();
                checkBillTransDetail.setCheckDate((Date) localTrans.get("CHECK_DATE"));
                checkBillTransDetail.setChannel(localTrans.get("CHANNEL").toString());
                checkBillTransDetail.setChannelNo("");
                checkBillTransDetail.setLocalTransId(localTrans.get("TRANS_ID").toString());
                checkBillTransDetail.setCheckBillId(checkBill.getId().intValue());
                checkBillTransDetail.setLocalAmount(Double.valueOf(localTrans.get("TRANS_AMOUNT").toString()));
                checkBillTransDetail.setBankName(localTrans.get("BANK_NAME") == null ? "" : localTrans.get("BANK_NAME").toString());
                checkBillTransDetail.setCheckTransStatus(Constants.CHECK_STATUS_BANK_LACK);// 银行无我方有
                checkBillTransDetail.setDealFlag(Constants.CHECK_BILL_1);
                checkBillTransDetail.setTransDate(
                        (localTrans.get("CREATE_TIME") == null ? "" : localTrans.get("CREATE_TIME")).toString());
                checkBillTransDetail.setBatchId((String) localTrans.get("BATCH_ID"));
                checkBillTransDetail.setBankBusiType((String) localTrans.get("TRANS_TYPE"));
                checkBillTransDetail.setBankBusiStatus((String) localTrans.get("TRANS_STATUS"));
                checkBillTransDetail.setPayOrgIdSeq((String) localTrans.get("PAY_ORG_ID_SEQ"));
                checkBillTransDetail.setDestOrgIdSeq((String) localTrans.get("DEST_ORG_ID_SEQ"));
                checkBillTransDetail.setActionName(localTrans.get("ACTION_NAME") == null ? "" : localTrans.get("ACTION_NAME").toString());
                checkBillTransDetail.setFileName(fileUploadRecord.getFileName());
                checkBillTransDetail.setAccountName(localTrans.get("NAME") == null ? "" : localTrans.get("NAME").toString());
                checkBill.setInflatCount((checkBill.getInflatCount() == null ? 0 : checkBill.getInflatCount()) + 1);// 单边帐增加
                checkBillTransDetailList.add(checkBillTransDetail);
            }
        }
        // Log.info("第一轮对账完毕剩余银行清单数目：" + bankTransList.size());
        for (int i = 0; i < bankTransList.size(); i++) {
            BankTrans bankTrans = bankTransList.get(i);
            CheckBillTransDetail checkBillTransDetail = new CheckBillTransDetail();
            checkBillTransDetail.setCheckDate(bankTrans.getTransDate());
            checkBillTransDetail.setChannel(bankTrans.getChannel());
            checkBillTransDetail.setBankTransId(bankTrans.getBankTransId());
            checkBillTransDetail.setCheckBillId(checkBill.getId().intValue());
            checkBillTransDetail.setBankAmount(bankTrans.getAmount());
            checkBillTransDetail.setFileName(fileUploadRecord.getFileName());
            checkBillTransDetail.setCheckTransStatus(Constants.CHECK_STATUS_LOCAL_LACK);// 银行有我方无
            checkBillTransDetail.setDealFlag(Constants.CHECK_BILL_1);
            checkBillTransDetail.setBatchId(bankTrans.getBatchId());
            checkBillTransDetail.setBankBusiType(bankTrans.getBankBusiType());
            checkBillTransDetail.setBankBusiStatus(bankTrans.getBankBusiStatus());
            checkBillTransDetail.setPayOrgIdSeq(bankTrans.getPayOrgIdSeq());
            checkBillTransDetail.setDestOrgIdSeq(bankTrans.getDestOrgIdSeq());
            // 单边帐增加
            checkBill.setInflatCount((checkBill.getInflatCount() == null ? 0 : checkBill.getInflatCount()) + 1);
            checkBillTransDetailList.add(checkBillTransDetail);
        }

        if (checkBillTransDetailList.size() > 0) {
            List<List> list = StringUtils.getList(checkBillTransDetailList);
            for (List listNew : list) {
                checkBillTransDetailMapper.insertList(listNew);
            }
        }
        return checkBill;
    }

    // 网联正常对账
    private List<CheckBillTransDetail> compareNetsUnionNormal(List<Map<String, Object>> localTransList,
                                                              List<BankTrans> bankTransList, CheckBill checkBill, String fileName) throws Exception {
        // 从末尾开始遍历，便于移除已确认的交易
        List<CheckBillTransDetail> list = new ArrayList<CheckBillTransDetail>();
        for (int i = localTransList.size() - 1; i >= 0; i--) {
            CheckBillTransDetail checkBillTransDetail = new CheckBillTransDetail();
            Map<String, Object> localTrans = localTransList.get(i);
            String localTransId = localTrans.get("TRANS_ID").toString();

            // 从末尾开始遍历，便于移除已确认的交易
            for (int j = bankTransList.size() - 1; j >= 0; j--) {
                BankTrans bankTrans = bankTransList.get(j);
                String[] transIdArr = bankTrans.getTransId().split("\\|");

                // 订单号相同时，进行比较
                if (localTransId.equals(bankTrans.getTransId())) {
                    //如果网联交易需要比较批次号、付款所属机构编码、收款所属机构编码、交易状态、交易类型
                    if ((localTrans.containsKey("BATCH_ID") && localTrans.get("BATCH_ID").equals(bankTrans.getBatchId())
                            && localTrans.containsKey("PAY_ORG_ID_SEQ") && localTrans.get("PAY_ORG_ID_SEQ").equals(bankTrans.getPayOrgIdSeq())
                            && localTrans.containsKey("DEST_ORG_ID_SEQ") && localTrans.get("DEST_ORG_ID_SEQ").equals(bankTrans.getDestOrgIdSeq())
                            && localTrans.containsKey("TRANS_STATUS") && localTrans.get("TRANS_STATUS").equals(bankTrans.getBankBusiStatus())
                            && localTrans.containsKey("TRANS_TYPE") && localTrans.get("TRANS_TYPE").equals(bankTrans.getBankBusiType()))) {
                        checkBillTransDetail = compareNetsUnionDetail(localTrans, bankTrans, checkBill, fileName);
                        if (Constants.CHECK_STATUS_NORMAL.equals(checkBillTransDetail.getCheckTransStatus())) { // 平账
                            checkBill.setFlatCount((checkBill.getFlatCount() == null ? 0 : checkBill.getFlatCount()) + 1);
                        } else {// 单边账
                            checkBill.setInflatCount(
                                    (checkBill.getInflatCount() == null ? 0 : checkBill.getInflatCount()) + 1);
                        }
                        list.add(checkBillTransDetail);
                        // 移除已匹配的银生宝交易
                        localTransList.remove(i);
                        // 移除已匹配的银行交易
                        bankTransList.remove(j);
                    }
                }
            }
        }

        return list;
    }

    // 获取银行交易总金额
    protected Double getNetsUnionBankAmount(List<BankTrans> list) {
        double bankAmount = 0.0d;
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                BankTrans bankTrans = list.get(i);
                bankAmount += bankTrans.getAmount().doubleValue();
            }
        }
        return bankAmount;
    }

    protected Double getNetsUnionLocalAmount(List<Map<String, Object>> list) {
        double localAmount = 0.0d;
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                if (Constants.TRANS_STATUS_SUCCESS_EPCC.equals(list.get(i).get("TRANS_STATUS"))
                        || Constants.TRANS_STATUS_PRE_SUCCESS_EPCC.equals(list.get(i).get("TRANS_STATUS"))) {
                    localAmount += Double.valueOf(list.get(i).get("TRANS_AMOUNT").toString());
                }
            }
        }
        return localAmount;
    }

    public void compareTransOld(Integer id, String userName, Map<String, Object> maps) throws Exception {
        // 获取本地交易，代扣表数据
        List<Map<String, Object>> localTrans = getLocalTransList(id, maps);
        // 获取银行交易(对账日期对账单的所有交易)
        List<BankTrans> bankTrans = null;
        int inflatCount = 0;
        String channelName = maps.get("channel").toString();
        if (channelName.equals(Constants.UPLOAD_CHANNEL) || channelName.equals(Constants.UPLOAD_CHANNEL_B)
                || channelName.equals(Constants.UPLOAD_CHANNEL_C)) {
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("id", id);
            bankTrans = bankTransMapper.getBankTransInActTypes(params);
        } else {
            Map<String, Object> params = CreateSearchMap(channelName, id);
            if (null != params) {
                bankTrans = bankTransMapper.getBankTransInActListVal(params);
            } else {
                //cncb_b2c特殊处理
                if (Constants.UPLOAD_CNCB_B2C.equals(channelName)) {
                    bankTrans = bankTransMapper.getCnbcB2cBankTrans(id);
                } else if (ChannelConstants.CHANNEL_UNIONPAY_XM_DP.equals(channelName)){
                    bankTrans = bankTransMapper.getUnionpayXmDpTrans(id);
                } else {
                    bankTrans = bankTransMapper.getBankTrans(id);
                }
            }
        }
        // 查询上一对账日期的对账记录
        CheckBill lastCheckBill = checkBillMapper.selectByChannel(maps);
        if (lastCheckBill != null) {// 如果存在则考虑挂起交易对账问题
            // 获取 通道前一对账日期挂起的交易：我方有银行无(交易挂起)
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("id", id);
            map.put("reason", Constants.ADJUST_REASON_TRANS_HANGUP);
            map.put("channel", maps.get("channel"));
            map.put("billType", maps.get("billType"));
            // 获取前一对账日期审核通过的挂起交易
            List<Map<String, Object>> lastLocalList = getHungTrans(map);
            if (lastLocalList.size() > 0) {// 前一天有挂起交易
                List<BankTrans> lastBankList;
                lastBankList = getLastBankList(bankTrans, id);// 分离对账单内上一对账日期和当前对账日期的交易
                // 挂起交易对账
                if (lastBankList.size() > 0) {
                    // 挂起交易对账
                    inflatCount = compareHangUp(lastLocalList, lastBankList, lastCheckBill);
                }
            }
        }
        CheckBill checkBill = compare(channelName, localTrans, bankTrans, id);
        inflatCount = inflatCount + (checkBill.getInflatCount() == null ? 0 : checkBill.getInflatCount());
        checkBill.setInflatCount(inflatCount);
        // 单边账数目为0且银生宝金额等于银行金额，则无差额
        if (inflatCount == 0 && (Math.abs(checkBill.getLocalAmount() - checkBill.getBankAmount()) < 0.001)) {
            checkBill.setCheckStatus(Constants.CHECK_BILL_4);
        } else {// 对账完成
            checkBill.setCheckStatus(Constants.CHECK_BILL_3);
        }
        checkBill.setCheckUser(userName);
        checkBill.setCheckTime(new Date());
        fileUploadRecordMapper.updateCheckStatus(checkBill);
        checkBillMapper.updateByPrimaryKeySelective(checkBill);
    }

    public void compareTransNew(Integer id, String userName, Map<String, Object> maps,
                                Map<String, List<String>> setting) throws Exception {
        // 获取本地交易，代扣表数据
        List<Map<String, Object>> localTrans = getLocalTransListNew(id, maps, setting);
        // 获取银行交易(对账日期对账单的所有交易)
        List<BankTrans> bankTrans = null;
        String channelName = maps.get("channel").toString();
        Map<String, Object> params = CreateSearchMapNew(id, setting);

        if (null == (bankTrans = BizMapping.findBizBaseInterface(channelName).readBizBank(params))) {
            bankTrans = bankTransMapper.getBankTransInActListVal(params);
        }

        // 查询上一对账日期的对账记录
        CheckBill lastCheckBill = checkBillMapper.selectByChannel(maps);
        int inflatCount = 0;
        if (lastCheckBill != null) {// 如果存在则考虑挂起交易对账问题
            // 获取 通道前一对账日期挂起的交易：我方有银行无(交易挂起)
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("id", id);
            map.put("reason", Constants.ADJUST_REASON_TRANS_HANGUP);
            map.put("channel", maps.get("channel"));

            // 获取前一对账日期审核通过的挂起交易
            List<Map<String, Object>> lastLocalList = upadjustApplyMapper.getHandUpTrans(map);

            if (lastLocalList.size() > 0) {// 前一天有挂起交易
                List<BankTrans> lastBankList = getLastBankListNew(bankTrans, id, channelName);// 分离对账单内上一对账日期和当前对账日期的交易
                // 挂起交易对账
                if (lastBankList.size() > 0) {
                    // 挂起交易对账
                    inflatCount = compareHangUp(lastLocalList, lastBankList, lastCheckBill);
                }
            }
        }
        CheckBill checkBill = compare(channelName, localTrans, bankTrans, id);

        inflatCount = inflatCount + (checkBill.getInflatCount() == null ? 0 : checkBill.getInflatCount());
        checkBill.setInflatCount(inflatCount);
        // 单边账数目为0且银生宝金额等于银行金额，则无差额
        if (inflatCount == 0 && (Math.abs(checkBill.getLocalAmount() - checkBill.getBankAmount()) < 0.001)) {
            checkBill.setCheckStatus(Constants.CHECK_BILL_4);
        } else {// 对账完成
            checkBill.setCheckStatus(Constants.CHECK_BILL_3);
        }
        checkBill.setCheckUser(userName);
        checkBill.setCheckTime(new Date());
        fileUploadRecordMapper.updateCheckStatus(checkBill);
        checkBillMapper.updateByPrimaryKeySelective(checkBill);
    }

    protected Map<String, Object> CreateSearchMapNew(int id, Map<String, List<String>> setting) {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", id);
        params.put("actionTypes", null);
        params.put("channelTypes", null);

        if (setting.containsKey("ACTION_LIST")) {
            params.put("actionTypes", setting.get("ACTION_LIST"));
        }

        if (setting.containsKey("CHANNEL_LIST")) {
            params.put("channelTypes", setting.get("CHANNEL_LIST"));
        }

        return params;
    }

    /**
     * 创建查询对象
     *
     * @param channelName
     * @param id
     * @return
     */
    protected Map<String, Object> CreateSearchMap(String channelName, int id) {
        String actionStr = DynamicConfigLoader
                .getByEnv(String.format("UNSPAY_TRANS_%s_ACTION_LIST", channelName.toUpperCase()));
        String channelStr = DynamicConfigLoader
                .getByEnv(String.format("UNSPAY_TRANS_%s_CHANNEL_LIST", channelName.toUpperCase()));

        if (null == actionStr && null == channelStr) {
            return null;
        }

        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", id);
        params.put("actionTypes", null);
        params.put("channelTypes", null);

        if (null != actionStr) {
            List<String> actionTypes = StringUtils.getSplit2List(actionStr, "\\|");
            params.put("actionTypes", actionTypes);
        }

        if (null != channelStr) {
            List<String> channelTypes = StringUtils.getSplit2List(channelStr, "\\|");
            params.put("channelTypes", channelTypes);
        }
        return params;
    }

    @SuppressWarnings("rawtypes")
    public CheckBill compare(String channelName, List<Map<String, Object>> localTransList, List<BankTrans> bankTransList, Integer id) throws Exception {
        CheckBill checkBill = checkBillMapper.selectByPrimaryKey(Long.valueOf(id));
        FileUploadRecord fileUploadRecord = fileUploadRecordMapper.getByCheckBill(checkBill);
        Double localAmount = getLocalAmount(localTransList);
        Double bankAmount = getBankAmount(bankTransList);
        checkBill.setLocalAmount(localAmount);
        checkBill.setBankAmount(bankAmount);
        // 如果本地交易清单或银行交易清单有一方无记录，则第一轮一般性比较不用进行
        // 否则进行第一轮一般性比较
        // Log.info("第一轮对账本地清单数目：" + localTransList.size());
        // Log.info("第一轮对账银行清单数目：" + bankTransList.size());
        List<CheckBillTransDetail> checkBillTransDetailList = new ArrayList<CheckBillTransDetail>();
        if (null == localTransList) {
            throw new Exception("本地无交易");
        }
        if (localTransList.size() > 0 && bankTransList.size() > 0) {
            checkBillTransDetailList = compareNormal(channelName, localTransList, bankTransList, checkBill,
                    fileUploadRecord.getFileName());
        }

        // 第一轮一般性比较完成后，本地交易清单和银行交易清单中剩余的交易为多出的交易
        // 整合多余交易清单
        //		// Log.info("第一轮对账完毕剩余本地清单数目：" + localTransList.size());

        for (int i = 0; i < localTransList.size(); i++) {
            Map<String, Object> localTrans = localTransList.get(i);
            if (Constants.TRANS_STATUS_SUCCESS.equals(localTrans.get("TRANS_STATUS"))) {// 只统计我方成功银行无的交易
                CheckBillTransDetail checkBillTransDetail = new CheckBillTransDetail();
                checkBillTransDetail.setCheckDate((Date) localTrans.get("CHECK_DATE"));
                checkBillTransDetail.setChannel(localTrans.get("CHANNEL").toString());
                checkBillTransDetail.setBankName(localTrans.get("BANK_NAME").toString());
                checkBillTransDetail.setActionName(localTrans.get("ACTION_NAME").toString());
                // TODO 通道商户号
                checkBillTransDetail.setChannelNo("");
                if (localTrans.get("TRANS_ID").toString().length() < 15 && localTrans.get("CHANNEL").equals("cncb_b2c")) {
                    checkBillTransDetail.setLocalTransId(StringUtils.getStringTime((Date) localTrans.get("CHECK_DATE"))
                            + localTrans.get("TRANS_ID").toString());
                } else {
                    checkBillTransDetail.setLocalTransId(localTrans.get("TRANS_ID").toString());
                }
                // 商户名称
                if (null != localTrans.get("NAME")) {
                    checkBillTransDetail.setAccountName(localTrans.get("NAME").toString());
                }
                checkBillTransDetail.setCheckBillId(checkBill.getId().intValue());
                checkBillTransDetail.setLocalAmount(Double.valueOf(localTrans.get("AMOUNT").toString()));
                // checkBillTransDetail.setFileName(fileUploadRecord.getFileName());
                checkBillTransDetail.setCheckTransStatus(Constants.CHECK_STATUS_BANK_LACK);// 银行无我方有
                checkBillTransDetail.setDealFlag(Constants.CHECK_BILL_1);
                checkBillTransDetail.setTransDate(
                        (localTrans.get("END_DATE") == null ? "" : localTrans.get("END_DATE")).toString());
                checkBill.setInflatCount((checkBill.getInflatCount() == null ? 0 : checkBill.getInflatCount()) + 1);// 单边帐增加
                checkBillTransDetailList.add(checkBillTransDetail);
            }
        }
        // Log.info("第一轮对账完毕剩余银行清单数目：" + bankTransList.size());
        for (int i = 0; i < bankTransList.size(); i++) {
            BankTrans bankTrans = bankTransList.get(i);
            CheckBillTransDetail checkBillTransDetail = new CheckBillTransDetail();
            // TODO 对账日期
            checkBillTransDetail.setCheckDate(bankTrans.getTransDate());
            checkBillTransDetail.setChannel(bankTrans.getChannel());
            if (bankTrans.getTransId().length() < 15 && bankTrans.getChannel().equals("cncb_b2c")) {
                checkBillTransDetail
                        .setBankTransId(StringUtils.getStringTime(bankTrans.getTransTime()) + bankTrans.getTransId());
            } else {
                checkBillTransDetail.setBankTransId(bankTrans.getTransId());
            }
            checkBillTransDetail.setCheckBillId(checkBill.getId().intValue());
            checkBillTransDetail.setBankAmount(bankTrans.getAmount());
            // TODO
            checkBillTransDetail.setFileName(fileUploadRecord.getFileName());
            checkBillTransDetail.setCheckTransStatus(Constants.CHECK_STATUS_LOCAL_LACK);// 银行有我方无
            checkBillTransDetail.setDealFlag(Constants.CHECK_BILL_1);
            // 单边帐增加
            checkBill.setInflatCount((checkBill.getInflatCount() == null ? 0 : checkBill.getInflatCount()) + 1);
            checkBillTransDetailList.add(checkBillTransDetail);
        }

        if (checkBillTransDetailList.size() > 0) {
            List<List> list = StringUtils.getList(checkBillTransDetailList);
            for (List listNew : list) {
                checkBillTransDetailMapper.insertList(listNew);
            }
        }
        return checkBill;
    }

    protected Double getLocalAmount(List<Map<String, Object>> list) {
        double localAmount = 0.0d;
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                if (Constants.TRANS_STATUS_SUCCESS.equals(list.get(i).get("TRANS_STATUS"))) {
                    localAmount += Double.valueOf(list.get(i).get("AMOUNT").toString());
                }
            }
        }
        return localAmount;
    }


    // 获取银行交易总金额
    protected Double getBankAmount(List<BankTrans> list) {
        double bankAmount = 0.0d;
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                BankTrans bankTrans = list.get(i);
                bankAmount += bankTrans.getAmount().doubleValue();
            }
        }
        return bankAmount;
    }

    // 对账
    private List<CheckBillTransDetail> compareNormal(String channelName, List<Map<String, Object>> localTransList,
                                                     List<BankTrans> bankTransList, CheckBill checkBill, String fileName) throws Exception {
        //TODO 对账
        // 从末尾开始遍历，便于移除已确认的交易
        List<CheckBillTransDetail> list = new ArrayList<CheckBillTransDetail>();
        for (int i = localTransList.size() - 1; i >= 0; i--) {
            CheckBillTransDetail checkBillTransDetail = new CheckBillTransDetail();
            Map<String, Object> localTrans = localTransList.get(i);
            String localTransId = localTrans.get("TRANS_ID").toString();
            String localOrderId = "";
            if (null != localTrans.get("ORDER_ID")) {
                localOrderId = localTrans.get("ORDER_ID").toString();
            }

            // 从末尾开始遍历，便于移除已确认的交易
            for (int j = bankTransList.size() - 1; j >= 0; j--) {
                BankTrans bankTrans = bankTransList.get(j);
                String[] transIdArr = bankTrans.getTransId().split("\\|");
                if (transIdArr.length > 1) { //厦门民生扫码交易
                    if (localOrderId.equals(transIdArr[0])) {
                        localTransId = localOrderId;
                        bankTrans.setTransId(transIdArr[0]);
                    } else if (localTransId.equals(transIdArr[1])) {
                        bankTrans.setTransId(transIdArr[1]);
                    }
                }

                // 订单号相同时，进行比较
                if (localTransId.equals(bankTrans.getTransId()) || localOrderId.equals(bankTrans.getTransId())) {
                    {
                        checkBillTransDetail = compareDetail(localTrans, bankTrans, checkBill, fileName);
                        if (Constants.CHECK_STATUS_NORMAL.equals(checkBillTransDetail.getCheckTransStatus())) { // 平账
                            checkBill.setFlatCount((checkBill.getFlatCount() == null ? 0 : checkBill.getFlatCount()) + 1);
                        } else {// 单边账
                            checkBill.setInflatCount(
                                    (checkBill.getInflatCount() == null ? 0 : checkBill.getInflatCount()) + 1);
                        }
                        list.add(checkBillTransDetail);
                        // 移除已匹配的银生宝交易
                        localTransList.remove(i);
                        // 移除已匹配的银行交易
                        bankTransList.remove(j);
                    }
                }
            }
        }

        return list;
    }

    // 挂起交易对账
    private void compareHangUpNormal(List<Map<String, Object>> localTransList, List<BankTrans> bankTransList,
                                     CheckBill checkBill, String fileName, CheckBill checkBillNew) throws Exception {
        //TODO 挂起交易对账
        for (int i = localTransList.size() - 1; i >= 0; i--) {
            Map<String, Object> localTrans = localTransList.get(i);
            String localTransId = localTrans.get("TRANS_ID").toString();
            String localOrderId = "";
            if (null != localTrans.get("ORDER_ID")) {
                localOrderId = localTrans.get("ORDER_ID").toString();
            }
            // 从末尾开始遍历，便于移除已确认的交易
            for (int j = bankTransList.size() - 1; j >= 0; j--) {
                BankTrans bankTrans = bankTransList.get(j);
                //判断是否厦门民生扫码交易
                String[] transIdArr = bankTrans.getTransId().split("\\|");
                if (transIdArr.length > 1) { //厦门民生扫码交易
                    if (localOrderId.equals(transIdArr[0])) {
                        localTransId = localOrderId;
                        bankTrans.setTransId(transIdArr[0]);
                    } else if (localTransId.equals(transIdArr[1])) {
                        bankTrans.setTransId(transIdArr[1]);
                    }
                }

                // 订单号相同时，进行比较
                if (localTransId.equals(bankTrans.getTransId()) || localOrderId.equals(bankTrans.getTransId())) {
                    if (bankTrans.getTransId().length() < 15 && bankTrans.getChannel().equals("cncb_b2c")) {
                        localTransId = StringUtils.getStringTime(bankTrans.getTransTime()) + bankTrans.getTransId();
                    }
                    CheckBillTransDetail checkBillTransDetail = checkBillTransDetailMapper
                            .getDetailByLocalTransId(localTrans.get("TRANS_ID").toString());
                    checkBillTransDetail = compareHangUpDetail(localTrans, bankTrans, checkBill.getId().intValue(),
                            fileName, checkBillTransDetail);
                    if (Constants.CHECK_STATUS_NORMAL.equals(checkBillTransDetail.getCheckTransStatus())) { // 如果对账后转平帐：本地有银行无转平帐
                        // 平帐数增加
                        checkBill.setFlatCount((checkBill.getFlatCount() == null ? 0 : checkBill.getFlatCount()) + 1);


                        // 已处理数目增加
                        checkBillNew.setDealInflatCount(
                                (checkBillNew.getDealInflatCount() == null ? 0 : checkBillNew.getDealInflatCount()) + 1);
                        checkBillNew.setBankAmount(
                                checkBillNew.getBankAmount() == null ? 0 : checkBillNew.getBankAmount() + checkBillTransDetail.getBankAmount().doubleValue());
                        checkBillNew.setLocalAmount(
                                checkBillNew.getLocalAmount() == null ? 0 : checkBillNew.getBankAmount() + checkBillTransDetail.getLocalAmount().doubleValue());
                    } else {// 单边账

                    }
                    // 移除已匹配的银生宝交易
                    localTransList.remove(i);
                    // 移除已匹配的银行交易
                    bankTransList.remove(j);
                    checkBillTransDetail.setCheckDate(checkBillNew.getCheckDate());
                    checkBillTransDetailMapper.updateByPrimaryKeySelective(checkBillTransDetail);
                    // 跟新上比交易记录
                }
            }
        }
    }

    /**
     * 比较一条本地交易与一条银行交易
     */
    private CheckBillTransDetail compareDetail(Map<String, Object> localTrans, BankTrans bankTrans, CheckBill checkBill,
                                               String fileName) {
        CheckBillTransDetail checkBillTransDetail = new CheckBillTransDetail();
        checkBillTransDetail.setCheckDate(checkBill.getCheckDate());
        checkBillTransDetail.setChannel(bankTrans.getChannel());
        checkBillTransDetail
                .setBankName(localTrans.get("BANK_NAME") == null ? "" : localTrans.get("BANK_NAME").toString());
        checkBillTransDetail
                .setActionName(localTrans.get("ACTION_NAME") == null ? "" : localTrans.get("ACTION_NAME").toString());
        // TODO 通道商户号
        checkBillTransDetail.setChannelNo("");
        checkBillTransDetail
                .setLocalTransId(localTrans.get("TRANS_ID") == null ? "" : localTrans.get("TRANS_ID").toString());
        checkBillTransDetail.setBankTransId(bankTrans.getTransId());
        // TODO 交易商户名称
        checkBillTransDetail.setAccountName(localTrans.get("NAME") == null ? "" : localTrans.get("NAME").toString());
        checkBillTransDetail.setCheckBillId(checkBill.getId().intValue());
        checkBillTransDetail.setLocalAmount(Double.valueOf(localTrans.get("AMOUNT").toString()));
        checkBillTransDetail.setBankAmount(bankTrans.getAmount());
        checkBillTransDetail.setFileName(fileName);
        checkBillTransDetail
                .setTransDate((localTrans.get("END_DATE") == null ? "" : localTrans.get("END_DATE")).toString());
        if (!Constants.TRANS_STATUS_SUCCESS.equals(localTrans.get("TRANS_STATUS").toString())) {// 如果交易状态不成功
            // 银行有我方无
            checkBillTransDetail.setCheckTransStatus(Constants.CHECK_STATUS_LOCAL_LACK);
            checkBillTransDetail.setDealFlag(Constants.CHECK_BILL_1);
        } else if (Math.abs(checkBillTransDetail.getLocalAmount().doubleValue()
                - checkBillTransDetail.getBankAmount().doubleValue()) > 0.0001) {
            // 金额不对
            checkBillTransDetail.setCheckTransStatus(Constants.CHECK_STATUS_AMOUNT_ERROR);
            checkBillTransDetail.setDealFlag(Constants.CHECK_BILL_1);
        } else {// 正常对账
            checkBillTransDetail.setCheckTransStatus(Constants.CHECK_STATUS_NORMAL);
            checkBillTransDetail.setDealFlag(Constants.CHECK_BILL_0);
        }
        checkBillTransDetail.setTransType(localTrans.get("TRANS_TYPE") == null ? 0 : Integer.valueOf(localTrans.get("TRANS_TYPE").toString()));
        return checkBillTransDetail;
    }

    /**
     * 网联单条交易比较
     */
    private CheckBillTransDetail compareNetsUnionDetail(Map<String, Object> localTrans, BankTrans bankTrans, CheckBill checkBill,
                                                        String fileName) {
        CheckBillTransDetail checkBillTransDetail = new CheckBillTransDetail();
        /*checkBillTransDetail.setAccountName(localTrans.get("NAME") == null ? "" : localTrans.get("NAME").toString());*/
        checkBillTransDetail.setCheckDate(checkBill.getCheckDate());
        checkBillTransDetail.setChannel(bankTrans.getChannel());
        checkBillTransDetail
                .setActionName(localTrans.get("ACTION_NAME") == null ? "" : localTrans.get("ACTION_NAME").toString());
        checkBillTransDetail.setAccountName(localTrans.get("NAME") == null ? "" : localTrans.get("NAME").toString());
        checkBillTransDetail.setChannelNo("");
        checkBillTransDetail
                .setLocalTransId(localTrans.get("TRANS_ID") == null ? "" : localTrans.get("TRANS_ID").toString());
        checkBillTransDetail.setBankTransId(bankTrans.getBankTransId());
        checkBillTransDetail.setBankName(localTrans.get("BANK_NAME") == null ? "" : localTrans.get("BANK_NAME").toString());
        checkBillTransDetail.setCheckBillId(checkBill.getId().intValue());
        checkBillTransDetail.setLocalAmount(Double.valueOf(localTrans.get("TRANS_AMOUNT").toString()));
        checkBillTransDetail.setBankAmount(bankTrans.getAmount());
        checkBillTransDetail.setFileName(fileName);
        checkBillTransDetail
                .setTransDate((localTrans.get("CREATE_TIME") == null ? "" : localTrans.get("CREATE_TIME")).toString());
        checkBillTransDetail.setBatchId(bankTrans.getBatchId());
        checkBillTransDetail.setBankBusiType(bankTrans.getBankBusiType());
        checkBillTransDetail.setBankBusiStatus(bankTrans.getBankBusiStatus());
        checkBillTransDetail.setPayOrgIdSeq(bankTrans.getPayOrgIdSeq());
        checkBillTransDetail.setDestOrgIdSeq(bankTrans.getDestOrgIdSeq());
        if (!Constants.TRANS_STATUS_SUCCESS_EPCC.equals(localTrans.get("TRANS_STATUS").toString())
                && !Constants.TRANS_STATUS_PRE_SUCCESS_EPCC.equals(localTrans.get("TRANS_STATUS").toString())) {// 如果交易状态不成功
            // 银行有我方无
            checkBillTransDetail.setCheckTransStatus(Constants.CHECK_STATUS_LOCAL_LACK);
            checkBillTransDetail.setDealFlag(Constants.CHECK_BILL_1);//未处理
        } else if (Math.abs(checkBillTransDetail.getLocalAmount().doubleValue()
                - checkBillTransDetail.getBankAmount().doubleValue()) > 0.0001) {
            // 金额不对
            checkBillTransDetail.setCheckTransStatus(Constants.CHECK_STATUS_AMOUNT_ERROR);
            checkBillTransDetail.setDealFlag(Constants.CHECK_BILL_1);//未处理
        } else {// 正常对账
            checkBillTransDetail.setCheckTransStatus(Constants.CHECK_STATUS_NORMAL);
            checkBillTransDetail.setDealFlag(Constants.CHECK_BILL_0);//正常对账
        }
        checkBillTransDetail.setTransType(localTrans.get("TRANS_TYPE") == null ? 0 : Integer.valueOf(localTrans.get("TRANS_TYPE").toString()));
        return checkBillTransDetail;
    }

    /**
     * 比较一条本地交易与一条银行交易,挂起对账
     *
     * @return
     */
    private CheckBillTransDetail compareHangUpDetail(Map<String, Object> localTrans, BankTrans bankTrans,
                                                     Integer checkBillId, String fileName, CheckBillTransDetail checkBillTransDetail) throws Exception {
        try {
            checkBillTransDetail.setBankTransId(bankTrans.getTransId());
            checkBillTransDetail.setBankAmount(bankTrans.getAmount());
            checkBillTransDetail.setFileName(fileName);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (!Constants.TRANS_STATUS_SUCCESS.equals(localTrans.get("TRANS_STATUS").toString())) {// 本地交易状态不成功
            // 该交易对账状态为：银行有我方无
            checkBillTransDetail.setCheckTransStatus(Constants.CHECK_STATUS_LOCAL_LACK);
            checkBillTransDetail.setDealFlag(Constants.CHECK_BILL_1);
        } else if (Math.abs(checkBillTransDetail.getLocalAmount().doubleValue()
                - checkBillTransDetail.getBankAmount().doubleValue()) > 0.0001) {
            // 金额不对
            checkBillTransDetail.setCheckTransStatus(Constants.CHECK_STATUS_AMOUNT_ERROR);
            checkBillTransDetail.setDealFlag(Constants.CHECK_BILL_1);
        } else {
            // 正常对账
            checkBillTransDetail.setCheckTransStatus(Constants.CHECK_STATUS_NORMAL);
            checkBillTransDetail.setDealFlag(Constants.CHECK_BILL_2);
        }
        // 更新数据
        return checkBillTransDetail;
    }

    private void isGeneratedRecord(List<FileUploadRecord> list) throws BusinessException {

        for (int i = 0; i < list.size(); i++) {
            CheckBill checkBill = checkBillMapper.getCheckBillByChannelCheckDate(list.get(i));
            if (checkBill == null) {
                throw new BusinessException(ExceptionDefine.您选择的对账日期还未生成对账记录请在生成对账记录后再上传);
            }
        }
        for (int i = 0; i < list.size(); i++) {
            FileUploadRecord record = fileUploadRecordMapper.getRecordByChannelCheckDate(list.get(i));
            if (record != null) {
                throw new BusinessException(ExceptionDefine.您选择的对账日期的对账文件已上传);
            }
        }

    }

    private void isGeneratedEpccRecord(List<FileUploadRecord> list) throws BusinessException {

        for (int i = 0; i < list.size(); i++) {
            CheckBill checkBill = checkBillMapper.getCheckBillByBatch(list.get(i));
            if (checkBill == null) {
                checkBill = checkBillMapper.getCheckBillByNullBatch(list.get(i));
                if (checkBill == null) {
                    throw new BusinessException(ExceptionDefine.您选择的对账日期还未生成对账记录请在生成对账记录后再上传);
                }
            }
        }
        for (int i = 0; i < list.size(); i++) {
            FileUploadRecord record = fileUploadRecordMapper.getRecordByBatchId(list.get(i));
            if (record != null) {
                throw new BusinessException(ExceptionDefine.您选择的对账日期的对账文件已上传);
            }
        }

    }

    public CheckBill getDetailById(Long id) {

        return checkBillMapper.selectByPrimaryKey(id);
    }

    public void updateRemark(CheckBill checkBill) {
        checkBillMapper.updateByPrimaryKeySelective(checkBill);
    }

    public void updateCheckStatus(String checkDate, String channel) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("checkDate", checkDate);
        map.put("channel", channel);
        checkBillMapper.updateCheckStatusByRecordId(map);
    }

    public void updateNetsUnionCheckStatus(CheckBillForm checkBillForm) {
        checkBillMapper.updateNetsUnionCheckStatus(checkBillForm);
    }

    public List<BankTrans> getLastBankListNew(List<BankTrans> bankList, Integer id, String channel) throws Exception {
        CheckBill cb = checkBillMapper.selectByPrimaryKey(Long.valueOf(id));
        List<BankTrans> lastBankList = new ArrayList<BankTrans>();
        for (int i = 0; i < bankList.size(); i++) {
            // 交易日期在上一对账日期范围内，当前对账单包含上上对账日期的交易的情况暂不考虑
            try {
                if (BizMapping.findBizBaseInterface(channel).checkHandUp(bankList.get(i), cb)) {
                    lastBankList.add(bankList.get(i));
                    bankList.remove(i);
                    i--;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return lastBankList;
    }

    // 根据交易时间把银行对账单分为 当前对账列表 和上一对账列表
    public List<BankTrans> getLastBankList(List<BankTrans> bankList, Integer id) {
        CheckBill cb = checkBillMapper.selectByPrimaryKey(Long.valueOf(id));
        // 当前对账日期
        Date checkDate = cb.getCheckDate();
        // 当前时间以前的对账日期交易
        List<BankTrans> lastBankList = new ArrayList<BankTrans>();
        for (int i = 0; i < bankList.size(); i++) {
            if (bankList.get(i).getTransTime().getTime() < checkDate.getTime()) {
                lastBankList.add(bankList.get(i));
                bankList.remove(i);
                i--;
            }
        }
        return lastBankList;
    }

    // 挂起交易对账
    @SuppressWarnings("rawtypes")
    public int compareHangUp(List<Map<String, Object>> localTransList, List<BankTrans> bankTransList,
                             CheckBill checkBill) throws Exception {
        FileUploadRecord fileUploadRecord = fileUploadRecordMapper.getByCheckBill(checkBill);
        List<CheckBillTransDetail> checkBillTransDetailList = new ArrayList<CheckBillTransDetail>();
        int inflat = 0;
        Map map = new HashMap();
        map.put("check_date", new SimpleDateFormat("yyyy-MM-dd").format(checkBill.getCheckDate()));
        map.put("channel", checkBill.getChannel());
        CheckBill checkBillNew = checkBillMapper.selectByMap(map);
        if (null != fileUploadRecord) {
            compareHangUpNormal(localTransList, bankTransList, checkBill, fileUploadRecord.getFileName(), checkBillNew);
            // Log.info("第一轮对账完毕剩余银行清单数目：" + bankTransList.size());

            for (int i = 0; i < bankTransList.size(); i++) {
                BankTrans bankTrans = bankTransList.get(i);
                CheckBillTransDetail checkBillTransDetail = new CheckBillTransDetail();
                // TODO 对账日期
                checkBillTransDetail.setCheckDate(bankTrans.getTransDate());
                checkBillTransDetail.setChannel(bankTrans.getChannel());
                if (bankTrans.getTransId().length() < 15 && bankTrans.getChannel().equals("cncb_b2c")) {
                    checkBillTransDetail.setBankTransId(bankTrans.getTransDate() + "_" + bankTrans.getTransId());
                } else {
                    checkBillTransDetail.setBankTransId(bankTrans.getTransId());
                }
                checkBillTransDetail.setCheckBillId(checkBill.getId().intValue());
                checkBillTransDetail.setBankAmount(bankTrans.getAmount());
                // TODO
                checkBillTransDetail.setFileName(fileUploadRecord.getFileName());
                checkBillTransDetail.setCheckTransStatus(Constants.CHECK_STATUS_LOCAL_LACK);// 银行有我方无
                checkBillTransDetail.setDealFlag(Constants.FLAG_1);
                //checkBillTransDetail.setTransDate(bankTrans.getTransTime().toString());
                checkBillTransDetailList.add(checkBillTransDetail);
                inflat = inflat + 1;
            }
            if (checkBillTransDetailList.size() > 0) {
                // 保存每笔交易对账详情
                List<List> list = StringUtils.getList(checkBillTransDetailList);
                for (List listNew : list) {
                    checkBillTransDetailMapper.insertList(listNew);
                }
            }
        }
        checkBillMapper.updateByPrimaryKeySelective(checkBillNew);
        checkBillMapper.updateByPrimaryKeySelective(checkBill);
        return inflat;
    }

    /**
     * 网联挂起交易对账
     *
     * @param localTransList
     * @param bankTransList
     * @param id
     */
    public int compareNetsUnionHungUp(List<Map<String, Object>> localTransList, List<BankTrans> bankTransList, Integer id) throws Exception {
        CheckBillTransDetail checkBillTransDetail;
        String localTransId;
        String bankTransId;
        Map<String, Object> paramMap = new HashMap<>();
        CheckBill checkBill;
        CheckBill checkBillNew = checkBillMapper.selectByPrimaryKey(id);
        int inflat = 0;
        List<CheckBillTransDetail> checkBillTransDetailList = new ArrayList<CheckBillTransDetail>();
        paramMap.put("id", id);
        for (int i = 0; i < localTransList.size(); i++) {
            for (int j = bankTransList.size() - 1; j >= 0; j--) {
                Map<String, Object> localTrans = localTransList.get(i);
                BankTrans bankTrans = bankTransList.get(j);
                localTransId = (String) localTrans.get("TRANS_ID");
                bankTransId = bankTrans.getTransId();
                if (localTransId.equals(bankTransId)) {
                    //如果网联交易需要比较批次号、付款所属机构编码、收款所属机构编码、交易状态、交易类型
                    if ((localTrans.containsKey("BATCH_ID") && localTrans.get("BATCH_ID").equals(bankTrans.getBatchId())
                            && localTrans.containsKey("PAY_ORG_ID_SEQ") && localTrans.get("PAY_ORG_ID_SEQ").equals(bankTrans.getPayOrgIdSeq())
                            && localTrans.containsKey("DEST_ORG_ID_SEQ") && localTrans.get("DEST_ORG_ID_SEQ").equals(bankTrans.getDestOrgIdSeq())
                            && localTrans.containsKey("TRANS_STATUS") && localTrans.get("TRANS_STATUS").equals(bankTrans.getBankBusiStatus())
                            && localTrans.containsKey("TRANS_TYPE") && localTrans.get("TRANS_TYPE").equals(bankTrans.getBankBusiType()))) {
                        String batchId = (String) localTrans.get("BATCH_ID");
                        paramMap.put("batchId", batchId);
                        //根据批次号查询上一日对账记录
                        checkBill = checkBillMapper.getCheckBillByBatchLastDate(paramMap);
                        checkBillTransDetail = compareNetsUnionDetail(localTrans, bankTrans, checkBillNew, bankTrans.getFileName());
                        if (Constants.CHECK_STATUS_NORMAL.equals(checkBillTransDetail.getCheckTransStatus())) { // 平账
                            checkBill.setDealInflatCount((checkBill.getDealInflatCount() == null ? 0 : checkBill.getDealInflatCount()) + 1);
                            checkBill.setFlatCount((checkBill.getFlatCount() == null ? 0 : checkBill.getFlatCount()) + 1);
                        } else {// 单边账
                            inflat += 1;
                            checkBill.setInflatCount(
                                    (checkBill.getInflatCount() == null ? 0 : checkBill.getInflatCount()) + 1);
                        }
                        checkBillMapper.updateByPrimaryKeySelective(checkBill);
                        checkBillTransDetailList.add(checkBillTransDetail);
                        paramMap.put("transId",localTrans.get("TRANS_ID"));
                        paramMap.put("bankTransId", bankTrans.getBankTransId());
                        paramMap.put("bankTransAmount", bankTrans.getAmount());
                        paramMap.put("payOrgIdSeq", bankTrans.getPayOrgIdSeq());
                        paramMap.put("destOrgIdSeq", bankTrans.getDestOrgIdSeq());
                        paramMap.put("checkdate",checkBillNew.getCheckDate());
                        checkBillTransDetailMapper.updateOldEpccDetail(paramMap);
                        paramMap.put("localTransId", localTrans.get("ID"));
                        UpadjustApply upadjustApply = upadjustApplyMapper.getNetsUnionByTransSeq(paramMap);
                        upadjustApply.setBankTransId(bankTrans.getBankTransId());
                        upadjustApplyMapper.updateByPrimaryKeySelective(upadjustApply);
                        // 移除已匹配的银生宝交易
                        localTransList.remove(i--);
                        // 移除已匹配的银行交易
                        bankTransList.remove(j--);
                    }
                }
            }
            if (checkBillTransDetailList.size() > 0) {
                List<List> list = StringUtils.getList(checkBillTransDetailList);
                for (List listNew : list) {
                    checkBillTransDetailMapper.insertList(listNew);
                }
            }
            checkBillMapper.updateByPrimaryKeySelective(checkBillNew);
        }
        return inflat;
    }

    // 获取前一日审核挂起的交易
    public List<Map<String, Object>> getHungTrans(Map map) {
        List<Map<String, Object>> lastLocalList = null;
        lastLocalList = upadjustApplyMapper.getHandUpTrans(map);
        return lastLocalList;
    }

    // 获取网联挂起交易
    public List<Map<String, Object>> getNetsUnionHungTrans(Map map) {
        List<Map<String, Object>> lastLocalList = upadjustApplyMapper.getNestUnionHungUpTrans(map);
        return lastLocalList;
    }

    public List<Map<String, Object>> getLocalTransListNew(Integer id, Map<String, Object> maps,
                                                          Map<String, List<String>> setting) {
        Map<String, Object> pareMap = CreateSearchMapNew(id, setting);
        String channel = maps.get("channel").toString();
        pareMap.put("channel", channel);
        List<Map<String, Object>> localTrans = null;
        try {
            if (null == (localTrans = BizMapping.findBizBaseInterface(channel).readBizValue(id, maps, setting))) {
                localTrans = checkBillMapper.getTransMapNew(pareMap);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return localTrans;
    }

    /**
     * 获取本地交易
     *
     * @param id
     * @param maps
     * @return
     */
    public List<Map<String, Object>> getLocalTransList(Integer id, Map<String, Object> maps) throws Exception {
        //TODO 获取本地交易
        List<Map<String, Object>> list = ChannelHandleMapping.handleInterface(maps.get("channel").toString()).getLocalTrans(id);
        return list;
    }

    /**
     * 获取银生宝B2B交易
     *
     * @param id
     * @param maps
     * @return
     */
    public List<Map<String, Object>> getB2bTrans(Integer id, Map<String, Object> maps) {
        List<Map<String, Object>> localTrans = null;
        Map<String, Object> pareMap = new HashMap<String, Object>();
        switch (maps.get("channel").toString()) {
            case Constants.UPLOAD_ICBC_B2B:
                pareMap.put("id", id);
                pareMap.put("channel", Constants.UPLOAD_ICBC.split(","));
                pareMap.put("actionType", Constants.UPLOAD_UPOP_B2B_ACTIONTYPE);
                localTrans = checkBillMapper.getB2BTrans(pareMap);
                break;
            case Constants.UPLOAD_CEB_B2B:
                pareMap.put("id", id);
                pareMap.put("channel", Constants.UPLOAD_CEB_KJ.split(","));
                pareMap.put("actionType", Constants.UPLOAD_UPOP_B2B_ACTIONTYPE);
                localTrans = checkBillMapper.getB2BTrans(pareMap);
                break;
        }
        return localTrans;

    }

    /**
     * 获取代扣通道
     *
     * @param channel
     * @param str
     * @return
     */
    public List<String> getChannelType(String channel, String str) {
        List<String> channelType = Arrays.asList(str.split(","));
        List<String> channelList = new ArrayList<String>();
        String channels;
        for (int i = 0; i < channelType.size(); i++) {
            if (channelType.get(i).contains(channel)) {
                channels = channelType.get(i);
                if (channelType.get(i).contains(Constants.CHECK_BILL_DK) || Constants.CHECK_BILL_DK.contains(channelType.get(i))) {
                    channels = channelType.get(i).substring(0, channel.length() - 3);
                }
                channelList.add(channels);
            }
        }
        if (channel.equals(Constants.UPLOAD_UNIONPAY_XM_DK)) {
            channelList = Arrays.asList(Constants.UPLOAD_UNIONPAY_XM_DK_CHANNEL.split(","));
        }
        if (channel.equals(Constants.UPLOAD_PINGAN_DK)) {
            channelList = Arrays.asList(Constants.UPLOAD_PINGAN_CHANEL.split(","));
        }
        if (channel.equals(Constants.UPLOAD_SPDB_DK)) {
            channelList = Arrays.asList(Constants.UPLOAD_SPDB_CHANNEL.split(","));
        }
        if (channel.equals(Constants.UPLOAD_UNIONPAY_TD)) {
            channelList.remove(Constants.UPLOAD_UNIONPAY_TD2);
        }
        if (channel.equals(Constants.UPLOAD_UNIONPAY)) {
            channelList = Arrays.asList(Constants.UPLOAD_UNIONPAY_CHANNEL.split(","));
        }
        if (channel.equals(Constants.UPLOAD_CHANNEL)) {
            channelList = Arrays.asList(Constants.UPLOAD_EGB_CHANNEL.split(","));
        }
        if (channel.equals(Constants.UPLOAD_CHANNEL_B)) {
            channelList = Arrays.asList(Constants.UPLOAD_EGB_CHANNEL_B.split(","));
        }
        if (channel.equals(Constants.UPLOAD_CHANNEL_C)) {
            channelList.clear();
            channelList.add(channel);
        }
        if (channel.equals(Constants.UPLOAD_YILIAN_DK)) {
            channelList = Arrays.asList(Constants.UPLOAD_YILIAN_DK_CHANEL.split(","));
        }
        return channelList;
    }

    /**
     * 同步网关交易
     *
     * @param checkdate
     * @return
     */
    public Map autoSyncTrans(String checkdate) {
        //删除已有同步交易
        transRefMapper.delDataOfCheckdate(checkdate);
        //删除提现订单表已经同步的交易
        transRefMapper.delTxDataOfCheckDate(checkdate);
        xmBankMapper.delXmbankOfCheckdate(checkdate);
        List<WithdrawOrder> txTransList;//提现交易数据
        List<EpccDpTransRef> epccDpTransRefList;//代付
        List<EpccAuthpayTransRef> epccAuthpayTransRefList;//认证支付
        List<EpccDcTransRef> epccDcTransRefList;//商业委托代扣
        List<EpccGatewayTransRef> epccGatewayTransRefList;//网关支付B2C/B2B
        List<EpccQpTransRef> epccQpTransRefList;//协议支付快捷
        List<XmBank> xmBankList; //厦门银联代付交易
        Integer count;//总条数
        int allCount = Constants.FLAG_default;//所有交易的总条数统计（返回给job）
        Integer pageNum = Constants.NETSUNION_PAGENUM;
        Map<String, String> paramMap = new HashMap<>();
        Map<String, String> hashMap;
        try {
            log.info("同步unionpay_xm_dp交易=============开始");
            DynamicDataSourceHolder.setDataSourceType(Constants.DATASOURCE_INSTANCE.WL_DF.name());
            count = Integer.valueOf(xmBankMapper.getXmbankTransCount(checkdate));
            allCount += count;
            for (int i = 0; i <= (count / pageNum); i++) {
                paramMap = createParamMap(paramMap, checkdate, i, pageNum, count);
                xmBankList = xmBankMapper.getXmbankTrans(paramMap);
                if (null != xmBankList && xmBankList.size() > 0){
                    List<List> list = StringUtils.getList(xmBankList);
                    for (List<XmBank> subList : list) {
                        DynamicDataSourceHolder.setDataSourceType(Constants.DATASOURCE_INSTANCE.DK_VNV.name());
                        xmBankMapper.insertXmBank(subList);
                        DynamicDataSourceHolder.setDataSourceType(Constants.DATASOURCE_INSTANCE.WL_DF.name());
                    }
                }
            }
            log.info("同步unionpay_xm_dp交易=============结束");

        	log.info("同步新提现交易===============>开始！");
            //同步新提现交易
            DynamicDataSourceHolder.setDataSourceType(Constants.DATASOURCE_INSTANCE.CK_DATA_SOURCE.name());
            count = Integer.valueOf(epccDpTransRefMapper.getNewTxCheckTransCount(checkdate));
            allCount += count;
            for (int i = 0; i <= (count / pageNum); i++) {
                paramMap = createParamMap(paramMap, checkdate, i, pageNum, count);
                txTransList = withDrawOrderMapper.getTxTrans(paramMap);//获取新提现交易数据
                if (null != txTransList && txTransList.size() != 0) {
                    List<List> list = StringUtils.getList(txTransList);
                    for (List<WithdrawOrder> sublist : list) {
                        DynamicDataSourceHolder.setDataSourceType(Constants.DATASOURCE_INSTANCE.DK_VNV.name());
                        withDrawOrderMapper.insertTxTable(sublist);
                        DynamicDataSourceHolder.setDataSourceType(Constants.DATASOURCE_INSTANCE.CK_DATA_SOURCE.name());
                    }
                }
            }
            log.info("同步新提现交易===============>结束！");

            log.info("同步网联代付===============>开始！");
            //同步网联代付
            DynamicDataSourceHolder.setDataSourceType(Constants.DATASOURCE_INSTANCE.WL_DF.name());
            count = Integer.valueOf(epccDpTransRefMapper.getNetsUnionCheckTransCount(checkdate));
            allCount += count;
            for (int i = 0; i <= (count / pageNum); i++) {
                paramMap = createParamMap(paramMap, checkdate, i, pageNum, count);
                epccDpTransRefList = epccDpTransRefMapper.getNetsUnionCheckTrans(paramMap);
                if (null != epccDpTransRefList && epccDpTransRefList.size() != 0) {
                    List<List> list = StringUtils.getList(epccDpTransRefList);
                    for (List<EpccDpTransRef> sublist : list) {
                        DynamicDataSourceHolder.setDataSourceType(Constants.DATASOURCE_INSTANCE.DK_VNV.name());
                        transRefMapper.insertFromEpccDp(sublist);
                        DynamicDataSourceHolder.setDataSourceType(Constants.DATASOURCE_INSTANCE.WL_DF.name());
                    }
                }
            }
            log.info("同步网联代付===============>结束！");

            log.info("同步认证支付===============>开始！");
            //同步认证支付
            DynamicDataSourceHolder.setDataSourceType(Constants.DATASOURCE_INSTANCE.GATEWAY.name());
            count = Integer.valueOf(epccAuthpayTransRefMapper.getNetsUnionCheckTransCount(checkdate));
            allCount += count;
            for (int i = 0; i <= (count / pageNum); i++) {
                paramMap = createParamMap(paramMap, checkdate, i, pageNum, count);
                epccAuthpayTransRefList = epccAuthpayTransRefMapper.getNetsUnionCheckTrans(paramMap);
                if (null != epccAuthpayTransRefList && epccAuthpayTransRefList.size() != 0) {
                    List<List> list = StringUtils.getList(epccAuthpayTransRefList);
                    for (List<EpccAuthpayTransRef> sublist : list) {
                        DynamicDataSourceHolder.setDataSourceType(Constants.DATASOURCE_INSTANCE.DK_VNV.name());
                        transRefMapper.insertFromEpccAuthpay(sublist);
                        DynamicDataSourceHolder.setDataSourceType(Constants.DATASOURCE_INSTANCE.GATEWAY.name());
                    }
                }
            }
            log.info("同步认证支付===============>结束！");

            log.info("同步商业委托代扣===============>开始！");
            //同步商业委托代扣
            DynamicDataSourceHolder.setDataSourceType(Constants.DATASOURCE_INSTANCE.GATEWAY.name());
            count = Integer.valueOf(epccDcTransRefMapper.getNetsUnionCheckTransCount(checkdate));
            allCount += count;
            for (int i = 0; i <= (count / pageNum); i++) {
                paramMap = createParamMap(paramMap, checkdate, i, pageNum, count);
                epccDcTransRefList = epccDcTransRefMapper.getNetsUnionCheckTrans(paramMap);
                if (null != epccDcTransRefList && epccDcTransRefList.size() != 0) {
                    List<List> list = StringUtils.getList(epccDcTransRefList);
                    for (List<EpccDcTransRef> sublist : list) {
                        DynamicDataSourceHolder.setDataSourceType(Constants.DATASOURCE_INSTANCE.DK_VNV.name());
                        transRefMapper.insertFromEpccDc(sublist);
                        DynamicDataSourceHolder.setDataSourceType(Constants.DATASOURCE_INSTANCE.GATEWAY.name());
                    }
                }
            }
            log.info("同步商业委托代扣===============>结束！");

            log.info("同步协议支付快捷===============>开始！");
            //同步协议支付快捷
            DynamicDataSourceHolder.setDataSourceType(Constants.DATASOURCE_INSTANCE.GATEWAY.name());
            count = Integer.valueOf(epccQpTransRefMapper.getNetsUnionCheckTransCount(checkdate));
            allCount += count;
            for (int i = 0; i <= (count / pageNum); i++) {
                paramMap = createParamMap(paramMap, checkdate, i, pageNum, count);
                epccQpTransRefList = epccQpTransRefMapper.getNetsUnionCheckTrans(paramMap);
                if (null != epccQpTransRefList && epccQpTransRefList.size() != 0) {
                    List<List> list = StringUtils.getList(epccQpTransRefList);
                    for (List<EpccQpTransRef> sublist : list) {
                        DynamicDataSourceHolder.setDataSourceType(Constants.DATASOURCE_INSTANCE.DK_VNV.name());
                        transRefMapper.insertFromEpccQp(sublist);
                        DynamicDataSourceHolder.setDataSourceType(Constants.DATASOURCE_INSTANCE.GATEWAY.name());
                    }
                }
            }
            log.info("同步协议支付快捷===============>结束！");

            log.info("同步网关支付B2C/B2B===============>开始！");
            //同步网关支付B2C/B2B
            DynamicDataSourceHolder.setDataSourceType(Constants.DATASOURCE_INSTANCE.GATEWAY.name());
            count = Integer.valueOf(epccGatewayTransRefMapper.getNetsUnionCheckTransCount(checkdate));
            allCount += count;
            for (int i = 0; i <= (count / pageNum); i++) {
                paramMap = createParamMap(paramMap, checkdate, i, pageNum, count);
                epccGatewayTransRefList = epccGatewayTransRefMapper.getNetsUnionCheckTrans(paramMap);
                if (null != epccGatewayTransRefList && epccGatewayTransRefList.size() != 0) {
                    List<List> list = StringUtils.getList(epccGatewayTransRefList);
                    for (List<EpccGatewayTransRef> sublist : list) {
                        DynamicDataSourceHolder.setDataSourceType(Constants.DATASOURCE_INSTANCE.DK_VNV.name());
                        transRefMapper.insertFromEpccGateway(sublist);
                        DynamicDataSourceHolder.setDataSourceType(Constants.DATASOURCE_INSTANCE.GATEWAY.name());
                    }
                }
            }
            log.info("同步网关支付B2C/B2B===============>结束！");
        } catch (Exception e) {
            e.printStackTrace();
            DynamicDataSourceHolder.clearDataSourceType();//还原数据源
            //删除已有同步交易
            transRefMapper.delDataOfCheckdate(checkdate);
            log.info("同步网联关联交易===============>异常！");
        } finally {
            DynamicDataSourceHolder.clearDataSourceType();//还原数据源
        }
        hashMap = new HashMap();
        hashMap.put("transCount", String.valueOf(allCount));
        return hashMap;
    }

    /**
     * 创建关联表查询属性map
     *
     * @param paramMap
     * @param checkdate
     * @param i
     * @param pageNum
     * @param count
     * @return
     */
    private Map createParamMap(Map paramMap, String checkdate, int i, Integer pageNum, Integer count) {
        paramMap.put("checkdate", checkdate);
        paramMap.put("pagenumStart", String.valueOf(i * pageNum));
        if (i == (count / pageNum)) {
            paramMap.put("pagenumEnd", String.valueOf(i * pageNum + pageNum + 1));
        } else {
            paramMap.put("pagenumEnd", String.valueOf(i * pageNum + pageNum));
        }
        return paramMap;
    }

    public  List<String> getAllBatch(String checkdate){
        return checkBillMapper.getAllBatch(checkdate);
    }

    public CheckBill getEpccRecord(CheckBillForm checkBillForm){
        return checkBillMapper.getCheckBillByFileBatch(checkBillForm);
    }
}
