package com.uns.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.dao.SysFunctionMapper;
import com.uns.model.SysFunction;

@Service
public class SysFunctionService {

	@Autowired
	private SysFunctionMapper sysFunctionMapper;

	public Map getUserMenu(Long id) throws Exception {
		List allFunctionList = sysFunctionMapper.getUserMenu(id);
		return generateMenu(allFunctionList);
	}

	@SuppressWarnings({ "unused", "rawtypes" })
	private Map getMenu(List<SysFunction> list) {
		Map<Long, SysFunction> allMap = new HashMap<Long, SysFunction>();
		Map<SysFunction, List<List<SysFunction>>> dataMap = new LinkedHashMap<SysFunction, List<List<SysFunction>>>();
		for (Iterator<SysFunction> iter = list.iterator(); iter.hasNext();) {
			SysFunction func = (SysFunction) iter.next();
			allMap.put(func.getId(), func);
		}

		for (int i = 0; i < list.size(); i++) {
			SysFunction func = list.get(i);
			if (func.getParentId() == 1) {
				for (int j = 0; j < list.size(); j++) {
					List value = new ArrayList();

				}
			}
		}

		return null;
	}

	// 根据树型结构整理功能菜单
	private Map generateMenu(List listFunctions) {
		Map<Long, SysFunction> allMap = new HashMap<Long, SysFunction>();
		Map mapReturn = new HashMap();
		// 第一次遍历,取根列表
		Long curId = null;
		Long parId = null;
		Map<SysFunction, List<SysFunction>> dataMap = new LinkedHashMap<SysFunction, List<SysFunction>>();
		List<SysFunction> subList = null;

		for (Iterator iter = listFunctions.iterator(); iter.hasNext();) {
			SysFunction func = (SysFunction) iter.next();
			curId = func.getId();
			allMap.put(curId, func);
			parId = func.getParentId();
			if (parId == null) {
				dataMap.put(func, new ArrayList<SysFunction>());
			}
		}
		for (Iterator iter = listFunctions.iterator(); iter.hasNext();) {
			SysFunction func = (SysFunction) iter.next();
			curId = func.getId();
			parId = func.getParentId();
			if (parId != null) {
				subList = dataMap.get(allMap.get(parId));
				if (subList == null) {
                    subList = new ArrayList<SysFunction>();
                }
				subList.add(func);
				dataMap.put(allMap.get(parId), subList);
			}
		}
		return dataMap;
	}

}
