package com.uns.dao;

import com.uns.model.EpccQpTransRef;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface EpccQpTransRefMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(EpccQpTransRef record);

    int insertSelective(EpccQpTransRef record);

    EpccQpTransRef selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(EpccQpTransRef record);

    int updateByPrimaryKey(EpccQpTransRef record);

    List<EpccQpTransRef> getNetsUnionCheckTrans(Map paramMap);

    String getNetsUnionCheckTransCount(String checkdate);

}