package com.uns.util;

import com.uns.common.Constants;
import com.uns.dao.ActionTypeMapper;
import com.uns.model.ActionType;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/8/29
 * @Modifyed By:
 */
public class ActionTypeUtils {

    private static ActionTypeMapper actionTypeMapper = SpringContextHolder.getBean(ActionTypeMapper.class);

    public static List<ActionType> getActionTypeList() {
        try {
            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
            HttpSession session = request.getSession();
            List<ActionType> actionTypes = (List<ActionType>) session.getAttribute(Constants.ACTIONTYPELIST_SESSIONKEY);
            if (null == actionTypes || actionTypes.size() <= 0) {
                actionTypes = actionTypeMapper.selectAllAction();
                session.setAttribute(Constants.ACTIONTYPELIST_SESSIONKEY, actionTypes);
            }
            return actionTypes;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
