package com.uns.dao;

import com.uns.model.EpccGatewayTransRef;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface EpccGatewayTransRefMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(EpccGatewayTransRef record);

    int insertSelective(EpccGatewayTransRef record);

    EpccGatewayTransRef selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(EpccGatewayTransRef record);

    int updateByPrimaryKey(EpccGatewayTransRef record);

    List<EpccGatewayTransRef> getNetsUnionCheckTrans(Map paramMap);

    String getNetsUnionCheckTransCount(String checkdate);

}