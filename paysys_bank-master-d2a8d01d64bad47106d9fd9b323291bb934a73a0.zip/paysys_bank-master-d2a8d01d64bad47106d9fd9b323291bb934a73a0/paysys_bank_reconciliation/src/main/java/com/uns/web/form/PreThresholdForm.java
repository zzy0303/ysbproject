package com.uns.web.form;

import java.math.BigDecimal;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/12/22
 * @Modifyed By:
 */
public class PreThresholdForm {
    private BigDecimal sumAmountC;
    private BigDecimal sumWaitAmountC;
    private BigDecimal sumWaitAmountYC;
    private BigDecimal sumWaitAmountTC;
    private String accountIdC;
    private String accountNameC;
    private Integer countC;
    private BigDecimal sumFeeC;
    private String checkDateC;
    private String countParamC;
    private String checkedId;

    public BigDecimal getSumAmountC() {
        return sumAmountC;
    }

    public void setSumAmountC(BigDecimal sumAmountC) {
        this.sumAmountC = sumAmountC;
    }

    public BigDecimal getSumWaitAmountC() {
        return sumWaitAmountC;
    }

    public void setSumWaitAmountC(BigDecimal sumWaitAmountC) {
        this.sumWaitAmountC = sumWaitAmountC;
    }

    public BigDecimal getSumWaitAmountYC() {
        return sumWaitAmountYC;
    }

    public void setSumWaitAmountYC(BigDecimal sumWaitAmountYC) {
        this.sumWaitAmountYC = sumWaitAmountYC;
    }

    public BigDecimal getSumWaitAmountTC() {
        return sumWaitAmountTC;
    }

    public void setSumWaitAmountTC(BigDecimal sumWaitAmountTC) {
        this.sumWaitAmountTC = sumWaitAmountTC;
    }

    public String getAccountIdC() {
        return accountIdC;
    }

    public void setAccountIdC(String accountIdC) {
        this.accountIdC = accountIdC;
    }

    public String getAccountNameC() {
        return accountNameC;
    }

    public void setAccountNameC(String accountNameC) {
        this.accountNameC = accountNameC;
    }

    public Integer getCountC() {
        return countC;
    }

    public void setCountC(Integer countC) {
        this.countC = countC;
    }

    public BigDecimal getSumFeeC() {
        return sumFeeC;
    }

    public void setSumFeeC(BigDecimal sumFeeC) {
        this.sumFeeC = sumFeeC;
    }

    public String getCheckDateC() {
        return checkDateC;
    }

    public void setCheckDateC(String checkDateC) {
        this.checkDateC = checkDateC;
    }

    public String getCountParamC() {
        return countParamC;
    }

    public void setCountParamC(String countParamC) {
        this.countParamC = countParamC;
    }

    public String getCheckedId() {
        return checkedId;
    }

    public void setCheckedId(String checkedId) {
        this.checkedId = checkedId;
    }
}
