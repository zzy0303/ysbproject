package com.uns.datasourceSwitch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SuppressWarnings({"unchecked","rawtypes"})
public class DynamicDataSourceHolder {
	
//	获得和设置上下文环境 主要负责改变上下文数据源的名称 
	private static final ThreadLocal contextHolder = new ThreadLocal();
	private static Logger log = LoggerFactory.getLogger(DynamicDataSourceHolder.class);

	public static void setDataSourceType(String dataSourceType) {
		log.info("==============数据源切换为："+dataSourceType);
		contextHolder.set(dataSourceType);
	}

	public static String getDataSourceType() {
		return (String) contextHolder.get();
	}

	public static void clearDataSourceType() {
		log.info("==============数据源还原为默认数据源。");
		contextHolder.remove();
	}
	
}
