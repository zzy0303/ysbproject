package com.uns.channel;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

import com.uns.common.Constants;
import com.uns.model.BankTrans;
import com.uns.util.AnalyExcel;
import com.uns.web.form.CheckBillForm;

public class ChannelHandleYifubao extends ChannelHandleDefault implements ChannelHandleInterface{

	@Override
	public List<BankTrans> loadDate(InputStream inputStream, CheckBillForm checkBillForm) throws Exception {
		return AnalyExcel.loadYifubaoText(inputStream, checkBillForm, Constants.UPLOAD_YIFUBAO_DK_TXT);
	}

	@Override
	public List<Map<String, Object>> getLocalTrans(Integer id) throws Exception {
		pareMap.put("channelType",
				checkBillService.getChannelType(Constants.UPLOAD_YIFUBAO, Constants.PARAM_CHECK_BILL_DK_CHANNEL));
		pareMap.put("id", id);
		localTrans = checkBillMapper.getDkTransAll(pareMap);
		localTrans.addAll(checkBillMapper.getLocalAuthTrans(pareMap));// 实名认证数据
		//新代扣交易
		localTrans.addAll(checkBillMapper.getlocalNewDkTrans(pareMap));
		//获取unionpay_b2b交易
		pareMap.put("actionType", Constants.UPLOAD_B2B_ACTIONTYPE);
		pareMap.put("channel",Constants.UPLOAD_UNIONPAY_B2B);
		localTrans.addAll( checkBillMapper.getUnionpayB2BTrans(pareMap));
		return localTrans;
	}

	@Override
	public Map<String, Object> getLocalAmount(String channel, String checkDate) {
		return null;
	}

	@Override
	public List<String> getChannelList() throws Exception {
		return null;
	}
	
}
