package com.uns.model;

import java.math.BigDecimal;
import java.util.Date;

public class WhiteAccount {
    private BigDecimal id;

    private String accountId;

    private String name;

    private String actionName;

    private String userName;

    private BigDecimal accountSubSeq;

    private BigDecimal actionSeq;

    private String reason;

    private BigDecimal operUserId;

    private Date operTime;

    private String status;

    private String statuStr;

    public String getStatuStr() {
        return statuStr;
    }

    public void setStatuStr(String statuStr) {
        this.statuStr = statuStr;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getActionName() {
        return actionName;
    }

    public void setActionName(String actionName) {
        this.actionName = actionName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public BigDecimal getAccountSubSeq() {
        return accountSubSeq;
    }

    public void setAccountSubSeq(BigDecimal accountSubSeq) {
        this.accountSubSeq = accountSubSeq;
    }

    public BigDecimal getActionSeq() {
        return actionSeq;
    }

    public void setActionSeq(BigDecimal actionSeq) {
        this.actionSeq = actionSeq;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason == null ? null : reason.trim();
    }

    public BigDecimal getOperUserId() {
        return operUserId;
    }

    public void setOperUserId(BigDecimal operUserId) {
        this.operUserId = operUserId;
    }

    public Date getOperTime() {
        return operTime;
    }

    public void setOperTime(Date operTime) {
        this.operTime = operTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }
}