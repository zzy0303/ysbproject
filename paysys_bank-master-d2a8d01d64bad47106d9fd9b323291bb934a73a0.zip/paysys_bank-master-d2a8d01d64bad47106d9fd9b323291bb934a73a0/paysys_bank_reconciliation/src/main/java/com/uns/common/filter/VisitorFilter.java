package com.uns.common.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class VisitorFilter implements Filter {

	@Override
    public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain arg2)
			throws IOException, ServletException {
		// TODO Auto-generated method stub

	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub

	}
	/*
	 * 
	 * OperateLogService operateLogService; List<MtOperatepermit> list=new
	 * ArrayList<MtOperatepermit>();
	 * 
	 * @Override public void init(FilterConfig fc) throws ServletException { //
	 * ApplicationContext context = new ClassPathXmlApplicationContext(new
	 * String[]{"applicationContext.xml"}); ApplicationContext ctx =
	 * WebApplicationContextUtils
	 * .getRequiredWebApplicationContext(fc.getServletContext());
	 * operateLogService = (OperateLogService) ctx.getBean("operateLogService");
	 * list = operateLogService.selectAccesspermitList(); }
	 * 
	 * @Override public void destroy() { // TODO Auto-generated method stub
	 * 
	 * }
	 * 
	 * @Override public void doFilter(ServletRequest req, ServletResponse res,
	 * FilterChain fc) throws IOException, ServletException { final
	 * HttpServletRequest request = (HttpServletRequest) req; final HttpSession
	 * session = request.getSession(); if(list==null||request==null){
	 * fc.doFilter(req, res); return; }
	 * 
	 * // String url=request.getRequestURI(); // String despator =
	 * request.getRequestDispatcher(); String url = request.getServletPath();
	 * String method = request.getParameter("method"); url =
	 * url+"?method="+method; for(int i=0;i<list.size();i++){
	 * if(url.equals(list.get(i).getUrl())){ MtOperatepermit accessPermit =
	 * list.get(i); Map<String,String[]> params=new
	 * HashMap(request.getParameterMap()); String
	 * remoteIP=request.getRemoteHost(); //���ʵ�IP Operator
	 * sessionUser=(Operator)session.getAttribute(Constants.SESSION_KEY_USER);
	 * //�ͻ��˴���������� String opername=null; if(sessionUser==null){ opername =
	 * request.getParameter("username"); String password =
	 * request.getParameter("password"); String verycode =
	 * request.getParameter("verycode"); if(opername==null||password==null){
	 * fc.doFilter(req, res); return; } String loginResult[] = new String[1];
	 * loginResult[0] = operateLogService.validateOper(opername,
	 * password,verycode); params.put("loginResult", loginResult); }else{
	 * opername = sessionUser.getUserName(); } String permitId=
	 * list.get(i).getPermitid(); MtOperateLog accesslog = new MtOperateLog();
	 * String uuid = UUID.randomUUID().toString(); uuid = uuid.replaceAll("-",
	 * ""); accesslog.setLogid(uuid); accesslog.setOperatornum(opername);
	 * accesslog.setTime(StringUtils.getToday());
	 * accesslog.setPermitid(accessPermit.getPermitid());
	 * accesslog.setIp(remoteIP); String param= params2String(params);
	 * accesslog.setParams(param); boolean state =
	 * operateLogService.insertAccesslog(accesslog); if(state==false){
	 * fc.doFilter(req, res); return; } } }
	 * 
	 * fc.doFilter(req, res); return; }
	 * 
	 * private String params2String( Map<String,String[]> params){ String param
	 * = null; if(params!=null){ for(String key:params.keySet()){
	 * if(params.get(key)!=null){ String tmp = params.get(key)[0];
	 * if(key.equals("password")){ tmp="******"; } param = param +key+"="+ tmp +
	 * " ; "; } } if(param.length()>1) param = param.substring(0,
	 * param.length()-1); } return param; }
	 * 
	 */}
