package com.uns.biz;

import java.util.List;
import java.util.Map;

import com.uns.model.BankTrans;
import com.uns.web.form.CheckBillForm;

public class SpdbDkBiz extends DefaultBiz{
	//代收标志 
	protected static final String SPDB_DK_FLAG_1 = "1";
	
	public boolean checkInputData(String[] data, CheckBillForm checkBillForm, BankTrans trans,
			Map<String, List<String>> setting) throws Exception {
		
		if(data[11].equals(SPDB_DK_FLAG_1)){
			return false;
		}
		
		return super.checkInputData(data, checkBillForm, trans, setting);
	}
}
