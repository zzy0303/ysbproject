package com.uns.model;

import java.math.BigDecimal;
import java.util.Date;

public class Transaction {
	private BigDecimal id;

	private String orderId;

	private String transId;

	private BigDecimal actionSeq;

	private BigDecimal creditSeq;

	private BigDecimal debitSeq;

	private BigDecimal amount;

	private String currency;

	private BigDecimal exchangeRate;

	private String tradeType;

	private String transStatus;

	private String insideStatus;

	private String bankResponse;

	private Date beginDate;

	private Date endDate;

	private BigDecimal creditRatioSeq;

	private BigDecimal debitRatioSeq;

	private BigDecimal bankSeq;

	private BigDecimal debitFee;

	private BigDecimal creditFee;

	private BigDecimal accountBankSeq;

	private String cardNo;

	private String bankName;

	private BigDecimal bankProvSeq;

	private BigDecimal bankCitySeq;

	private String personName;

	private String personMail;

	private String personPhone;

	private String personMobile;

	private String remark;

	private String verifyCode;

	private String sellerUrl;

	private String commodityInfo;

	private String sellerParam;

	private String desFlag;

	private String mac;

	private String reverseFlag;

	private BigDecimal relatingSeq;

	private BigDecimal vnvAccountSeq;

	private String serviceFlag;

	private Date serviceDate;

	private String servicePerson;

	private String barcode;

	private String operSource;

	private BigDecimal version;

	private String createUser;

	private Date createTime;

	private String updateUser;

	private Date updateTime;

	private String updateUserSystem;

	private String encryptcode;

	private String auditTrans;

	private String downloadstate;

	private BigDecimal vnvAccountId;

	private String voucherCode;

	private String operatorSeq;

	private BigDecimal bankInfoSeq;

	private String purpose;

	private String batchNo;

	private String orderUrl;

	private BigDecimal returnAmount;

	private String ip;

	private BigDecimal payTransSeq;

	private Date settlementDate;

	private Integer transType;

	private BigDecimal checkBillTransDetailId;

	public BigDecimal getCheckBillTransDetailId() {
		return checkBillTransDetailId;
	}

	public void setCheckBillTransDetailId(BigDecimal checkBillTransDetailId) {
		this.checkBillTransDetailId = checkBillTransDetailId;
	}

	public Integer getTransType() {
		return transType;
	}

	public void setTransType(Integer transType) {
		this.transType = transType;
	}

	public BigDecimal getId() {
		return id;
	}

	public void setId(BigDecimal id) {
		this.id = id;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId == null ? null : orderId.trim();
	}

	public String getTransId() {
		return transId;
	}

	public void setTransId(String transId) {
		this.transId = transId == null ? null : transId.trim();
	}

	public BigDecimal getActionSeq() {
		return actionSeq;
	}

	public void setActionSeq(BigDecimal actionSeq) {
		this.actionSeq = actionSeq;
	}

	public BigDecimal getCreditSeq() {
		return creditSeq;
	}

	public void setCreditSeq(BigDecimal creditSeq) {
		this.creditSeq = creditSeq;
	}

	public BigDecimal getDebitSeq() {
		return debitSeq;
	}

	public void setDebitSeq(BigDecimal debitSeq) {
		this.debitSeq = debitSeq;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency == null ? null : currency.trim();
	}

	public BigDecimal getExchangeRate() {
		return exchangeRate;
	}

	public void setExchangeRate(BigDecimal exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

	public String getTradeType() {
		return tradeType;
	}

	public void setTradeType(String tradeType) {
		this.tradeType = tradeType == null ? null : tradeType.trim();
	}

	public String getTransStatus() {
		return transStatus;
	}

	public void setTransStatus(String transStatus) {
		this.transStatus = transStatus == null ? null : transStatus.trim();
	}

	public String getInsideStatus() {
		return insideStatus;
	}

	public void setInsideStatus(String insideStatus) {
		this.insideStatus = insideStatus == null ? null : insideStatus.trim();
	}

	public String getBankResponse() {
		return bankResponse;
	}

	public void setBankResponse(String bankResponse) {
		this.bankResponse = bankResponse == null ? null : bankResponse.trim();
	}

	public Date getBeginDate() {
		return beginDate;
	}

	public void setBeginDate(Date beginDate) {
		this.beginDate = beginDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public BigDecimal getCreditRatioSeq() {
		return creditRatioSeq;
	}

	public void setCreditRatioSeq(BigDecimal creditRatioSeq) {
		this.creditRatioSeq = creditRatioSeq;
	}

	public BigDecimal getDebitRatioSeq() {
		return debitRatioSeq;
	}

	public void setDebitRatioSeq(BigDecimal debitRatioSeq) {
		this.debitRatioSeq = debitRatioSeq;
	}

	public BigDecimal getBankSeq() {
		return bankSeq;
	}

	public void setBankSeq(BigDecimal bankSeq) {
		this.bankSeq = bankSeq;
	}

	public BigDecimal getDebitFee() {
		return debitFee;
	}

	public void setDebitFee(BigDecimal debitFee) {
		this.debitFee = debitFee;
	}

	public BigDecimal getCreditFee() {
		return creditFee;
	}

	public void setCreditFee(BigDecimal creditFee) {
		this.creditFee = creditFee;
	}

	public BigDecimal getAccountBankSeq() {
		return accountBankSeq;
	}

	public void setAccountBankSeq(BigDecimal accountBankSeq) {
		this.accountBankSeq = accountBankSeq;
	}

	public String getCardNo() {
		return cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo == null ? null : cardNo.trim();
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName == null ? null : bankName.trim();
	}

	public BigDecimal getBankProvSeq() {
		return bankProvSeq;
	}

	public void setBankProvSeq(BigDecimal bankProvSeq) {
		this.bankProvSeq = bankProvSeq;
	}

	public BigDecimal getBankCitySeq() {
		return bankCitySeq;
	}

	public void setBankCitySeq(BigDecimal bankCitySeq) {
		this.bankCitySeq = bankCitySeq;
	}

	public String getPersonName() {
		return personName;
	}

	public void setPersonName(String personName) {
		this.personName = personName == null ? null : personName.trim();
	}

	public String getPersonMail() {
		return personMail;
	}

	public void setPersonMail(String personMail) {
		this.personMail = personMail == null ? null : personMail.trim();
	}

	public String getPersonPhone() {
		return personPhone;
	}

	public void setPersonPhone(String personPhone) {
		this.personPhone = personPhone == null ? null : personPhone.trim();
	}

	public String getPersonMobile() {
		return personMobile;
	}

	public void setPersonMobile(String personMobile) {
		this.personMobile = personMobile == null ? null : personMobile.trim();
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark == null ? null : remark.trim();
	}

	public String getVerifyCode() {
		return verifyCode;
	}

	public void setVerifyCode(String verifyCode) {
		this.verifyCode = verifyCode == null ? null : verifyCode.trim();
	}

	public String getSellerUrl() {
		return sellerUrl;
	}

	public void setSellerUrl(String sellerUrl) {
		this.sellerUrl = sellerUrl == null ? null : sellerUrl.trim();
	}

	public String getCommodityInfo() {
		return commodityInfo;
	}

	public void setCommodityInfo(String commodityInfo) {
		this.commodityInfo = commodityInfo == null ? null : commodityInfo.trim();
	}

	public String getSellerParam() {
		return sellerParam;
	}

	public void setSellerParam(String sellerParam) {
		this.sellerParam = sellerParam == null ? null : sellerParam.trim();
	}

	public String getDesFlag() {
		return desFlag;
	}

	public void setDesFlag(String desFlag) {
		this.desFlag = desFlag == null ? null : desFlag.trim();
	}

	public String getMac() {
		return mac;
	}

	public void setMac(String mac) {
		this.mac = mac == null ? null : mac.trim();
	}

	public String getReverseFlag() {
		return reverseFlag;
	}

	public void setReverseFlag(String reverseFlag) {
		this.reverseFlag = reverseFlag == null ? null : reverseFlag.trim();
	}

	public BigDecimal getRelatingSeq() {
		return relatingSeq;
	}

	public void setRelatingSeq(BigDecimal relatingSeq) {
		this.relatingSeq = relatingSeq;
	}

	public BigDecimal getVnvAccountSeq() {
		return vnvAccountSeq;
	}

	public void setVnvAccountSeq(BigDecimal vnvAccountSeq) {
		this.vnvAccountSeq = vnvAccountSeq;
	}

	public String getServiceFlag() {
		return serviceFlag;
	}

	public void setServiceFlag(String serviceFlag) {
		this.serviceFlag = serviceFlag == null ? null : serviceFlag.trim();
	}

	public Date getServiceDate() {
		return serviceDate;
	}

	public void setServiceDate(Date serviceDate) {
		this.serviceDate = serviceDate;
	}

	public String getServicePerson() {
		return servicePerson;
	}

	public void setServicePerson(String servicePerson) {
		this.servicePerson = servicePerson == null ? null : servicePerson.trim();
	}

	public String getBarcode() {
		return barcode;
	}

	public void setBarcode(String barcode) {
		this.barcode = barcode == null ? null : barcode.trim();
	}

	public String getOperSource() {
		return operSource;
	}

	public void setOperSource(String operSource) {
		this.operSource = operSource == null ? null : operSource.trim();
	}

	public BigDecimal getVersion() {
		return version;
	}

	public void setVersion(BigDecimal version) {
		this.version = version;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser == null ? null : createUser.trim();
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser == null ? null : updateUser.trim();
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getUpdateUserSystem() {
		return updateUserSystem;
	}

	public void setUpdateUserSystem(String updateUserSystem) {
		this.updateUserSystem = updateUserSystem == null ? null : updateUserSystem.trim();
	}

	public String getEncryptcode() {
		return encryptcode;
	}

	public void setEncryptcode(String encryptcode) {
		this.encryptcode = encryptcode == null ? null : encryptcode.trim();
	}

	public String getAuditTrans() {
		return auditTrans;
	}

	public void setAuditTrans(String auditTrans) {
		this.auditTrans = auditTrans == null ? null : auditTrans.trim();
	}

	public String getDownloadstate() {
		return downloadstate;
	}

	public void setDownloadstate(String downloadstate) {
		this.downloadstate = downloadstate == null ? null : downloadstate.trim();
	}

	public BigDecimal getVnvAccountId() {
		return vnvAccountId;
	}

	public void setVnvAccountId(BigDecimal vnvAccountId) {
		this.vnvAccountId = vnvAccountId;
	}

	public String getVoucherCode() {
		return voucherCode;
	}

	public void setVoucherCode(String voucherCode) {
		this.voucherCode = voucherCode == null ? null : voucherCode.trim();
	}

	public String getOperatorSeq() {
		return operatorSeq;
	}

	public void setOperatorSeq(String operatorSeq) {
		this.operatorSeq = operatorSeq == null ? null : operatorSeq.trim();
	}

	public BigDecimal getBankInfoSeq() {
		return bankInfoSeq;
	}

	public void setBankInfoSeq(BigDecimal bankInfoSeq) {
		this.bankInfoSeq = bankInfoSeq;
	}

	public String getPurpose() {
		return purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose == null ? null : purpose.trim();
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo == null ? null : batchNo.trim();
	}

	public String getOrderUrl() {
		return orderUrl;
	}

	public void setOrderUrl(String orderUrl) {
		this.orderUrl = orderUrl == null ? null : orderUrl.trim();
	}

	public BigDecimal getReturnAmount() {
		return returnAmount;
	}

	public void setReturnAmount(BigDecimal returnAmount) {
		this.returnAmount = returnAmount;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip == null ? null : ip.trim();
	}

	public BigDecimal getPayTransSeq() {
		return payTransSeq;
	}

	public void setPayTransSeq(BigDecimal payTransSeq) {
		this.payTransSeq = payTransSeq;
	}

	public Date getSettlementDate() {
		return settlementDate;
	}

	public void setSettlementDate(Date settlementDate) {
		this.settlementDate = settlementDate;
	}
}