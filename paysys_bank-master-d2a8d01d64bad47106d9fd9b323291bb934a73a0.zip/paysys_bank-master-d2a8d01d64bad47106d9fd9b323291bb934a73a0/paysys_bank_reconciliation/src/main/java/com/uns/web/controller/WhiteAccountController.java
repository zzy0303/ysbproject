package com.uns.web.controller;

import com.fasterxml.jackson.databind.ser.Serializers;
import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.model.Account;
import com.uns.model.ActionType;
import com.uns.model.WhiteAccount;
import com.uns.service.AccountService;
import com.uns.service.ActionTypeService;
import com.uns.service.WhiteAccountService;
import com.uns.util.AjaxResult;
import com.uns.util.ErrorCodeEnum;
import com.uns.util.PoiUtils;
import com.uns.web.form.WhiteAccountForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.OutputStream;
import java.util.List;

/**
 * @Author: KaiFeng
 * @Description: 客户白名单
 * @Date: 2017/8/28
 * @Modifyed By:
 */
@Controller
@RequestMapping(value = "/whiteAccount.htm")
public class WhiteAccountController extends BaseController {

    @Autowired
    private AccountService accountService;

    @Autowired
    private WhiteAccountService whiteAccountService;

    @Autowired
    private ActionTypeService actionTypeService;

    /**
     * 查询商户白名单列表
     *
     * @param whiteAccountForm
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(params = "method=whiteList")
    public String whiteAccountList(WhiteAccountForm whiteAccountForm, HttpServletRequest request, HttpServletResponse response) {
        try {
            List<WhiteAccount> whiteAccounts = whiteAccountService.queryWhiteAccountList(whiteAccountForm);
            request.setAttribute("whiteAccounts", whiteAccounts);
            request.setAttribute("whiteAccountForm", whiteAccountForm);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "threshold/whiteAccountList";
    }

    /**
     * 导出商户白名单列表page
     * @param whiteAccountForm
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(params = "method=toExportPageList")
    public String toExportPageList(WhiteAccountForm whiteAccountForm, HttpServletRequest request, HttpServletResponse response){
        try {
            PageContext context = PageContext.getContext();
            context.setPageSize(Constants.EXCEL_SIZE);
            whiteAccountService.queryWhiteAccountList(whiteAccountForm);
            request.setAttribute("whiteAccountForm", whiteAccountForm);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "threshold/exportAccountPage";
    }

    /**
     * 导出商户白名单列表
     * @param whiteAccountForm
     * @param request
     * @param response
     */
    @RequestMapping(params = "method=toExportList")
    public void toExport(WhiteAccountForm whiteAccountForm, HttpServletRequest request, HttpServletResponse response){
        try {
            PageContext context = PageContext.getContext();
            context.setPageSize(Constants.EXCEL_SIZE);
            List<WhiteAccount> whiteAccounts = whiteAccountService.queryWhiteAccountList(whiteAccountForm);
            OutputStream out = response.getOutputStream();
            response.reset();
            response.setHeader("content-disposition",
                    "attachment;filename=" + new String((Constants.whiteAccountTitle).getBytes("gb2312"), "ISO8859-1") + ".xls");
            response.setContentType("APPLICATION/msexcel");
            PoiUtils.exportWhiteAccountExcel(Constants.whiteAccountTitle, Constants.whiteAccountColnum, whiteAccounts, out, Constants.DEFAULT_DATETIME_FORMAT);
        } catch (Exception e1) {
            e1.printStackTrace();
        }
    }

    /**
     * 跳转新增商户白名单页面
     * @return
     */
    @RequestMapping(params = "method=preAddAccount")
    public String toAdd(HttpServletRequest request, HttpServletResponse response) {
        List<Account> accountList = (List<Account>) request.getSession().getAttribute(Constants.ACCOUNTLIST_SESSIONKEY);
        request.setAttribute("accountList", accountList);
        return "threshold/preAddAccount";
    }

    /**
     * 保存商户白名单
     * @param whiteAccount
     * @return
     */
    @FormToken(save = true)
    @RequestMapping(params = "method=saveWhiteAccount")
    public String saveWhiteAccount(WhiteAccount whiteAccount, HttpServletRequest request){
        try {
            whiteAccountService.saveWhiteAccount(whiteAccount, request);
            request.setAttribute("msg", "保存成功！");
        } catch (BusinessException be) {
            ApplicationContext ctx = WebApplicationContextUtils
                    .getRequiredWebApplicationContext(request.getSession().getServletContext());
            MessageSource messageSource = (MessageSource) ctx.getBean("messageSource");
            request.setAttribute("errMsg", be.getErrMessage(messageSource));
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errMsg", "保存出错！");
        }
        request.setAttribute("title", "新增商户白名单");
        request.setAttribute("closeTitle", "商户白名单");
        request.setAttribute("url", "whiteAccount.htm?method=whiteList");
        return "common/message";
    }

    /**
     * 修改商户白名单信息
     * @param whiteAccount
     * @return
     */
    @ResponseBody
    @RequestMapping(params = "method=editWhiteAccount")
    public String editWhiteAccount(WhiteAccount whiteAccount, HttpServletRequest request) {
        try {
            whiteAccountService.editWhiteAccount(whiteAccount);
        } catch (BusinessException be) {
            ApplicationContext ctx = WebApplicationContextUtils
                    .getRequiredWebApplicationContext(request.getSession().getServletContext());
            MessageSource messageSource = (MessageSource) ctx.getBean("messageSource");
            return be.getErrMessage(messageSource);
        } catch (Exception e) {
            e.printStackTrace();
            return "修改出错！";
        }
        return "true";
    }

    /**
     * 根据default_sub_seq查询account
     * @param defaultSeq
     * @return
     */
    @ResponseBody
    @RequestMapping(params = "method=queryAccountByDefaultSeq")
    public String queryAccountByDefaultSeq(@RequestParam(required = true) String defaultSeq) {
        try {
            return whiteAccountService.queryAccountByDefaultSeq(defaultSeq);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
