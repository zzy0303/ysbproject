package com.uns.service;

import java.math.BigDecimal;
import java.util.*;

import com.uns.web.form.CheckBillForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.uns.common.page.PageContext;
import com.uns.dao.CheckBillMapper;
import com.uns.dao.FileUploadRecordMapper;
import com.uns.model.CheckBill;
import com.uns.model.FileUploadRecord;
import com.uns.model.UserInfo;
import com.uns.util.StringUtils;

@Service
public class FileUploadRecordService {

	@Autowired
	private FileUploadRecordMapper fileUploadRecordMapper;
	@Autowired
	private CheckBillMapper checkBillMapper;
	@Autowired
	private CheckBillService checkBillService;

	public List<FileUploadRecord> getUploadRecordList() {
		PageContext page = new PageContext();
		page.setPageSize(20);
		return fileUploadRecordMapper.getUploadList();
	}

	public List<FileUploadRecord> getOutUploadRecordList(CheckBillForm checkBillForm) {
		PageContext page = new PageContext();
		page.setPageSize(20);
		return fileUploadRecordMapper.getOutUploadList(checkBillForm);
	}

	public List<FileUploadRecord> getNetsUnionUploadRecordList(CheckBillForm checkBillForm) {
		PageContext page = new PageContext();
		page.setPageSize(20);
		return fileUploadRecordMapper.getNetsUnionUploadList(checkBillForm);
	}

	public void deleteRecordById(Long id) {

		fileUploadRecordMapper.deleteByPrimaryKey(id);
	}

	public void updateCheckStatus(Long id) {
		CheckBill checkBill = checkBillMapper.selectByPrimaryKey(id);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("toStatus", 0);
		map.put("checkDate", checkBill.getCheckDate());
		map.put("channel", checkBill.getChannel());
		checkBillMapper.updateCheckStatus(map);
	}

	// 对账
	public void toCheck(List<CheckBill> list, UserInfo user, String billType) throws Exception {
		Map map = new HashMap();
		if (list.size() > 0) {
			Integer checkId = Integer.valueOf(list.get(0).getId().toString());
			String channel = list.get(0).getChannel();
			Date checkDate = list.get(0).getCheckDate();
			String checkDSate = StringUtils.getDate(checkDate);
			map.put("checkDate", checkDSate);
			map.put("channel", channel);
			map.put("billType", billType);
			checkBillService.compareTrans(checkId, user.getUserName(), map, null);
		}
	}

	public void netsUnionToCheck(CheckBillForm checkBillForm, CheckBill checkBill, UserInfo user, String billType) throws Exception {
		Map map = new HashMap();
		Integer checkId = Integer.valueOf(checkBill.getId().toString());
		String channel = checkBill.getChannel();
		Date checkDate = checkBill.getCheckDate();
		String checkdate = StringUtils.getDate(checkDate);
		map.put("checkDate", checkdate);
		map.put("channel", channel);
		map.put("billType", billType);
		checkBillService.compareTrans(checkId, user.getUserName(), map, checkBillForm);
	}

	public FileUploadRecord findFileUploadRecordById(String aLong) {
		return fileUploadRecordMapper.selectByPrimaryKey(new BigDecimal(aLong));
	}

	public FileUploadRecord getNetsUnionUploadRecordById(String id){
		return fileUploadRecordMapper.selectByPrimaryKey(BigDecimal.valueOf(Long.valueOf(id)));
	}
}
