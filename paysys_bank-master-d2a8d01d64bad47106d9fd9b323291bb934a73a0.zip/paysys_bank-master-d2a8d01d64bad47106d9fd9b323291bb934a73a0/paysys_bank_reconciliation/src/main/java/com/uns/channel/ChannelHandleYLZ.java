package com.uns.channel;

import com.uns.common.Constants;
import com.uns.model.BankTrans;
import com.uns.util.AnalyExcel;
import com.uns.util.AnalyTxt;
import com.uns.web.form.CheckBillForm;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

public class ChannelHandleYLZ extends ChannelHandleDefault implements ChannelHandleInterface {

    @Override
    public List<BankTrans> loadDate(InputStream inputStream, CheckBillForm checkBillForm) throws Exception {
        return AnalyExcel.loadText(inputStream, checkBillForm, Constants.UPLOAD_YLZ_TXT);
    }

    @Override
    public List<Map<String, Object>> getLocalTrans(Integer id) throws Exception {
        return super.getOutLocalTrans(id, Constants.UPLOAD_YLZ);
    }

    @Override
    public Map<String, Object> getLocalAmount(String channel, String checkDate) {
        return getOutLocalAmount(channel, checkDate);
    }

    @Override
    public List<String> getChannelList() throws Exception {
        return null;
    }
}
