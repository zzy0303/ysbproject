package com.uns.dao;

import com.uns.model.EpccDpTransRef;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Repository
public interface EpccDpTransRefMapper {
    int deleteByPrimaryKey(BigDecimal id);

    int insert(EpccDpTransRef record);

    int insertSelective(EpccDpTransRef record);

    EpccDpTransRef selectByPrimaryKey(BigDecimal id);

    int updateByPrimaryKeySelective(EpccDpTransRef record);

    int updateByPrimaryKey(EpccDpTransRef record);

    List<EpccDpTransRef> getNetsUnionCheckTrans(Map paramMap);

    String getNetsUnionCheckTransCount(String checkDate);

	String getNewTxCheckTransCount(String checkdate);

}