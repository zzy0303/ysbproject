package com.uns.util;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

import com.uns.common.Constants;
import com.uns.model.*;
import com.uns.web.form.ThresholdsForm;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;

public class PoiUtils {
	/**
	 * 创建文件
	 *
	 * @throws IOException
	 */
	public static void createExcel(String title, String[] headers, List<TransDetail> transList, OutputStream out,
			String pattern) throws IOException {
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet(title);
		sheet.setDefaultColumnWidth((short) 20);
		HSSFCellStyle style = workbook.createCellStyle();
		style.setFillForegroundColor(HSSFColor.SKY_BLUE.index);
		style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		HSSFFont font = workbook.createFont();
		font.setColor(HSSFColor.VIOLET.index);
		font.setFontHeightInPoints((short) 12);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		style.setFont(font);

		// 产生表格标题行
		HSSFRow row = sheet.createRow(0);
		for (short i = 0; i < headers.length; i++) {
			HSSFCell cell = row.createCell(i);
			cell.setCellStyle(style);
			HSSFRichTextString text = new HSSFRichTextString(headers[i]);
			cell.setCellValue(text);
		}

		Iterator<TransDetail> it = transList.iterator();
		int index = 0;
		while (it.hasNext()) {
			index++;
			row = sheet.createRow(index);
			TransDetail t = it.next();
			Field[] fields = t.getClass().getDeclaredFields();
			for (short i = 0; i < fields.length; i++) {
				HSSFCell cell = row.createCell(i);
				Field field = fields[i];
				String fieldName = field.getName();
				String getMethodName = "get" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
				Class<? extends TransDetail> tCls = t.getClass();
				try {
					Method getMethod = tCls.getMethod(getMethodName, new Class[] {});
					Object value = getMethod.invoke(t, new Object[] {});
					String cellValue = null;
					if (value instanceof Date) {
						Date date = (Date) value;
						SimpleDateFormat sdf = new SimpleDateFormat(pattern);
						cellValue = sdf.format(date);
					}
					if (value instanceof BigDecimal) {
						cellValue = ((BigDecimal) value).setScale(2).toString();
					} else if (null == value || "".equals(value)) {
						cellValue = "";
					} else {
						cellValue = String.valueOf(value);
					}
					HSSFRichTextString richString = new HSSFRichTextString(cellValue);
					HSSFFont font3 = workbook.createFont();
					richString.applyFont(font3);
					cell.setCellValue(richString);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		}
		try {
			workbook.write(out);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			out.close();
		}
	}


	public static void exportThresholdListExcel(String title, String[] headers, List<ThresholdsForm> thresholdsForms, OutputStream out,
												String pattern) throws IOException {
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet(title);
		sheet.setDefaultColumnWidth((short) 20);
		HSSFCellStyle style = workbook.createCellStyle();
		style.setFillForegroundColor(HSSFColor.SKY_BLUE.index);
		style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		HSSFFont font = workbook.createFont();
		font.setColor(HSSFColor.VIOLET.index);
		font.setFontHeightInPoints((short) 12);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		style.setFont(font);

		HSSFRow row = sheet.createRow(0);
		for (short i = 0; i < headers.length; i++) {
			HSSFCell cell = row.createCell(i);
			cell.setCellStyle(style);
			HSSFRichTextString text = new HSSFRichTextString(headers[i]);
			cell.setCellValue(text);
		}

		for (int i = 0; i < thresholdsForms.size(); i++) {
			row = sheet.createRow((int) i + 1);
			// 第四步，创建单元格，并设置值
			row.createCell((short) 0).setCellValue(thresholdsForms.get(i).getAccountId());
			row.createCell((short) 1).setCellValue(thresholdsForms.get(i).getAccountName());
			row.createCell((short) 2).setCellValue(thresholdsForms.get(i).getActionName());
			row.createCell((short) 3).setCellValue(thresholdsForms.get(i).getCount());
			row.createCell((short) 4).setCellValue(thresholdsForms.get(i).getSumAmount().toString());
			row.createCell((short) 5).setCellValue(thresholdsForms.get(i).getSumFee().toString());
			row.createCell((short) 6).setCellValue(thresholdsForms.get(i).getSumWaitAmount().toString());
			row.createCell((short) 7).setCellValue(thresholdsForms.get(i).getCheckDate());
		}
		try {
			workbook.write(out);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			out.close();
		}
	}

	public static void exportThresholdHisExcel(String title, String[] headers, List<ThresholdAdjustHis> thresholdAdjustHis, OutputStream out,
											   String pattern) throws IOException {
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet(title);
		sheet.setDefaultColumnWidth((short) 20);
		HSSFCellStyle style = workbook.createCellStyle();
		style.setFillForegroundColor(HSSFColor.SKY_BLUE.index);
		style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		HSSFFont font = workbook.createFont();
		font.setColor(HSSFColor.VIOLET.index);
		font.setFontHeightInPoints((short) 12);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		style.setFont(font);

		HSSFRow row = sheet.createRow(0);
		for (short i = 0; i < headers.length; i++) {
			HSSFCell cell = row.createCell(i);
			cell.setCellStyle(style);
			HSSFRichTextString text = new HSSFRichTextString(headers[i]);
			cell.setCellValue(text);
		}

		for (int i = 0; i < thresholdAdjustHis.size(); i++) {
			row = sheet.createRow((int) i + 1);
			// 第四步，创建单元格，并设置值
			row.createCell((short) 0).setCellValue(thresholdAdjustHis.get(i).getAccountId());
			row.createCell((short) 1).setCellValue(thresholdAdjustHis.get(i).getAccountName());
			row.createCell((short) 2).setCellValue(thresholdAdjustHis.get(i).getBillCount());
			row.createCell((short) 3).setCellValue(thresholdAdjustHis.get(i).getBillAmount().toString());
			row.createCell((short) 4).setCellValue(thresholdAdjustHis.get(i).getBillFee().toString());
			row.createCell((short) 5).setCellValue(thresholdAdjustHis.get(i).getThresholdAmount().toString());
			row.createCell((short) 6).setCellValue(thresholdAdjustHis.get(i).getThresholdedAmount().toString());
			row.createCell((short) 7).setCellValue(thresholdAdjustHis.get(i).getUserName());
			row.createCell((short) 8).setCellValue(new SimpleDateFormat(pattern).format(thresholdAdjustHis.get(i).getCreateTime()));
		}
		try {
			workbook.write(out);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			out.close();
		}
	}

	public static void exportThresholdInfoExcel(String title, String[] headers, List<CheckBillTransDetail> checkBillTransDetails, OutputStream out,
												String pattern) throws IOException {
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet(title);
		sheet.setDefaultColumnWidth((short) 20);
		HSSFCellStyle style = workbook.createCellStyle();
		style.setFillForegroundColor(HSSFColor.SKY_BLUE.index);
		style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		HSSFFont font = workbook.createFont();
		font.setColor(HSSFColor.VIOLET.index);
		font.setFontHeightInPoints((short) 12);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		style.setFont(font);

		HSSFRow row = sheet.createRow(0);
		for (short i = 0; i < headers.length; i++) {
			HSSFCell cell = row.createCell(i);
			cell.setCellStyle(style);
			HSSFRichTextString text = new HSSFRichTextString(headers[i]);
			cell.setCellValue(text);
		}

		for (int i = 0; i < checkBillTransDetails.size(); i++) {
			row = sheet.createRow((int) i + 1);
			// 第四步，创建单元格，并设置值
			row.createCell((short) 0).setCellValue(checkBillTransDetails.get(i).getChannel());
			row.createCell((short) 1).setCellValue(checkBillTransDetails.get(i).getBankName());
			row.createCell((short) 2).setCellValue(checkBillTransDetails.get(i).getActionName());
			row.createCell((short) 3).setCellValue(checkBillTransDetails.get(i).getLocalTransId());
			row.createCell((short) 4).setCellValue(checkBillTransDetails.get(i).getName());
			row.createCell((short) 5).setCellValue(checkBillTransDetails.get(i).getLocalAmount().toString());
			row.createCell((short) 6).setCellValue(checkBillTransDetails.get(i).getCreditFee().toString());
			row.createCell((short) 7).setCellValue(checkBillTransDetails.get(i).getBankTransId());
			row.createCell((short) 8).setCellValue(checkBillTransDetails.get(i).getBankAmount().toString());
			row.createCell((short) 9).setCellValue(checkBillTransDetails.get(i).getFileName());
			row.createCell((short) 10).setCellValue(checkBillTransDetails.get(i).getCheckTransStatus());
			row.createCell((short) 11).setCellValue(checkBillTransDetails.get(i).getOperStatus());
			row.createCell((short) 12).setCellValue(checkBillTransDetails.get(i).getCheckUser());
			row.createCell((short) 13).setCellValue(new SimpleDateFormat("yyyy-MM-dd").format(checkBillTransDetails.get(i).getCheckDate()));
		}
		try {
			workbook.write(out);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			out.close();
		}
	}

	public static void exportWhiteAccountExcel(String title, String[] headers, List<WhiteAccount> whiteAccountList, OutputStream out,
											   String pattern) throws IOException {
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet(title);
		sheet.setDefaultColumnWidth((short) 20);
		HSSFCellStyle style = workbook.createCellStyle();
		style.setFillForegroundColor(HSSFColor.SKY_BLUE.index);
		style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		HSSFFont font = workbook.createFont();
		font.setColor(HSSFColor.VIOLET.index);
		font.setFontHeightInPoints((short) 12);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		style.setFont(font);

		HSSFRow row = sheet.createRow(0);
		for (short i = 0; i < headers.length; i++) {
			HSSFCell cell = row.createCell(i);
			cell.setCellStyle(style);
			HSSFRichTextString text = new HSSFRichTextString(headers[i]);
			cell.setCellValue(text);
		}

		for (int i = 0; i < whiteAccountList.size(); i++) {
			row = sheet.createRow((int) i + 1);
			// 第四步，创建单元格，并设置值
			row.createCell((short) 0).setCellValue(whiteAccountList.get(i).getId().toString());
			row.createCell((short) 1).setCellValue(whiteAccountList.get(i).getAccountId());
			row.createCell((short) 2).setCellValue(whiteAccountList.get(i).getName());
			row.createCell((short) 3).setCellValue(whiteAccountList.get(i).getActionName());
			row.createCell((short) 4).setCellValue(whiteAccountList.get(i).getReason());
			row.createCell((short) 5).setCellValue(whiteAccountList.get(i).getUserName());
			row.createCell((short) 6).setCellValue(new SimpleDateFormat(pattern).format(whiteAccountList.get(i).getOperTime()));
			row.createCell((short) 7).setCellValue(whiteAccountList.get(i).getStatuStr());
		}
		try {
			workbook.write(out);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			out.close();
		}
	}

	public static void exportHangExcel(String title, String[] headers, List<Object> checkBillTransDetailList, OutputStream out,
								   String pattern) throws IOException {
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet(title);
		sheet.setDefaultColumnWidth((short) 20);
		HSSFCellStyle style = workbook.createCellStyle();
		style.setFillForegroundColor(HSSFColor.SKY_BLUE.index);
		style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		HSSFFont font = workbook.createFont();
		font.setColor(HSSFColor.VIOLET.index);
		font.setFontHeightInPoints((short) 12);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		style.setFont(font);

		HSSFRow row = sheet.createRow(0);
		for (short i = 0; i < headers.length; i++) {
			HSSFCell cell = row.createCell(i);
			cell.setCellStyle(style);
			HSSFRichTextString text = new HSSFRichTextString(headers[i]);
			cell.setCellValue(text);
		}

		HSSFCell cell = row.createCell((short) 0);
		cell.setCellValue("对账日期");
		cell = row.createCell((short) 1);
		cell.setCellValue("交易时间");
		cell = row.createCell((short) 2);
		cell.setCellValue("对账银行通道");
		cell = row.createCell((short) 3);
		cell.setCellValue("对账银行");
		cell = row.createCell((short) 4);
		cell.setCellValue("交易类型");
		cell = row.createCell((short) 5);
		cell.setCellValue("银生宝交易编号");
		cell = row.createCell((short) 6);
		cell.setCellValue("交易商户名");
		cell = row.createCell((short) 7);
		cell.setCellValue("银生宝交易金额");
		cell = row.createCell((short) 8);
		cell.setCellValue("银行交易编号");
		cell = row.createCell((short) 9);
		cell.setCellValue("银行交易金额");
		cell = row.createCell((short) 10);
		cell.setCellValue("对账文件名称");
		cell = row.createCell((short) 11);
		cell.setCellValue("对账状态");
		cell = row.createCell((short) 12);
		cell.setCellValue("审核状态");
		Map map = null;
		for (int i = 0; i < checkBillTransDetailList.size(); i++) {
			map = (Map) checkBillTransDetailList.get(i);
			row = sheet.createRow((int) i + 1);
			// 第四步，创建单元格，并设置值
			row.createCell((short) 0).setCellValue(map.get("CHECKDATE")==null?"":map.get("CHECKDATE").toString());
			row.createCell((short) 1).setCellValue(map.get("TRANSDATE")==null?"":map.get("TRANSDATE").toString());
			row.createCell((short) 2).setCellValue(map.get("CHANNEL")==null?"":map.get("CHANNEL").toString());
			row.createCell((short) 3).setCellValue(map.get("BANKNAME")==null?"":map.get("BANKNAME").toString());
			row.createCell((short) 4).setCellValue(map.get("ACTIONNAME")==null?"":map.get("ACTIONNAME").toString());
			row.createCell((short) 5).setCellValue(map.get("LOCALTRANSID")==null?"":map.get("LOCALTRANSID").toString());
			row.createCell((short) 6).setCellValue(map.get("ACCOUNTNAME")==null?"":map.get("ACCOUNTNAME").toString());
			row.createCell((short) 7).setCellValue(map.get("LOCALAMOUNT")==null?"":map.get("LOCALAMOUNT").toString());
			row.createCell((short) 8).setCellValue(map.get("BANKTRANSID")==null?"":map.get("BANKTRANSID").toString());
			row.createCell((short) 9).setCellValue(map.get("BNAKAMOUNT")==null?"":map.get("BNAKAMOUNT").toString());
			row.createCell((short) 10).setCellValue(map.get("FILENAME")==null?"":map.get("FILENAME").toString());
			if(Constants.FLAG_1.equals(map.get("CHECKTRANSSTATUS").toString())) {
				row.createCell((short) 11).setCellValue("正常对账");
			} else if(Constants.FLAG_2.equals(map.get("CHECKTRANSSTATUS").toString())) {
				row.createCell((short) 11).setCellValue("银行有我方无");
			} else if(Constants.FLAG_3.equals(map.get("CHECKTRANSSTATUS").toString())) {
				row.createCell((short) 11).setCellValue("银行无我方有");
			} else if(Constants.FLAG_4_.equals(map.get("CHECKTRANSSTATUS").toString())) {
				row.createCell((short) 11).setCellValue("金额不对");
			}
			row.createCell((short) 12).setCellValue(map.get("OPERATIONSTATUS").toString());
		}
		try {
			workbook.write(out);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			out.close();
		}
	}

	public static void exportNetsUnionHangExcel(String title, String[] headers, List<Object> checkBillTransDetailList, OutputStream out,
									   String pattern) throws IOException {
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet(title);
		sheet.setDefaultColumnWidth((short) 20);
		HSSFCellStyle style = workbook.createCellStyle();
		style.setFillForegroundColor(HSSFColor.SKY_BLUE.index);
		style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		HSSFFont font = workbook.createFont();
		font.setColor(HSSFColor.VIOLET.index);
		font.setFontHeightInPoints((short) 12);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		style.setFont(font);

		HSSFRow row = sheet.createRow(0);
		for (short i = 0; i < headers.length; i++) {
			HSSFCell cell = row.createCell(i);
			cell.setCellStyle(style);
			HSSFRichTextString text = new HSSFRichTextString(headers[i]);
			cell.setCellValue(text);
		}

		HSSFCell cell = row.createCell((short) 0);
		cell.setCellValue("对账日期");
		cell = row.createCell((short) 1);
		cell.setCellValue("交易时间");
		cell = row.createCell((short) 2);
		cell.setCellValue("对账银行通道");
		cell = row.createCell((short) 3);
		cell.setCellValue("对账银行");
		cell = row.createCell((short) 4);
		cell.setCellValue("交易类型");
		cell = row.createCell((short) 5);
		cell.setCellValue("银生宝交易编号");
		cell = row.createCell((short) 6);
		cell.setCellValue("交易商户名");
		cell = row.createCell((short) 7);
		cell.setCellValue("银生宝交易金额");
		cell = row.createCell((short) 8);
		cell.setCellValue("网联交易批次号");
		cell = row.createCell((short) 9);
		cell.setCellValue("银行交易编号");
		cell = row.createCell((short) 10);
		cell.setCellValue("银行交易金额");
		cell = row.createCell((short) 11);
		cell.setCellValue("银行交易类别");
		cell = row.createCell((short) 12);
		cell.setCellValue("银行交易状态");
		cell = row.createCell((short) 13);
		cell.setCellValue("付款行账户");
		cell = row.createCell((short) 14);
		cell.setCellValue("收款行账户");
		cell = row.createCell((short) 15);
		cell.setCellValue("对账文件名称");
		cell = row.createCell((short) 16);
		cell.setCellValue("对账状态");
		cell = row.createCell((short) 17);
		cell.setCellValue("审核状态");
		Map map = null;
		for (int i = 0; i < checkBillTransDetailList.size(); i++) {
			map = (Map) checkBillTransDetailList.get(i);
			row = sheet.createRow((int) i + 1);
			// 第四步，创建单元格，并设置值
			row.createCell((short) 0).setCellValue(map.get("CHECKDATE")==null?"":map.get("CHECKDATE").toString());
			row.createCell((short) 1).setCellValue(map.get("TRANSDATE")==null?"":map.get("TRANSDATE").toString());
			row.createCell((short) 2).setCellValue(map.get("CHANNEL")==null?"":map.get("CHANNEL").toString());
			row.createCell((short) 3).setCellValue(map.get("BANKNAME")==null?"":map.get("BANKNAME").toString());
			row.createCell((short) 4).setCellValue(map.get("ACTIONNAME")==null?"":map.get("ACTIONNAME").toString());
			row.createCell((short) 5).setCellValue(map.get("LOCALTRANSID")==null?"":map.get("LOCALTRANSID").toString());
			row.createCell((short) 6).setCellValue(map.get("ACCOUNTNAME")==null?"":map.get("ACCOUNTNAME").toString());
			row.createCell((short) 7).setCellValue(map.get("LOCALAMOUNT")==null?"":map.get("LOCALAMOUNT").toString());
			row.createCell((short) 8).setCellValue(map.get("BATCH_ID")==null?"":map.get("BATCH_ID").toString());
			row.createCell((short) 9).setCellValue(map.get("BANKTRANSID")==null?"":map.get("BANKTRANSID").toString());
			row.createCell((short) 10).setCellValue(map.get("BNAKAMOUNT")==null?"":map.get("BNAKAMOUNT").toString());
			row.createCell((short) 11).setCellValue(map.get("BANK_BUSI_TYPE")==null?"":map.get("BANK_BUSI_TYPE").toString());
			row.createCell((short) 12).setCellValue(map.get("BANK_BUSI_STATUS")==null?"":map.get("BANK_BUSI_STATUS").toString());
			row.createCell((short) 13).setCellValue(map.get("PAY_ORG_ID_SEQ")==null?"":map.get("PAY_ORG_ID_SEQ").toString());
			row.createCell((short) 14).setCellValue(map.get("DEST_ORG_ID_SEQ")==null?"":map.get("DEST_ORG_ID_SEQ").toString());
			row.createCell((short) 15).setCellValue(map.get("FILENAME")==null?"":map.get("FILENAME").toString());
			if(Constants.FLAG_1.equals(map.get("CHECKTRANSSTATUS").toString())) {
				row.createCell((short) 16).setCellValue("正常对账");
			} else if(Constants.FLAG_2.equals(map.get("CHECKTRANSSTATUS").toString())) {
				row.createCell((short) 16).setCellValue("银行有我方无");
			} else if(Constants.FLAG_3.equals(map.get("CHECKTRANSSTATUS").toString())) {
				row.createCell((short) 16).setCellValue("银行无我方有");
			} else if(Constants.FLAG_4_.equals(map.get("CHECKTRANSSTATUS").toString())) {
				row.createCell((short) 16).setCellValue("金额不对");
			}
			row.createCell((short) 17).setCellValue(map.get("OPERATIONSTATUS").toString());
		}
		try {
			workbook.write(out);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			out.close();
		}
	}
	
	
	public static void exportNetsUnionTransDateExcel(String title, String[] headers, List<Object> netsUnionTransDateList,
			OutputStream out, String pattern) throws IOException {
		SimpleDateFormat sf=new SimpleDateFormat("yyyy-MM-dd HH:ss:mm");
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet(title);
		sheet.setDefaultColumnWidth((short) 20);
		HSSFCellStyle style = workbook.createCellStyle();
		style.setFillForegroundColor(HSSFColor.SKY_BLUE.index);
		style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		HSSFFont font = workbook.createFont();
		font.setColor(HSSFColor.VIOLET.index);
		font.setFontHeightInPoints((short) 12);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		style.setFont(font);

		HSSFRow row = sheet.createRow(0);
		for (short i = 0; i < headers.length; i++) {
			HSSFCell cell = row.createCell(i);
			cell.setCellStyle(style);
			HSSFRichTextString text = new HSSFRichTextString(headers[i]);
			cell.setCellValue(text);
		}

		HSSFCell cell = row.createCell((short) 0);
		cell.setCellValue("银生宝交易编号");
		cell = row.createCell((short) 1);
		cell.setCellValue("交易时间");
		cell = row.createCell((short) 2);
		cell.setCellValue("银行交易批次号");
		cell = row.createCell((short) 3);
		cell.setCellValue("银行交易编号");
		cell = row.createCell((short) 4);
		cell.setCellValue("银行交易金额");
		cell = row.createCell((short) 5);
		cell.setCellValue("银行交易类别");
		cell = row.createCell((short) 6);
		cell.setCellValue("银行交易状态");
		cell = row.createCell((short) 7);
		cell.setCellValue("银行交易时间");
		Map map = null;
		for (int i = 0; i < netsUnionTransDateList.size(); i++) {
			map = (Map) netsUnionTransDateList.get(i);
			row = sheet.createRow((int) i + 1);
			// 第四步，创建单元格，并设置值
			row.createCell((short) 0).setCellValue(map.get("TRANS_ID") == null ? "" : map.get("TRANS_ID").toString());
			row.createCell((short) 1).setCellValue(map.get("CREATE_TIME") == null ? "" : sf.format( map.get("CREATE_TIME")));
			row.createCell((short) 2).setCellValue(map.get("BATCH_ID") == null ? "" : map.get("BATCH_ID").toString());
			row.createCell((short) 3).setCellValue(map.get("EPCC_TRANS_ID") == null ? "" : map.get("EPCC_TRANS_ID").toString());
			row.createCell((short) 4).setCellValue(map.get("TRANS_AMOUNT") == null ? "" : map.get("TRANS_AMOUNT").toString());
			if (Constants.FLAG_0110.equals(map.get("TRANS_TYPE").toString())) {
				row.createCell((short) 5).setCellValue("协议支付");
			} else if (Constants.FLAG_0112.equals(map.get("TRANS_TYPE").toString())) {
				row.createCell((short) 5).setCellValue("网关支付");
			} else if (Constants.FLAG_0113.equals(map.get("TRANS_TYPE").toString())) {
				row.createCell((short) 5).setCellValue("认证支付");
			} else if (Constants.FLAG_0114.equals(map.get("TRANS_TYPE").toString())) {
				row.createCell((short) 5).setCellValue("委托支付");
			}else if (Constants.FLAG_0120.equals(map.get("TRANS_TYPE").toString())) {
				row.createCell((short) 5).setCellValue("付款");
			}
			if (null != map.get("TRANS_STATUS")){
				if (Constants.FLAG_00.equals(map.get("TRANS_STATUS").toString())) {
					row.createCell((short) 6).setCellValue("交易成功");
				} else if (Constants.FLAG_01.equals(map.get("TRANS_STATUS").toString())) {
					row.createCell((short) 6).setCellValue("交易失败");
				} else if (Constants.FLAG_02.equals(map.get("TRANS_STATUS").toString())) {
					row.createCell((short) 6).setCellValue("交易处理中");
				} else if (Constants.FLAG_03.equals(map.get("TRANS_STATUS").toString())) {
					row.createCell((short) 6).setCellValue("交易推定成功");
				} else if (Constants.FLAG_04.equals(map.get("TRANS_STATUS").toString())) {
					row.createCell((short) 6).setCellValue("交易推定失败");
				}
			} else {
				row.createCell((short) 6).setCellValue("");
			}
			row.createCell((short) 7).setCellValue(map.get("TRANS_TIME") == null ? "" : map.get("TRANS_TIME").toString());
		}
		try {
			workbook.write(out);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			out.close();
		}
	}
	
	
	
	

	public static void exportExcel(String title, String[] headers, List<TransDetail> transList, OutputStream out,
			String pattern) throws IOException {
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet(title);
		sheet.setDefaultColumnWidth((short) 20);
		HSSFCellStyle style = workbook.createCellStyle();
		style.setFillForegroundColor(HSSFColor.SKY_BLUE.index);
		style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		HSSFFont font = workbook.createFont();
		font.setColor(HSSFColor.VIOLET.index);
		font.setFontHeightInPoints((short) 12);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		style.setFont(font);

		HSSFRow row = sheet.createRow(0);
		for (short i = 0; i < headers.length; i++) {
			HSSFCell cell = row.createCell(i);
			cell.setCellStyle(style);
			HSSFRichTextString text = new HSSFRichTextString(headers[i]);
			cell.setCellValue(text);
		}

		HSSFCell cell = row.createCell((short) 0);
		cell.setCellValue("对账日期");
		cell = row.createCell((short) 1);
		cell.setCellValue("交易时间");
		cell = row.createCell((short) 2);
		cell.setCellValue("对账银行通道");
		cell = row.createCell((short) 3);
		cell.setCellValue("对账银行");
		cell = row.createCell((short) 4);
		cell.setCellValue("交易类型");
		cell = row.createCell((short) 5);
		cell.setCellValue("银生宝交易编号");
		cell = row.createCell((short) 6);
		cell.setCellValue("交易商户名");
		cell = row.createCell((short) 7);
		cell.setCellValue("银生宝交易金额");
		cell = row.createCell((short) 8);
		cell.setCellValue("银行交易编号");
		cell = row.createCell((short) 9);
		cell.setCellValue("银行交易金额");
		cell = row.createCell((short) 10);
		cell.setCellValue("对账文件名称");
		cell = row.createCell((short) 11);
		cell.setCellValue("对账状态");
		cell = row.createCell((short) 12);

		for (int i = 0; i < transList.size(); i++) {
			row = sheet.createRow((int) i + 1);
			// 第四步，创建单元格，并设置值
			row.createCell((short) 0).setCellValue(transList.get(i).getCheckDate());
			row.createCell((short) 1).setCellValue(transList.get(i).getTransDate());
			row.createCell((short) 2).setCellValue(transList.get(i).getChannel());
			row.createCell((short) 3).setCellValue(transList.get(i).getBankName());
			row.createCell((short) 4).setCellValue(transList.get(i).getActionName());
			row.createCell((short) 5).setCellValue(transList.get(i).getLocalTransId() == null? transList.get(i).getBankTransId():
                    transList.get(i).getLocalTransId());
			row.createCell((short) 6).setCellValue(transList.get(i).getAccountName());
			row.createCell((short) 7).setCellValue(transList.get(i).getLocalAmount() == null? "":
					transList.get(i).getLocalAmount().toString());
			row.createCell((short) 8).setCellValue(transList.get(i).getBankTransId());
			row.createCell((short) 9).setCellValue(transList.get(i).getBankAmount() == null? "":
                    transList.get(i).getBankAmount().toString());
			row.createCell((short) 10).setCellValue(transList.get(i).getFileName());
			row.createCell((short) 11).setCellValue(transList.get(i).getCheckTransStatus());

		}
		try {
			workbook.write(out);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			out.close();
		}
	}

	public static void exportNetsUnionExcel(String title, String[] headers, List<TransDetail> transList, OutputStream out,
								   String pattern) throws IOException {
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet(title);
		sheet.setDefaultColumnWidth((short) 20);
		HSSFCellStyle style = workbook.createCellStyle();
		style.setFillForegroundColor(HSSFColor.SKY_BLUE.index);
		style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		HSSFFont font = workbook.createFont();
		font.setColor(HSSFColor.VIOLET.index);
		font.setFontHeightInPoints((short) 12);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		style.setFont(font);

		HSSFRow row = sheet.createRow(0);
		for (short i = 0; i < headers.length; i++) {
			HSSFCell cell = row.createCell(i);
			cell.setCellStyle(style);
			HSSFRichTextString text = new HSSFRichTextString(headers[i]);
			cell.setCellValue(text);
		}

		HSSFCell cell = row.createCell((short) 0);
		cell.setCellValue("对账日期");
		cell = row.createCell((short) 1);
		cell.setCellValue("交易时间");
		cell = row.createCell((short) 2);
		cell.setCellValue("对账银行通道");
		cell = row.createCell((short) 3);
		cell.setCellValue("对账银行");
		cell = row.createCell((short) 4);
		cell.setCellValue("交易类型");
		cell = row.createCell((short) 5);
		cell.setCellValue("银生宝交易编号");
		cell = row.createCell((short) 6);
		cell.setCellValue("网联交易批次号");
		cell = row.createCell((short) 7);
		cell.setCellValue("交易商户名");
		cell = row.createCell((short) 8);
		cell.setCellValue("银生宝交易金额");
		cell = row.createCell((short) 9);
		cell.setCellValue("银行交易编号");
		cell = row.createCell((short) 10);
		cell.setCellValue("银行交易类别");
		cell = row.createCell((short) 11);
		cell.setCellValue("银行交易状态");
		cell = row.createCell((short) 12);
		cell.setCellValue("付款行账户");
		cell = row.createCell((short) 13);
		cell.setCellValue("收款行账户");
		cell = row.createCell((short) 14);
		cell.setCellValue("银行交易金额");
		cell = row.createCell((short) 15);
		cell.setCellValue("对账文件名称");
		cell = row.createCell((short) 16);
		cell.setCellValue("对账状态");
		cell = row.createCell((short) 17);

		for (int i = 0; i < transList.size(); i++) {
			row = sheet.createRow((int) i + 1);
			// 第四步，创建单元格，并设置值
			row.createCell((short) 0).setCellValue(transList.get(i).getCheckDate());
			row.createCell((short) 1).setCellValue(transList.get(i).getTransDate());
			row.createCell((short) 2).setCellValue(transList.get(i).getChannel());
			row.createCell((short) 3).setCellValue(transList.get(i).getBankName());
			row.createCell((short) 4).setCellValue(transList.get(i).getActionName());
			row.createCell((short) 5).setCellValue(transList.get(i).getLocalTransId() == null? transList.get(i).getBankTransId():
					transList.get(i).getLocalTransId());
			row.createCell((short) 6).setCellValue(transList.get(i).getBatchId());
			row.createCell((short) 7).setCellValue(transList.get(i).getAccountName());
			row.createCell((short) 8).setCellValue(transList.get(i).getLocalAmount() == null? "":
					transList.get(i).getLocalAmount().toString());
			row.createCell((short) 9).setCellValue(transList.get(i).getBankTransId());

			row.createCell((short) 10).setCellValue(transList.get(i).getBankBusiType());
			row.createCell((short) 11).setCellValue(transList.get(i).getBankBusiStatus());
			row.createCell((short) 12).setCellValue(transList.get(i).getPayOrgIdSeq());
			row.createCell((short) 13).setCellValue(transList.get(i).getDestOrgIdSeq());

			row.createCell((short) 14).setCellValue(transList.get(i).getBankAmount() == null? "":
					transList.get(i).getBankAmount().toString());
			row.createCell((short) 15).setCellValue(transList.get(i).getFileName());
			row.createCell((short) 16).setCellValue(transList.get(i).getCheckTransStatus());

		}
		try {
			workbook.write(out);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			out.close();
		}
	}

	
	public static void exportThresholdExcel(String title, String[] headers, List<AdjustThreshold> transList, OutputStream out,
			String pattern) throws IOException {
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet(title);
		sheet.setDefaultColumnWidth((short) 20);
		HSSFCellStyle style = workbook.createCellStyle();
		style.setFillForegroundColor(HSSFColor.SKY_BLUE.index);
		style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		HSSFFont font = workbook.createFont();
		font.setColor(HSSFColor.VIOLET.index);
		font.setFontHeightInPoints((short) 12);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		style.setFont(font);
		
		HSSFRow row = sheet.createRow(0);
		for (short i = 0; i < headers.length; i++) {
			HSSFCell cell = row.createCell(i);
			cell.setCellStyle(style);
			HSSFRichTextString text = new HSSFRichTextString(headers[i]);
			cell.setCellValue(text);
		}
		
		for (int i = 0; i < transList.size(); i++) {
			row = sheet.createRow((int) i + 1);
			// 第四步，创建单元格，并设置值
			row.createCell((short) 0).setCellValue(StringUtils.getDate(transList.get(i).getCheckDate()));
			row.createCell((short) 1).setCellValue(StringUtils.getDate(transList.get(i).getTransDate()));
			row.createCell((short) 2).setCellValue(transList.get(i).getChannel());
			row.createCell((short) 3).setCellValue(transList.get(i).getBankName());
			row.createCell((short) 4).setCellValue(transList.get(i).getActionType());
			row.createCell((short) 5).setCellValue(transList.get(i).getLocalTransId());
			row.createCell((short) 6).setCellValue(transList.get(i).getAccountName());
			row.createCell((short) 7).setCellValue(transList.get(i).getLocalAmount().toString());
			row.createCell((short) 8).setCellValue(transList.get(i).getBankTransId());
			row.createCell((short) 9).setCellValue(transList.get(i).getBankAmount().toString());
			row.createCell((short) 10).setCellValue(transList.get(i).getFileName());
			row.createCell((short) 11).setCellValue(transList.get(i).getCheckStatus());
			row.createCell((short) 12).setCellValue(transList.get(i).getAdjustStatus());
			row.createCell((short) 13).setCellValue(transList.get(i).getOperator()==""?"":transList.get(i).getOperator());
			if(null==transList.get(i).getOperationTime()){
				row.createCell((short) 14).setCellValue("");
			}
			else {
                row.createCell((short) 14).setCellValue(StringUtils.getDate(transList.get(i).getOperationTime()));
            }

		}
		
		try {
			workbook.write(out);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			out.close();
		}
	}
}
