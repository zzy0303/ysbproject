package com.uns.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.dao.CheckBillMapper;
import com.uns.dao.CheckBillTransDetailMapper;
import com.uns.model.CheckBillTransDetail;
import com.uns.util.StringUtils;
import com.uns.web.form.TransDetailForm;

@Service
public class OutTransDetailService {
	@Autowired
	private CheckBillTransDetailMapper checkBillTransDetailMapper;

	/**
	 * 出金默认不显示正常交易
	 * @param transDetailForm
	 * @return
	 */
	public List<CheckBillTransDetail> getTransDetailList(TransDetailForm transDetailForm) {
		List<CheckBillTransDetail> transList = checkBillTransDetailMapper.getOutDetailList(transDetailForm);
		return transList;
	}
	
	/**
	 * 获取对账明细金额
	 * @param transDetailForm
	 * @return
	 */
	public String getNumAmount(TransDetailForm transDetailForm) {
		String amount = "0";
		amount = checkBillTransDetailMapper.getOutNumAmount(transDetailForm);
		return StringUtils.getDecimal(amount, 2);
	}
}
