package com.uns.service;

import com.uns.dao.CheckBillTransDetailMapper;
import com.uns.model.CheckBillTransDetail;
import com.uns.util.StringUtils;
import com.uns.web.form.TransDetailForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NetsUnionTransDetailService {

    @Autowired
    private CheckBillTransDetailMapper checkBillTransDetailMapper;

    /**
     * 网联对账详情，不显示对平交易
     * @param transDetailForm
     * @return
     */
    public List<CheckBillTransDetail> getTransDetailList(TransDetailForm transDetailForm) {
        List<CheckBillTransDetail> transList = checkBillTransDetailMapper.getNetsUnionDetailList(transDetailForm);
        return transList;
    }

    /**
     * 获取网联对账明细金额
     * @param transDetailForm
     * @return
     */
    public String getNumAmount(TransDetailForm transDetailForm) {
        String amount;
        amount = checkBillTransDetailMapper.getNetsUnionNumAmount(transDetailForm);
        return StringUtils.getDecimal(amount, 2);
    }

}
