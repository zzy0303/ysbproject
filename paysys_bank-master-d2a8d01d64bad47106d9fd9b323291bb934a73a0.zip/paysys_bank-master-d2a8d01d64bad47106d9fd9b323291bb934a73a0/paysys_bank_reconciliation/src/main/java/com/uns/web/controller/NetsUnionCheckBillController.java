package com.uns.web.controller;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.cache.CacheManager;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.dao.CheckBillMapper;
import com.uns.model.CheckBill;
import com.uns.model.FileUploadRecord;
import com.uns.model.UserInfo;
import com.uns.service.CheckBillService;
import com.uns.service.FileUploadRecordService;
import com.uns.util.AcmsMapUtils;
import com.uns.util.FastJson;
import com.uns.web.form.CheckBillForm;
import oracle.jdbc.driver.Const;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * 网联对账controller
 */
@Controller
@RequestMapping(value = "/netsUnionCheckBill.htm")
public class NetsUnionCheckBillController extends BaseController {

    @Autowired
    private MessageSource messageSource;

    @Autowired
    private CheckBillService checkBillService;

    @Autowired
    private FileUploadRecordService fileUploadRecordService;

    private Logger log = LoggerFactory.getLogger(this.getClass());
    /**
     * 跳转网联对账列表
     *
     * @param request
     * @param checkBillForm
     * @return
     */
    @RequestMapping(params = "method=netsUnionCheckBillList")
    @FormToken(save = true)
    public String checkBillList(HttpServletRequest request, CheckBillForm checkBillForm) {
        checkBillForm.setBillType(Constants.CHECK_BILL_2);//网联bill_type
        List<CheckBill> checkList = checkBillService.getCheckList(checkBillForm);
        String[] netsUnionChannel = StringUtils.split(Constants.NETS_UNION_CHECK_BILL_CHANNEL, ",");
        request.setAttribute("checkList", checkList);
        request.setAttribute("checkBillForm", checkBillForm);
        request.setAttribute("netsUnionChannel", netsUnionChannel);
        return "netsUnionCheckbill/netsUnionCheckBillList";
    }

    /**
     * 跳转网联对账文件上传页面
     * @param request
     * @param checkBillForm
     * @return
     * @throws BusinessException
     */
    @RequestMapping(params = "method=toUploadFile")
    @FormToken(save = true)
    public String toUploadBankTrans(HttpServletRequest request, CheckBillForm checkBillForm) throws BusinessException {
        //参数平台
        String[] netsUnionChannel = StringUtils.split(Constants.NETS_UNION_CHECK_BILL_CHANNEL, ",");
        request.setAttribute("getChannel", checkBillForm.getChannel());
        request.setAttribute("getCheckDate", checkBillForm.getCheckdate());
        request.setAttribute("netsUnionChannel", netsUnionChannel);
        request.setAttribute("batchId", checkBillForm.getBatchId());
        return "netsUnionCheckbill/uploadBankTrans";
    }

    @RequestMapping(params = "method=saveUploadFile")
    @FormToken(save = true)
    // 上传对账文件
    public String upload(HttpServletRequest request, CheckBillForm checkBillForm){
        String path = "netsUnionCheckbill/uploadBankTrans";
        UserInfo user = (UserInfo) (request.getSession().getAttribute(Constants.SESSION_KEY_USER));
        try {
            checkBillService.netsUnionUploadFile(checkBillForm, user.getUserName());
            List<FileUploadRecord> list = fileUploadRecordService.getNetsUnionUploadRecordList(checkBillForm);
            request.setAttribute("uploadList", list);
            request.setAttribute("accountForm", null);
            path = "netsUnionCheckbill/netsUnionRecordList";
        } catch (BusinessException be) {
            request.setAttribute("errMsg", be.getErrMessage(messageSource));
        } catch (Exception e) {
            request.setAttribute("errMsg", "保存出错！");
            log.info(e.getMessage());
        }
        // 获取通道信息传值到页面
        if (!path.equals("netsUnionCheckbill/netsUnionRecordList")) {
            String[] netsUnionChannel = Constants.NETS_UNION_CHECK_BILL_CHANNEL.split(",");
            request.setAttribute("netsUnionChannel", netsUnionChannel);
            path = "netsUnionCheckbill/uploadBankTrans";
        }
        return path;
    }

    @RequestMapping(params = "method=toNetsUnionAutoBill")
    public String toNetsUnionAutoBill(HttpServletRequest request, CheckBillForm checkBillForm) {
        request.setAttribute("checkBillForm", checkBillForm);
        return "netsUnionCheckbill/netsUnionAutoBill";
    }

    @RequestMapping(params = "method=netsUnionAutoBill")
    public String netsUnionAutoBill(CheckBillForm checkBillForm, HttpServletRequest request) {
        if (!CacheManager.getSimpleFlag(Constants.CHECK_FLAG)){
            CacheManager.setSimpleFlag(Constants.CHECK_FLAG, true);
            ExecutorService pool = null;
            try {
                String checkDate = checkBillForm.getCheckdate();
                List<String> batchList = checkBillService.getAllBatch(checkDate);
                if(batchList == null || batchList.size() == 0){
                    log.info("自动对账：无当天交易对账！");
                    batchList.add("");
                }
                int taskSize = 10;
                // 创建线程池  线程数=通道数量
                pool = Executors.newFixedThreadPool(taskSize);
                // 创建多个有返回值的任务
                List<Future> futureList = new ArrayList<Future>();

                Future future;
                Callable callable;
                for (int i = 0; i < batchList.size(); i++) {
                    callable = new NetssUnionAutoBillCallable(batchList.get(i), checkDate);
                    // 执行任务并获取Future对象
                    future = pool.submit(callable);
                    futureList.add(future);
                }

                // 获取所有并发任务的运行结果
                for (Future f : futureList) {
                    // 从Future对象上获取任务的返回值
                    log.info(f.get().toString());
                }
                request.setAttribute("msg", "自动对账完成");
            } catch (Exception e) {
                e.printStackTrace();
                request.setAttribute("msg", "自动对账出错!");
            } finally {
                //关闭线程池
                if (null != pool) {
                    pool.shutdown();
                }
                CacheManager.setSimpleFlag(Constants.CHECK_FLAG, false);
            }
        } else {
            request.setAttribute("errMsg", "对账中，请稍后!");
        }
        request.setAttribute("title", "自动对账");
        request.setAttribute("closeTitle", "对账列表");
        request.setAttribute("url", "netsUnionCheckBill.htm?method=netsUnionCheckBillList");
        return "common/message";
    }

    public class NetssUnionAutoBillCallable implements Callable<Object> {

        private String batchId;
        private String checkDate;
        public NetssUnionAutoBillCallable (String batchId, String checkDate) {
            this.checkDate = checkDate;
            this.batchId = batchId;
        }
        @Override
        public Object call() throws Exception {
            try {
                log.info("{}批次:{}对账开始", batchId, checkDate);
                long startTime = System.currentTimeMillis();

                CheckBillForm checkBillForm = new CheckBillForm();
                checkBillForm.setBatchId(batchId);
                checkBillForm.setCheckdate(checkDate);
                checkBillForm.setBillType(Constants.CHECK_BILL_2);
                checkBillService.autoUploadNetsUnion(checkBillForm);

                long endTime = System.currentTimeMillis();
                long time = endTime - startTime;
                log.info("{}批次:{}对账结束,对账完成时间【{}】",batchId,checkDate,time);
                return batchId + "对账完成，对账结果" + Constants.STATUS_0000;
            } catch (BusinessException be) {
                return batchId + "对账完成，对账结果" + be.getErrMessage(messageSource);
            } catch (Exception e) {
                e.printStackTrace();
                log.info(e.getMessage());
                return batchId + "对账完成，对账结果" + e.getMessage();
            }
        }
    }

}
