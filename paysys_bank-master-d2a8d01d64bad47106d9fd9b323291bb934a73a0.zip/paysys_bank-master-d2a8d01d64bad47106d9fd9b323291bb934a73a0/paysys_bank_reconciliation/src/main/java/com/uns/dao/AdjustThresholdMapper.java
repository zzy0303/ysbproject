package com.uns.dao;

import java.util.List;
import java.util.Map;

import com.uns.web.form.ThresholdsForm;
import org.springframework.stereotype.Repository;

import com.uns.model.AdjustThreshold;
import com.uns.web.form.ThresholdForm;

@Repository
public interface AdjustThresholdMapper {
	
	List<AdjustThreshold> getAdjustThresholdList(ThresholdForm thresholdForm);
	
	List<String> getActionName();

	List<String> getAccounts(Map<String,List<String>> map);


    List<ThresholdsForm> queryThresholdList(ThresholdsForm thresholdsForm);

    List<ThresholdsForm> queryPreThreshold(Map<String, Object> map);

    Map<String,Object> sumPreAmountFee(Map<String, Object> map);
}
