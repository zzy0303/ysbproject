package com.uns.dao;

import com.uns.model.*;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface TransRefMapper {

    void insertFromEpccDp(List<EpccDpTransRef> epccDpTransRefList);

    void insertFromEpccAuthpay(List<EpccAuthpayTransRef> epccAuthpayTransRefList);

    void insertFromEpccDc(List<EpccDcTransRef> epccDcTransRefList);

    void insertFromEpccGateway(List<EpccGatewayTransRef> epccGatewayTransRefList);

    void insertFromEpccQp(List<EpccQpTransRef> epccQpTransRefList);

    List<Map<String, Object>> getNetsUnionTrans(Integer id);

    void delDataOfCheckdate(String checkdate);

    List<TransRef> getTransRefByDetail(Map params);

	void delTxDataOfCheckDate(String checkdate);

}