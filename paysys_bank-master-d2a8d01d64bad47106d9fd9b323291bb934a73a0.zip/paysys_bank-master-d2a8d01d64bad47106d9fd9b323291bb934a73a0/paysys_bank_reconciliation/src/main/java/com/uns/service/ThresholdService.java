package com.uns.service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.uns.common.exception.BusinessException;
import com.uns.dao.CheckBillTransDetailMapper;
import com.uns.dao.ThresholdAdjustHisMapper;
import com.uns.dao.WhiteAccountMapper;
import com.uns.model.*;
import com.uns.paysys.entity.BailBalance;
import com.uns.web.form.PreThresholdForm;
import com.uns.web.form.ThresholdHisForm;
import com.uns.web.form.ThresholdsForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.dao.AdjustThresholdMapper;
import com.uns.web.form.ThresholdForm;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ThresholdService {

    private Logger logger = LoggerFactory.getLogger(ThresholdService.class);

    @Autowired
    private AdjustThresholdMapper adjustThresholdMapper;

    @Autowired
    private CheckBillTransDetailMapper checkBillTransDetailMapper;

    @Autowired
    private ThresholdAdjustHisMapper thresholdAdjustHisMapper;

    @Autowired
    private WhiteAccountMapper whiteAccountMapper;

    /**
     * 查询阀值调整列表
     *
     * @param thresholdForm
     * @return
     */
    public List<AdjustThreshold> getThresholdList(ThresholdForm thresholdForm) {
        //默认为正常对账交易
        if (null == thresholdForm.getCheckStatus()) {
            thresholdForm.setCheckStatus(Constants.CHECK_STATUS_NORMAL);
        }
        return adjustThresholdMapper.getAdjustThresholdList(thresholdForm);
    }

    /**
     * 获取交易类型
     *
     * @return
     */
    public List<String> getActionName() {
        return adjustThresholdMapper.getActionName();

    }
	/**
	 * 跳转页面获取选中商户名称
	 * @param id
	 * @return
	 */
	public List<String> getAccountList(String id) {
        List<String> idlist = Arrays.asList(id.split(","));
        Map<String, List<String>> map = new HashMap<String, List<String>>(1);
        map.put("list", idlist);
        List<String> accountList = adjustThresholdMapper.getAccounts(map);
        return accountList;
    }
    public List<ThresholdsForm> queryThresholdList(ThresholdsForm thresholdsForm) throws Exception {
        List<ThresholdsForm> thresholdsForms = adjustThresholdMapper.queryThresholdList(thresholdsForm);
        return thresholdsForms;
    }

    public Map<String, Object> sumPreAmountFee(List<PreThresholdForm> preThresholdForms) throws Exception {
        Map<String, Object> map = new HashMap<>();
        BigDecimal SUM_AMOUNT = new BigDecimal(0);
        BigDecimal SUM_WAIT_AMOUNT = new BigDecimal(0);
        BigDecimal SUM_WAIT_AMOUNT_Y = new BigDecimal(0);
        BigDecimal SUM_WAIT_AMOUNT_T = new BigDecimal(0);
        for (PreThresholdForm preThresholdForm : preThresholdForms) {
            SUM_AMOUNT = SUM_AMOUNT.add(preThresholdForm.getSumAmountC());
            SUM_WAIT_AMOUNT = SUM_WAIT_AMOUNT.add(preThresholdForm.getSumWaitAmountC());
            SUM_WAIT_AMOUNT_Y = SUM_WAIT_AMOUNT_Y.add(preThresholdForm.getSumWaitAmountYC());
            SUM_WAIT_AMOUNT_T = SUM_WAIT_AMOUNT_T.add(preThresholdForm.getSumWaitAmountTC());
        }
        map.put("SUM_AMOUNT", SUM_AMOUNT);
        map.put("SUM_WAIT_AMOUNT", SUM_WAIT_AMOUNT);
        map.put("SUM_WAIT_AMOUNT_Y", SUM_WAIT_AMOUNT_Y);
        map.put("SUM_WAIT_AMOUNT_T", SUM_WAIT_AMOUNT_T);
        return map;
    }

    public List<PreThresholdForm> queryPreThreshold(List<PreThresholdForm> thresholdsFormList) throws Exception {

        List<PreThresholdForm> list = new ArrayList<>();
        //SUM_AMOUNT,SUM_WAIT_AMOUNT,SUM_WAIT_AMOUNT_Y,SUM_WAIT_AMOUNT_T

        for (PreThresholdForm preThresholdForm : thresholdsFormList) {
            if (null == preThresholdForm.getCheckedId()){
                continue;
            }
            list.add(preThresholdForm);

        }
        return list;
    }

    protected List<String> getActionSeqs(Object[] arrParam) {
        List<String> actionSeqs = new ArrayList<>();
        String[] param;
        for (int i = 0; i < arrParam.length; i++) {
            param = arrParam[i].toString().split("\\|");
            actionSeqs.addAll(whiteAccountMapper.queryActionSeqByAccountId(param[1]));
        }
        return actionSeqs;
    }

    /**
     * 阀值调整
     * @param thresholdsForm
     * @throws BusinessException
     */
    @Transactional(rollbackFor = Exception.class)
    public synchronized void amountThreshold(ThresholdsForm thresholdsForm, UserInfo userInfo) throws Exception {
        //获取阀值参数  参数格式 付款方ID | 付款方SEQ | 对账时间
        List<String> countParamList = thresholdsForm.getCountParamList();
        //获取实调阀值金额
        List<String> waitAmountList = thresholdsForm.getWaitAmountList();
        List<String> waitTurnAmountList = thresholdsForm.getWaitTurnAmountList();
        //获取调整阀值信息
        Map<String, Object> mapNew = new HashMap(1);
        mapNew.put("list", countParamList);
        List<ThresholdsForm> forms = adjustThresholdMapper.queryPreThreshold(mapNew);

        String[] param;
        BigDecimal waitAmountY;
        BigDecimal waitAmountT;
        for (int i = 0; i < forms.size(); i++) {
            param = countParamList.get(i).split("\\|");
            waitAmountY = "".equals(waitAmountList.get(i)) ? BigDecimal.ZERO : new BigDecimal(waitAmountList.get(i));
            waitAmountT = "".equals(waitTurnAmountList.get(i)) ? BigDecimal.ZERO : new BigDecimal(waitTurnAmountList.get(i));
            //判断输入的实调阀值金额是否大于0
            if (waitAmountY.compareTo(BigDecimal.ZERO) == 1){
                //调用接口调整阀值
                this.amountThresholdY(param[0], waitAmountY, userInfo);
            }
            //判断输入的实调结转金额是否大于0
            if (waitAmountT.compareTo(BigDecimal.ZERO) == 1){
                //调用接口调整结转
                this.amountThresholdT(param[1], waitAmountT);
            }
            //调用成功 修改对账状态为已调阀值
            this.updateThreshold(param);
            //添加阀值调整历史
            this.saveThresholdAdjustHis(forms.get(i), waitAmountY.add(waitAmountT), userInfo.getId());
        }
    }

    /**
     * 修改对账记录状态为已调阀值
     * @param param
     */
    protected void updateThreshold(String[] param) throws Exception {
        Map<String, Object> map = new HashMap<>(3);
        List<String> actionSeqs;
        //查询阀值调整的交易类型
        actionSeqs = whiteAccountMapper.queryActionSeqByAccountId(param[1]);
        map.put("creditSeq", param[1]);
        map.put("checkDate", param[2]);
        map.put("actionSeq", actionSeqs);

        checkBillTransDetailMapper.updateByParam(map);
    }

    /**
     * 调整银生宝阀值余额
     * @param creditSeq
     * @param waitAmountY
     * @param userInfo
     * @return
     * @throws Exception
     */
    protected void amountThresholdY(String creditSeq, BigDecimal waitAmountY, UserInfo userInfo) throws Exception{
        BailBalance bailBalance = new BailBalance();
        bailBalance.setMerchantSeq(Long.valueOf(creditSeq));
        //实时代付（接口）
        bailBalance.setActionSeq(Long.valueOf(Constants.ACTION_TYPE_207));
        bailBalance.setAmount(waitAmountY);
        bailBalance.setUpdateUser(userInfo.getId().toString());
        logger.info("调用接口阀值调整请求参数：{}", JSONObject.toJSON(bailBalance));
        /*bailBalance = bailBalanceServiceImpl.modifyBailBalance(bailBalance);*/
        logger.info("调用接口阀值调整返回参数：{}", JSONObject.toJSON(bailBalance));
        //如果调用未成功  直接抛出异常 终止业务
        if (!bailBalance.isSuccessFlag()) {
            throw new BusinessException(bailBalance.getMessage());
        }
    }

    /**
     * 调整银生宝结转余额
     * @param defaultSubSeq
     * @param waitAmountT
     * @throws Exception
     */
    protected void amountThresholdT(String defaultSubSeq, BigDecimal waitAmountT) throws Exception{
        Map<String, String> paramMap = new HashMap<String, String>(6);
        Map<String, String> res;
        paramMap.put("creditSeq", defaultSubSeq);
        paramMap.put("amount", waitAmountT.toString());
        paramMap.put("orderId", new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date())+defaultSubSeq);
        //结转资金来源  1:银生宝 2:新代扣
        paramMap.put("amountSource", Constants.FLAG_2);
        paramMap.put("purpose", "结转");
        paramMap.put("remark", "结转");
        logger.info("调用接口结转调整请求参数：{}", JSONObject.toJSON(paramMap));
        /*res = transferBusinessService.recharge(paramMap);
        logger.info("调用接口结转调整返回参数：{}", JSONObject.toJSON(res));
        if (!Constants.STATUS_0000.equals(res.get("result_code"))){
            throw new BusinessException(res.get("result_msg"));
        }*/
    }

    /**
     * 保存余额阀值历史
     */
    @Async
    protected void saveThresholdAdjustHis(ThresholdsForm form, BigDecimal amount, Long id) throws Exception {
        ThresholdAdjustHis thresholdAdjustHis = new ThresholdAdjustHis();
        thresholdAdjustHis.setAccountId(form.getAccountId());
        thresholdAdjustHis.setAccountName(form.getAccountName());
        thresholdAdjustHis.setCheckDate(form.getCheckDate());
        thresholdAdjustHis.setBillCount(form.getCount());
        thresholdAdjustHis.setBillAmount(form.getSumAmount());
        thresholdAdjustHis.setBillFee(form.getSumFee());
        thresholdAdjustHis.setThresholdAmount(form.getSumWaitAmount());
        thresholdAdjustHis.setThresholdedAmount(amount);
        thresholdAdjustHis.setOperator(new BigDecimal(id));
        thresholdAdjustHis.setCreateTime(new Date());
        thresholdAdjustHisMapper.insertSelective(thresholdAdjustHis);
    }

    public List<CheckBillTransDetail> queryThresholdInfoList(ThresholdsForm thresholdsForm) throws Exception{
        Map<String, String> map = new HashMap<>(2);
        String[] param = thresholdsForm.getCountParam().split("\\|");
        map.put("creditSeq", param[1]);
        map.put("checkDate", param[2]);
        List<CheckBillTransDetail> checkBillTransDetails = checkBillTransDetailMapper.queryThresholdInfoList(map);
        return checkBillTransDetails;
    }

    public List<ThresholdAdjustHis> queryThresholdHisList(ThresholdHisForm thresholdHisForm) throws Exception {
        return thresholdAdjustHisMapper.getThresholdHisList(thresholdHisForm);
    }

    public Map<String, Object> sumThresholdHisAmountFee(ThresholdHisForm thresholdHisForm) throws Exception {
        return thresholdAdjustHisMapper.sumThresholdHisAmountFee(thresholdHisForm);
    }
}
