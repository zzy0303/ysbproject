package com.uns.model;

import java.util.Date;

public class BankTrans {
	private Long id;

	private String transId;

	private Date transDate;

	private String channel;

	private Date transTime;

	private Double amount;

	private Long uploadId;

	private String merchantCode;

	private String transTimeStr;

	private String bankBusiType;//银行交易类别

	private String bankBusiStatus;//交易状态

	private String payOrgIdSeq;//付款行所属机构

	private String destOrgIdSeq;//收款行所属机构编码

	private String batchId;//网联交易批次号

	private String fileName;

	private String bankTransId;

	public String getBankTransId() {
		return bankTransId;
	}

	public void setBankTransId(String bankTransId) {
		this.bankTransId = bankTransId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	public String getBankBusiType() {
		return bankBusiType;
	}

	public void setBankBusiType(String bankBusiType) {
		this.bankBusiType = bankBusiType;
	}

	public String getBankBusiStatus() {
		return bankBusiStatus;
	}

	public void setBankBusiStatus(String bankBusiStatus) {
		this.bankBusiStatus = bankBusiStatus;
	}

	public String getPayOrgIdSeq() {
		return payOrgIdSeq;
	}

	public void setPayOrgIdSeq(String payOrgIdSeq) {
		this.payOrgIdSeq = payOrgIdSeq;
	}

	public String getDestOrgIdSeq() {
		return destOrgIdSeq;
	}

	public void setDestOrgIdSeq(String destOrgIdSeq) {
		this.destOrgIdSeq = destOrgIdSeq;
	}

	public String getTransTimeStr() {
		return transTimeStr;
	}

	public void setTransTimeStr(String transTimeStr) {
		this.transTimeStr = transTimeStr;
	}

	public String getMerchantCode() {
		return merchantCode;
	}

	public void setMerchantCode(String merchantCode) {
		this.merchantCode = merchantCode;
	}

	public Long getUploadId() {
		return uploadId;
	}

	public void setUploadId(Long uploadId) {
		this.uploadId = uploadId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTransId() {
		return transId;
	}

	public void setTransId(String transId) {
		this.transId = transId == null ? null : transId.trim();
	}

	public Date getTransDate() {
		return transDate;
	}

	public void setTransDate(Date transDate) {
		this.transDate = transDate;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel == null ? null : channel.trim();
	}

	public Date getTransTime() {
		return transTime;
	}

	public void setTransTime(Date transTime) {
		this.transTime = transTime;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

}