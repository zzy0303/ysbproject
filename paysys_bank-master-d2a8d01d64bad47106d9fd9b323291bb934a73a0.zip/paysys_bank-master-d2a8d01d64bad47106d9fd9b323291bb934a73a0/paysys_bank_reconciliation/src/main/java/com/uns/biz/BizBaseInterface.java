package com.uns.biz;

import java.util.List;
import java.util.Map;

import com.uns.model.BankTrans;
import com.uns.model.CheckBill;
import com.uns.web.form.CheckBillForm;

public interface BizBaseInterface {
	public List<Map<String, Object>> readBizValue(Integer id, Map<String, Object> maps,
			Map<String, List<String>> setting) throws Exception;

	public boolean checkInputData(String[] data, CheckBillForm checkBillForm, BankTrans trans,
			Map<String, List<String>> setting) throws Exception;

	public List<BankTrans> readBizBank(Map<String, Object> param) throws Exception;

	public boolean checkHandUp(BankTrans bankTrans, CheckBill cb) throws Exception;
}
