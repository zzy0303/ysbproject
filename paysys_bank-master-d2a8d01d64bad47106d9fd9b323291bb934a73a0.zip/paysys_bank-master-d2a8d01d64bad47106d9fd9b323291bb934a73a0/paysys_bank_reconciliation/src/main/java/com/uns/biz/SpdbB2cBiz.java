package com.uns.biz;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import com.uns.model.BankTrans;
import com.uns.web.form.CheckBillForm;

public class SpdbB2cBiz extends DefaultBiz {
	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

	@Override
	public boolean checkInputData(String[] data, CheckBillForm checkBillForm, BankTrans trans,
			Map<String, List<String>> setting) throws Exception {

		trans.setTransId(sdf.format(trans.getTransDate()) + trans.getTransId());

		return super.checkInputData(data, checkBillForm, trans, setting);
	}
}
