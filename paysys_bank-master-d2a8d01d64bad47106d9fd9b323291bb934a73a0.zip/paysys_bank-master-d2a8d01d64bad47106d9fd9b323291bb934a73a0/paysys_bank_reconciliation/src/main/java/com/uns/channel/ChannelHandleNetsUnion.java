package com.uns.channel;

import com.uns.common.Constants;
import com.uns.model.BankTrans;
import com.uns.util.AnalyExcel;
import com.uns.util.ZipUtils;
import com.uns.web.form.CheckBillForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.*;
import java.util.List;
import java.util.Map;

@Component
public class ChannelHandleNetsUnion extends ChannelHandleDefault implements ChannelHandleInterface{

    @Override
    public List<BankTrans> loadDate(InputStream inputStream, CheckBillForm checkBillForm){
        List<BankTrans> list = null;
        try {
            InputStream txtFile = ZipUtils.getTxtInputStream(inputStream);
            list =  AnalyExcel.loadNetsUnion(txtFile, checkBillForm, Constants.UPLOAD_NETS_UNION_TXT);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<Map<String, Object>> getLocalTrans(Integer id) throws Exception {
        return transRefMapper.getNetsUnionTrans(id);
    }

    @Override
    public Map<String, Object> getLocalAmount(String channel, String checkDate) {
        return null;
    }

    @Override
    public List<String> getChannelList() throws Exception {
        return null;
    }
}
