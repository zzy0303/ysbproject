package com.uns.util;

import com.uns.common.Constants;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPClientConfig;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;

import java.io.*;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.InflaterInputStream;

public class FTPManager {

	// private static String encoding = System.getProperty("file.encoding");
	private static String encoding = "UTF-8";

	private static FTPClient ftpClient = new FTPClient();

	/**
	 * Description: 向FTP服务器上传文件
	 * 
	 * @param url
	 *            FTP服务器hostname
	 * @param port
	 *            FTP服务器端口
	 * @param username
	 *            FTP登录账号
	 * @param password
	 *            FTP登录密码
	 * @param path
	 *            FTP服务器保存目录
	 * @param filename
	 *            上传到FTP服务器上的文件名
	 * @param input
	 *            输入流
	 * @return 成功返回true，否则返回false
	 */
	public boolean upFile(String url, int port, String username, String password, String path, String filename, InputStream input) throws Exception {
		boolean success = false;
		FTPClient ftp = new FTPClient();
		try {
			System.out.println("上传文件开始，服务器：" + url + ",端口号：" + port + ",文件夹名称：" + path + ",文件名：" + filename + "用户名：" + username);
			int reply;
			ftp.connect(url, port);
			ftp.login(username, password);
			reply = ftp.getReplyCode();
			if (!FTPReply.isPositiveCompletion(reply)) {
				ftp.disconnect();
				return success;
			}
			createDirOnFTP(ftp, path);

			ftp.changeWorkingDirectory(new String(path.getBytes(encoding), "ISO-8859-1"));
			ftp.setFileType(FTPClient.BINARY_FILE_TYPE);
			ftp.storeFile(filename, input);

			input.close();
			ftp.logout();
			success = true;
			System.out.println("上传文件结束，服务器：" + url + ",端口号：" + port + ",文件夹名称：" + path + ",文件名：" + filename + "用户名：" + username);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (ftp.isConnected()) {
				try {
					ftp.disconnect();
				} catch (IOException ioe) {
				}
			}
		}
		return success;
	}

	/**
	 * Description: 从FTP服务器下载文件
	 * @param remotePath
	 *            FTP服务器上的相对路径
	 * @param fileName
	 *            要下载的文件名
	 * @param localPath
	 *            下载后保存到本地的路径
	 * @return
	 */
	public boolean downFile(String remotePath, String fileName, String localPath) throws Exception {
		boolean success = false;
		FTPClient ftp = new FTPClient();
		try {
			int reply;
			/*ftp.connect(url, port);*/
			ftp.connect(Constants.FTP_URL);
			// 如果采用默认端口，可以使用ftp.connect(url)的方式直接连接FTP服务器
			ftp.login(Constants.FTP_USERNAME, Constants.FTP_PASSWORD);// 登录
			reply = ftp.getReplyCode();
			if (!FTPReply.isPositiveCompletion(reply)) {
				ftp.disconnect();
				return success;
			}
			System.out.println("encoding:" + encoding);
			// ftp.changeWorkingDirectory(new
			// String(remotePath.getBytes(encoding),"ISO-8859-1"));//转移到FTP服务器目录
			File file = new File(remotePath);
			String dirParent = file.getParentFile().getPath();
			String dirSon = file.getPath().substring(remotePath.indexOf("/") + 1);
			if (ftp.changeWorkingDirectory(dirParent)) {
				ftp.changeWorkingDirectory(dirSon);
			}
			System.out.println(ftp.listFiles().length);
			FTPFile[] fs = ftp.listFiles();
			for (FTPFile ff : fs) {
				System.out.println(ff.getName());
				if (file.exists()) {
					ftp.changeWorkingDirectory(file.getPath());
				}
				if (ff.getName().contains(fileName)) {
					if (file.exists() && file.isDirectory()) {
						ftp.changeWorkingDirectory(file.getPath());
					}
					File localFile = new File(localPath + "/" + ff.getName());
					OutputStream is = new FileOutputStream(localFile);
					ftp.retrieveFile(ff.getName(), is);
					is.close();
				}
			}

			ftp.logout();
			success = true;
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (ftp.isConnected()) {
				try {
					ftp.disconnect();
				} catch (IOException ioe) {
					ioe.printStackTrace();
				}
			}
		}
		return success;
	}

	public List<InputStream> getFiles(String remotePath, String fileName) throws Exception {
		FTPClient ftp = new FTPClient();
		String path = Constants.FTP_PATH +"/" + remotePath ;
		List<InputStream> list = new ArrayList<>();
		List<String> fileNames = new ArrayList<>();
		try {
			int reply;
			ftp.connect(Constants.FTP_URL);
			ftp.login(Constants.FTP_USERNAME, Constants.FTP_PASSWORD);// 登录
			reply = ftp.getReplyCode();
			if (!FTPReply.isPositiveCompletion(reply)) {
				ftp.disconnect();
			}
			if (path != null) {//验证是否有该文件夹，有就转到，没有创建后转到该目录下
				ftp.changeWorkingDirectory(path);//转到指定目录下
			}
			ftp.setControlEncoding("UTF-8");
			ftp.setFileType(ftp.BINARY_FILE_TYPE);
			ftp.enterLocalPassiveMode();
			FTPFile[] fs = ftp.listFiles();
			for (FTPFile ff : fs) {
				if (ff.getName().contains(fileName)) {
					String remoteAbsoluteFile = toFtpFilename(path + "/" + ff.getName());
					fileNames.add(remoteAbsoluteFile);
				}
			}
			for (String name : fileNames) {
				InputStream in = getFile(name);
				list.add(in);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if (ftp.isConnected()) {
				try {
					ftp.disconnect();
				} catch (IOException ioe) {
					ioe.printStackTrace();
				}
			}
		}
		return list;
	}

	public List<InputStream> getNetsUnionFiles(String remotePath, String fileName) throws Exception {
		FTPClient ftp = new FTPClient();
		String path = Constants.FTP_PATH +"/" + remotePath ;
		List<InputStream> list = new ArrayList<>();
		List<String> fileNames = new ArrayList<>();
		try {
			int reply;
			ftp.connect(Constants.FTP_URL);
			ftp.login(Constants.FTP_USERNAME, Constants.FTP_PASSWORD);// 登录
			reply = ftp.getReplyCode();
			if (!FTPReply.isPositiveCompletion(reply)) {
				ftp.disconnect();
			}
			if (path != null) {//验证是否有该文件夹，有就转到，没有创建后转到该目录下
				ftp.changeWorkingDirectory(path);//转到指定目录下
			}
			ftp.setControlEncoding("UTF-8");
			ftp.setFileType(ftp.BINARY_FILE_TYPE);
			ftp.enterLocalPassiveMode();
			FTPFile[] fs = ftp.listFiles();
			for (FTPFile ff : fs) {
				if (ff.getName().contains(fileName)) {
					path = path + "/" + ff.getName();
					ftp.changeWorkingDirectory(path);
					FTPFile[] fsFiles = ftp.listFiles();
					for(FTPFile ftpFile : fsFiles){
						if(ftpFile.getName().contains(fileName) && ftpFile.getName().contains("B") && !ftpFile.getName().contains("HZ")){
							String remoteAbsoluteFile = toFtpFilename(path + "/" + ftpFile.getName());
							fileNames.add(remoteAbsoluteFile);
						}
					}
				}
			}
			for (String name : fileNames) {
				InputStream in = getFile(name);
				list.add(in);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if (ftp.isConnected()) {
				try {
					ftp.disconnect();
				} catch (IOException ioe) {
					ioe.printStackTrace();
				}
			}
		}
		return list;
	}

	public InputStream getFile (String fileName) {
		FTPClient ftp = new FTPClient();
		int reply;
		InputStream in = null;
		try {
			ftp.connect(Constants.FTP_URL);
			ftp.login(Constants.FTP_USERNAME, Constants.FTP_PASSWORD);// 登录
			reply = ftp.getReplyCode();
			if (!FTPReply.isPositiveCompletion(reply)) {
				ftp.disconnect();
			}
			ftp.setControlEncoding("UTF-8");
			ftp.setFileType(ftp.BINARY_FILE_TYPE);
			ftp.enterLocalPassiveMode();
			in = ftp.retrieveFileStream(fileName);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (ftp.isConnected()) {
				try {
					ftp.disconnect();
				} catch (IOException ioe) {
					ioe.printStackTrace();
				}
			}
		}
		return in;
	}

	/*public synchronized List<InputStream> getFile(String remotePath, String fileName) throws Exception {
		FTPClient ftp = new FTPClient();
		//   /autobill/unionpay_td2/unionpay_td2-20171104.txt
		String path = Constants.FTP_PATH +"/" + remotePath ;
		List<InputStream> list = new ArrayList<>();
		try {
			int reply;
			ftp.connect(Constants.FTP_URL);
			// 如果采用默认端口，可以使用ftp.connect(url)的方式直接连接FTP服务器
			ftp.login(Constants.FTP_USERNAME, Constants.FTP_PASSWORD);// 登录
			reply = ftp.getReplyCode();
			if (!FTPReply.isPositiveCompletion(reply)) {
				ftp.disconnect();
			}
			// 转到指定下载目录
			if (path != null) {//验证是否有该文件夹，有就转到，没有创建后转到该目录下
				ftp.changeWorkingDirectory(path);//转到指定目录下
			}
			ftp.setControlEncoding("UTF-8");
			ftp.setFileType(ftp.BINARY_FILE_TYPE);
			ftp.enterLocalPassiveMode();
			FTPFile[] fs = ftp.listFiles();
			for (FTPFile ff : fs) {
				if (ff.getName().contains(fileName)) {
					String remoteAbsoluteFile = toFtpFilename(path + "/" + ff.getName());
					InputStream in = ftp.retrieveFileStream(remoteAbsoluteFile);
					list.add(in);
					ftp.getReply();
				}
			}
			*//*ftp.logout();*//*
			// 下载文件
			*//*in.close();*//*
		} catch (IOException e) {
			System.out.println("++++++++++++++"+fileName+"++++++++++++");
			throw e;
		} finally {
			if (ftp.isConnected()) {
				try {
					ftp.disconnect();
				} catch (IOException ioe) {
					ioe.printStackTrace();
				}
			}
		}
		return list;
	}*/

	/**转化输出的编码*/
	private static String toFtpFilename(String fileName) throws Exception {
		return new String(fileName.getBytes("GBK"),"ISO8859-1");
	}

	/**
	 * 本方法用户登录远程的FTP服务器
	 * 
	 * @param url
	 *            :表示FTP的IP地址
	 * @param port
	 *            :FTP服务器端口，默认端口为21
	 * @param userName
	 *            :登录FTP的用户名
	 * @param password
	 *            :登录FTP的密码
	 * 
	 * @return FTPClient:返回为FTPClient对象
	 */
	public FTPClient loginFtp(String url, int port, String userName, String password) {
		try {
			ftpClient.connect(url, port);
			ftpClient.setControlEncoding("UTF-8");
			FTPClientConfig ftpConfig = new FTPClientConfig(FTPClientConfig.SYST_NT);
			ftpConfig.setServerLanguageCode("zh");
			ftpClient.login(userName, password);
			int reply = 0;
			reply = ftpClient.getReplyCode();
			System.out.println(reply);
			if (FTPReply.isPositiveCompletion(reply)) {
				System.out.println("登录成功！");
			} else {
				System.out.println("登录失败！");
			}
		} catch (SocketException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return ftpClient;
	}

	/**
	 * 在FTP服务器上创建目录
	 * 
	 * @return
	 * @throws IOException
	 */
	public void createDirOnFTP(FTPClient ftp, String path) throws IOException {
		if (StringUtils.isEmpty(path)) {
			return;
		}
		boolean isExistFalg = ftp.changeWorkingDirectory(path);
		if (!isExistFalg) {
			ftp.makeDirectory(path);
		}
	}
}
