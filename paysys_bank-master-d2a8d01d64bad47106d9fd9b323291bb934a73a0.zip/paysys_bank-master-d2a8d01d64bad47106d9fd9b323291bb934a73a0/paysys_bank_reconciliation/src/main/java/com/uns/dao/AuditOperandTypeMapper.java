package com.uns.dao;

import java.math.BigDecimal;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.AuditOperandType;

@Repository
public interface AuditOperandTypeMapper {

	int deleteByPrimaryKey(BigDecimal id);

	int insert(AuditOperandType record);

	int insertSelective(AuditOperandType record);

	AuditOperandType selectByPrimaryKey(BigDecimal id);

	int updateByPrimaryKeySelective(AuditOperandType record);

	int updateByPrimaryKey(AuditOperandType record);

	AuditOperandType getAuditOperandType(Map<String, Object> map);
}