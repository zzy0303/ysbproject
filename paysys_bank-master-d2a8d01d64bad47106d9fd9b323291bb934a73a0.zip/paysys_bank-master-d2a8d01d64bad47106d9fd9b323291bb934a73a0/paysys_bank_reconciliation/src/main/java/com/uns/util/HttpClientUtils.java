package com.uns.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import net.sf.json.JSONObject;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import com.uns.common.exception.BusinessException;

public class HttpClientUtils {
	private static Log log = LogFactory.getLog(HttpClientUtils.class);

	public static int postRequestStr(String url, String request) {
		log.info("request params : " + url);
		HttpPost put = new HttpPost(url);
		int statusCode = 200;
		try {
			StringEntity entity = new StringEntity(request, "UTF-8");
			entity.setContentType("application/x-www-form-urlencoded");
			put.setEntity(entity);

			HttpClient client = new DefaultHttpClient();
			HttpResponse httpRes = client.execute(put);
			statusCode = httpRes.getStatusLine().getStatusCode();

			log.info("response status : " + statusCode);
			if (statusCode != 200) {
                log.info("网络请求应答状态错误：" + statusCode);
            }
			return statusCode;
		} catch (Exception e) {
			log.info("网络连接错误：" + e.getMessage());
		}
		return statusCode;
	}

	public static int postRequestMap(String url, Map<String, ?> reqMap) {
		log.info("request params : " + url);
		HttpPost put = new HttpPost(url);
		int statusCode = 200;
		try {
			StringBuffer str = new StringBuffer();
			Iterator<String> ite = reqMap.keySet().iterator();
			String mKey = null;
			while (ite.hasNext()) {
				mKey = ite.next();
				str.append(mKey).append("=").append(reqMap.get(mKey)).append("&");
			}
			str = str.deleteCharAt(str.lastIndexOf("&"));

			statusCode = postRequestStr(url, str.toString());
			log.info("response status : " + statusCode);
			if (statusCode != 200) {
                log.info("网络请求应答状态错误：" + statusCode);
            }
			return statusCode;
		} catch (Exception e) {
			log.info("网络连接错误：" + e.getMessage());
		}
		return statusCode;
	}

	public static Integer postRequestUrl(String url) {
		int result = 0;
		try {
			URL u = new URL(url);
			try {
				HttpURLConnection uConnection = (HttpURLConnection) u.openConnection();
				try {
					uConnection.connect();
					result = uConnection.getResponseCode();
					log.info(uConnection.getResponseCode());

					InputStream is = uConnection.getInputStream();
					BufferedReader br = new BufferedReader(new InputStreamReader(is));
					StringBuilder sb = new StringBuilder();
					while (br.read() != -1) {
						sb.append(br.readLine());
					}

					String content = new String(sb);
					content = new String(content.getBytes("GBK"), "ISO-8859-1");
					log.info(content);
					br.close();
				} catch (Exception e) {
					log.info("connect failed");
					e.printStackTrace();
				}

			} catch (IOException e) {
				log.info("build failed");
				e.printStackTrace();
			}

		} catch (MalformedURLException e) {
			log.info("build url failed");
			e.printStackTrace();
		}

		return result;
	}

	public static String postRequestXml(String url, String xml) {
		log.info("request params : " + url);
		HttpPost put = new HttpPost(url);
		String result = "";
		try {
			log.info("request params :" + xml);
			StringEntity entity = new StringEntity(xml, "UTF-8");
			entity.setContentType("text/plain");
			put.setEntity(entity);

			HttpClient client = new DefaultHttpClient();

			HttpResponse httpRes = client.execute(put);
			int statusCode = httpRes.getStatusLine().getStatusCode();

			log.info("response status : " + statusCode);
			if (statusCode == 200) {
				result = EntityUtils.toString(httpRes.getEntity(), "UTF-8");
			} else {
				result = "0098网络请求应答状态错误：" + statusCode;
			}
			return result;
		} catch (Exception e) {
			result = "0099网络连接错误：" + e.getMessage();
		}
		log.info("response params : " + result);
		return xml;
	}

	public static String REpostRequestStr(String url, String request) throws BusinessException {
		log.info("start post request url:" + url);
		HttpPost put = new HttpPost(url);
		int statusCode = 200;
		try {
			StringEntity entity = new StringEntity(request, "UTF-8");
			entity.setContentType("application/json;charset=UTF-8");
			put.setEntity(entity);
			HttpClient client = new DefaultHttpClient();

			HttpResponse httpRes = client.execute(put);
			statusCode = httpRes.getStatusLine().getStatusCode();

			log.info("request end,status : " + statusCode);
			if (statusCode != 200) {
                throw new BusinessException("0098", "网络请求应答状态错误：" + statusCode);
            }

			String result = EntityUtils.toString(httpRes.getEntity(), "UTF-8");
			return result;
		} catch (Exception e) {
			log.info("网络连接错误：" + e.getMessage());
			throw new BusinessException("0099", "网络连接错误：" + e.getMessage());
		}
	}

	public static String RE1postRequestStr(String url, String request) throws BusinessException {
		log.info("start post request url:" + url);
		HttpPost put = new HttpPost(url);
		int statusCode = 200;
		try {
			StringEntity entity = new StringEntity(request, "UTF-8");
			entity.setContentType("application/x-www-form-urlencoded");
			put.setEntity(entity);
			HttpClient client = new DefaultHttpClient();

			HttpResponse httpRes = client.execute(put);
			statusCode = httpRes.getStatusLine().getStatusCode();

			log.info("request end,status : " + statusCode);
			if (statusCode != 200) {
                throw new BusinessException("0098", "网络请求应答状态错误：" + statusCode);
            }

			String result = EntityUtils.toString(httpRes.getEntity(), "UTF-8");
			return result;
		} catch (Exception e) {
			log.info("网络连接错误：" + e.getMessage());
			throw new BusinessException("0099", "网络连接错误：" + e.getMessage());
		}
	}

	public static String getRequestUrl(String url) throws BusinessException, Exception {
		log.info("start get request url:" + url);
		HttpGet put = new HttpGet(url);
		int statusCode = 200;
		String result = "";
		try {
			HttpClient client = new DefaultHttpClient();
			HttpResponse httpRes = client.execute(put);
			statusCode = httpRes.getStatusLine().getStatusCode();

			if (statusCode == 200) {
				result = EntityUtils.toString(httpRes.getEntity(), "UTF-8");
				return result;
			}
		} catch (Exception e) {
			log.info("网络连接错误：" + e.getMessage());
		}
		return result;
	}

	public static <T> T postRequest(String url, Object request, Class<T> clazz) throws Exception {

		HttpPost put = new HttpPost(url);
		try {
			log.info("request params : " + JsonUtil.toJSONString(request));
			StringEntity entity = new StringEntity(JsonUtil.toJSONString(request), "UTF-8");
			entity.setContentType("application/json");
			put.setEntity(entity);

			HttpClient client = new DefaultHttpClient();

			HttpResponse httpRes = client.execute(put);
			int statusCode = httpRes.getStatusLine().getStatusCode();
			log.info("response status : " + statusCode);
			if (statusCode != 200) {
                throw new BusinessException("0098", "网络请求应答状态错误：" + statusCode);
            }
			return JsonUtil.readValue(httpRes.getEntity().getContent(), clazz);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException("0099", "网络连接错误：" + e.getMessage());
		}
	}

	public static <T> T postRequestMap(String url, Map<String, ?> reqMap, Class<T> clazz) throws Exception {
		StringBuffer str = new StringBuffer();

		Iterator<String> ite = reqMap.keySet().iterator();
		String mKey = null;

		while (ite.hasNext()) {
			mKey = ite.next();
			str.append(mKey).append("=").append(reqMap.get(mKey)).append("&");
		}

		str = str.deleteCharAt(str.lastIndexOf("&"));
		return postRequestStr1(url, str.toString(), clazz);

	}

	public static <T> T postRequestStr1(String url, String request, Class<T> clazz) throws Exception {
		log.info("start post request url:" + url);
		HttpPost put = new HttpPost(url);
		int statusCode = 200;
		try {
			StringEntity entity = new StringEntity(request, "UTF-8");
			entity.setContentType("application/x-www-form-urlencoded");
			put.setEntity(entity);
			HttpClient client = new DefaultHttpClient();

			HttpResponse httpRes = client.execute(put);
			statusCode = httpRes.getStatusLine().getStatusCode();

			log.info("request end,status : " + statusCode);
			if (statusCode != 200) {
                log.info("网络请求应答状态错误：" + statusCode);
            }
			log.info(httpRes.getEntity().getContent());

			return JsonUtil.readValue(httpRes.getEntity().getContent(), clazz);
		} catch (Exception e) {
			log.info("网络连接错误：" + e.getMessage());
			throw new BusinessException("0099", "网络连接错误：" + e.getMessage());
		}
	}

	public static <T> T postJsonRequestMap(String url, Map<String, ?> reqMap, Class<T> clazz) throws Exception {
		return postJsonRequestStr1(url, JSONObject.fromObject(reqMap).toString(), clazz);

	}

	public static <T> T postJsonRequestStr1(String url, String request, Class<T> clazz) throws Exception {
		log.info("start post request url:" + url);
		HttpPost put = new HttpPost(url);
		int statusCode = 200;
		try {
			StringEntity entity = new StringEntity(request, "UTF-8");
			entity.setContentType("application/json");
			put.setEntity(entity);
			HttpClient client = new DefaultHttpClient();

			HttpResponse httpRes = client.execute(put);
			statusCode = httpRes.getStatusLine().getStatusCode();

			log.info("request end,status : " + statusCode);
			if (statusCode != 200) {
                log.info("网络请求应答状态错误：" + statusCode);
            }
			log.info(httpRes.getEntity().getContent());

			return JsonUtil.readValue(httpRes.getEntity().getContent(), clazz);
		} catch (Exception e) {
			log.info("网络连接错误：" + e.getMessage());
			throw new BusinessException("0099", "网络连接错误：" + e.getMessage());
		}
	}

	public static void main(String[] args) {
		Map map0 = new LinkedHashMap();
		map0.put("billId", "12344433");
		map0.put("returnCode", "0000");
		map0.put("status", "1");
		map0.put("realCharge", "3000");
		map0.put("errorMsg", "非法请求!");
		map0.put("mac", "aaaabvbbbccccdeeff");

		HttpClientUtils.postRequestMap("http://www.baidu000.com?", map0);
	}

	public static String REpostRequestStrNormal(String url, String request) throws Exception {
		log.info("start post request url:" + url);
		HttpPost put = new HttpPost(url);
		int statusCode = 200;
		try {
			StringEntity entity = new StringEntity(request, "UTF-8");
			entity.setContentType("application/x-www-form-urlencoded");
			put.setEntity(entity);
			HttpClient client = new DefaultHttpClient();

			HttpResponse httpRes = client.execute(put);
			statusCode = httpRes.getStatusLine().getStatusCode();

			log.info("request end,status : " + statusCode);
			if (statusCode != 200) {
                throw new Exception();
            }

			String result = EntityUtils.toString(httpRes.getEntity(), "UTF-8");
			return result;
		} catch (Exception e) {
			log.info("网络连接错误：" + e.getMessage());
			throw new Exception();
		}
	}

}
