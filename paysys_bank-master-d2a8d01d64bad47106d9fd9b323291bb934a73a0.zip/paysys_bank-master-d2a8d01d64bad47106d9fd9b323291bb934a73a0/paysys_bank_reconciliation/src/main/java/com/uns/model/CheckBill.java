package com.uns.model;

import java.util.Date;

public class CheckBill {
	private Long id;

	private Date checkDate;

	private String channel;

	private Double localAmount;

	private Double bankAmount;

	private Integer flatCount;

	private Integer inflatCount;

	private Integer dealInflatCount;

	private String checkStatus;

	private String handler;// 处理人

	private Date handlingTime;// 处理时间

	private Date checkTime;// 对账时间

	private String checkUser;// 对账人

	private String dealRemark;// 处理说明
	
	private String billType; //对账类型

	private String batchId;//网联交易批次号

	public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	public String getBillType() {
		return billType;
	}

	public void setBillType(String billType) {
		this.billType = billType;
	}

	public Integer getDealInflatCount() {
		return dealInflatCount;
	}

	public void setDealInflatCount(Integer dealInflatCount) {
		this.dealInflatCount = dealInflatCount;
	}

	public String getDealRemark() {
		return dealRemark;
	}

	public void setDealRemark(String dealRemark) {
		this.dealRemark = dealRemark;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getCheckDate() {
		return checkDate;
	}

	public void setCheckDate(Date checkDate) {
		this.checkDate = checkDate;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel == null ? null : channel.trim();
	}

	public Double getLocalAmount() {
		return localAmount;
	}

	public void setLocalAmount(Double localAmount) {
		this.localAmount = localAmount;
	}

	public Double getBankAmount() {
		return bankAmount;
	}

	public void setBankAmount(Double bankAmount) {
		this.bankAmount = bankAmount;
	}

	public Date getCheckTime() {
		return checkTime;
	}

	public void setCheckTime(Date checkTime) {
		this.checkTime = checkTime;
	}

	public String getCheckUser() {
		return checkUser;
	}

	public void setCheckUser(String checkUser) {
		this.checkUser = checkUser;
	}

	public Integer getFlatCount() {
		return flatCount;
	}

	public void setFlatCount(Integer flatCount) {
		this.flatCount = flatCount;
	}

	public Integer getInflatCount() {
		return inflatCount;
	}

	public void setInflatCount(Integer inflatCount) {
		this.inflatCount = inflatCount;
	}

	public String getCheckStatus() {
		return checkStatus;
	}

	public void setCheckStatus(String checkStatus) {
		this.checkStatus = checkStatus == null ? null : checkStatus.trim();
	}

	public String getHandler() {
		return handler;
	}

	public void setHandler(String handler) {
		this.handler = handler == null ? null : handler.trim();
	}

	public Date getHandlingTime() {
		return handlingTime;
	}

	public void setHandlingTime(Date handlingTime) {
		this.handlingTime = handlingTime;
	}
}