package com.uns.web.form;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/8/28
 * @Modifyed By:
 */
public class WhiteAccountForm {

    private Long id;
    private String accountId;
    private String name;
    private BigDecimal actionSeq;
    private String status;
    private String beginOperTime;
    private String endOperTime;
    private BigDecimal accountSubSeq;

    public BigDecimal getAccountSubSeq() {
        return accountSubSeq;
    }

    public void setAccountSubSeq(BigDecimal accountSubSeq) {
        this.accountSubSeq = accountSubSeq;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getActionSeq() {
        return actionSeq;
    }

    public void setActionSeq(BigDecimal actionSeq) {
        this.actionSeq = actionSeq;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getBeginOperTime() {
        return beginOperTime;
    }

    public void setBeginOperTime(String beginOperTime) {
        this.beginOperTime = beginOperTime;
    }

    public String getEndOperTime() {
        return endOperTime;
    }

    public void setEndOperTime(String endOperTime) {
        this.endOperTime = endOperTime;
    }
}
