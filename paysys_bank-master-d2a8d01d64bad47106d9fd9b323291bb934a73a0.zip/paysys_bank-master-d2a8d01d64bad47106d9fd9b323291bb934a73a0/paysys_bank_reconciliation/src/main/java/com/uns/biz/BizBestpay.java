package com.uns.biz;

import java.util.List;
import java.util.Map;

import com.uns.model.BankTrans;
import com.uns.web.form.CheckBillForm;

public class BizBestpay extends DefaultBiz {
	protected final static String transStatus = "00000001";

	@Override
	public boolean checkInputData(String[] data, CheckBillForm checkBillForm, BankTrans trans,
			Map<String, List<String>> setting) throws Exception {

		if (transStatus.equals(data[7])) {
			return false;
		}

		return super.checkInputData(data, checkBillForm, trans, setting);
	}
}
