package com.uns.common;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.URL;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JSONUtil {

	private static ObjectMapper mapper = new ObjectMapper();

	public static String toJSONString(Object o) throws IOException {
		return mapper.writeValueAsString(o);
	}

	public static <T> T readValue(String url, Class<T> clz) {
		try {
			URL u = new URL(url);
			return mapper.readValue(u, clz);

		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static <T> T readValue(String url, String params, Class<T> clz) {
		try {
			String param = "?params=" + params;
			URL u = new URL(url + param);
			return mapper.readValue(u, clz);

		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static JavaType getCollectionType(Class<?> collectionClass, Class<?>... elementClasses) {
		return mapper.getTypeFactory().constructParametricType(collectionClass, elementClasses);
	}

	public static void writeTo(PrintWriter writer, Object value) {
		try {
			mapper.writeValue(writer, value);
		} catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static <T> T readParams(String params, Class<T> clz) {
		try {
			return mapper.readValue(params, clz);
		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static <T> T readValue(InputStream content, Class<T> type) throws Exception {
		return mapper.readValue(content, type);
	}

	/**
	 * 将一个对象转换成目标对象
	 * 
	 * @param src
	 * @param dest
	 * @return
	 */
	public static <T> T copyProperties(Object src, Class<T> dest) throws Exception {
		return mapper.readValue(mapper.writeValueAsString(src), dest);
	}

	public static <T> T copyProperties(Object src, JavaType type) throws Exception {
		return mapper.readValue(mapper.writeValueAsString(src), type);
	}
}
