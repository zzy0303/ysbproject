package com.uns.biz;

import java.util.HashMap;
import java.util.Map;

import com.uns.common.Constants;

public class BizMapping {
	private Map<String, BizBaseInterface> bizContent;
	private static BizMapping bizMapping;

	public BizMapping() {
		bizContent = new HashMap<String, BizBaseInterface>();
		bizContent.put(Constants.UPLOAD_DEFAULT, new DefaultBiz());
		bizContent.put(Constants.UPLOAD_BESTPAY, new BizBestpay());
		bizContent.put(Constants.UPLOAD_ICBC_B2C, new BizIcbc());
		bizContent.put(Constants.UPLOAD_YILIAN_KJ, new yiliankjBiz());
		bizContent.put(Constants.UPLOAD_SPDB_B2C, new SpdbB2cBiz());
		bizContent.put(Constants.UPLOAD_CMBC_B2C_D, new BizCmbcB2c());
		bizContent.put(Constants.UPLOAD_CCB_B2C, new BizCcbB2c());
		bizContent.put(Constants.UPLOAD_SPDB_DK, new SpdbDkBiz());
		bizContent.put(Constants.UPLOAD_ABC_B2C, new BizAbcB2c());
	}

	public Map<String, BizBaseInterface> getBizContent() {
		return bizContent;
	}

	public static BizBaseInterface findBizBaseInterface(String channel) {
		if (null == bizMapping) {
			synchronized (BizMapping.class) {
				if (null == bizMapping) {
					bizMapping = new BizMapping();
				}
			}
		}

		if (bizMapping.bizContent.containsKey(channel)) {
			return bizMapping.getBizContent().get(channel);
		}

		return bizMapping.getBizContent().get("default");
	}
}
