package com.uns.web.controller;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.model.UserInfo;
import com.uns.service.AdjustAuditService;
import com.uns.web.form.AdjustAuditForm;

@Controller
@RequestMapping(value = "/adjustAudit.htm")
public class AdjustAuditController extends BaseController {
	@Autowired
	private AdjustAuditService adjustAuditService;

	@RequestMapping(params = "method=adjustAuditList")
	@FormToken(save = true)
	public String adjustAuditList(HttpServletRequest request, AdjustAuditForm adjustAuditForm)
			throws BusinessException {
		UserInfo user = (UserInfo) (request.getSession().getAttribute(Constants.SESSION_KEY_USER));
		adjustAuditForm.setUserId(user.getId().toString());
		// 调账审核列表
		List<Object> adjustAuditList = adjustAuditService.getAdjustAuditList(adjustAuditForm);
		request.setAttribute("auditList", adjustAuditList);
		request.setAttribute("adjustApplyForm", adjustAuditForm);
		return "adjust/adjustAuditList";
	}

	@RequestMapping(params = "method=toAudit")
	@FormToken(save = true)
	public String toAudit(HttpServletRequest request, AdjustAuditForm adjustAuditForm) throws BusinessException {
		// 跳转到调账审核页面
		String[] transId = request.getParameter("transId").split(",");
		String[] applyNo = request.getParameter("applyNo").split(",");
		String[] amount = request.getParameter("amount").split(",");
		// 交易详情
		Map<String, Object> transDetail = null;
		// 审核历史
		List<Map<String, Object>> auditHis = null;
		// 交易总金额，交易笔数;
		Map<String, Object> allBankAmount = new HashMap<String, Object>();
		double allAmount = 0;
		try {
			if (transId.length > 1) {
				for (int i = 0; i < transId.length; i++) {
					allAmount += Double.parseDouble(amount[i].toString());
				}
				BigDecimal amounts = new BigDecimal(allAmount);
				allBankAmount.put("RECORDCOUNT", transId.length);
				allBankAmount.put("allAmount", amounts.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
			} else if (transId.length == 1) {
				transDetail = adjustAuditService.getAuditDetail(transId[0],applyNo[0]);
				/*auditHis = adjustAuditService.getAuditHis(applyNo[0]);*/
			} else {
				request.setAttribute("errMsg", "交易编号不存在！");
			}
		} catch (BusinessException be) {
			ApplicationContext ctx = WebApplicationContextUtils
					.getRequiredWebApplicationContext(request.getSession().getServletContext());
			MessageSource messageSource = (MessageSource) ctx.getBean("messageSource");
			request.setAttribute("errMsg", be.getErrMessage(messageSource));
			request.setAttribute("title", "调账审核详情");
			return "common/message";
		} catch (Exception e) {
			request.setAttribute("errMsg", "系统出错！");
			e.printStackTrace();
			request.setAttribute("title", "调账审核详情");
			return "common/message";
		}
		request.setAttribute("detail", transDetail);
		request.setAttribute("auditHis", auditHis);
		request.setAttribute("allBankAmount", allBankAmount);
		request.setAttribute("allApplayNo", request.getParameter("applyNo"));
		return "adjust/auditDetail";
	}

	@RequestMapping(params = "method=agree")
	@FormToken(save = true)
	public String agree(HttpServletRequest request, AdjustAuditForm adjustAuditForm) throws Exception {
		// 审核同意
		UserInfo user = (UserInfo) (request.getSession().getAttribute(Constants.SESSION_KEY_USER));
		String[] allApplayNos = request.getParameter("allApplayNo").split(",");
		try {
			adjustAuditService.agreeRecord(adjustAuditForm, user.getId(), allApplayNos);
			/*for (int i = 0; i < allApplayNos.length; i++) {
				adjustAuditForm.setApplyNo(allApplayNos[i]);
				adjustAuditService.agree(adjustAuditForm, user.getId());
			}*/
			request.setAttribute("msg", "审核同意成功！");
		} catch (BusinessException be) {
			ApplicationContext ctx = WebApplicationContextUtils
					.getRequiredWebApplicationContext(request.getSession().getServletContext());
			MessageSource messageSource = (MessageSource) ctx.getBean("messageSource");
			request.setAttribute("errMsg", be.getErrMessage(messageSource));
		} catch (Exception e) {
			request.setAttribute("errMsg", "审核出错！");
			e.printStackTrace();
		}
		// return "redirect:/adjustAudit.htm?method=adjustAuditList ";
		request.setAttribute("title", "调账审核详情");
		request.setAttribute("closeTitle", "调账审核列表");
		request.setAttribute("url", "adjustAudit.htm?method=adjustAuditList");
		return "common/message";
	}

	@RequestMapping(params = "method=reject")
	@FormToken(save = true)
	public String reject(HttpServletRequest request, AdjustAuditForm adjustAuditForm) throws Exception {
		// 审核拒绝
		UserInfo user = (UserInfo) (request.getSession().getAttribute(Constants.SESSION_KEY_USER));
		String[] allApplayNos = request.getParameter("allApplayNo").split(",");
		try {
			adjustAuditService.rejectRecord(user.getId(), allApplayNos);
			/*for (int i = 0; i < allApplayNos.length; i++) {
				adjustAuditForm.setApplyNo(allApplayNos[i]);
				adjustAuditService.reject(adjustAuditForm, user.getId());
			}*/
			request.setAttribute("msg", "审核拒绝成功！");
		} catch (Exception e) {
			request.setAttribute("errMsg", "审核出错！");
			e.printStackTrace();
		}
		request.setAttribute("title", "调账审核详情");
		request.setAttribute("closeTitle", "调账审核列表");
		request.setAttribute("url", "adjustAudit.htm?method=adjustAuditList");
		return "common/message";
	}

	@RequestMapping(params = "method=outAdjustAuditList")
	@FormToken(save = true)
	public String outAdjustAuditList(HttpServletRequest request, AdjustAuditForm adjustAuditForm){
        UserInfo user = (UserInfo) (request.getSession().getAttribute(Constants.SESSION_KEY_USER));
        adjustAuditForm.setUserId(user.getId().toString());
        // 调账出金审核列表
        List<Object> adjustAuditList = adjustAuditService.getOutAdjustAuditList(adjustAuditForm);
        request.setAttribute("auditList", adjustAuditList);
        request.setAttribute("adjustApplyForm", adjustAuditForm);
        return  "adjust/outAdjustAuditList";
	}

    @RequestMapping(params = "method=toOutAudit")
    @FormToken(save = true)
    public String toOutAudit(HttpServletRequest request, AdjustAuditForm adjustAuditForm) throws BusinessException {
        // 跳转到出金调账审核页面
        String[] transId = request.getParameter("transId").split(",");
        String[] applyNo = request.getParameter("applyNo").split(",");
        String[] amount = request.getParameter("amount").split(",");
        // 交易详情
        Map<String, Object> transDetail = null;
        // 审核历史
        List<Map<String, Object>> auditHis = null;
        // 交易总金额，交易笔数;
        Map<String, Object> allBankAmount = new HashMap<String, Object>();
        double allAmount = 0;
        try {
            if (transId.length > 1) {
                for (int i = 0; i < transId.length; i++) {
                    allAmount += Double.parseDouble(amount[i].toString());
                }
                BigDecimal amounts = new BigDecimal(allAmount);
                allBankAmount.put("RECORDCOUNT", transId.length);
                allBankAmount.put("allAmount", amounts.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
            } else if (transId.length == 1) {
                transDetail = adjustAuditService.getAuditDetail(transId[0],applyNo[0]);
            } else {
                request.setAttribute("errMsg", "交易编号不存在！");
            }
        } catch (BusinessException be) {
            ApplicationContext ctx = WebApplicationContextUtils
                    .getRequiredWebApplicationContext(request.getSession().getServletContext());
            MessageSource messageSource = (MessageSource) ctx.getBean("messageSource");
            request.setAttribute("errMsg", be.getErrMessage(messageSource));
            request.setAttribute("title", "出金调账审核详情");
            return "common/message";
        } catch (Exception e) {
            request.setAttribute("errMsg", "系统出错！");
            e.printStackTrace();
            request.setAttribute("title", "出金调账审核详情");
            return "common/message";
        }
        request.setAttribute("detail", transDetail);
        request.setAttribute("auditHis", auditHis);
        request.setAttribute("allBankAmount", allBankAmount);
        request.setAttribute("allApplayNo", request.getParameter("applyNo"));
        return "adjust/outAuditDetail";
    }

    /**
     * 出金审核同意
     * @param request
     * @param adjustAuditForm
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=outAgree")
    @FormToken(save = true)
    public String outAgree(HttpServletRequest request, AdjustAuditForm adjustAuditForm) throws Exception {
        // 审核同意
        UserInfo user = (UserInfo) (request.getSession().getAttribute(Constants.SESSION_KEY_USER));
        String[] allApplayNos = request.getParameter("allApplayNo").split(",");
        try {
            adjustAuditService.agreeRecord(adjustAuditForm, user.getId(), allApplayNos);
            request.setAttribute("msg", "审核同意成功！");
        } catch (BusinessException be) {
            ApplicationContext ctx = WebApplicationContextUtils
                    .getRequiredWebApplicationContext(request.getSession().getServletContext());
            MessageSource messageSource = (MessageSource) ctx.getBean("messageSource");
            request.setAttribute("errMsg", be.getErrMessage(messageSource));
        } catch (Exception e) {
            request.setAttribute("errMsg", "审核出错！");
            e.printStackTrace();
        }
        request.setAttribute("title", "出金调账审核详情");
        request.setAttribute("closeTitle", "出金调账审核列表");
        request.setAttribute("url", "adjustAudit.htm?method=outAdjustAuditList");
        return "common/message";
    }

    /**
     * 出金审核拒绝
     * @param request
     * @param adjustAuditForm
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=outReject")
    @FormToken(save = true)
    public String outReject(HttpServletRequest request, AdjustAuditForm adjustAuditForm) throws Exception {
        // 审核拒绝
        UserInfo user = (UserInfo) (request.getSession().getAttribute(Constants.SESSION_KEY_USER));
        String[] allApplayNos = request.getParameter("allApplayNo").split(",");
        try {
            adjustAuditService.rejectRecord(user.getId(), allApplayNos);
			/*for (int i = 0; i < allApplayNos.length; i++) {
				adjustAuditForm.setApplyNo(allApplayNos[i]);
				adjustAuditService.reject(adjustAuditForm, user.getId());
			}*/
            request.setAttribute("msg", "审核拒绝成功！");
        }catch (Exception e) {
            request.setAttribute("errMsg", "审核出错！");
            e.printStackTrace();
        }
        request.setAttribute("title", "出金调账审核详情");
        request.setAttribute("closeTitle", "出金调账审核列表");
        request.setAttribute("url", "adjustAudit.htm?method=outAdjustAuditList");
        return "common/message";
    }

	@RequestMapping(params = "method=netsUnionAdjustAuditList")
	@FormToken(save = true)
	public String netsUnionAdjustAuditList(HttpServletRequest request, AdjustAuditForm adjustAuditForm){
		UserInfo user = (UserInfo) (request.getSession().getAttribute(Constants.SESSION_KEY_USER));
		adjustAuditForm.setUserId(user.getId().toString());
		List<Object> adjustAuditList = adjustAuditService.getNetsUnionAdjustAuditList(adjustAuditForm);
		request.setAttribute("auditList", adjustAuditList);
		request.setAttribute("adjustApplyForm", adjustAuditForm);
		return  "adjust/netsUnionAdjustAuditList";
	}

	/**
	 * 网联跳转审核详情页面
	 * @param request
	 * @param adjustAuditForm
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=toNetsUnionAudit")
	@FormToken(save = true)
	public String toNetsUnionAudit(HttpServletRequest request, AdjustAuditForm adjustAuditForm) throws BusinessException {
		// 跳转到网联调账审核页面
		String[] transId = adjustAuditForm.getTransId().split(",");
		String[] applyNo = adjustAuditForm.getApplyNo().split(",");
		String[] amount = adjustAuditForm.getAmount().split(",");
		// 交易详情
		Map<String, Object> transDetail = null;
		// 审核历史
		List<Map<String, Object>> auditHis = null;
		// 交易总金额，交易笔数;
		Map<String, Object> allBankAmount = new HashMap<String, Object>();
		double allAmount = 0;
		try {
			if (transId.length > 1) {
				for (int i = 0; i < transId.length; i++) {
					allAmount += Double.parseDouble(amount[i].toString());
				}
				BigDecimal amounts = new BigDecimal(allAmount);
				allBankAmount.put("RECORDCOUNT", transId.length);
				allBankAmount.put("allAmount", amounts.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
			} else if (transId.length == 1) {
				transDetail = adjustAuditService.getNetsUnionAuditDetail(transId[0],applyNo[0]);
			} else {
				request.setAttribute("errMsg", "交易编号不存在！");
			}
		} catch (BusinessException be) {
			ApplicationContext ctx = WebApplicationContextUtils
					.getRequiredWebApplicationContext(request.getSession().getServletContext());
			MessageSource messageSource = (MessageSource) ctx.getBean("messageSource");
			request.setAttribute("errMsg", be.getErrMessage(messageSource));
			request.setAttribute("title", "网联调账审核详情");
			return "common/message";
		} catch (Exception e) {
			request.setAttribute("errMsg", "系统出错！");
			e.printStackTrace();
			request.setAttribute("title", "网联调账审核详情");
			return "common/message";
		}
		request.setAttribute("detail", transDetail);
		request.setAttribute("auditHis", auditHis);
		request.setAttribute("allBankAmount", allBankAmount);
		request.setAttribute("allApplayNo", request.getParameter("applyNo"));
		return "adjust/netsUnionAuditDetail";
	}

	/**
	 * 网联审核同意
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=netsUnionAgree")
	@FormToken(save = true)
	public String netsUnionAgree(HttpServletRequest request) {
		// 审核同意
		UserInfo user = (UserInfo) (request.getSession().getAttribute(Constants.SESSION_KEY_USER));
		String[] allApplayNos = request.getParameter("allApplayNo").split(",");
		try {
			adjustAuditService.agreeNetsUnionRecord(user.getId(), allApplayNos);
			request.setAttribute("msg", "审核同意成功！");
		} catch (BusinessException be) {
			ApplicationContext ctx = WebApplicationContextUtils
					.getRequiredWebApplicationContext(request.getSession().getServletContext());
			MessageSource messageSource = (MessageSource) ctx.getBean("messageSource");
			request.setAttribute("errMsg", be.getErrMessage(messageSource));
		} catch (Exception e) {
			request.setAttribute("errMsg", "审核出错！");
			e.printStackTrace();
		}
		request.setAttribute("title", "网联调账审核详情");
		request.setAttribute("closeTitle", "网联调账审核列表");
		request.setAttribute("url", "adjustAudit.htm?method=netsUnionAdjustAuditList");
		return "common/message";
	}

	/**
	 * 网联审核拒绝
	 * @param request
	 * @param adjustAuditForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=netsUnionReject")
	@FormToken(save = true)
	public String netsUnionReject(HttpServletRequest request, AdjustAuditForm adjustAuditForm) throws Exception {
		// 审核拒绝
		UserInfo user = (UserInfo) (request.getSession().getAttribute(Constants.SESSION_KEY_USER));
		String[] allApplayNos = request.getParameter("allApplayNo").split(",");
		try {
			adjustAuditService.rejectNetsUnionRecord(user.getId(), allApplayNos);
			request.setAttribute("msg", "审核拒绝成功！");
		} catch (Exception e) {
			request.setAttribute("errMsg", "审核出错！");
			e.printStackTrace();
		}
		request.setAttribute("title", "网联调账审核详情");
		request.setAttribute("closeTitle", "网联调账审核列表");
		request.setAttribute("url", "adjustAudit.htm?method=netsUnionAdjustAuditList");
		return "common/message";
	}

}
