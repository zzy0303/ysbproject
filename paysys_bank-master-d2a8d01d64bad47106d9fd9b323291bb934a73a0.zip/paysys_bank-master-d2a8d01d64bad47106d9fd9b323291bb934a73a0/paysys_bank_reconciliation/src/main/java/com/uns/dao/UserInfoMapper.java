package com.uns.dao;

import java.util.List;

import com.uns.model.UserInfo;
import java.math.BigDecimal;

import org.springframework.stereotype.Repository;

@Repository
public interface UserInfoMapper extends BaseMapper<Object> {

	int deleteByPrimaryKey(BigDecimal id);

	int insert(UserInfo record);

	int insertSelective(UserInfo record);

	UserInfo selectByPrimaryKey(BigDecimal id);

	int updateByPrimaryKeySelective(UserInfo record);

	int updateByPrimaryKey(UserInfo record);

	List<UserInfo> selectUserInfoByName(String loginName) throws Exception;

}
