package com.uns.web;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.NativeWebRequest;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.Page;
import com.uns.model.Users;
import com.uns.service.SplitService;
import com.uns.slx.common.mutidatasource.DataSourceSwitch;
import com.uns.util.AcmsMapUtils;
import com.uns.util.DateUtil;
import com.uns.util.ExcelUtils;
import com.uns.web.form.SplitForm;

@Controller
@RequestMapping("/split.htm")
public class SplitController  extends BaseController{
	@Autowired
	private SplitService splitService;
	@Autowired
	private AcmsMapUtils acmsMapUtils;
	
	/**
	 * 服务商刷卡批次查询
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=findAgentSkSplitList")
	public String findAgentSkSplitList(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform) throws BusinessException{
		try {
			//动态获取，用于是否显示确认按钮  0显示，1不显示
			String ifhide=acmsMapUtils.getAcmsMap().get("ifhide");
			
			request.setAttribute("ifhide", ifhide);
			Users  sessionUser=(Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			if(sessionUser==null || StringUtils.isEmpty(Long.toString(sessionUser.getMerchantid()))){
				throw new BusinessException(ExceptionDefine.商户查询失败);
			}
			sform.setSessionUserNo(String.valueOf(sessionUser.getMerchantid()));
			//标识为刷卡批次
			sform.setTransType("1");
			if(sform.getEndDate() != null){
				Calendar c = Calendar.getInstance();
				c.setTime(sform.getEndDate());
				c.add(Calendar.DAY_OF_MONTH, 1);
				sform.setEndDate(c.getTime());
			}
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
			List<Map<String,Object>> listData = splitService.selectBatchList(sform);
			for(Map<String,Object> map:listData){
				Date d1 = (Date)map.get("END_DATE");
				Calendar cal=Calendar.getInstance();
				cal.add(Calendar.WEEK_OF_MONTH, -4);
				cal.set(Calendar.DAY_OF_WEEK, 2);
				Date d2 = cal.getTime();
				if(d1.compareTo(d2) == -1 ){
					map.put("detailFlag", "0");
				}else{
					map.put("detailFlag", "1");
				}
			}
			//如果是下载
			if("1".equals(sform.getIfDownload())){
				//判断是否操作最大条数
				if(((Page)request.getAttribute("page")).getTotalRows()>Constants.MAX_DOWNLOAD_SIZE){
					request.setAttribute(Constants.MESSAGE_KEY,"单次最大下载条数为" + Constants.MAX_DOWNLOAD_SIZE + "条");
					request.setAttribute("url","split.htm?method=findAgentSkSplitList");
					return "/returnPage";
				}
				listData = splitService.downBatchList(sform);
				for(Map<String,Object> map:listData){
					 map.put("STATUS", Constants.convertMap.get(map.get("STATUS")));
				}
				
				List<String> listHead = new ArrayList<String>();
				listHead.add("结算批次号");
				listHead.add("批次生成时间");
				listHead.add("服务商编号");
				listHead.add("服务商名称");
				/*listHead.add("费率类-费率％");
				listHead.add("封顶类-费率％");
				listHead.add("封顶类-封顶值/元");*/
				listHead.add("贷记卡底价费率");
				listHead.add("借记卡底价费率");
				listHead.add("交易笔数/笔");
				listHead.add("刷卡交易总金额/元");
				listHead.add("分润总金额/元");
				listHead.add("状态");
				List<String> listKey = new ArrayList<String>();
				listKey.add("BATCH_NO");
				listKey.add("CREATE_DATE");
				listKey.add("SHOPPERIDP");
				listKey.add("SCOMPANY");
				/*listKey.add("SK_FEETYPE_FEE");
				listKey.add("SK_TOPTYPE_FEE");
				listKey.add("SK_TOPTYPE_TOP");*/
				listKey.add("SK_CREDIT_FEE");
				listKey.add("SK_DEBIT_FEE");
				listKey.add("SUM_COUNT");
				listKey.add("SUM_AMOUNT");
				listKey.add("SUM_PROFIT");
				listKey.add("STATUS");
				
				ExcelUtils.downExcel(listData, listKey, listHead, "SK-BATCH", "刷卡分润批次信息", response);
				return null;
				
			}
			
			request.setAttribute("list", listData);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"服务商刷卡批次查询错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		
		return "splitProfit/skBatchList";
	}
	
	
	
	/**
	 * 服务商刷卡批次查询-新
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=findAgentSkSplitNewList")
	public String findAgentSkSplitNewList(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform) throws BusinessException{
		try {
			Users  sessionUser=(Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			if(sessionUser==null || StringUtils.isEmpty(Long.toString(sessionUser.getMerchantid()))){
				throw new BusinessException(ExceptionDefine.商户查询失败);
			}
			sform.setSessionUserNo(String.valueOf(sessionUser.getMerchantid()));
			//标识为刷卡批次
			sform.setTransType("1");
			if(sform.getEndDate() != null){
				Calendar c = Calendar.getInstance();
				c.setTime(sform.getEndDate());
				c.add(Calendar.DAY_OF_MONTH, 1);
				sform.setEndDate(c.getTime());
			}
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
			List<Map<String,Object>> listData = splitService.selectBatchNewList(sform);
			for(Map<String,Object> map:listData){
				Date d1 = (Date)map.get("END_DATE");
				Calendar cal=Calendar.getInstance();
				cal.add(Calendar.WEEK_OF_MONTH, -4);
				cal.set(Calendar.DAY_OF_WEEK, 2);
				Date d2 = cal.getTime();
				if(d1.compareTo(d2) == -1 ){
					map.put("detailFlag", "0");
				}else{
					map.put("detailFlag", "1");
				}
			}
			//如果是下载
			if("1".equals(sform.getIfDownload())){
				//判断是否操作最大条数
				if(((Page)request.getAttribute("page")).getTotalRows()>Constants.MAX_DOWNLOAD_SIZE){
					request.setAttribute(Constants.MESSAGE_KEY,"单次最大下载条数为" + Constants.MAX_DOWNLOAD_SIZE + "条");
					request.setAttribute("url","split.htm?method=findAgentSkSplitList");
					return "/returnPage";
				}
				listData = splitService.downBatchNewList(sform);
				for(Map<String,Object> map:listData){
					 map.put("STATUS", Constants.convertMap.get(map.get("STATUS")));
				}
				
				List<String> listHead = new ArrayList<String>();
				listHead.add("结算批次号");
				listHead.add("批次生成时间");
				listHead.add("服务商编号");
				listHead.add("服务商名称");
				listHead.add("到账方式");
				listHead.add("费率");
				listHead.add("交易笔数/笔");
				listHead.add("刷卡交易总金额/元");
				listHead.add("分润总金额/元");
				listHead.add("状态");
				List<String> listKey = new ArrayList<String>();
				listKey.add("BATCH_NO");
				listKey.add("CREATE_DATE");
				listKey.add("SHOPPERIDP");
				listKey.add("SCOMPANY");
				listKey.add("SETTLE_TYPE");
				listKey.add("FEE");
				listKey.add("SUM_COUNT");
				listKey.add("SUM_AMOUNT");
				listKey.add("SUM_PROFIT");
				listKey.add("STATUS");
				
				ExcelUtils.downExcel(listData, listKey, listHead, "SK-BATCH", "刷卡分润批次信息", response);
				return null;
				
			}
			
			request.setAttribute("list", listData);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"服务商刷卡批次查询错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		
		return "splitProfit/skBatchNewList";
	}
	
	
	
	
	/**
	 *  服务商刷卡批次详情查询
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=skBatchDetailList")
	public String skBatchDetailList(HttpServletRequest request, HttpServletResponse response,
		SplitForm sform) throws BusinessException{
		try{
		//动态获取，用于是否显示确认按钮  0显示，1不显示
		String ifhide=acmsMapUtils.getAcmsMap().get("ifhide");
		request.setAttribute("batchNo", sform.getBatchNo());
		request.setAttribute("status", sform.getStatus());
		request.setAttribute("id", sform.getId());
		request.setAttribute("ifhide", ifhide);
		DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
		List<Map<String,Object>> listData = splitService.selectSplitList(sform);
		//如果是下载
		if("1".equals(sform.getIfDownload())){
			if(((Page)request.getAttribute("page")).getTotalRows()>Constants.MAX_DOWNLOAD_SIZE){
				request.setAttribute(Constants.MESSAGE_KEY,"单次最大下载条数为" + Constants.MAX_DOWNLOAD_SIZE + "条");
				request.setAttribute("url","split.htm?method=skBatchDetailList&batchNo="
						+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
				return "/returnPage";
			}
			listData = splitService.downSplitList(sform);
			for(Map<String,Object> map:listData){
				 String time = String.valueOf(map.get("OUTTRADETIME"));
				 map.put("OUTTRADETIME", time.substring(0, 4) + "-" + time.substring(4, 6) + "-" + time.substring(6, 8) + "-" 
						 + time.substring(8, 10) + ":" + time.substring(10, 12) + ":" + time.substring(12, 14));
				 String fee = String.valueOf(map.get("SK_FEE"));
				 String feeType = String.valueOf(map.get("FEE_TYPE"));
				 String top = String.valueOf(map.get("SK_TOP"));
				 if("1".equals(feeType)){
					 map.put("SK_FEE", fee + "-" + top + "元封顶");
				 }
			}
			
			List<String> listHead = new ArrayList<String>();
			listHead.add("订单号");
			listHead.add("服务商编号");
			listHead.add("服务商名称");
			listHead.add("商户号");
			listHead.add("商户名称");
			listHead.add("交易时间");
			/*listHead.add("费率类型");*/
			listHead.add("费率(％)");
			listHead.add("刷卡金额");
			listHead.add("手续费/元");
			listHead.add("到账金额/元");
			listHead.add("分润金额/元");

			List<String> listKey = new ArrayList<String>();
			listKey.add("OUTTRADENO");
			listKey.add("SHOPPERID_P");
			listKey.add("SCOMPANYP");
			listKey.add("SHOPPERID");
			listKey.add("SCOMPANY");
			listKey.add("OUTTRADETIME");
			/*listKey.add("FEE_TYPE");*/
			listKey.add("SK_FEE");
			listKey.add("AMOUNT");
			listKey.add("COMMISSION");
			listKey.add("ARRIVALAMOUNT");
			listKey.add("PROFIT");
			try {
				for(Map<String,Object> map:listData){
					map.put("FEE_TYPE", "0".equals(map.get("FEE_TYPE"))?"费率类":"封顶类");
				}
				ExcelUtils.downExcel(listData, listKey, listHead, "SK-BATCH", "刷卡分润批次信息", response);
				return null;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}
		request.setAttribute("list", listData);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"服务商刷卡批次详情查询错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		return "splitProfit/skBatchDetailList";
	}
	
	/**
	 * 服务商D0提现批次查询
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=findAgentD0SplitList")
	public String findAgentD0SplitList(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform) throws BusinessException{
		try {
			//动态获取，用于是否显示确认按钮
			String ifhide=acmsMapUtils.getAcmsMap().get("ifhide");
			
			request.setAttribute("ifhide", ifhide);
			
			
			Users  sessionUser=(Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			if(sessionUser==null || StringUtils.isEmpty(Long.toString(sessionUser.getMerchantid()))){
				throw new BusinessException(ExceptionDefine.商户查询失败);
			}
			//标识为d0批次
			sform.setSessionUserNo(String.valueOf(sessionUser.getMerchantid()));
			sform.setTransType("2");
			if(sform.getEndDate() != null){
				Calendar c = Calendar.getInstance();
				c.setTime(sform.getEndDate());
				c.add(Calendar.DAY_OF_MONTH, 1);
				sform.setEndDate(c.getTime());
			}
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
			List<Map<String,Object>> listData = splitService.selectBatchList(sform);
			for(Map<String,Object> map:listData){
				Date d1 = (Date)map.get("END_DATE");
				Calendar cal=Calendar.getInstance();
				cal.add(Calendar.WEEK_OF_MONTH, -4);
				cal.set(Calendar.DAY_OF_WEEK, 2);
				Date d2 = cal.getTime();
				if(d1.compareTo(d2) == -1 ){
					map.put("detailFlag", "0");
				}else{
					map.put("detailFlag", "1");
				}
			}
			//如果是下载
			if("1".equals(sform.getIfDownload())){
				//判断是否操作最大条数
				if(((Page)request.getAttribute("page")).getTotalRows()>Constants.MAX_DOWNLOAD_SIZE){
					request.setAttribute(Constants.MESSAGE_KEY,"单次最大下载条数为" + Constants.MAX_DOWNLOAD_SIZE + "条");
					request.setAttribute("url","split.htm?method=d0BatchDetailList&batchNo="
							+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
					return "/returnPage";
				}
				listData = splitService.downBatchList(sform);
				for(Map<String,Object> map:listData){
					 map.put("STATUS", Constants.convertMap.get(map.get("STATUS")));
				}
			
				List<String> listHead = new ArrayList<String>();
				listHead.add("结算批次号");
				listHead.add("批次生成时间");
				listHead.add("服务商编号");
				listHead.add("服务商名称");
				listHead.add("D0提现费率％");
				listHead.add("交易笔数/笔");
				listHead.add("交易总金额/元");
				listHead.add("分润总金额/元");
				listHead.add("状态");
				List<String> listKey = new ArrayList<String>();
				listKey.add("BATCH_NO");
				listKey.add("CREATE_DATE");
				listKey.add("SHOPPERIDP");
				listKey.add("SCOMPANY");
				listKey.add("D0_FEE");
				listKey.add("SUM_COUNT");
				listKey.add("SUM_AMOUNT");
				listKey.add("SUM_PROFIT");
				listKey.add("STATUS");
				try {
					ExcelUtils.downExcel(listData, listKey, listHead, "SK-BATCH", "刷卡分润批次信息", response);
					return null;
				} catch (Exception e) {
					e.printStackTrace();
					return null;
				}
			}
			request.setAttribute("list", listData);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"服务商D0提现批次查询 错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		return "splitProfit/d0BatchList";
	}
	
	/**
	 * 服务商D0提现批次详情查询
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=d0BatchDetailList")
	public String d0BatchDetailList(HttpServletRequest request, HttpServletResponse response,
		SplitForm sform) throws BusinessException{
		try{
			//动态获取，用于是否显示确认按钮  0显示，1不显示
			String ifhide=acmsMapUtils.getAcmsMap().get("ifhide");
			request.setAttribute("batchNo", sform.getBatchNo());
			request.setAttribute("status", sform.getStatus());
			request.setAttribute("id", sform.getId());
			request.setAttribute("ifhide", ifhide);
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
			List<Map<String,Object>> listData = splitService.selectSplitList(sform);
			//如果是下载
			if("1".equals(sform.getIfDownload())){
				if(((Page)request.getAttribute("page")).getTotalRows()>Constants.MAX_DOWNLOAD_SIZE){
					request.setAttribute(Constants.MESSAGE_KEY,"单次最大下载条数为" + Constants.MAX_DOWNLOAD_SIZE + "条");
					request.setAttribute("url","split.htm?method=d0BatchDetailList&batchNo="
							+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
					return "/returnPage";
				}
				listData = splitService.downSplitList(sform);
				for(Map<String,Object> map:listData){
					 String time = String.valueOf(map.get("OUTTRADETIME"));
					 map.put("OUTTRADETIME", time.substring(0, 4) + "-" + time.substring(4, 6) + "-" + time.substring(6, 8) + "-" 
							 + time.substring(8, 10) + ":" + time.substring(10, 12) + ":" + time.substring(12, 14));
				}
				
				List<String> listHead = new ArrayList<String>();
				listHead.add("订单号");
				listHead.add("服务商编号");
				listHead.add("服务商名称");
				listHead.add("商户号");
				listHead.add("商户名称");
				listHead.add("交易时间");
				/*listHead.add("费率类型");*/
				listHead.add("提现费率(％)");
				listHead.add("提现金额");
				listHead.add("手续费/元");
				listHead.add("到账金额/元");
				listHead.add("分润金额/元");
	
				List<String> listKey = new ArrayList<String>();
				listKey.add("OUTTRADENO");
				listKey.add("SHOPPERID_P");
				listKey.add("SCOMPANYP");
				listKey.add("SHOPPERID");
				listKey.add("SCOMPANY");
				listKey.add("OUTTRADETIME");
				/*listKey.add("FEE_TYPE");*/
				listKey.add("D0_FEE");
				listKey.add("AMOUNT");
				listKey.add("COMMISSION");
				listKey.add("ARRIVALAMOUNT");
				listKey.add("PROFIT");
				try {
					for(Map<String,Object> map:listData){
						map.put("FEE_TYPE", "0".equals(map.get("FEE_TYPE"))?"费率类":"封顶类");
					}
					ExcelUtils.downExcel(listData, listKey, listHead, "SK-BATCH", "刷卡分润批次信息", response);
					return null;
				} catch (Exception e) {
					e.printStackTrace();
					return null;
				}
			}
			request.setAttribute("list", listData);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"服务商D0提现批次详情查询 错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}	
		return "splitProfit/d0BatchDetailList";
	}
	
	/**
	 * 更新批次状态 
	 */
	@RequestMapping(params = "method=auditSplit")
	public String auditSplit(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform){
		try {
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
			splitService.updateStatusByBatchNo(sform);
			
			request.setAttribute(Constants.MESSAGE_KEY,"操作成功");
			if("d0".equals(sform.getType())){
				request.setAttribute("url","split.htm?method=d0BatchDetailList&batchNo="
						+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
			}
			else if("sk".equals(sform.getType())){
				request.setAttribute("url","split.htm?method=skBatchDetailList&batchNo="
						+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute(Constants.MESSAGE_KEY,"操作失败");
			if("d0".equals(sform.getType())){
				request.setAttribute("url","split.htm?method=d0BatchDetailList&batchNo="
						+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
			}
			else if("sk".equals(sform.getType())){
				request.setAttribute("url","split.htm?method=skBatchDetailList&batchNo="
						+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
			}
		}finally{
			DataSourceSwitch.clearDataSourceType();
		}
		return "/returnPage";
	}
	
	/**
	 * 服务商疑议
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=toUpdateDoubt")
	public String toUpdateDoubt(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform) throws BusinessException{
		try {
			request.setAttribute("type", sform.getType());
			request.setAttribute("batchNo", sform.getBatchNo());
			request.setAttribute("status", sform.getStatus());
			request.setAttribute("id", sform.getId());
			if("1".equals(sform.getStatus())){
				return "splitProfit/insertDoubt";
			}else{
				DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
				Map<String,Object> map = splitService.selectDoubt(sform);
				request.setAttribute("bat", map);
				return "splitProfit/updateDoubt";
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"服务商疑议错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
	}
	
	/**
	 * 添加疑议 
	 */
	@RequestMapping(params = "method=insertDoubt")
	public String insertDoubt(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform){
		try {
			sform.setStatus("2");
			sform.setCreateDate(new Date());
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
			splitService.insertDoubt(sform);
			request.setAttribute(Constants.MESSAGE_KEY,"操作失败");
			if("d0".equals(sform.getType())){
				request.setAttribute("url","split.htm?method=d0BatchDetailList&batchNo="
						+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
			}
			else if("sk".equals(sform.getType())){
				request.setAttribute("url","split.htm?method=skBatchDetailList&batchNo="
						+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute(Constants.MESSAGE_KEY,"操作失败");
			if("d0".equals(sform.getType())){
				request.setAttribute("url","split.htm?method=d0BatchDetailList&batchNo="
						+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
			}
			else if("sk".equals(sform.getType())){
				request.setAttribute("url","split.htm?method=skBatchDetailList&batchNo="
						+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
			}
		}finally{
			DataSourceSwitch.clearDataSourceType();
		}
		return "/returnPage";
	}
	
	/**
	 * 更新疑议 
	 */
	@RequestMapping(params = "method=updateDoubt")
	public String updateDoubt(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform){
		try {
			sform.setStatus("2");
			String str = sform.getDoubtHis();
			if(str != null && !"".equals(str) && !"null".equals(str)){
				sform.setDoubt(sform.getDoubtHis() + " || " + sform.getDoubt());
			}
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
			splitService.updateDoubt(sform);
			request.setAttribute(Constants.MESSAGE_KEY,"操作失败");
			if("d0".equals(sform.getType())){
				request.setAttribute("url","split.htm?method=d0BatchDetailList&batchNo="
						+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
			}
			else if("sk".equals(sform.getType())){
				request.setAttribute("url","split.htm?method=skBatchDetailList&batchNo="
						+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute(Constants.MESSAGE_KEY,"操作失败");
			if("d0".equals(sform.getType())){
				request.setAttribute("url","split.htm?method=d0BatchDetailList&batchNo="
						+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
			}
			else if("sk".equals(sform.getType())){
				request.setAttribute("url","split.htm?method=skBatchDetailList&batchNo="
						+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
			}
		}finally{
			DataSourceSwitch.clearDataSourceType();
		}
		return "/returnPage";
	}
	
	
	
	
	/**
	 * 批量更新批次状态
	 */
	@RequestMapping(params = "method=batchUpdate")
	public String batchUpdate(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform){
		try {
			if(sform.getIds() != null){
				String ids = sform.getIds();
				String[] idsArr = ids.substring(1, ids.length()).split(",");
				List<String> list = Arrays.asList(idsArr);
				Map<String,Object> param = new HashMap<String, Object>();
				param.put("status", sform.getStatus());
				param.put("list", list);
				DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
				splitService.batchUpdate(param);
			}
			request.setAttribute(Constants.MESSAGE_KEY,"操作成功");
			if("d0".equals(sform.getType())){
				request.setAttribute("url", "split.htm?method=findAgentD0SplitList");
			}
			else if("sk".equals(sform.getType())){
				request.setAttribute("url", "split.htm?method=findAgentSkSplitList");
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute(Constants.MESSAGE_KEY,"操作失败");
			if("d0".equals(sform.getType())){
				request.setAttribute("url", "split.htm?method=findAgentD0SplitList");
			}
			else if("sk".equals(sform.getType())){
				request.setAttribute("url", "split.htm?method=findAgentSkSplitList");
			}
		}finally{
			DataSourceSwitch.clearDataSourceType();
		}
		return "/returnPage";
	}
	
	
	/**
	 * 处理状态
	 * @param sform
	 * @return
	 */
	public void disposeStatus (SplitForm sform) {
		
		List<String> list = null;
		//秒到状态
		if(StringUtils.isNotEmpty(sform.getStatus_s0())){
			list=new ArrayList<String>();
			//未审核(5:审核不通过 合并为0 未审核)
			
			if(Constants.STATUS0.equals(sform.getStatus_s0())) {
				list.add(Constants.STATUS0);
				list.add(Constants.STATUS5);
				sform.setS0List(list);
			}
			
			
			//未确认(合并状态 2，代理商有疑议，6:疑议已处理 合并为1, 未确认)
			if(Constants.STATUS1.equals(sform.getStatus_s0())) {
				list.add(Constants.STATUS1);
				list.add(Constants.STATUS2);
				list.add(Constants.STATUS6);
				sform.setS0List(list);
			}
			if(Constants.STATUS3.equals(sform.getStatus_s0())||Constants.STATUS4.equals(sform.getStatus_s0())) {
				list.add(sform.getStatus_s0());
				sform.setS0List(list);
			}
		}
		//即时状态
		if(StringUtils.isNotEmpty(sform.getStatus_d0())){
			list=new ArrayList<String>();
			//未审核(5:审核不通过 合并为0 未审核)
			if(Constants.STATUS0.equals(sform.getStatus_d0())) {
				list.add(Constants.STATUS0);
				list.add(Constants.STATUS5);
				sform.setD0List(list);
			}
			//未确认(合并状态 2，代理商有疑议，6:疑议已处理 合并为1, 未确认)
			if(Constants.STATUS1.equals(sform.getStatus_d0())) {
				list.add(Constants.STATUS1);
				list.add(Constants.STATUS2);
				list.add(Constants.STATUS6);
				sform.setD0List(list);
			}
			if(Constants.STATUS3.equals(sform.getStatus_d0())||Constants.STATUS4.equals(sform.getStatus_d0())) {
				list.add(sform.getStatus_d0());
				sform.setD0List(list);
			}
		}
		
		//T1状态
		if(StringUtils.isNotEmpty(sform.getStatus_t1())){
			list=new ArrayList<String>();
			//未审核(5:审核不通过 合并为0 未审核)
			if(Constants.STATUS0.equals(sform.getStatus_t1())) {
				list.add(Constants.STATUS0);
				list.add(Constants.STATUS5);
				sform.setT1List(list);
			}
			//未确认(合并状态 2，代理商有疑议，6:疑议已处理 合并为1, 未确认)
			if(Constants.STATUS1.equals(sform.getStatus_t1())) {
				list.add(Constants.STATUS1);
				list.add(Constants.STATUS2);
				list.add(Constants.STATUS6);
				sform.setT1List(list);
			}
			if(Constants.STATUS3.equals(sform.getStatus_t1())||Constants.STATUS4.equals(sform.getStatus_t1())) {
				list.add(sform.getStatus_t1());
				sform.setT1List(list);
			}
		}
	}
	
	
	/**
	 * 分润确认列表
	 * 计算公式： 
	 *税后总分润=税前总分润-税前总分润*7%（四舍五入，保留小数点后两位）
	 *7%税点可后台动态配置   
	 * @author yang.liu01
	 * @param request
	 * @param response
	 * @param sform
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=findProfitConfirmList")
	public String findProfitConfirmList(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform) throws BusinessException{
		try {
			Users  sessionUser=(Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			if(sessionUser==null || StringUtils.isEmpty(Long.toString(sessionUser.getMerchantid()))){
				throw new BusinessException(ExceptionDefine.商户查询失败);
			}
			sform.setSessionUserNo(String.valueOf(sessionUser.getMerchantid()));
			
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
			disposeStatus(sform);
			String ratio= acmsMapUtils.getAcmsMap().get("profit_ratio");//动态获取
			sform.setRatio(ratio);
			List<Map<String,Object>> listData =splitService.selectProfitConfirmation(sform);
			request.setAttribute("list", listData);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.查询出错,new String[]{"分润确认查询出错"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		
		return "splitProfit/profitConfirmList";
	}
	
	
	
	/**
	 * 更新代理商分润状态
	 * @author yang.liu01
	 * @param request
	 * @param response
	 * @param sform
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=updateSplitAgentStatus")
	public String updateSplitAgentStatus(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform) throws BusinessException{
		
		String page = request.getParameter("page");
		Map<String, Object> map = new HashMap<String,Object>();
		try {
			String[] batchNos=request.getParameterValues("selectId");
			String ids [];
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
			for (String batchNO : batchNos) {
				ids =batchNO.split(",");
				if(StringUtils.isNotEmpty(ids[0])) {
					map.put("shopperidp", ids[0]);
					map.put("begin_date", ids[1]);
					map.put("end_date", ids[2]);
					map.put("confirmDate", new Date());
					map.put("status", Constants.STATUS3);//3未结算
					splitService.updateSplitAgentStatus(map);
				}
				
			}
			request.setAttribute("url", "split.htm?method=findProfitConfirmList&page="+page);
			request.setAttribute(Constants.MESSAGE_KEY, "操作成功");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.确认失败,new String[]{"服务商确认操作失败"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		
		return "/returnPage";
	}

}
