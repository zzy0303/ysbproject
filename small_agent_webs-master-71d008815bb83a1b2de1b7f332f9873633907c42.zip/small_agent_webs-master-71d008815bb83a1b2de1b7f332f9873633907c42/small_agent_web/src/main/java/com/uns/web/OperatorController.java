package com.uns.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.model.Operator;
import com.uns.model.RoleInfo;
import com.uns.model.RoleMerInfo;
import com.uns.model.Users;
import com.uns.service.OperatorService;
import com.uns.service.RoleService;
import com.uns.util.Md5Encrypt;
import com.uns.util.StringUtils;
import com.uns.web.form.AgentUserForm;

@Controller("OperatorController")
@RequestMapping("/operator.htm")
public class OperatorController extends BaseController {

	@Autowired
	private OperatorService operatorService;
	

	
	@Autowired
	private RoleService roleService;
	/**操作员管理目录
	 * @param request
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=toUserManageList")
	public String toUserManageList(HttpServletRequest request,@ModelAttribute("mb") AgentUserForm mbForm, ModelMap modelMap) throws BusinessException{
		try {
			//获取当前登录的用户ID
			Users oper = (Users)request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			if(oper==null||Long.toString(oper.getMerchantid())==null||"".equals(Long.toString(oper.getMerchantid()))){
				throw new BusinessException(ExceptionDefine.请使用商户账号登录);
			}
			mbForm.setMerchantIdq(Long.toString(oper.getMerchantid()));
			List userList = operatorService.selectUsersList(mbForm);
//			List roleInfoList = roleService.selectRoleInfo(Constants.CON_YES);
			modelMap.put("userList",userList );
//			modelMap.put("roleList",roleInfoList);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.操作员列表);
		}
		modelMap.put("mbForm", mbForm);
		return "operator/operatorList";
	}

	/**操作员角色页面
	 * @param request
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=operatorUpdate")
	@FormToken(save=true)
	public String operatorUpdate(HttpServletRequest request,@ModelAttribute("mb") AgentUserForm mbForm, ModelMap modelMap) throws BusinessException{
		try {
			String userId=request.getParameter("userId");
			Users users = null;
			if(!StringUtils.isEmpty(userId)){
				users = operatorService.selectUserById(userId);
			}
			List<RoleMerInfo> roleInfoList;
			roleInfoList = operatorService.selectRoleList();
			modelMap.put("user",users );
			modelMap.put("roleInfoList",roleInfoList );
		} catch (NumberFormatException e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.数字格式化错误);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.操作员角色);
		}
		return "operator/operatorUpdate";
	}
	
	/**保存操作员
	 * @param request
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=saveOperator")
	@FormToken(remove=true)
	public String saveOperator(HttpServletRequest request,@ModelAttribute("mb") AgentUserForm mbForm, ModelMap modelMap) throws BusinessException{
		try {
			String userId=request.getParameter("userId");
			if(!StringUtils.isEmpty(userId)){
				Users user = operatorService.selectUserById(userId);
				if(mbForm.getUserName()!=null&&!"".equals(mbForm.getUserName())){
				    user.setUserName(mbForm.getUserName());
				}
				user.setDemo(mbForm.getDemo());
				user.setLastlogindate(new Date());
				user.setEnabled(Short.parseShort(mbForm.getEnabledq()));
				user.setLoginname(mbForm.getLoginName());
				operatorService.updateUserById(user);
				request.setAttribute(Constants.MESSAGE_KEY,Constants.SAVE_MESSAGE);
			}else{
				throw new BusinessException(ExceptionDefine.空指针异常);
			}
		} catch (NumberFormatException e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.数字格式化错误);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.保存操作员);
		}
	    request.setAttribute("url","operator.htm?method=toUserManageList");
        return "/returnPage";
	}
	
	/**前往操作员新增页面
	 * @param request
	 * @param mbForm
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(params = "method=toAddOperator")
	@FormToken(remove=true)
	public String toAddOperator(HttpServletRequest request,@ModelAttribute("mb") AgentUserForm mbForm, ModelMap modelMap){
		List list = null;
		try {
			list= roleService.selectRoleInfo(Constants.CON_YES);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.setAttribute("roleInfoList", list);
		return "operator/operatorAdd";
	}
	

	/**新增操作员
	 * @param request
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=addOperator")
	@FormToken(remove=true)
	public String addOperator(HttpServletRequest request,@ModelAttribute("mb") AgentUserForm mbForm, ModelMap modelMap) throws BusinessException{
		try{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd kk/mm/ss");
			String today = sdf.format(new Date());
			Date date = sdf.parse(today);
			if(mbForm.getUserName()==null||"".equals(mbForm.getUserName())){
				throw new BusinessException(ExceptionDefine.字段不允许为空);
			}
			Map map = new HashMap();
			map.put("username", mbForm.getUserName());
			Users op = operatorService.findOperatorByCode(mbForm.getUserName());
			if(op!=null){
				throw new BusinessException(ExceptionDefine.用户名已存在);
			}
			if(mbForm.getPassword()==null||"".equals(mbForm.getPassword())){
				throw new BusinessException(ExceptionDefine.字段不允许为空);
			}
			Users opers = (Users)request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			if(opers==null||Long.toString(opers.getMerchantid())==null||"".equals(Long.toString(opers.getMerchantid()))){
				throw new BusinessException(ExceptionDefine.请使用商户账号登录);
			}
			Users oper = new Users();
			
			oper.setMerchantid(opers.getMerchantid());
			oper.setUserName(mbForm.getUserName());
			oper.setPassword(Md5Encrypt.md5(mbForm.getPassword()));
			oper.setCreatedate(date);
			oper.setLastlogindate(date);
			oper.setDemo(mbForm.getDemo());//角色
			oper.setEnabled(Short.parseShort(mbForm.getEnabledq()));
			oper.setRoledesc("2");
			oper.setIsAgent(new Short("1"));
			oper.setLoginname(mbForm.getLoginname());
			operatorService.insertUsers(oper);
		}catch(Exception e){
			e.printStackTrace();
		}
		String message="添加操作员成功";
		request.setAttribute("message", message);
		request.setAttribute("url","operator.htm?method=toUserManageList");
		return "/returnPage";
	}

	/**前往密码修改页面
	 * @param request
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=toUpdateOperPassword")
	@FormToken(remove=true)
	public String toUpdateOperPassword(HttpServletRequest request,@ModelAttribute("mb") AgentUserForm mbForm, ModelMap modelMap) throws BusinessException{
	return "operator/updatePassword";
	}
		
	/**修改密码
	 * @param request
	 * @param response
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=updateOperPassword")
	@FormToken(remove=true)
	public String updateOperPassword(HttpServletRequest request,HttpServletResponse response,@ModelAttribute("mb") AgentUserForm mbForm, ModelMap modelMap)throws Exception{
		String pwd = this.reTrim(request.getParameter("password"));
		String newpwd = this.reTrim(request.getParameter("newpassword"));
		if(pwd==null||"".equals(pwd)){
			throw new BusinessException(ExceptionDefine.字段不允许为空);
		}
		if(request.getSession()==null||"".equals(request.getSession())){
			throw new BusinessException(ExceptionDefine.登录失效);
		}
		//获取当前登录的用户ID
		Users oper = (Users)request.getSession().getAttribute(Constants.SESSION_KEY_USER);
		if(oper==null||Long.toString(oper.getMerchantid())==null||"".equals(Long.toString(oper.getMerchantid()))){
			throw new BusinessException(ExceptionDefine.请使用商户账号登录);
		}
		String operid =Long.toString(oper.getId());
		try{
		    oper = operatorService.selectUser(operid,oper.getUserName());
		  //获取旧的密码,判断输入的原密码是否和数据库中的密码一致
			String password = oper.getPassword();
			if(!password.equals(Md5Encrypt.md5(pwd))){
				throw new BusinessException(ExceptionDefine.密码错误);
			}
		  //将新密码存入数据库
			oper.setPassword(Md5Encrypt.md5(newpwd));
			operatorService.updateUserPwd(oper);
			
			request.setAttribute("message", Constants.SAVE_MESSAGE);
			request.setAttribute("url","operator.htm?method=toUserManageList");
		}catch(Exception e){
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.密码错误);
		}
		
		return "/returnPage";
	}
	
	/**冻结操作员
	 * @param request
	 * @param response
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=blockOperator")
	@FormToken(remove=true)
	public String blockOperator(HttpServletRequest request,HttpServletResponse response,@ModelAttribute("mb") AgentUserForm mbForm, ModelMap modelMap)throws Exception{
		String userId=request.getParameter("userId");
		if(userId==null||"".equals(userId)){
			throw new BusinessException(ExceptionDefine.空指针异常);
		}
		Users users = operatorService.selectUserById(userId);
		users.setEnabled(new Short("0"));
		operatorService.updateUserById(users);
		String message = "冻结操作员成功";
		request.setAttribute("message", message);
		request.setAttribute("url", "operator.htm?method=toUserManageList");
	return "returnPage";
	}
	/**是否有重复的用户名存在
	 *@param request
	 * @param response
	 * @throws 
	 * @throws IOException
	 */
	@RequestMapping(params="method=ajaxCheckName")
	public void ajaxCheckName(HttpServletRequest request,HttpServletResponse response) throws IOException{
		try {
			String userName=request.getParameter("userName");
			List<Users> users=null;
			if(StringUtils.isTrimNotEmpty(userName)){
			    userName=userName.trim();
			    users=operatorService.selectByUsersName(userName);
			}
			PrintWriter out=response.getWriter();
			try {
				if(users!=null&&users.size()>0){
					out.write("{\"x\":\"1\"}");
				}else{
					out.write("{\"x\":\"2\"}");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				if(out !=null){
					out.flush();
					out.close();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/**删除操作员
	 * @param request
	 * @param response
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=removeOperator")
	@FormToken(remove=true)
	public String removeOperator(HttpServletRequest request,HttpServletResponse response,@ModelAttribute("mb") AgentUserForm mbForm, ModelMap modelMap)throws Exception{
		String userId=request.getParameter("userId");
		if(userId==null||"".equals(userId)){
			throw new BusinessException(ExceptionDefine.空指针异常);
		}
		operatorService.removeOperator(new BigDecimal(userId));
		String message = "删除操作员成功";
		request.setAttribute("message", message);
		request.setAttribute("url", "operator.htm?method=toUserManageList");
	return "returnPage";
	}
	
	private String reTrim(String str){
		return str.replace(" ","");
	}
}
