package com.uns.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class AgentSplitBatch implements Serializable {
	private static final long serialVersionUID = 1L;

	private BigDecimal id;

    private Date beginDate;

    private Date endDate;

    private String transType;

    private String batchNo;

    private String shopperidp;

    private String scompany;

    private BigDecimal sumCount;

    private BigDecimal sumAmount;

    private BigDecimal sumProfit;

    private String status;
    
    private Date createDate;

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public Date getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(Date beginDate) {
        this.beginDate = beginDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getTransType() {
        return transType;
    }

    public void setTransType(String transType) {
        this.transType = transType;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public String getShopperidp() {
        return shopperidp;
    }

    public void setShopperidp(String shopperidp) {
        this.shopperidp = shopperidp;
    }

    public String getScompany() {
        return scompany;
    }

    public void setScompany(String scompany) {
        this.scompany = scompany;
    }

    public BigDecimal getSumCount() {
        return sumCount;
    }

    public void setSumCount(BigDecimal sumCount) {
        this.sumCount = sumCount;
    }

    public BigDecimal getSumAmount() {
        return sumAmount;
    }

    public void setSumAmount(BigDecimal sumAmount) {
        this.sumAmount = sumAmount;
    }

    public BigDecimal getSumProfit() {
        return sumProfit;
    }

    public void setSumProfit(BigDecimal sumProfit) {
        this.sumProfit = sumProfit;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
    
}