package com.uns.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.dao.QrCodeMapper;

@Service
public class QrCodeService {
	
	@Autowired
	private QrCodeMapper qrCodeMapper;

	public Map<String, Object> queryQrCodeInfoByShopperId(String shopperid) {
		return qrCodeMapper.queryQrCodeInfoByShopperId(shopperid);
	}

}
