package com.uns.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.MposSystemInformation;
@Repository
public interface MposSystemInformationMapper {

    int insert(MposSystemInformation record);

    int insertSelective(MposSystemInformation record);

	String findinformationCount(Long shopperid);

	List findAppInformationThemeList(String merchantNo);


	Map findAppInformationDetails(Map map);


}