package com.uns.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.uns.common.MD5Util;
import com.uns.model.B2cShopperbiTemp;
import com.uns.service.*;
import com.uns.util.FastJson;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.servlet.ModelAndView;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.model.Agent;
import com.uns.model.B2cShopperbi;
import com.uns.model.Users;
import com.uns.util.Md5Encrypt;
import sun.management.resources.agent;

@Controller
@RequestMapping(value = "/main.htm")
public class LoginController extends BaseController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private AgentOperatorService operatorservice;

	@Autowired
	private SendMessageService sendMessageService;

	@Autowired
	private AgentService agentservice;
	
	@Autowired
	private RoleService roleService;

	@Autowired
	private UserService userService;

	@Autowired
	private ShopPerbiService shopPerbiService;

	@RequestMapping(params="method=preIndex")
	public String preIndex() {
		return "preIndex";
	}

	@RequestMapping(params="method=forgetPwd")
	public String forgetPwd(String tel, String verycode, String password, HttpServletRequest request, HttpServletResponse response) throws IOException {
		HashMap result = new HashMap();
		PrintWriter out = response.getWriter();
		result.put("code", "0000");
		try {
			Users users = userService.findbytel(tel);
			if (null == users){
				result.put("code", "1001");
				result.put("msg", "手机号码未注册");
				out.print(FastJson.toJson(result));
				return null;
			}

			HttpSession session = request.getSession();
			Long time = (Long) session.getAttribute(tel+"_time");
			String sessionMsgCode = (String) session.getAttribute(tel+"_msgCode");
			if(null == sessionMsgCode){
				result.put("code", "1003");
				result.put("msg", "未发送验证码");
				out.print(FastJson.toJson(result));
				return null;
			}
			if(System.currentTimeMillis()-time > 10*60*1000){
				session.removeAttribute(tel+"_time");
				session.removeAttribute(tel+"_msgCode");
				result.put("code", "1004");
				result.put("msg", "短信验证码过期");
				out.print(FastJson.toJson(result));
				return null;
			}
			if(!org.apache.commons.lang3.StringUtils.equals(verycode, sessionMsgCode)){
				result.put("code", "1005");
				result.put("msg", "短信验证码错误");
				out.print(FastJson.toJson(result));
				return null;
			}
			users.setPassword(password);
			userService.updateUserPwd(users, password);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("修改密码失败,{}", e.getMessage());
			result.put("code", "2222");
			result.put("msg", "修改密码失败");
			out.print(FastJson.toJson(result));
			return null;
		}
		out.print(FastJson.toJson(result));
		return null;
	}

	@RequestMapping(params = "method=preForgetPwd")
	public String preForgetPwd() {
		return "forgetPwd";
	}

	@RequestMapping(params="method=sendCode")
	public String sendCode(String tel, HttpServletRequest request, HttpServletResponse response) throws IOException {
		HashMap result = new HashMap();
		PrintWriter out = response.getWriter();
		try {
			Agent agent = agentservice.findbytel(tel);
			if (null == agent){
				result.put("code", "0001");
				result.put("msg", "手机号未注册");
				out.print(FastJson.toJson(result));
				return null;
			}
			String smsCode = RandomStringUtils.randomNumeric(6);
			sendMessageService.sendMessage(tel, smsCode);
			logger.info("忘记密码短信验证码:{}",smsCode);
			HttpSession session = request.getSession();
			session.setMaxInactiveInterval(10*60);
			session.setAttribute(tel+"_time", System.currentTimeMillis());
			session.setAttribute(tel+"_msgCode", smsCode);
			result.put("code", "0000");
			out.print(FastJson.toJson(result));
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("发送验证码失败,{}", e.getMessage());
			result.put("code", "2222");
			result.put("msg", "系统异常");
			out.print(FastJson.toJson(result));
		}
		return null;
	}

	@RequestMapping(params = "method=login")
	public ModelAndView login(HttpServletRequest request,HttpServletResponse response,String shopperId,String userName,
				String pasword, String verycode ,Short isagent) throws Exception {
		try {
			Map map=new HashMap();
			// 判断验证码
		    if(StringUtils.isEmpty(verycode)){
		    	throw new BusinessException(ExceptionDefine.验证码错);
		    }
			if (!verycode.equals( request.getSession().getAttribute(Constants.SESSION_VERIFY_CODE))) {
				throw new BusinessException(ExceptionDefine.验证码错);
			}
			// 判断服务商是否存在
			String tel =request.getParameter("tel");
			if (StringUtils.isEmpty(tel)) {
				throw new BusinessException(ExceptionDefine.字段不允许为空,new String[]{"手机号码"});
			}
			else{
				map.put("tel", tel);
			}
			
			Users operator =null;
			
			Agent agent = null;
			Map agentInfo=null;
			agent = agentservice.findbytel(tel + "");
			
			if (agent != null) {
				if (agent.getTransactid() != null && agent.getTransactid() ==0) {
					throw new BusinessException(ExceptionDefine.服务商未开通);
				}
				if (agent.getTransactid() != null && agent.getTransactid() ==2) {
					throw new BusinessException(ExceptionDefine.服务商被冻结);
				}
				operator = operatorservice.findOperatorByCodetel(map);
				
				if (operator == null) {
					throw new BusinessException(ExceptionDefine.用户名不存在);
				}else{
					if (null != operator && operator.getEnabled() == 0) {
						throw new BusinessException(ExceptionDefine.服务商被冻结);
					}
				}
			}else{
				throw new BusinessException(ExceptionDefine.用户名不存在);
			}
			// 判断密码
			if (StringUtils.isNotEmpty(pasword)) {
				String md5passwd = Md5Encrypt.md5(pasword.trim());
				if (!operator.getPassword().equals(md5passwd)) {
					throw new BusinessException(ExceptionDefine.密码错误);
				}
			}
			operator.setLastlogindate(new Date());
		
		    agentservice.updateUser(operator);
		    agentInfo=agentservice.queryAgentInfotel(agent.getShopperid().toString());
		    request.getSession().setAttribute(Constants.SESSION_KEY_USER,operator);
			List listFuncSelect = new ArrayList();
			request.getSession().setAttribute("funcSelect", listFuncSelect);
			//判断登录权限
			Map maps=null;
			if(StringUtils.isNotEmpty(operator.getDemo())){
    			maps=roleService.findFunction1(operator.getDemo());
			}
			request.getSession().setAttribute("functionTree", maps);
			request.getSession().setAttribute("agent", agent);
			request.getSession().setAttribute("agentInfo",agentInfo);
			request.getRequestDispatcher("/main.htm?method=home").forward(request, response);
		} catch (BusinessException ex) {
			Map<String, String> model=new HashMap<String, String>();
			ApplicationContext ctx = WebApplicationContextUtils.getRequiredWebApplicationContext(request.getSession().getServletContext());
			MessageSource messageSource = (MessageSource) ctx.getBean("messageSource");
			BusinessException e = (BusinessException) ex;
			model.put(Constants.ERROR_MESSAGE, e.getErrMessage(messageSource));
			return new ModelAndView("redirect:/", model);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("更新登陆时间出现异常" + e.getMessage());
		}
		return null; 
	}

	/**
	 * 跳转到主界面
	 * 
	 * @return
	 */
	@RequestMapping(params = "method=home")
	public String home() {
		return "home";
	}
	
	/**
	 * 跳转到主界面
	 * 
	 * @return
	 */
	@RequestMapping(params = "method=logout")
	public String logout(HttpServletRequest request) {
		request.getSession().invalidate();
		return "index";
	}
	
	
}
					
