package com.uns.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.AgentMcc;
import com.uns.model.AgentSplit;
@Repository
public interface AgentMccMapper {
	
	List searchAgentMccList(String agentId);

	AgentMcc findAgentMcc(Long amid);

	List<Map> isMcc(Long agentidP);

	List<Map> isMccTmp(Long agentidP);

	List<AgentSplit> findAgentMcc6(Long agentid);
	
	List<AgentMcc> findAgentMccMccid(Long agentid);

	List<AgentMcc> findAgentMccTmpMccid(Long agentid);
	
	AgentMcc findAgentMccTmp(Long amid);
	AgentMcc findAgentMccTmp2(Long amid);

	Long findAgentMccSq();
	
	Map searchAgentMccById(Long amid);

	List findAgentMccTmpBySgentId(Long editAgentid);

	List<AgentMcc> findAgentMccByAgentid(Long agentid);

	List<AgentMcc> findAgentMccTmpByAgentid(Long agentid);
	
}
