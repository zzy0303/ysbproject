package com.uns.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.uns.common.Constants;
import com.uns.common.page.PageContext;
import com.uns.dao.MtOperateLogMapper;
import com.uns.dao.MtOperatepermitMapper;
import com.uns.dao.OperatorMapper;
import com.uns.model.MtOperateLog;
import com.uns.model.MtOperatepermit;
import com.uns.model.Operator;
import com.uns.util.Md5Encrypt;
import com.uns.web.form.OperateLogForm;

@Service
public class OperateLogService {
	@Autowired
	private MtOperateLogMapper mtOperateLogMapper;
	@Autowired
	private MtOperatepermitMapper mtOperatepermitMapper;
	
	@Autowired
	private OperatorMapper operatorMapper;
	/**
	 * 获取需要过滤的地址列表
	 * @return
	 */
	public List<MtOperatepermit> selectAccesspermitList(){
		PageContext.initPageSize(10);
		return mtOperatepermitMapper.selectAllPermitTypeList();
	}
	
	/**
	 * 获取日志列表
	 * @param form
	 * @return
	 */
	public List<MtOperateLog> selectAccesslogList(OperateLogForm form){
		PageContext.initPageSize(10);
		return mtOperateLogMapper.selectAccesslogList(form);
	}
	
	/**
	 * 通过logid查询单条日志
	 * @param logid
	 * @return
	 */
	public MtOperateLog selectByPrimaryKey(String logid){
		return mtOperateLogMapper.selectByPrimaryKey(logid);
	}
	
	/**
	 * 插入日志
	 * @param accesslog
	 */
	public boolean insertAccesslog(MtOperateLog accesslog){
		return mtOperateLogMapper.insert(accesslog);
	}
	
	public String validateOper(String username,String password,String verycode){
		HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
		if(StringUtils.isEmpty(verycode)){
	    	return "验证码错误";
	    }
		if (!verycode.equals( request.getSession().getAttribute(Constants.SESSION_VERIFY_CODE))) {
			return "验证码错误";
		}
		Map map = new HashMap();
		map.put("username", username);
		List<Operator> agentUser = (List<Operator>) operatorMapper.findOperatorByCode(map);
		if(agentUser == null || agentUser.size()<1){
			return "登录的用户不存在";
		}
		Operator operator =  agentUser.get(0);
		if(!operator.getPassword().equals(Md5Encrypt.md5(password))){
			return "输入的密码错误";
		}
		if (null != operator && operator.getEnabled() == 0) {
			return "操作员被冻结";
		}
		return "登录成功";
	}
}
