package com.uns.dao;

import org.springframework.stereotype.Repository;

import com.uns.model.AgentTopFee;
@Repository
public interface AgentTopFeeMapper {


    int insert(AgentTopFee record);

    int insertSelective(AgentTopFee record);
    
    void updateById(AgentTopFee agenttopfee);
    
    AgentTopFee findbyid();


}