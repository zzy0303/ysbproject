package com.uns.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.dao.MposMerchantFeeMapper;
import com.uns.model.MposMerchantFee;
import com.uns.model.MposRemoteFee;
import com.uns.util.ToolsUtils;

@Service
public class MposmerchantfeeService {
	@Autowired
	private MposMerchantFeeMapper mposMerchantFeeMapper;
	
	public void insertfee(MposMerchantFee merchantfee) {
		mposMerchantFeeMapper.insertSelective(merchantfee);
	}
	
	public MposMerchantFee findbyshopperid(String shopperid){
		List list= mposMerchantFeeMapper.findbyshopperid(shopperid);
		MposMerchantFee fee=null;
		if(list!=null&&list.size()>0){
			fee=(MposMerchantFee)list.get(0);
		}
		return fee;
	}
	
	
    
	public List queryfee1(String shopperid, String cardType){
	 Map map=new HashMap();
	 map.put("shopperid", shopperid);
	 map.put("cardType", cardType);
	 List<MposMerchantFee> list =mposMerchantFeeMapper.queryfee1(map);
		return list;
		
	}

	public List queryfee(String shopperid) {
		 List<MposMerchantFee> list =mposMerchantFeeMapper.queryfee(shopperid);
			return list;
	}

	public List merchantfeelist(String shopperid) {
		return mposMerchantFeeMapper.merchantfeelist(shopperid);
	}

	public List findmerchantFeeList(String shopperid) {
		return mposMerchantFeeMapper.findmerchantFeeList(shopperid);
	}

	public List findQrPayMerchantFeeList(String shopperid) {
		return mposMerchantFeeMapper.findQrPayMerchantFeeList(shopperid);
	}

	public void insertMerchantFeeList(String shopperid) {
		mposMerchantFeeMapper.deleteByshopperid(Long.valueOf(shopperid));
		
		
		MposMerchantFee mposDebitfee=new MposMerchantFee();
		mposDebitfee.setShopperid(Long.valueOf(shopperid));
		mposDebitfee.setFeetype(Constants.CON_NO);//借记卡
		mposDebitfee.setFee(ToolsUtils.div(Double.parseDouble("0.0065"), 1, 4)+"");
		mposDebitfee.setCreateDate(new Date());
		mposDebitfee.setStatus(Constants.CON_YES);
		mposDebitfee.setD0fee(ToolsUtils.div(Double.parseDouble("0.0007"), 1, 4)+"");

		MposMerchantFee mposCreditFee=new MposMerchantFee();
		mposCreditFee.setShopperid(Long.valueOf(shopperid));
		mposCreditFee.setFeetype(Constants.CON_YES);//借记卡
		mposCreditFee.setFee(ToolsUtils.div(Double.parseDouble("0.0065"), 1, 4)+"");
		mposCreditFee.setCreateDate(new Date());
		mposCreditFee.setStatus(Constants.CON_YES);
		mposCreditFee.setD0fee(ToolsUtils.div(Double.parseDouble("0.0007"), 1, 4)+"");
		
		MposMerchantFee mweChatfee=new MposMerchantFee();
		mweChatfee.setShopperid(Long.valueOf(shopperid));
		mweChatfee.setFeetype(Constants.STATUS2);//
		mweChatfee.setFee(ToolsUtils.div(Double.parseDouble("0.0047"), 1, 4)+"");
		mweChatfee.setCreateDate(new Date());
		mweChatfee.setStatus(Constants.CON_YES);
		mweChatfee.setD0fee(ToolsUtils.div(Double.parseDouble("0.0049"), 1, 4)+"");
		
		MposMerchantFee mposAliPayFee=new MposMerchantFee();
		mposAliPayFee.setShopperid(Long.valueOf(shopperid));
		mposAliPayFee.setFeetype(Constants.STATUS3);//借记卡
		mposAliPayFee.setFee(ToolsUtils.div(Double.parseDouble("0.0047"), 1, 4)+"");
		mposAliPayFee.setCreateDate(new Date());
		mposAliPayFee.setStatus(Constants.CON_YES);
		mposAliPayFee.setD0fee(ToolsUtils.div(Double.parseDouble("0.0049"), 1, 4)+"");
		
		mposMerchantFeeMapper.insertSelective(mposDebitfee);
		
		mposCreditFee.setId(mposDebitfee.getId());
		mposMerchantFeeMapper.insert(mposCreditFee);
		
		mweChatfee.setId(mposDebitfee.getId());
		mposMerchantFeeMapper.insert(mweChatfee);
		
		mposAliPayFee.setId(mposDebitfee.getId());
		mposMerchantFeeMapper.insert(mposAliPayFee);
		
	}

	public String findQrPayMerchantFee(String shopperid) {
		return mposMerchantFeeMapper.findQrPayMerchantFee(shopperid);
	}
}
