package com.uns.model;


public class MposPhotoTmp {
    private Long photoId;

    private String handIdentityCardPhoto;

    private String frontIdentityCardPhoto;

    private String reverseIdentityCardPhoto;

    private String storePhoto;

    private String licensePhoto;

    private String instorePhoto;

    private String checkstandPhoto;

    private String signaturePhoto;
    
    
    private String checkFlag;
    
    private String identityid;
    
    private String creditCardPhoto;
    
    
    private String settlementCardPhoto;

	//活体
	private String livingbodyFacePhoto;

	private String livingbodyLeftPhoto;

	private String livingbodyRightPhoto;

	private String livingbodyReturnPhoto;

	private String idCardHeadPhoto;

	private String openLicensePhoto;

	private String lobbyPhoto;

	public String getLobbyPhoto() {
		return lobbyPhoto;
	}

	public void setLobbyPhoto(String lobbyPhoto) {
		this.lobbyPhoto = lobbyPhoto;
	}

	public String getOpenLicensePhoto() {
		return openLicensePhoto;
	}

	public void setOpenLicensePhoto(String openLicensePhoto) {
		this.openLicensePhoto = openLicensePhoto;
	}

	public String getLivingbodyFacePhoto() {
		return livingbodyFacePhoto;
	}

	public void setLivingbodyFacePhoto(String livingbodyFacePhoto) {
		this.livingbodyFacePhoto = livingbodyFacePhoto;
	}

	public String getLivingbodyLeftPhoto() {
		return livingbodyLeftPhoto;
	}

	public void setLivingbodyLeftPhoto(String livingbodyLeftPhoto) {
		this.livingbodyLeftPhoto = livingbodyLeftPhoto;
	}

	public String getLivingbodyRightPhoto() {
		return livingbodyRightPhoto;
	}

	public void setLivingbodyRightPhoto(String livingbodyRightPhoto) {
		this.livingbodyRightPhoto = livingbodyRightPhoto;
	}

	public String getLivingbodyReturnPhoto() {
		return livingbodyReturnPhoto;
	}

	public void setLivingbodyReturnPhoto(String livingbodyReturnPhoto) {
		this.livingbodyReturnPhoto = livingbodyReturnPhoto;
	}

	public String getIdCardHeadPhoto() {
		return idCardHeadPhoto;
	}

	public void setIdCardHeadPhoto(String idCardHeadPhoto) {
		this.idCardHeadPhoto = idCardHeadPhoto;
	}

	public String getSettlementCardPhoto() {
		return settlementCardPhoto;
	}


	public void setSettlementCardPhoto(String settlementCardPhoto) {
		this.settlementCardPhoto = settlementCardPhoto;
	}


	public String getCreditCardPhoto() {
		return creditCardPhoto;
	}


	public void setCreditCardPhoto(String creditCardPhoto) {
		this.creditCardPhoto = creditCardPhoto;
	}


	public String getIdentityid() {
		return identityid;
	}


	public void setIdentityid(String identityid) {
		this.identityid = identityid;
	}


	public Long getPhotoId() {
		return photoId;
	}


	public void setPhotoId(Long photoId) {
		this.photoId = photoId;
	}


	public String getHandIdentityCardPhoto() {
		return handIdentityCardPhoto;
	}


	public void setHandIdentityCardPhoto(String handIdentityCardPhoto) {
		this.handIdentityCardPhoto = handIdentityCardPhoto;
	}


	public String getFrontIdentityCardPhoto() {
		return frontIdentityCardPhoto;
	}


	public void setFrontIdentityCardPhoto(String frontIdentityCardPhoto) {
		this.frontIdentityCardPhoto = frontIdentityCardPhoto;
	}


	public String getReverseIdentityCardPhoto() {
		return reverseIdentityCardPhoto;
	}


	public void setReverseIdentityCardPhoto(String reverseIdentityCardPhoto) {
		this.reverseIdentityCardPhoto = reverseIdentityCardPhoto;
	}


	public String getStorePhoto() {
		return storePhoto;
	}


	public void setStorePhoto(String storePhoto) {
		this.storePhoto = storePhoto;
	}


	public String getLicensePhoto() {
		return licensePhoto;
	}


	public void setLicensePhoto(String licensePhoto) {
		this.licensePhoto = licensePhoto;
	}


	public String getInstorePhoto() {
		return instorePhoto;
	}


	public void setInstorePhoto(String instorePhoto) {
		this.instorePhoto = instorePhoto;
	}


	public String getCheckstandPhoto() {
		return checkstandPhoto;
	}


	public void setCheckstandPhoto(String checkstandPhoto) {
		this.checkstandPhoto = checkstandPhoto;
	}


	public String getSignaturePhoto() {
		return signaturePhoto;
	}


	public void setSignaturePhoto(String signaturePhoto) {
		this.signaturePhoto = signaturePhoto;
	}


	public String getCheckFlag() {
		return checkFlag;
	}


	public void setCheckFlag(String checkFlag) {
		this.checkFlag = checkFlag;
	}

    
    
   
}