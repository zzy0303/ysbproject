package com.uns.model;

import java.io.Serializable;
import java.util.Date;

public class TradeRecord implements Serializable {
    private String id;

    private String operateType;

    private String merchantType;

    private String stel;

    private String merchantId;

    private String userId;

    private String orderId;

    private String orderTime;

    private String curType;

    private String amount;

    private String remark;
    
    private String traceNo;

    private String mac;

    private String rspCode;
    
    private String rspCodeTrue;

    private String rspMsg;

    private String rspMac;

    private String rspAmount;

    private String rspBalance;

    private String rspCreditLine;

    private Date createDate;

    public TradeRecord() {
		super();
	}

	public TradeRecord(String operateType, String merchantType, String orderId,
			String orderTime, String curType, String amount, String remark,
			String mac, Date createDate) {
		super();
		this.operateType = operateType;
		this.merchantType = merchantType;
		this.orderId = orderId;
		this.orderTime = orderTime;
		this.curType = curType;
		this.amount = amount;
		this.remark = remark;
		this.mac = mac;
		this.createDate = createDate;
	}

	public String getTraceNo() {
		return traceNo;
	}

	public void setTraceNo(String traceNo) {
		this.traceNo = traceNo;
	}

	public String getRspCodeTrue() {
		return rspCodeTrue;
	}

	public void setRspCodeTrue(String rspCodeTrue) {
		this.rspCodeTrue = rspCodeTrue;
	}

	public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getOperateType() {
        return operateType;
    }

    public void setOperateType(String operateType) {
        this.operateType = operateType;
    }

    public String getMerchantType() {
        return merchantType;
    }

    public void setMerchantType(String merchantType) {
        this.merchantType = merchantType;
    }

    public String getStel() {
        return stel;
    }

    public void setStel(String stel) {
        this.stel = stel;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(String orderTime) {
        this.orderTime = orderTime;
    }

    public String getCurType() {
        return curType;
    }

    public void setCurType(String curType) {
        this.curType = curType;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getMac() {
        return mac;
    }

    public void setMac(String mac) {
        this.mac = mac;
    }

    public String getRspCode() {
        return rspCode;
    }

    public void setRspCode(String rspCode) {
        this.rspCode = rspCode;
    }

    public String getRspMsg() {
        return rspMsg;
    }

    public void setRspMsg(String rspMsg) {
        this.rspMsg = rspMsg;
    }

    public String getRspMac() {
        return rspMac;
    }

    public void setRspMac(String rspMac) {
        this.rspMac = rspMac;
    }

    public String getRspAmount() {
        return rspAmount;
    }

    public void setRspAmount(String rspAmount) {
        this.rspAmount = rspAmount;
    }

    public String getRspBalance() {
        return rspBalance;
    }

    public void setRspBalance(String rspBalance) {
        this.rspBalance = rspBalance;
    }

    public String getRspCreditLine() {
        return rspCreditLine;
    }

    public void setRspCreditLine(String rspCreditLine) {
        this.rspCreditLine = rspCreditLine;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
}