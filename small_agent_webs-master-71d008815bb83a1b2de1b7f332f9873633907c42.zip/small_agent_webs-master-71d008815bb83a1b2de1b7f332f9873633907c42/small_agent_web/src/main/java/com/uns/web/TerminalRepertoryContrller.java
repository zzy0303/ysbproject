
package com.uns.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.model.Agent;
import com.uns.model.B2cTermBinder;
import com.uns.model.Users;
import com.uns.service.AgentService;
import com.uns.service.TerminalRepertoryService;
import com.uns.util.StringUtils;
import com.uns.web.form.TerminalForm;

import net.sf.json.JSONObject;

/**
 * 库存管理
 *
 */
@Controller("terminalRepertoryContrller")
@RequestMapping("/terminalRepertory.htm")
public class TerminalRepertoryContrller extends BaseController {

	@Autowired
	private TerminalRepertoryService terminalRepertoryService;
	
	@Autowired
	private AgentService agentService;
	
	
	
	/**终端入库查询
	 * @param request
	 * @param response
	 * @param mbForm
	 * @return
	 */
	@RequestMapping(params = "method=findTerminalRepertoryInList")
	@FormToken(save=true)
	public String findTerminalRepertoryInList(HttpServletRequest request,HttpServletResponse response,TerminalForm mbForm) {
		Users  sessionUser=(Users)request.getSession().getAttribute(Constants.SESSION_KEY_USER); 
		List<B2cTermBinder> terminalRepertoryInList =null;
		//当前登录商
		Long merchantId = sessionUser.getMerchantid();
		//一级服务商 searchAgentByShopperid
		Agent agent =agentService.searchAgentByShopperId(merchantId.toString());
		/*if(null==agent.getShopperidP()) {
			mbForm.setMerchantid(merchantId.toString());
			terminalRepertoryInList=terminalRepertoryService.findFirstTerminalInList(mbForm);
		}else {
			mbForm.setMerchantid(null==merchantId?"":merchantId.toString());
			terminalRepertoryInList=terminalRepertoryService.findTerminalRepertoryInList(mbForm);
		}*/
		mbForm.setMerchantid(null==merchantId?"":merchantId.toString());
		terminalRepertoryInList=terminalRepertoryService.findTerminalRepertoryInList(mbForm);
	
		request.setAttribute("terminalRepertoryInList", terminalRepertoryInList);
		request.setAttribute("belongsAgent", mbForm.getBelongsAgent());
		return "terminal/terminalRepertoryInList";
	}
	
	/**
	 * 终端出库查询
	 * @param request
	 * @param response
	 * @param mbForm
	 * @return
	 */
	@RequestMapping(params = "method=findTerminalRepertoryOutList")
	@FormToken(save=true)
	public String findTerminalRepertoryOutList(HttpServletRequest request,HttpServletResponse response,TerminalForm mbForm) {
		Users  sessionUser=(Users)request.getSession().getAttribute(Constants.SESSION_KEY_USER); 
		//当前登录商
		Long merchantId = sessionUser.getMerchantid();
		String currentAgentNo = null==merchantId?"":merchantId.toString();
		List<B2cTermBinder> terminalRepertoryOutList=null;
		mbForm.setMerchantid(currentAgentNo);
		terminalRepertoryOutList =terminalRepertoryService.findTerminalRepertoryOutList(mbForm);
		
		
		Agent agent = agentService.findAgentbyParam(currentAgentNo);
		Long shopperidP = agent.getShopperidP();
		String shopperid_p = null==shopperidP?"":shopperidP.toString();
		if(StringUtils.isEmpty(shopperid_p)) {
			request.setAttribute("isFirst", 1);
		}
		request.setAttribute("terminalRepertoryOutList", terminalRepertoryOutList);
		request.setAttribute("belongsAgent", mbForm.getBelongsAgent());
		return "terminal/terminalRepertoryOutList";
	}
	
	
	/**终端入库
	 * @param request
	 * @param response
	 * @param mbForm
	 * @return
	 */
	@RequestMapping(params = "method=terminalRepertoryIn")
	@FormToken(save=true)
	public String terminalRepertoryIn(HttpServletRequest request,HttpServletResponse response,TerminalForm mbForm) {
		
		return "terminal/terminalRepertoryIn";
	}
	
	@RequestMapping(params = "method=saveterminalRepertoryIn")
	@FormToken(remove=true)
	public String saveterminalRepertoryIn(HttpServletRequest request,HttpServletResponse response,TerminalForm mbForm) throws Exception {
		HSSFSheet sheet;
		InputStream in =null;
		Map map = new HashMap();
		try {
				MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
				// 获得文件
				MultipartFile file = multipartRequest.getFile("termNosFile");
			
				// 获取输出流
				in = file.getInputStream();
		
				HSSFWorkbook workbook = new HSSFWorkbook(in);
			
				sheet = workbook.getSheetAt(0);
			} catch (Exception e) {
				e.printStackTrace();
				throw new BusinessException(ExceptionDefine.库存管理,new String[]{"文件上传失败"});
			}finally {
				in.close();
			}
		
			String batchNo=request.getParameter("batchNo");
			String terminal_type_no=request.getParameter("terminal_type_no");
			String factory_no=request.getParameter("factory_no");
			if (sheet != null) {
				map =insertBatchIn(request,batchNo,terminal_type_no,factory_no,sheet);
			}
			JSONObject json =JSONObject.fromObject(map);
			log.info(map.get("rspMsg") + json.toString());
			if(map.get("rspCode").equals(Constants.SUCCESS_CODE)){
				request.setAttribute("url","terminalRepertory.htm?method=findTerminalRepertoryInList");
				response.setContentType("UTF-8");
				
				request.setAttribute(Constants.MESSAGE_KEY, map.get("rspMsg"));
			}
		return "/returnPage";
	}
	

	/**出库保存
	 * @param request
	 * @param response
	 * @param mbForm
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=saveterminalRepertoryOut")
	@FormToken(remove=true)
	public String saveterminalRepertoryOut(HttpServletRequest request,HttpServletResponse response,TerminalForm mbForm) throws Exception {
		HSSFSheet sheet;
		InputStream in = null;
		try {
				MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
				// 获得文件
				MultipartFile file = multipartRequest.getFile("termNosFile");
				// 获取输出流
				in = file.getInputStream();
				HSSFWorkbook workbook = new HSSFWorkbook(in);
				sheet = workbook.getSheetAt(0);
			} catch (Exception e) {
				e.printStackTrace();
				throw new BusinessException(ExceptionDefine.库存管理,new String[]{"文件上传失败"});
			}finally {
				in.close();
			}
		
			String batchNo=request.getParameter("batchNo");
			String shopperid_p=request.getParameter("shopperidP");
			if (sheet != null) {
				Map map = insertBatchOut(request, shopperid_p, sheet);
				
				JSONObject json =JSONObject.fromObject(map);
				log.info(map.get("rspMsg") + json.toString());
				if(map.get("rspCode").equals(Constants.SUCCESS_CODE)){
					request.setAttribute("url","terminalRepertory.htm?method=findTerminalRepertoryOutList");
					response.setContentType("UTF-8");
					
					request.setAttribute(Constants.MESSAGE_KEY, map.get("rspMsg"));
				}
				
			}
		
			
			return "/returnPage";
	}
	
	
	/**
	 * 终端退货
	 * @param request
	 * @param response
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=saveterminalRetreat")
	@FormToken(remove=true)
	public String saveterminalRetreat(HttpServletRequest request,HttpServletResponse response,TerminalForm mbForm) throws Exception{
		HSSFSheet sheet;
		InputStream in = null;
		try {
				MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
				// 获得文件
				MultipartFile file = multipartRequest.getFile("termNosFile");
				// 获取输出流
				in = file.getInputStream();
				HSSFWorkbook workbook = new HSSFWorkbook(in);
				sheet = workbook.getSheetAt(0);
			} catch (Exception e) {
				e.printStackTrace();
				throw new BusinessException(ExceptionDefine.库存管理,new String[]{"文件上传失败"});
			}finally {
				in.close();
			}
			String shopperid_p=request.getParameter("shopperidP");
			if (sheet != null) {
				Map<String,Object> map = updateTerminalRetreat(request,shopperid_p, sheet);
				
				JSONObject json =JSONObject.fromObject(map);
				log.info(map.get("rspMsg") + json.toString());
				if(map.get("rspCode").equals(Constants.SUCCESS_CODE)){
					request.setAttribute("url","terminalRepertory.htm?method=findTerminalRepertoryOutList");
					response.setContentType("UTF-8");
					request.setAttribute(Constants.MESSAGE_KEY, map.get("rspMsg"));
				}
				
			}
			
			return "/returnPage";
	}
	
	

	/**验证批次号是否存在
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(params="method=ajaxTermBatchNo")
	public void ajaxTermBatchNo(HttpServletRequest request,HttpServletResponse response) throws IOException{
		try {
			String ajaxTermBatchNo=request.getParameter("batchNo");
			List list=null;
			if(StringUtils.isTrimNotEmpty(ajaxTermBatchNo)){
			    list=terminalRepertoryService.findTermBatchNo(ajaxTermBatchNo.trim());
			}
			PrintWriter out=response.getWriter();
			try {
				if(list!=null&&list.size()>0){
					out.write("{\"x\":\"1\"}");
				}else{
					out.write("{\"x\":\"2\"}");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				if(out !=null){
					out.flush();
					out.close();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	/**
	 * 退货页面
	 * @author yang.liu01
	 * @return
	 */
	@RequestMapping(params = "method=terminalRepertoryRetreat")
	@FormToken(save=true)
	public String terminalRepertoryRetreat(HttpServletRequest request) {
		Users  sessionUser=(Users)request.getSession().getAttribute(Constants.SESSION_KEY_USER); 
		//当前登录商
		Long merchantId = sessionUser.getMerchantid();
		String currentAgentNo = null==merchantId?"":merchantId.toString();
		//取得上一级服务商
		Agent agent = agentService.findAgentbyParam(currentAgentNo);
		Long shopperidP = agent.getShopperidP();
		String shopperid_p = null==shopperidP?"":shopperidP.toString();
		if(!StringUtils.isEmpty(shopperid_p)) {
			agent = agentService.findAgentByShopperid(currentAgentNo);
		}
		
		request.setAttribute("shopperid", agent.getShopperid());
		request.setAttribute("belongsAgent", agent.getScompany());
		
		
		return "terminal/terminalRepertoryRetreat";
	}
	
	
	
	/**出库页面
	 * @param request
	 * @param response
	 * @param mbForm
	 * @return
	 */
	@RequestMapping(params = "method=terminalRepertoryOut")
	@FormToken(save=true)
	public String terminalRepertoryOut(HttpServletRequest request,HttpServletResponse response,TerminalForm mbForm) {
		
		return "terminal/terminalRepertoryOut";
	}
	

	/**
	 * 终端退货操作
	 * @author yang.liu01
	 * @param request 
	 * @param request
	 * @param retreatAgentNo
	 * @param sheet
	 * @return
	 * @throws BusinessException
	 */
	public Map<String, Object> updateTerminalRetreat(HttpServletRequest request, String retreatAgentNo, HSSFSheet sheet) throws BusinessException{
		HSSFRow row=null;
		int index=0;
		Map<String,Object> msgMap = new HashMap<String,Object>();	
		List<B2cTermBinder> retreatList = new ArrayList<B2cTermBinder>();
		
		Users  sessionUser=(Users)request.getSession().getAttribute(Constants.SESSION_KEY_USER); 
		//当前登录商
		Long merchantId = sessionUser.getMerchantid();
		String currentAgentNo = null==merchantId?"":merchantId.toString();
		
		int rowNum=sheet.getLastRowNum()+1;
		if(rowNum<Constants.UPLOAD_SIZE) {
			for (int i = 0; i <= rowNum; i++) {
				row = sheet.getRow(i);
				if (null != row) {
					//设备编号
					String termNo=row.getCell(0).toString();
					//处理空格
					termNo=termNo.replaceAll(" ", "");
					//异常处理
					//正则表达式判断二维码只能是数字
					if(!termNo.matches(Constants.TERM_REGULAR)) {
						index++;
						logger.info("第"+index+"条，终端序列号有非法数字!");
						throw new BusinessException(ExceptionDefine.终端序列号有非法数字,new String[]{"文件第"+index+"条,终端序列号有非法数字,请转换成文本格式数字!"});
					}
					//终端序列号长度校验
					if(termNo.length()!=Constants.TERM_SIZE) {
						index++;
						logger.info("第"+index+"条，终端序列号长度错误!");
						throw new BusinessException(ExceptionDefine.终端序列号长度错误,new String[]{"文件第"+index+"条,终端序列号长度错误!"});
					}
					//通过终端序列号查询出对应的相关信息
					B2cTermBinder b2cTermBinder = terminalRepertoryService.findTermBatchByTermNo(termNo);
					if(b2cTermBinder==null) {
						index++;
						throw new BusinessException(ExceptionDefine.终端未入库,new String[]{"终端第"+index+"条没有入库，批次提交失败！"});
					}
					if(StringUtils.isEmpty(b2cTermBinder.getMerchantNo())) {
						index++;
						if(b2cTermBinder.getAgent_no().equals(currentAgentNo)) {
							//更改所属服务商和上级服务商
							b2cTermBinder.setAgent_no(retreatAgentNo);
							b2cTermBinder.setUpper_level_agent_no(retreatAgentNo);
							b2cTermBinder.setUpdate_date(new Date());
							b2cTermBinder.setUpdate_user(currentAgentNo);
							retreatList.add(b2cTermBinder);
						}else{
							throw new BusinessException(ExceptionDefine.终端退货的服务商不一致,new String[]{"终端第"+index+"条的服务商不一致，批次提交失败！"});
						}
					
					}else {
						index++;
						logger.info("第"+index+"条，终端序列号长度错误!");
						throw new BusinessException(ExceptionDefine.终端已经绑定商户,new String[]{"文件第"+index+"条,终端已经绑定商户!"});
					}
				}
			}
			if(!retreatList.isEmpty()) {
				try {
					this.terminalRepertoryService.updateTerminalRetreat(retreatList);
				} catch (Exception e) {
					e.printStackTrace();
					throw new BusinessException(ExceptionDefine.操作失败);
				}
				msgMap.put("rspCode", Constants.SUCCESS_CODE);
				msgMap.put("rspMsg", "共"+retreatList.size()+"条，终端编号退货成功");
				
			}
		}else{
			throw new BusinessException(ExceptionDefine.上传条数超限制);
		}
		
		return msgMap;
		
	}
	
	
	/**
	 * 终端出库
	 * @author yang.liu01
	 * @param request
	 * @param sheet
	 * @throws BusinessException 
	 */
	public Map insertBatchOut(HttpServletRequest request,String outAgentNo, HSSFSheet sheet) throws BusinessException {
		HSSFRow row=null;
		int index=0;
		Map msgMap = new HashMap();		
		Users  sessionUser=(Users)request.getSession().getAttribute(Constants.SESSION_KEY_USER); 
		//当前登录商
		Long merchantId = sessionUser.getMerchantid();
		String currentAgentNo = null==merchantId?"":merchantId.toString();
		List<B2cTermBinder> outList = new ArrayList<B2cTermBinder>();
		int rowNum=sheet.getLastRowNum()+1;
		if(rowNum<=Constants.UPLOAD_SIZE) {
			for (int i = 0; i  <= rowNum; i++) {
				row = sheet.getRow(i);
				if (null != row) {
					// 出库：修改层级服务商和所属服务商。
					//设备编号
					String termNo=row.getCell(0).toString();
					//处理空格
					termNo=termNo.replaceAll(" ", "");
					
					//正则表达式判断二维码只能是数字
					if(!termNo.matches(Constants.TERM_REGULAR)) {
						index++;
						logger.info("第"+index+"条，终端序列号有非法数字!");
						throw new BusinessException(ExceptionDefine.终端序列号有非法数字,new String[]{"文件第"+index+"条,终端序列号有非法数字,请转换成文本格式数字!"});
					}
					//终端序列号长度校验
					if(termNo.length()!=Constants.TERM_SIZE) {
						index++;
						logger.info("第"+index+"条，终端序列号长度错误!");
						throw new BusinessException(ExceptionDefine.终端序列号长度错误,new String[]{"文件第"+index+"条,终端序列号长度错误!"});
					}
					
					B2cTermBinder b2cTermBinder = terminalRepertoryService.findTermBatchByTermNo(termNo);
					//如果已经入库
					if(null!=b2cTermBinder) {
						String termAgentNo=b2cTermBinder.getAgent_no();
						//首先要判断是不是一级服务商
						if(null!=b2cTermBinder.getParent_agent_no()&&b2cTermBinder.getAgent_no()==null) {
							index++;
							//层级关系设置
							b2cTermBinder.setAgent_no(outAgentNo);//服务商编号
							b2cTermBinder.setUpper_level_agent_no(outAgentNo);
							//绑定商户相关信息
							//todo 封装更新数据-出库
							outList.add(b2cTermBinder);
						}else{
							//首先判断登录服务商与设备服务商是否一致
							if(currentAgentNo.equals(termAgentNo)) {
								index++;
								//层级关系设置
								b2cTermBinder.setAgent_no(outAgentNo);//服务商编号
								b2cTermBinder.setUpper_level_agent_no(outAgentNo);
								outList.add(b2cTermBinder);
								
							}else {
								//服务商不一致
								index++;
								logger.info("第"+index+"条，终端序列号长度错误!");
								throw new BusinessException(ExceptionDefine.服务商不一致,new String[]{"文件第"+index+"条,服务商不一致!"});
							}
						}
					}else {
						index++;
						logger.info("第"+index+"条，设备编号没有入库");
						throw new BusinessException(ExceptionDefine.设备编号没有入库,new String[]{"文件第"+index+"条设备编号没有入库，该批次失效!"});
					}
				}
				
			}
		}else{
			throw new BusinessException(ExceptionDefine.上传条数超限制);
		}
		
		//如果没有异常统一出库
		for (B2cTermBinder binder : outList) {
			//出库
			if(null !=binder) {
				try {
					terminalRepertoryService.updateBatchBinderOut(binder);
				} catch (Exception e) {
					e.printStackTrace();
					throw new BusinessException(ExceptionDefine.终端出库异常);
				}
				
			}
			
		}
		
		msgMap.put("rspCode", Constants.SUCCESS_CODE);
		msgMap.put("rspMsg", "共"+index+"条，终端编号出库成功");
		JSONObject json = JSONObject.fromObject(msgMap);
		return msgMap;
	}
	
	

	
	/**
	 * 终端入库
	 * @author yang.liu01
	 * @param request
	 * @param batchNo
	 * @param terminal_type_no
	 * @param factory_no
	 * @param sheet
	 * @throws BusinessException 
	 */
	public Map insertBatchIn(HttpServletRequest request, String batchNo,
			String terminal_type_no, String factory_no, HSSFSheet sheet) throws BusinessException {
		HSSFRow row=null;
		int index=0;
		Map msgMap = new HashMap();		
		Users  sessionUser=(Users)request.getSession().getAttribute(Constants.SESSION_KEY_USER); 
		//当前登录商
		Long merchantId = sessionUser.getMerchantid();
		String agentNo = null==merchantId?"":merchantId.toString();
		List<B2cTermBinder> bactList = new ArrayList<B2cTermBinder>();
		String firstNo ="";
		
		int rowNum=sheet.getLastRowNum()+1;
		if(rowNum<=Constants.UPLOAD_SIZE) {
			for (int i = 0; i <= rowNum; i++) {
				row = sheet.getRow(i);
				if (null != row) {
					//设备编号
					String termNo=row.getCell(0).toString();
					//处理空格
					termNo=termNo.replaceAll(" ", "");
					//正则表达式判断二维码只能是数字
					if(!termNo.matches(Constants.TERM_REGULAR)) {
						index++;
						logger.info("第"+index+"条，终端序列号有非法数字!");
						throw new BusinessException(ExceptionDefine.终端序列号有非法数字,new String[]{"文件第"+index+"条,终端序列号有非法数字,请转换成文本格式数字!"});
					}
					//终端序列号长度校验
					if(termNo.length()!=Constants.TERM_SIZE) {
						index++;
						logger.info("第"+index+"条，终端序列号长度错误!");
						throw new BusinessException(ExceptionDefine.终端序列号长度错误,new String[]{"文件第"+index+"条,终端序列号长度错误!"});
					}
					B2cTermBinder b2cTermBinder = terminalRepertoryService.findTermBatchByTermNo(termNo);
					//如果已经入库
					if(null!=b2cTermBinder) {
						if(b2cTermBinder.getUpper_level_agent_no()!=null) {
							index++;
 							logger.info("第"+index+"条，终端已经入过库!");
							throw new BusinessException(ExceptionDefine.终端已经入过库,new String[]{"文件第"+index+"条,终端已经入过库，该批次失效!"});
						}else {
							//如果终端已经和商户绑定
							if(!StringUtils.isEmpty(b2cTermBinder.getMerchantNo())) {
								index++;
	 							logger.info("第"+index+"条，终端号已经绑定终端不能入库");
	 							throw new BusinessException(ExceptionDefine.终端已经绑定商户,new String[]{"文件第"+index+"条含绑定状态的终端，该批次失效!"});
								
							}else {
								//递归取到一级服务商
								firstNo = terminalRepertoryService.findFisrtAgentByNo(agentNo);
								if(firstNo.equals(b2cTermBinder.getParent_agent_no())) {
									index++;
									b2cTermBinder.setUpper_level_agent_no(agentNo);	
									b2cTermBinder.setAgent_no(agentNo);
									//将要入库的数据都放入list
									bactList.add(b2cTermBinder);
								}else{
									index++;
									logger.info("第"+index+"条，一级服务商不一致");
									throw new BusinessException(ExceptionDefine.一级服务商不一致,new String[]{"文件第"+index+"条一级服务商不一致，该批次失效!"});
								}
								
							}
						}
						
					}else {
						index++;
						logger.info("第"+index+"条，设备编号没有入库");
						throw new BusinessException(ExceptionDefine.设备编号没有入库,new String[]{"文件第"+index+"条设备编号没有入库，该批次失效!"});
					}
				}
				
			}
		}else {
			throw new BusinessException(ExceptionDefine.终端入库条数过大);
		}
		
		//如果没有异常统一入库
		for (B2cTermBinder binder : bactList) {
			try {
				if(null!=binder) {
					this.terminalRepertoryService.updateBatchBinder(binder);
				}
			} catch (Exception e) {
				e.printStackTrace();
				throw new BusinessException(ExceptionDefine.终端入库异常);
			}
			
		}
		msgMap.put("rspCode", Constants.SUCCESS_CODE);
		msgMap.put("rspMsg", "共"+index+"条，终端编号入库成功");
		JSONObject json = JSONObject.fromObject(msgMap);
		return msgMap;
	}
	
	/**
	 * 出库模板下载
	 * @param fileName
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/download")
	public void download(HttpServletRequest request,HttpServletResponse response) {
		String path = request.getContextPath();
		String basePath = request.getScheme() + "://"
				+ request.getServerName() + ":" + request.getServerPort()
				+ path + "/";
		String filePath =request.getSession().getServletContext().getRealPath("/")+
				"upload"+File.separator+"terminal"+File.separator+"templatae.xls" ;
    	String fileName = "";
    	
    	System.out.println("文件路径："+filePath);
    	
    	//从文件完整路径中提取文件名，并进行编码转换，防止不能正确显示中文名
    	try {
        	if(filePath.lastIndexOf("/") > 0) {
        		fileName = new String(filePath.substring(filePath.lastIndexOf("/")+1, filePath.length()).getBytes("GB2312"), "ISO8859_1");
        	}else if(filePath.lastIndexOf("\\") > 0) {
        		fileName = new String(filePath.substring(filePath.lastIndexOf("\\")+1, filePath.length()).getBytes("GB2312"), "ISO8859_1");
        	}
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    	//打开指定文件的流信息
    	InputStream fs = null;
    	try {
    		fs = new FileInputStream(new File(filePath));
    		
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    	//设置响应头和保存文件名 
    	response.setCharacterEncoding("ISO-8859-1");
    	response.setContentType("APPLICATION/OCTET-STREAM"); 
    	response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
    	//写出流信息
    	int b = 0;
    	try {
        	PrintWriter out = response.getWriter();
        	while((b=fs.read())!=-1) {
        		out.write(b);
        	}
        	out.flush();
        	fs.close();
        	out.close();
        	System.out.println("文件下载完毕.");
    	}catch(Exception e) {
        	e.printStackTrace();
        	System.out.println("下载文件失败!");
    	}
	}
	
	
	
}
