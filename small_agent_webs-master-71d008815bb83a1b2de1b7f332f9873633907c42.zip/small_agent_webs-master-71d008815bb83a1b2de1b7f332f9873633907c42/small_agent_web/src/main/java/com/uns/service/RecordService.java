package com.uns.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.common.page.PageContext;
import com.uns.dao.B2cShopperbiMapper;
import com.uns.dao.OrderInfoMapper;
import com.uns.model.B2cShopperbi;
import com.uns.web.form.AgentRechargeForm;

@Service
public class RecordService {
	@Autowired
	private B2cShopperbiMapper b2cShopperbiMapper; 
	
	@Autowired
	public OrderInfoMapper orderInfoMapper;
	/**
	 * 根据商户号查询保理账户ID
	 * @param stel
	 * @return
	 */
	public B2cShopperbi findFactoringNoByShopperid(String shopperid){
		return b2cShopperbiMapper.findFactoringNoByShopperid(shopperid);
	}
	
	/**
	 * 查询充值记录
	 * @param param
	 * @return
	 */
	public List<Map<String,String>> selectRechargeList(Map<String, Object> param){
		PageContext.initPageSize(20);
		return orderInfoMapper.selectRechargeList(param);
	}
	/**
	 * 刷卡总计
	 * @param param
	 * @return
	 */
	public Map selectRechargeListSum(Map<String, Object> param){
		return orderInfoMapper.selectRechargeListSum(param);
	}
	
	/**
	 * 查询提现记录
	 * @param param
	 * @return
	 */
	public List<Map<String,String>> selectWithdrawList(Map<String, Object> param){
		PageContext.initPageSize(20);
		return orderInfoMapper.selectWithdrawList(param);
	}
	/**
	 * D0提现记录
	 * @author yang.liu01
	 * @param param
	 * @return
	 */
	public List<Map<String, String>> selectWithdrawD0List(Map<String, Object> param){
		PageContext.initPageSize(20);
		return orderInfoMapper.selectWithdrawD0List(param);
	}
	/**
	 * T1提现记录
	 * @author yang.liu01
	 * @param param
	 * @return
	 */
	public List<Map<String, String>> selectWithdrawT1List(Map<String, Object> param) {
		PageContext.initPageSize(20);
		return orderInfoMapper.selectWithdrawT1List(param);
	}
	/**
	 * T0提现总计
	 * @param param
	 * @return
	 */
	public Map selectWithdrawListSum(Map<String, Object> param){
		return orderInfoMapper.selectWithdrawListSum(param);
	}
	
	/**
	 * 查询提现记录
	 * @param qp
	 * @return
	 */
	public List<Map<String,String>> excelWithdrawList(Map<String, Object> qp){
		PageContext.initPageSize(Constants.excel_size);
		return orderInfoMapper.selectWithdrawD0List(qp);
	}
	/**
	 * T1导出
	 * @param qp
	 * @return
	 */
	public List<Map<String, String>> excelWithdrawT1List(Map<String, Object> qp){
		PageContext.initPageSize(Constants.excel_size);
		return orderInfoMapper.selectWithdrawT1List(qp);
	}
    
	/**
	 * 通过商户号查询银生宝找好
	 * @param shopperidp
	 * @return
	 */
    public List<String> selectYsbno(Long shopperidp){
    	return orderInfoMapper.selectYsbno(shopperidp);
    }  
    
    /**
     * 充值记录信息下载
     * @param arForm
     * @return
     */
    public List<Map<String,Object>> findRechargePageList(Map<String, Object> param){
		PageContext.initPageSize(Constants.excel_size);
		List<Map<String,Object>> list=orderInfoMapper.findRechargePageList(param);
		if(list!=null&&list.size()!=0){
			return list;
		}
    	return new ArrayList<Map<String,Object>>();
    }
    
    /**
     * 查询D0提现时间
     * @return
     */
    public List<Map<String,String>> selectD0Time(){
    	return orderInfoMapper.selectD0Time();
    }
}
