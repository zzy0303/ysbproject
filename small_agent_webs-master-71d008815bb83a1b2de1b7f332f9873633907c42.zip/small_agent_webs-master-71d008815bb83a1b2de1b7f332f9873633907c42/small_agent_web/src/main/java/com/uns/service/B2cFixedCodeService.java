package com.uns.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.page.PageContext;
import com.uns.dao.B2cFixedCodeMapper;
import com.uns.model.B2cFixedCode;


@Service
public class B2cFixedCodeService {
	
	@Autowired
	private B2cFixedCodeMapper b2cFixedCodeMapperDao;
	
	/**
	 * 固码入库列表
	 * @author yang.liu01
	 * @param b2cFixedCode
	 * @return
	 */
	public List<B2cFixedCode> findFixedCodeList(B2cFixedCode b2cFixedCode){
		List<B2cFixedCode> resultList = null;
		try {
			PageContext.initPageSize(20);
			resultList = b2cFixedCodeMapperDao.findFixedCodeList(b2cFixedCode);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultList;
		
	}
	/**
	 * 通过二维码编号查询
	 * @param qrCodeNo
	 * @return
	 */
	public B2cFixedCode findFixedCodeByParam(String qrCodeNo) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("qrCodeNo", qrCodeNo);
		return b2cFixedCodeMapperDao.findFixedCodeByParam(map);
	}
	
	/**
	 * 批量插入
	 * @param bactList
	 */
	public void insertBatchModel(List<B2cFixedCode> bactList) {
			this.b2cFixedCodeMapperDao.insertBatchModel(bactList);
		
	}
	/**
	 * 固码出库列表 
	 * @param b2cFixedCode
	 * @return
	 */
	public List<B2cFixedCode> findFixedCodeOutList(B2cFixedCode b2cFixedCode) {
		List<B2cFixedCode> resultList = null;
		try {
			PageContext.initPageSize(20);
			resultList = b2cFixedCodeMapperDao.findFixedCodeOutList(b2cFixedCode);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultList;
	}
	
	/**
	 * 批量出库
	 * @param bactList
	 */
	public void updateBatchModel(B2cFixedCode model) {
		this.b2cFixedCodeMapperDao.updateBatchModel(model);
		
	}
	public List<B2cFixedCode> findFixedCodesByParam(B2cFixedCode b2cFixedCode) {
		return b2cFixedCodeMapperDao.findFixedCodesByParam(b2cFixedCode);
	}
	public List<B2cFixedCode> findNoBindQrCode(Map map) {
		return b2cFixedCodeMapperDao.findNoBindQrCode(map);
	}
	public void updateById(B2cFixedCode b2cFixedCode) {
		b2cFixedCodeMapperDao.updateById(b2cFixedCode);
	}
	
	public B2cFixedCode findModelByParam(B2cFixedCode b2cFixedCode) {
		return b2cFixedCodeMapperDao.findModelByParam(b2cFixedCode);
	}
	public List<B2cFixedCode> findModelByMerNo(String merchantid) {
		return b2cFixedCodeMapperDao.findModelByMerNo(merchantid);
	}
	
}
