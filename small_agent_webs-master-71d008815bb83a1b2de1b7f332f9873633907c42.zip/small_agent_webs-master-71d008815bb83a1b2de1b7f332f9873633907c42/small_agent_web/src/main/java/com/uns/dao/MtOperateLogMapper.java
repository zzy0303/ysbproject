package com.uns.dao;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;
import org.springframework.stereotype.Repository;

import com.uns.web.form.OperateLogForm;

import com.uns.model.MtOperateLog;
@Repository
public interface MtOperateLogMapper {

    List<MtOperateLog> selectAccesslogList(OperateLogForm form);

    boolean insert(MtOperateLog record);

    MtOperateLog selectByPrimaryKey(String logid);
}