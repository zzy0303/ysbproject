package com.uns.dao;

import org.springframework.stereotype.Repository;

import com.uns.model.TerminalHistory;
@Repository
public interface TerminalHistoryMapper {


    int insert(TerminalHistory record);

    int insertSelective(TerminalHistory record);

}