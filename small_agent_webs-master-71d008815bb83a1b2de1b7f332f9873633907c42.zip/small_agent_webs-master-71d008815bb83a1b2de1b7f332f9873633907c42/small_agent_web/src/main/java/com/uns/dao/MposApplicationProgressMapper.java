package com.uns.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.B2cShopperbiTemp;
import com.uns.model.MposApplicationProgress;
import com.uns.web.form.ApplicationProgressForm;

@Repository
public interface MposApplicationProgressMapper {
	
    int insert(MposApplicationProgress record);

    int insertSelective(MposApplicationProgress record);

    List<Map<String,String>> searchApplicationProgressList(ApplicationProgressForm applicationProgressForm);
    
    List queryall();
    
    List findbyshopperidp(String shopperidp);
    
    List findbyid(long applicationProgressId);

	MposApplicationProgress findMposApplicationProgress(Map map);

	void updateSelective(MposApplicationProgress alp);
	     
	MposApplicationProgress findbyshopperid(String shopperid);
	
	int updateByPrimaryKeySelective(MposApplicationProgress record);
	
	List findbystatusList(Map map);
	
	MposApplicationProgress findbyid(String applicationProgressId);
	
	void deleteByPrimaryKey(String shopperid);
}