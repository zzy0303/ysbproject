package com.uns.web;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.model.Users;
import com.uns.service.AgentFissionFeeSplitService;
import com.uns.slx.common.mutidatasource.DataSourceSwitch;
import com.uns.util.ExcelUtils;
import com.uns.web.form.SplitForm;

/**
 * mpos 服务商裂变分润
 *
 */
@Controller
@RequestMapping(value = "/agentFissionFeeSplit.htm")
public class AgentFissionFeeSplitController extends BaseController {

	
	@Autowired
	private AgentFissionFeeSplitService agentFissionFeeSplitService;
	
	
	/**
	 * 服务商裂变分润
	 * @param request
	 * @param response
	 * @param sform
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=findAgentFissionFeeSpList")
	public String findAgentFissionFeeSpList(HttpServletRequest request, HttpServletResponse response,
									   SplitForm sform) throws BusinessException{
		DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
		try {
			Users  sessionUser=(Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			if(sessionUser==null || StringUtils.isEmpty(Long.toString(sessionUser.getMerchantid()))){
				throw new BusinessException(ExceptionDefine.商户查询失败);
			}
			sform.setSessionUserNo(String.valueOf(sessionUser.getMerchantid()));
			List<Map<String,Object>> listData = agentFissionFeeSplitService.findAgentFissionFeeSpList(sform);
			for(Map<String,Object> map:listData){
				Date d1 = (Date)map.get("END_DATE");
				Calendar cal=Calendar.getInstance();
				cal.add(Calendar.WEEK_OF_MONTH, -4);
				cal.set(Calendar.DAY_OF_WEEK, 2);
				Date d2 = cal.getTime();
				if(d1.compareTo(d2) == -1 ){
					map.put("detailFlag", "0");
				}else{
					map.put("detailFlag", "1");
				}
				String shopperid = (String) map.get("SHOPPERIDP");
				String settleType=(String) map.get("SETTLE_TYPE");
				List<Map<String, Object>> feeList = agentFissionFeeSplitService.selectAgentFee(shopperid,Constants.CON_YES);
				for (Map<String, Object> map2 : feeList) {
					if(Constants.SS_FEE_TYPE.equals(settleType)){
						map.put("AG_FEE", map2.get("SK_SECOND_FEE"));
					}
					if(Constants.SI_FEE_TYPE.equals(settleType)){
						map.put("AG_FEE", map2.get("SK_IMMEDIATE_FEE"));
					}
					if(Constants.T1_FEE_TYPE.equals(settleType)){
						map.put("AG_FEE", map2.get("T1_FEE"));
					}
				}
			}
			
			request.setAttribute("list", listData);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.裂变分润出错);
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		
		return "agentfission/agentfissionList";
	}
	
	
	/**
	 * 导出分页
	 * @param request
	 * @param response
	 * @param sform
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=downAgentFissionSplitPage")
	public String downAgentFissionSplitPage(HttpServletRequest request, HttpServletResponse response,
									   SplitForm sform) throws Exception{
		DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
        try {
        	Users  sessionUser=(Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			if(sessionUser==null || StringUtils.isEmpty(Long.toString(sessionUser.getMerchantid()))){
				throw new BusinessException(ExceptionDefine.商户查询失败);
			}
			sform.setSessionUserNo(String.valueOf(sessionUser.getMerchantid()));
        	Page page  = new Page();
    		page.setPageSize(Constants.EXCEL_SIZE);
    		PageContext context = PageContext.getContext();
    		BeanUtils.copyProperties(context, page);
    		context.setPagination(true);
    		
    		agentFissionFeeSplitService.downAgentFissionSplitList(sform);
    		BeanUtils.copyProperties(page, context);
    		request.setAttribute("mbForm",sform);
    		request.setAttribute("page",page);
    		request.setAttribute("startDate", sform.getStartDate());
    		request.setAttribute("endDate", sform.getEndDate());
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.裂变分润导出分页出错);
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		

		return "agentfission/agentfissionBatchListPage";
	}
	
	
	/**
	 * 带出
	 * @param request
	 * @param response
	 * @param sform
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=downAgentProfitAuditPageExcel")
	public String downAgentProfitAuditPageExcel(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform) throws Exception{
		
		DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
		try {
			Users  sessionUser=(Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			if(sessionUser==null || StringUtils.isEmpty(Long.toString(sessionUser.getMerchantid()))){
				throw new BusinessException(ExceptionDefine.商户查询失败);
			}
			sform.setSessionUserNo(String.valueOf(sessionUser.getMerchantid()));
			String tPage = request.getParameter("page");
			if (StringUtils.isEmpty(tPage) || !StringUtils.isNumeric(tPage)){
				tPage = "1";
			}
			int currentPage = Integer.valueOf(tPage);
			Page page  = new Page();
			page.setPageSize(Constants.EXCEL_SIZE);
			PageContext context = PageContext.getContext();
			BeanUtils.copyProperties(context, page);
			context.setPagination(true);
			context.setCurrentPage(currentPage);
			List<Map<String,Object>> listData = agentFissionFeeSplitService.downAgentFissionSplitList(sform);
			BeanUtils.copyProperties(page, context);
			request.setAttribute("page",page);
			
			for(Map<String,Object> map:listData){
				String settleType=(String) map.get("SETTLE_TYPE");
				String shopperid = (String) map.get("SHOPPERIDP");
				List<Map<String, Object>> feeList = agentFissionFeeSplitService.selectAgentFee(shopperid,Constants.CON_YES);
				for (Map<String, Object> map2 : feeList) {
					if(Constants.SS_FEE_TYPE.equals(settleType)){
						map.put("AG_FEE", map2.get("SK_SECOND_FEE"));
					}
					if(Constants.SI_FEE_TYPE.equals(settleType)){
						map.put("AG_FEE", map2.get("SK_IMMEDIATE_FEE"));
					}
					if(Constants.T1_FEE_TYPE.equals(settleType)){
						map.put("AG_FEE", map2.get("T1_FEE"));
					}
				}
			}
			
			List<String> listHead = new ArrayList<String>();
			listHead.add("结算批次号");
			listHead.add("批次生成时间");
			listHead.add("一级服务商编号");
			listHead.add("一级服务商名称");
			listHead.add("交易笔数/笔");
			listHead.add("刷卡交易总金额/元");
			listHead.add("分润总金额/元");
			listHead.add("服务商费率");
			listHead.add("收益服务商标识");
			listHead.add("收益服务商分润比例");
			listHead.add("状态");
			List<String> listKey = new ArrayList<String>();
			listKey.add("BATCH_NO");
			listKey.add("CREATE_DATE");
			listKey.add("SHOPPERIDP");
			listKey.add("SCOMPANY");
			listKey.add("SUM_COUNT");
			listKey.add("SUM_AMOUNT");
			listKey.add("SUM_PROFIT");
			listKey.add("AG_FEE");
			listKey.add("PROFIT_OWNER");
			listKey.add("AGENT_PROFIT_RATIO");
			listKey.add("STATUSS");
			
			ExcelUtils.downExcel(listData, listKey, listHead, "AGENT_PROFIT_AUDIT", "服务商裂变分润", response);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.裂变分润导出出错);
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		
	    return null;
	}
	
	
	@RequestMapping(params = "method=batchUpdateAgFissFee")
	public String batchUpdateAgFissFee(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform) throws BusinessException{
		DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
		try {
			Users  sessionUser=(Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			if(sessionUser==null || StringUtils.isEmpty(Long.toString(sessionUser.getMerchantid()))){
				throw new BusinessException(ExceptionDefine.商户查询失败);
			}
			sform.setSessionUserNo(String.valueOf(sessionUser.getMerchantid()));
			String ids=request.getParameter("ids");
			String status=request.getParameter("status");
			if(sform.getIds() != null){
				String[] idsArr = ids.substring(1, ids.length()).split(",");
				List<String> list = Arrays.asList(idsArr);
				agentFissionFeeSplitService.batchUpdateAgFissFee(status,list);
			}
			request.setAttribute(Constants.MESSAGE_KEY, "操作成功");
			request.setAttribute("url", "agentFissionFeeSplit.htm?method=findAgentFissionFeeSpList");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.裂变分润审核出错);
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		
		return "/returnPage";
	}
}
