package com.uns.dao;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.B2cShopperbi;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.MposPhotoTmp;
import com.uns.web.form.ShopPerbiForm;
@Repository
public interface B2cShopperbiTempMapper{

    int deleteByPrimaryKey(BigDecimal b2cShopperbiId);

    int insert(B2cShopperbiTemp record);

    int insertSelective(B2cShopperbiTemp record);

    B2cShopperbiTemp selectByPrimaryKey(BigDecimal b2cShopperbiId);

    int updateByPrimaryKeySelective(B2cShopperbiTemp record);

    int updateByPrimaryKey(B2cShopperbiTemp record);

	List<HashMap> ShopPerbiManageList(ShopPerbiForm mbForm);

	B2cShopperbiTemp selectByshopperId(Long b2cShopperbiId);

	void updateByShopperId(B2cShopperbiTemp b2cShopperbi);
	
	void updateBankInfo(B2cShopperbiTemp b2cShopperbi);

	B2cShopperbiTemp selectByScompany(String scompany);
	
	B2cShopperbiTemp selectByshopperName(String muserId);
	
	List<HashMap> ShopPerbiCheckList(ShopPerbiForm mbForm);
	//未审核商户的数量
	String selectCheckCount(ShopPerbiForm shopPerbiForm);
	//未审核商户开户银行的数量
	String selectCheckBkCount(ShopPerbiForm shopPerbiForm);
	//未审核商户终端的数量
	String selectTerminalCount(ShopPerbiForm shopPerbiForm);

	List selectByMuserid(String userName);
	
	
	List findtelbyscompany(String scompany);
	
	
    B2cShopperbiTemp findtelajax(Map map);
    
    List findmerchantbyNo(String b2cShopperbiId);
    
    B2cShopperbiTemp findShopperbiTempByShopperid(String shopperid);
    List findbytel(String tel);
    
    B2cShopperbiTemp findShopperbiTempByShopperidp(String shopperid);
    
    List<HashMap> shopPerbiTerminalList(ShopPerbiForm mbForm);
    
    
    String selectevicenumCount(ShopPerbiForm shopPerbiForm);
    
    List findbysid(String identityId);
    
    List findbyshopperid(String shopperid);
    
    List<HashMap> findbyshopper(String shopperid);

	void updateByphoto(Map map);

	void updateB2cShopperbiTempSmsCode(B2cShopperbiTemp b2cShopperbi);

	void updateQrCode(Map map);

	void updateQrPayCode(Map map);
    
    List<B2cShopperbiTemp> findShopperTempList(ShopPerbiForm mbform);
    
    List<HashMap> findShopperTempExportList(ShopPerbiForm mbForm);
}