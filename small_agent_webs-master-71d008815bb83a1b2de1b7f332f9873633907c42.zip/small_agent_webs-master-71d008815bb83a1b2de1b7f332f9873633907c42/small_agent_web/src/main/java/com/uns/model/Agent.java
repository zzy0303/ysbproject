package com.uns.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class Agent implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long b2cShopperbiId;
	private String scompany;
	private String gateway;
	private String sqcode;
	private String synum;
	private String sicp;
	private String saddress;
	private String szip;
	private String smanager;
	private String srelation;
	private String semail;
	private String stel;
	private String sfax;
	private String shandset;
	private String sqq;
	private String smsn;
	private Long sshopertypeid;
	private String sshopertype;
	private String sdomain;
	private Long sshoppertypeid;
	private String sshoppertype;
	private String scity;
	private String city;
	private String sprovince;
	private String province;
	private Long transactid;
	private String transactsub;
	private String transact;
	private String operid;
	private String oper;
	private Long sifpactid;
	private String sifpact;
	private String spactoperid;
	private String spactoper;
	private Long sisnew;
	private String shoppercallingid;
	private String shoppercalling;
	private Date created;
	private Long shopperid;
	private Long sagentid;
	private Long battalion;
	private Long persentid;
	private Short ifattend;
	private Long ifagent;
	private Short shoppertypeid;
	private String srelationcredno;
	private String legalentity;
	private String srelationcrededate;
	private String legalecredno;
	private String legalecrededate;
	private String synumedate;
	private String licenseno;
	private String taxregisterno;
	private String remark;
	private String upoperid;
	private String upoper;
	private Date updated;
	private String grade;
	private String division;
	private Long shopperidP;
	private String shortname;
	private String levels;
	
	private Double max;
	private Double min;
	private Double fixamount;
	private Double t1fee;
	private Double t0fee;
	private Double t1top;
	private Double limit;
	
	private BigDecimal skDebitFee;//借记卡充值
	private BigDecimal skCreditFee;//贷记卡充值
	private BigDecimal d0Fee;//d0
	private BigDecimal smWechatT1Fee;//微信T1
	private BigDecimal smWechatD0Fee;//微信D0
	private BigDecimal smAlipayT1Fee;//支付宝T1
	private BigDecimal smAlipayD0Fee;//支付宝D0
	private BigDecimal smYlzfT1Fee;//银联T1
	private BigDecimal smYlzfD0Fee;//银联D0
	private BigDecimal skSecondFee;//秒到收款签约费率
	private BigDecimal skImmediateFee;//即时收款签约费率
	private BigDecimal skT1Fee;//T1收款签约费率
	
	private BigDecimal smShortCutT1Fee;//快捷T1收款签约费率
	private BigDecimal smShortCutD0Fee;//快捷 D0收款签约费率
	private BigDecimal smB2cT1Fee;//B2CT1收款签约费率
	private BigDecimal smB2cD0Fee;//B2C D0收款签约费率
	private BigDecimal smShortCutSHD0Fee;//快捷速惠收款签约费率
	
	
	
	
	
	public BigDecimal getSmShortCutSHD0Fee() {
		return smShortCutSHD0Fee;
	}
	public void setSmShortCutSHD0Fee(BigDecimal smShortCutSHD0Fee) {
		this.smShortCutSHD0Fee = smShortCutSHD0Fee;
	}
	public BigDecimal getSmYlzfD0Fee() {
		return smYlzfD0Fee;
	}
	public void setSmYlzfD0Fee(BigDecimal smYlzfD0Fee) {
		this.smYlzfD0Fee = smYlzfD0Fee;
	}
	public BigDecimal getSmShortCutT1Fee() {
		return smShortCutT1Fee;
	}
	public void setSmShortCutT1Fee(BigDecimal smShortCutT1Fee) {
		this.smShortCutT1Fee = smShortCutT1Fee;
	}
	public BigDecimal getSmShortCutD0Fee() {
		return smShortCutD0Fee;
	}
	public void setSmShortCutD0Fee(BigDecimal smShortCutD0Fee) {
		this.smShortCutD0Fee = smShortCutD0Fee;
	}
	public BigDecimal getSmB2cT1Fee() {
		return smB2cT1Fee;
	}
	public void setSmB2cT1Fee(BigDecimal smB2cT1Fee) {
		this.smB2cT1Fee = smB2cT1Fee;
	}
	public BigDecimal getSmB2cD0Fee() {
		return smB2cD0Fee;
	}
	public void setSmB2cD0Fee(BigDecimal smB2cD0Fee) {
		this.smB2cD0Fee = smB2cD0Fee;
	}
	public BigDecimal getSkSecondFee() {
		return skSecondFee;
	}
	public void setSkSecondFee(BigDecimal skSecondFee) {
		this.skSecondFee = skSecondFee;
	}
	public BigDecimal getSkImmediateFee() {
		return skImmediateFee;
	}
	public void setSkImmediateFee(BigDecimal skImmediateFee) {
		this.skImmediateFee = skImmediateFee;
	}
	public BigDecimal getSkT1Fee() {
		return skT1Fee;
	}
	public void setSkT1Fee(BigDecimal skT1Fee) {
		this.skT1Fee = skT1Fee;
	}
	public BigDecimal getSmYlzfT1Fee() {
		return smYlzfT1Fee;
	}
	public void setSmYlzfT1Fee(BigDecimal smYlzfT1Fee) {
		this.smYlzfT1Fee = smYlzfT1Fee;
	}
	public BigDecimal getSkDebitFee() {
		return skDebitFee;
	}
	public void setSkDebitFee(BigDecimal skDebitFee) {
		this.skDebitFee = skDebitFee;
	}
	public BigDecimal getSkCreditFee() {
		return skCreditFee;
	}
	public void setSkCreditFee(BigDecimal skCreditFee) {
		this.skCreditFee = skCreditFee;
	}
	public BigDecimal getD0Fee() {
		return d0Fee;
	}
	public void setD0Fee(BigDecimal d0Fee) {
		this.d0Fee = d0Fee;
	}
	public BigDecimal getSmWechatT1Fee() {
		return smWechatT1Fee;
	}
	public void setSmWechatT1Fee(BigDecimal smWechatT1Fee) {
		this.smWechatT1Fee = smWechatT1Fee;
	}
	public BigDecimal getSmWechatD0Fee() {
		return smWechatD0Fee;
	}
	public void setSmWechatD0Fee(BigDecimal smWechatD0Fee) {
		this.smWechatD0Fee = smWechatD0Fee;
	}
	public BigDecimal getSmAlipayT1Fee() {
		return smAlipayT1Fee;
	}
	public void setSmAlipayT1Fee(BigDecimal smAlipayT1Fee) {
		this.smAlipayT1Fee = smAlipayT1Fee;
	}
	public BigDecimal getSmAlipayD0Fee() {
		return smAlipayD0Fee;
	}
	public void setSmAlipayD0Fee(BigDecimal smAlipayD0Fee) {
		this.smAlipayD0Fee = smAlipayD0Fee;
	}
	
	/*private BigDecimal skFeetypeFee;
	private BigDecimal skToptypeFee;
	private BigDecimal skToptypeTop;
	private BigDecimal feetypeD0Fee;
	private BigDecimal toptypeD0Fee;
	
	public BigDecimal getSkFeetypeFee() {
		return skFeetypeFee;
	}
	public void setSkFeetypeFee(BigDecimal skFeetypeFee) {
		this.skFeetypeFee = skFeetypeFee;
	}
	public BigDecimal getSkToptypeFee() {
		return skToptypeFee;
	}
	public void setSkToptypeFee(BigDecimal skToptypeFee) {
		this.skToptypeFee = skToptypeFee;
	}
	public BigDecimal getSkToptypeTop() {
		return skToptypeTop;
	}
	public void setSkToptypeTop(BigDecimal skToptypeTop) {
		this.skToptypeTop = skToptypeTop;
	}
	public BigDecimal getFeetypeD0Fee() {
		return feetypeD0Fee;
	}
	public void setFeetypeD0Fee(BigDecimal feetypeD0Fee) {
		this.feetypeD0Fee = feetypeD0Fee;
	}
	public BigDecimal getToptypeD0Fee() {
		return toptypeD0Fee;
	}
	public void setToptypeD0Fee(BigDecimal toptypeD0Fee) {
		this.toptypeD0Fee = toptypeD0Fee;
	}*/

	private Double limitamount;
	
	private String iflast;
	
	public String getIflast() {
		return iflast;
	}
	public void setIflast(String iflast) {
		this.iflast = iflast;
	}
	public Double getLimitamount() {
		return limitamount;
	}
	public void setLimitamount(Double limitamount) {
		this.limitamount = limitamount;
	}
	public Double getMax() {
		return max;
	}
	public void setMax(Double max) {
		this.max = max;
	}
	public Double getMin() {
		return min;
	}
	public void setMin(Double min) {
		this.min = min;
	}
	public Double getFixamount() {
		return fixamount;
	}
	public void setFixamount(Double fixamount) {
		this.fixamount = fixamount;
	}
	public Double getT1fee() {
		return t1fee;
	}
	public void setT1fee(Double t1fee) {
		this.t1fee = t1fee;
	}
	public Double getT0fee() {
		return t0fee;
	}
	public void setT0fee(Double t0fee) {
		this.t0fee = t0fee;
	}
	public Double getT1top() {
		return t1top;
	}
	public void setT1top(Double t1top) {
		this.t1top = t1top;
	}
	public Double getLimit() {
		return limit;
	}
	public void setLimit(Double limit) {
		this.limit = limit;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Long getB2cShopperbiId() {
		return b2cShopperbiId;
	}
	public void setB2cShopperbiId(Long b2cShopperbiId) {
		this.b2cShopperbiId = b2cShopperbiId;
	}
	public String getScompany() {
		return scompany;
	}
	public void setScompany(String scompany) {
		this.scompany = scompany;
	}
	public String getGateway() {
		return gateway;
	}
	public void setGateway(String gateway) {
		this.gateway = gateway;
	}
	public String getSqcode() {
		return sqcode;
	}
	public void setSqcode(String sqcode) {
		this.sqcode = sqcode;
	}
	public String getSynum() {
		return synum;
	}
	public void setSynum(String synum) {
		this.synum = synum;
	}
	public String getSicp() {
		return sicp;
	}
	public void setSicp(String sicp) {
		this.sicp = sicp;
	}
	public String getSaddress() {
		return saddress;
	}
	public void setSaddress(String saddress) {
		this.saddress = saddress;
	}
	public String getSzip() {
		return szip;
	}
	public void setSzip(String szip) {
		this.szip = szip;
	}
	public String getSmanager() {
		return smanager;
	}
	public void setSmanager(String smanager) {
		this.smanager = smanager;
	}
	public String getSrelation() {
		return srelation;
	}
	public void setSrelation(String srelation) {
		this.srelation = srelation;
	}
	public String getSemail() {
		return semail;
	}
	public void setSemail(String semail) {
		this.semail = semail;
	}
	public String getStel() {
		return stel;
	}
	public void setStel(String stel) {
		this.stel = stel;
	}
	public String getSfax() {
		return sfax;
	}
	public void setSfax(String sfax) {
		this.sfax = sfax;
	}
	public String getShandset() {
		return shandset;
	}
	public void setShandset(String shandset) {
		this.shandset = shandset;
	}
	public String getSqq() {
		return sqq;
	}
	public void setSqq(String sqq) {
		this.sqq = sqq;
	}
	public String getSmsn() {
		return smsn;
	}
	public void setSmsn(String smsn) {
		this.smsn = smsn;
	}
	public Long getSshopertypeid() {
		return sshopertypeid;
	}
	public void setSshopertypeid(Long sshopertypeid) {
		this.sshopertypeid = sshopertypeid;
	}
	public String getSshopertype() {
		return sshopertype;
	}
	public void setSshopertype(String sshopertype) {
		this.sshopertype = sshopertype;
	}
	public String getSdomain() {
		return sdomain;
	}
	public void setSdomain(String sdomain) {
		this.sdomain = sdomain;
	}
	public Long getSshoppertypeid() {
		return sshoppertypeid;
	}
	public void setSshoppertypeid(Long sshoppertypeid) {
		this.sshoppertypeid = sshoppertypeid;
	}
	public String getSshoppertype() {
		return sshoppertype;
	}
	public void setSshoppertype(String sshoppertype) {
		this.sshoppertype = sshoppertype;
	}
	public String getScity() {
		return scity;
	}
	public void setScity(String scity) {
		this.scity = scity;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getSprovince() {
		return sprovince;
	}
	public void setSprovince(String sprovince) {
		this.sprovince = sprovince;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public Long getTransactid() {
		return transactid;
	}
	public void setTransactid(Long transactid) {
		this.transactid = transactid;
	}
	public String getTransactsub() {
		return transactsub;
	}
	public void setTransactsub(String transactsub) {
		this.transactsub = transactsub;
	}
	public String getTransact() {
		return transact;
	}
	public void setTransact(String transact) {
		this.transact = transact;
	}
	public String getOperid() {
		return operid;
	}
	public void setOperid(String operid) {
		this.operid = operid;
	}
	public String getOper() {
		return oper;
	}
	public void setOper(String oper) {
		this.oper = oper;
	}
	public Long getSifpactid() {
		return sifpactid;
	}
	public void setSifpactid(Long sifpactid) {
		this.sifpactid = sifpactid;
	}
	public String getSifpact() {
		return sifpact;
	}
	public void setSifpact(String sifpact) {
		this.sifpact = sifpact;
	}
	public String getSpactoperid() {
		return spactoperid;
	}
	public void setSpactoperid(String spactoperid) {
		this.spactoperid = spactoperid;
	}
	public String getSpactoper() {
		return spactoper;
	}
	public void setSpactoper(String spactoper) {
		this.spactoper = spactoper;
	}
	public Long getSisnew() {
		return sisnew;
	}
	public void setSisnew(Long sisnew) {
		this.sisnew = sisnew;
	}
	public String getShoppercallingid() {
		return shoppercallingid;
	}
	public void setShoppercallingid(String shoppercallingid) {
		this.shoppercallingid = shoppercallingid;
	}
	public String getShoppercalling() {
		return shoppercalling;
	}
	public void setShoppercalling(String shoppercalling) {
		this.shoppercalling = shoppercalling;
	}
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	public Long getShopperid() {
		return shopperid;
	}
	public void setShopperid(Long shopperid) {
		this.shopperid = shopperid;
	}
	public Long getSagentid() {
		return sagentid;
	}
	public void setSagentid(Long sagentid) {
		this.sagentid = sagentid;
	}
	public Long getBattalion() {
		return battalion;
	}
	public void setBattalion(Long battalion) {
		this.battalion = battalion;
	}
	public Long getPersentid() {
		return persentid;
	}
	public void setPersentid(Long persentid) {
		this.persentid = persentid;
	}
	public Short getIfattend() {
		return ifattend;
	}
	public void setIfattend(Short ifattend) {
		this.ifattend = ifattend;
	}
	public Long getIfagent() {
		return ifagent;
	}
	public void setIfagent(Long ifagent) {
		this.ifagent = ifagent;
	}
	public Short getShoppertypeid() {
		return shoppertypeid;
	}
	public void setShoppertypeid(Short shoppertypeid) {
		this.shoppertypeid = shoppertypeid;
	}
	public String getSrelationcredno() {
		return srelationcredno;
	}
	public void setSrelationcredno(String srelationcredno) {
		this.srelationcredno = srelationcredno;
	}
	public String getLegalentity() {
		return legalentity;
	}
	public void setLegalentity(String legalentity) {
		this.legalentity = legalentity;
	}
	public String getSrelationcrededate() {
		return srelationcrededate;
	}
	public void setSrelationcrededate(String srelationcrededate) {
		this.srelationcrededate = srelationcrededate;
	}
	public String getLegalecredno() {
		return legalecredno;
	}
	public void setLegalecredno(String legalecredno) {
		this.legalecredno = legalecredno;
	}
	public String getLegalecrededate() {
		return legalecrededate;
	}
	public void setLegalecrededate(String legalecrededate) {
		this.legalecrededate = legalecrededate;
	}
	public String getSynumedate() {
		return synumedate;
	}
	public void setSynumedate(String synumedate) {
		this.synumedate = synumedate;
	}
	public String getLicenseno() {
		return licenseno;
	}
	public void setLicenseno(String licenseno) {
		this.licenseno = licenseno;
	}
	public String getTaxregisterno() {
		return taxregisterno;
	}
	public void setTaxregisterno(String taxregisterno) {
		this.taxregisterno = taxregisterno;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getUpoperid() {
		return upoperid;
	}
	public void setUpoperid(String upoperid) {
		this.upoperid = upoperid;
	}
	public String getUpoper() {
		return upoper;
	}
	public void setUpoper(String upoper) {
		this.upoper = upoper;
	}
	public Date getUpdated() {
		return updated;
	}
	public void setUpdated(Date updated) {
		this.updated = updated;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public Long getShopperidP() {
		return shopperidP;
	}
	public void setShopperidP(Long shopperidP) {
		this.shopperidP = shopperidP;
	}
	public String getShortname() {
		return shortname;
	}
	public void setShortname(String shortname) {
		this.shortname = shortname;
	}
	public String getLevels() {
		return levels;
	}
	public void setLevels(String levels) {
		this.levels = levels;
	}

}
