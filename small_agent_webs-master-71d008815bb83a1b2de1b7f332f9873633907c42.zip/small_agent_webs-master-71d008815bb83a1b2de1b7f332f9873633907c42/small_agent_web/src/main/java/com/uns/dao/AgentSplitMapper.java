package com.uns.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.AgentRatio;
import com.uns.model.AgentSplit;
import com.uns.web.form.AgentForm;

@Repository
public interface AgentSplitMapper {


	//public List<AgentSplit> findAgentSplit();
	
	public List<AgentSplit> findAgentSplit(AgentForm form);

	public List<Map> isSplitTmp(Long shopperid);

	public List<Map> isSplit(Long shopperid);

	public AgentSplit findAgentSplitTmp(Long shopperid);

	public AgentSplit findAgentSplit1(Long shopperid);
	
	

	public AgentSplit searchAgentSplitTmpCP(AgentSplit agentSplit);

	public AgentSplit searchAgentSplitTmpCP2(AgentSplit agentSplit);

	public List<AgentSplit> getAgentSplit(Map map);
	

	public void saveEAgentSplit(AgentSplit agentSplit);


	public void saveEAgentRatio(AgentRatio ratio);

	public void delESplitTmp(Long agentid);

	public void delEMccTmp(Long agentid);

	public void delERatioTmp(Long agentid);

	public void saveEAgentSplitTmp(AgentSplit agentSplit);


	public void saveEAgentRatioTmp(AgentRatio ratio);

	public AgentSplit getAgentSplitByAgentid(String shopperid);



	public AgentSplit searchAgentSplit(Long agentid);

	public Map getAgentSplitByShoperid(String shopperid);

	public Map getAgentSplitTmp(Long shopperid);


}
