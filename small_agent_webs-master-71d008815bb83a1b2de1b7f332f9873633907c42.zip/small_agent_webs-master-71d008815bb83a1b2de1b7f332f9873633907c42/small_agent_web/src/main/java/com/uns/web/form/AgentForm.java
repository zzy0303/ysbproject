package com.uns.web.form;

import java.util.Date;

import com.uns.model.Agent;

public class AgentForm extends Agent{
	private String agentid;
	private String agentname;
	private String agentstatus;
	private String belongsAgent;
	private String addStart;
	private String addEnd;
	private String shopperid_p;
	private Long currentid;
	private String shopperids;
	
	
	private String scompany;
	private String saddress;
	private String szip;
	private String srelation;
	private String semail;
	private String stel;
	private String sfax;
	private String scity;
	private String city;
	private String sprovince;
	private String province;
	private String remark;
	private String shortname;
	
	private Double max;
	private Double min;
	private Double fixamount;
	private Double t1fee;
	private Double t0fee;
	private Double t1top;
	private Double limit;
	private Double limitamount;
	
	private String loginname;
	private String agentpassword;
	
    private String transact;
    
	
	
	public String getTransact() {
		return transact;
	}
	public void setTransact(String transact) {
		this.transact = transact;
	}
	public String getScompany() {
		return scompany;
	}
	public void setScompany(String scompany) {
		this.scompany = scompany;
	}
	public String getSaddress() {
		return saddress;
	}
	public void setSaddress(String saddress) {
		this.saddress = saddress;
	}
	public String getSzip() {
		return szip;
	}
	public void setSzip(String szip) {
		this.szip = szip;
	}
	public String getSrelation() {
		return srelation;
	}
	public void setSrelation(String srelation) {
		this.srelation = srelation;
	}
	public String getSemail() {
		return semail;
	}
	public void setSemail(String semail) {
		this.semail = semail;
	}
	public String getStel() {
		return stel;
	}
	public void setStel(String stel) {
		this.stel = stel;
	}
	public String getSfax() {
		return sfax;
	}
	public void setSfax(String sfax) {
		this.sfax = sfax;
	}
	public String getScity() {
		return scity;
	}
	public void setScity(String scity) {
		this.scity = scity;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getSprovince() {
		return sprovince;
	}
	public void setSprovince(String sprovince) {
		this.sprovince = sprovince;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getShortname() {
		return shortname;
	}
	public void setShortname(String shortname) {
		this.shortname = shortname;
	}
	public Double getMax() {
		return max;
	}
	public void setMax(Double max) {
		this.max = max;
	}
	public Double getMin() {
		return min;
	}
	public void setMin(Double min) {
		this.min = min;
	}
	public Double getFixamount() {
		return fixamount;
	}
	public void setFixamount(Double fixamount) {
		this.fixamount = fixamount;
	}
	public Double getT1fee() {
		return t1fee;
	}
	public void setT1fee(Double t1fee) {
		this.t1fee = t1fee;
	}
	public Double getT0fee() {
		return t0fee;
	}
	public void setT0fee(Double t0fee) {
		this.t0fee = t0fee;
	}
	public Double getT1top() {
		return t1top;
	}
	public void setT1top(Double t1top) {
		this.t1top = t1top;
	}
	public Double getLimit() {
		return limit;
	}
	public void setLimit(Double limit) {
		this.limit = limit;
	}
	public Double getLimitamount() {
		return limitamount;
	}
	public void setLimitamount(Double limitamount) {
		this.limitamount = limitamount;
	}
	public String getLoginname() {
		return loginname;
	}
	public void setLoginname(String loginname) {
		this.loginname = loginname;
	}
	public String getAgentpassword() {
		return agentpassword;
	}
	public void setAgentpassword(String agentpassword) {
		this.agentpassword = agentpassword;
	}
	public String getShopperids() {
		return shopperids;
	}
	public void setShopperids(String shopperids) {
		this.shopperids = shopperids;
	}
	public Long getCurrentid() {
		return currentid;
	}
	public void setCurrentid(Long currentid) {
		this.currentid = currentid;
	}
	public String getShopperid_p() {
		return shopperid_p;
	}
	public void setShopperid_p(String shopperid_p) {
		this.shopperid_p = shopperid_p;
	}
	public String getAgentid() {
		return agentid;
	}
	public void setAgentid(String agentid) {
		this.agentid = agentid;
	}
	public String getAgentname() {
		return agentname;
	}
	public void setAgentname(String agentname) {
		this.agentname = agentname;
	}
	public String getAgentstatus() {
		return agentstatus;
	}
	public void setAgentstatus(String agentstatus) {
		this.agentstatus = agentstatus;
	}
	public String getBelongsAgent() {
		return belongsAgent;
	}
	public void setBelongsAgent(String belongsAgent) {
		this.belongsAgent = belongsAgent;
	}
	public String getAddStart() {
		return addStart;
	}
	public void setAddStart(String addStart) {
		this.addStart = addStart;
	}
	public String getAddEnd() {
		return addEnd;
	}
	public void setAddEnd(String addEnd) {
		this.addEnd = addEnd;
	}
	
}
