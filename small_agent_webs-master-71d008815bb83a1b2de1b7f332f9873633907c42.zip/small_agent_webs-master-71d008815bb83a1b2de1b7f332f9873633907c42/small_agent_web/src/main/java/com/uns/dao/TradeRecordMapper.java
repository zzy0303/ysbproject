package com.uns.dao;

import org.springframework.stereotype.Repository;

import com.uns.model.TradeRecord;
@Repository
public interface TradeRecordMapper {
	int deleteByPrimaryKey(String id);

    int insert(TradeRecord record);

    int insertSelective(TradeRecord record);

    TradeRecord selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TradeRecord record);

    int updateByPrimaryKey(TradeRecord record);
    
    int getMposOrderId();
}