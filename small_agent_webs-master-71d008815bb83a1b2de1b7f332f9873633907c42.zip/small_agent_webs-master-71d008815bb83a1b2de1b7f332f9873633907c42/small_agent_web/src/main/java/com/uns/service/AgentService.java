package com.uns.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.common.page.PageContext;
import com.uns.dao.AgentMapper;
import com.uns.dao.AgentOperatorMapper;
import com.uns.dao.UsersMapper;

import com.uns.dao.B2cShopperbiTempMapper;
import com.uns.model.Agent;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.Users;
import com.uns.web.form.AgentForm;

@Service
public class AgentService {
	
	@Autowired
	private AgentMapper agentMapper;
	
	@Autowired
	private AgentOperatorMapper agentOperatorMapper;
	@Autowired
	private B2cShopperbiTempMapper b2cShopperbiTempMapper;
	
	@Autowired
	private UsersMapper usermapper;
	
	private SimpleDateFormat format=new SimpleDateFormat(Constants.DEFAULT_DATE_FORMAT); 
	
	/**
	 * 查询服务商
	 * @param agent
	 * @return
	 * @throws ParseException 
	 */
	public List<Agent> queryAgentList(AgentForm agentForm) throws ParseException{
		PageContext.initPageSize(20);
		List<Agent> agentList = agentMapper.searchAgentList(agentForm);
		return agentList;
	}
	
	public List<Agent> selectAgentList(AgentForm agentForm) throws ParseException{
		PageContext.initPageSize(20);
		List<Agent> agentList = agentMapper.selectAgentList(agentForm);
		return agentList;
	}
	
	
	/**
	 * 查询商户
	 * @param shopperUser
	 * @return
	 * @throws ParseException 
	 */
	public B2cShopperbiTemp queryShopPerbi(String b2cShopperbiId)throws Exception {
		return b2cShopperbiTempMapper.selectByshopperId(Long.valueOf(b2cShopperbiId));
	}
	
	/**
	 * 查询服务商的信息
	 * @param agentid
	 * @return
	 * @throws ParseException 
	 */
	public Map queryAgentInfo(String agentid) throws ParseException{
		Map agentinfo = agentMapper.agentInfo(agentid);
		return agentinfo;
	}
	
	/**
	 * 查询服务商的信息根据手机号码
	 * @param agentid
	 * @return
	 * @throws ParseException 
	 */
	public Map queryAgentInfotel(String stel) throws ParseException{
		Map agentinfo = agentMapper.agentInfotel(stel);
		return agentinfo;
	}
	
	/**
	 * 查询服务商树
	 * @return
	 */
	public List<Agent> searchAgentTree(AgentForm agentForm){
		return agentMapper.searchAgentTree(agentForm);
	}
	
	public List<Agent> findAgentByMerchantId(String shopperbiid){
		return agentMapper.findAgentByMerchantId(shopperbiid);
	}
	
	public void updateUser(Users agentUser){
		agentOperatorMapper.updateOperator(agentUser);
	}
	
	public Agent searchAgentById(String id) {
		return agentMapper.searchAgentById(id);
	}
	
	public Agent searchAgentByShopperId(String shopperId) {
		return agentMapper.searchAgentByShopperid(shopperId);
	}
	public Agent findAgentbyParam(String agentNo) {
		return agentMapper.findAgentbyParam(agentNo);
	}
	public Agent searchAgentByName(String scompany) {
		return agentMapper.searchAgentByName(scompany);
	}
	
	public Long searchUserByNameAndShopperid(Map params){
		return agentMapper.searchUserByNameAndShopperid(params);
	}
	public void updateAgent(Agent agent){
		agentMapper.updateAgent(agent);
	}
	/**服务商地图
	 * @param merchantId
	 * @return
	 */
	public List findAgentByMerchantIdMap(String merchantId) {
		return agentMapper.findAgentByMerchantIdMap(merchantId);
	}
	public List updateAgentByMerchantId(String merchantId, String shopperid) {
		Map map=new HashMap();
		map.put("merchantId", Long.valueOf(merchantId));
		map.put("shopperid", Long.valueOf(shopperid));
		return agentMapper.updateAgentByMerchantId(map);
	}
	
	public Agent findbyshopperidp(String shopperidp){
		return agentMapper.findbyshopperidp(shopperidp);
	}
	
	
	public Agent findbytel(String tel){
		List list=agentMapper.findbytel(tel);
  		Agent agent=null;
		if(list!=null&&list.size()>0){
			agent=(Agent)list.get(0);
		}
		return agent;
	}
	
	public void updateuseragent(Users users,Agent agent, Users sessionUser){
		//判断有没有修改费率,如果修改了费率，需要在保存修改日志
		Map<String, Object> param = new HashMap<String, Object>();
		Agent a = agentMapper.searchAgentByShopperid(String.valueOf(agent.getShopperid()));
		boolean flag = false;
	/*	if(!agent.getSkDebitFee().equals(a.getSkDebitFee())){
			flag = true;
			param.put("skDebitFee", agent.getSkDebitFee());
		}
		if(!agent.getSkCreditFee().equals(a.getSkCreditFee())){
			flag = true;
			param.put("skCreditFee", agent.getSkCreditFee());
		}
		if(!agent.getD0Fee().equals(a.getD0Fee())){
			flag = true;
			param.put("d0Fee", agent.getD0Fee());
		}*/
		if(!agent.getSmWechatD0Fee().equals(a.getSmWechatD0Fee())){
			flag = true;
			param.put("smWechatD0Fee", agent.getSmWechatD0Fee());
		}
		if(!agent.getSmWechatT1Fee().equals(a.getSmWechatT1Fee())){
			flag = true;
			param.put("smWechatT1Fee", agent.getSmWechatT1Fee());
		}
		if(!agent.getSmAlipayD0Fee().equals(a.getSmAlipayD0Fee())){
			flag = true;
			param.put("smAlipayD0Fee", agent.getSmAlipayD0Fee());
		}
		if(!agent.getSmAlipayT1Fee().equals(a.getSmAlipayT1Fee())){
			flag = true;
			param.put("smAlipayT1Fee", agent.getSmAlipayT1Fee());
		}
		if(!agent.getSmYlzfT1Fee().equals(a.getSmYlzfT1Fee())){
			flag = true;
			param.put("smYlzfT1Fee", agent.getSmYlzfT1Fee());
		}
		if(!agent.getSmYlzfD0Fee().equals(a.getSmYlzfD0Fee())){
			flag = true;
			param.put("smYlzfD0Fee", agent.getSmYlzfD0Fee());
		}
		if(!agent.getSkSecondFee().equals(a.getSkSecondFee())){
			flag = true;
			param.put("skSecondFee", agent.getSkSecondFee());
		}
		
		if(!agent.getSkImmediateFee().equals(a.getSkImmediateFee())){
			flag = true;
			param.put("skImmediateFee", agent.getSkImmediateFee());
		}
		
		if(!agent.getSkT1Fee().equals(a.getSkT1Fee())){
			flag = true;
			param.put("skT1Fee", agent.getSkT1Fee());
		}
		//无卡费率是否有去修改
		if(!agent.getSmShortCutT1Fee().equals(a.getSmShortCutT1Fee())){
			flag = true;
			param.put("smShortCutT1Fee", agent.getSmShortCutT1Fee());
		}
		if(!agent.getSmShortCutD0Fee().equals(a.getSmShortCutD0Fee())){
			flag = true;
			param.put("smShortCutD0Fee", agent.getSmShortCutD0Fee());
		}

		//是否有速惠收款费率
		if(!agent.getSmShortCutSHD0Fee().equals(a.getSmShortCutSHD0Fee())){
			flag = true;
			param.put("smShortCutSHD0Fee", agent.getSmShortCutSHD0Fee());
		}
		if(!agent.getSmB2cT1Fee().equals(a.getSmB2cT1Fee())){
			flag = true;
			param.put("smB2cT1Fee", agent.getSmB2cT1Fee());
		}
		if(!agent.getSmB2cD0Fee().equals(a.getSmB2cD0Fee())){
			flag = true;
			param.put("smB2cD0Fee", agent.getSmB2cD0Fee());
		}
		if(flag){
			param.put("createDate", new Date());
			param.put("updateUser", a.getShopperidP());
			param.put("shopperid", a.getShopperid());
			param.put("updateScompany", sessionUser.getUserName() );
			agentMapper.insertUpdateAgentfeeAlog(param);
		}
		
		agentMapper.updateAgent(agent);
		users.setIsAgent(Short.valueOf(Constants.CON_YES));
		usermapper.updateByUsresId(users);
	}
	
	public List<Map<String,Object>> selectUpdateAgentfeeAlogList(String shopperid){
		PageContext.initPageSize(20);
		return agentMapper.selectUpdateAgentfeeAlogList(shopperid);
	}

	public List findAgentTopFee() {
		return agentMapper.findAgentTopFee();
	}

	public List findAgentByScompay(String shopperId, String scompay) {
		Map map=new HashMap();
		map.put("shopperId", shopperId);
		map.put("scompay", scompay);
		return agentMapper.findAgentByScompay(map);
	}

	public List findAgentTopFeeList() {
		return agentMapper.findAgentTopFeeList();
	}

	public List findAgentTopFeeByType(String type) {
		return agentMapper.findAgentTopFeeByType(type);
	}
	
	/**
	 * 库存管理终端出库用到的树结构 
	 * @param shopperId
	 * @return
	 */
	public List<Agent>findAgentForTermOutTree(String shopperId){
		return this.agentMapper.findAgentForTermOutTree(shopperId);
	}

	public Agent findAgentByShopperid(String currentAgentNo) {
		return  this.agentMapper.findAgentByShopperid(currentAgentNo);
	}

}	
