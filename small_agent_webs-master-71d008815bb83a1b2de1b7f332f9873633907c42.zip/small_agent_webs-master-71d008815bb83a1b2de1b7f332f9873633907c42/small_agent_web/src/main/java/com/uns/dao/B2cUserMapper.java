package com.uns.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.B2cUser;
@Repository
public interface B2cUserMapper {
	/**
	 * 商户签约销售，商户客户经理
	 */
	List<B2cUser> selectB2cUserList();

	B2cUser selectB2cUserById(Long writeoperid);
}