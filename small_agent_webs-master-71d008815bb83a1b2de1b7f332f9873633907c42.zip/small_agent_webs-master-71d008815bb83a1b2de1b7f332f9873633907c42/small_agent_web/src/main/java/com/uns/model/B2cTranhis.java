package com.uns.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class B2cTranhis implements Serializable {
    
	private static final long serialVersionUID = 1L;

	// 商户
	private B2cShopperbi shopperbi; 
	
	// 终端
	private B2cTerminal terminal;
	
	// 增加字段
	private String scompany;
	private String num;
	
	// 字段
	private String tranid;

    private String terminalid;

    private String merchantid;

    private String oldtranid;

    private String cardno;

    private String cardid;

    private String enryptcard;

    private Long amount;

    private Long reamount;

    private Long batchnumber;

    private String trannumber;

    private String rrn;

    private String trandate;

    private String trantime;

    private String localdate;

    private String localtime;

    private String trantype;

    private String tranflag;

    private String bankdate;

    private String returncode;

    private String authno;

    private String settleflag;

    private BigDecimal bankfee;

    private String operatorid;

    private String cardexp;

    private String type;

    private String nodeid;

    private String bizid;

    private String name;

    private String certificate;

    private String phone;

    private String version;

    private String note;

    private String bizinfo;

    private String banktime;

    private String bankmerchant;

    private String bankterminal;

    private String opflag;

    private String cboperatorid;

    private String reason;

    private String pjcode;

    private String certificateType;

    private String apiLanguage;

    private String apiVersion;

    private String apiType;

    private String updatetime;

    private String updatedate;

    private String serviceType;

    private String risknote;

    private String bankbatch;

    private String bankcode;

    private String tradeflag;

    private String refuseflag;

    private String cvv;

    private String settletime;

    private String orgcode;

    public String getTranid() {
        return tranid;
    }

    public void setTranid(String tranid) {
        this.tranid = tranid;
    }

    public String getTerminalid() {
        return terminalid;
    }

    public void setTerminalid(String terminalid) {
        this.terminalid = terminalid;
    }

    public String getMerchantid() {
        return merchantid;
    }

    public void setMerchantid(String merchantid) {
        this.merchantid = merchantid;
    }

    public String getOldtranid() {
        return oldtranid;
    }

    public void setOldtranid(String oldtranid) {
        this.oldtranid = oldtranid;
    }

    public String getCardno() {
        return cardno;
    }

    public void setCardno(String cardno) {
        this.cardno = cardno;
    }

    public String getCardid() {
        return cardid;
    }

    public void setCardid(String cardid) {
        this.cardid = cardid;
    }

    public String getEnryptcard() {
        return enryptcard;
    }

    public void setEnryptcard(String enryptcard) {
        this.enryptcard = enryptcard;
    }

    public Long getAmount() {
        return amount;
    }

    public void setAmount(Long amount) {
        this.amount = amount;
    }

    public Long getReamount() {
        return reamount;
    }

    public void setReamount(Long reamount) {
        this.reamount = reamount;
    }

    public Long getBatchnumber() {
		return batchnumber;
	}

	public void setBatchnumber(Long batchnumber) {
		this.batchnumber = batchnumber;
	}

	public String getTrannumber() {
        return trannumber;
    }

    public void setTrannumber(String trannumber) {
        this.trannumber = trannumber;
    }

    public String getRrn() {
        return rrn;
    }

    public void setRrn(String rrn) {
        this.rrn = rrn;
    }

    public String getTrandate() {
        return trandate;
    }

    public void setTrandate(String trandate) {
        this.trandate = trandate;
    }

    public String getTrantime() {
        return trantime;
    }

    public void setTrantime(String trantime) {
        this.trantime = trantime;
    }

    public String getLocaldate() {
        return localdate;
    }

    public void setLocaldate(String localdate) {
        this.localdate = localdate;
    }

    public String getLocaltime() {
        return localtime;
    }

    public void setLocaltime(String localtime) {
        this.localtime = localtime;
    }

    public String getTrantype() {
        return trantype;
    }

    public void setTrantype(String trantype) {
        this.trantype = trantype;
    }

    public String getTranflag() {
        return tranflag;
    }

    public void setTranflag(String tranflag) {
        this.tranflag = tranflag;
    }

    public String getBankdate() {
        return bankdate;
    }

    public void setBankdate(String bankdate) {
        this.bankdate = bankdate;
    }

    public String getReturncode() {
        return returncode;
    }

    public void setReturncode(String returncode) {
        this.returncode = returncode;
    }

    public String getAuthno() {
        return authno;
    }

    public void setAuthno(String authno) {
        this.authno = authno;
    }

    public String getSettleflag() {
        return settleflag;
    }

    public void setSettleflag(String settleflag) {
        this.settleflag = settleflag;
    }

    public BigDecimal getBankfee() {
        return bankfee;
    }

    public void setBankfee(BigDecimal bankfee) {
        this.bankfee = bankfee;
    }

    public String getOperatorid() {
        return operatorid;
    }

    public void setOperatorid(String operatorid) {
        this.operatorid = operatorid;
    }

    public String getCardexp() {
        return cardexp;
    }

    public void setCardexp(String cardexp) {
        this.cardexp = cardexp;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getNodeid() {
        return nodeid;
    }

    public void setNodeid(String nodeid) {
        this.nodeid = nodeid;
    }

    public String getBizid() {
        return bizid;
    }

    public void setBizid(String bizid) {
        this.bizid = bizid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCertificate() {
        return certificate;
    }

    public void setCertificate(String certificate) {
        this.certificate = certificate;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getBizinfo() {
        return bizinfo;
    }

    public void setBizinfo(String bizinfo) {
        this.bizinfo = bizinfo;
    }

    public String getBanktime() {
        return banktime;
    }

    public void setBanktime(String banktime) {
        this.banktime = banktime;
    }

    public String getBankmerchant() {
        return bankmerchant;
    }

    public void setBankmerchant(String bankmerchant) {
        this.bankmerchant = bankmerchant;
    }

    public String getBankterminal() {
        return bankterminal;
    }

    public void setBankterminal(String bankterminal) {
        this.bankterminal = bankterminal;
    }

    public String getOpflag() {
        return opflag;
    }

    public void setOpflag(String opflag) {
        this.opflag = opflag;
    }

    public String getCboperatorid() {
        return cboperatorid;
    }

    public void setCboperatorid(String cboperatorid) {
        this.cboperatorid = cboperatorid;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getPjcode() {
        return pjcode;
    }

    public void setPjcode(String pjcode) {
        this.pjcode = pjcode;
    }

    public String getCertificateType() {
        return certificateType;
    }

    public void setCertificateType(String certificateType) {
        this.certificateType = certificateType;
    }

    public String getApiLanguage() {
        return apiLanguage;
    }

    public void setApiLanguage(String apiLanguage) {
        this.apiLanguage = apiLanguage;
    }

    public String getApiVersion() {
        return apiVersion;
    }

    public void setApiVersion(String apiVersion) {
        this.apiVersion = apiVersion;
    }

    public String getApiType() {
        return apiType;
    }

    public void setApiType(String apiType) {
        this.apiType = apiType;
    }

    public String getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(String updatetime) {
        this.updatetime = updatetime;
    }

    public String getUpdatedate() {
        return updatedate;
    }

    public void setUpdatedate(String updatedate) {
        this.updatedate = updatedate;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public String getRisknote() {
        return risknote;
    }

    public void setRisknote(String risknote) {
        this.risknote = risknote;
    }

    public String getBankbatch() {
        return bankbatch;
    }

    public void setBankbatch(String bankbatch) {
        this.bankbatch = bankbatch;
    }

    public String getBankcode() {
        return bankcode;
    }

    public void setBankcode(String bankcode) {
        this.bankcode = bankcode;
    }

    public String getTradeflag() {
        return tradeflag;
    }

    public void setTradeflag(String tradeflag) {
        this.tradeflag = tradeflag;
    }

    public String getRefuseflag() {
        return refuseflag;
    }

    public void setRefuseflag(String refuseflag) {
        this.refuseflag = refuseflag;
    }

    public String getCvv() {
        return cvv;
    }

    public void setCvv(String cvv) {
        this.cvv = cvv;
    }

    public String getSettletime() {
        return settletime;
    }

    public void setSettletime(String settletime) {
        this.settletime = settletime;
    }

    public String getOrgcode() {
        return orgcode;
    }

    public void setOrgcode(String orgcode) {
        this.orgcode = orgcode;
    }

	public B2cShopperbi getShopperbi() {
		return shopperbi;
	}

	public void setShopperbi(B2cShopperbi shopperbi) {
		this.shopperbi = shopperbi;
	}

	public String getScompany() {
		return scompany;
	}

	public void setScompany(String scompany) {
		this.scompany = scompany;
	}

	public B2cTerminal getTerminal() {
		return terminal;
	}

	public void setTerminal(B2cTerminal terminal) {
		this.terminal = terminal;
	}

	public String getNum() {
		return num;
	}

	public void setNum(String num) {
		this.num = num;
	}
	
	
}