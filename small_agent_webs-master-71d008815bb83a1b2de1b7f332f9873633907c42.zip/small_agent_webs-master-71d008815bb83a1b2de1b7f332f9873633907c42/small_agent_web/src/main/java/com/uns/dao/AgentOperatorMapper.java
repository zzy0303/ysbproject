package com.uns.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.Users;
import com.uns.web.form.AgentUserForm;

@Repository
public interface AgentOperatorMapper {
	/**
	 * 操作员修改
	 * @param user
	 */
	public void updateOperator(Users agentUser);
	
	public List<Users> findOperatorList(AgentUserForm form);
	
	public void deleteOperator(String userCode);
	
	public List findOperatorByCode(Map map);
	
	public void updateUserByCode(Map params);
	
	public void addOperator(Map params);
	
	public  List<Users> selectByUsersName(String userName);
	
	public Users selectByUsersIds(String shopperId);
	
	public Users findOperatorByShopperid(Long merchantId);

	public void updateUserByMerchantId(Users user);

	/**查询操作员记录
	 * @param mbForm
	 * @return
	 */
	public List selectByUsersList(AgentUserForm mbForm)throws Exception;

	/**根据id查询记录
	 * @param userId
	 * @return
	 */
	public Users selectUsersById(Long userId)throws Exception;

	public void update(Users user)throws Exception;

	/**根据商户编号，用户名查询记录
	 * @param map
	 * @return
	 */
	public Users findUsersByParam(HashMap map);
	
	public List findOperatorByCodetel(Map map);
	
}
