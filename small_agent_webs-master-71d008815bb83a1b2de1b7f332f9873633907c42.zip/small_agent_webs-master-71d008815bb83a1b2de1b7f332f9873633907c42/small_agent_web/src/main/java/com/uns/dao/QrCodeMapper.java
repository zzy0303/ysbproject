package com.uns.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;
@Repository
public interface QrCodeMapper {

	//根据shopperid查询QRPAYNO,QRPAY_MERCHANT_KEY
	Map<String, Object> queryQrCodeInfoByShopperId(String shopperid);

}
