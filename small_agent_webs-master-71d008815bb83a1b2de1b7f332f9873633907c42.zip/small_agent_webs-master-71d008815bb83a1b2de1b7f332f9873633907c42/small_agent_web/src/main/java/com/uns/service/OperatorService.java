package com.uns.service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.uns.bean.PageBean;
import com.uns.common.page.PageContext;
import com.uns.dao.OperatorMapper;
import com.uns.dao.RoleMerInfoMapper;
import com.uns.dao.UsersMapper;
import com.uns.model.Operator;
import com.uns.model.RoleMerInfo;
import com.uns.model.Users;
import com.uns.web.form.AgentUserForm;
@Service
public class OperatorService {
	@Autowired
	private OperatorMapper operatorMapper;
	
	@Autowired
	private UsersMapper usersMapper;
	
	@Autowired
	private RoleMerInfoMapper roleMerInfoMapper;
	
	//判断是否有重复的userName
	public List selectByUsersName(String userName) throws Exception {
		List<Users>  Users= usersMapper.selectByUsesrName(userName);
		return Users;
	}
	/**查询角色 
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public List<RoleMerInfo> selectRoleList(){
		List<RoleMerInfo> list=roleMerInfoMapper.selectByRoleInfo();
		return list;
	}
	/**查询users 
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public Users selectUser(String id,String userName){
		Map map=new HashMap();
		map.put("id", id);
		map.put("userName", userName);
		Users users=usersMapper.selectByNameMap(map);
		return users;
	}
	/**修改操作员密码
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public void updateUserPwd(Users users){
		usersMapper.updateByUsresId(users);
	}
	/**登录
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public Users findOperatorByCode(String userName) throws Exception {
		List<Users> agentUser = (List<Users>)usersMapper.selectByUsesrName(userName);
		if(agentUser!=null&&agentUser.size()>0){
			return agentUser.get(0);
		}
		return null;
		
	}
	
	/**操作员页面
	 * @param form
	 * @param curPage
	 * @return
	 */
	public PageBean getOperatorList(AgentUserForm form, int curPage) {
		PageContext.initPageSize(20);
		List<Operator> operatorList = operatorMapper.findOperatorList(form);
		PageBean pageBean = new PageBean();
		pageBean.setData(operatorList);
		pageBean.setCurPage(curPage);
		pageBean.setTotalCount(operatorList.size());
		pageBean.setLength(20);
		pageBean.setTotalPage(operatorList.size() / 20 + 1);
		return pageBean;
	}
	/**修改登录时间
	 * @param agentUser
	 */
	public void updateOperator(Operator agentUser) {
		operatorMapper.updateOperator(agentUser);
	}
	/**删除操作员
	 * @param usercode
	 */
	public void deleteOperator(String usercode) {
		operatorMapper.deleteOperator(usercode);
	}
	
	public void updateUserByCode(Map params) {
		operatorMapper.updateUserByCode(params);
	}

	public void addOperator(Map params) {
		operatorMapper.addOperator(params);
	}
	
	public Operator findUserByShopperid(Long merchantid){
		return operatorMapper.findOperatorByShopperid(merchantid);
	}

	public void updateUserByMerchantId(Operator user) {
		operatorMapper.updateUserByMerchantId(user);
	}


	/**查询用户信息
	 * @param mbForm
	 * @return
	 */
	public List selectUsersList(AgentUserForm mbForm)throws Exception {
		PageContext.initPageSize(20);
		return operatorMapper.selectByUsersList(mbForm);
	}


	public Operator selectUsersById(Long userId) throws Exception {
		return operatorMapper.selectUsersById(userId);
	}


	public void update(Operator user) throws Exception {
		operatorMapper.update(user);
	}
	
	public void insert(Operator record) throws Exception{
		operatorMapper.insert(record);
	}
	/*
	 * 
	 * 添加新操作员
	 */
	public void insertUsers(Users users) throws Exception{
		usersMapper.insert(users);
	}
	
	public Users selectUserById(String id) throws Exception {
		return usersMapper.selectByPrimaryId(id);
	}
	public void updateUserById(Users users) throws Exception {
		usersMapper.updateByPrimaryKey(users);
	}
	
	public void removeOperator(BigDecimal id){
		operatorMapper.deleteByPrimaryKey(id);
	}

	public Map getOperaterByUserName(String userName) {
		return operatorMapper.getOperaterByUserName(userName);
	}
}
