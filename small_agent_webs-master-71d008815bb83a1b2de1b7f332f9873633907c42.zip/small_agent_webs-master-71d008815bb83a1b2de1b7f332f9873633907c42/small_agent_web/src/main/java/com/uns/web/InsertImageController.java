package com.uns.web;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.dao.ImageMapper;
import com.uns.model.Image;
import com.uns.model.MposPhotoTmp;
import com.uns.service.ImageService;
import com.uns.service.PhotoService;
import com.uns.util.StringUtils;

@Controller
@RequestMapping(value = "/insertimagecontroller.htm")
public class InsertImageController extends BaseController {
	@Autowired
	private ImageService imageService;

	@Autowired
	private PhotoService photoservice;

	@RequestMapping(params = "method=insertimage")
	public void insertimage(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Map hashMap = new HashMap();
		try {
			String handIdentity = request.getParameter("handIdentity");
			String frontIdentity = request.getParameter("frontIdentity");
			String reverseIdentity = request.getParameter("reverseIdentity");
			String storePhoto = request.getParameter("storePhoto");
			String licensePhoto = request.getParameter("licensePhoto");
			String instorePhoto = request.getParameter("instorePhoto");
			String checkstandPhoto = request.getParameter("checkstandPhoto");
			String signaturePhoto = request.getParameter("signaturePhoto");
			String creditCardPhoto = request.getParameter("creditCardPhoto");
			String settlementCardPhoto = request.getParameter("settlementCardPhoto");

			Map handIdentity1 = com.uns.util.JsonUtil.jsonStrToMap(handIdentity);
			Map frontIdentity1 = com.uns.util.JsonUtil.jsonStrToMap(frontIdentity);
			Map reverseIdentity1 = com.uns.util.JsonUtil.jsonStrToMap(reverseIdentity);
			Map storePhoto1 = com.uns.util.JsonUtil.jsonStrToMap(storePhoto);
			Map licensePhoto1 = com.uns.util.JsonUtil.jsonStrToMap(licensePhoto);
			Map instorePhoto1 = com.uns.util.JsonUtil.jsonStrToMap(instorePhoto);
			Map checkstandPhoto1 = com.uns.util.JsonUtil.jsonStrToMap(checkstandPhoto);
			Map signaturePhoto1 = com.uns.util.JsonUtil.jsonStrToMap(signaturePhoto);
			Map creditCardPhoto1 = com.uns.util.JsonUtil.jsonStrToMap(creditCardPhoto);
			Map settlementCardPhoto1 = com.uns.util.JsonUtil.jsonStrToMap(settlementCardPhoto);
			String identityId = (String) signaturePhoto1.get("identityId");

			MposPhotoTmp photo = new MposPhotoTmp();
			// 签名 1
			if (signaturePhoto1 != null) {
				String signaturePhotoph = insertphototemp(signaturePhoto1);
				photo.setSignaturePhoto(signaturePhotoph);
			}

			// 手持 2
			if (handIdentity1 != null) {
				String handIdentityph = insertphototemp(handIdentity1);
				photo.setHandIdentityCardPhoto(handIdentityph);
			}
			// 正面 3
			if (frontIdentity1 != null) {
				String frontIdentityph = insertphototemp(frontIdentity1);
				photo.setFrontIdentityCardPhoto(frontIdentityph);
			}
			// 反面 4
			if (reverseIdentity1 != null) {
				String reverseIdentityph = insertphototemp(reverseIdentity1);
				photo.setReverseIdentityCardPhoto(reverseIdentityph);
			}

			// 门面 5
			if (storePhoto1 != null) {
				String storePhotoph = insertphototemp(storePhoto1);
				photo.setStorePhoto(storePhotoph);
			}

			// 收银台照片 6
			if (checkstandPhoto1 != null) {
				String checkstandPhotoph = insertphototemp(checkstandPhoto1);
				photo.setCheckstandPhoto(checkstandPhotoph);
			}
			// 执照 7
			if (licensePhoto1 != null) {
				String licensePhotoph = insertphototemp(licensePhoto1);
				photo.setLicensePhoto(licensePhotoph);
			}
			// 门店内 8
			if (instorePhoto1 != null) {
				String instorePhotoph = insertphototemp(instorePhoto1);
				photo.setInstorePhoto(instorePhotoph);
			}
			// 信用卡 9
			if (creditCardPhoto1 != null) {
				String creditCardPhotop = insertphototemp(creditCardPhoto1);// 信用卡照片
				photo.setCreditCardPhoto(creditCardPhotop);
			}
			// 结算银行卡 10
			if (settlementCardPhoto1 != null) {
				String settlementCardPhotop = insertphototemp(settlementCardPhoto1);// 信用卡照片
				photo.setSettlementCardPhoto(settlementCardPhotop);
			}

			photo.setCheckFlag(Constants.STATUS0);
			photo.setIdentityid(identityId);
			photoservice.insertphoto(photo);

			hashMap.put("returnCode", "0000");
			hashMap.put("msg", "照片上传成功");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("照片上传成功:" + json.toString());
			response.getWriter().write(json.toString());
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("returnCode", "2222");
			hashMap.put("msg", "照片上传失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("照片上传:" + json.toString());
			response.getWriter().write(json.toString());
		}

	}



	@RequestMapping(params = "method=updateimage")
	public void updateimage(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Map hashMap = new HashMap();
		try {
			String handIdentity = request.getParameter("handIdentity");
			String frontIdentity = request.getParameter("frontIdentity");
			String reverseIdentity = request.getParameter("reverseIdentity");
			String storePhoto = request.getParameter("storePhoto");
			String licensePhoto = request.getParameter("licensePhoto");
			String instorePhoto = request.getParameter("instorePhoto");
			String checkstandPhoto = request.getParameter("checkstandPhoto");
			String signaturePhoto = request.getParameter("signaturePhoto");
			String creditCardPhoto = request.getParameter("creditCardPhoto");
			String settlementCardPhoto = request.getParameter("settlementCardPhoto");
			
			String  hand=request.getParameter("hand");
			String  front=request.getParameter("front");
			String  rever=request.getParameter("rever");
			String  store=request.getParameter("store");
			String  licen=request.getParameter("licen");
			String  instore=request.getParameter("instore");
			String  sign=request.getParameter("sign");
			String  credit=request.getParameter("credit");
			String  settle=request.getParameter("settle");
			

			Map handIdentity1 = com.uns.util.JsonUtil.jsonStrToMap(handIdentity);
			Map frontIdentity1 = com.uns.util.JsonUtil.jsonStrToMap(frontIdentity);
			Map reverseIdentity1 = com.uns.util.JsonUtil.jsonStrToMap(reverseIdentity);
			Map storePhoto1 = com.uns.util.JsonUtil.jsonStrToMap(storePhoto);
			Map licensePhoto1 = com.uns.util.JsonUtil.jsonStrToMap(licensePhoto);
			Map instorePhoto1 = com.uns.util.JsonUtil.jsonStrToMap(instorePhoto);
			Map checkstandPhoto1 = com.uns.util.JsonUtil.jsonStrToMap(checkstandPhoto);
			Map signaturePhoto1 = com.uns.util.JsonUtil.jsonStrToMap(signaturePhoto);
			Map creditCardPhoto1 = com.uns.util.JsonUtil.jsonStrToMap(creditCardPhoto);
			Map settlementCardPhoto1 = com.uns.util.JsonUtil.jsonStrToMap(settlementCardPhoto);
			
			String photoid = (String) signaturePhoto1.get("photoid");
			MposPhotoTmp photo1 = photoservice.findbyphotoid(photoid);
			MposPhotoTmp photo=new  MposPhotoTmp();
			
			photo.setPhotoId(Long.parseLong(photoid));
//			Map maphoto=new HashMap();
			// 签名 1
			if (sign != null&&org.apache.commons.lang3.StringUtils.isNotEmpty(sign)) {
				String signaturePhotoph = insertphototemp(signaturePhoto1);
				photo.setSignaturePhoto(signaturePhotoph);
				//maphoto.put("signaturePhotoph", signaturePhotoph);
			}

			// 手持 2
			if (hand != null&&org.apache.commons.lang3.StringUtils.isNotEmpty(hand)) {
				String handIdentityph = updatephototemp(handIdentity1);
				photo.setHandIdentityCardPhoto(handIdentityph);
				//maphoto.put("handIdentityph", handIdentityph);
			}
			// 正面 3
			if (front != null&&org.apache.commons.lang3.StringUtils.isNotEmpty(front)) {
				String frontIdentityph = updatephototemp(frontIdentity1);
				photo.setFrontIdentityCardPhoto(frontIdentityph);
				//maphoto.put("frontIdentityph", frontIdentityph);
			}
			// 反面 4
			if (rever != null&&org.apache.commons.lang3.StringUtils.isNotEmpty(rever)) {
				String reverseIdentityph = updatephototemp(reverseIdentity1);
				photo.setReverseIdentityCardPhoto(reverseIdentityph);
				//maphoto.put("reverseIdentityph", reverseIdentityph);
			}

			// 门面 5
			if (store!= null&&org.apache.commons.lang3.StringUtils.isNotEmpty(store)) {
				String storePhotoph = updatephototemp(storePhoto1);
				photo.setStorePhoto(storePhotoph);
				//maphoto.put("storePhotoph", storePhotoph);
			}

			/*// 收银台照片 6
			if (check= null) {
				String checkstandPhotoph = insertphototemp(checkstandPhoto1);
				//photo.setCheckstandPhoto(checkstandPhotoph);
				
				maphoto.put("checkstandPhotoph", checkstandPhotoph);
			}*/
			// 执照 7
			if (licen != null&&org.apache.commons.lang3.StringUtils.isNotEmpty(licen)) {
				String licensePhotoph = updatephototemp(licensePhoto1);
				photo.setLicensePhoto(licensePhotoph);
				//maphoto.put("licensePhotoph", licensePhotoph);
			}
			// 门店内 8
			if (instore!= null&&org.apache.commons.lang3.StringUtils.isNotEmpty(instore)) {
				String instorePhotoph = updatephototemp(instorePhoto1);
				photo.setInstorePhoto(instorePhotoph);
				//maphoto.put("instorePhotoph",instorePhotoph);
			}
			// 信用卡 9
			if (credit != null&&org.apache.commons.lang3.StringUtils.isNotEmpty(credit)) {
				String creditCardPhotop = updatephototemp(creditCardPhoto1);// 信用卡照片
				photo.setCreditCardPhoto(creditCardPhotop);
				//maphoto.put("creditCardPhotop", creditCardPhotop);
			}
			// 结算银行卡 10
			if (settle!= null&&org.apache.commons.lang3.StringUtils.isNotEmpty(settle)) {
				String settlementCardPhotop = insertphototemp(settlementCardPhoto1);// 信用卡照片
				photo.setSettlementCardPhoto(settlementCardPhotop);
				//maphoto.put("settlementCardPhotop", settlementCardPhotop);
			}
			if(photo1!=null){
				photoservice.updatephoto(photo);
			}else{
				photoservice.inserOrUpdatetphoto(photo,photoid);
			}
			
			hashMap.put("returnCode", "0000");
			hashMap.put("maphoto", photo);
			hashMap.put("msg", "照片上传成功");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("照片上传成功:" + json.toString());
			response.getWriter().write(json.toString());
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("returnCode", "2222");
			hashMap.put("msg", "照片上传失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("照片上传失败:" + json.toString());
			response.getWriter().write(json.toString());
		}
	}
	
	
	public String insertphototemp(Map hasmap) throws Exception {
		String targetFileName = (String) hasmap.get("targetFileName");

		String imagepath = (String) hasmap.get("imagepath");
		String moduleName = (String) hasmap.get("moduleName");
		String imageFrom = (String) hasmap.get("imageFrom");
		String identityId = (String) hasmap.get("identityId");
		String photoname = (String) hasmap.get("photoname");

		/*MposPhotoTmp photo = this.photoservice.findbsid(identityId);
		if (photo != null) {
			this.photoservice.delphoto(identityId);
		}*/
		Image image = new Image();
		image.setImageName(targetFileName);
		image.setImagePath(imagepath);
		image.setModuleName(moduleName);
		image.setCreateDate(new Date());
		image.setUpdateDate(new Date());
		image.setImageFrom(imageFrom);
		imageService.insertSelective(image);
		Image image1 = imageService.getImageByName(targetFileName);
		String uuid = image1.getUuid().toString();
		return uuid;

	}
	
	
	
	
	
	public String updatephototemp(Map hasmap) throws Exception {
		String targetFileName = (String) hasmap.get("targetFileName");

		String imagepath = (String) hasmap.get("imagepath");
		String moduleName = (String) hasmap.get("moduleName");
		String imageFrom = (String) hasmap.get("imageFrom");
		String identityId = (String) hasmap.get("identityId");
		String photoname = (String) hasmap.get("photoname");

		/*MposPhotoTmp photo = this.photoservice.findbsid(identityId);
		if (photo != null) {
			this.photoservice.delphoto(identityId);
		}*/
		Image image = new Image();
		image.setImageName(targetFileName);
		image.setImagePath(imagepath);
		image.setModuleName(moduleName);
		image.setCreateDate(new Date());
		image.setUpdateDate(new Date());
		image.setImageFrom(imageFrom);
		imageService.insertSelective(image);
		Image image1 = imageService.getImageByName(targetFileName);
		String uuid = image1.getUuid().toString();
		return uuid;

	}

}
