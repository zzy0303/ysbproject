package com.uns.model;

import java.util.Date;

public class Users {
	private Long id;
	private Date createdate;
	private Long merchantid;
	private String usercode;
	private String password;
	private String userName;
	private Date lastlogindate;
	private short enabled;
	private Long results;
	private Long attempttimes;
	private Long locked;
	private String permits;
	private String demo;
	private String roledesc;
	private Long subsidiarid;
	private Short isAgent;
	private String loginname;
	private String tel;
	
	
	
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getLoginname() {
		return loginname;
	}
	public void setLoginname(String loginname) {
		this.loginname = loginname;
	}
	public Short getIsAgent() {
		return isAgent;
	}
	public void setIsAgent(Short isAgent) {
		this.isAgent = isAgent;
	}
	public void setRoledesc(String roledesc) {
		this.roledesc = roledesc;
	}
	public Long getSubsidiarid() {
		return subsidiarid;
	}
	public void setSubsidiarid(Long subsidiarid) {
		this.subsidiarid = subsidiarid;
	}
	public String getDemo() {
		return demo;
	}
	public void setDemo(String demo) {
		this.demo = demo;
	}
	public String getRoledesc() {
		return roledesc;
	}
	public void setRoleDesc(String roledesc) {
		this.roledesc = roledesc;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}

	public Date getCreatedate() {
		return createdate;
	}
	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}
	public Long getMerchantid() {
		return merchantid;
	}
	public void setMerchantid(Long merchantid) {
		this.merchantid = merchantid;
	}
	public String getUsercode() {
		return usercode;
	}
	public void setUsercode(String usercode) {
		this.usercode = usercode;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Date getLastlogindate() {
		return lastlogindate;
	}
	public void setLastlogindate(Date lastlogindate) {
		this.lastlogindate = lastlogindate;
	}
	
	public short getEnabled() {
		return enabled;
	}
	public void setEnabled(short enabled) {
		this.enabled = enabled;
	}
	public Long getResults() {
		return results;
	}
	public void setResults(Long results) {
		this.results = results;
	}
	public Long getAttempttimes() {
		return attempttimes;
	}
	public void setAttempttimes(Long attempttimes) {
		this.attempttimes = attempttimes;
	}
	public Long getLocked() {
		return locked;
	}
	public void setLocked(Long locked) {
		this.locked = locked;
	}
	public String getPermits() {
		return permits;
	}
	public void setPermits(String permits) {
		this.permits = permits;
	}
	
	
	
	
	
	
}


