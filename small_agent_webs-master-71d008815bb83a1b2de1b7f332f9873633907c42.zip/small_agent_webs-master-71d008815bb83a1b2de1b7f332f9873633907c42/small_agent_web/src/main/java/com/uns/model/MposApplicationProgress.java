package com.uns.model;
import java.util.Date;

public class MposApplicationProgress {
    private Long applicationProgressId;

    private String shopperid;

    private String scompany;

    private String applicationTheme;

    private String applicationType;

    private Long createUser;

    private String shopperidP;

    private String agentName;

    private Date createDate;

    private Date updateDate;

    private String applicationStatus;

    private String applicationRemark;

    private String openT0Flag;

    private String icCardFlag;

    private String t0Fee;

    private String shopperLimit;

    private String shopperType;

    private String tel;

    private String shopperName;

    private String identityId;

    private Long photoId;

    private String singleLimit;

    public Long getApplicationProgressId() {
        return applicationProgressId;
    }

    public void setApplicationProgressId(Long applicationProgressId) {
        this.applicationProgressId = applicationProgressId;
    }

    public String getShopperid() {
        return shopperid;
    }

    public void setShopperid(String shopperid) {
        this.shopperid = shopperid;
    }

    public String getScompany() {
        return scompany;
    }

    public void setScompany(String scompany) {
        this.scompany = scompany == null ? null : scompany.trim();
    }

    public String getApplicationTheme() {
        return applicationTheme;
    }

    public void setApplicationTheme(String applicationTheme) {
        this.applicationTheme = applicationTheme == null ? null : applicationTheme.trim();
    }

    public String getApplicationType() {
        return applicationType;
    }

    public void setApplicationType(String applicationType) {
        this.applicationType = applicationType == null ? null : applicationType.trim();
    }

    public Long getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Long createUser) {
        this.createUser = createUser;
    }

    public String getShopperidP() {
        return shopperidP;
    }

    public void setShopperidP(String shopperidP) {
        this.shopperidP = shopperidP;
    }

    public String getAgentName() {
        return agentName;
    }

    public void setAgentName(String agentName) {
        this.agentName = agentName == null ? null : agentName.trim();
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getApplicationStatus() {
        return applicationStatus;
    }

    public void setApplicationStatus(String applicationStatus) {
        this.applicationStatus = applicationStatus == null ? null : applicationStatus.trim();
    }

    public String getApplicationRemark() {
        return applicationRemark;
    }

    public void setApplicationRemark(String applicationRemark) {
        this.applicationRemark = applicationRemark == null ? null : applicationRemark.trim();
    }

    public String getOpenT0Flag() {
        return openT0Flag;
    }

    public void setOpenT0Flag(String openT0Flag) {
        this.openT0Flag = openT0Flag == null ? null : openT0Flag.trim();
    }

    public String getIcCardFlag() {
        return icCardFlag;
    }

    public void setIcCardFlag(String icCardFlag) {
        this.icCardFlag = icCardFlag == null ? null : icCardFlag.trim();
    }

    public String getT0Fee() {
        return t0Fee;
    }

    public void setT0Fee(String t0Fee) {
        this.t0Fee = t0Fee == null ? null : t0Fee.trim();
    }

    public String getShopperLimit() {
        return shopperLimit;
    }

    public void setShopperLimit(String shopperLimit) {
        this.shopperLimit = shopperLimit == null ? null : shopperLimit.trim();
    }

    public String getShopperType() {
        return shopperType;
    }

    public void setShopperType(String shopperType) {
        this.shopperType = shopperType == null ? null : shopperType.trim();
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel == null ? null : tel.trim();
    }

    public String getShopperName() {
        return shopperName;
    }

    public void setShopperName(String shopperName) {
        this.shopperName = shopperName == null ? null : shopperName.trim();
    }

    public String getIdentityId() {
        return identityId;
    }

    public void setIdentityId(String identityId) {
        this.identityId = identityId == null ? null : identityId.trim();
    }

    public Long getPhotoId() {
        return photoId;
    }

    public void setPhotoId(Long photoId) {
        this.photoId = photoId;
    }

    public String getSingleLimit() {
        return singleLimit;
    }

    public void setSingleLimit(String singleLimit) {
        this.singleLimit = singleLimit == null ? null : singleLimit.trim();
    }
}