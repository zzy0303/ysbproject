package com.uns.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.web.form.SmRecordForm;

@Repository
public interface SmRecordMapper {


	  /**
     * 扫码记录查询
     * @author yang.liu01
     * @param smRecordForm
     * @return
     */
    List<Map<String,Object>> selectRecordList(SmRecordForm smRecordForm);

    /**
     * 查询扫码相关费率
     * @param shopperid
     * @return
     */
	List<Map<String, Object>> selectAgentFeeForQrcode(String shopperid);
	
	/**
	 * 扫码记录下载
	 * @param smRecordForm
	 * @return
	 */
	List<Map<String, Object>> downSmRecordList(SmRecordForm smRecordForm);
	/**
	 * 商户扫码记录
	 * @param smRecordForm
	 * @return
	 */
	List<Map<String, Object>> selectMersmRecordList(SmRecordForm smRecordForm);
	/**
	 * 商户扫码记录下载
	 * @param smRecordForm
	 * @return
	 */
	List<Map<String, Object>> selectDownMerSmRecordList(SmRecordForm smRecordForm);
	
}