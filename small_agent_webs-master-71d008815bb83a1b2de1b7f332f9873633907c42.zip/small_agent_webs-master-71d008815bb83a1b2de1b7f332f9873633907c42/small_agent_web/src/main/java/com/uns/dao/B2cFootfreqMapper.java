package com.uns.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.B2cFootfreq;

@Repository
public interface B2cFootfreqMapper {

	/**结算周期
	 * @return
	 */
	List<B2cFootfreq> searchFootFreqList();


	B2cFootfreq searchFootFreqById(Long footfreqId);
    
}