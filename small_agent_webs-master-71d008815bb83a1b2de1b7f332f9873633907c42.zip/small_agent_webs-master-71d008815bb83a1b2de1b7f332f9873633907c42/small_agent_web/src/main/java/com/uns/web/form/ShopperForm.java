package com.uns.web.form;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.multipart.MultipartFile;

public class ShopperForm {
	private String b2cShopperbiId;
	private String shopperid;
	private String scompany;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date startDate;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date overDate;
	private String salesman;
	private String provinceCode;
	private String cityCode;
	private String openT0Flag;

	private Long shopperidp;
	private String shopperType;
	private String returnsFlag;
	private Long industryType;
	private String fee;
	private String billName;
	private String province;
	private String city;
	private String county;
	private String countyCode;
	private String address;
	private Date createDate;
	private Date updateDate;
	private String tel;
	private String shopperName;
	private String identityId;
	private Long photoId;
	private String accountName;
	private String bankCard;
	private String bankName;
	private String bankCode;
	private String cardProvince;
	private String cardProvinceCode;
	private String cardCity;
	private String cardCityCode;
	private String cardCounty;
	private String cardCountyCode;
	private String branchBankName;
	private String icCardFlag;
	private String t0Fee;
	private String shopperLimit;
	private String remark;
	private String eviceNumber;
	private String linceseNo;
	private String merchantStatus;
    private String protocol;
    private MultipartFile contract;
    private String signatrue;
    private String singleLimit;
    
	private MultipartFile handIdentityCardPhoto;
    private MultipartFile frontIdentityCardPhoto;
    private MultipartFile reverseIdentityCardPhoto;
    private MultipartFile storePhoto;
    private MultipartFile licensePhoto;
    private MultipartFile instorePhoto;
    private MultipartFile checkstandPhoto;
    
    public String getSingleLimit() {
		return singleLimit;
	}

	public void setSingleLimit(String singleLimit) {
		this.singleLimit = singleLimit;
	}
	public String getLinceseNo() {
		return linceseNo;
	}
	public void setLinceseNo(String linceseNo) {
		this.linceseNo = linceseNo;
	}
	public String getMerchantStatus() {
		return merchantStatus;
	}
	public void setMerchantStatus(String merchantStatus) {
		this.merchantStatus = merchantStatus;
	}
	public String getProtocol() {
		return protocol;
	}
	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}
	
	public MultipartFile getContract() {
		return contract;
	}

	public void setContract(MultipartFile contract) {
		this.contract = contract;
	}

	public String getSignatrue() {
		return signatrue;
	}
	public void setSignatrue(String signatrue) {
		this.signatrue = signatrue;
	}
	public MultipartFile getHandIdentityCardPhoto() {
		return handIdentityCardPhoto;
	}
	public void setHandIdentityCardPhoto(MultipartFile handIdentityCardPhoto) {
		this.handIdentityCardPhoto = handIdentityCardPhoto;
	}
	public MultipartFile getFrontIdentityCardPhoto() {
		return frontIdentityCardPhoto;
	}
	public void setFrontIdentityCardPhoto(MultipartFile frontIdentityCardPhoto) {
		this.frontIdentityCardPhoto = frontIdentityCardPhoto;
	}
	public MultipartFile getReverseIdentityCardPhoto() {
		return reverseIdentityCardPhoto;
	}
	public void setReverseIdentityCardPhoto(MultipartFile reverseIdentityCardPhoto) {
		this.reverseIdentityCardPhoto = reverseIdentityCardPhoto;
	}
	public MultipartFile getStorePhoto() {
		return storePhoto;
	}
	public void setStorePhoto(MultipartFile storePhoto) {
		this.storePhoto = storePhoto;
	}
	public MultipartFile getLicensePhoto() {
		return licensePhoto;
	}
	public void setLicensePhoto(MultipartFile licensePhoto) {
		this.licensePhoto = licensePhoto;
	}
	public MultipartFile getInstorePhoto() {
		return instorePhoto;
	}
	public void setInstorePhoto(MultipartFile instorePhoto) {
		this.instorePhoto = instorePhoto;
	}
	public MultipartFile getCheckstandPhoto() {
		return checkstandPhoto;
	}
	public void setCheckstandPhoto(MultipartFile checkstandPhoto) {
		this.checkstandPhoto = checkstandPhoto;
	}
	public String getB2cShopperbiId() {
		return b2cShopperbiId;
	}

	public void setB2cShopperbiId(String b2cShopperbiId) {
		this.b2cShopperbiId = b2cShopperbiId;
	}

	public String getShopperid() {
		return shopperid;
	}

	public void setShopperid(String shopperid) {
		this.shopperid = shopperid;
	}

	public String getScompany() {
		return scompany;
	}
	public void setScompany(String scompany) {
		this.scompany = scompany;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getOverDate() {
		return overDate;
	}
	public void setOverDate(Date overDate) {
		this.overDate = overDate;
	}
	public String getSalesman() {
		return salesman;
	}
	public void setSalesman(String salesman) {
		this.salesman = salesman;
	}
	public String getProvinceCode() {
		return provinceCode;
	}
	public void setProvinceCode(String provinceCode) {
		this.provinceCode = provinceCode;
	}
	public String getCityCode() {
		return cityCode;
	}
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}
	public String getOpenT0Flag() {
		return openT0Flag;
	}
	public void setOpenT0Flag(String openT0Flag) {
		this.openT0Flag = openT0Flag;
	}
	public Long getShopperidp() {
		return shopperidp;
	}
	public void setShopperidp(Long shopperidp) {
		this.shopperidp = shopperidp;
	}
	public String getShopperType() {
		return shopperType;
	}
	public void setShopperType(String shopperType) {
		this.shopperType = shopperType;
	}
	public String getReturnsFlag() {
		return returnsFlag;
	}
	public void setReturnsFlag(String returnsFlag) {
		this.returnsFlag = returnsFlag;
	}
	public Long getIndustryType() {
		return industryType;
	}
	public void setIndustryType(Long industryType) {
		this.industryType = industryType;
	}
	public String getFee() {
		return fee;
	}
	public void setFee(String fee) {
		this.fee = fee;
	}
	public String getBillName() {
		return billName;
	}
	public void setBillName(String billName) {
		this.billName = billName;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCounty() {
		return county;
	}
	public void setCounty(String county) {
		this.county = county;
	}
	public String getCountyCode() {
		return countyCode;
	}
	public void setCountyCode(String countyCode) {
		this.countyCode = countyCode;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getShopperName() {
		return shopperName;
	}
	public void setShopperName(String shopperName) {
		this.shopperName = shopperName;
	}
	public String getIdentityId() {
		return identityId;
	}
	public void setIdentityId(String identityId) {
		this.identityId = identityId;
	}
	public Long getPhotoId() {
		return photoId;
	}
	public void setPhotoId(Long photoId) {
		this.photoId = photoId;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getBankCard() {
		return bankCard;
	}
	public void setBankCard(String bankCard) {
		this.bankCard = bankCard;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public String getCardProvince() {
		return cardProvince;
	}
	public void setCardProvince(String cardProvince) {
		this.cardProvince = cardProvince;
	}
	public String getCardProvinceCode() {
		return cardProvinceCode;
	}
	public void setCardProvinceCode(String cardProvinceCode) {
		this.cardProvinceCode = cardProvinceCode;
	}
	public String getCardCity() {
		return cardCity;
	}
	public void setCardCity(String cardCity) {
		this.cardCity = cardCity;
	}
	public String getCardCityCode() {
		return cardCityCode;
	}
	public void setCardCityCode(String cardCityCode) {
		this.cardCityCode = cardCityCode;
	}
	public String getCardCounty() {
		return cardCounty;
	}
	public void setCardCounty(String cardCounty) {
		this.cardCounty = cardCounty;
	}
	public String getCardCountyCode() {
		return cardCountyCode;
	}
	public void setCardCountyCode(String cardCountyCode) {
		this.cardCountyCode = cardCountyCode;
	}
	public String getBranchBankName() {
		return branchBankName;
	}
	public void setBranchBankName(String branchBankName) {
		this.branchBankName = branchBankName;
	}
	public String getIcCardFlag() {
		return icCardFlag;
	}
	public void setIcCardFlag(String icCardFlag) {
		this.icCardFlag = icCardFlag;
	}
	public String getT0Fee() {
		return t0Fee;
	}
	public void setT0Fee(String t0Fee) {
		this.t0Fee = t0Fee;
	}
	public String getShopperLimit() {
		return shopperLimit;
	}
	public void setShopperLimit(String shopperLimit) {
		this.shopperLimit = shopperLimit;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getEviceNumber() {
		return eviceNumber;
	}
	public void setEviceNumber(String eviceNumber) {
		this.eviceNumber = eviceNumber;
	}
	
	private String applicationStatus;
	private String applicationProgressId;
	
	public String getApplicationProgressId() {
		return applicationProgressId;
	}
	
	public void setApplicationProgressId(String applicationProgressId) {
		this.applicationProgressId = applicationProgressId;
	}
	public String getApplicationStatus() {
		return applicationStatus;
	}
	public void setApplicationStatus(String applicationStatus) {
		this.applicationStatus = applicationStatus;
	}
	
}
