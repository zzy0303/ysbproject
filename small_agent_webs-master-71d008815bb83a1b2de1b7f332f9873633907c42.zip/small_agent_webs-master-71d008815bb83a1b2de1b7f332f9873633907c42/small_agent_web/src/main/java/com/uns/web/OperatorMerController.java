package com.uns.web;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.model.Operator;
import com.uns.model.RoleMerInfo;
import com.uns.model.Users;
import com.uns.service.AOperatorService;
import com.uns.service.RoleMerService;
import com.uns.util.StringUtils;
import com.uns.web.form.AgentUserForm;

@Controller("OperatorMerController")
@RequestMapping("/operatorMer.htm")
public class OperatorMerController extends BaseController {

	@Autowired
	private AOperatorService operatorService;
	
	@Autowired
	private RoleMerService roleService;
	
	/**操作员管理目录
	 * @param request
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=toUserManageList")
	public String toUserManageList(HttpServletRequest request,AgentUserForm mbForm, ModelMap modelMap) throws BusinessException{
		try {
			List userList = operatorService.selectUsersList(mbForm);
			modelMap.put("userList",userList );
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.操作员列表);
		}
		
		return "operator/operatorMerList";
	}
	
	/**操作员角色页面
	 * @param request
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=operatorUpdate")
	@FormToken(save=true)
	public String operatorUpdate(HttpServletRequest request, AgentUserForm mbForm, ModelMap modelMap) throws BusinessException{
		try {
			Operator operator=(Operator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			if(operator==null) throw new BusinessException(ExceptionDefine.登录失效);
			String userId=request.getParameter("userId");
			Users user=null;
			if(!StringUtils.isEmpty(userId)){
				user=operatorService.selectUsersById(Long.valueOf(userId));
			}
			List<RoleMerInfo> roleInfoList;
			roleInfoList = roleService.selectRoleInfo(Constants.CON_YES);
			modelMap.put("user",user );
			modelMap.put("roleInfoList",roleInfoList );
		} catch (NumberFormatException e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.数字格式化错误);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.操作员角色);
		}
		return "operator/operatorMerUpdate";
	}
	
	/**保存操作员
	 * @param request
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=saveOperator")
	@FormToken(remove=true)
	public String saveOperator(HttpServletRequest request, AgentUserForm mbForm, ModelMap modelMap) throws BusinessException{
		try {
			String userId=request.getParameter("userId");
			if(!StringUtils.isEmpty(userId)){
				Users user = operatorService.selectUsersById(Long.valueOf(userId));
				user.setUsercode(mbForm.getUsercode());
				operatorService.update(user);
				request.setAttribute(Constants.MESSAGE_KEY,Constants.SAVE_MESSAGE);
			}else{
				throw new BusinessException(ExceptionDefine.空指针异常);
			}
		} catch (NumberFormatException e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.数字格式化错误);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.保存操作员);
		}
	    request.setAttribute("url","operatorMer.htm?method=toUserManageList");
        return "/returnPage";
	}
	
}
