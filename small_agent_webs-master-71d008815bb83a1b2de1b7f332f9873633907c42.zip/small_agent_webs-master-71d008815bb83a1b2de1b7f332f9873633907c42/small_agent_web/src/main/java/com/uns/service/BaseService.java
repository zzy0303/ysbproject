package com.uns.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.Logger;

public class BaseService {
	
	protected Log log = LogFactory.getLog(this.getClass());
	
	protected final Logger logger = Logger.getLogger(this.getClass());

}
