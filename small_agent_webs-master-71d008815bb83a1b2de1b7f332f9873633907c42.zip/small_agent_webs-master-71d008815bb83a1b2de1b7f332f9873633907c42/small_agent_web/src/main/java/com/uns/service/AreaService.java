package com.uns.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.uns.dao.AreaMapper;
import com.uns.model.Area;

@Service
public class AreaService {
	
	@Autowired
	private AreaMapper areaMapper;
	
	public List<Area> searchArea() throws Exception{
		return areaMapper.searchArea();
	}
	public List<Area> searchProvince() throws Exception{
		return areaMapper.searchProvince();
	}
	public List searchCity(String city) throws Exception{
		Area area = new Area();
		area.setCity(city);
		return areaMapper.searchCity(area);
	}
	public List searchProvincial(String province) {
		Area area = new Area();
		area.setProvincial(province);
		return areaMapper.searchProvincial(area);
	}
}
