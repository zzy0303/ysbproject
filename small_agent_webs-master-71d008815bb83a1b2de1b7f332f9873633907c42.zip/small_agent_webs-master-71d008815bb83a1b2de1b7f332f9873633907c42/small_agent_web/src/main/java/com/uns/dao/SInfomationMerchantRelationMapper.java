package com.uns.dao;

import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.SInfomationMerchantRelation;
@Repository
public interface SInfomationMerchantRelationMapper {

    int insert(SInfomationMerchantRelation record);

    int insertSelective(SInfomationMerchantRelation record);

	void updateInfomationMerchant(Map map);

}