package com.uns.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.MposRemoteFee;
@Repository
public interface MposRemoteFeeMapper {

    int deleteByPrimaryKey(BigDecimal id);

    int insert(MposRemoteFee record);

    int insertSelective(MposRemoteFee record);

    MposRemoteFee selectByPrimaryKey(BigDecimal id);

    int updateByPrimaryKeySelective(MposRemoteFee record);

    int updateByPrimaryKey(MposRemoteFee record);
    
    List findbytel(String tel);
    
    List queryfee(String tel);
    
    void delfee(String tel);

	MposRemoteFee findMposRemoteFee(Map debitfeeMap);

	List remotefeeList(String tel);

	List findbytel1(String tel);
    
   
}