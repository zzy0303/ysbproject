package com.uns.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.Mcc;
@Repository
public interface MccMapper {

	List<Mcc> searchMcc();

	List<Mcc> searchMccById(Map map);
}
