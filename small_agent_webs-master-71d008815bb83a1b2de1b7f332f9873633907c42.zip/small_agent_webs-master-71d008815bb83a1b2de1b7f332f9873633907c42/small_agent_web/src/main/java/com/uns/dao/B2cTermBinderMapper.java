package com.uns.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.B2cTermBinder;
import com.uns.web.form.TerminalForm;
@Repository
public interface B2cTermBinderMapper {

    int insert(B2cTermBinder record);

    int insertSelective(B2cTermBinder record);

    B2cTermBinder selectOneBinder(String terNo);
    
    int deleteByShopperId(String shopperId);
    //是否取消绑定 1为取消绑定
    void updateIsBinder(B2cTermBinder b2cTermBinder);

	List<B2cTermBinder> selectByB2cTermBinderList(String shopperId);
	
	void deleteBinderId(String shopperId);
	//审核不通过
	void updateBackBinder(B2cTermBinder b2cTermBinder);
	//查询商户绑定终端
	List findTerminalList(String merchantNo);

	List findDiveceNo(String merchantNo);

	B2cTermBinder findB2cTermBinderByTermNo(String termNo);

	void updateBundling(B2cTermBinder termno);

	List findbinderList(String merchantNo);
	/**
	 * 终端查询-登录人为一级服务商的
	 * @param mbForm
	 * @return
	 */
	public List<B2cTermBinder> findFirstTerminalInList(TerminalForm mbForm);
	/**
	 * 终端查询-登录人非一级服务商的
	 * @param mbForm
	 * @return
	 */
	public List<B2cTermBinder> findTerminalRepertoryInList(TerminalForm mbForm);
	/**
	 * 查询批次号是否存在
	 * @param termBatchNo
	 * @return
	 */
	public List findTermBatchNo(String termBatchNo);

	/**
	 * 根据设备编号查询记录
	 * @param termNo
	 * @return
	 */
	public B2cTermBinder findTermBatchByTermNo(String termNo);
	
	/**
	 * 查询所属自己的代理的
	 * @param agentNo
	 * @return
	 */
	public List<B2cTermBinder> findTermBatchList(String agentNo);
	/**
	 * 根据当前服务商编号查询记录
	 * @param agentNo
	 * @return
	 */
	public List<B2cTermBinder> findTermBatchByTermByAgentNo(String agentNo);
	/**
	 * 通过设备编号批量更新数据
	 * @param termNo
	 */
	public void updateBatchBinder(B2cTermBinder b2cTermBinder);

	/**
	 * 终端出库查询
	 * @param mbForm
	 * @return
	 */
	public List<B2cTermBinder> findTerminalRepertoryOutList(TerminalForm mbForm);
	/**
	 * 更新数据-出库
	 * @param b2cTermBinder
	 */
	public void updateBatchBinderOut(B2cTermBinder b2cTermBinder);

	/**
	 * 终端退货
	 * @author yang.liu01
	 * @param b2cTermBinder
	 */
	public void updateTerminalRetreat(B2cTermBinder b2cTermBinder);
	
	
}