package com.uns.service;

import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.dao.AgentMapper;
import com.uns.dao.AgentTopFeeMapper;
import com.uns.dao.AreaMapper;
import com.uns.dao.B2cAgentBinderMapper;
import com.uns.dao.B2cDictMapper;
import com.uns.dao.B2cFootfreqMapper;
import com.uns.dao.B2cShopperbiMapper;
import com.uns.dao.B2cShopperbiTempHistoryMapper;
import com.uns.dao.B2cShopperbiTempMapper;
import com.uns.dao.B2cTempTermBinderMapper;
import com.uns.dao.B2cTermBinderMapper;
import com.uns.dao.B2cTerminalMapper;
import com.uns.dao.B2cUserMapper;
import com.uns.dao.BackupsShopperInformationMapper;
import com.uns.dao.FixAmaountMapper;
import com.uns.dao.MposApplicationProgressMapper;
import com.uns.dao.MposMerchantFeeMapper;
import com.uns.dao.MposPhotoTmpMapper;
import com.uns.dao.MposRemoteFeeMapper;
import com.uns.dao.MposRemoteInvitationMapper;
import com.uns.dao.OperatorMapper;
import com.uns.dao.UsersMapper;
import com.uns.model.Agent;
import com.uns.model.AgentTopFee;
import com.uns.model.Area;
import com.uns.model.B2cAgentBinder;
import com.uns.model.B2cDict;
import com.uns.model.B2cFootfreq;
import com.uns.model.B2cShopperbargainTemp;
import com.uns.model.B2cShopperbi;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.B2cTempTermBinder;
import com.uns.model.B2cTermBinder;
import com.uns.model.B2cTerminal;
import com.uns.model.B2cUser;
import com.uns.model.BackupsShopperInformation;
import com.uns.model.FixAmaount;
import com.uns.model.MposApplicationProgress;
import com.uns.model.MposMerchantFee;
import com.uns.model.MposPhotoTmp;
import com.uns.model.MposRemoteFee;
import com.uns.model.MposRemoteInvitation;
import com.uns.model.Operator;
import com.uns.model.Users;
import com.uns.util.ToolsUtils;
import com.uns.web.form.ShopPerbiForm;


@Service
public class ShopPerbiService {
	
	@Autowired
	private UsersMapper usersMapper;
	@Autowired
	private OperatorMapper operatorMapper;
	@Autowired
	private B2cDictMapper b2cDictMapper;
	
	@Autowired
	private MposMerchantFeeMapper  mposMerchantFeeMapper;
	
	@Autowired
	private MposPhotoTmpMapper mposphototmpmapper;
	
	@Autowired
	private B2cFootfreqMapper b2cFootfreqMapper;
	
	@Autowired
	private AreaMapper areaMapper;
	
	@Autowired
	private B2cAgentBinderMapper b2cAgentBinderMapper;
	
	@Autowired
	private B2cUserMapper b2cUserMapper;
	
	@Autowired
	private AgentMapper agentMapper;
	
	@Autowired
	private B2cShopperbiMapper b2cShopperbiMapper;
	
	@Autowired
	private B2cShopperbiTempMapper b2cShopperbiTempMapper;
	
	

	@Autowired
	private B2cTermBinderMapper b2cTermBinderMapper;
	
	@Autowired
	private B2cTerminalMapper b2cTerminalMapper;
	
	@Autowired
	private B2cTempTermBinderMapper b2cTempTermBinderMapper;
	

	
	@Autowired
	private MposApplicationProgressMapper progressmapper;
	
	
	@Autowired
	private B2cDictMapper  b2cdictmapper;
	

	
	@Autowired
	private MposRemoteInvitationMapper  remotemapper;

	@Autowired
	private BackupsShopperInformationMapper bkshoppermapper;
	
	@Autowired
	private AgentTopFeeMapper agenttopfeemapper;
	
	@Autowired
	private   B2cShopperbiTempHistoryMapper  b2cShopperbiTempHistoryMapper;
	
	
	@Autowired
	private   MposRemoteInvitationMapper    mposRemoteInvitationMapper;
	

	
	@Autowired
	private  FixAmaountMapper fixamountMapper;
	
	@Autowired
	private MposRemoteFeeMapper mposRemoteFeeMapper;
	
	
	public List<HashMap> selectAgentNum(String agentNo){
		List<HashMap> list=b2cAgentBinderMapper.selectBinderNum(agentNo);
		return list;
	}
	/**
	 * 
	 * 查询中间表终端信息
	 * @return 
	 */
	public B2cTempTermBinder selectTempTermNo(String terminalid) {
		return b2cTempTermBinderMapper.selectByTempBinder(terminalid);
	}
	/**
	 * 
	 * 添加绑定的中间表
	 */
	public void addTempBinder(B2cTempTermBinder b2cTempTermBinder) {
		b2cTempTermBinderMapper.insert(b2cTempTermBinder);
	}
	
	/**
	 * 
	 * 商户审核，添加数据到正式表中
	 */
	public void updateShoppbi(B2cShopperbiTemp b2cShopperbi){
		b2cShopperbiMapper.updateShoppbiTemp(b2cShopperbi);
	}
	
	/**
	 * 
	 * 查原有商户绑定的终端
	 */
	public List<HashMap> selectOldTerminal(String shopperid) {
		List<HashMap> Terlist=b2cTerminalMapper.selectOldTerminal(shopperid);
		return Terlist;
	}
	/**
	 * 
	 * 根据terNUM查询服务商编号
	 */
	public B2cAgentBinder selectByTermNo(String termNum){
		B2cAgentBinder agentbinder=b2cAgentBinderMapper.selectAgentnoByTermNo(termNum);
		return agentbinder;
	};
	/**
	 * 
	 * 查商户新绑定的终端
	 */
	public List<HashMap> selectNewBinder(String shopperid) {
		List<HashMap> newTer=b2cTempTermBinderMapper.selectNewBinder(shopperid);
		return newTer;
	}
	/**
	 * 
	 * 查询出中间绑定的中间表
	 */
	public List<HashMap> selectTempBinderList(String  shopperId) {
		List<HashMap> Binderlist=b2cTempTermBinderMapper.selectTempBinderList(shopperId);
		return Binderlist;
	}
	/**
	 * 
	 * 添加User
	 */
	public void addUser(Map params) {
		usersMapper.addUsers(params);
	}
	/**
	 * 
	 * 查询出终端信息
	 * @return 
	 */
	public B2cTerminal findtermainal(String terminalid) {
		return b2cTerminalMapper.selectByPrimaryKey(terminalid);
	}
	/**
	 * 
	 * 查询出终端号是否绑定了商户
	 * @return 
	 */
	public String selectBindtermainal(String terminalid) {
		return b2cTerminalMapper.selectTerminalbind(terminalid);
	}
	
	/** 查询省
	 * @return
	 */
	public List<Area> searchProvince()throws Exception {
		List<Area> list=areaMapper.searchProvince();
		return list;
	}
	public List<Area> searchArea()throws Exception {
		List<Area> list=areaMapper.searchArea();
		return list;
	}
	/** 查询银行
	 * @return
	 */
	public List<B2cDict> searchBank()throws Exception {
		List<B2cDict> list=b2cDictMapper.searchDictBank();
		return list;
	}
	
	/** 查询银行名字
	 * @return
	 */
	public B2cDict findBankName(String b2cDictId)throws Exception {
		B2cDict b2cdict=b2cDictMapper.findDictBankName(b2cDictId);
		return b2cdict;
	}
	/**�̻���Ӧ��ҵ
	 * @param conDictclsCalling
	 * @return
	 */
	public List searchDictCls (String dictclsid)throws BusinessException {
		List<B2cDict> list=b2cDictMapper.searchDictCls(dictclsid);
		return list;
	}

	/**��������
	 * @return
	 */
	public List searchFootFreqList()throws Exception {
		return b2cFootfreqMapper.searchFootFreqList();
	}
	/**
	 * 查询商户信息未审核的个数
	 * @return
	 */
	public String selectCheckCount(ShopPerbiForm shopPerbiForm){
		String ckCount = b2cShopperbiTempMapper.selectCheckCount(shopPerbiForm);
		return ckCount!=null&&!"".equals(ckCount)?ckCount:"0";
	}	
	/**
	 * 查询商户开户银行的信息未审核的个数
	 * @return
	 */
	public String selectCheckBkCount(ShopPerbiForm shopPerbiForm){
		String bankCount = b2cShopperbiTempMapper.selectCheckBkCount(shopPerbiForm);
		return bankCount!=null&&!"".equals(bankCount)?bankCount:"0";
	}
	
	/**
	 * 查询商户终端未审核的个数
	 * @return
	 */
	public String selectTerminalCount(ShopPerbiForm shopPerbiForm){
		String TerCount = b2cShopperbiTempMapper.selectTerminalCount(shopPerbiForm);
		return TerCount!=null&&!"".equals(TerCount)?TerCount:"0";
	}
	
	
	
	//根据merchantid 查询单个的username
	public Users selectByUserId(String shopperid) throws Exception {
		Users user = usersMapper.selectByUserId(shopperid);
		return user;
	}
	
	//根据shopperid 查询单个的fomalshopper
	public B2cShopperbi selectFormalShopperId(String shopperid) throws Exception {
		B2cShopperbi forshopperbi = b2cShopperbiMapper.selectFormalshoppId(shopperid);
		return forshopperbi;
	}
	
	//判断是否有重复的userName
	public List selectByUsersName(String userName) throws Exception {
		List<Users>  Users= usersMapper.selectByUsesrName(userName);
		return Users;
	}
	
	/**查询服务商
	 * @param agentId
	 * @return
	 */
	public Agent searchAgent(Long agentId)throws Exception {
		return agentMapper.searchAgentByShopperid(agentId.toString());
	}
	
	/**查询服务商
	 * @param agentId
	 * @return
	 */
	public Agent selectAgent(Long agentId)throws Exception {
		return agentMapper.searchAgentById(agentId.toString());
	}

	/**省
	 * @param province
	 * @return
	 */
	public List searchProvincial(String province)throws Exception {
		Area area=new Area();
		area.setProvincial(province);
		return areaMapper.searchProvincial(area);
	}
	
	/**查询单个ip
	 * @param province
	 * @return
	 */
	public Area searchBankProvincial(String provincial)throws Exception {
		Area pro=areaMapper.searchBankProvince(provincial);
		return pro;
	}
	/**查询单个服务商信息
	 * @param province
	 * @return
	 */
	public Agent searchAgentById(String id) {
		return agentMapper.searchAgentById(id);
	}
	/**城市
	 * @param city
	 * @return
	 */
	public List searchCity(String city)throws Exception {
		Area area=new Area();
		area.setCity(city);
		return areaMapper.searchCity(area);
	}

	/**
	 * @param conDictclsCalling
	 * @param shoppercallingid
	 * @return
	 * @throws BusinessException 
	 */
	public List searchDictName(String conDictclsCalling, String dictid) throws BusinessException {
		Map<String, String> map=new HashMap<String, String>();
		map.put("dictclsid", conDictclsCalling);
		map.put("dictid", dictid);
		List list= b2cDictMapper.searchDictName(map);
		return list;
	}
	/**查询结算周期
	 * @param footfreqId
	 * @return
	 */
	public B2cFootfreq searchFootFreqById(Long footfreqId)throws Exception {
		return b2cFootfreqMapper.searchFootFreqById(footfreqId);
	}

	public B2cUser selectB2cUserById(Long writeoperid)throws Exception {
		return b2cUserMapper.selectB2cUserById(writeoperid);
	}
	/**查询商户信息
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	public List<HashMap> queryShopPerbiManageList(ShopPerbiForm mbForm) throws BusinessException{
		PageContext.initPageSize(20);
		return b2cShopperbiTempMapper.ShopPerbiManageList(mbForm);
	}
	
	/**查询正式商户信息
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	public List<HashMap> queryFormalManageList(ShopPerbiForm mbForm) throws BusinessException{
		PageContext.initPageSize(20);
		List<HashMap> list = b2cShopperbiMapper.ShopFormalManageList(mbForm);
		return list;
	}
	
	/**查询正式商户信息
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	public List<HashMap> excelFormalManageList(ShopPerbiForm mbForm) throws BusinessException{
		PageContext.initPageSize(Constants.excel_size);
		List<HashMap> list = b2cShopperbiMapper.ShopFormalManageList(mbForm);
		return list;
	}
	
	/**查询出待审核商户的列表信息
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	public List<HashMap> ShopPerbiCheckList(ShopPerbiForm mbForm) throws BusinessException{
		PageContext.initPageSize(20);
		return b2cShopperbiTempMapper.ShopPerbiCheckList(mbForm);
	}
	
	
	/**
	 * @param mbForm
	 * @return    zt
	 * @throws BusinessException
	 */
	public List<HashMap> shopPerbiTerminalList(ShopPerbiForm mbForm) throws BusinessException{
		PageContext.initPageSize(20);
		return b2cShopperbiTempMapper.shopPerbiTerminalList(mbForm);
	}
	/**添加商户表
	 * @param b2cShopperbi
	 */
	public void insertB2cShopperbi(B2cShopperbiTemp b2cShopperbi) {
		b2cShopperbiTempMapper.insert(b2cShopperbi);
	}
	
	/**商户审核通过以后加入到正式表中
	 * @param b2cShopperbi
	 */
	public void insertFormalB2cShopperbi(B2cShopperbiTemp b2cShopperbi) {
		b2cShopperbiMapper.insert(b2cShopperbi);
	}

	/**查询商户信息
	 * @param shopPerbiregId
	 * @return
	 */
	public B2cShopperbiTemp queryShopPerbi(String b2cShopperbiId)throws Exception {
		return b2cShopperbiTempMapper.selectByshopperId(Long.valueOf(b2cShopperbiId));
	}
	/**查询正式商户信息
	 * @param shopPerbiregId
	 * @return
	 */
	public B2cShopperbi queryFormalShopPerbi(String b2cShopperbiId)throws Exception {
		return b2cShopperbiMapper.selectFormalshoppId(b2cShopperbiId);
	}

	/**判断是否有同样的公司名
	 * @param userName
	 * @return
	 */
	public B2cShopperbiTemp findB2cShopperbiScompany(String scompany) {
		return b2cShopperbiTempMapper.selectByScompany(scompany);
	}
	/**修改小商户的资料
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @throws Exception
	 */
	public void updateByShopperId(B2cShopperbiTemp b2cShopperbi,B2cShopperbargainTemp b2cShopperbargain)throws Exception {
		b2cShopperbiTempMapper.updateByShopperId(b2cShopperbi);
		/*B2cShopperbargainTemp b2cShopperbargains=b2cShopperbargainTempMapper.selectByShopperbiId(Long.valueOf(b2cShopperbargain.getShopperid()));
		if(b2cShopperbargains!=null){
			b2cShopperbargainTempMapper.updateByShopperId(b2cShopperbargain);
		}else{
			insertB2cShopperbargain(b2cShopperbargain);
		}*/
//		usersMapper.updateByUsresId(users);
		saveOrUpdateProgress(b2cShopperbi,Constants.TYPE_2);
	}
	/**修改小商户开户银行的资料
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @throws Exception
	 */
	public void updateBankInfo(B2cShopperbiTemp b2cShopperbi,BackupsShopperInformation bkshopper){
		b2cShopperbiTempMapper.updateBankInfo(b2cShopperbi);
		//申请进度
		saveOrUpdateProgress(b2cShopperbi,Constants.TYPE_3);
		BackupsShopperInformation bk=findbkshopper(new BigDecimal(b2cShopperbi.getShopperid()));
		if(bk==null){
			this.bkshoppermapper.insert(bkshopper);
		}
	}
	
	/**审核成功时候，修改正式表中小商户开户银行的资料
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @throws Exception
	 */
	public void updateFormalBank(B2cShopperbiTemp b2cShopperbi){
		b2cShopperbiMapper.updateFormalBankInfo(b2cShopperbi);
	}
	
	/**
	 * @param b2cShopperbi
	 * @param remark 
	 * @param type22 
	 * @param type2 
	 * @param b2cShopperbargain
	 * @throws Exception
	 */
	public void updateCheckShopper(B2cShopperbiTemp b2cShopperbi, String type,String status, String remark)throws Exception {
		b2cShopperbiTempMapper.updateBankInfo(b2cShopperbi);
		//b2cShopperbiTempMapper.updateByShopperId(b2cShopperbi);
		updateProgress(b2cShopperbi.getShopperid().toString(),type,status,remark);
	}
	
	public void updateCheckShopper1(B2cShopperbiTemp b2cShopperbi, String type,String status, String remark)throws Exception {
		//b2cShopperbiTempMapper.updateBankInfo(b2cShopperbi);
		b2cShopperbiTempMapper.updateByShopperId(b2cShopperbi);
		updateProgress(b2cShopperbi.getShopperid().toString(),type,status,remark);
	}
	
	public void updatephotoShopper(B2cShopperbiTemp b2cShopperbi, String type,String status, String remark)throws Exception {
		//b2cShopperbiTempMapper.updateBankInfo(b2cShopperbi);
		b2cShopperbiTempMapper.updateByShopperId(b2cShopperbi);
		updateProgress(b2cShopperbi.getShopperid().toString(),type,status,remark);
	}


	/**审核绑定终端
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @throws Exception
	 */
	public void updateTermianl(B2cShopperbiTemp b2cShopperbi,String Shopperid,String status)throws Exception {
		B2cTermBinder Termbinder=new B2cTermBinder();
		b2cShopperbiTempMapper.updateByShopperId(b2cShopperbi);
		if(status.equals("1")){
			//先删除原来取消绑定的的终端
			b2cTermBinderMapper.deleteBinderId(Shopperid);
			List<HashMap> oldTerminl=b2cTempTermBinderMapper.selectNewBinder(Shopperid);
			if(oldTerminl!=null){
				for (int i = 0; i < oldTerminl.size(); i++) {
					Termbinder.setStatus("1");
					Termbinder.setCreateDate(new Date());
					Termbinder.setMerchantNo(Shopperid);
					Termbinder.setMerchantNo(Shopperid);
					Termbinder.setTermNo(oldTerminl.get(i).get("TERMINALID").toString());
					b2cTermBinderMapper.insert(Termbinder);
				}
			}
			b2cTempTermBinderMapper.deleteByMerchantNo(Shopperid);
			B2cShopperbiTemp shopper2=new B2cShopperbiTemp();
			shopper2.setShopperid(Long.valueOf(Shopperid));
			shopper2.setTermianlstatus("1");
			b2cShopperbiTempMapper.updateByShopperId(shopper2);
		}else{
			B2cTermBinder b2c=new B2cTermBinder();
			b2c.setMerchantNo(Shopperid);
			b2c.setStatus("0");
			b2cTermBinderMapper.updateBackBinder(b2c);
			B2cShopperbiTemp shopper=new B2cShopperbiTemp();
			shopper.setShopperid(Long.valueOf(Shopperid));
			shopper.setTermianlstatus("2");
			b2cShopperbiTempMapper.updateByShopperId(shopper);
		}
		
	}
	

	/**
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param shopperpriIds
	 */
	public void updateByB2cShopperId(B2cShopperbiTemp b2cShopperbi,B2cShopperbargainTemp b2cShopperbargain, String shopperId)throws Exception {
		b2cTermBinderMapper.deleteByShopperId(shopperId);
		b2cShopperbiTempMapper.updateByShopperId(b2cShopperbi);
		/*B2cShopperbargainTemp b2cShopperbargains=b2cShopperbargainTempMapper.selectByShopperbiId(Long.valueOf(b2cShopperbargain.getShopperid()));
		if(b2cShopperbargains!=null){
			b2cShopperbargainTempMapper.updateByShopperId(b2cShopperbargain);
		}else{
			insertB2cShopperbargain(b2cShopperbargain);
		}*/
		saveOrUpdateProgress(b2cShopperbi,Constants.TYPE_2);
	}
	/**
	 * @param shopperId
	 * @param agentId
	 * @return
	 */
	public List<B2cTermBinder> selectByB2cTermBinder(String shopperId,String agentId) {
		Map map=new HashMap();
		map.put("shopperId", shopperId);
		map.put("agentId", agentId);
		return b2cTerminalMapper.selectB2cb2cTerminal(map);
	}
	/**查询商户绑定好的终端
	 * @param shopperId
	 * @param agentId
	 * @return
	 */
	public List<HashMap> shopperB2cTermBinder(String shopperId) {
		return b2cTerminalMapper.selectExistTerminal(shopperId);
	}
	
	/**查询商户绑定好的终端
	 * @param shopperId
	 * @param agentId
	 * @return
	 */
	public List<HashMap> selectBinderNum(String shopperId) {
		return b2cTerminalMapper.selectBinderNum(shopperId);
	}
	
	/**查询即将商户绑定好的终端
	 * @param shopperId
	 * @param agentId
	 * @return
	 */
	public List<HashMap> shopperAjaxBinder(String shopperId) {
		return b2cTerminalMapper.selectAjaxTerminal(shopperId);
	}
	
	/**查询商户绑定的终端数量
	 * @param shopperId
	 * @param agentId
	 * @return
	 */
	public String selectTerminalCount(String shopperId) {
		String tercount=b2cTerminalMapper.selectTerminalCount(shopperId);
		return  tercount!=null&&!"".equals(tercount)?tercount:"0";
	}
	
	/**添加终端
	 * @param shopperid
	 * @param bindTerminal
	 * @throws Exception
	 */

	/**查询中间表的终端信息
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @throws Exception
	 */
	public  B2cTempTermBinder selectByTempBinder(String terNo){
		return b2cTempTermBinderMapper.selectByTempBinder(terNo);
	}
	/**修改绑定终端中间表的
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @throws Exception
	 */
	public void updateTermBinder(B2cTempTermBinder b2cTempTermBinder){
		
		b2cTempTermBinderMapper.updateTermBinder(b2cTempTermBinder);
	}
	
	/**
	 * 将A集合与B集合进行比较，返回A集合中不包含B集合的元素集合
	 * @param arg0
	 * @param arg1
	 * @return
	 */
	public List<String> compareList(String[] arg0, String[] arg1) {
		List<String> startList = transformList(arg0);
		List<String> endList = transformList(arg1);
		for (int i = 0; i < startList.size(); i++) {
			String start = (String) startList.get(i);
			for (int k = 0; k < endList.size(); k++) {
				String end = (String) endList.get(k);
				if ((start).equals(end)) {
					startList.remove(i);
					i = i - 1;
				}
			}
		}
		return startList;
	}
	
	/**
	 * 将数组转换成集合
	 * @param arg0 
	 * @return
	 */
	public List<String> transformList(String[] arg0){
		List<String> transList = new ArrayList<String>();
		for (int i = 0; i < arg0.length; i++) {
			transList.add(i, arg0[i]);
		}
		return transList;
	}
	public void updateBindTerminal( String bindTerminal,String hiddNum)throws Exception {
		 String[] hiddenNum=hiddNum.split(",");
		if(bindTerminal==null || StringUtils.isEmpty(bindTerminal)){
		    for (int i = 0; i < hiddenNum.length; i++) {
			    B2cTempTermBinder termBinder=b2cTempTermBinderMapper.selectByTempBinder(hiddenNum[i]);
				if(termBinder!=null){
					b2cTempTermBinderMapper.deleteByTermno(termBinder.getTermNo());
				}else{
				    B2cTermBinder  b2cTermBinder=b2cTermBinderMapper.selectOneBinder(hiddenNum[i]);
				    if(b2cTermBinder!=null && b2cTermBinder.getStatus().equals("0")){
					    b2cTermBinder.setStatus("1");
					    b2cTermBinderMapper.updateIsBinder(b2cTermBinder);
				    }else{
				    	System.out.println("dd");
				    }
				}
		    }
			}else{
		    String[] bindTerminals=bindTerminal.split(",");
			List<String> bindter=compareList(hiddenNum,bindTerminals);
			if(bindter.size()>0){
				for(int j=0;j<bindter.size();j++){
				    B2cTermBinder  b2cTermBinder=b2cTermBinderMapper.selectOneBinder(bindter.get(j));
				    if(b2cTermBinder!=null && b2cTermBinder.getStatus().equals("0")){
					    b2cTermBinder.setStatus("1");
					    b2cTermBinderMapper.updateIsBinder(b2cTermBinder);
				    }
				    else{
				        B2cTempTermBinder termBinder=b2cTempTermBinderMapper.selectByTempBinder(bindter.get(j));
				        if(termBinder!=null){
				            b2cTempTermBinderMapper.deleteByTermno(termBinder.getTermNo());
				        }
				    }
				}
			}
			if(bindTerminals.length>0){
				for(int i=0;i<bindTerminals.length;i++){
					B2cTempTermBinder termBinder=b2cTempTermBinderMapper.selectByTempBinder(bindTerminals[i]);
					if(termBinder!=null){
						termBinder.setStatus("1");
						b2cTempTermBinderMapper.updateTermBinder(termBinder);
					}else{
					    B2cTermBinder  b2cTermBinder=b2cTermBinderMapper.selectOneBinder(bindTerminals[i]);
					    if(b2cTermBinder!=null && b2cTermBinder.getStatus().equals("1")){
						    b2cTermBinder.setStatus("0");
						    b2cTermBinderMapper.updateIsBinder(b2cTermBinder);
					    }else{
					    	System.out.println("dd");
					    }
					}
				}
			}
	    }
	  
	}
	/**添加终端
	 * @param shopperid
	 * @param bindTerminal
	 * @throws Exception
	 */
	public void insertBindTerminal(String shopperId, String bindTerminal)throws Exception {
		b2cTermBinderMapper.deleteByShopperId(shopperId);
		String[] bindTerminals=bindTerminal.split(",");
		if(bindTerminals.length>0){
			for(int i=0;i<bindTerminals.length;i++){
				B2cTermBinder b2cTermBinder=new B2cTermBinder();
				b2cTermBinder.setMerchantNo(shopperId);
				b2cTermBinder.setTermNo(bindTerminals[i]);
				b2cTermBinder.setCreateDate(new Date());
				b2cTermBinderMapper.insert(b2cTermBinder);
			}
		}
	}
	/**
	 * @param shopperId
	 * @return
	 */
	public List<B2cTermBinder> selectByB2cTermBinderList(String shopperId) {
		return b2cTermBinderMapper.selectByB2cTermBinderList(shopperId);
	}
	/**注册
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @throws Exception
	 */
	public void saveReg( B2cShopperbiTemp b2cShopperbi,B2cShopperbargainTemp b2cShopperbargain,
			MposPhotoTmp photo1,MposApplicationProgress  pro,String[] fees,String[] topamounts) throws Exception {
	/*	mposphototmpmapper.insertSelective(photo1);*/
		b2cShopperbi.setPhotoid(photo1.getPhotoId().longValue());
		insertB2cShopperbi(b2cShopperbi);
	//	insertB2cShopperbargain(b2cShopperbargain);
		progressmapper.insertSelective(pro);
		
		if(fees.length>0&&fees!=null){
			for(int i=0;i<fees.length;i++){
				String fee1=fees[i];
				double   d   =   Double.parseDouble(fee1);
				String fee=ToolsUtils.div(d, 100, 4);
				if(com.uns.util.StringUtils.isTrimNotEmpty(fee)){
					MposMerchantFee mposMerchantFee=new MposMerchantFee();
					mposMerchantFee.setShopperid(b2cShopperbi.getShopperid());
					mposMerchantFee.setFee(fee);
					mposMerchantFee.setTopAmount(topamounts[i]);
					mposMerchantFee.setStatus(Constants.CON_YES);
					mposMerchantFee.setCreateDate(new Date());
					mposMerchantFeeMapper.insertSelective(mposMerchantFee);
				}
			}
		}
	}
	public void deleteTempTermianl(String termNo) {
		b2cTempTermBinderMapper.deleteByTermno(termNo);
		
	}
	public List selectByMuserid(String userName) {
		return b2cShopperbiTempMapper.selectByMuserid(userName);
	}
	
	
	public B2cShopperbiTemp findtelbyscompany(String scompany){
		List list=b2cShopperbiTempMapper.findtelbyscompany(scompany);
		B2cShopperbiTemp shopper=null;
		if(list!=null&&list.size()>0){
			shopper=(B2cShopperbiTemp)list.get(0);
		}
		return shopper;  
	}
	 
	 
	
	 
	 
	 
	

		
		/** 查询行业
		 * @return
		 *//*
		public List<B2cDict> searchBank()throws Exception {
			List<B2cDict> list=b2cdictmapper.searchDictBank();
			return list;
		}*/
		//通过行业名查行业
	public B2cDict findbyB2Cname(String bank)throws Exception{
		List list=b2cdictmapper.findbyB2Cname(bank);
		B2cDict industry=null;
		if(list!=null&&list.size()>0){
			industry=(B2cDict)list.get(0);
		}
		return industry; 
	}
	
	public B2cDict findbyhCname(String industryType)throws Exception{
		List list=b2cdictmapper.findbyhCname(industryType);
		B2cDict industry=null;
		if(list!=null&&list.size()>0){
			industry=(B2cDict)list.get(0);
		}
		return industry; 
	}
	//ajax tel
	public B2cShopperbiTemp findtelajax(String tel,String shopperName,String identityId) {
	    Map map=new HashMap();       
	    map.put("tel", tel);
	    map.put("shopperName", shopperName);
	    map.put("identityId", identityId);
	    return b2cShopperbiTempMapper.findtelajax(map);
	}
	 //添加
	public void insertmerchant(B2cShopperbiTemp shopper) {
		b2cShopperbiTempMapper.insertSelective(shopper);
			
	}
	 //通过ID查询
	 
	public B2cShopperbiTemp findmerchantbyNo(String b2cShopperbiId) {
		List list=b2cShopperbiTempMapper.findmerchantbyNo(b2cShopperbiId);
		B2cShopperbiTemp shopper=null;
		if(list!=null&&list.size()>0){
			shopper=(B2cShopperbiTemp)list.get(0);
		}
		return shopper;
	}
	public void savemerchant( B2cShopperbiTemp shopper)  throws BusinessException{
		try{
			shopper.setUpdated(new Date());
			b2cShopperbiTempMapper.updateByPrimaryKeySelective(shopper);  
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	 
	public Area findcityname (String provinceCode,String cityCode){
		Map map=new HashMap();       
	    map.put("provinceCode", provinceCode);
	    map.put("cityCode", cityCode);
	    List list=(List) areaMapper.findcityname(map);
	    Area are=null;
	    if(list!=null&&list.size()>0){
			are=(Area)list.get(0);
	    }
		return are;
	}
	
	 //是否已经注册
	public B2cShopperbi findregajax(String tel,String shopperName,String identityId) {
		Map map=new HashMap();       
		map.put("tel", tel);
		map.put("shopperName", shopperName);
		map.put("identityId", identityId);
		return b2cShopperbiMapper.findregajax(map);
	}
	 
	 /**
	  * 根据商户号查询注册商户信息
	  * @param b2cShopperbiId 商户号
	  * @return
	  */
	public B2cShopperbiTemp findShopperbiTempByShopperid(String shopperbiId) {
		return b2cShopperbiTempMapper.findShopperbiTempByShopperid(shopperbiId);
	}
	 
	public B2cShopperbi findtelbytel(String tel){
		List list=b2cShopperbiMapper.findtelbytel(tel);
		B2cShopperbi shopper=null;
		if(list!=null&&list.size()>0){
			shopper=(B2cShopperbi)list.get(0);
		}
		return shopper;  
	}
	 
	
	 
	public Area findcity (String cityname){
		 
		List list=areaMapper.findcity(cityname);
		Area area=null;
		if(list!=null&&list.size()>0){
			area=(Area)list.get(0);
		}
		return area; 
	}
	 

	public B2cShopperbi findbyid(String identityId){
		List list=b2cShopperbiMapper.findbyid(identityId);
		B2cShopperbi shopper=null;
		if(list!=null&&list.size()>0){
			shopper=(B2cShopperbi)list.get(0);
		}
		return shopper;  
	}
  	
  	public Area findbyname(String provincialname,String cityname){
  		Map map=new HashMap();       
        map.put("provincialname", provincialname);
        map.put("cityname", cityname);
        List list=(List) areaMapper.findbyname(map);
        Area are=null;
        if(list!=null&&list.size()>0){
			are=(Area)list.get(0);
		}
		return are;
       	      
   	}
  
  
  	public Area findbyareaid(String provincial,String city){
  		Map map=new HashMap();       
        map.put("provincial", provincial);
        map.put("city", city);
        List list=(List) areaMapper.findbyareaid(map);
        Area are=null;
        if(list!=null&&list.size()>0){
			are=(Area)list.get(0);
		}
		return are;
       	      
  	}
  	public void saveorinsertprogress(B2cShopperbiTemp shopper,MposApplicationProgress progress) {
		shopper.setUpdated(new Date());
		b2cShopperbiTempMapper.updateByPrimaryKeySelective(shopper);
		progressmapper.insertSelective(progress);
	}
  	/*public void insershopperorprogress(MposPhotoTmp photo,B2cShopperbiTemp shopper,MposApplicationProgress progress,B2cShopperbargainTemp bar,MposRemoteInvitation remote1,String fee) {
  		mposphototmpmapper.insertSelective(photo);
		shopper.setPhotoid(Long.valueOf(photo.getPhotoId()));
  		b2cShopperbiTempMapper.insert(shopper);
  		MposMerchantFee merchantfee = new MposMerchantFee();
		String[] str = fee.split("\\|");
		for (int i = 0; i < str.length; i++) {
			String a = str[i];
			String fee1 = a.substring(0, a.indexOf(','));
			String top = a.substring(a.indexOf(',') + 1, a.length());
			merchantfee.setFee(fee1);
			merchantfee.setTopAmount(top);
			merchantfee.setStatus(Constants.TYPE_1);
			merchantfee.setCreateDate(new Date());
			merchantfee.setShopperid(shopper.getShopperid());
			feemapper.insertSelective(merchantfee);
		}
  		
  		progress.setPhotoId(photo.getPhotoId());
		progressmapper.insertSelective(progress);
		remotemapper.updateByPrimaryKeySelective(remote1);
		bartemp.insert(bar);
	}
  	*/
  	
  	
	public void insershopperorprogress1(B2cShopperbiTemp shopper,MposApplicationProgress progress,B2cShopperbargainTemp bar,MposRemoteInvitation remote1,String fee) {
  		
  		b2cShopperbiTempMapper.insert(shopper);
  		MposMerchantFee merchantfee = new MposMerchantFee();
		String[] str = fee.split("\\|");
		for (int i = 0; i < str.length; i++) {
			String a = str[i];
			String fee1 = a.substring(0, a.indexOf(','));
			String top = a.substring(a.indexOf(',') + 1, a.length());
			merchantfee.setFee(fee1);
			merchantfee.setTopAmount(top);
			merchantfee.setStatus(Constants.TYPE_1);
			merchantfee.setCreateDate(new Date());
			merchantfee.setShopperid(shopper.getShopperid());
			mposMerchantFeeMapper.insertSelective(merchantfee);
		}
  		 	
		progressmapper.insertSelective(progress);
		remotemapper.updateByPrimaryKeySelective(remote1);
		//bartemp.insert(bar);
	}
	
	

	/**
	 * @param shopper
	 * @param progress
	 * @param bar
	 * @param remote1  注册商户2.0.0版 zt
	 * @param fee
	 */
	public void saveshopper(B2cShopperbiTemp shopper,MposApplicationProgress progress,MposRemoteInvitation remote1) {
		shopper.setIsformal(new Short(Constants.STATUS1));
		Users user=new Users();
		Users usres=saveUsers(user,shopper);
		usersMapper.insert(usres);
		b2cShopperbiTempMapper.insert(shopper);
  		b2cShopperbiMapper.insert(shopper);
		progressmapper.insertSelective(progress);
		remotemapper.updateByPrimaryKeySelective(remote1);
		
	}
  	
  	/*public void insertsbar(MposPhotoTmp photo,B2cShopperbiTemp shopper,B2cShopperbargainTemp bar,MposApplicationProgress progress,String fee) {
  		mposphototmpmapper.insertSelective(photo);
		shopper.setPhotoid(Long.valueOf(photo.getPhotoId()));
  		b2cShopperbiTempMapper.insert(shopper);
  		MposMerchantFee merchantfee = new MposMerchantFee();
		String[] str = fee.split("\\|");
		for (int i = 0; i < str.length; i++) {
			String a = str[i];
			String fee1 = a.substring(0, a.indexOf(','));
			String top = a.substring(a.indexOf(',') + 1, a.length());
			merchantfee.setFee(fee1);
			merchantfee.setTopAmount(top);
			merchantfee.setStatus(Constants.TYPE_1);
			merchantfee.setCreateDate(new Date());
			merchantfee.setShopperid(shopper.getShopperid());
			feemapper.insertSelective(merchantfee);
		}
  		
  		progress.setPhotoId(photo.getPhotoId());
		progressmapper.insertSelective(progress);
		bartemp.insert(bar);
	}*/
  	
	public void insertsbar1(B2cShopperbiTemp shopper,MposApplicationProgress progress,String fee) {

  	/*	MposMerchantFee mposmerchantfeetemp = new MposMerchantFee();
		String[] str = fee.split("\\|");
		for (int i = 0; i < str.length; i++) {
			String a = str[i];
			String fee1 = a.substring(0, a.indexOf(','));
			String top = a.substring(a.indexOf(',') + 1, a.length());
			double   d   =   Double.parseDouble(fee1);
			String fees=ToolsUtils.div( d, 1, 4);
			mposmerchantfeetemp.setFee(fees);
			mposmerchantfeetemp.setTopAmount(top);
			mposmerchantfeetemp.setStatus(Constants.TYPE_1);
			mposmerchantfeetemp.setCreateDate(new Date());
			mposmerchantfeetemp.setShopperid(shopper.getShopperid());
			mposMerchantFeeMapper.insertSelective(mposmerchantfeetemp);
		}*/
  		b2cShopperbiTempMapper.insert(shopper);
  		insertMerchantFeeList(shopper.getShopperid());
		progressmapper.insertSelective(progress);
	}
  	
	public void insertMerchantFeeList(Long shopperid) {
		mposMerchantFeeMapper.deleteByshopperid(shopperid);
		
		
		MposMerchantFee mposDebitfee=new MposMerchantFee();
		mposDebitfee.setShopperid(Long.valueOf(shopperid));
		mposDebitfee.setFeetype(Constants.CON_NO);//借记卡
		mposDebitfee.setFee(ToolsUtils.div(Double.parseDouble("0.0065"), 1, 4)+"");
		mposDebitfee.setCreateDate(new Date());
		mposDebitfee.setStatus(Constants.CON_YES);
		mposDebitfee.setD0fee(ToolsUtils.div(Double.parseDouble("0.0007"), 1, 4)+"");

		MposMerchantFee mposCreditFee=new MposMerchantFee();
		mposCreditFee.setShopperid(Long.valueOf(shopperid));
		mposCreditFee.setFeetype(Constants.CON_YES);//借记卡
		mposCreditFee.setFee(ToolsUtils.div(Double.parseDouble("0.0065"), 1, 4)+"");
		mposCreditFee.setCreateDate(new Date());
		mposCreditFee.setStatus(Constants.CON_YES);
		mposCreditFee.setD0fee(ToolsUtils.div(Double.parseDouble("0.0007"), 1, 4)+"");
		
		MposMerchantFee mweChatfee=new MposMerchantFee();
		mweChatfee.setShopperid(Long.valueOf(shopperid));
		mweChatfee.setFeetype(Constants.STATUS2);//
		mweChatfee.setFee(ToolsUtils.div(Double.parseDouble("0.0047"), 1, 4)+"");
		mweChatfee.setCreateDate(new Date());
		mweChatfee.setStatus(Constants.CON_YES);
		mweChatfee.setD0fee(ToolsUtils.div(Double.parseDouble("0.0049"), 1, 4)+"");
		
		MposMerchantFee mposAliPayFee=new MposMerchantFee();
		mposAliPayFee.setShopperid(Long.valueOf(shopperid));
		mposAliPayFee.setFeetype(Constants.STATUS3);//借记卡
		mposAliPayFee.setFee(ToolsUtils.div(Double.parseDouble("0.0047"), 1, 4)+"");
		mposAliPayFee.setCreateDate(new Date());
		mposAliPayFee.setStatus(Constants.CON_YES);
		mposAliPayFee.setD0fee(ToolsUtils.div(Double.parseDouble("0.0049"), 1, 4)+"");
		
		mposMerchantFeeMapper.insertSelective(mposDebitfee);
		
		mposCreditFee.setId(mposDebitfee.getId());
		mposMerchantFeeMapper.insert(mposCreditFee);
		
		mweChatfee.setId(mposDebitfee.getId());
		mposMerchantFeeMapper.insert(mweChatfee);
		
		mposAliPayFee.setId(mposDebitfee.getId());
		mposMerchantFeeMapper.insert(mposAliPayFee);
		
	}
  	
  	
  	public void insertsbarb(B2cShopperbiTemp shopper,B2cShopperbargainTemp bar,MposApplicationProgress progress){
  		b2cShopperbiTempMapper.insert(shopper);
		progressmapper.insertSelective(progress);
  	}
  
  	public B2cShopperbiTemp findbytel(String tel){
  		List list=b2cShopperbiTempMapper.findbytel(tel);
  		B2cShopperbiTemp shopper=null;
		if(list!=null&&list.size()>0){
			shopper=(B2cShopperbiTemp)list.get(0);
		}
		return shopper;  
	}
	  
	 
	  /**查找进度
		 * @param b2cShopperbi
		 * @param type1
		 * @return
		 */
	public MposApplicationProgress findMposApplicationProgress(
			String shopperid, String type1) {
		Map map=new HashMap();
		map.put("shopperid",shopperid);
		map.put("applicationType", type1);
		return progressmapper.findMposApplicationProgress(map);
	}
		
		
		/**修改进度
		 * @param alp
		 */
	public void updateMposApplicationProgress(MposApplicationProgress alp) {
		progressmapper.updateSelective(alp);
	}
		/**保存或修改进度表
		 * @param b2cShopperbi
		 * @param applicationType
		 */
	public void  saveOrUpdateProgress(B2cShopperbiTemp b2cShopperbi,String applicationType){
		//在进度表中插入数据
		MposApplicationProgress  alp=findMposApplicationProgress(b2cShopperbi.getShopperid().toString(),applicationType);
		if(alp!=null){
			alp.setApplicationStatus(Constants.TYPE_1);
			alp.setApplicationRemark(b2cShopperbi.getRemark());
			alp.setUpdateDate(new Date());
			updateMposApplicationProgress(alp);
		}else{
			alp=new MposApplicationProgress();
			Agent ag=agentMapper.searchAgentByShopperid(b2cShopperbi.getShopperidP().toString());
			alp.setShopperid(b2cShopperbi.getShopperid().toString());
			alp.setScompany(b2cShopperbi.getScompany());
			alp.setShopperidP(b2cShopperbi.getShopperidP().toString());
			alp.setAgentName(ag.getScompany());
			String theme=getThemeByType(applicationType);
			alp.setApplicationTheme(theme);
			alp.setApplicationType(applicationType);
			alp.setApplicationStatus(Constants.TYPE_1);
			alp.setApplicationRemark(b2cShopperbi.getRemark());
			alp.setCreateDate(new Date());
			progressmapper.insertSelective(alp);
		}
		
	}
		
		/**根据状态获取主题
		 * @param applicationType
		 * @return
		 */
	private String getThemeByType(String applicationType) {
		String theme="";
		if(applicationType.equals(Constants.TYPE_1)){
			theme="商户开通";
		}else if(applicationType.equals(Constants.TYPE_2)){
			theme="变更商户信息";
		}else if(applicationType.equals(Constants.TYPE_3)){
			theme="变更开户信息";
		}else if(applicationType.equals(Constants.TYPE_4)){
			theme="变更终端信息";
		}else if(applicationType.equals(Constants.TYPE_5)){
			theme="变更证照";
		}
		return theme;
	}
		/**修改进度状态
		 * @param b2cShopperbi
		 * @param type
		 */
	public void updateProgress(String shopperid, String type,String status,String remark) {
		MposApplicationProgress  alp=findMposApplicationProgress(shopperid,type);
		if(alp!=null){
			alp.setApplicationStatus(status);
			alp.setApplicationRemark(remark);
			updateMposApplicationProgress(alp);
		}
	}
	/**修改终端
	 * @param bindTerminal
	 * @param hiddNum
	 * @param shopperbi
	 * @throws Exception
	 */
	public void updateTerminal(String bindTerminal, String hiddNum,
			B2cShopperbiTemp shopperbi) throws Exception {
		updateBindTerminal(bindTerminal,hiddNum);
		b2cShopperbiTempMapper.updateByShopperId(shopperbi);
		//修改申请进度
		saveOrUpdateProgress(shopperbi,Constants.TYPE_4);
		
	}
	
	public MposPhotoTmp selectPhotoTmpById(Long id){
		return mposphototmpmapper.selectByPrimaryKey(new BigDecimal(id));
	}
	
	/**变更证照信息
	 * @param map
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @throws Exception 
	 */
	public void updatePhoto(MposPhotoTmp photo1,MposApplicationProgress  pro) throws Exception {
		mposphototmpmapper.updatePhotoTmpById(photo1);
		progressmapper.insertSelective(pro);
	}
	
	public void updatePhoto1(Map maphoto, MposApplicationProgress pro,String photoid,B2cShopperbiTemp b2cShopperbi)
			throws Exception {
		MposPhotoTmp photo =mposphototmpmapper.findbyphotoid(photoid) ;
		String s1 = (String) maphoto.get("signaturePhotoph");
		String s2 = (String) maphoto.get("handIdentityph");
		String s3 = (String) maphoto.get("frontIdentityph");
		String s4 = (String) maphoto.get("reverseIdentityph");
		String s5 = (String) maphoto.get("storePhotoph");
		String s7 = (String) maphoto.get("licensePhotoph");
		String s8 = (String) maphoto.get("instorePhotoph");
		String s9 = (String) maphoto.get("creditCardPhotop");
		String s10 = (String) maphoto.get("settlementCardPhotop");

		if (s1 != null) {
			photo.setSignaturePhoto(s1);
		}
		if (s2 != null) {
			photo.setHandIdentityCardPhoto(s2);
		}
		if (s3 != null) {
			photo.setFrontIdentityCardPhoto(s3);
		}
		if (s4 != null) {
			photo.setReverseIdentityCardPhoto(s4);
		}
		if (s5 != null) {
			photo.setStorePhoto(s5);
		}
		if (s7 != null) {
			photo.setLicensePhoto(s7);
		}
		if (s8 != null) {
			photo.setInstorePhoto(s8);
		}
		if (s9 != null) {
			photo.setCreditCardPhoto(s9);
		}
		if (s10 != null) {
			photo.setSettlementCardPhoto(s10);
		}

		mposphototmpmapper.updatePhotoTmpById(photo);
		
		b2cShopperbi.setPhotoCheckFlag("0");
		this.b2cShopperbiTempMapper.updateByShopperId(b2cShopperbi);
		 MposApplicationProgress ap=this.findMposApplicationProgress(b2cShopperbi.getShopperid().toString(),"5");
		if(ap==null){
			progressmapper.insertSelective(pro);
		}
		
	}
	
	
	public String selectevicenumCount(ShopPerbiForm shopPerbiForm){
		String ckCount = b2cShopperbiTempMapper.selectevicenumCount(shopPerbiForm);
		return ckCount!=null&&!"".equals(ckCount)?ckCount:"0";
	}

	
	/**
	 * 根据商户号查询费率
	 * @param shopperid
	 * @return
	 */
	public List<HashMap> selectFeeByShopperid(Long shopperid){
		return mposMerchantFeeMapper.selectByMerchantId(shopperid);
	}
	
	public List<HashMap> selectFeeByShopperid1(Long shopperid){
		return mposMerchantFeeMapper.selectByMerchantId1(shopperid);
	}
	
	public int insertbinder(B2cTempTermBinder binder){
		return b2cTempTermBinderMapper.insert(binder);
	}
	
	public Map findHisTranList(String merchantNo, String tPage, HttpServletRequest request) throws IllegalAccessException, InvocationTargetException {
		if (StringUtils.isEmpty(tPage) || !StringUtils.isNumeric(tPage)){
			tPage = "1";
		}
		int currentPage = Integer.valueOf(tPage);
		Page page  = new Page();

		PageContext context = PageContext.getContext();
		page.setCurrentPage(currentPage);
		BeanUtils.copyProperties(context, page);
		context.setPageSize(Constants.page_size);
		context.setPagination(true);
		
		
		List list=b2cTermBinderMapper.findbinderList(merchantNo);
		
		Map map=new HashMap();
		map.put("list", list);
		map.put("page", context.getCurrentPage());
		map.put("pages",context.getTotalPages());
		map.put("count",context.getTotalRows());
		return map;
	}
	
	public B2cTempTermBinder findbyterm(String deviceNum){
		B2cTempTermBinder binder=b2cTempTermBinderMapper.selectByTempBinder(deviceNum);
  		
		return binder;  
	}
	
	public B2cShopperbiTemp findbysid(String identityId){
		List list=b2cShopperbiTempMapper.findbysid(identityId);
		B2cShopperbiTemp shopper=null;
		if(list!=null&&list.size()>0){
			shopper=(B2cShopperbiTemp)list.get(0);
		}
		return shopper;  
	}
	
	
	

	public B2cShopperbiTemp findbyshopperid(String shopperid){
		List list=b2cShopperbiTempMapper.findbyshopperid(shopperid);
		B2cShopperbiTemp shopper=null;
		if(list!=null&&list.size()>0){
			shopper=(B2cShopperbiTemp)list.get(0);
		}
		return shopper;  
	}
	
	public List<B2cShopperbi> judgeShopper(Map<String,Object> map){
		return b2cShopperbiMapper.judgeShopper(map);
	}
	
	public void updateB2cShopperbiTemp(B2cShopperbiTemp b2cShopperbi) {
		b2cShopperbiTempMapper.updateByPrimaryKeySelective(b2cShopperbi);
		
	}
	
	/**
	 * 查询备份表
	 * @param shopperid
	 * @return
	 */
	public BackupsShopperInformation  findbkshopper(BigDecimal shopperid){
		return this.bkshoppermapper.findByshopperid(shopperid);
	}
	
	/**查询交易手续费
	 * @return
	 */
	public MposMerchantFee querymerchantfee(String shopperid)throws Exception{
		List list=mposMerchantFeeMapper.findfee(Long.valueOf(shopperid));
		
		MposMerchantFee merchantfee=null;
		if(list!=null&&list.size()>0){
			merchantfee=(MposMerchantFee)list.get(0);
		}
		return merchantfee; 
		
	}
	
	public AgentTopFee findTopFee()throws Exception{
		return this.agenttopfeemapper.findbyid();
	}
	
	
	public void saveagent(Agent agent,Map param,Users user) throws Exception{
		this.agentMapper.addAgent(agent);
		this.agentMapper.insertUpdateAgentfeeAlog(param);
		this.usersMapper.insert(user);
	}
	
	
	/**
	 * 1.现在历史表中插入删除记录
	 * 2.修改远程邀请表(已提交的改为已撤回)
	 * 3.删除记录
	 */
	public void deleteShopperbi(B2cShopperbiTemp b2cShopperbiTemp) {
		b2cShopperbiTempMapper.updateByShopperId(b2cShopperbiTemp);
		b2cShopperbiTempHistoryMapper.insert(b2cShopperbiTemp);
		Map map=new HashMap();
		map.put("status", Constants.STATUS3);
		map.put("tel", b2cShopperbiTemp.getStel());
		map.put("statusq", Constants.STATUS2);
		mposRemoteInvitationMapper.updateByTel(map);
		
		mposMerchantFeeMapper.deleteByshopperid(b2cShopperbiTemp.getShopperid());
		b2cShopperbiTempMapper.deleteByPrimaryKey(new BigDecimal(b2cShopperbiTemp.getB2cShopperbiId()));
		progressmapper.deleteByPrimaryKey(b2cShopperbiTemp.getShopperid().toString());
	}
	
	public Users selectUsersByAgentNo(String merchantid){
		Users user = usersMapper.selectUsersByAgentNo(merchantid);
		return user;
	}
	
	
	public List<HashMap>  findbyshopper(String shopperid){
		return b2cShopperbiTempMapper.findbyshopper(shopperid);
		
	}
	
	
	public void savefee(MposMerchantFee merchantfee ){
		mposMerchantFeeMapper.insertSelective(merchantfee);
	}

	
	
	/**绑定终端
	 * @param b2cTempTermBinder
	 * @param b2cTermBinder
	 */
	public void insertTermBinder(B2cTempTermBinder b2cTempTermBinder,
		B2cTermBinder b2cTermBinder) {
		b2cTempTermBinderMapper.insert(b2cTempTermBinder);
		b2cTermBinderMapper.insertSelective(b2cTermBinder);
		
	}
	public List findMposMerchantFee(String shopperid) {
		return mposMerchantFeeMapper.findMposMerchantFee(shopperid);
	}
	public List findDiveceNo(String merchantNo) {
		
		return b2cTermBinderMapper.findDiveceNo(merchantNo);
	}
	
	
	public FixAmaount searchFixAmaount()throws Exception {
		List<FixAmaount> list=fixamountMapper.searchFixAmaount();
		
		FixAmaount fixamount=null;
		if(list!=null&&list.size()>0){
			fixamount=(FixAmaount)list.get(0);
		}
		return fixamount;
	}
	
	
	/**保存用户名密码
	 * @param user
	 * @param b2cShopperbi
	 * @return
	 */
	private Users saveUsers(Users user, B2cShopperbiTemp b2cShopperbi) {
		user.setMerchantid(b2cShopperbi.getShopperid());
		user.setUserName(b2cShopperbi.getMuserid());
		user.setPassword(b2cShopperbi.getMpassword());
		user.setTel(b2cShopperbi.getStel());
		user.setEnabled(Short.valueOf(Constants.CON_YES));
		user.setCreatedate(new Date());
		user.setLocked(Long.valueOf(b2cShopperbi.getSifpactid()==null?Constants.CON_NO:b2cShopperbi.getSifpactid().toString()));
		user.setIsAgent(Short.valueOf(Constants.CON_NO));
		return user;
	}
	public void updateB2cShopperbiTempSmsCode(B2cShopperbiTemp b2cShopperbi) {
		b2cShopperbiTempMapper.updateB2cShopperbiTempSmsCode(b2cShopperbi);
		
	}

	public String findFisrtAgentByNo(String shopperid) {
		return agentMapper.findFisrtAgentByNo(shopperid);
	}
	
	/**服务商面签 保存费率
	 * @param shopper
	 * @param progress
	 * @param debitfee
	 * @param creditfee
	 * @param weChatT1fee
	 * @param aliPayT1Fee
	 * @param weChatD0fee
	 * @param aliPayD0Fee
	 */
	public void insertMerchant(B2cShopperbiTemp shopper,
			MposApplicationProgress progress, String debitfee, String creditfee,
			String weChatT1fee, String aliPayT1Fee, String weChatD0fee, String aliPayD0Fee) {
		
		//删除已存在的之前注册的数据
		mposMerchantFeeMapper.deleteByshopperid(shopper.getShopperid());
		
		MposMerchantFee mposDebitfee=new MposMerchantFee();
		mposDebitfee.setShopperid(shopper.getShopperid());
		mposDebitfee.setFeetype(Constants.CON_NO);//借记卡
		mposDebitfee.setFee(debitfee);
		mposDebitfee.setCreateDate(new Date());
		mposDebitfee.setStatus(Constants.CON_YES);
		mposDebitfee.setD0fee(ToolsUtils.div(Double.parseDouble(shopper.getT0fee()==null?"0":shopper.getT0fee().toString()), 1, 4)+"");
		
		MposMerchantFee mposCreditFee=new MposMerchantFee();
		mposCreditFee.setShopperid(shopper.getShopperid());
		mposCreditFee.setFeetype(Constants.CON_YES);//贷记卡
		mposCreditFee.setFee(creditfee);
		mposCreditFee.setCreateDate(new Date());
		mposCreditFee.setStatus(Constants.CON_YES);
		mposCreditFee.setD0fee(ToolsUtils.div(Double.parseDouble(shopper.getT0fee()==null?"0":shopper.getT0fee().toString()), 1, 4)+"");
		
	
		MposMerchantFee mweChatfee=new MposMerchantFee();
		mweChatfee.setShopperid(shopper.getShopperid());
		mweChatfee.setFeetype(Constants.STATUS2);//
		mweChatfee.setFee(weChatT1fee);
		mweChatfee.setCreateDate(new Date());
		mweChatfee.setStatus(Constants.CON_YES);
		mweChatfee.setD0fee(weChatD0fee);
		
		MposMerchantFee mposAliPayFee=new MposMerchantFee();
		mposAliPayFee.setShopperid(shopper.getShopperid());
		mposAliPayFee.setFeetype(Constants.STATUS3);//借记卡
		mposAliPayFee.setFee(aliPayT1Fee);
		mposAliPayFee.setCreateDate(new Date());
		mposAliPayFee.setStatus(Constants.CON_YES);
		mposAliPayFee.setD0fee(aliPayD0Fee);
		
		mposMerchantFeeMapper.insertSelective(mposDebitfee);
		
		mposCreditFee.setId(mposDebitfee.getId());
		mposMerchantFeeMapper.insert(mposCreditFee);
		
		mweChatfee.setId(mposDebitfee.getId());
		mposMerchantFeeMapper.insert(mweChatfee);
		
		mposAliPayFee.setId(mposDebitfee.getId());
		mposMerchantFeeMapper.insert(mposAliPayFee);
		
		b2cShopperbiTempMapper.insert(shopper);
		progressmapper.insertSelective(progress);
		
	}
	/**
	 * 远程邀请保存费率
	 */
	public void saveMerchantFee(B2cShopperbiTemp shopper) {
		Map debitfeeMap =new HashMap();
		debitfeeMap.put("tel", shopper.getStel());
		debitfeeMap.put("feetype", Constants.CON_NO);
		MposRemoteFee debitfee=mposRemoteFeeMapper.findMposRemoteFee(debitfeeMap);
		
		MposMerchantFee mposDebitfee=new MposMerchantFee();
		mposDebitfee.setShopperid(shopper.getShopperid());
		mposDebitfee.setFeetype(Constants.CON_NO);//借记卡
		mposDebitfee.setFee(debitfee.getFee());
		mposDebitfee.setCreateDate(new Date());
		mposDebitfee.setStatus(Constants.CON_YES);
		mposDebitfee.setD0fee(ToolsUtils.div(Double.parseDouble(debitfee==null?"0":debitfee.getD0fee()==null?"0":debitfee.getD0fee().toString()), 1, 4)+"");
		
		Map creditfeeMap =new HashMap();
		creditfeeMap.put("tel", shopper.getStel());
		creditfeeMap.put("feetype", Constants.CON_YES);
		
		MposRemoteFee creditfee=mposRemoteFeeMapper.findMposRemoteFee(creditfeeMap);
		MposMerchantFee mposCreditFee=new MposMerchantFee();
		mposCreditFee.setShopperid(shopper.getShopperid());
		mposCreditFee.setFeetype(Constants.CON_YES);//借记卡
		mposCreditFee.setFee(creditfee.getFee());
		mposCreditFee.setCreateDate(new Date());
		mposCreditFee.setStatus(Constants.CON_YES);
		mposCreditFee.setD0fee(ToolsUtils.div(Double.parseDouble(creditfee==null?"0":creditfee.getD0fee()==null?"0":creditfee.getD0fee().toString()), 1, 4)+"");
		
		
		Map weChatfeeMap =new HashMap();
		weChatfeeMap.put("tel", shopper.getStel());
		weChatfeeMap.put("feetype", Constants.STATUS2);
		
		MposRemoteFee weChatfee=mposRemoteFeeMapper.findMposRemoteFee(weChatfeeMap);
		MposMerchantFee mweChatfee=new MposMerchantFee();
		mweChatfee.setShopperid(shopper.getShopperid());
		mweChatfee.setFeetype(Constants.STATUS2);//
		mweChatfee.setFee(weChatfee.getFee());
		mweChatfee.setCreateDate(new Date());
		mweChatfee.setStatus(Constants.CON_YES);
		mweChatfee.setD0fee(weChatfee.getD0fee());
		
		Map aliPayFeeMap =new HashMap();
		aliPayFeeMap.put("tel", shopper.getStel());
		aliPayFeeMap.put("feetype", Constants.STATUS3);
		
		MposRemoteFee aliPayFee=mposRemoteFeeMapper.findMposRemoteFee(aliPayFeeMap);
		MposMerchantFee mposAliPayFee=new MposMerchantFee();
		mposAliPayFee.setShopperid(shopper.getShopperid());
		mposAliPayFee.setFeetype(Constants.STATUS3);//借记卡
		mposAliPayFee.setFee(aliPayFee.getFee());
		mposAliPayFee.setCreateDate(new Date());
		mposAliPayFee.setStatus(Constants.CON_YES);
		mposAliPayFee.setD0fee(aliPayFee.getD0fee());
		
		mposMerchantFeeMapper.insertSelective(mposDebitfee);
		
		mposCreditFee.setId(mposDebitfee.getId());
		mposMerchantFeeMapper.insert(mposCreditFee);
		
		mweChatfee.setId(mposDebitfee.getId());
		mposMerchantFeeMapper.insert(mweChatfee);
		
		mposAliPayFee.setId(mposDebitfee.getId());
		mposMerchantFeeMapper.insert(mposAliPayFee);
		
	}
	

	public String findB2cDictQrPAY() {
		return b2cDictMapper.findB2cDictQrPAY();
	}
	
	public List<Map<String, Object>> findGatheringMethod() {
		return b2cDictMapper.findGatheringMethod();
	}
	public List findMposMerchantFeezhifu(String shopperid) {
		return mposMerchantFeeMapper.findMposMerchantFeezhifu(shopperid);
	}
	
	
	public void updateQrCode(String fixedQrCodeUrl,String merchantNo) {
		Map map=new HashMap();
		map.put("fixedQrCodeUrl", fixedQrCodeUrl);
		map.put("fixedQrCodeFlag", Constants.CON_YES);
		map.put("merchantNo", merchantNo);
		b2cShopperbiMapper.updateQrCode(map);
		b2cShopperbiTempMapper.updateQrCode(map);
	}
	
	public void updateb2cShopperbi(B2cShopperbiTemp b2cShopperbi) {
		Map map=new HashMap();
		map.put("qrPayNo", b2cShopperbi.getQrPayNo());
		map.put("qrpayMerchantkey", b2cShopperbi.getQrpayMerchantkey());
		map.put("merchantNo", b2cShopperbi.getShopperid());
		
		b2cShopperbiMapper.updateQrPayCode(map);
		b2cShopperbiTempMapper.updateQrPayCode(map);
	}
	
	public List findMerchantFee(Long shopperid) {
		return mposMerchantFeeMapper.findMerchantFee(shopperid);
	}
	public List findMerchantSkFee(Long shopperid ) {
		return mposMerchantFeeMapper.findMerchantSkFee(shopperid);
	}
	
	public B2cShopperbi selectModelByParam(Map<String, Object> map) throws Exception {
		
		return b2cShopperbiMapper.selectModelByParam(map);
	}
	/** mpos_merchant_fee_temp
	 * @param shopperId
	 * @param feeTypeDebit
	 * @param s0ChannelType
	 * @return
	 */
	public MposMerchantFee findTempFeeTChannelType(String shopperId, String feeTypeDebit, String s0ChannelType) {
		Map params=new HashMap();
		params.put("shopperId", shopperId);
		params.put("feeType", feeTypeDebit);
		params.put("channelType", s0ChannelType);
		return mposMerchantFeeMapper.findRomteFeeTChannelType(params);
	}
	/**按类型获取费率from MPOS_MERCHANT_TEMP
	 * @param feeType 费率类型
	 * @param shopperId 商户编号
	 */
	public MposMerchantFee findMposMerchantFeeTemp(String shopperId,String feeType) {
		Map<String, Object> paramsMap = new HashMap<String, Object>();
		paramsMap.put("shopperId", shopperId);
		paramsMap.put("feeType", feeType);
		List<MposMerchantFee> mposMerchantFeeTempList = mposMerchantFeeMapper.findMposMerchantFeeTempByType(paramsMap);
		if(mposMerchantFeeTempList!=null&&mposMerchantFeeTempList.size()>0){
			return mposMerchantFeeTempList.get(0);
		}else{
		    return null;
		}
	}
	/** MPOS_MERCHANT_FEE
	 * @param shopperId
	 * @param feeTypeDebit
	 * @param s0ChannelType
	 * @return
	 */
	public MposMerchantFee findMposMerchantFee(String shopperId, String feeTypeDebit, String s0ChannelType) {
		Map params=new HashMap();
		params.put("shopperId", shopperId);
		params.put("feeType", feeTypeDebit);
		params.put("channelType", s0ChannelType);
		return mposMerchantFeeMapper.findMerchantFeeTChannelType(params);
	}
	/**mpos_remote_fee
	 * @param shopperTel
	 * @param feeTypeDebit
	 * @param s0ChannelType
	 * @return
	 */
	public MposMerchantFee findMposRemoteFee(String shopperTel, String feeTypeDebit, String s0ChannelType) {
		MposMerchantFee mposMerchantFee = new MposMerchantFee();
		Map params=new HashMap();
		params.put("shopperTel", shopperTel);
		params.put("feeType", feeTypeDebit);
		params.put("channelType", s0ChannelType);
		List<Map<String, String>> mposRemoteFeeList = mposMerchantFeeMapper.findMposRemoteFeeByChannelType(params);
		if(mposRemoteFeeList!=null&&mposRemoteFeeList.size()>0){
			Map<String, String> map = mposRemoteFeeList.get(0);
			mposMerchantFee.setFee(map.get("fee"));
			mposMerchantFee.setD0fee(map.get("d0Fee"));
			return mposMerchantFee;
		}else{
			return null;
		}
	}
	/**按类型获取费率from MPOS_REMOTE_FEE
	 * @param feeType 费率类型
	 * @param shopperTel 商户电话
	 */
	public MposMerchantFee findMposRemoteFee(String shopperTel, String feeType) {
		MposMerchantFee mposMerchantFee = new MposMerchantFee();
		Map<String, Object> paramsMap = new HashMap<String, Object>();
		paramsMap.put("shopperTel", shopperTel);
		paramsMap.put("feeType", feeType);
		List<Map<String, String>> mposRemoteFeeList = mposMerchantFeeMapper.findMposRemoteFeeByType(paramsMap);
		if(mposRemoteFeeList!=null&&mposRemoteFeeList.size()>0){
			Map<String, String> map = mposRemoteFeeList.get(0);
			mposMerchantFee.setFee(map.get("fee"));
			mposMerchantFee.setD0fee(map.get("d0Fee"));
			return mposMerchantFee;
		}else{
			return null;
		}
	}
	
	/**按类型获取费率from MPOS_MERCHANT_FEE
	 * @param feeType 费率类型
	 * @param shopperId 商户编号
	 */
	public MposMerchantFee findMposMerchantFee(String shopperId, String feeType) {
		Map<String, Object> paramsMap = new HashMap<String, Object>();
		paramsMap.put("shopperId", new BigDecimal(shopperId));
		paramsMap.put("feeType", feeType);
		List<MposMerchantFee> mposMerchantFeeList = mposMerchantFeeMapper.findMposMerchantFeeByType(paramsMap);
		if(mposMerchantFeeList!=null&&mposMerchantFeeList.size()>0){
			return mposMerchantFeeList.get(0);
		}else{
		    return null;
		}
	}

	public List<B2cShopperbiTemp> findShopperTempList(ShopPerbiForm shopPerbiForm){
		PageContext.initPageSize(Constants.page_size);
		return b2cShopperbiTempMapper.findShopperTempList(shopPerbiForm);
	}

	/**
	 * 查询商户列表下载
	 * @param shopPerbiForm
	 * @return
	 */
	public List<HashMap> findShopperTempExportList(ShopPerbiForm shopPerbiForm){
		PageContext.initPageSize(Constants.page_size);
		return b2cShopperbiTempMapper.findShopperTempExportList(shopPerbiForm);
	}

	public List<Map<String, Object>> findShopperList(ShopPerbiForm mbForm) {
		List<Map<String, Object>> list = b2cShopperbiMapper.findShopperList(mbForm);
		return list;
	}
}
