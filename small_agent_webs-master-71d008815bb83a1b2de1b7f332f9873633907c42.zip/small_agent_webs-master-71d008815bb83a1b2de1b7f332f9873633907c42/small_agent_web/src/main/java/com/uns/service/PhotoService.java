package com.uns.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.dao.B2cShopperbiTempMapper;
import com.uns.dao.MposApplicationProgressMapper;
import com.uns.dao.MposPhotoTmpMapper;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.MposApplicationProgress;
import com.uns.model.MposPhotoTmp;

@Service
public class PhotoService {
	
	
	@Autowired
	private MposPhotoTmpMapper mposphototmpmapper;
	
	@Autowired
	private B2cShopperbiTempMapper b2cShopperbiTempMapper;
	


	@Autowired
	private MposApplicationProgressMapper progressmapper;
	 //添加
	 public void insertphoto(MposPhotoTmp photo) {
		 mposphototmpmapper.insertSelective(photo);
	}
	 
	 public void inserOrUpdatetphoto(MposPhotoTmp photo,String oldphotoid) {
		 mposphototmpmapper.insertSelective(photo);
		 Map map=new HashMap();
		 map.put("newphotoid", photo.getPhotoId());
		 map.put("oldphotoid", oldphotoid);
		 b2cShopperbiTempMapper.updateByphoto(map);
	}


	public void insertphotoAndshopper(MposPhotoTmp photo1,	B2cShopperbiTemp shopper,MposApplicationProgress progress) {
		mposphototmpmapper.insertSelective(photo1);
		shopper.setPhotoid(Long.valueOf(photo1.getPhotoId()));
		b2cShopperbiTempMapper.updateByPrimaryKeySelective(shopper);
		progress.setPhotoId(photo1.getPhotoId());
		progressmapper.updateByPrimaryKeySelective(progress);
		
	}

	
	
	public MposPhotoTmp findbsid(String sid){
	
		List list= mposphototmpmapper.findbysid(sid);
		MposPhotoTmp photo=null;
		if(list!=null&&list.size()>0){
			photo=(MposPhotoTmp)list.get(0);
		}
		return photo;
	}
	
	

	public MposPhotoTmp findbyphotoid(String photoid){
		return mposphototmpmapper.findbyphotoid(photoid);
	}
	
	 //添加
	 public void updatephoto(MposPhotoTmp photo) {
		 mposphototmpmapper.updatePhotoTmpById(photo);
			
		} 
}
