package com.uns.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.common.exception.BusinessException;
import com.uns.model.B2cDict;
@Repository
public interface B2cDictMapper {


	 /**根据分类编码，查询行业类型
	 * @param dictdlsid
	 * @return
	 */
	List<B2cDict> searchDictCls(String  dictclsid)throws BusinessException;
	
	/* (non-Javadoc)根据分类编码和外部编码，获取对象
	 */
	public List searchDictName(Map<String,String> map)throws BusinessException;
	
	/**
	 * 查询银行
	 */
	public List searchDictBank();
	/**
	 * 查询银行名字
	 */
	public B2cDict findDictBankName(String b2cDictId);
	
	
	
	
	List findbyB2Cname(String dict);
    
	
	List findbyhCname(String dict);
	
	public List queryBank();


	String findB2cDictQrPAY();

	List<Map<String, Object>> findGatheringMethod();

	public B2cDict findDictByBankName(String accountbankdictval);			
}