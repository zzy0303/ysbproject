package com.uns.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.uns.bean.PageBean;
import com.uns.common.page.PageContext;
import com.uns.dao.AgentOperatorMapper;
import com.uns.model.Users;
import com.uns.web.form.AgentUserForm;

@Component
public class AgentOperatorService {
	@Autowired
	private AgentOperatorMapper agentOperatorMapper;

	public void updateOperator(Users agentUser) {
		agentOperatorMapper.updateOperator(agentUser);
	}
	
	
	public PageBean getOperatorList(AgentUserForm form, int curPage) {
		PageContext.initPageSize(20);
		List<Users> agentUserList = agentOperatorMapper
				.findOperatorList(form);
		PageBean pageBean = new PageBean();
		pageBean.setData(agentUserList);
		pageBean.setCurPage(curPage);
		pageBean.setTotalCount(agentUserList.size());
		pageBean.setLength(20);
		pageBean.setTotalPage(agentUserList.size() / 20 + 1);
		return pageBean;
	}

	public void deleteOperator(String usercode) {
		agentOperatorMapper.deleteOperator(usercode);
	}

	public Users findOperatorByCode(Map map) throws Exception {
		List<Users> agentUser = (List<Users>) agentOperatorMapper.findOperatorByCode(map);
		if(agentUser!=null&&agentUser.size()>0){
			return agentUser.get(0);
		}
		return null;
		
	}
		
	
	public Users findOperatorByCodetel(Map map) throws Exception {
		List<Users> agentUser = (List<Users>) agentOperatorMapper.findOperatorByCodetel(map);
		if(agentUser!=null&&agentUser.size()>0){
			return agentUser.get(0);
		}
		return null;
		
	}

	
	public void updateUserByCode(Map params) {
		agentOperatorMapper.updateUserByCode(params);
	}

	public void addOperator(Map params) {
		agentOperatorMapper.addOperator(params);
	}
	
	public Users findUserByShopperid(Long merchantid){
		return agentOperatorMapper.findOperatorByShopperid(merchantid);
	}

	public void updateUserByMerchantId(Users user) {
		agentOperatorMapper.updateUserByMerchantId(user);
	}


	/**查询用户信息
	 * @param mbForm
	 * @return
	 */
	public List selectUsersList(AgentUserForm mbForm)throws Exception {
		PageContext.initPageSize(20);
		return agentOperatorMapper.selectByUsersList(mbForm);
	}


	public Users selectUsersById(Long userId) throws Exception {
		return agentOperatorMapper.selectUsersById(userId);
	}


	public void update(Users user) throws Exception {
		// TODO Auto-generated method stub
		agentOperatorMapper.update(user);
	}
}
