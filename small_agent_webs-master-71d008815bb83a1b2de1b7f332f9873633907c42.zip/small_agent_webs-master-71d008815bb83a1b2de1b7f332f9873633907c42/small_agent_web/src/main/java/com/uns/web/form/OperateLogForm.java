package com.uns.web.form;

public class OperateLogForm {
	 private String logid;

	    private String operatornum;

	    private String ip;

	    private String time;

	    private String permitid;

	    private String params;

	    private String url;

	    private Short permittype;

	    private String description;
	    
	    private String time_start;
	    
	    private String time_end;

		public String getLogid() {
			return logid;
		}

		public void setLogid(String logid) {
			this.logid = logid;
		}

		public String getOperatornum() {
			return operatornum;
		}

		public void setOperatornum(String operatornum) {
			this.operatornum = operatornum;
		}

		public String getIp() {
			return ip;
		}

		public void setIp(String ip) {
			this.ip = ip;
		}

		public String getTime() {
			return time;
		}

		public void setTime(String time) {
			this.time = time;
		}

		public String getPermitid() {
			return permitid;
		}

		public void setPermitid(String permitid) {
			this.permitid = permitid;
		}

		public String getParams() {
			return params;
		}

		public void setParams(String params) {
			this.params = params;
		}

		public String getUrl() {
			return url;
		}

		public void setUrl(String url) {
			this.url = url;
		}

		public Short getPermittype() {
			return permittype;
		}

		public void setPermittype(Short permittype) {
			this.permittype = permittype;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public String getTime_start() {
			return time_start;
		}

		public void setTime_start(String time_start) {
			this.time_start = time_start;
		}

		public String getTime_end() {
			return time_end;
		}

		public void setTime_end(String time_end) {
			this.time_end = time_end;
		}
}
