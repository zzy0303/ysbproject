package com.uns.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uns.util.*;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Base64;
import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.model.Agent;
import com.uns.model.Area;
import com.uns.model.B2cAgentBinder;
import com.uns.model.B2cDict;
import com.uns.model.B2cShopperbargain;
import com.uns.model.B2cShopperbargainTemp;
import com.uns.model.B2cShopperbi;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.B2cTempTermBinder;
import com.uns.model.B2cTermBinder;
import com.uns.model.B2cTerminal;
import com.uns.model.BackupsShopperInformation;
import com.uns.model.MposApplicationProgress;
import com.uns.model.MposMerchantFee;
import com.uns.model.MposPhotoTmp;
import com.uns.model.Users;
import com.uns.service.AgentService;
import com.uns.service.PhotoService;
import com.uns.service.ShopPerbiService;
import com.uns.web.form.ShopPerbiForm;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import net.sf.json.JSONObject;


@Controller("shopPerbiController")
@RequestMapping("/shopPerbi.htm")
public class ShopPerbiController extends BaseController {
	@Autowired
	private AgentService agentservice;
	
	@Autowired
	private ShopPerbiService shopPerbiService;
	
	@Autowired
	private PhotoService  photoservice;
	
	private String sep = File.separator;
	
	String basePath=DynamicConfigLoader.getByEnv("PATH");
	
	String PHOTO_URL=DynamicConfigLoader.getByEnv("PHOTO_URL");
	
	String UPDATE_PHOTO=DynamicConfigLoader.getByEnv("UPDATE_PHOTO_URL");
	
	String IMAGE_GET_URL=DynamicConfigLoader.getByEnv("IMAGE_GET_URL");
	
	
	/**商户查询
	 * @param request
	 * @param b2cShopperbiTmp
	 * @param b2cShopperbargainTmp
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=shopPerbiManageList")
	public String shopPerbiManageList(HttpServletRequest request, ModelMap modelMap,
			@ModelAttribute("mb") ShopPerbiForm mbForm)throws Exception {
		try{

			//切换数据库 
			Users  sessionUser=(Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
		    if(sessionUser==null || StringUtils.isEmpty(Long.toString(sessionUser.getMerchantid()))){
				throw new BusinessException(ExceptionDefine.商户查询失败);
			}
			
			List<HashMap> shopPerbilist=null;
			//判断商户编号是否为数字
			String shopperIdq=mbForm.getShopperidq();
			if(!StringUtils.isEmpty(shopperIdq)){
				boolean b = shopperIdq.matches("^[-+]?(([0-9]+)([.]([0-9]+))?|([.]([0-9]+))?)$");
				if(!b){
					mbForm.setShopperidq("");
				}
			}
			
			//获取省
			List<Area> Provincial=shopPerbiService.searchProvince();
			
			//获取市
			List<Area> list = shopPerbiService.searchArea();
	    	
	    	
	    	request.setAttribute("belongsAgent", mbForm.getBelongsAgent());
			if(mbForm.getSprovince()!=null){
				List searchProvincialList=shopPerbiService.searchProvincial(mbForm.getSprovince());
	    		if(searchProvincialList!=null&&searchProvincialList.size()>0){
	    			Area spro=(Area)searchProvincialList.get(0);
	        		if(spro!=null){
	        			String sprov=spro.getProvincialname();
	        			mbForm.setSprovince(sprov);
	        		}
	    		}
			}
			if(mbForm.getCity()!=null){
				List cityList = shopPerbiService.searchCity(mbForm.getCity());
				if (cityList != null && cityList.size() > 0) {
					Area area = (Area) cityList.get(0);
					if (area != null) {
						String cityName = (String) area.getCityname();
						mbForm.setCity(cityName);
		    		}
				}
			}
		
		    String shopperid_p=request.getParameter("shopperid_p");
	        String shopperid=Long.toString(sessionUser.getMerchantid());
	        mbForm.setAgentNo(shopperid);
	        String  checkAgent=request.getParameter("checkAgent");
			if(StringUtils.isEmpty(checkAgent)){
				mbForm.setCheckAgents(false);
			}else{
				if(checkAgent.equals("true")){
					mbForm.setCheckAgents(true);
				}else{
					mbForm.setCheckAgents(false);
				}
			}
	        if(org.apache.commons.lang3.StringUtils.isNotEmpty(shopperid_p)){
	        	mbForm.setAgentNo(shopperid_p);
	        }else{
	        	mbForm.setAgentNo(shopperid);
	        }
	        shopPerbilist = shopPerbiService.queryShopPerbiManageList(mbForm);
	        
	        request.setAttribute("shopperid", shopperid);
	        request.setAttribute("Provincial",Provincial);
	        request.setAttribute("area",list);
			request.setAttribute("shopPerbilist", shopPerbilist);
			
		}catch (BusinessException e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.商户查询失败);
		}
		return "shopPerbi/shopPerbiManage";
	}
	
	/** 预约查看商户详情
	 * @param request
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=queryShopPerbiDetails")
	@FormToken(save=true)
	public String queryShopPerbiDetails(HttpServletRequest request, 
			B2cShopperbiTemp b2cShopperbi,
			@ModelAttribute("mb") ShopPerbiForm mbForm) throws Exception {
		try {
			String shopPerbiregId=request.getParameter("shopperpriId");
			if(StringUtils.isEmpty(shopPerbiregId)){
			    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url","shopPerbi.htm?method=shopPerbiManageList");
                return "shopPerbi/shopPerbiCheckDetails";
			}else{
				b2cShopperbi=shopPerbiService.queryShopPerbi(shopPerbiregId);
			}
			
			// 行业类型
			List<B2cDict> cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
			//获取银行
			B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval());
	        
			//获取服务商
	        if(b2cShopperbi!=null){
	        	//获取服务商
	            Long shopperId= b2cShopperbi.getShopperidP();
	            if(shopperId!=null){
	            	Agent agent=shopPerbiService.searchAgent(shopperId);
	            	request.setAttribute("agentName", agent.getScompany());
	            	request.setAttribute("agentId", agent.getShopperid());
	            }
	        }
	        //获取证照信息
	        Long photoid = b2cShopperbi.getPhotoid();
			MposPhotoTmp photo =  shopPerbiService.selectPhotoTmpById(photoid);
			
			// 手续费
			//List feeMap=shopPerbiService.findMerchantSkFee(b2cShopperbi.getShopperid());
			String shopperTel = null;
			if(b2cShopperbi!=null){
				shopperTel = b2cShopperbi.getStel();
			if(b2cShopperbi!=null&&shopperTel==null){
				shopperTel = b2cShopperbi.getStel();
				}
			}
			// 手续费，临时表
			MposMerchantFee s0creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
			MposMerchantFee s0debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
			
			MposMerchantFee d0creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
			MposMerchantFee d0debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
			
			MposMerchantFee t1creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
			MposMerchantFee t1debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
			
			MposMerchantFee weChatMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId, Constants.FEE_TYPE_WECHAT2);
			MposMerchantFee alipayMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId, Constants.FEE_TYPE_ALIPAY2);
			MposMerchantFee ylpayMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId,Constants.FEE_TYPE_YLPAY);
			
			MposMerchantFee shortCutMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId,Constants.STATUS5);

			MposMerchantFee shortCutSHMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId,Constants.STATUS7);
			MposMerchantFee b2cMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId,Constants.STATUS6);
			request.setAttribute("shortCutSHMerchantFeeTemp",shortCutSHMerchantFeeTemp);
			request.setAttribute("s0creditMerchantFeeTemp", s0creditMerchantFeeTemp);
			request.setAttribute("s0debitMerchantFeeTemp", s0debitMerchantFeeTemp);
			
			request.setAttribute("d0creditMerchantFeeTemp", d0creditMerchantFeeTemp);
			request.setAttribute("d0debitMerchantFeeTemp", d0debitMerchantFeeTemp);
			
			request.setAttribute("t1creditMerchantFeeTemp", t1creditMerchantFeeTemp);
			request.setAttribute("t1debitMerchantFeeTemp", t1debitMerchantFeeTemp);
			
			request.setAttribute("weChatMerchantFeeTemp", weChatMerchantFeeTemp);
			request.setAttribute("alipayMerchantFeeTemp",  alipayMerchantFeeTemp);
			request.setAttribute("ylpayMerchantFeeTemp",ylpayMerchantFeeTemp);
			
			request.setAttribute("shortCutMerchantFeeTemp",shortCutMerchantFeeTemp);
			request.setAttribute("b2cMerchantFeeTemp",b2cMerchantFeeTemp);
			// 手续费
			MposMerchantFee s0creditMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
			if(s0creditMerchantFee==null&&shopperTel!=null){
				s0creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
			}
			MposMerchantFee s0debitMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
			if(s0debitMerchantFee==null&&shopperTel!=null){
				s0debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
			}
			
			MposMerchantFee d0creditMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
			if(d0creditMerchantFee==null&&shopperTel!=null){
				d0creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
			}
			MposMerchantFee d0debitMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
			if(d0debitMerchantFee==null&&shopperTel!=null){
				d0debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
			}
			
			MposMerchantFee t1creditMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
			if(t1creditMerchantFee==null&&shopperTel!=null){
				t1creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
			}
			MposMerchantFee t1debitMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
			if(t1debitMerchantFee==null&&shopperTel!=null){
				t1debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
			}
			
			MposMerchantFee weChatMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_WECHAT2);
			if(weChatMerchantFee==null&&shopperTel!=null){
				weChatMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_WECHAT);
			}
			MposMerchantFee alipayMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_ALIPAY2);
			if(alipayMerchantFee==null&&shopperTel!=null){
				alipayMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_ALIPAY);
			}
			MposMerchantFee ylpayMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId,Constants.FEE_TYPE_YLPAY);
			if(ylpayMerchantFee == null && shopperTel != null){
				ylpayMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_YLPAY);
			}
			
			MposMerchantFee b2cMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId,Constants.STATUS6);
			
			MposMerchantFee shortCutMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId,Constants.STATUS5);
			MposMerchantFee shortCutSHMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId,Constants.STATUS7);
			
			request.setAttribute("shortCutMerchantFee", shortCutMerchantFee);
			/**
			 * 10月19号添加
			 */
			request.setAttribute("shortCutSHMerchantFee",shortCutSHMerchantFee);	
			
			request.setAttribute("b2cMerchantFee", b2cMerchantFee);
			
			request.setAttribute("s0creditMerchantFee", s0creditMerchantFee);
			request.setAttribute("s0debitMerchantFee", s0debitMerchantFee);
			
			request.setAttribute("d0creditMerchantFee", d0creditMerchantFee);
			request.setAttribute("d0debitMerchantFee", d0debitMerchantFee);
			
			request.setAttribute("t1creditMerchantFee", t1creditMerchantFee);
			request.setAttribute("t1debitMerchantFee", t1debitMerchantFee);
			
			request.setAttribute("weChatMerchantFee", weChatMerchantFee);
			request.setAttribute("alipayMerchantFee",  alipayMerchantFee);
			request.setAttribute("ylpayMerchantFee",ylpayMerchantFee);
			
			request.setAttribute("b2cShopperbi", b2cShopperbi);
			request.setAttribute("cillinglist", cillinglist);
			request.setAttribute("bankName",dicbank);
			request.setAttribute("photo", photo);
			request.setAttribute("image_get_url", IMAGE_GET_URL);
			//request.setAttribute("feeList", feeMap);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取商户信息失败);
		}
		
        
		return "shopPerbi/shopPerbiCheckDetails";
	}

	/**
	 * 查看商户用户详情
	 * @param request
	 * @param mbForm
	 * @return
	 */
	@RequestMapping(params = "method=queryShopperDetail")
	public String queryShopperDetail(HttpServletRequest request, B2cShopperbiTemp b2cShopperbi, @ModelAttribute("mb") ShopPerbiForm mbForm) throws BusinessException {
		try {
			String shopPerbiregId=request.getParameter("shopperpriId");
			if(StringUtils.isEmpty(shopPerbiregId)){
				request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
				mbForm.setBelongsAgent(null);
				request.setAttribute("url","shopPerbi.htm?method=shopPerbiManageList");
				return "shopPerbi/shopPerbiCheckDetails";
			}else{
				b2cShopperbi=shopPerbiService.queryShopPerbi(shopPerbiregId);
			}

			// 行业类型
			List<B2cDict> cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
			//获取银行
			B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval());

			//获取服务商
			if(b2cShopperbi!=null){
				//获取服务商
				Long shopperId= b2cShopperbi.getShopperidP();
				if(shopperId!=null){
					Agent agent=shopPerbiService.searchAgent(shopperId);
					request.setAttribute("agentName", agent.getScompany());
					request.setAttribute("agentId", agent.getShopperid());
				}
			}
			//获取证照信息
			Long photoid = b2cShopperbi.getPhotoid();
			MposPhotoTmp photo =  shopPerbiService.selectPhotoTmpById(photoid);

			String shopperTel = null;
			if(b2cShopperbi!=null){
				shopperTel = b2cShopperbi.getStel();
				if(b2cShopperbi!=null&&shopperTel==null){
					shopperTel = b2cShopperbi.getStel();
				}
			}

			MposMerchantFee weChatMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_WECHAT2);
			if(weChatMerchantFee==null&&shopperTel!=null){
				weChatMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_WECHAT);
			}
			MposMerchantFee alipayMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_ALIPAY2);
			if(alipayMerchantFee==null&&shopperTel!=null){
				alipayMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_ALIPAY);
			}

			request.setAttribute("weChatMerchantFee", weChatMerchantFee);
			request.setAttribute("alipayMerchantFee",  alipayMerchantFee);

			request.setAttribute("b2cShopperbi", b2cShopperbi);
			request.setAttribute("cillinglist", cillinglist);
			request.setAttribute("bankName",dicbank);
			request.setAttribute("photo", photo);
			request.setAttribute("image_get_url", IMAGE_GET_URL);

		} catch (Exception e) {
			logger.error("获取商户信息失败," + e.getMessage());
			throw new BusinessException(ExceptionDefine.获取商户信息失败);
		}
		return "shopPerbi/shopperDetail";
	}
	
	
	/**正式商户查询
	 * @param request
	 * @param b2cShopperbiTmp
	 * @param b2cShopperbargainTmp
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=shopFormalManageList")
	public String shopFormalManageList(HttpServletRequest request,ShopPerbiForm mbForm)throws Exception {
		try{
			Users  sessionUser=(Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
		    if(sessionUser==null || StringUtils.isEmpty(Long.toString(sessionUser.getMerchantid()))){
				throw new BusinessException(ExceptionDefine.商户查询失败);
			}
			//行业类型
			List cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
			request.setAttribute("cillinglist",cillinglist);
			//判断商户编号是否为数字
			String shopperIdq=mbForm.getShopperidq();
			if(!StringUtils.isEmpty(shopperIdq)){
				boolean b = shopperIdq.matches("^[-+]?(([0-9]+)([.]([0-9]+))?|([.]([0-9]+))?)$");
				if(!b){
					mbForm.setShopperidq("");
				}
			}
			if(mbForm.getSprovince()!=null){
				List searchProvincialList=shopPerbiService.searchProvincial(mbForm.getSprovince());
	    		if(searchProvincialList!=null&&searchProvincialList.size()>0){
	    			Area spro=(Area)searchProvincialList.get(0);
	        		if(spro!=null){
	        			String sprov=spro.getProvincialname();
	        			mbForm.setSprovince(sprov);
	        		}
	    		}
			}
			if(mbForm.getCity()!=null){
				List cityList = shopPerbiService.searchCity(mbForm.getCity());
				if (cityList != null && cityList.size() > 0) {
					Area area = (Area) cityList.get(0);
					if (area != null) {
						String cityName = (String) area.getCityname();
						mbForm.setCity(cityName);
		    		}
				}
			}
			

			//获取省
			List<Area> Provincial=shopPerbiService.searchProvince();
			//获取市
			List<Area> list = shopPerbiService.searchArea();
	    	
	        String shopperid=Long.toString(sessionUser.getMerchantid());
	        mbForm.setAgentNo(shopperid);
	        String  checkAgent=request.getParameter("checkAgent");
			if(StringUtils.isEmpty(checkAgent)){
				mbForm.setCheckAgents(false);
			}else{
				if(checkAgent.equals("true")){
					mbForm.setCheckAgents(true);
				}else{
					mbForm.setCheckAgents(false);
				}
			}
			List<HashMap> shopPerbilist = shopPerbiService.queryFormalManageList(mbForm);
			
			request.setAttribute("area",list);
			request.setAttribute("Provincial",Provincial);
			request.setAttribute("shopperid", shopperid);
			request.setAttribute("shopPerbilist", shopPerbilist);
			request.setAttribute("belongsAgent", mbForm.getBelongsAgent());
			
		}catch (BusinessException e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.商户查询失败);
		}
		return "shopPerbi/shopFormalPerbiManage";
	}

	@RequestMapping(params = "method=findShopperList")
	public String findShopperList(HttpServletRequest request,ShopPerbiForm mbForm) {
		try {
			Users  sessionUser=(Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			//判断商户编号是否为数字
			String shopperIdq=mbForm.getShopperidq();
			if(!StringUtils.isEmpty(shopperIdq)){
				boolean b = shopperIdq.matches("^[-+]?(([0-9]+)([.]([0-9]+))?|([.]([0-9]+))?)$");
				if(!b){
					mbForm.setShopperidq("");
				}
			}
			if(mbForm.getSprovince()!=null){
				List searchProvincialList=shopPerbiService.searchProvincial(mbForm.getSprovince());
				if(searchProvincialList!=null&&searchProvincialList.size()>0){
					Area spro=(Area)searchProvincialList.get(0);
					if(spro!=null){
						String sprov=spro.getProvincialname();
						mbForm.setSprovince(sprov);
					}
				}
			}
			if(mbForm.getCity()!=null){
				List cityList = shopPerbiService.searchCity(mbForm.getCity());
				if (cityList != null && cityList.size() > 0) {
					Area area = (Area) cityList.get(0);
					if (area != null) {
						String cityName = (String) area.getCityname();
						mbForm.setCity(cityName);
					}
				}
			}

			//获取省
			List<Area> Provincial=shopPerbiService.searchProvince();
			//获取市
			List<Area> list = shopPerbiService.searchArea();

			String shopperid=Long.toString(sessionUser.getMerchantid());
			mbForm.setAgentNo(shopperid);
			String  checkAgent=request.getParameter("checkAgent");
			if(StringUtils.isEmpty(checkAgent)){
				mbForm.setCheckAgents(false);
			}else{
				if(checkAgent.equals("true")){
					mbForm.setCheckAgents(true);
				}else{
					mbForm.setCheckAgents(false);
				}
			}
			PageContext.initPageSize(20);
			List<Map<String, Object>> shopperList = shopPerbiService.findShopperList(mbForm);
			request.setAttribute("area",list);
			request.setAttribute("Provincial",Provincial);
			request.setAttribute("shopperid", shopperid);
			request.setAttribute("shopPerbilist", shopperList);
			request.setAttribute("belongsAgent", mbForm.getBelongsAgent());
		} catch (Exception e) {
			log.info("商户用户信息查询失败" + e.getMessage());
		}
		return "shopPerbi/shopperList";
	}

	/**
	 * 跳转商户用户信息分页页面
	 * @param request
	 * @param mbForm
	 * @return
	 */
	@RequestMapping(params = "method=findShopperPageList")
	public String findShopperPageList(HttpServletRequest request,ShopPerbiForm mbForm) {
		try {
			Users  sessionUser=(Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			//判断商户编号是否为数字
			String shopperIdq=mbForm.getShopperidq();
			if(!StringUtils.isEmpty(shopperIdq)){
				boolean b = shopperIdq.matches("^[-+]?(([0-9]+)([.]([0-9]+))?|([.]([0-9]+))?)$");
				if(!b){
					mbForm.setShopperidq("");
				}
			}
			if(mbForm.getSprovince()!=null){
				List searchProvincialList=shopPerbiService.searchProvincial(mbForm.getSprovince());
				if(searchProvincialList!=null&&searchProvincialList.size()>0){
					Area spro=(Area)searchProvincialList.get(0);
					if(spro!=null){
						String sprov=spro.getProvincialname();
						mbForm.setSprovince(sprov);
					}
				}
			}
			if(mbForm.getCity()!=null){
				List cityList = shopPerbiService.searchCity(mbForm.getCity());
				if (cityList != null && cityList.size() > 0) {
					Area area = (Area) cityList.get(0);
					if (area != null) {
						String cityName = (String) area.getCityname();
						mbForm.setCity(cityName);
					}
				}
			}

			String shopperid=Long.toString(sessionUser.getMerchantid());
			mbForm.setAgentNo(shopperid);
			String  checkAgent=request.getParameter("checkAgent");
			if(StringUtils.isEmpty(checkAgent)){
				mbForm.setCheckAgents(false);
			}else{
				if(checkAgent.equals("true")){
					mbForm.setCheckAgents(true);
				}else{
					mbForm.setCheckAgents(false);
				}
			}
			Page page  = new Page();
			page.setPageSize(Constants.excel_size);
			PageContext context = PageContext.getContext();
			BeanUtils.copyProperties(context, page);
			context.setPagination(true);
			shopPerbiService.findShopperList(mbForm);
			BeanUtils.copyProperties(page, context);
			request.setAttribute("page",page);
			request.setAttribute("mbForm", mbForm);
			request.setAttribute("checkAgent",checkAgent);
		} catch (Exception e) {
			log.info("跳转商户用户分页页面失败" + e.getMessage());
		}
		return "shopPerbi/shopperListPage";
	}

	@RequestMapping(params = "method=exportShopperPageList")
	public void exportShopperPageList(HttpServletRequest request,HttpServletResponse response, @ModelAttribute("mb") ShopPerbiForm mbForm) {
		try {
			Users  sessionUser=(Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			//判断商户编号是否为数字
			String shopperIdq=mbForm.getShopperidq();
			if(!StringUtils.isEmpty(shopperIdq)){
				boolean b = shopperIdq.matches("^[-+]?(([0-9]+)([.]([0-9]+))?|([.]([0-9]+))?)$");
				if(!b){
					mbForm.setShopperidq("");
				}
			}
			if(mbForm.getSprovince()!=null){
				List searchProvincialList=shopPerbiService.searchProvincial(mbForm.getSprovince());
				if(searchProvincialList!=null&&searchProvincialList.size()>0){
					Area spro=(Area)searchProvincialList.get(0);
					if(spro!=null){
						String sprov=spro.getProvincialname();
						mbForm.setSprovince(sprov);
					}
				}
			}
			if(mbForm.getCity()!=null){
				List cityList = shopPerbiService.searchCity(mbForm.getCity());
				if (cityList != null && cityList.size() > 0) {
					Area area = (Area) cityList.get(0);
					if (area != null) {
						String cityName = (String) area.getCityname();
						mbForm.setCity(cityName);
					}
				}
			}

			String shopperid=Long.toString(sessionUser.getMerchantid());
			mbForm.setAgentNo(shopperid);
			String  checkAgent=request.getParameter("checkAgent");
			if(StringUtils.isEmpty(checkAgent)){
				mbForm.setCheckAgents(false);
			}else{
				if(checkAgent.equals("true")){
					mbForm.setCheckAgents(true);
				}else{
					mbForm.setCheckAgents(false);
				}
			}
			Page page  = new Page();
			page.setPageSize(Constants.excel_size);
			PageContext context = PageContext.getContext();
			BeanUtils.copyProperties(context, page);
			context.setPagination(true);
			List<Map<String, Object>> listData = shopPerbiService.findShopperList(mbForm);
			BeanUtils.copyProperties(page, context);
			List<String> listHead = new ArrayList<String>();
			listHead.add("商户编号");
			listHead.add("商户名称");
			listHead.add("所在地区");
			listHead.add("所属服务商编号");
			listHead.add("所属服务商名称");
			listHead.add("商户状态");
			listHead.add("业务类型");
			listHead.add("审核状态");
			listHead.add("创建时间");
			listHead.add("审核时间");
			List<String> listKey = new ArrayList<String>();
			listKey.add("SHOPPERID");
			listKey.add("SCOMPANY");
			listKey.add("SPROVINCE");
			listKey.add("SHOPPERID_P");
			listKey.add("SAGENTID");
			listKey.add("SIFPACTIDSTR");
			listKey.add("BUSINESSTYPE");
			listKey.add("CHECKSTATUS");
			listKey.add("CREATED");
			listKey.add("CHECK_DATE");
			ExcelUtils.downExcel(listData, listKey, listHead, "SHOPPER_LIST", "商户用户信息", response);
		} catch (Exception e) {
			logger.info("商户用户信息导出失败," + e.getMessage());
		}
	}

	
	/**是否有重复的用户名存在
	 *@param request
	 * @param response
	 * @throws 
	 * @throws IOException
	 */
	@RequestMapping(params="method=ajaxaddTermainal")
	public void ajaxaddTermainal(HttpServletRequest request,HttpServletResponse response) throws IOException{
		B2cTempTermBinder tempTermBinder=new B2cTempTermBinder();
		B2cTempTermBinder tempTermBinder2=new B2cTempTermBinder();
		String terminalid=request.getParameter("terminalid");
		String num=request.getParameter("num");
		String merchantNo=request.getParameter("shopPerbiregId");
		if(StringUtils.isTrimNotEmpty(terminalid)){
			tempTermBinder2=shopPerbiService.selectTempTermNo(terminalid);
		}
		if(tempTermBinder2!=null){
			if(tempTermBinder2.getStatus().toString().equals("0")){
			    shopPerbiService.deleteTempTermianl(tempTermBinder2.getTermNo());
			}
		}
		List Tershopper=null;
		if(tempTermBinder2==null|| tempTermBinder2.getStatus().toString().equals("0")){
			if(StringUtils.isTrimNotEmpty(merchantNo)){
				System.out.println(merchantNo);
				tempTermBinder.setMerchantNo(merchantNo);
			}
			if(StringUtils.isTrimNotEmpty(terminalid)){
				tempTermBinder.setTermNo(terminalid);
			}
			tempTermBinder.setStatus("0");
			tempTermBinder.setCreateDate(new Date());
			shopPerbiService.addTempBinder(tempTermBinder);
			Tershopper=shopPerbiService.shopperAjaxBinder(merchantNo);
		}
		String str="无";
		PrintWriter out=null;
		try {
			out=response.getWriter();
			if(Tershopper!=null&&Tershopper.size()>0){
				out.println(JsonUtil.getJsonString4List(Tershopper));
			}else{
				response.getWriter().print(str);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			if (out != null) {
				out.flush();
				out.close();
			}
		}finally{
			if(out !=null){
				out.flush();
				out.close();
			}
		}
			
	}
	
	
	/**是否有重复的用户名存在
	 *@param request
	 * @param response
	 * @throws 
	 * @throws IOException
	 */
	@RequestMapping(params="method=ajaxfindTermainal")
	public void ajaxfindTermainal(HttpServletRequest request,HttpServletResponse response) throws IOException{
		try {
			String terminalid=request.getParameter("terminalid");
			String agentno=request.getParameter("");
			B2cTerminal b2cterminal=null;
			String shopperbi=null;
			B2cAgentBinder agentBinder=null;
			if(StringUtils.isTrimNotEmpty(terminalid)){
				terminalid=terminalid.trim();
				b2cterminal=shopPerbiService.findtermainal(terminalid);
				shopperbi=shopPerbiService.selectBindtermainal(terminalid);
				agentBinder=shopPerbiService.selectByTermNo(terminalid);
			}
			
			String str="";
			if(b2cterminal==null){
				throw new BusinessException(ExceptionDefine.空指针异常);
			}
			if(b2cterminal.getNum()!=null){
				str+=b2cterminal.getNum()+",";
			}else{
				str+=null+",";
			}
			if(b2cterminal.getName()!=null){
				str+=b2cterminal.getName()+",";
			}else{
				str+=null+",";
			}
			if(shopperbi==null){
				str+="无,";
			}else{
				str+=shopperbi+",";
			}
			if(b2cterminal.getTerminalid()!=null){
				str+=b2cterminal.getTerminalid()+",";
			}
			if(agentBinder!=null){
				str+=agentBinder.getAgentNo();
			}else{
				str+="无";
			}
			response.getWriter().print(str);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**是否有重复的用户名存在
	 *@param request
	 * @param response
	 * @throws 
	 * @throws IOException
	 */
	@RequestMapping(params="method=ajaxCheckName")
	public void ajaxCheckName(HttpServletRequest request,HttpServletResponse response) throws IOException{
		try {
			String userName=request.getParameter("userName");
			List<Users> users=null;
			List list=null;
			if(StringUtils.isTrimNotEmpty(userName)){
			    userName=userName.trim();
			    users=shopPerbiService.selectByUsersName(userName);
			    list=shopPerbiService.selectByMuserid(userName);
			}
			PrintWriter out=response.getWriter();
			try {
				if((users!=null&&users.size()>0)||(list!=null&&list.size()>0)){
					out.write("{\"x\":\"1\"}");
				}else{
					out.write("{\"x\":\"2\"}");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				if(out !=null){
					out.flush();
					out.close();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	/**审核开户行信息之前需要先审核商户信息
	 *@param request
	 * @param response
	 * @throws 
	 * @throws IOException
	 */
	@RequestMapping(params="method=ajaxFormalShopper")
	public void ajaxFormalShopper(HttpServletRequest request,HttpServletResponse response) throws IOException{
		try {
			String ShooperId=request.getParameter("ShooperId");
			B2cShopperbi formalShopper=new B2cShopperbi();
			B2cShopperbiTemp shoper=new B2cShopperbiTemp();
			if(!StringUtils.isEmpty(ShooperId)){
			    shoper=shopPerbiService.queryShopPerbi(ShooperId);
			}
			if(!StringUtils.isEmpty(ShooperId)){
				formalShopper=shopPerbiService.selectFormalShopperId(ShooperId);
			}
			PrintWriter out=response.getWriter();
			try {
				if(formalShopper!=null){
					out.write("{\"x\":\"1\"}");
				}else if(shoper.getIfvalid().toString().equals("2")){
					out.write("{\"x\":\"2\"}");
				}else{
					out.write("{\"x\":\"3\"}");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				if(out !=null){
					out.flush();
					out.close();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/**审核开户行信息之前需要先审核商户信息
	 *@param request
	 * @param response
	 * @throws 
	 * @throws IOException
	 */
	@RequestMapping(params="method=ajaxTerminalShopper")
	public void ajaxTerminalShopper(HttpServletRequest request,HttpServletResponse response) throws IOException{
		try {
			String ShooperId=request.getParameter("ShooperId");
//			B2cShopperbi formalShopper=new B2cShopperbi();
			B2cShopperbiTemp shoper=new B2cShopperbiTemp();
			if(!StringUtils.isEmpty(ShooperId)){
			    shoper=shopPerbiService.queryShopPerbi(ShooperId);
			}
			/*if(!StringUtils.isEmpty(ShooperId)){
				formalShopper=shopPerbiService.selectFormalShopperId(ShooperId);
			}*/
			PrintWriter out=response.getWriter();
			try {
				if(shoper.getIfvalid().toString().equals("1")){
					out.write("{\"x\":\"1\"}");
				}else if(shoper.getIfvalid().toString().equals("2")){
					out.write("{\"x\":\"2\"}");
				}else{
					out.write("{\"x\":\"3\"}");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				if(out !=null){
					out.flush();
					out.close();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	/**
	 * 查询正式信息（下载用）
	 * @throws Exception
	 */
	@RequestMapping(params = "method=findDownloadShopper")
	public String findDownloadShopper(HttpServletRequest request, ModelMap modelMap,
			@ModelAttribute("mb") ShopPerbiForm mbForm)throws Exception{
			try{
				//行业类型
				List cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
				request.setAttribute("cillinglist",cillinglist);
				List<HashMap> shopPerbilist=null;
				//判断商户编号是否为数字
				String shopperIdq=mbForm.getShopperidq();
				if(!StringUtils.isEmpty(shopperIdq)){
					boolean b = shopperIdq.matches("^[-+]?(([0-9]+)([.]([0-9]+))?|([.]([0-9]+))?)$");
					if(!b){
						mbForm.setShopperidq("");
					}
				}
				if(mbForm.getSprovince()!=null){
					List searchProvincialList=shopPerbiService.searchProvincial(mbForm.getSprovince());
		    		if(searchProvincialList!=null&&searchProvincialList.size()>0){
		    			Area spro=(Area)searchProvincialList.get(0);
		        		if(spro!=null){
		        			String sprov=spro.getProvincialname();
		        			mbForm.setSprovince(sprov);
		        		}
		    		}
				}
				if(mbForm.getCity()!=null){
					List cityList = shopPerbiService.searchCity(mbForm.getCity());
					if (cityList != null && cityList.size() > 0) {
						Area area = (Area) cityList.get(0);
						if (area != null) {
							String cityName = (String) area.getCityname();
							mbForm.setCity(cityName);
			    		}
					}
				}
				Users  sessionUser=(Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			    if(sessionUser==null || StringUtils.isEmpty(Long.toString(sessionUser.getMerchantid()))){
					throw new BusinessException(ExceptionDefine.商户查询失败);
				}
				String shopperid=Long.toString(sessionUser.getMerchantid());
			    mbForm.setAgentNo(shopperid);
			    request.getSession().setAttribute("shopperid", shopperid);
			    String  checkAgent=request.getParameter("checkAgent");
				if(StringUtils.isEmpty(checkAgent)){
					mbForm.setCheckAgents(false);
				}else{
					if(checkAgent.equals("true")){
						mbForm.setCheckAgents(true);
					}else{
						mbForm.setCheckAgents(false);
					}
				}
				Page page  = new Page();
				page.setPageSize(Constants.excel_size);
				PageContext context = PageContext.getContext();
				BeanUtils.copyProperties(context, page);
				context.setPagination(true);
				
				shopPerbilist = shopPerbiService.excelFormalManageList(mbForm);
				BeanUtils.copyProperties(page, context);
				request.setAttribute("page",page);
				request.setAttribute("mbForm", mbForm);
				request.setAttribute("checkAgent",checkAgent);
				
			}catch (BusinessException e) {
				e.printStackTrace();
				throw new BusinessException(ExceptionDefine.商户查询失败);
			}
			
			return "shopPerbi/excelPage";
	}
	
	/**
	 * 导出记录
	 */
	@RequestMapping(params = "method=downloadShopperList")
	public String downloadShopperList(HttpServletRequest request,HttpServletResponse response, ModelMap modelMap,
			@ModelAttribute("mb") ShopPerbiForm mbForm) throws ParseException, BusinessException {
		try{
			//行业类型
			List cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
			request.setAttribute("cillinglist",cillinglist);
			List<HashMap> shopPerbilist=null;
			//判断商户编号是否为数字
			String shopperIdq=mbForm.getShopperidq();
			if(!StringUtils.isEmpty(shopperIdq)){
				boolean b = shopperIdq.matches("^[-+]?(([0-9]+)([.]([0-9]+))?|([.]([0-9]+))?)$");
				if(!b){
					mbForm.setShopperidq("");
				}
			}
			if(mbForm.getSprovince()!=null){
				List searchProvincialList=shopPerbiService.searchProvincial(mbForm.getSprovince());
	    		if(searchProvincialList!=null&&searchProvincialList.size()>0){
	    			Area spro=(Area)searchProvincialList.get(0);
	        		if(spro!=null){
	        			String sprov=spro.getProvincialname();
	        			mbForm.setSprovince(sprov);
	        		}
	    		}
			}
			if(mbForm.getCity()!=null){
				List cityList = shopPerbiService.searchCity(mbForm.getCity());
				if (cityList != null && cityList.size() > 0) {
					Area area = (Area) cityList.get(0);
					if (area != null) {
						String cityName = (String) area.getCityname();
						mbForm.setCity(cityName);
		    		}
				}
			}
			Users  sessionUser=(Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
		    if(sessionUser==null || StringUtils.isEmpty(Long.toString(sessionUser.getMerchantid()))){
				throw new BusinessException(ExceptionDefine.商户查询失败);
			}
	        String shopperid=Long.toString(sessionUser.getMerchantid());
	        mbForm.setAgentNo(shopperid);
			request.getSession().setAttribute("shopperid", shopperid);
		    String  checkAgent=request.getParameter("checkAgent");
			if(StringUtils.isEmpty(checkAgent)){
				mbForm.setCheckAgents(false);
			}else{
				if(checkAgent.equals("true")){
					mbForm.setCheckAgents(true);
				}else{
					mbForm.setCheckAgents(false);
				}
			}
			shopPerbilist = shopPerbiService.excelFormalManageList(mbForm);
	    	
			request.setAttribute("belongsAgent", mbForm.getBelongsAgent());
			
			outExcel(shopPerbilist,response,"merchant_info",shopPerbilist.size());
		}catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.商户查询失败);
		}
		return null;
	}
	
	/**导出excel
	 */
	private void outExcel(List<HashMap> excelList, HttpServletResponse response,String fileNames,
			int totalRows) throws Exception {
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		response.setContentType("application/vnd.ms-excel");
		response.setHeader("content-disposition", "attachment;filename="+new String(fileNames.getBytes("GBK"),"iso8859-1")+".xls");
		response.setCharacterEncoding("UTF-8");
		
        OutputStream os = response.getOutputStream(); 
		WritableWorkbook wwb=Workbook.createWorkbook(os);
		WritableSheet sheet0 = wwb.createSheet(fileNames,0);
		sheet0.addCell(new Label(0,0, "总记录数"));
		sheet0.addCell(new Label(1,0, String.valueOf(totalRows)));
		sheet0.addCell(new Label(0,1, "商户编号"));
		sheet0.addCell(new Label(1,1, "商户名称"));
		sheet0.addCell(new Label(2,1, "所在地区"));
        sheet0.addCell(new Label(3,1, "所属服务商"));
        sheet0.addCell(new Label(4,1, "复核时间"));
        sheet0.addCell(new Label(5,1, "修改时间"));
        sheet0.addCell(new Label(6,1, "商户状态"));
        sheet0.addCell(new Label(7,1, "激活状态"));
        sheet0.addCell(new Label(8,1, "激活时间"));
        sheet0.addCell(new Label(9,1, "开通时间"));
		sheet0.addCell(new Label(10,1, "是否裂变商户"));
        
        for (int i = 0; i < excelList.size(); i++) {  
            //转换成map集合{activyName:测试功能,count:2}  
        	Map<String,String> info = excelList.get(i);
            //循环输出map中的子集：既列值  
        	String address = info.get("SPROVINCE")==null?"":String.valueOf(info.get("SPROVINCE")) + "," ;
        	String city = info.get("SCITY")==null?"":String.valueOf(info.get("SCITY"));
            sheet0.addCell(new Label(0,i+2, info.get("SHOPPERID")==null?"":String.valueOf(info.get("SHOPPERID"))));
            sheet0.addCell(new Label(1,i+2, info.get("SCOMPANY")));
            sheet0.addCell(new Label(2,i+2,  address + city ));
            sheet0.addCell(new Label(3,i+2, info.get("SAGENTID")));
            sheet0.addCell(new Label(4,i+2, info.get("RECHECK_DATE")==null?"":sf.format(info.get("RECHECK_DATE"))));
            sheet0.addCell(new Label(5,i+2, info.get("UPDATED")==null?"":sf.format(info.get("UPDATED"))));
			String status = "";
			if(Constants.CON_NO.equals(String.valueOf(info.get("SIFPACTID")))){
				status = "正常";
			}else if (Constants.CON_YES.equals(String.valueOf(info.get("SIFPACTID")))){
				status = "冻结";
			}else {
				status = "注销";
			}
            sheet0.addCell(new Label(6,i+2, status));
            sheet0.addCell(new Label(7,i+2, Constants.CON_YES.equals(info.get("IFACTIVATED"))?"已激活":"暂未"));
            sheet0.addCell(new Label(8,i+2, info.get("IFACTIVADATE")==null?"":sf.format(info.get("IFACTIVADATE"))));
            sheet0.addCell(new Label(9,i+2, info.get("OPEN_MPOS_CREATE_DATE")==null?"":sf.format(info.get("OPEN_MPOS_CREATE_DATE"))));
			sheet0.addCell(new Label(10,i+2, info.get("HAVEINVITECODEP")==null?"":info.get("HAVEINVITECODEP")));
        }
        //写入Exel工作表  
        wwb.write();  
        //关闭Excel工作薄对象   
        wwb.close();  
        //关闭流  
        os.flush();  
        os.close();  
          
        os =null;  
       
	}
	
	/**商户审核
	 * @param request
	 * @param b2cShopperbiTmp
	 * @param b2cShopperbargainTmp
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params="method=shopPerbiCheckList")
	public String shopPerbiCheckList(HttpServletRequest request, ModelMap modelMap,
			 @ModelAttribute("mb") ShopPerbiForm mbForm) throws Exception {
		try{
			//行业类型
			List cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
			request.setAttribute("cillinglist",cillinglist);
			//Agent agent = (Agent)request.getSession().getAttribute("agent");
			List<HashMap> shopPerbilist=null;
			//判断商户编号是否为数字
			String shopperIdq=mbForm.getShopperidq();
			if(!StringUtils.isEmpty(shopperIdq)){
				boolean b = shopperIdq.matches("^[-+]?(([0-9]+)([.]([0-9]+))?|([.]([0-9]+))?)$");
				if(!b){
					mbForm.setShopperidq("");
				}
			}
//			if(agent==null){
//				throw new BusinessException(ExceptionDefine.登录失效);
//			}else{
//				mbForm.setCurrentid(new Long(agent.getShopperid()));
//			}
			if(mbForm.getSprovince()!=null){
				List searchProvincialList=shopPerbiService.searchProvincial(mbForm.getSprovince());
	    		if(searchProvincialList!=null&&searchProvincialList.size()>0){
	    			Area spro=(Area)searchProvincialList.get(0);
	        		if(spro!=null){
	        			String sprov=spro.getProvincialname();
	        			mbForm.setSprovince(sprov);
	        		}
	    		}
			}
			if(mbForm.getCity()!=null){
				List cityList = shopPerbiService.searchCity(mbForm.getCity());
				if (cityList != null && cityList.size() > 0) {
					Area area = (Area) cityList.get(0);
					if (area != null) {
						String cityName = (String) area.getCityname();
						mbForm.setCity(cityName);
		    		}
				}
			}
			Users  sessionUser=(Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
		    if(sessionUser==null || StringUtils.isEmpty(Long.toString(sessionUser.getMerchantid()))){
				throw new BusinessException(ExceptionDefine.商户查询失败);
			}
	        String shopperid=Long.toString(sessionUser.getMerchantid());
	        String shopperid_p=request.getParameter("shopperid_p");
	        
	        if(org.apache.commons.lang3.StringUtils.isNotEmpty(shopperid_p)){
	        	mbForm.setAgentNo(shopperid_p);
	        }else{
	        	mbForm.setAgentNo(shopperid);
	        }

			//获取省
			List<Area> Provincial=shopPerbiService.searchProvince();
			request.setAttribute("Provincial",Provincial);
			//获取市
			List<Area> list = shopPerbiService.searchArea();
	    	request.setAttribute("area",list);
	    	//获取未审核的商户个数
			String Shoppercount = shopPerbiService.selectCheckCount(mbForm);
	    	request.setAttribute("Shoppercount",Shoppercount);
			request.setAttribute("belongsAgent", mbForm.getBelongsAgent());
			
			request.getSession().setAttribute("shopperid", shopperid);
			 String  checkAgent=request.getParameter("checkAgent");
				if(StringUtils.isEmpty(checkAgent)){
					mbForm.setCheckAgents(false);
				}else{
					if(checkAgent.equals("true")){
						mbForm.setCheckAgents(true);
					}else{
						mbForm.setCheckAgents(false);
					}
				}
			shopPerbilist = shopPerbiService.ShopPerbiCheckList(mbForm);
			modelMap.put("shopPerbilist", shopPerbilist);
			
		}catch (BusinessException e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.商户查询失败);
		}
		return "shopPerbi/shopPerbiCheck";
	}
	
	/**查看商户详情
	 * @param request
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=selectAgent")
	@FormToken(save=true)
	public String selectAgent(HttpServletRequest request, 
			ModelMap modelMap,@ModelAttribute("mb") ShopPerbiForm mbForm) throws Exception {
		try {
			Agent agent=null;
			String Id=request.getParameter("id");
			if(StringUtils.isEmpty(Id)){
			    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url","shopPerbi.htm?method=shopPerbiManageList");
			}else{
				agent=shopPerbiService.selectAgent(Long.valueOf(Id));
			}
			request.getSession().setAttribute("agent", agent);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取商户信息失败);
		}
		
        
		return "shopPerbi/shopPerbiAgentDetails";
	}
	/**查看商户详情
	 * @param request
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=findAgent")
	@FormToken(save=true)
	public String findAgent(HttpServletRequest request, 
			ModelMap modelMap,@ModelAttribute("mb") ShopPerbiForm mbForm) throws Exception {
		try {
			Agent agent=null;
			String Id=request.getParameter("id");
			if(StringUtils.isEmpty(Id)){
			    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url","shopPerbi.htm?method=shopPerbiManageList");
			}else{
				agent=shopPerbiService.selectAgent(Long.valueOf(Id));
			}
			request.getSession().setAttribute("agent", agent);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取商户信息失败);
		}
		
        
		return "shopPerbi/shopPerbiFindAgent";
	}
	/**商户开户银行的审核
	 * @param request
	 * @param b2cShopperbiTmp
	 * @param b2cShopperbargainTmp
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
    @RequestMapping(params = "method=shopPerbiBankList")
	public String shopPerbiBankList(HttpServletRequest request, ModelMap modelMap,
			 @ModelAttribute("mb") ShopPerbiForm mbForm) throws Exception {
		try{
			//行业类型
			List cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
			request.setAttribute("cillinglist",cillinglist);
			//Agent agent = (Agent)request.getSession().getAttribute("agent");
			List<HashMap> shopPerbilist=null;
			//判断商户编号是否为数字
			String shopperIdq=mbForm.getShopperidq();
			if(!StringUtils.isEmpty(shopperIdq)){
				boolean b = shopperIdq.matches("^[-+]?(([0-9]+)([.]([0-9]+))?|([.]([0-9]+))?)$");
				if(!b){
					mbForm.setShopperidq("");
				}
			}
			if(mbForm.getSprovince()!=null){
				List searchProvincialList=shopPerbiService.searchProvincial(mbForm.getSprovince());
	    		if(searchProvincialList!=null&&searchProvincialList.size()>0){
	    			Area spro=(Area)searchProvincialList.get(0);
	        		if(spro!=null){
	        			String sprov=spro.getProvincialname();
	        			mbForm.setSprovince(sprov);
	        		}
	    		}
			}
			if(mbForm.getCity()!=null){
				List cityList = shopPerbiService.searchCity(mbForm.getCity());
				if (cityList != null && cityList.size() > 0) {
					Area area = (Area) cityList.get(0);
					if (area != null) {
						String cityName = (String) area.getCityname();
						mbForm.setCity(cityName);
		    		}
				}
			}
			Users  sessionUser=(Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
		    if(sessionUser==null || StringUtils.isEmpty(Long.toString(sessionUser.getMerchantid()))){
				throw new BusinessException(ExceptionDefine.商户查询失败);
			}
	        String shopperid=Long.toString(sessionUser.getMerchantid());
	        mbForm.setAgentNo(shopperid);
			request.getSession().setAttribute("shopperid", shopperid);
			shopPerbilist = shopPerbiService.ShopPerbiCheckList(mbForm);
			modelMap.put("shopPerbilist", shopPerbilist);
			//获取省
			List<Area> Provincial=shopPerbiService.searchProvince();
			request.setAttribute("Provincial",Provincial);
			//获取市
			List<Area> list = shopPerbiService.searchArea();
	    	request.setAttribute("area",list);
	    	//获取未审核的商户开户行信息的个数
			String Bankcount = shopPerbiService.selectCheckBkCount(mbForm);
	    	request.setAttribute("Bankcount",Bankcount);
	    	
			request.setAttribute("belongsAgent", mbForm.getBelongsAgent());
		}catch (BusinessException e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.商户查询失败);
		}
		return "shopPerbi/shopPerbiCheckBank";
	}
    /**商户终端的审核
	 * @param request
	 * @param b2cShopperbiTmp
	 * @param b2cShopperbargainTmp
	 * @param modelMap
	 * @return
	 * @throws Exception   zt
	 */
    @RequestMapping(params = "method=shopPerbiTerminalList")
	public String shopPerbiTerminalList(HttpServletRequest request, ModelMap modelMap,
			 @ModelAttribute("mb") ShopPerbiForm mbForm) throws Exception {
		try{
			//行业类型
			List cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
			request.setAttribute("cillinglist",cillinglist);
			//Agent agent = (Agent)request.getSession().getAttribute("agent");
			List<HashMap> shopPerbilist=null;
			//判断商户编号是否为数字
			String shopperIdq=mbForm.getShopperidq();
			if(!StringUtils.isEmpty(shopperIdq)){
				boolean b = shopperIdq.matches("^[-+]?(([0-9]+)([.]([0-9]+))?|([.]([0-9]+))?)$");
				if(!b){
					mbForm.setShopperidq("");
				}
			}
			if(mbForm.getSprovince()!=null){
				List searchProvincialList=shopPerbiService.searchProvincial(mbForm.getSprovince());
	    		if(searchProvincialList!=null&&searchProvincialList.size()>0){
	    			Area spro=(Area)searchProvincialList.get(0);
	        		if(spro!=null){
	        			String sprov=spro.getProvincialname();
	        			mbForm.setSprovince(sprov);
	        		}
	    		}
			}
			if(mbForm.getCity()!=null){
				List cityList = shopPerbiService.searchCity(mbForm.getCity());
				if (cityList != null && cityList.size() > 0) {
					Area area = (Area) cityList.get(0);
					if (area != null) {
						String cityName = (String) area.getCityname();
						mbForm.setCity(cityName);
		    		}
				}
			}
			Users  sessionUser=(Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
		    if(sessionUser==null || StringUtils.isEmpty(Long.toString(sessionUser.getMerchantid()))){
				throw new BusinessException(ExceptionDefine.商户查询失败);
			}
	        String shopperid=Long.toString(sessionUser.getMerchantid());
	        mbForm.setAgentNo(shopperid);
			request.getSession().setAttribute("shopperid", shopperid);
			shopPerbilist = shopPerbiService.shopPerbiTerminalList(mbForm);
			modelMap.put("shopPerbilist", shopPerbilist);
			//获取省
			List<Area> Provincial=shopPerbiService.searchProvince();
			request.setAttribute("Provincial",Provincial);
			//获取市
			List<Area> list = shopPerbiService.searchArea();
	    	request.setAttribute("area",list);
	    	//获取未审核的商户开户行信息的个数
			String Tercount = shopPerbiService.selectevicenumCount(mbForm);
	    	request.setAttribute("Tercount",Tercount);
	    	
			request.setAttribute("belongsAgent", mbForm.getBelongsAgent());
		}catch (BusinessException e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.商户查询失败);
		}
		return "shopPerbi/shopPerbiTermianlList";
	}
	
	
	/**商户注册
	 * @param request
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 * @ 
	 */
	@RequestMapping(params = "method=queryShopPerbireg")
	@FormToken(save=true)
	public String queryShopPerbireg(HttpServletRequest request, ModelMap modelMap) throws Exception  {
		try {
			//获取省
			List<Area> Provincial=shopPerbiService.searchProvince();
			request.setAttribute("Provincial",Provincial);
			//获取市
			List<Area> list = shopPerbiService.searchArea();
	    	request.setAttribute("area",list);
	    	//获取银行
			List<B2cDict> dicbank = shopPerbiService.searchBank();
	    	request.setAttribute("bank",dicbank);
			//行业类型
			List cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
			request.setAttribute("cillinglist",cillinglist);
			//T0fee写死
			//request.setAttribute("T0FEE", Constants.T0FEE);
			
			
			
			//结算周期
			List footfreqlist =  shopPerbiService.searchFootFreqList();
	        request.setAttribute("footfreqlist",footfreqlist);
	        
	        Users  sessionUser=(Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
	       Agent   sessionAgent = agentservice.searchAgentByShopperId(sessionUser.getMerchantid().toString());
	       request.setAttribute("agent", sessionAgent);
	        if(sessionUser==null || StringUtils.isEmpty(Long.toString(sessionUser.getMerchantid()))){
				throw new BusinessException(ExceptionDefine.商户注册获取列表失败);
			}
	        String shopperid=Long.toString(sessionUser.getMerchantid());
			request.getSession().setAttribute("shopperid", shopperid);
			
		} catch (BusinessException e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.商户注册获取列表失败);
		}
		return "shopPerbi/shopPerbireg";
        
        
	}
	
	/**保存商户注册
	 * 1.生成小商户编码
	 * @param request
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param modelMap
	 * @return
	 * @throws IOException 
	 */
	
	@RequestMapping(params="method=saveShopPerbiregList")
	@FormToken(remove=true)
	public String saveShopPerbiregList(HttpServletRequest request, ModelMap modelMap,
			B2cShopperbiTemp b2cShopperbi,B2cShopperbargainTemp b2cShopperbargain,@ModelAttribute("mb") ShopPerbiForm mbForm) throws Exception {
		try{
			String shopperid = getPosShopperId(b2cShopperbi.getCity(), Constants.CON_MCC);
			String path=basePath;
			/*//上传商户准入合规材料
			String StdFileNamePath="upload"+sep+"StdFileNames";
			MultipartFile file =mbForm.getStdFileNames();
			String fileName = file.getOriginalFilename();
			int index = fileName.lastIndexOf("\\");
			String fileFileName = "";
			if(index == -1){
				fileFileName = fileName;
			}else{
				fileFileName = fileName.substring(index + 1);
			}
			String dateStr = DateFormatUtils.format(new Date(), "yyMMddHHmmss");
			String merchantRadom=org.apache.commons.lang.RandomStringUtils.randomNumeric(4);
			String namefile=dateStr+merchantRadom;
			String type = fileName.substring(fileName.lastIndexOf(".") + 1);
			if(type!="" || !StringUtils.isEmpty(type)){
				if(type.equalsIgnoreCase("zip")){
					InputStream fileInputStream = file.getInputStream();
					String pdfName=namefile+".zip";
					
					File uploadFile = new File(path+sep+StdFileNamePath); 
					//检查文件是否已经存在
					if(!uploadFile.exists()){
						//建立文件
						uploadFile.mkdirs();
					}
					String stdFileNamePaths=path+sep+StdFileNamePath+sep+pdfName;
			        OutputStream out = new FileOutputStream(stdFileNamePaths);    
			        @SuppressWarnings("unused")
					int len = 0;//每次读取的字节数
					byte[] bytes = new byte[1024]; 
					while((len = fileInputStream.read(bytes, 0, bytes.length)) != -1){
						out.write(bytes);
					}
			        fileInputStream.close();
			        out.close();
			        b2cShopperbargain.setStdfilename(stdFileNamePaths);
				}else{
					modelMap.put("msg", "商户准入合规材料请上传zip文件！");
					return queryShopPerbireg(request,modelMap);
				}
			}
	        //上传商户准入辅助材料
			String addFileNamePath="upload"+sep+"AddFileNames";
			MultipartFile file2 =mbForm.getAddFileNames();
			String fileName2 = file2.getOriginalFilename();
			int index2 = fileName2.lastIndexOf("\\");
			String fileFileName2 = "";
			if(index2 == -1){
				fileFileName2 = fileName2;
			}else{
				fileFileName2 = fileName2.substring(index2 + 1);
			}
			String dateStr2 = DateFormatUtils.format(new Date(), "yyMMddHHmmss");
			String merchantRadom2=org.apache.commons.lang.RandomStringUtils.randomNumeric(4);
			String namefile2=dateStr2+merchantRadom2;
			String type2 = fileName2.substring(fileName2.lastIndexOf(".") + 1);
			if(type2!=""||!StringUtils.isEmpty(type2)){
				if(type2.equalsIgnoreCase("zip")){
					InputStream fileInput = file2.getInputStream();
					String pdfName2=namefile2+".zip";
					File uploadFile2 = new File(path+sep+addFileNamePath);
					
					//检查文件是否已经存在
					if(!uploadFile2.exists()){
						//建立文件
						uploadFile2.mkdirs();
					}
					String addFileNamePaths=path+sep+addFileNamePath+sep+pdfName2;
			        OutputStream out2 = new FileOutputStream(addFileNamePaths);    
			        @SuppressWarnings("unused")
					int len = 0;//每次读取的字节数
					byte[] bytes = new byte[1024]; 
					while((len = fileInput.read(bytes, 0, bytes.length)) != -1){
						out2.write(bytes);
					}
			        fileInput.close();
			        out2.close();
			        b2cShopperbargain.setAddfilename(addFileNamePaths);
				}else{
					modelMap.put("msg", "上传商户准入辅助材料请上传zip文件！");
					return queryShopPerbireg(request,modelMap);
				}
			}*/
			//前台jsp必须判断选择开户银行的省份，否则会出先错误。
			Area ares=shopPerbiService.searchBankProvincial(b2cShopperbi.getAccountbankprov());
			if(ares!=null){
				b2cShopperbi.setAccountbankprov(ares.getProvincialname());
			}
			b2cShopperbi.setShopperid(Long.valueOf(shopperid));
			if(b2cShopperbi.getProvince()!=null){
				List searchProvincialList=shopPerbiService.searchProvincial(b2cShopperbi.getProvince());
	    		if(searchProvincialList!=null&&searchProvincialList.size()>0){
	    			Area spro=(Area)searchProvincialList.get(0);
	        		if(spro!=null){
	        			String sprov=spro.getProvincialname();
	        			b2cShopperbi.setSprovince(sprov);
	        		}
	    		}
			}
			if(b2cShopperbi.getCity()!=null){
				List cityList = shopPerbiService.searchCity(b2cShopperbi
						.getCity());
				if (cityList != null && cityList.size() > 0) {
					Area area = (Area) cityList.get(0);
					if (area != null) {
						String cityName = (String) area.getCityname();
						b2cShopperbi.setScity(cityName);
		    		}
				}
			}
			String stel=request.getParameter("stel");
		//	String mpassword=StringUtils.getCharAndNumr(6);
		//	String Md5pwd=Md5Encrypt.md5(mpassword);
			b2cShopperbi.setMuserid(stel);
		//	b2cShopperbi.setMpassword(Md5pwd);
	        b2cShopperbi.setShopperidP(mbForm.getShopperid_p());
	        b2cShopperbi.setCreated(new Date());
	        b2cShopperbi.setIfvalid(new Short("0"));//是否审核
	        b2cShopperbi.setOpencheckstatus(new Short("0"));//开户行信息未审核
	        b2cShopperbi.setTermianlstatus("0");
	        b2cShopperbi.setIsformal(new Short("0"));
	        //设置复核初始值
	        b2cShopperbi.setRecheckmerchantflag("0");
	        b2cShopperbi.setRecheckaccountflag("0");
	        b2cShopperbi.setRecheckterminalflag("0");
	        b2cShopperbi.setPhotoCheckFlag("0");
	        b2cShopperbi.setPhotoRecheckFlag("0");
	        
//	    	if(b2cShopperbi.getIstopmerchant().toString().equals("0")){
//				b2cShopperbi.setTopfee(b2cShopperbi.getTopfee()*100);
//			}else{
//				b2cShopperbi.setTopfee(0.0);
//			}
	       /* b2cShopperbi.setMinsettlemoney(b2cShopperbi.getMinsettlemoney()*100);*/
//			shopPerbiService.insertB2cShopperbi(b2cShopperbi);
			Long shopperbiId = b2cShopperbi.getShopperid();
			
			//20151118  zzh  add
			b2cShopperbi.setSagentid(mbForm.getShopperid_p());
			b2cShopperbi.setReportResource("2");
			if(b2cShopperbi.getAccountBankProvCode()!=null){
				List searchProvincialList=shopPerbiService.searchProvincial(b2cShopperbi.getAccountBankProvCode());
	    		if(searchProvincialList!=null&&searchProvincialList.size()>0){
	    			Area spro=(Area)searchProvincialList.get(0);
	        		if(spro!=null){
	        			String sprov=spro.getProvincialname();
	        			b2cShopperbi.setAccountbankprov(sprov);
	        		}
	    		}
			}
			if(b2cShopperbi.getAccountBankCityCode()!=null){
				List cityList = shopPerbiService.searchCity(b2cShopperbi.getAccountBankCityCode());
				if (cityList != null && cityList.size() > 0) {
					Area area = (Area) cityList.get(0);
					if (area != null) {
						String cityName = (String) area.getCityname();
						b2cShopperbi.setAccountBankCity(cityName);
		    		}
				}
			}
			if(b2cShopperbi.getBillProvinceCode()!=null){
				List searchProvincialList=shopPerbiService.searchProvincial(b2cShopperbi.getBillProvinceCode());
	    		if(searchProvincialList!=null&&searchProvincialList.size()>0){
	    			Area spro=(Area)searchProvincialList.get(0);
	        		if(spro!=null){
	        			String sprov=spro.getProvincialname();
	        			b2cShopperbi.setBillProvince(sprov);
	        		}
	    		}
			}
			if(b2cShopperbi.getBillCityCode()!=null){
				List cityList = shopPerbiService.searchCity(b2cShopperbi.getBillCityCode());
				if (cityList != null && cityList.size() > 0) {
					Area area = (Area) cityList.get(0);
					if (area != null) {
						String cityName = (String) area.getCityname();
						b2cShopperbi.setBillCity(cityName);
		    		}
				}
			}
			// =得到web路径
			Map hashmap = new HashMap();
			String uploadpath = request.getSession().getServletContext().getRealPath("/");
			String uploadpath1 = uploadpath + "image1.jpg";
			String uploadpath2 = uploadpath + "image2.jpg";
			String uploadpath3 = uploadpath + "image3.jpg";
			String uploadpath4 = uploadpath + "image4.jpg";
			String uploadpath5 = uploadpath + "image5.jpg";
			String uploadpath6 = uploadpath + "image6.jpg";
			String uploadpath7 = uploadpath + "image7.jpg";
			String uploadpath8 = uploadpath + "image8.jpg";
			String uploadpath9 = uploadpath + "image9.jpg";
			InputStream input1 = mbForm.getHandidentitycardphoto().getInputStream();
			ImageCompressUtil.saveMinPhoto(input1, uploadpath1, 800, 0.9d);
			InputStream input11 = new FileInputStream(uploadpath1);

			InputStream input2 = mbForm.getFrontidentitycardphoto().getInputStream();
			ImageCompressUtil.saveMinPhoto(input2, uploadpath2, 800, 0.9d);
			InputStream input22 = new FileInputStream(uploadpath2);

			InputStream input3 = mbForm.getReverseidentitycardphoto().getInputStream();
			ImageCompressUtil.saveMinPhoto(input3, uploadpath3, 800, 0.9d);
			InputStream input33 = new FileInputStream(uploadpath3);

			InputStream input4 = mbForm.getStorephoto().getInputStream();
			ImageCompressUtil.saveMinPhoto(input4, uploadpath4, 800, 0.9d);
			InputStream input44 = new FileInputStream(uploadpath4);

			if (b2cShopperbi.getMerchantType().equals("1")) {
				InputStream input5 = mbForm.getInstorephoto().getInputStream();
				ImageCompressUtil.saveMinPhoto(input5, uploadpath5, 800, 0.9d);
				InputStream input55 = new FileInputStream(uploadpath5);
//				input5.close();
				InputStream input8 = mbForm.getLicensephoto().getInputStream();
				ImageCompressUtil.saveMinPhoto(input8, uploadpath6, 800, 0.9d);
				InputStream input88 = new FileInputStream(uploadpath6);
//				input8.close();
				String licensePhoto = photoString(input88);
				String instorePhoto = photoString(input55);
				hashmap.put("instorePhoto", instorePhoto.replace("+", "%2B"));
				hashmap.put("licensePhoto", licensePhoto.replace("+", "%2B"));
//				input55.close();
//				input88.close();
			}

			// InputStream input6 =
			// mbForm.getCheckstandphoto().getInputStream();
			InputStream input7 = mbForm.getSignaturephoto().getInputStream();
			ImageCompressUtil.saveMinPhoto(input7, uploadpath7, 800, 0.9d);
			InputStream input77 = new FileInputStream(uploadpath7);

			InputStream input9 = mbForm.getCreditCardPhoto().getInputStream();
			ImageCompressUtil.saveMinPhoto(input9, uploadpath8, 800, 0.9d);
			InputStream input99 = new FileInputStream(uploadpath8);

			InputStream input10 = mbForm.getSettlementCardPhoto().getInputStream();
			ImageCompressUtil.saveMinPhoto(input10, uploadpath9, 800, 0.9d);
			InputStream input1010 = new FileInputStream(uploadpath9);

			String identityId = b2cShopperbi.getIDNo();
			String shopperType = b2cShopperbi.getMerchantType();

			String handIdentityCardPhoto = photoString(input11);
			String frontIdentityCardPhoto = photoString(input22);
			String reverseIdentityCardPhoto = photoString(input33);
			String storePhoto = photoString(input44);

			// String checkstandPhoto =photoString(input6);
			String signaturePhoto = photoString(input77);
			String creditCardPhoto = photoString(input99);
			String settlementCardPhoto = photoString(input1010);

//			input1.close();input2.close();input3.close();input4.close();input7.close();input9.close();input10.close();
//			input11.close();input22.close();input33.close();input44.close();input77.close();input99.close();input1010.close();
			hashmap.put("identityId", identityId);
			hashmap.put("shopperType", shopperType);
			hashmap.put("handIdentityCardPhoto",handIdentityCardPhoto.replace("+", "%2B"));
			hashmap.put("frontIdentityCardPhoto",frontIdentityCardPhoto.replace("+", "%2B"));
			hashmap.put("reverseIdentityCardPhoto",reverseIdentityCardPhoto.replace("+", "%2B"));
			hashmap.put("storePhoto", storePhoto.replace("+", "%2B"));

			// hashmap.put("checkstandPhoto", checkstandPhoto);
			hashmap.put("signaturePhoto", signaturePhoto.replace("+", "%2B"));
			hashmap.put("creditCardPhoto", creditCardPhoto.replace("+", "%2B"));
			hashmap.put("settlementCardPhoto",settlementCardPhoto.replace("+", "%2B"));
			Map resultMap = HttpClientUtils.postRequestMap(PHOTO_URL,hashmap, Map.class);

			
			//插入图片，插入一条季度记录
			MposApplicationProgress  pro=new MposApplicationProgress();
			pro.setShopperid(shopperid);
			pro.setScompany(b2cShopperbi.getScompany());
			pro.setApplicationTheme("商户开通");
			pro.setApplicationType("1");
			pro.setCreateUser(((Users)request.getSession().getAttribute(Constants.SESSION_KEY_USER)).getId());
			pro.setCreateDate(new Date());
			pro.setShopperidP(mbForm.getShopperid_p().toString());
			pro.setAgentName(mbForm.getBelongsAgent());	
			pro.setApplicationStatus("1");
			//b2cShopperbargain.setBargainbdate(Global.String2Date(mbForm.getBargainbdates(), "yyyy-MM-dd"));
			//b2cShopperbargain.setBargainedate(Global.String2Date(mbForm.getBargainedates(),"yyyy-MM-dd"));
			//b2cShopperbargain.setBasecost(mbForm.getBasecost());
			//b2cShopperbargain.setWritebargain(Global.String2Date(mbForm.getWritebargains(),"yyyy-MM-dd"));
			//上传商户准入合规材料和上传商户准入辅助材料
			b2cShopperbargain.setShopperid(shopperbiId.toString());
//			shopPerbiService.insertB2cShopperbargain(b2cShopperbargain);
			
			String[] fees=request.getParameterValues("fees");
			String[] topamounts=request.getParameterValues("topamounts");
			//将t0fee做处理
			String t0fee=ToolsUtils.div(b2cShopperbi.getT0fee(), 100, 4);
			b2cShopperbi.setT0fee(Double.valueOf(t0fee));
			
			b2cShopperbi.setSettlementType(Constants.CON_NO);
			MposPhotoTmp photo1=photoservice.findbsid(b2cShopperbi.getIDNo());
			shopPerbiService.saveReg(b2cShopperbi,b2cShopperbargain,photo1,pro,fees,topamounts);
			request.setAttribute(Constants.MESSAGE_KEY,"注册成功!");
		    request.setAttribute("url","shopPerbi.htm?method=shopPerbiManageList");
		}catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.商户注册失败);
		}
	    return "/returnPage";

	}
	

	

	/**
	 * 添加user
	 * 
	 * @param userName
	 * @param mpassword
	 * @param shopperid
	 */
	public void addUsers(String userName,String mpassword,String shopperid,String locked){
		String Md5pwd=Md5Encrypt.md5(mpassword);
		HashMap map=new HashMap();
		map.put("userName", userName);
		map.put("pwd", Md5pwd);
		map.put("isagent", new Short("0"));
		map.put("createDate", new Date());
		map.put("merchantid", Long.valueOf(shopperid));
		map.put("locked", locked);
		//表示是否冻结 0 冻结 1 正常
		map.put("enabled", new Short("1"));
		shopPerbiService.addUser(map);
	}
	
	/**修改商户信息变更
	 * @param request
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=queryShopPerbiupdate")
	@FormToken(save=true)
	public String queryShopPerbiupdate(HttpServletRequest request, 
			ModelMap modelMap,B2cShopperbiTemp b2cShopperbi,
			B2cShopperbargainTemp b2cShopperbargain,
			@ModelAttribute("mb") ShopPerbiForm mbForm) throws Exception {
		try {
			String shopPerbiregId=request.getParameter("shopperpriId");
			if(StringUtils.isEmpty(shopPerbiregId)){
			    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url","shopPerbi.htm?method=shopPerbiCheckList");
			}else{
				b2cShopperbi=shopPerbiService.queryShopPerbi(shopPerbiregId);
			/*	b2cShopperbargain=shopPerbiService.queryShopPerbargain(shopPerbiregId);*/
			}
			/*Users users=shopPerbiService.selectByUserId(shopPerbiregId);
			request.setAttribute("merchant", users);*/
			//获取省
			List<Area> Provincial=shopPerbiService.searchProvince();
			request.setAttribute("Provincial",Provincial);
			//获取市
			List<Area> list = shopPerbiService.searchArea();
	    	request.setAttribute("area",list);
			//行业类型
			List cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
			request.setAttribute("cillinglist",cillinglist);
			//结算周期
			List footfreqlist =  shopPerbiService.searchFootFreqList();
	        request.setAttribute("footfreqlist",footfreqlist);
	        //服务商
	        String path = request.getSession().getServletContext().getContextPath();
	        request.setAttribute("agentlist",path+"agent/selectAgentTree.htm");
	        
	        if(b2cShopperbi!=null){
	        	//获取服务商
	            Long shopperId= b2cShopperbi.getShopperidP();
	            if(shopperId!=null){
	            	Agent agent=shopPerbiService.searchAgent(shopperId);
	                modelMap.put("agentName", agent.getScompany());
	                modelMap.put("agentId", agent.getShopperid());
	            }
	        }
	       /* List mccList =  mccService.searchMcc();
	        modelMap.put("mccList",mccList);
	        String agentMccName="";
	        String agentMccId="";
	        if(b2cShopperbi!=null&&b2cShopperbargain!=null){
	        	//获取服务商低价
	            Long baseCostId=b2cShopperbargain.getBasecost();
	            if(baseCostId!=null){
		    	    Map agentMccList=(HashMap)agentMccService.searchAgentMccById(baseCostId);
		            if(agentMccList!=null&&agentMccList.size()>0){
		                agentMccName=agentMccList.get("MCC_FEE").toString()+"	"+agentMccList.get("FIRM_NAME").toString()+"	底价	"+agentMccList.get("BASE_COST").toString();
		                agentMccId=agentMccList.get("AMID").toString();
		            }
	            }
	        }
	        modelMap.put("agentMccName", agentMccName);
	        modelMap.put("agentMccId", agentMccId);*/
	        
	        modelMap.put("feeList", shopPerbiService.selectFeeByShopperid1(b2cShopperbi.getShopperid()));
	        modelMap.put("b2cShopperbi", b2cShopperbi);
	      /*  modelMap.put("b2cShopperbargain", b2cShopperbargain);*/
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取商户信息失败);
		}
		
        
		return "shopPerbi/shopPerbiupdate";
	}
	
	/**查询商户的开户行信息
	 * @param request
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=queryShopPerbiBank")
	@FormToken(save=true)
	public String queryShopPerbiBank(HttpServletRequest request, 
			ModelMap modelMap,B2cShopperbiTemp b2cShopperbi,
			B2cShopperbargainTemp b2cShopperbargain,
			@ModelAttribute("mb") ShopPerbiForm mbForm) throws Exception {
		try {
			String shopPerbiregId=request.getParameter("shopperpriId");
			//获取省
			List<Area> Provincial=shopPerbiService.searchProvince();
			request.setAttribute("Provincial",Provincial);
			
			//获取银行
			List<B2cDict> dicbank = shopPerbiService.searchBank();
	    	request.setAttribute("bank",dicbank);
			
			if(StringUtils.isEmpty(shopPerbiregId)){
			    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url","shopPerbi.htm?method=shopPerbiCheckList");
			}else{
				b2cShopperbi=shopPerbiService.queryShopPerbi(shopPerbiregId);
				
			}
	        modelMap.put("b2cShopperbi", b2cShopperbi);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取商户信息失败);
		}
		return "shopPerbi/shopPerbiUpdateBank";
	}
	/**查看商户详情
	 * @param request
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=queryShopPerbiTerminal")
	@FormToken(save=true)
	public String queryShopPerbiTerminal(HttpServletRequest request, 
			ModelMap modelMap,B2cShopperbiTemp b2cShopperbi,
			B2cShopperbargain b2cShopperbargain,
			@ModelAttribute("mb") ShopPerbiForm mbForm) throws Exception {
		try {
			List<HashMap> Tershopper=null;
			List<HashMap> binderNum=null;
			String shopPerbiregId=request.getParameter("shopperpriId");
			String agentNo=request.getParameter("AgentNO");
			if(!StringUtils.isEmpty(agentNo)){
			    List<HashMap> agentNum=shopPerbiService.selectAgentNum(agentNo);
			    modelMap.put("agentNum", agentNum);
			}
			if(shopPerbiregId==null || StringUtils.isEmpty(shopPerbiregId)){
				shopPerbiregId=b2cShopperbi.getShopperid().toString();
			}
			if(StringUtils.isEmpty(shopPerbiregId)){
			    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url","shopPerbi.htm?method=shopPerbiManageList");
			}else{
				b2cShopperbi=shopPerbiService.queryShopPerbi(shopPerbiregId);
				Tershopper=shopPerbiService.shopperB2cTermBinder(shopPerbiregId);
				binderNum=shopPerbiService.selectBinderNum(shopPerbiregId);
			}
	        if(b2cShopperbi!=null){
	        	//获取服务商
	            Long shopperId= b2cShopperbi.getShopperidP();
	            if(shopperId!=null){
	            	Agent agent=shopPerbiService.searchAgent(shopperId);
	                modelMap.put("agentName", agent.getScompany());
	                modelMap.put("agentId", agent.getShopperid());
	            }
	        }
	        String b2cTermBinderNo="";
	        if(binderNum.size()>0){
			    for(int i=0;i<binderNum.size();i++){
			        b2cTermBinderNo+=binderNum.get(i).get("TERMINALID")+",";
				}
			    b2cTermBinderNo=b2cTermBinderNo.substring(0,b2cTermBinderNo.length()-1);
			}
	        modelMap.put("b2cShopperbi", b2cShopperbi);
	        modelMap.put("Tershopper", Tershopper);
	        request.getSession().setAttribute(Constants.SESSION_KEY_SHOPPER, b2cTermBinderNo);
	        System.out.println(request.getSession().getAttribute(Constants.SESSION_KEY_SHOPPER));
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取商户信息失败);
		}
		
        
		return "shopPerbi/bindTerminal";
	}
	
	
	/**查看商户详情
	 * @param request
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=ShopPerbiinfoDetails")
	@FormToken(save=true)
	public String ShopPerbiinfoDetails(HttpServletRequest request, 
			ModelMap modelMap,B2cShopperbiTemp b2cShopperbi,
			B2cShopperbargainTemp b2cShopperbargain,
			@ModelAttribute("mb") ShopPerbiForm mbForm) throws Exception {
		try {
			String shopPerbiregId=request.getParameter("shopperpriId");
			String terCount="0";
			if(StringUtils.isEmpty(shopPerbiregId)){
			    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url","shopPerbi.htm?method=shopPerbiManageList");
			}else{
				b2cShopperbi=shopPerbiService.queryShopPerbi(shopPerbiregId);
				/*b2cShopperbargain=shopPerbiService.queryShopPerbargain(shopPerbiregId);*/
			}
			/*Users users=shopPerbiService.selectByUserId(shopPerbiregId);
			request.setAttribute("merchant", users);*/
			//获取当前绑定终端的个数
			terCount=shopPerbiService.selectTerminalCount(shopPerbiregId);
			request.setAttribute("terCount", terCount);
			//获取当前商户绑定的终端
			List<HashMap> terminalInfo=shopPerbiService.shopperB2cTermBinder(shopPerbiregId);
			request.setAttribute("terminalInfo", terminalInfo);
			//获取省
			List<Area> Provincial=shopPerbiService.searchProvince();
			request.setAttribute("Provincial",Provincial);
			//获取市
			List<Area> list = shopPerbiService.searchArea();
	    	request.setAttribute("area",list);
			//获取银行
			B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval());
	    	request.setAttribute("bankName",dicbank);
			
	        //服务商
	        String path = request.getSession().getServletContext().getContextPath();
	        request.setAttribute("agentlist",path+"agent/selectAgentTree.htm");
	       /* //服务商手续费底价
	        String agentMccName="";
	        Long baseCostId=b2cShopperbargain.getBasecost();
	        if(baseCostId!=null){
		    	Map agentMccList=(HashMap)agentMccService.searchAgentMccById(baseCostId);
		        if(agentMccList!=null&&agentMccList.size()>0){
		            agentMccName=agentMccList.get("MCC_FEE").toString()+"	"+agentMccList.get("MCC_FEE").toString()+"	"+agentMccList.get("FIRM_NAME").toString()+"	底价	"+agentMccList.get("BASE_COST").toString();
		        	//agentMccName=agentMccList.get("FIRM_NAME").toString()+"	底价	"+agentMccList.get("BASE_COST").toString();
		        	
		        }
	        }*/
	        if(b2cShopperbi!=null){
	        	//获取服务商
	            Long shopperId= b2cShopperbi.getShopperidP();
	            if(shopperId!=null){
	            	Agent agent=shopPerbiService.searchAgent(shopperId);
	                modelMap.put("agentName", agent.getScompany());
	                modelMap.put("agentId", agent.getShopperid());
	            }
	        }
	        Long photoid = b2cShopperbi.getPhotoid();
			MposPhotoTmp photo =  shopPerbiService.selectPhotoTmpById(photoid);
			modelMap.put("photo", photo);
			modelMap.put("image_get_url", IMAGE_GET_URL);
			
			
			String shopperTel = null;
			if(b2cShopperbi!=null){
				shopperTel = b2cShopperbi.getStel();
			}
			// 手续费，临时表
			MposMerchantFee s0creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
			MposMerchantFee s0debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
			
			MposMerchantFee d0creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
			MposMerchantFee d0debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
			
			MposMerchantFee t1creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
			MposMerchantFee t1debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
			
			MposMerchantFee weChatMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId, Constants.FEE_TYPE_WECHAT2);
			MposMerchantFee alipayMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId, Constants.FEE_TYPE_ALIPAY2);
			MposMerchantFee ylpayMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId,Constants.FEE_TYPE_YLPAY);
			
			/**
			 * 10月20号添加速惠快捷D0费率临时
			 */
			MposMerchantFee shortCutSHMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId,Constants.FEE_TYPE_SHORTCUTSHD0);//7
			
			MposMerchantFee shortCutMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId,Constants.STATUS5);
			MposMerchantFee b2cMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId,Constants.STATUS6);
			request.setAttribute("shortCutSHMerchantFeeTemp", shortCutSHMerchantFeeTemp);
			request.setAttribute("shortCutMerchantFeeTemp", shortCutMerchantFeeTemp);
			request.setAttribute("b2cMerchantFeeTemp", b2cMerchantFeeTemp);
			
			request.setAttribute("s0creditMerchantFeeTemp", s0creditMerchantFeeTemp);
			request.setAttribute("s0debitMerchantFeeTemp", s0debitMerchantFeeTemp);
			
			request.setAttribute("d0creditMerchantFeeTemp", d0creditMerchantFeeTemp);
			request.setAttribute("d0debitMerchantFeeTemp", d0debitMerchantFeeTemp);
			
			request.setAttribute("t1creditMerchantFeeTemp", t1creditMerchantFeeTemp);
			request.setAttribute("t1debitMerchantFeeTemp", t1debitMerchantFeeTemp);
			
			request.setAttribute("weChatMerchantFeeTemp", weChatMerchantFeeTemp);
			request.setAttribute("alipayMerchantFeeTemp",  alipayMerchantFeeTemp);
			request.setAttribute("ylpayMerchantFeeTemp",ylpayMerchantFeeTemp);
			// 手续费
			MposMerchantFee s0creditMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
			if(s0creditMerchantFee==null&&shopperTel!=null){
				s0creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
			}
			MposMerchantFee s0debitMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
			if(s0debitMerchantFee==null&&shopperTel!=null){
				s0debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
			}
			
			MposMerchantFee d0creditMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
			if(d0creditMerchantFee==null&&shopperTel!=null){
				d0creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
			}
			MposMerchantFee d0debitMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
			if(d0debitMerchantFee==null&&shopperTel!=null){
				d0debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
			}
			
			MposMerchantFee t1creditMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
			if(t1creditMerchantFee==null&&shopperTel!=null){
				t1creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
			}
			MposMerchantFee t1debitMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
			if(t1debitMerchantFee==null&&shopperTel!=null){
				t1debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
			}
			
			MposMerchantFee weChatMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_WECHAT2);
			if(weChatMerchantFee==null&&shopperTel!=null){
				weChatMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_WECHAT);
			}
			MposMerchantFee alipayMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_ALIPAY2);
			if(alipayMerchantFee==null&&shopperTel!=null){
				alipayMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_ALIPAY);
			}
			MposMerchantFee ylpayMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId,Constants.FEE_TYPE_YLPAY);
			if(ylpayMerchantFee == null && shopperTel != null){
				ylpayMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_YLPAY);
			}
			
			/**
			 * 10月20号添加速惠快捷费率正式
			 */
			MposMerchantFee shortCutSHMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId,Constants.FEE_TYPE_SHORTCUTSHD0);
			
			MposMerchantFee shortCutMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId,Constants.STATUS5);
			MposMerchantFee b2cMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId,Constants.STATUS6);
			request.setAttribute("shortCutSHMerchantFee", shortCutSHMerchantFee);
			
			request.setAttribute("shortCutMerchantFee", shortCutMerchantFee);
			request.setAttribute("b2cMerchantFee", b2cMerchantFee);
			
			request.setAttribute("s0creditMerchantFee", s0creditMerchantFee);
			request.setAttribute("s0debitMerchantFee", s0debitMerchantFee);
			
			request.setAttribute("d0creditMerchantFee", d0creditMerchantFee);
			request.setAttribute("d0debitMerchantFee", d0debitMerchantFee);
			
			request.setAttribute("t1creditMerchantFee", t1creditMerchantFee);
			request.setAttribute("t1debitMerchantFee", t1debitMerchantFee);
			
			request.setAttribute("weChatMerchantFee", weChatMerchantFee);
			request.setAttribute("alipayMerchantFee", alipayMerchantFee);
			request.setAttribute("ylpayMerchantFee",ylpayMerchantFee);


			
	        modelMap.put("b2cShopperbi", b2cShopperbi);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取商户信息失败);
		}
		
        
		return "shopPerbi/shopPerbiInfoDetails";
	}
	/**查看商户详情
	 * @param request
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=updateShopPerbiDetails")
	@FormToken(save=true)
	public String updateShopPerbiDetails(HttpServletRequest request, 
			ModelMap modelMap,B2cShopperbiTemp b2cShopperbi,
			B2cShopperbargainTemp b2cShopperbargain,
			@ModelAttribute("mb") ShopPerbiForm mbForm) throws Exception {
		try {
			String shopPerbiregId=request.getParameter("shopperpriId");
			String terCount="0";
			if(StringUtils.isEmpty(shopPerbiregId)){
			    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url","shopPerbi.htm?method=shopPerbiManageList");
			}else{
				b2cShopperbi=shopPerbiService.queryShopPerbi(shopPerbiregId);
				/*b2cShopperbargain=shopPerbiService.queryShopPerbargain(shopPerbiregId);*/
			}
//			Users users=shopPerbiService.selectByUserId(shopPerbiregId);
//			request.setAttribute("merchant", users);
			/*  //服务商手续费底价
	        String agentMccName="";
	        Long baseCostId=b2cShopperbargain.getBasecost();
	        if(baseCostId!=null){
		    	Map agentMccList=(HashMap)agentMccService.searchAgentMccById(baseCostId);
		        if(agentMccList!=null&&agentMccList.size()>0){
		        	agentMccName=agentMccList.get("MCC_FEE").toString()+"	"+agentMccList.get("MCC_FEE").toString()+"	"+agentMccList.get("FIRM_NAME").toString()+"	底价	"+agentMccList.get("BASE_COST").toString();
		        	//agentMccName=agentMccList.get("FIRM_NAME").toString()+"	底价	"+agentMccList.get("BASE_COST").toString();
		        }
	        }
	        modelMap.put("agentMccName", agentMccName);*/
			//获取当前绑定终端的个数
			terCount=shopPerbiService.selectTerminalCount(shopPerbiregId);
			request.setAttribute("terCount", terCount);
			//获取当前商户绑定的终端
			List<HashMap> terminalInfo=shopPerbiService.shopperB2cTermBinder(shopPerbiregId);
			request.setAttribute("terminalInfo", terminalInfo);
			//获取省
			List<Area> Provincial=shopPerbiService.searchProvince();
			request.setAttribute("Provincial",Provincial);
			//获取市
			List<Area> list = shopPerbiService.searchArea();
	    	request.setAttribute("area",list);
			//获取银行
			B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval());
	    	request.setAttribute("bankName",dicbank);
			
	        //服务商
	        String path = request.getSession().getServletContext().getContextPath();
	        request.setAttribute("agentlist",path+"agent/selectAgentTree.htm");
	        
	        if(b2cShopperbi!=null){
	        	//获取服务商
	            Long shopperId= b2cShopperbi.getShopperidP();
	            if(shopperId!=null){
	            	Agent agent=shopPerbiService.searchAgent(shopperId);
	                modelMap.put("agentName", agent.getScompany());
	                modelMap.put("agentId", agent.getShopperid());
	            }
	        }
	        
	        modelMap.put("b2cShopperbi", b2cShopperbi);
	       /* modelMap.put("b2cShopperbargain", b2cShopperbargain);*/
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取商户信息失败);
		}
		
        
		return "shopPerbi/shopPerbiUpdateDetails";
	}
	/**查看商户详情
	 * @param request
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=queryShopPerbiFormalDetails")
	@FormToken(save=true)
	public String queryShopPerbiFormalDetails(HttpServletRequest request, 
			ModelMap modelMap,B2cShopperbi b2cShopperbi,
			B2cShopperbargain b2cShopperbargain,
			@ModelAttribute("mb") ShopPerbiForm mbForm) throws Exception {
		try {
			B2cShopperbiTemp Shopperbi=new B2cShopperbiTemp();
			String shopPerbiregId=request.getParameter("shopperpriId");
			String terCount="0";
			if(StringUtils.isEmpty(shopPerbiregId)){
			    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url","shopPerbi.htm?method=shopPerbiManageList");
			}else{
				b2cShopperbi=shopPerbiService.queryFormalShopPerbi(shopPerbiregId);
				/*b2cShopperbargain=shopPerbiService.queryFormalShopPerbargain(shopPerbiregId);*/
				Shopperbi=shopPerbiService.queryShopPerbi(shopPerbiregId);
			}
			
			request.setAttribute("Shopperbi", Shopperbi);
			Users users=shopPerbiService.selectByUserId(shopPerbiregId);
			request.setAttribute("merchant", users);
			 /* //服务商手续费底价
	        String agentMccName="";
	        Long baseCostId=b2cShopperbargain.getBasecost();
	        if(baseCostId==null||baseCostId.equals("")){
	        	baseCostId=new Long(0);
	        }
	        if(baseCostId!=null){
		    	Map agentMccList=(HashMap)agentMccService.searchAgentMccById(baseCostId);
		        if(agentMccList!=null&&agentMccList.size()>0){
		        	agentMccName=agentMccList.get("MCC_FEE").toString()+"	"+agentMccList.get("FIRM_NAME").toString()+"	底价	"+agentMccList.get("BASE_COST").toString();
		        }
	        }
	        modelMap.put("agentMccName", agentMccName);*/
			//获取当前绑定终端的个数
			terCount=shopPerbiService.selectTerminalCount(shopPerbiregId);
			request.setAttribute("terCount", terCount);
			//获取当前商户绑定的终端
			List<HashMap> terminalInfo=shopPerbiService.shopperB2cTermBinder(shopPerbiregId);
			request.setAttribute("terminalInfo", terminalInfo);
			//获取省
			List<Area> Provincial=shopPerbiService.searchProvince();
			request.setAttribute("Provincial",Provincial);
			//获取市
			List<Area> list = shopPerbiService.searchArea();
	    	request.setAttribute("area",list);
			//获取银行
			B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval());
	    	request.setAttribute("bankName",dicbank);
			
	        //服务商
	        String path = request.getSession().getServletContext().getContextPath();
	        request.setAttribute("agentlist",path+"agent/selectAgentTree.htm");
	        
	        if(b2cShopperbi!=null){
	        	//获取服务商
	            Long shopperId= b2cShopperbi.getShopperidP();
	            if(shopperId!=null){
	            	Agent agent=shopPerbiService.searchAgent(shopperId);
	                modelMap.put("agentName", agent.getScompany());
	                modelMap.put("agentId", agent.getShopperid());
	            }
	        }
	        
	        modelMap.put("b2cShopperbi", b2cShopperbi);
	        modelMap.put("feeList", shopPerbiService.selectFeeByShopperid1(b2cShopperbi.getShopperid()));
	      /*  modelMap.put("b2cShopperbargain", b2cShopperbargain);*/
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取商户信息失败);
		}
		
        
		return "shopPerbi/shopPerbiFormalDetails";
	}
	
	/**审核商户信息变更
	 * @param request
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=queryShopPerbiCheck")
	@FormToken(save=true)
	public String queryShopPerbiCheck(HttpServletRequest request, 
			ModelMap modelMap,B2cShopperbiTemp b2cShopperbi,
			B2cShopperbargainTemp b2cShopperbargain,
			@ModelAttribute("mb") ShopPerbiForm mbForm) throws Exception {
		try {
			String shopPerbiregId=request.getParameter("shopperpriId");
			if(StringUtils.isEmpty(shopPerbiregId)){
			    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url","shopPerbi.htm?method=shopPerbiCheckList");
			}else{
				b2cShopperbi=shopPerbiService.queryShopPerbi(shopPerbiregId);
				/*b2cShopperbargain=shopPerbiService.queryShopPerbargain(shopPerbiregId);*/
			}
			//获取省
			List<Area> Provincial=shopPerbiService.searchProvince();
			request.setAttribute("Provincial",Provincial);
			//获取市
			List<Area> list = shopPerbiService.searchArea();
	    	request.setAttribute("area",list);
			//获取银行
			B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval());
	    	request.setAttribute("bankName",dicbank);
			
	        //服务商
	        String path = request.getSession().getServletContext().getContextPath();
	        request.setAttribute("agentlist",path+"agent/selectAgentTree.htm");
	        
	        if(b2cShopperbi!=null){
	        	//获取服务商
	            Long shopperId= b2cShopperbi.getShopperidP();
	            if(shopperId!=null){
	            	Agent agent=shopPerbiService.searchAgent(shopperId);
	                modelMap.put("agentName", agent.getScompany());
	                modelMap.put("agentId", agent.getShopperid());
	            }
	        }
	        if(b2cShopperbi!=null){
	        	//获取服务商
	            Long shopperId= b2cShopperbi.getShopperidP();
	            if(shopperId!=null){
	            	Agent agent=shopPerbiService.searchAgent(shopperId);
	                modelMap.put("agentName", agent.getScompany());
	                modelMap.put("agentId", agent.getShopperid());
	            }
	        }
	        Long photoid = b2cShopperbi.getPhotoid();
			MposPhotoTmp photo =  shopPerbiService.selectPhotoTmpById(photoid);
	        
	        String shopperTel = null;
			if(b2cShopperbi!=null){
				shopperTel = b2cShopperbi.getStel();
			}
			// 手续费，临时表
			MposMerchantFee s0creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
			MposMerchantFee s0debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
			
			MposMerchantFee d0creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
			MposMerchantFee d0debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
			
			MposMerchantFee t1creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
			MposMerchantFee t1debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
			
			MposMerchantFee weChatMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId, Constants.FEE_TYPE_WECHAT2);
			MposMerchantFee alipayMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId, Constants.FEE_TYPE_ALIPAY2);
			MposMerchantFee ylpayMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId,Constants.FEE_TYPE_YLPAY);
			
			/**
			 * 10月20号添加，快捷收款t1费率，快捷收款d0费率，速惠收款费率（临时）
			 */
			MposMerchantFee shortCutMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId,Constants.STATUS5);
			MposMerchantFee b2cMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId,Constants.STATUS6);
			MposMerchantFee shortCutSHMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId,Constants.STATUS7);
			request.setAttribute("b2cMerchantFeeTemp", b2cMerchantFeeTemp);
			request.setAttribute("shortCutMerchantFeeTemp", shortCutMerchantFeeTemp);
			request.setAttribute("shortCutSHMerchantFeeTemp", shortCutSHMerchantFeeTemp);
			
			request.setAttribute("s0creditMerchantFeeTemp", s0creditMerchantFeeTemp);
			request.setAttribute("s0debitMerchantFeeTemp", s0debitMerchantFeeTemp);
			
			request.setAttribute("d0creditMerchantFeeTemp", d0creditMerchantFeeTemp);
			request.setAttribute("d0debitMerchantFeeTemp", d0debitMerchantFeeTemp);
			
			request.setAttribute("t1creditMerchantFeeTemp", t1creditMerchantFeeTemp);
			request.setAttribute("t1debitMerchantFeeTemp", t1debitMerchantFeeTemp);
			
			request.setAttribute("weChatMerchantFeeTemp", weChatMerchantFeeTemp);
			request.setAttribute("alipayMerchantFeeTemp",  alipayMerchantFeeTemp);
			request.setAttribute("ylpayMerchantFeeTemp",ylpayMerchantFeeTemp);
			// 手续费
			MposMerchantFee s0creditMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
			if(s0creditMerchantFee==null&&shopperTel!=null){
				s0creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
			}
			MposMerchantFee s0debitMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
			if(s0debitMerchantFee==null&&shopperTel!=null){
				s0debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
			}
			
			MposMerchantFee d0creditMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
			if(d0creditMerchantFee==null&&shopperTel!=null){
				d0creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
			}
			MposMerchantFee d0debitMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
			if(d0debitMerchantFee==null&&shopperTel!=null){
				d0debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
			}
			
			MposMerchantFee t1creditMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
			if(t1creditMerchantFee==null&&shopperTel!=null){
				t1creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
			}
			MposMerchantFee t1debitMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
			if(t1debitMerchantFee==null&&shopperTel!=null){
				t1debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
			}
			
			MposMerchantFee weChatMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_WECHAT2);
			if(weChatMerchantFee==null&&shopperTel!=null){
				weChatMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_WECHAT);
			}
			MposMerchantFee alipayMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_ALIPAY2);
			if(alipayMerchantFee==null&&shopperTel!=null){
				alipayMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_ALIPAY);
			}
			MposMerchantFee ylpayMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId,Constants.FEE_TYPE_YLPAY);
			if(ylpayMerchantFee == null && shopperTel != null){
				ylpayMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_YLPAY);
			}
			
			/**
			 * 10月20号添加快捷和速惠快捷（正式）
			 */
			
			MposMerchantFee b2cMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId,Constants.STATUS6);
			MposMerchantFee shortCutMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId,Constants.STATUS5);
			MposMerchantFee shortCutSHMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId,Constants.STATUS7);

			modelMap.put("b2cMerchantFee", b2cMerchantFee);
			modelMap.put("shortCutMerchantFee", shortCutMerchantFee);
			modelMap.put("shortCutSHMerchantFee", shortCutSHMerchantFee);
			
			modelMap.put("s0creditMerchantFee", s0creditMerchantFee);
			modelMap.put("s0debitMerchantFee", s0debitMerchantFee);
			modelMap.put("d0creditMerchantFee", d0creditMerchantFee);
			modelMap.put("d0debitMerchantFee", d0debitMerchantFee);
			modelMap.put("t1creditMerchantFee", t1creditMerchantFee);
			modelMap.put("t1debitMerchantFee", t1debitMerchantFee);
			modelMap.put("weChatMerchantFee", weChatMerchantFee);
			modelMap.put("alipayMerchantFee",  alipayMerchantFee);
			modelMap.put("ylpayMerchantFee",ylpayMerchantFee); 
	        modelMap.put("b2cShopperbi", b2cShopperbi);
			modelMap.put("photo", photo);
			modelMap.put("image_get_url", IMAGE_GET_URL);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取商户信息失败);
		}
		return "shopPerbi/shopPerbiDetails";
	}
	/**审核商户信息变更
	 * @param request
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=updateBankdetails")
	@FormToken(save=true)
	public String updateBankdetails(HttpServletRequest request, 
			ModelMap modelMap,B2cShopperbiTemp b2cShopperbi,
			B2cShopperbargainTemp b2cShopperbargain,
			@ModelAttribute("mb") ShopPerbiForm mbForm) throws Exception {
		try {
			String shopPerbiregId=request.getParameter("shopperpriId");
			if(StringUtils.isEmpty(shopPerbiregId)){
			    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url","shopPerbi.htm?method=shopPerbiCheckList");
			}else{
				b2cShopperbi=shopPerbiService.queryShopPerbi(shopPerbiregId);
				/*b2cShopperbargain=shopPerbiService.queryShopPerbargain(shopPerbiregId);*/
			}
			/*Users users=shopPerbiService.selectByUserId(shopPerbiregId);
			request.setAttribute("merchant", users);*/
			//获取省
			List<Area> Provincial=shopPerbiService.searchProvince();
			request.setAttribute("Provincial",Provincial);
			//获取市
			List<Area> list = shopPerbiService.searchArea();
	    	request.setAttribute("area",list);
			//行业类型
//			List cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
//			request.setAttribute("cillinglist",cillinglist);
//			
			//获取银行
			B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval());
	    	request.setAttribute("bankName",dicbank);
			
	        //服务商
	        String path = request.getSession().getServletContext().getContextPath();
	        request.setAttribute("agentlist",path+"agent/selectAgentTree.htm");
	        
	        if(b2cShopperbi!=null){
	        	//获取服务商
	            Long shopperId= b2cShopperbi.getShopperidP();
	            if(shopperId!=null){
	            	Agent agent=shopPerbiService.searchAgent(shopperId);
	                modelMap.put("agentName", agent.getScompany());
	                modelMap.put("agentId", agent.getShopperid());
	            }
	        }
	        
	        modelMap.put("b2cShopperbi", b2cShopperbi);
	       /* modelMap.put("b2cShopperbargain", b2cShopperbargain);*/
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取商户信息失败);
		}
		
        
		return "shopPerbi/shopPerbiBankInfo";
	}
	
	/**审核商户信息变更
	 * @param request
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=queryCheckBank")
	@FormToken(save=true)
	public String queryCheckBank(HttpServletRequest request, 
			ModelMap modelMap,B2cShopperbiTemp b2cShopperbi,
			B2cShopperbargainTemp b2cShopperbargain,
			@ModelAttribute("mb") ShopPerbiForm mbForm) throws Exception {
		try {
			String shopPerbiregId=request.getParameter("shopperpriId");
			if(StringUtils.isEmpty(shopPerbiregId)){
			    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url","shopPerbi.htm?method=shopPerbiCheckList");
			}else{
				b2cShopperbi=shopPerbiService.queryShopPerbi(shopPerbiregId);
				/*b2cShopperbargain=shopPerbiService.queryShopPerbargain(shopPerbiregId);*/
			}
//			Users users=shopPerbiService.selectByUserId(shopPerbiregId);
//			request.setAttribute("merchant", users);
			//获取省
			List<Area> Provincial=shopPerbiService.searchProvince();
			request.setAttribute("Provincial",Provincial);
			//获取市
			List<Area> list = shopPerbiService.searchArea();
	    	request.setAttribute("area",list);
			//行业类型
//			List cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
//			request.setAttribute("cillinglist",cillinglist);
//			
			//获取银行
			B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval());
	    	request.setAttribute("bankName",dicbank);
			
	        //服务商
	        String path = request.getSession().getServletContext().getContextPath();
	        request.setAttribute("agentlist",path+"agent/selectAgentTree.htm");
	        
	        if(b2cShopperbi!=null){
	        	//获取服务商
	            Long shopperId= b2cShopperbi.getShopperidP();
	            if(shopperId!=null){
	            	Agent agent=shopPerbiService.searchAgent(shopperId);
	                modelMap.put("agentName", agent.getScompany());
	                modelMap.put("agentId", agent.getShopperid());
	            }
	        }
	        
	        modelMap.put("b2cShopperbi", b2cShopperbi);
	      /*  modelMap.put("b2cShopperbargain", b2cShopperbargain);*/
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取商户信息失败);
		}
		
        
		return "shopPerbi/shopPerbiBankDetails";
	}
	/**商户信息开户信息修改后的信息
	 * @param request
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=queryBankinfo")
	@FormToken(save=true)
	public String queryBankinfo(HttpServletRequest request, 
			ModelMap modelMap,B2cShopperbi b2cShopperbi,
			B2cShopperbargain b2cShopperbargain,
			@ModelAttribute("mb") ShopPerbiForm mbForm) throws Exception {
		try {
			B2cShopperbiTemp shopper=new B2cShopperbiTemp();
			String shopPerbiregId=request.getParameter("shopperpriId");
			if(StringUtils.isEmpty(shopPerbiregId)){
			    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url","shopPerbi.htm?method=shopPerbiCheckList");
			}else{
				b2cShopperbi=shopPerbiService.queryFormalShopPerbi(shopPerbiregId);
				/*b2cShopperbargain=shopPerbiService.queryFormalShopPerbargain(shopPerbiregId);*/
				shopper=shopPerbiService.queryShopPerbi(shopPerbiregId);
			}
			request.setAttribute("shopper", shopper);
			/*Users users=shopPerbiService.selectByUserId(shopPerbiregId);
			request.setAttribute("merchant", users);*/
			//获取省
			List<Area> Provincial=shopPerbiService.searchProvince();
			request.setAttribute("Provincial",Provincial);
			//获取市
			List<Area> list = shopPerbiService.searchArea();
	    	request.setAttribute("area",list);
			//行业类型
//			List cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
//			request.setAttribute("cillinglist",cillinglist);
//			
			//获取银行
			B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval());
	    	request.setAttribute("bankName",dicbank);
			
	        //服务商
	        String path = request.getSession().getServletContext().getContextPath();
	        request.setAttribute("agentlist",path+"agent/selectAgentTree.htm");
	        
	        if(b2cShopperbi!=null){
	        	//获取服务商
	            Long shopperId= b2cShopperbi.getShopperidP();
	            if(shopperId!=null){
	            	Agent agent=shopPerbiService.searchAgent(shopperId);
	                modelMap.put("agentName", agent.getScompany());
	                modelMap.put("agentId", agent.getShopperid());
	            }
	        }
	        
	        modelMap.put("b2cShopperbi", b2cShopperbi);
	      /*  modelMap.put("b2cShopperbargain", b2cShopperbargain);*/
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取商户信息失败);
		}
		
        
		return "shopPerbi/shopPerbiBkupdateDetails";
	}
	
	/**审核终端信息变更
	 * @param request
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=queryCheckTerminal")
	@FormToken(save=true)
	public String queryCheckTerminal(HttpServletRequest request, 
			ModelMap modelMap,B2cShopperbiTemp b2cShopperbi,
			B2cShopperbargainTemp b2cShopperbargain,
			@ModelAttribute("mb") ShopPerbiForm mbForm) throws Exception {
		try {
			String shopPerbiregId=request.getParameter("shopperpriId");
			if(StringUtils.isEmpty(shopPerbiregId)){
			    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url","shopPerbi.htm?method=");
			}else{
				b2cShopperbi=shopPerbiService.queryShopPerbi(shopPerbiregId);
				/*b2cShopperbargain=shopPerbiService.queryShopPerbargain(shopPerbiregId);*/
			}

			
			//获取省
			List<Area> Provincial=shopPerbiService.searchProvince();
			request.setAttribute("Provincial",Provincial);
			//获取市
			List<Area> list = shopPerbiService.searchArea();
	    	request.setAttribute("area",list);

	        //服务商
	        String path = request.getSession().getServletContext().getContextPath();
	        request.setAttribute("agentlist",path+"agent/selectAgentTree.htm");
	        
	        if(b2cShopperbi!=null){
	        	//获取服务商
	            Long shopperId= b2cShopperbi.getShopperidP();
	            if(shopperId!=null){
	            	Agent agent=shopPerbiService.searchAgent(shopperId);
	                modelMap.put("agentName", agent.getScompany());
	                modelMap.put("agentId", agent.getShopperid());
	            }
	        }
	        
	        modelMap.put("b2cShopperbi", b2cShopperbi);
	       /* modelMap.put("b2cShopperbargain", b2cShopperbargain);*/
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取商户信息失败);
		}
		return "shopPerbi/shopPerbiCheckTerminal";
	}
	/**保存商户基本信息
	 * @param request
	 * @param response
	 * @param modelMap
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param mbForm
	 * @return
	 * @throws IOException
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=saveShopPerbiupdateList")
	@FormToken(remove=true)
	public String saveShopPerbiupdateList(HttpServletRequest request,B2cShopperbiTemp b2cShopperbi,B2cShopperbargainTemp b2cShopperbargain,
			@ModelAttribute("mb") ShopPerbiForm mbForm) throws Exception, BusinessException {
		try {
			
			String shopperpriIds=request.getParameter("shopperpriIds");
			
			if(StringUtils.isEmpty(shopperpriIds)){
			    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
				mbForm.setBelongsAgent(null);
				request.setAttribute("url","shopPerbi.htm?method=shopPerbiCheckList");
			}else{
				if(b2cShopperbi.getProvince()!=null){
					List searchProvincialList=shopPerbiService.searchProvincial(b2cShopperbi.getProvince());
		    		if(searchProvincialList!=null&&searchProvincialList.size()>0){
		    			Area spro=(Area)searchProvincialList.get(0);
		        		if(spro!=null){
		        			String sprov=spro.getProvincialname();
		        			b2cShopperbi.setSprovince(sprov);
		        		}
		    		}
				}
				if(b2cShopperbi.getCity()!=null){
					List cityList=shopPerbiService.searchCity(b2cShopperbi.getCity());
		    		if(cityList!=null&&cityList.size()>0){
		    			Area area=(Area)cityList.get(0);
		    			if(area!=null){
			        		String cityName=(String)area.getCityname();
			        		b2cShopperbi.setScity(cityName);
		    			}
		    		}
				}
				
				
				
				
				if(b2cShopperbi.getBillProvinceCode()!=null){
					List searchProvincialList=shopPerbiService.searchProvincial(b2cShopperbi.getBillProvinceCode());
		    		if(searchProvincialList!=null&&searchProvincialList.size()>0){
		    			Area spro=(Area)searchProvincialList.get(0);
		        		if(spro!=null){
		        			String sprov=spro.getProvincialname();
		        			b2cShopperbi.setBillProvince(sprov);
		        		}
		    		}
				}
				if(b2cShopperbi.getBillCityCode()!=null){
					List cityList=shopPerbiService.searchCity(b2cShopperbi.getBillCityCode());
		    		if(cityList!=null&&cityList.size()>0){
		    			Area area=(Area)cityList.get(0);
		    			if(area!=null){
			        		String cityName=(String)area.getCityname();
			        		b2cShopperbi.setBillCity(cityName);
		    			}
		    		}
				}
			/*	String path="http://"+request.getLocalAddr()+":"+request.getLocalPort()+request.getContextPath();
				
				String paths = request.getSession().getServletContext().getRealPath("\\").replaceAll("\\\\", "/");
			*/	
				String path=basePath;
				/*//上传商户准入合规材料
				String StdFileNamePath="upload"+sep+"StdFileNames";
				MultipartFile file =mbForm.getStdFileNames();
				String fileName = file.getOriginalFilename();
				int index = fileName.lastIndexOf("\\");
				String fileFileName = "";
				if(index == -1){
					fileFileName = fileName;
				}else{
					fileFileName = fileName.substring(index + 1);
				}
				if(!StringUtils.isEmpty(fileFileName)){
					String dateStr = DateFormatUtils.format(new Date(), "yyMMddHHmmss");
					String merchantRadom=org.apache.commons.lang.RandomStringUtils.randomNumeric(4);
					String namefile=dateStr+merchantRadom;
					String type = fileName.substring(fileName.lastIndexOf(".") + 1);
					if(type.equalsIgnoreCase("zip")){
						InputStream fileInputStream = file.getInputStream();
						String pdfName=namefile+".zip";
						
						File uploadFile = new File(path+sep+StdFileNamePath); 
						//检查文件是否已经存在
						if(!uploadFile.exists()){
							//建立文件
							uploadFile.mkdirs();
						}
						String stdFileNamePaths=path+sep+StdFileNamePath+sep+pdfName;
				        OutputStream out = new FileOutputStream(stdFileNamePaths);    
				        @SuppressWarnings("unused")
						int len = 0;//每次读取的字节数
						byte[] bytes = new byte[1024]; 
						while((len = fileInputStream.read(bytes, 0, bytes.length)) != -1){
							out.write(bytes);
						}
				        fileInputStream.close();
				        out.close();
				        b2cShopperbargain.setStdfilename(stdFileNamePaths);
					}
				}
		        //上传商户准入辅助材料
				String addFileNamePath="upload"+"AddFileNames";
				MultipartFile file2 =mbForm.getAddFileNames();
				String fileName2 = file2.getOriginalFilename();
				int index2 = fileName2.lastIndexOf("\\");
				String fileFileName2 = "";
				if(index2 == -1){
					fileFileName2 = fileName2;
				}else{
					fileFileName2 = fileName2.substring(index2 + 1);
				}
				if(!StringUtils.isEmpty(fileFileName2)){
					String dateStr2 = DateFormatUtils.format(new Date(), "yyMMddHHmmss");
					String merchantRadom2=org.apache.commons.lang.RandomStringUtils.randomNumeric(4);
					String namefile2=dateStr2+merchantRadom2;
					String type2 = fileName2.substring(fileName2.lastIndexOf(".") + 1);

					if(type2.equalsIgnoreCase("zip")){
						InputStream fileInput = file2.getInputStream();
						String pdfName2=namefile2+".zip";
						
						File uploadFile2 = new File(path+sep+addFileNamePath);
						//检查文件是否已经存在
						if(!uploadFile2.exists()){
							//建立文件
							uploadFile2.mkdirs();
						}
						String addFileNamePaths=path+sep+addFileNamePath+sep+pdfName2;
				        OutputStream out2 = new FileOutputStream(uploadFile2);    
				        @SuppressWarnings("unused")
						int len = 0;//每次读取的字节数
						byte[] bytes = new byte[1024]; 
						while((len = fileInput.read(bytes, 0, bytes.length)) != -1){
							out2.write(bytes);
						}
				        fileInput.close();
				        out2.close();
				        b2cShopperbargain.setAddfilename(addFileNamePaths);
					}
				}*/
				B2cShopperbiTemp shopper=shopPerbiService.queryShopPerbi(shopperpriIds);
				if(shopper.getIsformal().toString().equals("1")){
					b2cShopperbi.setIsupdateshopper(new Short("1"));//修改的标准
				}
				b2cShopperbi.setIfagent(new Long(0));//0为商户，1为服务商
				b2cShopperbi.setShopperidP(mbForm.getShopperid_p());
				b2cShopperbi.setUpdated(new Date());
				b2cShopperbi.setIfvalid(new Short("0"));
				
/*			    b2cShopperbi.setMinsettlemoney(b2cShopperbi.getMinsettlemoney()*100);*/
				b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
				//将复核标志改成0
				b2cShopperbi.setRecheckmerchantflag("0");
				b2cShopperbi.setRecheckmerchantremark("");
				//验证用户名密码是否改变
				String pwds=request.getParameter("pwd");
				String passwords=request.getParameter("mpasswordHidden");
				String userName=request.getParameter("uname");
				String hiddenName=request.getParameter("userNameHidden");
				/*
				if(!hiddenName.equals(userName.trim())){
					
				}*/
				b2cShopperbi.setMuserid(b2cShopperbi.getStel());
				//b2cShopperbargain.setBargainbdate(Global.String2Date(mbForm.getBargainbdates(), "yyyy-MM-dd"));
			//	b2cShopperbargain.setBargainedate(Global.String2Date(mbForm.getBargainedates(),"yyyy-MM-dd"));
				/*b2cShopperbargain.setShopperid(shopperpriIds);*/
				String bAgentId=mbForm.getShopperidq();
				//如果改变服务商，要删除以前绑定的终端 800110000015766
				if(bAgentId.equals(b2cShopperbi.getShopperidP().toString())){
					shopPerbiService.updateByShopperId(b2cShopperbi,b2cShopperbargain);
				}else{
					shopPerbiService.updateByB2cShopperId(b2cShopperbi,b2cShopperbargain,shopperpriIds);
				}
			}
			mbForm.setBelongsAgent(null);
			request.setAttribute(Constants.MESSAGE_KEY,"修改成功!");
		    request.setAttribute("url","shopPerbi.htm?method=shopPerbiManageList");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.保存商户修改信息失败);
		}
		
	    return "/returnPage";
	}
	
	/**修改商户开户行信息
	 * @param request
	 * @param response
	 * @param modelMap
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param mbForm
	 * @return
	 * @throws IOException
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=UpdateBankInfo")
	@FormToken(remove=true)
    public String UpdateBankInfo(HttpServletRequest request,
			HttpServletResponse response, ModelMap modelMap,
			B2cShopperbiTemp b2cShopperbi,B2cShopperbargainTemp b2cShopperbargain,
			@ModelAttribute("mb") ShopPerbiForm mbForm) throws Exception, BusinessException {
		try {
			String shopperpriIds=request.getParameter("shopperpriIds");
			b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
			b2cShopperbi.setUpdated(new Date());
			B2cShopperbiTemp shopper=shopPerbiService.queryShopPerbi(shopperpriIds);
			/*if(shopper.getIsformal().toString().equals("1")){
				String path="http://"+request.getLocalAddr()+":"+request.getLocalPort()+request.getContextPath();
				
				String paths = request.getSession().getServletContext().getRealPath("\\").replaceAll("\\\\", "/");
				
				String path=basePath;
				//上传商户准入合规材料
				String StdFileNamePath="upload"+sep+"BankFiles";
				MultipartFile file =mbForm.getBankfiles();
				String fileName = file.getOriginalFilename();
				int index = fileName.lastIndexOf("\\");
				String fileFileName = "";
				if(index == -1){
					fileFileName = fileName;
				}else{
					fileFileName = fileName.substring(index + 1);
				}
				if(!StringUtils.isEmpty(fileFileName)){
					String dateStr = DateFormatUtils.format(new Date(), "yyMMddHHmmss");
					String merchantRadom=org.apache.commons.lang.RandomStringUtils.randomNumeric(4);
					String namefile=dateStr+merchantRadom;
					String type = fileName.substring(fileName.lastIndexOf(".") + 1);
					if(type!="" || !StringUtils.isEmpty(type)){
						if(type.equalsIgnoreCase("xls")){
							InputStream fileInputStream = file.getInputStream();
							String pdfName=namefile+".xls";
							
							File uploadFile = new File(path+sep+StdFileNamePath); 
							//检查文件是否已经存在
							if(!uploadFile.exists()){
								//建立文件
								uploadFile.mkdirs();
							}
							String stdFileNamePaths=path+sep+StdFileNamePath+sep+pdfName;
					        OutputStream out = new FileOutputStream(stdFileNamePaths);    
					        @SuppressWarnings("unused")
							int len = 0;//每次读取的字节数
							byte[] bytes = new byte[1024]; 
							while((len = fileInputStream.read(bytes, 0, bytes.length)) != -1){
								out.write(bytes);
							}
					        fileInputStream.close();
					        out.close();
					        b2cShopperbi.setBankfile(stdFileNamePaths);
						}
						else{
							modelMap.put("msg", "商户开户行信息变更申请表上传xls文件！");
						    return queryShopPerbiBank(request,modelMap,shopper,b2cShopperbargain,mbForm);
						}
					}
				}
		    }*/
			
			MposMerchantFee merchantfee=this.shopPerbiService.querymerchantfee(shopperpriIds);
			BackupsShopperInformation bk=shopPerbiService.findbkshopper(new BigDecimal(shopperpriIds));
			BackupsShopperInformation bkshopper=new BackupsShopperInformation();
			//备份开户信息以及手续费信息 如果数据不存在 插入一条数据
			if(bk==null){
				bkshopper.setCreateUser(((Users)request.getSession().getAttribute(Constants.SESSION_KEY_USER)).getId().toString());
				bkshopper.setCreateDate(new Date());
				bkshopper.setT0fee(new BigDecimal(shopper.getT0fee()== null ? 0.0:shopper.getT0fee()));
				bkshopper.setT0topamount(new BigDecimal(shopper.getT0topamount()== null ? 0.0:shopper.getT0topamount()));
				bkshopper.setShopperid(new BigDecimal(shopper.getShopperid()== null ? 0.0:shopper.getShopperid()));
				bkshopper.setT0additionfee(new BigDecimal(shopper.getT0additionfee()== null ? 0.0 :shopper.getT0additionfee()));
				bkshopper.setT0fixedamount(new BigDecimal(shopper.getT0fixedamount()== null ? 0.0 :shopper.getT0fixedamount()));
				bkshopper.setT0maxamount(new BigDecimal(shopper.getT0maxamount()== null ? 0.0 :shopper.getT0maxamount()));
				bkshopper.setT0minamount(new BigDecimal(shopper.getT0minamount()== null ? 0.0 :shopper.getT0minamount()));
				bkshopper.setT0singledaylimit(new BigDecimal(shopper.getT0SingleDayLimit()== null ? 0.0 :shopper.getT0SingleDayLimit()));
				bkshopper.setT0type(shopper.getT0type()== null ? "" :shopper.getT0type());
				bkshopper.setAccountBankClientName(shopper.getAccountbankclientname()== null ? "" :shopper.getAccountbankclientname());
				bkshopper.setAccountBankDictval(shopper.getAccountbankdictval()== null ? "" :shopper.getAccountbankdictval());
				bkshopper.setAccountBankName(shopper.getAccountbankname()== null ? "" :shopper.getAccountbankname());
				bkshopper.setAccountBankNo(shopper.getAccountbankno()== null ? "" :shopper.getAccountbankno());
				bkshopper.setAccountBankProv(shopper.getAccountbankprov()== null ? "" :shopper.getAccountbankprov());
				bkshopper.setCardtype(shopper.getCardType()== null ? "" :shopper.getCardType());
				//bkshopper.setFee(new BigDecimal(merchantfee.getFee()== null ? "" :merchantfee.getFee()));
				//bkshopper.setTopAmount(new BigDecimal(merchantfee.getTopAmount()== null ? "" :merchantfee.getTopAmount()));
				if(merchantfee.getFee()== null||merchantfee.getFee()==""){
					bkshopper.setFee(new BigDecimal(0.0));
				}else{
					bkshopper.setFee(new BigDecimal(merchantfee.getFee()));
				}
				
				if(merchantfee.getTopAmount()== null||merchantfee.getTopAmount()==""){
					bkshopper.setTopAmount(new BigDecimal(0.0));
				}else{
					bkshopper.setTopAmount(new BigDecimal(merchantfee.getFee()));
				}
			}
			b2cShopperbi.setShopperidP(shopper.getShopperidP());
			b2cShopperbi.setScompany(shopper.getScompany());
			//前台jsp必须判断选择开户银行的省份，否则会出先错误。
			Area ares=shopPerbiService.searchBankProvincial(b2cShopperbi.getAccountbankprov());
			if(ares!=null){
				b2cShopperbi.setAccountbankprov(ares.getProvincialname());
			}
			b2cShopperbi.setUpdated(new Date());
			b2cShopperbi.setOpencheckstatus(new Short("0"));
			if(shopper.getIsformal().toString().equals("1")){
		        b2cShopperbi.setIsupdatebank(new Short("1"));
			}
			/*//前台jsp必须判断选择开户银行的省份，否则会出先错误。
			if(b2cShopperbi.getSettlementType().equals("0")){
				b2cShopperbi.setYsbNo("");
				b2cShopperbi.setYsbScompany("");
			}else{
				b2cShopperbi.setAccountbankclientname("");
				b2cShopperbi.setAccountbankdictval("");
				b2cShopperbi.setAccountbankname("");
				b2cShopperbi.setAccountbankno("");
				b2cShopperbi.setAccountbankother("");
				b2cShopperbi.setAccountbankprov("");
			}*/
			//修改时修改审核状态
			/*b2cShopperbi.setIfvalid(Short.valueOf(Constants.CON_NO));//初审记录
			b2cShopperbi.setRecheckmerchantflag(Constants.CON_NO);//复核
*/			
			//修改时修改审核状态
			b2cShopperbi.setOpencheckstatus(new Short("0"));//开户信息 初审
			b2cShopperbi.setRecheckaccountflag(Constants.CON_NO);//开户信息 复核
			
			shopPerbiService.updateBankInfo(b2cShopperbi,bkshopper);
			request.setAttribute(Constants.MESSAGE_KEY,"修改成功!");
			request.setAttribute("url","shopPerbi.htm?method=shopPerbiManageList");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.保存商户修改信息失败);
		}
		return "/returnPage";
	}
	
	/**保存商户基本信息
	 * @param request
	 * @param response
	 * @param modelMap
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param mbForm
	 * @return
	 * @throws IOException
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=saveShopPerbiCheck")
	@FormToken(remove=true)
    public String saveShopPerbiCheck(HttpServletRequest request, ModelMap modelMap,
			B2cShopperbiTemp b2cShopperbi,B2cShopperbargainTemp b2cShopperbargain,
			@ModelAttribute("mb") ShopPerbiForm mbForm) throws Exception, BusinessException {
		try {
			String shopperpriIds=request.getParameter("shopperpriIds");
			if(mbForm.getIfvalid()!=null&& mbForm.getIfvalid().equals("1"))
			{
				if(mbForm.getWorktime()!=null){
					b2cShopperbi.setWorktime(mbForm.getWorktime());
					b2cShopperbi.setIfvalid(new Short("1"));//审核通过
					b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
//					b2cShopperbi.setIsformal(new Short("1"));
					b2cShopperbi.setIsupdateshopper(new Short("1"));
//					shopPerbiService.updateCheckShopper(b2cShopperbi);
					b2cShopperbi.setCheckdate(new Date());
					b2cShopperbi.setPhotoCheckFlag("1");
					String remark="审核通过";
					shopPerbiService.updateCheckShopper1(b2cShopperbi,Constants.TYPE_2,Constants.TYPE_2,remark);

					/*B2cShopperbiTemp shopperbi=shopPerbiService.queryShopPerbi(shopperpriIds);
					shopPerbiService.updateShoppbi(shopperbi);*/
				}
				else{
					b2cShopperbi.setIfvalid(new Short("1"));//审核通过
					b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
//					b2cShopperbi.setIsformal(new Short("1"));
					b2cShopperbi.setIsupdateshopper(new Short("0"));
					b2cShopperbi.setOpencheckstatus(new Short("1"));//开户行信息审核通过
//					shopPerbiService.updateCheckShopper(b2cShopperbi);
					b2cShopperbi.setCheckdate(new Date());
					b2cShopperbi.setPhotoCheckFlag("1");
					String remark="审核通过";
					shopPerbiService.updateCheckShopper1(b2cShopperbi,Constants.TYPE_1,Constants.TYPE_2,remark);
			
					/*B2cShopperbiTemp shopperbi=shopPerbiService.queryShopPerbi(shopperpriIds);
					shopPerbiService.insertFormalB2cShopperbi(shopperbi);
					B2cShopperbargainTemp shopperbargian=shopPerbiService.queryShopPerbargain(shopperpriIds);
					shopPerbiService.insertFormalB2cShopperbargain(shopperbargian);*/
				}
			}else{
				b2cShopperbi.setIfvalid(new Short("2"));//审核不通过
				b2cShopperbi.setIsupdateshopper(new Short("0"));//商户审核不通过
				b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
				b2cShopperbi.setExamineresullt(mbForm.getExamineresullt());//初审不通过理由
				if(mbForm.getWorktime()!=null){
					String remark="审核不通过";
					b2cShopperbi.setCheckdate(new Date());
					shopPerbiService.updateCheckShopper1(b2cShopperbi,Constants.TYPE_2,Constants.TYPE_3,remark);
//					shopPerbiService.updateProgress(shopperpriIds,Constants.TYPE_2,Constants.TYPE_3,remark);
				}else{
					String remark="审核不通过";
					b2cShopperbi.setCheckdate(new Date());
					shopPerbiService.updateCheckShopper1(b2cShopperbi,Constants.TYPE_1,Constants.TYPE_3,remark);
//					shopPerbiService.updateProgress(shopperpriIds,Constants.TYPE_1,Constants.TYPE_3,remark);
			
				}
			}
			request.setAttribute(Constants.MESSAGE_KEY,"审核成功!");
			request.setAttribute("url","shopPerbi.htm?method=shopPerbiCheckList");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.审核失败);
		}
		return "/returnPage";
		
	}
	
	/**审核商户开户银行基本信息
	 * @param request
	 * @param response
	 * @param modelMap
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param mbForm
	 * @return
	 * @throws IOException
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=saveCheckBank")
	@FormToken(remove=true)
    public String saveCheckBank(HttpServletRequest request,
			HttpServletResponse response, ModelMap modelMap,
			B2cShopperbiTemp b2cShopperbi,B2cShopperbargainTemp b2cShopperbargain,
			@ModelAttribute("mb") ShopPerbiForm mbForm) throws Exception, BusinessException {
		try {
			String openCheck=mbForm.getOpencheckstatus();
			if(openCheck.equals("1")){
				String shopperpriIds=request.getParameter("shopperpriIds");
				b2cShopperbi.setOpencheckstatus(new Short("1"));//审核通过
				b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
				b2cShopperbi.setIsupdatebank(new Short("0"));
				b2cShopperbi.setRecheckaccountflag("0");
				String remark="审核通过";
				shopPerbiService.updateCheckShopper(b2cShopperbi,Constants.TYPE_3,Constants.TYPE_2,remark);

				
				
				request.setAttribute(Constants.MESSAGE_KEY,"审核成功!");
				request.setAttribute("url","shopPerbi.htm?method=shopPerbiBankList");
			}else{
				
				
				String shopperpriIds=request.getParameter("shopperpriIds");
				b2cShopperbi.setOpencheckstatus(new Short(openCheck));//审核不通过
				b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
				b2cShopperbi.setIsupdatebank(new Short("0"));
				b2cShopperbi.setRecheckaccountflag("0");
				String remark="审核不通过";
				
				//审核不通数据还原
				//审核不通过数据还原
				BackupsShopperInformation bkshopper=shopPerbiService.findbkshopper(new BigDecimal(shopperpriIds));
				b2cShopperbi.setAccountbankclientname(bkshopper.getAccountBankClientName());
				b2cShopperbi.setAccountbankdictval(bkshopper.getAccountBankDictval());
				b2cShopperbi.setAccountbankprov(bkshopper.getAccountBankProv());
				b2cShopperbi.setAccountbankname(bkshopper.getAccountBankName());
				b2cShopperbi.setAccountbankno(bkshopper.getAccountBankNo());
				
				shopPerbiService.updateCheckShopper(b2cShopperbi,Constants.TYPE_3,Constants.TYPE_2,remark);

//				shopPerbiService.updateCheckShopper(b2cShopperbi);
				request.setAttribute(Constants.MESSAGE_KEY,"审核成功!");
				request.setAttribute("url","shopPerbi.htm?method=shopPerbiBankList");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.审核失败);
		}
		
		return "/returnPage";
		
	}
	

	/**审核商户开户银行基本信息
	 * @param request
	 * @param response
	 * @param modelMap
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param mbForm
	 * @return
	 * @throws IOException
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=saveCheckTermianl")
	@FormToken(remove=true)
    public String saveCheckTermianl(HttpServletRequest request,
			HttpServletResponse response, ModelMap modelMap,
			B2cShopperbiTemp b2cShopperbi,B2cShopperbargainTemp b2cShopperbargain,
			@ModelAttribute("mb") ShopPerbiForm mbForm) throws Exception, BusinessException {
		try {
			String shopperpriIds=request.getParameter("shopperpriIds");
			b2cShopperbi.setTermianlstatus(mbForm.getTermianlstatus());//审核通过,或者不通过
			b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
			shopPerbiService.updateTermianl(b2cShopperbi,shopperpriIds,mbForm.getTermianlstatus());
			request.setAttribute(Constants.MESSAGE_KEY,"审核成功!");
			request.setAttribute("url","shopPerbi.htm?method=shopPerbiTerminalList");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.审核失败);
		}
		
		return "/returnPage";
		
	}
	/**验证企业全称是否存在
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(params="method=ajaxCheckScompany")
	public void ajaxCheckScompany(HttpServletRequest request,HttpServletResponse response ) throws IOException{
		try {
			String scompany=request.getParameter("scompany");
			if(StringUtils.isTrimNotEmpty(scompany)){
				scompany=scompany.trim();
			}
			B2cShopperbiTemp  b2cShopperbi=shopPerbiService.findB2cShopperbiScompany(scompany);
			PrintWriter out=response.getWriter();
			try {
				if(b2cShopperbi!=null){
					out.write("{\"x\":\"1\"}");
				}else{
					out.write("{\"x\":\"2\"}");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				if(out !=null){
					out.flush();
					out.close();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	/**绑定终端
	 * @param request
	 * @param modelMap
	 * @param mbForm
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=bindTerminal")
	@FormToken(save=true)
	public String bindTerminal(HttpServletRequest request, ModelMap modelMap,@ModelAttribute("mb") ShopPerbiForm mbForm) throws BusinessException {
		try {
			String shopperId=request.getParameter("shopperpriId");
			if(StringUtils.isEmpty(shopperId)){
				modelMap.put("errorMsg", "id为空！");
				mbForm.setBelongsAgent(null);
				return shopPerbiManageList(request,modelMap,mbForm);
			}
			else{
				B2cShopperbiTemp b2cShopperbi=shopPerbiService.queryShopPerbi(shopperId);
				List<B2cTermBinder> list=null;
				List<B2cTermBinder> b2cTermBinderList=null;
				String b2cTermBinderNo="";
		        if(b2cShopperbi!=null){
			        	//获取服务商
			        Long agentId= b2cShopperbi.getShopperidP();
			        if(shopperId!=null){
			        	Agent agent=shopPerbiService.searchAgent(agentId);
	                    modelMap.put("agentName", agent.getScompany());
	                    modelMap.put("agentId", agent.getShopperid());
			        }
					//查询出该服务商下面没有被挂载的pos终端
					list=shopPerbiService.selectByB2cTermBinder(shopperId,b2cShopperbi.getShopperidP().toString());
					b2cTermBinderList=shopPerbiService.selectByB2cTermBinderList(shopperId);
					if(b2cTermBinderList.size()>0){
					    for(int i=0;i<b2cTermBinderList.size();i++){
							B2cTermBinder b2cTermBinders=b2cTermBinderList.get(i);
					        b2cTermBinderNo+=b2cTermBinders.getTermNo()+",";
						}
					    b2cTermBinderNo=b2cTermBinderNo.substring(0,b2cTermBinderNo.length()-1);
					}
				}
				modelMap.put("b2cShopperbi", b2cShopperbi);
				modelMap.put("list", list);
				modelMap.put("b2cTermBinderNo", b2cTermBinderNo);
				return "shopPerbi/bindTerminal";
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取商户终端信息失败);
		}
		
	}
	
	/**保存商户--终端
	 * 1.根据商户删除以前的终端，再添加现在的终端！
	 * @param request
	 * @param modelMap
	 * @param mbForm
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=saveBindTerminal")
	@FormToken(remove=true)
	public String saveBindTerminal(HttpServletRequest request, ModelMap modelMap,@ModelAttribute("mb") ShopPerbiForm mbForm) throws Exception {
		try {
			String shopperid=mbForm.getShopperidq();
			String bindTerminal=mbForm.getTerminalNum();
			if(StringUtils.isEmpty(shopperid)||StringUtils.isEmpty(bindTerminal)){
				request.setAttribute(Constants.MESSAGE_KEY,"绑定失败，请重新绑定!");
			    request.setAttribute("url","shopPerbi.htm?method=shopPerbiManageList");
			}else{
				shopPerbiService.insertBindTerminal(shopperid,bindTerminal);
				request.setAttribute(Constants.MESSAGE_KEY,"绑定成功!");
			    request.setAttribute("url","shopPerbi.htm?method=shopPerbiManageList");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.商户终端信息绑定失败);
		}
	    return "/returnPage";
	}

	/**保存商户--终端
	 * 1.根据商户删除以前的终端，再添加现在的终端！
	 * @param request
	 * @param modelMap
	 * @param mbForm
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=saveTerminal")
	@FormToken(remove=true)
	public String saveTerminal(HttpServletRequest request,B2cShopperbargain b2cShopperbargain, ModelMap modelMap,@ModelAttribute("mb") ShopPerbiForm mbForm) throws Exception {
		try {
			String bindTerminal=mbForm.getTerminalNum();
			String hiddNum=mbForm.getHiddenNum();
			String shopPerbiregId=request.getParameter("shopPerbiregId");
			B2cShopperbiTemp shopperbi=new B2cShopperbiTemp();
			B2cShopperbiTemp shopper=shopPerbiService.queryShopPerbi(shopPerbiregId);
			List<HashMap> Tershopper=shopPerbiService.shopperB2cTermBinder(shopPerbiregId);
			if(StringUtils.isEmpty(bindTerminal)&&StringUtils.isEmpty(shopPerbiregId)){
				request.setAttribute(Constants.MESSAGE_KEY,"绑定失败，请重新绑定!");
			    request.setAttribute("url","shopPerbi.htm?method=shopPerbiManageList");
			}else{
				
				shopperbi.setShopperid(Long.valueOf(shopPerbiregId));
				shopperbi.setTermianlstatus("0");
				shopperbi.setRecheckterminalflag("0");
				shopPerbiService.updateTerminal(bindTerminal,hiddNum,shopperbi);
				request.setAttribute(Constants.MESSAGE_KEY,"绑定成功!");
			    request.setAttribute("url","shopPerbi.htm?method=shopPerbiManageList");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.商户终端信息绑定失败);
		}
	    return "/returnPage";
	}
	
	
	/**生成编码
	 * @param area
	 * @param mcc
	 * @return
	 * @throws Exception
	 */
	public  String getPosShopperId(String area, String mcc) throws Exception {
        String organization="800"; 
        String areacold="";
        if (area.length()>4) {
            areacold=area.substring(0,4);
        }else {
            areacold=area;
        }   
        String mcccold="";  
        if (mcc.length()==1) {
            mcccold="000"+mcc;
        }else {
            mcccold="00"+mcc;
        }
        String merchantRadom=RandomStringUtils.randomNumeric(4);
        String posMerchantId=organization+areacold+mcccold+merchantRadom;
        B2cShopperbiTemp b2cShopperbi=shopPerbiService.queryShopPerbi(posMerchantId);
        if(b2cShopperbi!=null){
            return getPosShopperId(area,mcc);
        }
        return posMerchantId;
    }
	
	/**
	 * 查询商户的证照信息
	 */
	@RequestMapping(params = "method=queryShopPerbiLicensePhoto")
	@FormToken(save=true)
	public String queryShopPerbiLicensePhoto(HttpServletRequest request, 
			ModelMap modelMap,B2cShopperbiTemp b2cShopperbi) throws Exception {
		try {
			String shopPerbiregId=request.getParameter("shopperpriId");
			
			if(StringUtils.isEmpty(shopPerbiregId)){
			    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
                request.setAttribute("url","shopPerbi.htm?method=shopPerbiCheckList");
			}else{
				b2cShopperbi=shopPerbiService.queryShopPerbi(shopPerbiregId);
				Long photoid = b2cShopperbi.getPhotoid();
				MposPhotoTmp photo =  shopPerbiService.selectPhotoTmpById(photoid);
				modelMap.put("photo", photo);
				modelMap.put("image_get_url", IMAGE_GET_URL);
			}
	        modelMap.put("b2cShopperbi", b2cShopperbi);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取商户信息失败);
		}
		return "shopPerbi/shopPerbiUpdateLicensePhoto";
	}
	
	/**
	 * 保存商户证照变更
	 */
	@RequestMapping(params = "method=saveShopPerbiLicensePhoto")
	@FormToken(remove=true)
	public String saveShopPerbiLicensePhoto(HttpServletRequest request, 
			ModelMap modelMap,B2cShopperbiTemp b2cShopperbi,
			ShopPerbiForm mbForm) throws Exception {
		String path=basePath;
		 Map hashmap=new HashMap();
		try {
		    
			String photoid =b2cShopperbi.getPhotoid().toString() ;
			if(photoid!=null){
			    hashmap.put("photoid", photoid);
			}
			
			String shopperType=b2cShopperbi.getMerchantType();
		//压缩照片
			
			
			String uploadpath = request.getSession().getServletContext().getRealPath("/");
			String uploadpath1 = uploadpath + "image1.jpg";
			String uploadpath2 = uploadpath + "image2.jpg";
			String uploadpath3 = uploadpath + "image3.jpg";
			String uploadpath4 = uploadpath + "image4.jpg";
			String uploadpath5 = uploadpath + "image5.jpg";
			String uploadpath6 = uploadpath + "image6.jpg";
			String uploadpath7 = uploadpath + "image7.jpg";
			String uploadpath8 = uploadpath + "image8.jpg";
			String uploadpath9 = uploadpath + "image9.jpg";
			
			
			InputStream input1 = mbForm.getHandidentitycardphoto().getInputStream();
			int inputsize1=inputsize(input1);
			
			if(inputsize1!=0){
				ImageCompressUtil.saveMinPhoto(input1, uploadpath1, 800, 0.9d);
				InputStream input11 = new FileInputStream(uploadpath1);
				String handIdentityCardPhoto = photoString(input11);
				 hashmap.put("handIdentityCardPhoto", handIdentityCardPhoto.replace("+", "%2B"));
			}
			InputStream input2 = mbForm.getFrontidentitycardphoto().getInputStream();
			int inputsize2=inputsize(input2);
			if(inputsize2!=0){
				ImageCompressUtil.saveMinPhoto(input2, uploadpath2, 800, 0.9d);
				InputStream input22 = new FileInputStream(uploadpath2);
				String frontIdentityCardPhoto = photoString(input22);
			    hashmap.put("frontIdentityCardPhoto", frontIdentityCardPhoto.replace("+", "%2B"));
			}
			
			
			InputStream input3 = mbForm.getReverseidentitycardphoto().getInputStream();
			int inputsize3=inputsize(input3);
			if(inputsize3!=0){
				ImageCompressUtil.saveMinPhoto(input3, uploadpath3, 800, 0.9d);
				InputStream input33 = new FileInputStream(uploadpath3);
				String reverseIdentityCardPhoto = photoString(input33);
				hashmap.put("reverseIdentityCardPhoto", reverseIdentityCardPhoto.replace("+", "%2B"));
			}
			
			
			InputStream input4 = mbForm.getStorephoto().getInputStream();
			int inputsize4=inputsize(input4);
			if(inputsize4!=0){
				ImageCompressUtil.saveMinPhoto(input4, uploadpath4, 800, 0.9d);
				InputStream input44 = new FileInputStream(uploadpath4);
				String storePhoto = photoString(input44);
				hashmap.put("storePhoto", storePhoto.replace("+", "%2B"));
			}
			
			
			InputStream input7 = mbForm.getSignaturephoto().getInputStream();
			int inputsize7=inputsize(input7);
			if(inputsize7!=0){
				ImageCompressUtil.saveMinPhoto(input7, uploadpath5, 800, 0.9d);
				InputStream input77 = new FileInputStream(uploadpath5);
				String signaturePhoto = photoString(input77);
				hashmap.put("signaturePhoto", signaturePhoto.replace("+", "%2B"));
			}
			
			
			InputStream input9 = mbForm.getCreditCardPhoto().getInputStream();
			int inputsize9=inputsize(input9);
			if(inputsize9!=0){
				ImageCompressUtil.saveMinPhoto(input9, uploadpath6, 800, 0.9d);
				InputStream input99 = new FileInputStream(uploadpath6);
				String creditCardPhoto = photoString(input99);
				hashmap.put("creditCardPhoto", creditCardPhoto.replace("+", "%2B"));
				    
			}
			
			InputStream input10 = mbForm.getSettlementCardPhoto().getInputStream();
			int inputsize10=inputsize(input10);
			if(inputsize10!=0){
				ImageCompressUtil.saveMinPhoto(input10, uploadpath7, 800, 0.9d);
				InputStream input1010 = new FileInputStream(uploadpath7);
				String settlementCardPhoto = photoString(input1010);
				hashmap.put("settlementCardPhoto", settlementCardPhoto.replace("+", "%2B"));
			}
			
		
			InputStream input5 = mbForm.getInstorephoto().getInputStream();	
			int inputsize5=inputsize(input5);
			if(inputsize5!=0){
				ImageCompressUtil.saveMinPhoto(input5, uploadpath8, 800, 0.9d);
				InputStream input55 = new FileInputStream(uploadpath8);
				String instorePhoto = photoString(input55);
				hashmap.put("instorePhoto", instorePhoto.replace("+", "%2B"));
			}
			
			
			InputStream input8 = mbForm.getLicensephoto().getInputStream();
			int inputsize8=inputsize(input8);
			if(inputsize8!=0){
				ImageCompressUtil.saveMinPhoto(input8, uploadpath9, 800, 0.9d);
				InputStream input88 = new FileInputStream(uploadpath9);
			    String licensePhoto = photoString(input88);
			    hashmap.put("licensePhoto", licensePhoto.replace("+", "%2B"));
			}
			
		
		
			
		   
		    hashmap.put("photoid", photoid);
		    hashmap.put("shopperType", shopperType);
		    Map resultMap=HttpClientUtils.postRequestMap(UPDATE_PHOTO,hashmap,Map.class);
		  
			//插入图片，插入一条季度记录
		    MposApplicationProgress ap=shopPerbiService.findMposApplicationProgress(b2cShopperbi.getShopperid().toString(), "5");
		    MposApplicationProgress  pro=new MposApplicationProgress();
		    if(ap==null){
		    	
				pro.setShopperid(mbForm.getShopperid());
				pro.setScompany(b2cShopperbi.getScompany());
				pro.setApplicationTheme("变更证照");
				pro.setApplicationType("5");
				pro.setCreateUser(((Users)request.getSession().getAttribute(Constants.SESSION_KEY_USER)).getId());
				pro.setCreateDate(new Date());
				pro.setShopperidP(mbForm.getShopperid_p().toString());
				pro.setAgentName(shopPerbiService.searchAgent(Long.valueOf(mbForm.getShopperid_p())).getScompany());	
				pro.setApplicationStatus("1");
		    }
		    b2cShopperbi.setPhotoRecheckFlag(Constants.CON_NO);
			b2cShopperbi.setPhotoCheckFlag(Constants.CON_NO);
			//返回值得到photo
			JSONObject ob=null;
			ob= JSONObject.fromObject(resultMap);
			Map  maphoto=(Map) ob.get("maphoto");
			shopPerbiService.updatePhoto1(maphoto,pro,photoid,b2cShopperbi);
			modelMap.put(Constants.MESSAGE_KEY,"修改成功!");
			modelMap.put("url","shopPerbi.htm?method=shopPerbiManageList");
		}catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.保存商户修改信息失败);
		}
		return "returnPage";
	}
	
	/**
	 * 判断商户号
	 * 
	 * @param userName
	 * @param mpassword
	 * @param shopperid
	 */
	public boolean isFigure(String shopperIdq){
		boolean b=shopperIdq.matches(Constants.CON_FIGURE);
		return b;
	}
	
	/**商户证照信息的审核列表
	 * @param request
	 * @param b2cShopperbiTmp
	 * @param b2cShopperbargainTmp
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
    @RequestMapping(params = "method=shopPerbiPhotoList")
	public String shopPerbiPhotoList(HttpServletRequest request, ModelMap modelMap,
			 @ModelAttribute("mb") ShopPerbiForm mbForm) throws Exception {
		try{
			
			Users  sessionUser=(Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
		    if(sessionUser==null || StringUtils.isEmpty(Long.toString(sessionUser.getMerchantid()))){
				throw new BusinessException(ExceptionDefine.商户查询失败);
			}
	        String shopperid=Long.toString(sessionUser.getMerchantid());
	        mbForm.setAgentNo(shopperid);
			request.getSession().setAttribute("shopperid", shopperid);
			List shopPerbilist = shopPerbiService.ShopPerbiCheckList(mbForm);
			modelMap.put("shopPerbilist", shopPerbilist);
			//获取省
			List<Area> Provincial=shopPerbiService.searchProvince();
			request.setAttribute("Provincial",Provincial);
			//获取市
			List<Area> list = shopPerbiService.searchArea();
	    	request.setAttribute("area",list);
	    	//获取未审核的商户开户行信息的个数
			String Tercount = shopPerbiService.selectTerminalCount(mbForm);
	    	request.setAttribute("Tercount",Tercount);
	    	
			request.setAttribute("belongsAgent", mbForm.getBelongsAgent());
		}catch (BusinessException e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.商户查询失败);
		}
		return "shopPerbi/shopPerbiPhotoList";
	}
	
	/**审核证照信息信息变更页面
	 * @param request
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=queryShopPerbiPhoto")
	@FormToken(save=true)
	public String queryShopPerbiPhoto(HttpServletRequest request, 
			ModelMap modelMap,B2cShopperbiTemp b2cShopperbi,
			B2cShopperbargainTemp b2cShopperbargain,
			ShopPerbiForm mbForm) throws Exception {
		try {
			String shopPerbiregId=request.getParameter("shopperpriId");
			if(StringUtils.isEmpty(shopPerbiregId)){
			    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url","shopPerbi.htm?method=shopPerbiCheckList");
			}else{
				b2cShopperbi=shopPerbiService.queryShopPerbi(shopPerbiregId);
			}
			MposPhotoTmp photo =  shopPerbiService.selectPhotoTmpById(b2cShopperbi.getPhotoid());
			modelMap.put("photo", photo);
			modelMap.put("image_get_url", IMAGE_GET_URL);
	        modelMap.put("b2cShopperbi", b2cShopperbi);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取商户信息失败);
		}
		return "shopPerbi/shopPerbiPhotoDetails";
	}
	
	/**审核证照信息信息详情
	 * @param request
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=ShopPerbiPhotoinfoDetails")
	@FormToken(save=true)
	public String ShopPerbiPhotoinfoDetails(HttpServletRequest request, 
			ModelMap modelMap,B2cShopperbiTemp b2cShopperbi,
			B2cShopperbargainTemp b2cShopperbargain,
			ShopPerbiForm mbForm) throws Exception {
		try {
			String shopPerbiregId=request.getParameter("shopperpriId");
			if(StringUtils.isEmpty(shopPerbiregId)){
			    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url","shopPerbi.htm?method=shopPerbiCheckList");
			}else{
				b2cShopperbi=shopPerbiService.queryShopPerbi(shopPerbiregId);
			}
			MposPhotoTmp photo =  shopPerbiService.selectPhotoTmpById(b2cShopperbi.getPhotoid());
			modelMap.put("photo", photo);
			modelMap.put("image_get_url", IMAGE_GET_URL);
	        modelMap.put("b2cShopperbi", b2cShopperbi);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取商户信息失败);
		}
		return "shopPerbi/shopPerbiPhotoInfoDetails";
	}
	
	/**
	 * 审核照片信息(保存):
	 */
	@RequestMapping(params = "method=saveShopPerbiPhoto")
	@FormToken(remove=true)
    public String saveShopPerbiPhoto(HttpServletRequest request, ModelMap modelMap,
			B2cShopperbiTemp b2cShopperbi,B2cShopperbargainTemp b2cShopperbargain,
			ShopPerbiForm mbForm) throws Exception, BusinessException {
		try {
			String shopperpriIds=request.getParameter("shopperpriIds");
			b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
			if(b2cShopperbi.getPhotoCheckFlag()!=null&&"1".equals(b2cShopperbi.getPhotoCheckFlag()))
			{
				b2cShopperbi.setPhotoCheckFlag("1");
				String remark="审核通过";
				shopPerbiService.updatephotoShopper(b2cShopperbi,Constants.TYPE_5,Constants.TYPE_2,remark);

			}else{
				b2cShopperbi.setPhotoCheckFlag("2");
				String remark="审核不通过";
				shopPerbiService.updatephotoShopper(b2cShopperbi,Constants.TYPE_5,Constants.TYPE_3,remark);

			}
//			shopPerbiService.updateCheckShopper(b2cShopperbi);
			request.setAttribute(Constants.MESSAGE_KEY,"审核成功!");
			request.setAttribute("url","shopPerbi.htm?method=shopPerbiPhotoList");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.审核失败);
		}
		return "/returnPage";
		
	}
	
	

	/**审核商户基本信息(保存):
	 * @param request
	 * @param response
	 * @param modelMap
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param mbForm
	 * @return
	 * @throws IOException
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=savedevicenum")
	@FormToken(remove=true)
    public String savedevicenum(HttpServletRequest request, ModelMap modelMap,
			B2cShopperbiTemp b2cShopperbi,B2cShopperbargainTemp b2cShopperbargain,
			ShopPerbiForm mbForm) throws Exception, BusinessException {
		try {
			String shopperpriIds=request.getParameter("shopperpriIds");
			if(mbForm.getIfvalid()!=null&& mbForm.getIfvalid().equals("1"))
			{
				//没有修改商户基本信息，
				b2cShopperbi.setIfvalid(new Short("1"));//审核通过
				b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
				b2cShopperbi.setIsupdateshopper(new Short("0"));
				b2cShopperbi.setOpencheckstatus(new Short("1"));//开户行信息审核通过
				String remark="审核通过";
				shopPerbiService.updateCheckShopper1(b2cShopperbi,Constants.TYPE_4,Constants.TYPE_2,remark);
				
			}else{
				b2cShopperbi.setIfvalid(new Short("2"));//审核不通过
				b2cShopperbi.setIsupdateshopper(new Short("0"));//商户审核不通过
				b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
				
				String remark="审核不通过";
				shopPerbiService.updateCheckShopper1(b2cShopperbi,Constants.TYPE_4,Constants.TYPE_3,remark);
			
			}
			request.setAttribute(Constants.MESSAGE_KEY,"审核成功!");
			request.setAttribute("url","shopPerbi.htm?method=shopPerbiTerminalList");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.审核失败);
		}
		return "/returnPage";
		
	}
	
	
	/**验证 身份证是否有存在的
	 *@param request
	 * @param response
	 * @throws 
	 * @throws IOException
	 */
	@RequestMapping(params="method=ajaxsid")
	public void ajaxsid(HttpServletRequest request,HttpServletResponse response) throws IOException{
		try {
			String IDNo=request.getParameter("IDNo");
			
			B2cShopperbiTemp shopper=null;
			if(StringUtils.isTrimNotEmpty(IDNo)){
				IDNo=IDNo.trim();
			    
				shopper=shopPerbiService.findbysid(IDNo);
			}
			PrintWriter out=response.getWriter();
			try {
				if((shopper!=null)){
					out.write("{\"x\":\"1\"}");
				}
				else{
					out.write("{\"x\":\"2\"}");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				if(out !=null){
					out.flush();
					out.close();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	/**是否有重复的电话号码存在
	 *@param request
	 * @param response
	 * @throws 
	 * @throws IOException
	 */
	@RequestMapping(params="method=ajaxCheckTel")
	public void ajaxCheckTel(HttpServletRequest request,HttpServletResponse response) throws IOException{
		try {
			String stel=request.getParameter("stel");
			
			B2cShopperbiTemp list=null;
			if(StringUtils.isTrimNotEmpty(stel)){
			    stel=stel.trim();
			    
			    list=shopPerbiService.findbytel(stel);
			}
			PrintWriter out=response.getWriter();
			try {
				if((list!=null)){
					out.write("{\"x\":\"1\"}");
				}
				else{
					out.write("{\"x\":\"2\"}");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				if(out !=null){
					out.flush();
					out.close();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	public String photoString(InputStream input1) throws IOException {
		byte[] data = null;
		// 读取图片字节数组
		try {
			data = new byte[input1.available()];
			input1.read(data);
			input1.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		String ss = Base64.encode(data);
		return ss;
	}
	
	 public int inputsize(InputStream input1) throws Exception{
	        byte[] by=new byte[1000];
	        int size=input1.available();
	        if(size==0){
	           System.out.println("文件为空!!");
	           return  size;
	        }
			return 1;
	    }
	
	 
	 
	 /**删除审核不通过的商户信息
		 * @param request
		 * @param b2cShopperbi
		 * @param b2cShopperbargain
		 * @param modelMap
		 * @return
		 * @throws Exception 
		 */
		@RequestMapping(params = "method=delshopper")
		@FormToken(save=true)
		public String delshopper(HttpServletRequest request, 
				ModelMap modelMap,B2cShopperbiTemp b2cShopperbi,
				B2cShopperbargainTemp b2cShopperbargain,
				ShopPerbiForm mbForm) throws Exception {
			try {
				String shopPerbiregId=request.getParameter("shopperpriId");
				if(StringUtils.isEmpty(shopPerbiregId)){
				    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
	                mbForm.setBelongsAgent(null);
	                request.setAttribute("url","shopPerbi.htm?method=shopPerbiCheckList");
				}else{
					b2cShopperbi=shopPerbiService.queryShopPerbi(shopPerbiregId);
				}
				//获取省
				List<Area> Provincial=shopPerbiService.searchProvince();
				request.setAttribute("Provincial",Provincial);
				//获取市
				List<Area> list = shopPerbiService.searchArea();
		    	request.setAttribute("area",list);
				//获取银行
				B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval());
		    	request.setAttribute("bankName",dicbank);
		    	Long photoid = b2cShopperbi.getPhotoid();
		    	if(photoid!=null){
		    		MposPhotoTmp photo =  shopPerbiService.selectPhotoTmpById(photoid);
					modelMap.put("photo", photo);
					modelMap.put("image_get_url", IMAGE_GET_URL);
		    	}
				
		        //服务商
		        String path = request.getSession().getServletContext().getContextPath();
		        request.setAttribute("agentlist",path+"agent/selectAgentTree.htm");
		        
		        if(b2cShopperbi!=null){
		        	//获取服务商
		            Long shopperId= b2cShopperbi.getShopperidP();
		            if(shopperId!=null){
		            	Agent agent=shopPerbiService.searchAgent(shopperId);
		                modelMap.put("agentName", agent.getScompany());
		                modelMap.put("agentId", agent.getShopperid());
		            }
		        }
		        modelMap.put("feeList", shopPerbiService.selectFeeByShopperid1(b2cShopperbi.getShopperid()));
		        modelMap.put("b2cShopperbi", b2cShopperbi);
			} catch (Exception e) {
				e.printStackTrace();
				throw new BusinessException(ExceptionDefine.获取商户信息失败);
			}
			return "shopPerbi/delresult";
		}
		
		
		/**初审不通过的记录删除
		 * 1.删除商户临时表
		 * 2.将远程邀请表，邀请数据撤回
		 * @param request
		 * @param modelMap
		 * @param mbForm
		 * @return
		 * @throws Exception
		 */
		@RequestMapping(params = "method=deleteShopperbi")
		public String deleteShopperbi(HttpServletRequest request, ModelMap modelMap,
				ShopPerbiForm mbForm,B2cShopperbiTemp b2cShopperbi)throws Exception {
			try{
				String shopperpriId=request.getParameter("shopperpriId");
				String delresult=request.getParameter("ysbScompany");
			if(org.apache.commons.lang.StringUtils.isNotEmpty(shopperpriId)){
				B2cShopperbiTemp  b2cShopperbiTemp=shopPerbiService.queryShopPerbi(shopperpriId);
				b2cShopperbiTemp.setYsbScompany(delresult);		
				if(b2cShopperbiTemp!=null){
					shopPerbiService.deleteShopperbi(b2cShopperbiTemp);
					request.setAttribute(Constants.MESSAGE_KEY,"删除成功!");
				}else{
					request.setAttribute(Constants.MESSAGE_KEY,"记录不存在!");
				}
			}else{
				request.setAttribute(Constants.MESSAGE_KEY,"id为空!");
				
			}
			request.setAttribute("url","shopPerbi.htm?method=shopPerbiManageList");
			}catch (Exception e) {
				e.printStackTrace();
				throw new BusinessException(ExceptionDefine.删除用户失败);
			}
			return "/returnPage";
		}	
		
		
		
		
		
		/**
		 * 显示照片，使照片可以旋转
		 * 
		 * @param request
		 * @param modelMap
		 * @param mbForm
		 * @return
		 * @throws Exception
		 */
		@RequestMapping(params = "method=showPhoto")
		public String showPhoto(HttpServletRequest request, ModelMap modelMap,
				ShopPerbiForm mbForm,B2cShopperbiTemp b2cShopperbi)throws Exception {
			try{
			   String photo=request.getParameter("photo");
				modelMap.put("photo", photo);
				modelMap.put("image_get_url", IMAGE_GET_URL);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			return "shopPerbi/showPhoto";
		}	
		
		
		
}
