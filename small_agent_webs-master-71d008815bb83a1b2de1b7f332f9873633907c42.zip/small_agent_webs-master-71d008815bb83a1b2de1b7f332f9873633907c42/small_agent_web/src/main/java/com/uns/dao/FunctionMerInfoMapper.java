package com.uns.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.FunctionMerInfo;
@Repository
public interface FunctionMerInfoMapper {

    int deleteByPrimaryKey(Long id);

    int insert(FunctionMerInfo record);
    
    int insertSelective(FunctionMerInfo record);
    
    List<FunctionMerInfo> selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(FunctionMerInfo record);

    int updateByPrimaryKey(FunctionMerInfo record);
    //查询有效的权限
	List<FunctionMerInfo> selectByStatus(Long valueOf);

	List<FunctionMerInfo> selectFunctionByUsercode1(String usercode);
}