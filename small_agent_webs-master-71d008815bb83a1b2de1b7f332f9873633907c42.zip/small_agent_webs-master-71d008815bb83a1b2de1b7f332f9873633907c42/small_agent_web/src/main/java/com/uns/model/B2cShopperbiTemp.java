package com.uns.model;

import java.util.Date;

public class B2cShopperbiTemp {
	private Long b2cShopperbiId;
	private String scompany;
	private String gateway;
	private String sqcode;
	private String synum;
	private String sicp;
	private String saddress;
	private String szip;
	private String smanager;
	private String srelation;
	private String semail;
	private String stel;
	private String sfax;
	private String shandset;
	private String sqq;
	private String smsn;
	private Long sshopertypeid;
	private String sshopertype;
	private String sdomain;
	private Long sshoppertypeid;
	private String sshoppertype;
	private String scity;//鍩庡競
	private String city;//鍩庡競缂栫爜
	private String sprovince;//鐪佷唤
	private String province;//鐪佷唤缂栫爜
	private Long transactid;
	private String transactsub;
	private String transact;
	private String operid;
	private String oper;
	private Long sifpactid;
	private String sifpact;
	private String spactoperid;
	private String spactoper;
	private Long sisnew;
	private String shoppercallingid;
	private String shoppercalling;
	private Date created;
	private Long shopperid;
	private Long sagentid;
	private Long battalion;
	private Long persentid;
	private Short ifattend;
	private Long ifagent;
	private Short shoppertypeid;
	private String srelationcredno;
	private String legalentity;
	private String srelationcrededate;
	private String legalecredno;
	private String legalecrededate;
	private String synumedate;
	private String licenseno;
	private String taxregisterno;
	private String remark;
	private String upoperid;
	private String upoper;
	private Date updated;
	private String grade;
	private String division;
	private Long shopperidP;
	private String shortname;
	private String levels;
	private Short ifvalid;
	private String accountbankdictval;
	private String accountbankname;
	private String accountbankclientname;
	private String accountbankno;
	private String  accountbankprov;
	private String accountbankother;
	private String istopmerchant;
	private Double topfee;
	private Double minsettlemoney;
	private String settlefrequency;
	private Short opencheckstatus;
	private String termianlstatus;
	private String termialfile;
	private String bankfile;
	private Date worktime;
	private Short isformal;//鍒ゆ柇姝ｅ紡琛ㄤ腑鏄惁鏈夋暟鎹�
	private Short isupdateshopper;//鍒ゆ柇鍟嗘埛鍩烘湰淇℃伅鏄惁淇敼
	private Short isupdatebank;//寮�埛淇℃伅鏄惁淇敼
	//缁撶畻鏂瑰紡
	private String settlementType;
	private String ysbNo;
	private String ysbScompany;
	//澶嶆牳
	private String 	recheckmerchantflag;
	private String 	recheckaccountflag;
	private String 	recheckterminalflag;
	private String 	recheckmerchantremark;
	private String 	recheckaccountremark;
	private String 	recheckterminalremark;
	//鐢ㄦ埛鍚嶅瘑鐮�
	private String	muserid;
	private String	mpassword;
    private Long  photoid;
    private String merchantType;
    private String name;
    private String IDNo;
    private String licenseNo;
    private String industry;
    private String billProvince;
    private String billProvinceCode;
    private String billCity;
    private String billCityCode;
    private String billAddress;
    private String billName;
    private String isSupportT0;
    private String isIcApplyT0;
    private Double T0fee;
    private Double T0SingleDayLimit;
    private String accountBankProvCode;
    private String accountBankCity;
    private String accountBankCityCode;
    private String reportResource;
    private String shopperlimit;
    private String evicenumber;
    private String parentid;
    private String factoringno;
    private String photoRecheckRemark;
    private String photoRecheckFlag;
    private String photoCheckFlag;
    private String  t0type;
    private String t1type; 
    private Double t0fixedamount; 
    private Double t0topamount; 
    private Double t0additionfee; 
    private Double t0minamount; 
    private Double t0maxamount; 
    private Double t1fee;
    private Double t1topamount;
    private String examineresullt;
    private String cardType;
    private String smsCode;
    private Date smsCodeDate;
    private Date checkdate;
    private Date recheckdate;
    private String orgNo;
    private String currentLocation;
    private String longitude;
    private String latitude;
    private String aiflag;
    private String merchantKey;
    private Date bankUpdateDate;
    private Date open_mpos_create_date;
    private String qrPayNo;
    private String qrpayMerchantkey;
    
    private String fixedqrcodeurl;
    private String fixedqrcodeflag;

	private String sex;//性别
	private Date birthday;//生日
	private String nation;//民族
	private String signunit;//身份证签发机关
	private String usefullife;//身份证有效期限
	private String creditBankDictval;//贷记卡银行数据字典
	private String creditBankNo;//贷记卡号
	private String creditBankUsefullife;//贷记卡有效期
	private String creditBankClientName;//贷记卡开卡人姓名
	private String creditBankClientIdNo;//贷记卡开卡人身份证号
	private String creditBankClientTel;//贷记卡开卡人手机号
	private String checkstatus;//审核状态OCR
	private String accountBankClientTel;//结算卡开卡人手机号
	private Date toManualauditDate;//转人工时间
	private String visualCheckStatus;//人工检查状态（OCR）
	private String notPassReason;//人工审核不通过文本原因（OCR）
	private String notPassStep;//人工审核不通过问题步骤（OCR）
	private String agentname;//所属服务商名称
	private String ifactivated;//激活状态
	private Date ifactivadate;//激活时间
    
    private String inviteCodeP;//上级商户邀请码
	private String licenseName;
	private String licenseAddress;
	private String accountBankLineNumber;

	public String getAccountBankLineNumber() {
		return accountBankLineNumber;
	}

	public void setAccountBankLineNumber(String accountBankLineNumber) {
		this.accountBankLineNumber = accountBankLineNumber;
	}

	public String getLicenseName() {
		return licenseName;
	}

	public void setLicenseName(String licenseName) {
		this.licenseName = licenseName;
	}

	public String getLicenseAddress() {
		return licenseAddress;
	}

	public void setLicenseAddress(String licenseAddress) {
		this.licenseAddress = licenseAddress;
	}

	public String getInviteCodeP() {
        return inviteCodeP;
    }

    public void setInviteCodeP(String inviteCodeP) {
        this.inviteCodeP = inviteCodeP;
    }

    public Date getIfactivadate() {
		return ifactivadate;
	}

	public void setIfactivadate(Date ifactivadate) {
		this.ifactivadate = ifactivadate;
	}

	public String getIfactivated() {
		return ifactivated;
	}

	public void setIfactivated(String ifactivated) {
		this.ifactivated = ifactivated;
	}

	public String getAgentname() {
		return agentname;
	}

	public void setAgentname(String agentname) {
		this.agentname = agentname;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public String getNation() {
		return nation;
	}

	public void setNation(String nation) {
		this.nation = nation;
	}

	public String getSignunit() {
		return signunit;
	}

	public void setSignunit(String signunit) {
		this.signunit = signunit;
	}

	public String getUsefullife() {
		return usefullife;
	}

	public void setUsefullife(String usefullife) {
		this.usefullife = usefullife;
	}

	public String getCreditBankDictval() {
		return creditBankDictval;
	}

	public void setCreditBankDictval(String creditBankDictval) {
		this.creditBankDictval = creditBankDictval;
	}

	public String getCreditBankNo() {
		return creditBankNo;
	}

	public void setCreditBankNo(String creditBankNo) {
		this.creditBankNo = creditBankNo;
	}

	public String getCreditBankUsefullife() {
		return creditBankUsefullife;
	}

	public void setCreditBankUsefullife(String creditBankUsefullife) {
		this.creditBankUsefullife = creditBankUsefullife;
	}

	public String getCreditBankClientName() {
		return creditBankClientName;
	}

	public void setCreditBankClientName(String creditBankClientName) {
		this.creditBankClientName = creditBankClientName;
	}

	public String getCreditBankClientIdNo() {
		return creditBankClientIdNo;
	}

	public void setCreditBankClientIdNo(String creditBankClientIdNo) {
		this.creditBankClientIdNo = creditBankClientIdNo;
	}

	public String getCreditBankClientTel() {
		return creditBankClientTel;
	}

	public void setCreditBankClientTel(String creditBankClientTel) {
		this.creditBankClientTel = creditBankClientTel;
	}

	public String getCheckstatus() {
		return checkstatus;
	}

	public void setCheckstatus(String checkstatus) {
		this.checkstatus = checkstatus;
	}

	public String getAccountBankClientTel() {
		return accountBankClientTel;
	}

	public void setAccountBankClientTel(String accountBankClientTel) {
		this.accountBankClientTel = accountBankClientTel;
	}

	public Date getToManualauditDate() {
		return toManualauditDate;
	}

	public void setToManualauditDate(Date toManualauditDate) {
		this.toManualauditDate = toManualauditDate;
	}

	public String getVisualCheckStatus() {
		return visualCheckStatus;
	}

	public void setVisualCheckStatus(String visualCheckStatus) {
		this.visualCheckStatus = visualCheckStatus;
	}

	public String getNotPassReason() {
		return notPassReason;
	}

	public void setNotPassReason(String notPassReason) {
		this.notPassReason = notPassReason;
	}

	public String getNotPassStep() {
		return notPassStep;
	}

	public void setNotPassStep(String notPassStep) {
		this.notPassStep = notPassStep;
	}

	public String getFixedqrcodeurl() {
		return fixedqrcodeurl;
	}
	public void setFixedqrcodeurl(String fixedqrcodeurl) {
		this.fixedqrcodeurl = fixedqrcodeurl;
	}
	public String getFixedqrcodeflag() {
		return fixedqrcodeflag;
	}
	public void setFixedqrcodeflag(String fixedqrcodeflag) {
		this.fixedqrcodeflag = fixedqrcodeflag;
	}
	public String getQrPayNo() {
		return qrPayNo;
	}
	public void setQrPayNo(String qrPayNo) {
		this.qrPayNo = qrPayNo;
	}
	public String getQrpayMerchantkey() {
		return qrpayMerchantkey;
	}
	public void setQrpayMerchantkey(String qrpayMerchantkey) {
		this.qrpayMerchantkey = qrpayMerchantkey;
	}
	public Date getOpen_mpos_create_date() {
		return open_mpos_create_date;
	}
	public void setOpen_mpos_create_date(Date open_mpos_create_date) {
		this.open_mpos_create_date = open_mpos_create_date;
	}
	public Date getBankUpdateDate() {
		return bankUpdateDate;
	}
	public void setBankUpdateDate(Date bankUpdateDate) {
		this.bankUpdateDate = bankUpdateDate;
	}
	public String getMerchantKey() {
		return merchantKey;
	}
	public void setMerchantKey(String merchantKey) {
		this.merchantKey = merchantKey;
	}
	public String getCurrentLocation() {
		return currentLocation;
	}
	public void setCurrentLocation(String currentLocation) {
		this.currentLocation = currentLocation;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getAiflag() {
		return aiflag;
	}
	public void setAiflag(String aiflag) {
		this.aiflag = aiflag;
	}
	public String getOrgNo() {
		return orgNo;
	}
	public void setOrgNo(String orgNo) {
		this.orgNo = orgNo;
	}
	public Date getCheckdate() {
		return checkdate;
	}
	public void setCheckdate(Date checkdate) {
		this.checkdate = checkdate;
	}
	public Date getRecheckdate() {
		return recheckdate;
	}
	public void setRecheckdate(Date recheckdate) {
		this.recheckdate = recheckdate;
	}
	public String getSmsCode() {
		return smsCode;
	}
	public void setSmsCode(String smsCode) {
		this.smsCode = smsCode;
	}
	public Date getSmsCodeDate() {
		return smsCodeDate;
	}
	public void setSmsCodeDate(Date smsCodeDate) {
		this.smsCodeDate = smsCodeDate;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public String getExamineresullt() {
		return examineresullt;
	}
	public void setExamineresullt(String examineresullt) {
		this.examineresullt = examineresullt;
	}
	public Double getT1fee() {
		return t1fee;
	}
	public void setT1fee(Double t1fee) {
		this.t1fee = t1fee;
	}
	public Double getT1topamount() {
		return t1topamount;
	}
	public void setT1topamount(Double t1topamount) {
		this.t1topamount = t1topamount;
	}
	public String getT1type() {
		return t1type;
	}
	public void setT1type(String t1type) {
		this.t1type = t1type;
	}
	public Double getT0fixedamount() {
		return t0fixedamount;
	}
	public void setT0fixedamount(Double t0fixedamount) {
		this.t0fixedamount = t0fixedamount;
	}
	public Double getT0topamount() {
		return t0topamount;
	}
	public void setT0topamount(Double t0topamount) {
		this.t0topamount = t0topamount;
	}
	public Double getT0additionfee() {
		return t0additionfee;
	}
	public void setT0additionfee(Double t0additionfee) {
		this.t0additionfee = t0additionfee;
	}
	public Double getT0minamount() {
		return t0minamount;
	}
	public void setT0minamount(Double t0minamount) {
		this.t0minamount = t0minamount;
	}
	public Double getT0maxamount() {
		return t0maxamount;
	}
	public void setT0maxamount(Double t0maxamount) {
		this.t0maxamount = t0maxamount;
	}
	public String getT0type() {
		return t0type;
	}
	public void setT0type(String t0type) {
		this.t0type = t0type;
	}
	public String getPhotoRecheckRemark() {
		return photoRecheckRemark;
	}
	public void setPhotoRecheckRemark(String photoRecheckRemark) {
		this.photoRecheckRemark = photoRecheckRemark;
	}
	public String getPhotoRecheckFlag() {
		return photoRecheckFlag;
	}
	public void setPhotoRecheckFlag(String photoRecheckFlag) {
		this.photoRecheckFlag = photoRecheckFlag;
	}
	public String getPhotoCheckFlag() {
		return photoCheckFlag;
	}
	public void setPhotoCheckFlag(String photoCheckFlag) {
		this.photoCheckFlag = photoCheckFlag;
	}
	public String getParentid() {
		return parentid;
	}
	public void setParentid(String parentid) {
		this.parentid = parentid;
	}
	public String getFactoringno() {
		return factoringno;
	}
	public void setFactoringno(String factoringno) {
		this.factoringno = factoringno;
	}
	public String getBillProvinceCode() {
		return billProvinceCode;
	}
	public void setBillProvinceCode(String billProvinceCode) {
		this.billProvinceCode = billProvinceCode;
	}
	public String getShopperlimit() {
		return shopperlimit;
	}
	public void setShopperlimit(String shopperlimit) {
		this.shopperlimit = shopperlimit;
	}
	public String getEvicenumber() {
		return evicenumber;
	}
	public void setEvicenumber(String evicenumber) {
		this.evicenumber = evicenumber;
	}
	public String getMerchantType() {
		return merchantType;
	}
	public void setMerchantType(String merchantType) {
		this.merchantType = merchantType;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIDNo() {
		return IDNo;
	}
	public void setIDNo(String iDNo) {
		IDNo = iDNo;
	}
	public String getLicenseNo() {
		return licenseNo;
	}
	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getBillProvince() {
		return billProvince;
	}
	public void setBillProvince(String billProvince) {
		this.billProvince = billProvince;
	}
	public String getBillCity() {
		return billCity;
	}
	public void setBillCity(String billCity) {
		this.billCity = billCity;
	}
	public String getBillCityCode() {
		return billCityCode;
	}
	public void setBillCityCode(String billCityCode) {
		this.billCityCode = billCityCode;
	}
	
	public String getBillAddress() {
		return billAddress;
	}
	public void setBillAddress(String billAddress) {
		this.billAddress = billAddress;
	}
	public String getBillName() {
		return billName;
	}
	public void setBillName(String billName) {
		this.billName = billName;
	}
	public String getIsSupportT0() {
		return isSupportT0;
	}
	public void setIsSupportT0(String isSupportT0) {
		this.isSupportT0 = isSupportT0;
	}
	
	public String getIsIcApplyT0() {
		return isIcApplyT0;
	}
	public void setIsIcApplyT0(String isIcApplyT0) {
		this.isIcApplyT0 = isIcApplyT0;
	}
	

	public Double getT0fee() {
		return T0fee;
	}
	public void setT0fee(Double t0fee) {
		T0fee = t0fee;
	}
	public Double getT0SingleDayLimit() {
		return T0SingleDayLimit;
	}
	public void setT0SingleDayLimit(Double t0SingleDayLimit) {
		T0SingleDayLimit = t0SingleDayLimit;
	}
	public String getAccountBankProvCode() {
		return accountBankProvCode;
	}
	public void setAccountBankProvCode(String accountBankProvCode) {
		this.accountBankProvCode = accountBankProvCode;
	}
	public String getAccountBankCity() {
		return accountBankCity;
	}
	public void setAccountBankCity(String accountBankCity) {
		this.accountBankCity = accountBankCity;
	}
	public String getAccountBankCityCode() {
		return accountBankCityCode;
	}
	public void setAccountBankCityCode(String accountBankCityCode) {
		this.accountBankCityCode = accountBankCityCode;
	}
	public String getReportResource() {
		return reportResource;
	}
	public void setReportResource(String reportResource) {
		this.reportResource = reportResource;
	}
	public Long getPhotoid() {
		return photoid;
	}
	public void setPhotoid(Long photoid) {
		this.photoid = photoid;
	}
	public Long getB2cShopperbiId() {
		return b2cShopperbiId;
	}
	public void setB2cShopperbiId(Long b2cShopperbiId) {
		this.b2cShopperbiId = b2cShopperbiId;
	}
	public String getScompany() {
		return scompany;
	}
	public void setScompany(String scompany) {
		this.scompany = scompany;
	}
	public String getGateway() {
		return gateway;
	}
	public void setGateway(String gateway) {
		this.gateway = gateway;
	}
	public String getSqcode() {
		return sqcode;
	}
	public void setSqcode(String sqcode) {
		this.sqcode = sqcode;
	}
	public String getSynum() {
		return synum;
	}
	public void setSynum(String synum) {
		this.synum = synum;
	}
	public String getSicp() {
		return sicp;
	}
	public void setSicp(String sicp) {
		this.sicp = sicp;
	}
	public String getSaddress() {
		return saddress;
	}
	public void setSaddress(String saddress) {
		this.saddress = saddress;
	}
	public String getSzip() {
		return szip;
	}
	public void setSzip(String szip) {
		this.szip = szip;
	}
	public String getSmanager() {
		return smanager;
	}
	public void setSmanager(String smanager) {
		this.smanager = smanager;
	}
	public String getSrelation() {
		return srelation;
	}
	public void setSrelation(String srelation) {
		this.srelation = srelation;
	}
	public String getSemail() {
		return semail;
	}
	public void setSemail(String semail) {
		this.semail = semail;
	}
	public String getStel() {
		return stel;
	}
	public void setStel(String stel) {
		this.stel = stel;
	}
	public String getSfax() {
		return sfax;
	}
	public void setSfax(String sfax) {
		this.sfax = sfax;
	}
	public String getShandset() {
		return shandset;
	}
	public void setShandset(String shandset) {
		this.shandset = shandset;
	}
	public String getSqq() {
		return sqq;
	}
	public void setSqq(String sqq) {
		this.sqq = sqq;
	}
	public String getSmsn() {
		return smsn;
	}
	public void setSmsn(String smsn) {
		this.smsn = smsn;
	}
	public Long getSshopertypeid() {
		return sshopertypeid;
	}
	public void setSshopertypeid(Long sshopertypeid) {
		this.sshopertypeid = sshopertypeid;
	}
	public String getSshopertype() {
		return sshopertype;
	}
	public void setSshopertype(String sshopertype) {
		this.sshopertype = sshopertype;
	}
	public String getSdomain() {
		return sdomain;
	}
	public void setSdomain(String sdomain) {
		this.sdomain = sdomain;
	}
	public Long getSshoppertypeid() {
		return sshoppertypeid;
	}
	public void setSshoppertypeid(Long sshoppertypeid) {
		this.sshoppertypeid = sshoppertypeid;
	}
	public String getSshoppertype() {
		return sshoppertype;
	}
	public void setSshoppertype(String sshoppertype) {
		this.sshoppertype = sshoppertype;
	}
	public String getScity() {
		return scity;
	}
	public void setScity(String scity) {
		this.scity = scity;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getSprovince() {
		return sprovince;
	}
	public void setSprovince(String sprovince) {
		this.sprovince = sprovince;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public Long getTransactid() {
		return transactid;
	}
	public void setTransactid(Long transactid) {
		this.transactid = transactid;
	}
	public String getTransactsub() {
		return transactsub;
	}
	public void setTransactsub(String transactsub) {
		this.transactsub = transactsub;
	}
	public String getTransact() {
		return transact;
	}
	public void setTransact(String transact) {
		this.transact = transact;
	}
	public String getOperid() {
		return operid;
	}
	public void setOperid(String operid) {
		this.operid = operid;
	}
	public String getOper() {
		return oper;
	}
	public void setOper(String oper) {
		this.oper = oper;
	}
	public Long getSifpactid() {
		return sifpactid;
	}
	public void setSifpactid(Long sifpactid) {
		this.sifpactid = sifpactid;
	}
	public String getSifpact() {
		return sifpact;
	}
	public void setSifpact(String sifpact) {
		this.sifpact = sifpact;
	}
	public String getSpactoperid() {
		return spactoperid;
	}
	public void setSpactoperid(String spactoperid) {
		this.spactoperid = spactoperid;
	}
	public String getSpactoper() {
		return spactoper;
	}
	public void setSpactoper(String spactoper) {
		this.spactoper = spactoper;
	}
	public Long getSisnew() {
		return sisnew;
	}
	public void setSisnew(Long sisnew) {
		this.sisnew = sisnew;
	}
	public String getShoppercallingid() {
		return shoppercallingid;
	}
	public void setShoppercallingid(String shoppercallingid) {
		this.shoppercallingid = shoppercallingid;
	}
	public String getShoppercalling() {
		return shoppercalling;
	}
	public void setShoppercalling(String shoppercalling) {
		this.shoppercalling = shoppercalling;
	}
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	public Long getShopperid() {
		return shopperid;
	}
	public void setShopperid(Long shopperid) {
		this.shopperid = shopperid;
	}
	public Long getSagentid() {
		return sagentid;
	}
	public void setSagentid(Long sagentid) {
		this.sagentid = sagentid;
	}
	public Long getBattalion() {
		return battalion;
	}
	public void setBattalion(Long battalion) {
		this.battalion = battalion;
	}
	public Long getPersentid() {
		return persentid;
	}
	public void setPersentid(Long persentid) {
		this.persentid = persentid;
	}
	public Short getIfattend() {
		return ifattend;
	}
	public void setIfattend(Short ifattend) {
		this.ifattend = ifattend;
	}
	public Long getIfagent() {
		return ifagent;
	}
	public void setIfagent(Long ifagent) {
		this.ifagent = ifagent;
	}
	public Short getShoppertypeid() {
		return shoppertypeid;
	}
	public void setShoppertypeid(Short shoppertypeid) {
		this.shoppertypeid = shoppertypeid;
	}
	public String getSrelationcredno() {
		return srelationcredno;
	}
	public void setSrelationcredno(String srelationcredno) {
		this.srelationcredno = srelationcredno;
	}
	public String getLegalentity() {
		return legalentity;
	}
	public void setLegalentity(String legalentity) {
		this.legalentity = legalentity;
	}
	public String getSrelationcrededate() {
		return srelationcrededate;
	}
	public void setSrelationcrededate(String srelationcrededate) {
		this.srelationcrededate = srelationcrededate;
	}
	public String getLegalecredno() {
		return legalecredno;
	}
	public void setLegalecredno(String legalecredno) {
		this.legalecredno = legalecredno;
	}
	public String getLegalecrededate() {
		return legalecrededate;
	}
	public void setLegalecrededate(String legalecrededate) {
		this.legalecrededate = legalecrededate;
	}
	public String getSynumedate() {
		return synumedate;
	}
	public void setSynumedate(String synumedate) {
		this.synumedate = synumedate;
	}
	public String getLicenseno() {
		return licenseno;
	}
	public void setLicenseno(String licenseno) {
		this.licenseno = licenseno;
	}
	public String getTaxregisterno() {
		return taxregisterno;
	}
	public void setTaxregisterno(String taxregisterno) {
		this.taxregisterno = taxregisterno;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getUpoperid() {
		return upoperid;
	}
	public void setUpoperid(String upoperid) {
		this.upoperid = upoperid;
	}
	public String getUpoper() {
		return upoper;
	}
	public void setUpoper(String upoper) {
		this.upoper = upoper;
	}
	public Date getUpdated() {
		return updated;
	}
	public void setUpdated(Date updated) {
		this.updated = updated;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public Long getShopperidP() {
		return shopperidP;
	}
	public void setShopperidP(Long shopperidP) {
		this.shopperidP = shopperidP;
	}
	public String getShortname() {
		return shortname;
	}
	public void setShortname(String shortname) {
		this.shortname = shortname;
	}
	public String getLevels() {
		return levels;
	}
	public void setLevels(String levels) {
		this.levels = levels;
	}
	public Short getIfvalid() {
		return ifvalid;
	}
	public void setIfvalid(Short ifvalid) {
		this.ifvalid = ifvalid;
	}
	public String getAccountbankdictval() {
		return accountbankdictval;
	}
	public void setAccountbankdictval(String accountbankdictval) {
		this.accountbankdictval = accountbankdictval;
	}
	public String getAccountbankname() {
		return accountbankname;
	}
	public void setAccountbankname(String accountbankname) {
		this.accountbankname = accountbankname;
	}
	public String getAccountbankclientname() {
		return accountbankclientname;
	}
	public void setAccountbankclientname(String accountbankclientname) {
		this.accountbankclientname = accountbankclientname;
	}
	public String getAccountbankno() {
		return accountbankno;
	}
	public void setAccountbankno(String accountbankno) {
		this.accountbankno = accountbankno;
	}
	public String getAccountbankprov() {
		return accountbankprov;
	}
	public void setAccountbankprov(String accountbankprov) {
		this.accountbankprov = accountbankprov;
	}
	public String getAccountbankother() {
		return accountbankother;
	}
	public void setAccountbankother(String accountbankother) {
		this.accountbankother = accountbankother;
	}
	public String getIstopmerchant() {
		return istopmerchant;
	}
	public void setIstopmerchant(String istopmerchant) {
		this.istopmerchant = istopmerchant;
	}
	public Double getTopfee() {
		return topfee;
	}
	public void setTopfee(Double topfee) {
		this.topfee = topfee;
	}
	public Double getMinsettlemoney() {
		return minsettlemoney;
	}
	public void setMinsettlemoney(Double minsettlemoney) {
		this.minsettlemoney = minsettlemoney;
	}
	public String getSettlefrequency() {
		return settlefrequency;
	}
	public void setSettlefrequency(String settlefrequency) {
		this.settlefrequency = settlefrequency;
	}
	public Short getOpencheckstatus() {
		return opencheckstatus;
	}
	public void setOpencheckstatus(Short opencheckstatus) {
		this.opencheckstatus = opencheckstatus;
	}

	public String getTermianlstatus() {
		return termianlstatus;
	}
	public void setTermianlstatus(String termianlstatus) {
		this.termianlstatus = termianlstatus;
	}
	public String getTermialfile() {
		return termialfile;
	}
	public void setTermialfile(String termialfile) {
		this.termialfile = termialfile;
	}
	public String getBankfile() {
		return bankfile;
	}
	public void setBankfile(String bankfile) {
		this.bankfile = bankfile;
	}
	public Date getWorktime() {
		return worktime;
	}
	public void setWorktime(Date worktime) {
		this.worktime = worktime;
	}
	public Short getIsformal() {
		return isformal;
	}
	public void setIsformal(Short isformal) {
		this.isformal = isformal;
	}
	public Short getIsupdateshopper() {
		return isupdateshopper;
	}
	public void setIsupdateshopper(Short isupdateshopper) {
		this.isupdateshopper = isupdateshopper;
	}
	public Short getIsupdatebank() {
		return isupdatebank;
	}
	public void setIsupdatebank(Short isupdatebank) {
		this.isupdatebank = isupdatebank;
	}
	public String getMuserid() {
		return muserid;
	}
	public void setMuserid(String muserid) {
		this.muserid = muserid;
	}
	public String getMpassword() {
		return mpassword;
	}
	public void setMpassword(String mpassword) {
		this.mpassword = mpassword;
	}
	public String getSettlementType() {
		return settlementType;
	}
	public void setSettlementType(String settlementType) {
		this.settlementType = settlementType;
	}
	public String getYsbNo() {
		return ysbNo;
	}
	public void setYsbNo(String ysbNo) {
		this.ysbNo = ysbNo;
	}
	public String getYsbScompany() {
		return ysbScompany;
	}
	public void setYsbScompany(String ysbScompany) {
		this.ysbScompany = ysbScompany;
	}
	public String getRecheckmerchantflag() {
		return recheckmerchantflag;
	}
	public void setRecheckmerchantflag(String recheckmerchantflag) {
		this.recheckmerchantflag = recheckmerchantflag;
	}
	public String getRecheckaccountflag() {
		return recheckaccountflag;
	}
	public void setRecheckaccountflag(String recheckaccountflag) {
		this.recheckaccountflag = recheckaccountflag;
	}
	public String getRecheckterminalflag() {
		return recheckterminalflag;
	}
	public void setRecheckterminalflag(String recheckterminalflag) {
		this.recheckterminalflag = recheckterminalflag;
	}
	public String getRecheckmerchantremark() {
		return recheckmerchantremark;
	}
	public void setRecheckmerchantremark(String recheckmerchantremark) {
		this.recheckmerchantremark = recheckmerchantremark;
	}
	public String getRecheckaccountremark() {
		return recheckaccountremark;
	}
	public void setRecheckaccountremark(String recheckaccountremark) {
		this.recheckaccountremark = recheckaccountremark;
	}
	public String getRecheckterminalremark() {
		return recheckterminalremark;
	}
	public void setRecheckterminalremark(String recheckterminalremark) {
		this.recheckterminalremark = recheckterminalremark;
	}
	
}