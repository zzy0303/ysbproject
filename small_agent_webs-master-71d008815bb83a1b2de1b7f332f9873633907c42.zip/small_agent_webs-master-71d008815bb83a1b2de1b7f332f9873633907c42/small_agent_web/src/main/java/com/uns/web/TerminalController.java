package com.uns.web;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;


import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.model.ActionHistory;
import com.uns.model.Agent;
import com.uns.model.B2cAgentBinder;
import com.uns.model.B2cTermBinder;
import com.uns.model.B2cTerminal;

import com.uns.service.TerminalService;
import com.uns.util.StringUtils;
import com.uns.web.form.TerminalForm;

@Controller("TerminalController")
@RequestMapping("/terminal.htm")
public class TerminalController extends BaseController{
	@Autowired
	private TerminalService terminalService;
	
	/**查询终端列表
	 * @param request
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=toTerminalList")
	@FormToken(save=true)
	public String toTerminalList(HttpServletRequest request,@ModelAttribute("mb") TerminalForm mbForm, ModelMap modelMap) throws BusinessException{
		try{
			request.getParameter("page");
			Agent agent = (Agent)request.getSession().getAttribute("agent");
			String shopperId=agent.getShopperid()==null?"":agent.getShopperid().toString();
			mbForm.setShopperid(shopperId);
	        List<B2cTerminal> list = terminalService.selectTermimalList(mbForm);
		    modelMap.put("termList", list);
		    modelMap.put("mbForm", mbForm);
		}catch(Exception e){
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.查询终端失败);
		}
		return "terminal/terminalList";
	}
	
	/**前往修改终端页面
	 * @param request
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=toUpdateTermAgent")
	@FormToken(save=true)
	public String toUpdateTermAgent(HttpServletRequest request,TerminalForm mbForm, ModelMap modelMap) throws BusinessException{
		String termid = request.getParameter("termid");
		if(termid==null||"".equals(termid)){
			throw new BusinessException(ExceptionDefine.查询终端失败);
		}
		B2cAgentBinder terminal = terminalService.selectAgentBinderByPK(termid);
		if(terminal==null||"".equals(terminal)){
			B2cTerminal term = terminalService.selectAllByPrimaryKey(termid);
			modelMap.put("terminal", term);
			return "terminal/terminalUpdate";
		}
		modelMap.put("terminal", terminal);
		return "terminal/terminalUpdate";
	}
	
	/**显示终端详情
	 * @param request
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=toShowTermDetail")
	@FormToken(save=true)
	public String toShowTermDetail(HttpServletRequest request,@ModelAttribute("mb") TerminalForm mbForm, ModelMap modelMap) throws BusinessException{
		String termid = request.getParameter("termid");
		if(termid==null||"".equals(termid)){
			throw new BusinessException(ExceptionDefine.查询终端失败);
		}
		B2cTerminal terminal = terminalService.selectAllByPrimaryKey(termid);
		mbForm.setChangetype("1");
		mbForm.setTerminalid(terminal.getTerminalid());
		List<ActionHistory> list = terminalService.getLast5ActionHistory(mbForm);
		modelMap.put("ahlist", list);
		modelMap.put("terminal", terminal);
		return "terminal/terminalDetail";
	}
	

	@RequestMapping(params = "method=updateTermAgent")
	@FormToken(save=true)
	public String updateTermAgent(HttpServletRequest request,HttpServletResponse response,@ModelAttribute("mb") TerminalForm mbForm, ModelMap modelMap) throws BusinessException{
		Date date =null;
		try {
			date = StringUtils.getToday1();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		String termid = mbForm.getTerminalid();
		if(termid==null||"".equals(termid)){
			throw new BusinessException(ExceptionDefine.获取商户终端信息失败);
		}
		//获取当前该终端的绑定信息
		
		/*try {
			String fileName = uploadFile(response,request,mbForm);
		} catch (IOException e) {
			e.printStackTrace();
		}*/
		B2cAgentBinder agentBinder = terminalService.selectAgentBinderByPK(termid);
		if(agentBinder!=null&&!"".equals(agentBinder)){
			
		}
		TerminalForm termform = new TerminalForm();
		termform.setTerminalid(termid);
		termform.setCheckstatus("2");
		
		//修改之前先判断是否已经该终端是否已经和商户绑定
		B2cTermBinder termBinder = terminalService.searchTBByprimaryKey(termid);
		if(termBinder!=null){
			String message = "已绑定商户不能变更服务商";
			request.setAttribute("message", message);
			request.setAttribute("url", "terminal.htm?method=toTerminalList");
			return "/returnPage";
		
		}
		//获取上传的文件路径
		String bankPath = null;
		try {
			bankPath = this.uploadFile(response, request, mbForm);
		} catch (IOException e) {
			e.printStackTrace();
		} 
		ActionHistory actionHistory = new ActionHistory();
		//首先尝试查询是否已经被修改而未被审核，如果存在，则在原有的基础上进行修改
		List<ActionHistory> list = terminalService.selectActionHisList(termform);
		if(list.size()!=0&&!"".equals(list)){
			actionHistory = list.get(0);
			if(agentBinder!=null&&!"".equals(agentBinder)){
				actionHistory.setOldVest(agentBinder.getAgentNo());
			}
			actionHistory.setNewVest(terminalService.getAgentByName(mbForm.getAgentscompany()).getShopperid().toString());
			actionHistory.setUpdateDate(date);
			actionHistory.setBankfiles(bankPath);
			terminalService.updateABinderinActionHistory(actionHistory);
			String message="变更成功";
			request.setAttribute("message", message);
			request.setAttribute("url","terminal.htm?method=toTerminalList");
		    return "/returnPage";
		}
		//如果不存在已修改而未审核的变更信息，则直接插入一条变更信息
		actionHistory.setChangeType("1");   //假定1为服务商变更
		actionHistory.setCreateDate(date);
		actionHistory.setUpdateDate(date);
		if(agentBinder!=null&&!"".equals(agentBinder)){
			actionHistory.setOldVest(agentBinder.getAgentNo());
		}
		actionHistory.setNewVest(terminalService.getAgentByName(mbForm.getAgentscompany()).getShopperid().toString());
		actionHistory.setTerminalId(termid);
		actionHistory.setCheckStatus("2");
		actionHistory.setBankfiles(bankPath);
		terminalService.insertABinderinActionhistory(actionHistory);
		String message="变更成功";
		request.setAttribute("message", message);
		request.setAttribute("url","terminal.htm?method=toTerminalList");
	    return "/returnPage";
	}
	

	@RequestMapping(params = "method=updateBatchTermAgent")
	@FormToken(save=true)
	public String updateBatchTermAgent(HttpServletResponse response,HttpServletRequest request,@ModelAttribute("mb") TerminalForm mbForm, ModelMap modelMap) throws BusinessException{
		Date date =null;
		String[] index = request.getParameterValues("index");
		String[] ids = request.getParameterValues("terminalid");
		String bankPath = null;
		try {
			bankPath = this.uploadFile(response, request, mbForm);
		} catch (IOException e) {
			e.printStackTrace();
		} 
		for(int i=0;i<index.length;i++){
			String terminalid = ids[Integer.parseInt(index[i])];
			try {
				date = StringUtils.getToday1();
			} catch (ParseException e) {
				e.printStackTrace();
			}
//			String termid = mbForm.getTerminalid();
			if(terminalid==null||"".equals(terminalid)){
				throw new BusinessException(ExceptionDefine.获取商户终端信息失败);
			}
			TerminalForm termform = new TerminalForm();
			termform.setTerminalid(terminalid);
			termform.setCheckstatus("2");
			ActionHistory actionHistory = new ActionHistory();
			//首先尝试查询是否已经被修改而未被审核，如果存在，则在原有的基础上进行修改
			List<ActionHistory> list = terminalService.selectActionHisList(termform);
			if(list!=null&&list.size()!=0&&!"".equals(list)){
				actionHistory = list.get(0);
				actionHistory.setNewVest(terminalService.getAgentByName(mbForm.getNewscompany()).getShopperid().toString());
				actionHistory.setUpdateDate(date);
				actionHistory.setBankfiles(bankPath);
				terminalService.updateABinderinActionHistory(actionHistory);
				continue;
			}
			
			actionHistory.setChangeType("1");   //假定1为服务商变更
			actionHistory.setCreateDate(date);
			actionHistory.setUpdateDate(date);
			actionHistory.setOldVest(mbForm.getAgentid());
			actionHistory.setNewVest(terminalService.getAgentByName(mbForm.getNewscompany()).getShopperid().toString());
			actionHistory.setTerminalId(terminalid);
			actionHistory.setBankfiles(bankPath);
			actionHistory.setCheckStatus("2");
			terminalService.insertABinderinActionhistory(actionHistory);
		}
		
		String message="变更成功";
		request.setAttribute("message", message);
		request.setAttribute("url","terminal.htm?method=toTerminalList");
	    return "/returnPage";
	}
	
	
	
	@RequestMapping(params = "method=toAgentBinderList")
	@FormToken(save=true)
	public String toAgentBinderList(HttpServletRequest request,@ModelAttribute("mb") TerminalForm mbForm, ModelMap modelMap){
		String agentscompany = mbForm.getAgentscompany();
		if (agentscompany != null && !"".equals(agentscompany)) {
			Agent agent = terminalService.getAgentByName(agentscompany);
			mbForm.setAgentid(agent.getShopperid().toString());
		}
		List list = terminalService.selectActionHisList(mbForm);
		int count = terminalService.agentBinderCount();
		modelMap.put("count", count);
		modelMap.put("binderList",list);
		modelMap.put("mbForm", mbForm);
		return "terminal/termAgentBinderList";
	}
	
	/**
	 * 前往终端服务商归属调整审核页面
	 * @param request
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=toUpdateAgentBinder")
	@FormToken(save=true)
	public String toUpdateAgentBinder(HttpServletRequest request,@ModelAttribute("mb") TerminalForm mbForm, ModelMap modelMap) throws BusinessException{
		String binderid = request.getParameter("id");
		if(binderid==null||"".equals(binderid)){
			throw new BusinessException(ExceptionDefine.空指针异常);
		}
		
		ActionHistory actionhistory = terminalService.selectActionHistoryByPK(Short.parseShort(binderid));
		modelMap.put("binderList",actionhistory);
		return "terminal/agentBinderUpdate";
	}
	
	/**
	 * 变更终端所归属服务商
	 * @param request
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=updateAgentBinder")
	@FormToken(save=true)
	public String updateAgentBinder(HttpServletRequest request,@ModelAttribute("mb") TerminalForm mbForm, ModelMap modelMap) throws BusinessException{
		//1.修改ActionHistory表，审核通过设为0，未通过为1，未审核为2
		//2.若是通过，修改AgentBinder表，将服务商号更改为新的服务商
		String binderid = request.getParameter("id");
		String checkStatus = request.getParameter("checkstatus");
		String comments = request.getParameter("comments");
		ActionHistory actionHistory = terminalService.selectActionHistoryByPK(Short.parseShort(binderid));
		if(actionHistory==null||"".equals(actionHistory)){
			throw new BusinessException(ExceptionDefine.归属变更失败);
		}
		
		// 如果审核状态为0，则对原服务商绑定进行修改
		if (checkStatus.equals("0")) {
			B2cAgentBinder agentbinder = terminalService.selectAgentBinderByPK(actionHistory.getTerminalId());
			// 判断是否是初次修改
			if (agentbinder == null || "".equals(agentbinder)) {
				agentbinder = new B2cAgentBinder();
				agentbinder.setTermNo(actionHistory.getTerminalId());
				agentbinder.setAgentNo(actionHistory.getNewVest());
				try {
					agentbinder.setCreateDate(StringUtils.getToday1());
				} catch (ParseException e) {
					e.printStackTrace();
				}
				agentbinder.setStatus(Constants.term_agent_binder);
				terminalService.insertAgentBinder(agentbinder);

			}else{
			
			// 如果已经存在，则修改
				try {
					mbForm.setCreatedate(StringUtils.getToday1());
				} catch (ParseException e) {
					e.printStackTrace();
				}
			    terminalService.updateAgentBinder(mbForm);
			}
		}

		//修改服务商绑定关系后再修改绑定历史
		actionHistory.setCheckStatus(checkStatus);
		actionHistory.setComments(comments);
		try {
			actionHistory.setUpdateDate(StringUtils.getToday1());
			actionHistory.setCheckDate(StringUtils.getToday1());
		} catch (ParseException e1) {
			e1.printStackTrace();
		}
		terminalService.updateABinderinActionHistory(actionHistory);
		request.setAttribute("message","变更服务商成功");
		request.setAttribute("url","terminal.htm?method=toAgentBinderList");
		return "/returnPage";
	}
	
	@RequestMapping(params = "method=toShowBinderDetail")
	@FormToken(save=true)
	public String toShowBinderDetail(HttpServletRequest request,@ModelAttribute("mb") TerminalForm mbForm, ModelMap modelMap) throws BusinessException{
		String binderid = request.getParameter("id");
		if(binderid==null||"".equals(binderid)){
			throw new BusinessException(ExceptionDefine.查询终端失败);
		}
		ActionHistory actionhistory = terminalService.selectAllBinderByPrimaryKey(Short.parseShort(binderid));
		modelMap.put("binders", actionhistory);
		return "terminal/agentBinderDetail";
	}
	
	/**下载pdf
	 * @param request
	 * @param modelMap
	 * @param mbForm
	 */
	@RequestMapping(params = "method=downBkTemplate")
	@FormToken(save=true)
	public void downBkTemplate(HttpServletRequest request,HttpServletResponse response) {
		String path = request.getContextPath();
		String basePath = request.getScheme() + "://"
				+ request.getServerName() + ":" + request.getServerPort()
				+ path + "/";
		String filePath =request.getSession().getServletContext().getRealPath("/")+
				"upload"+File.separator+"BankFiles"+File.separator+"终端信息变更申请表.doc" ;
    	String fileName = "";
    	//从文件完整路径中提取文件名，并进行编码转换，防止不能正确显示中文名
    	try {
        	if(filePath.lastIndexOf("/") > 0) {
        		fileName = new String(filePath.substring(filePath.lastIndexOf("/")+1, filePath.length()).getBytes("GB2312"), "ISO8859_1");
        	}else if(filePath.lastIndexOf("\\") > 0) {
        		fileName = new String(filePath.substring(filePath.lastIndexOf("\\")+1, filePath.length()).getBytes("GB2312"), "ISO8859_1");
        	}
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    	//打开指定文件的流信息
    	InputStream fs = null;
    	try {
    		fs = new FileInputStream(new File(filePath));
    		
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    	//设置响应头和保存文件名 
    	response.setCharacterEncoding("ISO-8859-1");
    	response.setContentType("APPLICATION/OCTET-STREAM"); 
    	response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
    	//写出流信息
    	int b = 0;
    	try {
        	PrintWriter out = response.getWriter();
        	while((b=fs.read())!=-1) {
        		out.write(b);
        	}
        	out.flush();
        	fs.close();
        	out.close();
        	System.out.println("文件下载完毕.");
    	}catch(Exception e) {
        	e.printStackTrace();
        	System.out.println("下载文件失败!");
    	}
		
	}


	public String uploadFile(HttpServletResponse response,HttpServletRequest request, TerminalForm mbForm) throws IOException {
		String path = "http://" + request.getLocalAddr() + ":"+ request.getLocalPort() + request.getContextPath();

		String paths = request.getSession().getServletContext().getRealPath("\\").replaceAll("\\\\", "/");
		// 上传商户准入合规材料
		String StdFileNamePath = "/upload/BankFiles";
		String pdfName = null;
		MultipartFile file = mbForm.getBankfiles();
		if(file==null||"".equals(file)){
			return null;
		}
		String fileName = file.getOriginalFilename();
		int index = fileName.lastIndexOf("\\");
		String fileFileName = "";
		if (index == -1) {
			fileFileName = fileName;
		} else {
			fileFileName = fileName.substring(index + 1);
		}
		if (!StringUtils.isEmpty(fileFileName)) {
			String dateStr = DateFormatUtils.format(new Date(), "yyMMddHHmmss");
			String merchantRadom = org.apache.commons.lang.RandomStringUtils.randomNumeric(4);
			String namefile = dateStr + merchantRadom;
			String type = fileName.substring(fileName.lastIndexOf(".") + 1);

			if (type.equalsIgnoreCase("doc")) {
				InputStream fileInputStream = file.getInputStream();
				pdfName = namefile + ".doc";
				File uploadFile = new File(paths + StdFileNamePath, pdfName);
				uploadFile.getParentFile().mkdirs();
				// 检查文件是否已经存在
				if (!uploadFile.exists()) {
					// 建立文件
					uploadFile.createNewFile();
				}
				OutputStream out = new FileOutputStream(uploadFile);
				@SuppressWarnings("unused")
				int len = 0;// 每次读取的字节数
				byte[] bytes = new byte[1024];
				while ((len = fileInputStream.read(bytes, 0, bytes.length)) != -1) {
					out.write(bytes);
				}
				fileInputStream.close();
				out.close();
				// b2cShopperbi.setBankfile(path+StdFileNamePath+"/"+pdfName);

			}
		}
		return path + StdFileNamePath + "/" + pdfName;
	}
		
}
