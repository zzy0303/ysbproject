package com.uns.dao;

import org.springframework.stereotype.Repository;

import com.uns.model.RoleMerFunctionMer;
@Repository
public interface RoleMerFunctionMerMapper {

	//插入角色与权限
    int insert(RoleMerFunctionMer record);

  
    int insertSelective(RoleMerFunctionMer record);

    //删除关系表
	void deleteByRoleId(Long id);

    
}