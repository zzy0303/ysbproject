package com.uns.web.servlet;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGImageEncoder;

public class VerifyCodeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public static final String VERIFYCODE = "VerifyCode";
	
	public static boolean validate(HttpSession session, String verifyCode) {
		boolean result = false;
		
		String value = (String)session.getAttribute(VERIFYCODE);
		
		try{
			if(verifyCode.toUpperCase().trim().equals(value))
			{
				result = true; 
			}
		}
		catch(Exception e){}
		
		return result;
	}
	
	private String[] element = new String[]{
		"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"
	};
	
	private Color getRandColor(int m, int n) {
		Random random = new Random();
		
		if(m > 255)
		{
			m = 255;
		}
		
		if(n > 255)
		{
			n = 255;
		}
		
		int r = m + random.nextInt(n - m);
		int g = m + random.nextInt(n - m);
		int b = m + random.nextInt(n - m);
		
		return new Color(r, g, b);
	}
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException,ServletException {
		HttpSession session = request.getSession();
		
        int width = 60;
        int height = 20;
        
        BufferedImage bi = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics g = bi.getGraphics();
        g.setColor(getRandColor(200, 250));
        g.fillRect(0, 0, width, height);
        g.setFont(new Font("Times New Roman", Font.BOLD, 18));
        g.setColor(Color.BLACK);
        g.drawRect(0, 0, width - 1, height - 1);
        
        String verifyCode = "";
        Random random = new Random();
        for(int i = 0; i < 4; i ++)
        {
            String temp = element[random.nextInt(10)];
            verifyCode += temp;
            g.setColor(new Color(20 + random.nextInt(110), 20 + random.nextInt(110), 20 + random.nextInt(110)));
            if(i % 2 == 0)
            {
                g.drawString(temp, 13 * i + 6, 16 + 2);
            }
            else
            {
                g.drawString(temp, 13 * i + 6, 16 - 2);
            }
        }
        session.setAttribute(VERIFYCODE, verifyCode);
        
		response.setContentType("image/gif");
		response.setHeader("pragma","no-cache");
		response.setHeader("cache-control","no-cache");
		response.setHeader("cache-control","no-store");
		response.setDateHeader("expires", 0);
		
		
	    ImageIO.write(bi,  "jpeg" , response.getOutputStream()); 
	    bi.flush();
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException,ServletException {
		doGet(request, response);
	}
}