package com.uns.util;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Random;

import net.sf.json.JSONObject;

import com.uns.common.Constants;

/**
 * 常用的工具类
 *
 */
public class ToolsUtils {
	
	public static String div(double v1, double v2, int scale) {
		 if (scale < 0) {
		 throw new IllegalArgumentException("The scale must be a positive integer or zero");
		 }
		 BigDecimal b1 = new BigDecimal(Double.toString(v1));
		 BigDecimal b2 = new BigDecimal(Double.toString(v2));
		 return b1.divide(b2, scale, BigDecimal.ROUND_HALF_UP).toString();
	}

	/**根据code获取错误码
	 * @param code
	 * @return
	 */
	public static String errorMsg(String code){
		HashMap<String,String> hashMap = new HashMap<String, String>();
		hashMap.put("rspCode", code);
		hashMap.put("rspMsg", Constants.mapReturnMsg.get(code));
		String mac = Md5Encrypt.md5("rspCode=" + code + "&rspMsg=" + Constants.mapReturnMsg.get(code));
	    hashMap.put("mac", mac);
		return JSONObject.fromObject(hashMap).toString();
	}
	
	
	public static String getSubStr(String str){
		String strLength=str.substring(0, 6)+"*****"+str.substring(str.length()-4);
		return strLength;
	}
	
}
