package com.uns.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.web.form.AgentRechargeForm;

@Repository
public interface OrderInfoMapper {
	List<Map<String,String>> selectRechargeList(Map<String, Object> param);
	//刷卡总计
	Map selectRechargeListSum(Map<String, Object> param);
	
	List<Map<String,String>> selectWithdrawList(Map<String, Object> param);
	
	//T0提现总计
   Map selectWithdrawListSum(Map<String, Object> param);
		
	int judgeShopper(Map<String,Object> map);
	
	List<String> selectYsbno(Long shopperidp);
	
	List<String> selectYsbnoByAmount(Map<String, Object> param);
	//充值记录查询下载
	List<Map<String,Object>> findRechargePageList(Map<String, Object> param);
	
	Map findRechargeById(String orderId);
	    
	List<Map<String,String>> selectD0Time();
	/**
	 * D0提现记录
	 * @author yang.liu01
	 * @param param
	 * @return
	 */
	List<Map<String, String>> selectWithdrawD0List(Map<String, Object> param);
	/**
	 * T1提现记录
	 * @author yang.liu01
	 * @param param
	 * @return
	 */
	List<Map<String, String>> selectWithdrawT1List(Map<String, Object> param);
}