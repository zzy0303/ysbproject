package com.uns.model;

import java.util.Date;

public class B2cShopperbargain {

    private Long b2cShopperbargainId;
    private Long operationtypeid;
    private String operationtype;
    private String bargaincode;
    private String industry;
    private String management;
    private Long drawbackflag;
    private String drawbackflagbe;
    private Long footflag;
    private String footflagbe;
    private Long jinpoundage;
    private Long footfreq;
    private String footfreqbe;
    private Long footamount;
    private Long assureamount;
    private Long dredgeamount;
    private Long serviceamount;
    private Long foottransside;
    private String passno3d;
    private String apitype;
    private Date writebargain;
    private String writeoperid;
    private String writeoper;
    private Long bargainability;
    private Date bargainbdate;
    private Date bargainedate;
    private Date bargainrdate;
    private String shopperid;
    private Date created;
    private String foottranssidesu;
    private String bargain;
    private Double poundage;
    private Long returnflag;
    private Long returnpound;
    private String returnflagsu;
    private String autorcvurl;
    private Long apitypeid;
    private String sverify;
    private String operuserid;
    private String operusername;
    private Long subsidiarid;
    private Long bargainid;
    private Long poundtype;
    private Long indepbankshopid;
    private String returnurl;
    private Short inheritedflag;
    private String inherbargainid;
    private Date invalidate;
    private String manage;
    private String manager;
    private String notes;
    private Date crededate;
    private Long basecost;
	private String stdfilename;
    private String addfilename;
    
    
    public String getStdfilename() {
  		return stdfilename;
  	}
  	public void setStdfilename(String stdfilename) {
  		this.stdfilename = stdfilename;
  	}
  	public String getAddfilename() {
  		return addfilename;
  	}
  	public void setAddfilename(String addfilename) {
  		this.addfilename = addfilename;
  	}
	public Long getB2cShopperbargainId() {
		return b2cShopperbargainId;
	}
	public void setB2cShopperbargainId(Long b2cShopperbargainId) {
		this.b2cShopperbargainId = b2cShopperbargainId;
	}
	public Long getOperationtypeid() {
		return operationtypeid;
	}
	public void setOperationtypeid(Long operationtypeid) {
		this.operationtypeid = operationtypeid;
	}
	public String getOperationtype() {
		return operationtype;
	}
	public void setOperationtype(String operationtype) {
		this.operationtype = operationtype;
	}
	public String getBargaincode() {
		return bargaincode;
	}
	public void setBargaincode(String bargaincode) {
		this.bargaincode = bargaincode;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getManagement() {
		return management;
	}
	public void setManagement(String management) {
		this.management = management;
	}
	public Long getDrawbackflag() {
		return drawbackflag;
	}
	public void setDrawbackflag(Long drawbackflag) {
		this.drawbackflag = drawbackflag;
	}
	public String getDrawbackflagbe() {
		return drawbackflagbe;
	}
	public void setDrawbackflagbe(String drawbackflagbe) {
		this.drawbackflagbe = drawbackflagbe;
	}
	public Long getFootflag() {
		return footflag;
	}
	public void setFootflag(Long footflag) {
		this.footflag = footflag;
	}
	public String getFootflagbe() {
		return footflagbe;
	}
	public void setFootflagbe(String footflagbe) {
		this.footflagbe = footflagbe;
	}
	public Long getJinpoundage() {
		return jinpoundage;
	}
	public void setJinpoundage(Long jinpoundage) {
		this.jinpoundage = jinpoundage;
	}
	public Long getFootfreq() {
		return footfreq;
	}
	public void setFootfreq(Long footfreq) {
		this.footfreq = footfreq;
	}
	public String getFootfreqbe() {
		return footfreqbe;
	}
	public void setFootfreqbe(String footfreqbe) {
		this.footfreqbe = footfreqbe;
	}
	public Long getFootamount() {
		return footamount;
	}
	public void setFootamount(Long footamount) {
		this.footamount = footamount;
	}
	public Long getAssureamount() {
		return assureamount;
	}
	public void setAssureamount(Long assureamount) {
		this.assureamount = assureamount;
	}
	public Long getDredgeamount() {
		return dredgeamount;
	}
	public void setDredgeamount(Long dredgeamount) {
		this.dredgeamount = dredgeamount;
	}
	public Long getServiceamount() {
		return serviceamount;
	}
	public void setServiceamount(Long serviceamount) {
		this.serviceamount = serviceamount;
	}
	public Long getFoottransside() {
		return foottransside;
	}
	public void setFoottransside(Long foottransside) {
		this.foottransside = foottransside;
	}
	public String getPassno3d() {
		return passno3d;
	}
	public void setPassno3d(String passno3d) {
		this.passno3d = passno3d;
	}
	public String getApitype() {
		return apitype;
	}
	public void setApitype(String apitype) {
		this.apitype = apitype;
	}
	public Date getWritebargain() {
		return writebargain;
	}
	public void setWritebargain(Date writebargain) {
		this.writebargain = writebargain;
	}
	public String getWriteoperid() {
		return writeoperid;
	}
	public void setWriteoperid(String writeoperid) {
		this.writeoperid = writeoperid;
	}
	public String getWriteoper() {
		return writeoper;
	}
	public void setWriteoper(String writeoper) {
		this.writeoper = writeoper;
	}
	public Long getBargainability() {
		return bargainability;
	}
	public void setBargainability(Long bargainability) {
		this.bargainability = bargainability;
	}
	public Date getBargainbdate() {
		return bargainbdate;
	}
	public void setBargainbdate(Date bargainbdate) {
		this.bargainbdate = bargainbdate;
	}
	public Date getBargainedate() {
		return bargainedate;
	}
	public void setBargainedate(Date bargainedate) {
		this.bargainedate = bargainedate;
	}
	public Date getBargainrdate() {
		return bargainrdate;
	}
	public void setBargainrdate(Date bargainrdate) {
		this.bargainrdate = bargainrdate;
	}
	public String getShopperid() {
		return shopperid;
	}
	public void setShopperid(String shopperid) {
		this.shopperid = shopperid;
	}
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	public String getFoottranssidesu() {
		return foottranssidesu;
	}
	public void setFoottranssidesu(String foottranssidesu) {
		this.foottranssidesu = foottranssidesu;
	}
	public String getBargain() {
		return bargain;
	}
	public void setBargain(String bargain) {
		this.bargain = bargain;
	}
	
	public Double getPoundage() {
		return poundage;
	}
	public void setPoundage(Double poundage) {
		this.poundage = poundage;
	}
	public Long getReturnflag() {
		return returnflag;
	}
	public void setReturnflag(Long returnflag) {
		this.returnflag = returnflag;
	}
	public Long getReturnpound() {
		return returnpound;
	}
	public void setReturnpound(Long returnpound) {
		this.returnpound = returnpound;
	}
	public String getReturnflagsu() {
		return returnflagsu;
	}
	public void setReturnflagsu(String returnflagsu) {
		this.returnflagsu = returnflagsu;
	}
	public String getAutorcvurl() {
		return autorcvurl;
	}
	public void setAutorcvurl(String autorcvurl) {
		this.autorcvurl = autorcvurl;
	}
	public Long getApitypeid() {
		return apitypeid;
	}
	public void setApitypeid(Long apitypeid) {
		this.apitypeid = apitypeid;
	}
	public String getSverify() {
		return sverify;
	}
	public void setSverify(String sverify) {
		this.sverify = sverify;
	}
	public String getOperuserid() {
		return operuserid;
	}
	public void setOperuserid(String operuserid) {
		this.operuserid = operuserid;
	}
	public String getOperusername() {
		return operusername;
	}
	public void setOperusername(String operusername) {
		this.operusername = operusername;
	}
	public Long getSubsidiarid() {
		return subsidiarid;
	}
	public void setSubsidiarid(Long subsidiarid) {
		this.subsidiarid = subsidiarid;
	}
	public Long getBargainid() {
		return bargainid;
	}
	public void setBargainid(Long bargainid) {
		this.bargainid = bargainid;
	}
	public Long getPoundtype() {
		return poundtype;
	}
	public void setPoundtype(Long poundtype) {
		this.poundtype = poundtype;
	}
	public Long getIndepbankshopid() {
		return indepbankshopid;
	}
	public void setIndepbankshopid(Long indepbankshopid) {
		this.indepbankshopid = indepbankshopid;
	}
	public String getReturnurl() {
		return returnurl;
	}
	public void setReturnurl(String returnurl) {
		this.returnurl = returnurl;
	}
	public Short getInheritedflag() {
		return inheritedflag;
	}
	public void setInheritedflag(Short inheritedflag) {
		this.inheritedflag = inheritedflag;
	}
	public String getInherbargainid() {
		return inherbargainid;
	}
	public void setInherbargainid(String inherbargainid) {
		this.inherbargainid = inherbargainid;
	}
	public Date getInvalidate() {
		return invalidate;
	}
	public void setInvalidate(Date invalidate) {
		this.invalidate = invalidate;
	}
	public String getManage() {
		return manage;
	}
	public void setManage(String manage) {
		this.manage = manage;
	}
	public String getManager() {
		return manager;
	}
	public void setManager(String manager) {
		this.manager = manager;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public Date getCrededate() {
		return crededate;
	}
	public void setCrededate(Date crededate) {
		this.crededate = crededate;
	}
	public Long getBasecost() {
		return basecost;
	}
	public void setBasecost(Long basecost) {
		this.basecost = basecost;
	}
}