package com.uns.dao;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.B2cAgentSplitFees;
import com.uns.model.B2cTranhis;
import com.uns.web.form.AgentSplitFeeForm;
@Repository
public interface B2cAgentSplitFeesMapper {


    B2cAgentSplitFees selectByPrimaryKey(BigDecimal splitfeesid);
    //分润历史统计信息汇总
	List getSplitFeesList(AgentSplitFeeForm form);
	
	//分润历史统计信息列表
	List getAgentSplitFeeList(AgentSplitFeeForm form);
	//下载分润信息
	List getExcelAgentSplitFeeList(AgentSplitFeeForm form);

   
} 