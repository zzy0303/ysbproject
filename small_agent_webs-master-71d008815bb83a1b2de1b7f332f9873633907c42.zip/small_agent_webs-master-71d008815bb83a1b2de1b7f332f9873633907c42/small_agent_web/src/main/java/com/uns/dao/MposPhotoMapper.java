package com.uns.dao;

import java.math.BigDecimal;

import com.uns.model.MposPhoto;

public interface MposPhotoMapper {


    int deleteByPrimaryKey(BigDecimal photoId);

    int insert(MposPhoto record);

    int insertSelective(MposPhoto record);

    MposPhoto selectByPrimaryKey(BigDecimal photoId);

    int updateByPrimaryKeySelective(MposPhoto record);

    int updateByPrimaryKey(MposPhoto record);
}