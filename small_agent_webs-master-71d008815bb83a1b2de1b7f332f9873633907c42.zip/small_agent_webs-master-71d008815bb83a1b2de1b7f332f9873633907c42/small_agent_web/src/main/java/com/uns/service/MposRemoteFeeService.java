package com.uns.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.dao.MposRemoteFeeMapper;
import com.uns.model.B2cDict;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.MposMerchantFee;
import com.uns.model.MposRemoteFee;
import com.uns.util.ToolsUtils;

@Service
public class MposRemoteFeeService {
	@Autowired
	private MposRemoteFeeMapper remotefeemapper;

	public void insertfee(MposRemoteFee remotefee) {
		remotefeemapper.insertSelective(remotefee);
	}
	public void delfee(String tel){
		remotefeemapper.delfee(tel);
	}
	public MposRemoteFee findbytel(String tel){
		List list= remotefeemapper.findbytel(tel);
		MposRemoteFee fee=null;
		if(list!=null&&list.size()>0){
			fee=(MposRemoteFee)list.get(0);
		}
		return fee;
	}
	
	
    
	public List queryfee(String tel){
	 List<MposRemoteFee> list =remotefeemapper.queryfee(tel);
		return list;
		
	}
	public List remotefeeList(String stel) {
		return remotefeemapper.remotefeeList(stel);
	}
	public void insert4RemoteFee(String tel) {
		remotefeemapper.delfee(tel);
		
		MposRemoteFee mposDebitfee=new MposRemoteFee();
		mposDebitfee.setTel(tel);
		mposDebitfee.setFeetype(Constants.CON_NO);//借记卡
		mposDebitfee.setFee(ToolsUtils.div(Double.parseDouble("0.0065"), 1, 4)+"");
		mposDebitfee.setCreateDate(new Date());
		mposDebitfee.setStatus(Constants.CON_YES);
		mposDebitfee.setD0fee(ToolsUtils.div(Double.parseDouble("0.0007"), 1, 4)+"");
		

		
		MposRemoteFee mposCreditFee=new MposRemoteFee();
		mposCreditFee.setTel(tel);
		mposCreditFee.setFeetype(Constants.CON_YES);//借记卡
		mposCreditFee.setFee(ToolsUtils.div(Double.parseDouble("0.0065"), 1, 4)+"");
		mposCreditFee.setCreateDate(new Date());
		mposCreditFee.setStatus(Constants.CON_YES);
		mposCreditFee.setD0fee(ToolsUtils.div(Double.parseDouble("0.0007"), 1, 4)+"");
		
		
	
		
		MposRemoteFee mweChatfee=new MposRemoteFee();
		mweChatfee.setTel(tel);
		mweChatfee.setFeetype(Constants.STATUS2);//
		mweChatfee.setFee(ToolsUtils.div(Double.parseDouble("0.0047"), 1, 4)+"");
		mweChatfee.setCreateDate(new Date());
		mweChatfee.setStatus(Constants.CON_YES);
		mweChatfee.setD0fee(ToolsUtils.div(Double.parseDouble("0.0049"), 1, 4)+"");
		
	
		
		MposRemoteFee mposAliPayFee=new MposRemoteFee();
		mposAliPayFee.setTel(tel);
		mposAliPayFee.setFeetype(Constants.STATUS3);//借记卡
		mposAliPayFee.setFee(ToolsUtils.div(Double.parseDouble("0.0047"), 1, 4)+"");
		mposAliPayFee.setCreateDate(new Date());
		mposAliPayFee.setStatus(Constants.CON_YES);
		mposAliPayFee.setD0fee(ToolsUtils.div(Double.parseDouble("0.0049"), 1, 4)+"");
		
		remotefeemapper.insertSelective(mposDebitfee);
		
		mposCreditFee.setId(mposDebitfee.getId());
		remotefeemapper.insert(mposCreditFee);
		
		mweChatfee.setId(mposDebitfee.getId());
		remotefeemapper.insert(mweChatfee);
		
		mposAliPayFee.setId(mposDebitfee.getId());
		remotefeemapper.insert(mposAliPayFee);
		
		
	}
	public List findbytel1(String tel) {
		List list= remotefeemapper.findbytel1(tel);
		return list;
	}
	
}
