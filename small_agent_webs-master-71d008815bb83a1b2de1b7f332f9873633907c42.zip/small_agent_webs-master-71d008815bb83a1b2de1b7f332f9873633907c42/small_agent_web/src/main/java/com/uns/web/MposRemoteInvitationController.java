package com.uns.web;

import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.MposRemoteInvitation;
import com.uns.model.Users;
import com.uns.service.AgentService;
import com.uns.service.MposRemoteInvitationService;
import com.uns.service.ShopPerbiService;
import com.uns.web.form.MposRemoteInvitationForm;


@Controller("MposRemoteInvitationController")
@RequestMapping("/mposRemoteInvitation.htm")
public class MposRemoteInvitationController {

	
	@Autowired
	private  MposRemoteInvitationService mposRemoteInvitationService;
	
	@Autowired
	private ShopPerbiService shopPerbiService;
	
	@Autowired
	private AgentService agentService;
	
	/**远程邀请查询列表
	 * @param request
	 * @param modelMap
	 * @param mbform
	 * @return
	 */
	@RequestMapping(params = "method=findMposRemoteInvitationList")
	public String findMposRemoteInvitationList(HttpServletRequest request,ModelMap modelMap,MposRemoteInvitationForm mbform){
		Users agent=(Users)request.getSession().getAttribute(Constants.SESSION_KEY_USER);
		mbform.setSalesmans(agent.getId().toString());
		List mposRemoteInvitationList=mposRemoteInvitationService.findMposRemoteInvitationList(mbform);
		request.setAttribute("mposRemoteInvitationList", mposRemoteInvitationList);
		if(agent!=null){
			List mposAgentList=mposRemoteInvitationService.findmposAgent(agent.getMerchantid());
			request.setAttribute("mposAgentList", mposAgentList);
		}
		
		return "mposRemoteInvitation/mposRemoteInvitationList";
	}
	
	/**远程邀请页面
	 * @param request
	 * @param modelMap
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=Initiateinvitation")
	@FormToken(save=true)
	public String Initiateinvitation(HttpServletRequest request, ModelMap modelMap) throws BusinessException {
		try {
			Users agent=(Users)request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			if(agent!=null){
				List mposAgentList=mposRemoteInvitationService.findmposAgent(agent.getMerchantid());
				request.setAttribute("mposAgentList", mposAgentList);
				//借记卡 费率
				List debitfeeList=agentService.findAgentTopFeeByType(Constants.CON_NO);
				//贷记卡费率
				List creditfeeList=agentService.findAgentTopFeeByType(Constants.CON_YES);
				//微信 费率
				List weChatfeeList=agentService.findAgentTopFeeByType(Constants.STATUS2);
				//支付宝费率
				List aliPayfeeList=agentService.findAgentTopFeeByType(Constants.STATUS3);
				
				request.setAttribute("debitfeeList", debitfeeList);
				request.setAttribute("creditfeeList", creditfeeList);
				request.setAttribute("weChatfeeList", weChatfeeList);
				request.setAttribute("aliPayfeeList", aliPayfeeList);
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.发起邀请);
		} 
		return "mposRemoteInvitation/initiateinvitation";
	}
	
	
	
	
	
	
	/**ajax验证是否有状态是否为3 或4
     * @param request
     * @param response
     * @return
     * @throws BusinessException
     */
    @RequestMapping(params = "method=ajaxStatus")
    public String ajaxStatus(HttpServletRequest request,HttpServletResponse response) throws BusinessException{
        try {
        String tel=request.getParameter("tel");
        MposRemoteInvitation  remote=mposRemoteInvitationService.findbytel(tel);
        PrintWriter out=response.getWriter();
        try {
        	if(remote==null){
        		//查询注册
        		B2cShopperbiTemp bs=shopPerbiService.findbytel(tel);
	        		if(bs!=null){
	        			out.write("{\"x\":\"0\"}");
	        		}else{
	        			out.write("{\"x\":\"5\"}");
	        		}
        		}else{
	        		if(remote.getStatus().equals("1")){
	        			out.write("{\"x\":\"1\"}");
	                }else if(remote.getStatus().equals("2")){
	                    out.write("{\"x\":\"2\"}");
	                }else if(remote.getStatus().equals("3")){
	                    out.write("{\"x\":\"3\"}");
	                }else{
	                	out.write("{\"x\":\"4\"}");
	                }
        	}
            } catch (Exception e) {
                e.printStackTrace();
            }finally{
                if(out !=null){
                    out.flush();
                    out.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
	
	
	
	

	
	/**撤回
	 * @param request
	 * @param modelMap
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=recall")
	public String recall(HttpServletRequest request, 
			ModelMap modelMap) throws BusinessException {
	    try {
	    	String remoteInvitationId=request.getParameter("remoteInvitationId");
    		if(StringUtils.isNotEmpty(remoteInvitationId)){
    			MposRemoteInvitation mposRemoteInvitation=mposRemoteInvitationService.findMposRemoteInvitationById(Long.valueOf(remoteInvitationId));
    			if(mposRemoteInvitation!=null){
    				mposRemoteInvitationService.recall(mposRemoteInvitation);
    				request.setAttribute(Constants.MESSAGE_KEY, "撤回成功!");
        			request.setAttribute("url", "mposRemoteInvitation.htm?method=findMposRemoteInvitationList");
    			}else{
    				request.setAttribute(Constants.MESSAGE_KEY, "该记录查询不到，请查证!");
        			request.setAttribute("url", "mposRemoteInvitation.htm?method=findMposRemoteInvitationList");
    			}
    		}else{
				request.setAttribute(Constants.MESSAGE_KEY, "该记录查询不到，请查证!!");
    			request.setAttribute("url", "mposRemoteInvitation.htm?method=findMposRemoteInvitationList");
			}
	    } catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.保存发送邀请失败);
		}
	    return "/returnPage";
	}
}
