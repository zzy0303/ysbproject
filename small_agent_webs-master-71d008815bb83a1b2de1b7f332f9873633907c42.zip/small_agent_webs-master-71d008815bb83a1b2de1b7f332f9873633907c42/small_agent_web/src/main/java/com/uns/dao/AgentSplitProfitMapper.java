package com.uns.dao;

import com.uns.model.AgentSplitProfit;
import com.uns.web.form.SplitForm;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;
@Repository
public interface AgentSplitProfitMapper {
    int deleteByPrimaryKey(BigDecimal id);

    AgentSplitProfit selectByPrimaryKey(BigDecimal id); 

    List<Map<String,Object>> selectSplitList(SplitForm param);

	List<Map<String, Object>> selectSmSplitList(SplitForm sform);

	List<Map<String, Object>> findsplitProfitByBatch(String batchNo); 
}