package com.uns.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.page.PageContext;
import com.uns.dao.ActionHistoryMapper;
import com.uns.dao.AgentMapper;
import com.uns.dao.B2cAgentBinderMapper;
import com.uns.dao.B2cTermBinderMapper;
import com.uns.dao.B2cTerminalMapper;
import com.uns.model.ActionHistory;
import com.uns.model.Agent;
import com.uns.model.B2cAgentBinder;
import com.uns.model.B2cTermBinder;
import com.uns.model.B2cTerminal;
import com.uns.web.form.AgentForm;
import com.uns.web.form.TerminalForm;

@Service
public class TerminalService {
	@Autowired
	private B2cTerminalMapper b2cTerminalMapper;
	
	@Autowired
	private B2cTermBinderMapper b2cTermBinderMapper;
	
	@Autowired
	private AgentMapper agentMapper;
	
	@Autowired
	private B2cAgentBinderMapper b2cAgentBinderMapper;
	
	@Autowired
	private ActionHistoryMapper actionHistoryMapper;
	/**
	 * 查询终端列表
	 * @param form
	 * @return
	 * @throws Exception
	 */
	public List selectTermimalList(TerminalForm form) throws Exception{
		PageContext.initPageSize(10);
		return b2cTerminalMapper.selectTerminalList(form);
	}
	
	/**
	 * 修改终端信息
	 * @param term
	 */
	public void updateTermByPrimarykey(B2cTerminal term){
		b2cTerminalMapper.updateByPrimaryKeySelective(term);
	}
	
	/**
	 * 通过Id查询终端信息
	 * @param termid
	 * @return
	 */
	public B2cTerminal selectTermByPrimarykey(String termid){
		return b2cTerminalMapper.selectByPrimaryKey(termid);
	}
	/**
	 * 查询服务商树
	 * @return
	 */
	public List getAgentTreeList(AgentForm agentForm){
		return agentMapper.searchAgentTree(agentForm);
	}
	
	public B2cTerminal selectAllByPrimaryKey(String termid){
		return b2cTerminalMapper.selectAllByPrimaryKey(termid);
	}
	public Agent getAgentByName(String scompany){
		return agentMapper.searchAgentByName(scompany);
	}
	

	/**
	 * 通过终端号查询与服务商之间的绑定关系
	 * @param terminalid
	 * @return
	 */
	public B2cAgentBinder selectAgentBinderByPK(String terminalid){
		return b2cAgentBinderMapper.selectAgentBinderByid(terminalid);
	}
	
	public int updateAgentBinder(TerminalForm form){
		return b2cAgentBinderMapper.updateAgentBinder(form);
	}
	
	public int deleteAgentBinderBytermId(String terminalid){
		return b2cAgentBinderMapper.delectAgentBinderBytermId(terminalid);
	}
	public int insertAgentBinder(B2cAgentBinder binder){
		return b2cAgentBinderMapper.insert(binder);
	}
	
	//操作ActionHistory
	
	/**
	 * 获取服务商变更列表
	 * 一定要传变更类型
	 * @param form
	 * @return
	 */
	public List selectActionHisList(TerminalForm form){
		PageContext.initPageSize(10);
		return actionHistoryMapper.selectAgentBinderList(form);
	}
	public ActionHistory selectActionHistoryByPK(short id){
		return actionHistoryMapper.selectByPrimaryKey(id);
	}
	public int insertABinderinActionhistory(ActionHistory actionHistory){
		return actionHistoryMapper.insert(actionHistory);
	}
	
	public int updateABinderinActionHistory(ActionHistory actionHistory){
		return actionHistoryMapper.updateByPrimaryKey(actionHistory);
	}
	public int delABinderinActionHistory(short id){
		return actionHistoryMapper.deleteByPrimaryKey(id);
	}
	public ActionHistory selectAllBinderByPrimaryKey(short id){
		return actionHistoryMapper.selectAllByPrimaryKey(id);
	}
	/**
	 * 获取待审核服务商变更数量
	 */
	public int agentBinderCount(){
		return actionHistoryMapper.selectAgentBinderCount();
	}
	
	//获取商户终端绑定信息
	public B2cTermBinder searchTBByprimaryKey(String terminalid){
		return b2cTermBinderMapper.selectOneBinder(terminalid);
	}
	public List getLast5ActionHistory(TerminalForm form){
		PageContext.initPageSize(5);
		return actionHistoryMapper.selectAgentBinderList(form);
	}

	/**根据终端号得到终端id
	 * @param terNo
	 * @return
	 */
	public String getTerminByTerNo(String terNo) {
		return b2cTerminalMapper.getTerminByTerNo(terNo);
	}
}
