package com.uns.model;

import java.util.ArrayList;
import java.util.List;



public class AgentMcc{
	 
	private Long amid;
	private Mcc mcc; // MCC规则
	private AgentSplit agentSplit; // 分润规则
	
	private List<AgentRatio> ratios = new ArrayList<AgentRatio>(); // 分润
	private Double baseCost; // 通道底价
	
	private Long mccidc;
	
	public Long getMccidc() {
		return mccidc;
	}
	public void setMccidc(Long mccidc) {
		this.mccidc = mccidc;
	}
	public List<AgentRatio> getRatios() {
		return ratios;
	}
	public void setRatios(List<AgentRatio> ratios) {
		this.ratios = ratios;
	}

	public Long getAmid() {
		return amid;
	}
	public void setAmid(Long amid) {
		this.amid = amid;
	}
	public AgentSplit getAgentSplit() {
		return agentSplit;
	}
	public void setAgentSplit(AgentSplit agentSplit) {
		this.agentSplit = agentSplit;
	}
	public Mcc getMcc() {
		return mcc;
	}
	public void setMcc(Mcc mcc) {
		this.mcc = mcc;
	}
	public Double getBaseCost() {
		return baseCost;
	}
	public void setBaseCost(Double baseCost) {
		this.baseCost = baseCost;
	}
	
}