package com.uns.web.form;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.uns.common.Constants;

public class SplitForm {
	private BigDecimal id;
	private String ids;
	private String shopperidp;
	private String scompany;
	private Date startDate;
	private Date endDate;
	private String status;
	private String batchNo;
	private String transType;
	private String replyHis;
	private String reply;
	private String doubt;
	private String doubtHis;
	private String doubtId;
	private String type;
	private String ifDownload;
	private String sessionUserNo;
	private String contact;
	private Date createDate;
	
	
	//新加入的参数
	private String confirmStartDate;//确认开始时间
	private String confirmEndDate;//确认结束时间
	private String settleStartDate;//结算开始时间
	private String settleEndDate;//结算结束时间
	private String batchStartDate;//批次生成开始时间
	private String batchEndDate;//批次生成结束时间
	private String s0BatchNo;//秒到批次号
	private String d0BatchNo;//即时批次号
	private String t1BatchNo;//T1批次号
	private List<String> s0List = new  ArrayList<String>();
	private List<String> d0List = new  ArrayList<String>();
	private List<String> t1List = new ArrayList<String>();
	private String status_s0;//秒到状态
	private String status_d0;//即时状态
	private String status_t1;//t1状态
	private String ratio;
	
	
	
	
	public String getSettleStartDate() {
		return settleStartDate;
	}
	public void setSettleStartDate(String settleStartDate) {
		this.settleStartDate = settleStartDate;
	}
	public String getSettleEndDate() {
		return settleEndDate;
	}
	public void setSettleEndDate(String settleEndDate) {
		this.settleEndDate = settleEndDate;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public String getDoubt() {
		return doubt;
	}
	public void setDoubt(String doubt) {
		this.doubt = doubt;
	}
	public String getSessionUserNo() {
		return sessionUserNo;
	}
	public void setSessionUserNo(String sessionUserNo) {
		this.sessionUserNo = sessionUserNo;
	}
	public String getIfDownload() {
		return ifDownload;
	}
	public void setIfDownload(String ifDownload) {
		this.ifDownload = ifDownload;
	}
	public String getReplyHis() {
		return replyHis;
	}
	public void setReplyHis(String replyHis) {
		this.replyHis = replyHis;
	}
	public String getDoubtHis() {
		return doubtHis;
	}
	public void setDoubtHis(String doubtHis) {
		this.doubtHis = doubtHis;
	}
	public String getIds() {
		return ids;
	}
	public void setIds(String ids) {
		this.ids = ids;
	}
	public BigDecimal getId() {
		return id;
	}
	public void setId(BigDecimal id) {
		this.id = id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDoubtId() {
		return doubtId;
	}
	public void setDoubtId(String doubtId) {
		this.doubtId = doubtId;
	}
	public String getTransType() {
		return transType;
	}
	public void setTransType(String transType) {
		this.transType = transType;
	}
	public String getShopperidp() {
		return shopperidp;
	}
	public void setShopperidp(String shopperidp) {
		this.shopperidp = shopperidp;
	}
	public String getScompany() {
		return scompany;
	}
	public void setScompany(String scompany) {
		this.scompany = scompany;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		if(endDate != null && !"".equals(endDate)){
			String tmp = Constants.SF_YYYYMMDD.format(endDate);
			try {
				endDate = Constants.SF_YYYYMMDDHHMMSS.parse(tmp + "235959");
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		this.endDate = endDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getBatchNo() {
		return batchNo;
	}
	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}
	public String getReply() {
		return reply;
	}
	public void setReply(String reply) {
		this.reply = reply;
	}
	
	
	
	
	public String getConfirmStartDate() {
		return confirmStartDate;
	}
	public void setConfirmStartDate(String confirmStartDate) {
		this.confirmStartDate = confirmStartDate;
	}
	public String getConfirmEndDate() {
		return confirmEndDate;
	}
	public void setConfirmEndDate(String confirmEndDate) {
		this.confirmEndDate = confirmEndDate;
	}
	public String getBatchStartDate() {
		return batchStartDate;
	}
	public void setBatchStartDate(String batchStartDate) {
		this.batchStartDate = batchStartDate;
	}
	public String getBatchEndDate() {
		return batchEndDate;
	}
	public void setBatchEndDate(String batchEndDate) {
		this.batchEndDate = batchEndDate;
	}
	public String getD0BatchNo() {
		return d0BatchNo;
	}
	public void setD0BatchNo(String d0BatchNo) {
		this.d0BatchNo = d0BatchNo;
	}
	
	
	public String getS0BatchNo() {
		return s0BatchNo;
	}
	public void setS0BatchNo(String s0BatchNo) {
		this.s0BatchNo = s0BatchNo;
	}
	public String getT1BatchNo() {
		return t1BatchNo;
	}
	public void setT1BatchNo(String t1BatchNo) {
		this.t1BatchNo = t1BatchNo;
	}
	public List<String> getS0List() {
		return s0List;
	}
	public void setS0List(List<String> s0List) {
		this.s0List = s0List;
	}
	public List<String> getD0List() {
		return d0List;
	}
	public void setD0List(List<String> d0List) {
		this.d0List = d0List;
	}
	public List<String> getT1List() {
		return t1List;
	}
	public void setT1List(List<String> t1List) {
		this.t1List = t1List;
	}
	public String getStatus_s0() {
		return status_s0;
	}
	public void setStatus_s0(String status_s0) {
		this.status_s0 = status_s0;
	}
	public String getStatus_d0() {
		return status_d0;
	}
	public void setStatus_d0(String status_d0) {
		this.status_d0 = status_d0;
	}
	public String getStatus_t1() {
		return status_t1;
	}
	public void setStatus_t1(String status_t1) {
		this.status_t1 = status_t1;
	}
	public String getRatio() {
		return ratio;
	}
	public void setRatio(String ratio) {
		this.ratio = ratio;
	}
	
	
	
	
	
	
	
	
	
}
