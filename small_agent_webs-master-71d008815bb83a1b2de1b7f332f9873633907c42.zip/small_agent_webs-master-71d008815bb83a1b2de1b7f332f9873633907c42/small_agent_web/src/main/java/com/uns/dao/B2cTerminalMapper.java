package com.uns.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.B2cTermBinder;
import com.uns.model.B2cTerminal;
import com.uns.web.form.TerminalForm;
@Repository
public interface B2cTerminalMapper {

    int deleteByPrimaryKey(String terminalid);

    int insert(B2cTerminal record);

    int insertSelective(B2cTerminal record);

    B2cTerminal selectByPrimaryKey(String terminalid);

    int updateByPrimaryKeySelective(B2cTerminal record);


    int updateByPrimaryKey(B2cTerminal record);

	List<B2cTermBinder> selectB2cb2cTerminal(Map map);
	//查看商户对应的绑定终端
	List<HashMap> selectTerBymerchantId();
	//查看商户对应的绑定终端的个数
	String selectTerminalCount(String terminalid);
	
	String selectTerminalbind(String terminalid);
	
	//查询选择商户对应的绑定终端
	List<HashMap> selectBinderNum(String shopperId);
	
	//查询出商户对应的绑定终端
	List<HashMap> selectExistTerminal(String shopperId);
	
	//查询出商户对应的绑定终端 和即将要添加的终端
	List<HashMap>  selectAjaxTerminal(String shopperId);
	
	//查询出商户对应的绑定终端 和即将要添加的终端
	List<HashMap>  selectOldTerminal(String shopperId);
	
	List selectTerminalList(TerminalForm form);

	B2cTerminal selectAllByPrimaryKey(String termid);

	//根据终端编号查询终端id
	String getTerminByTerNo(String terNo);

	List getTerminByMerchantNo(String merchantNo);
}