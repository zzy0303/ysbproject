package com.uns.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.common.page.PageContext;
import com.uns.dao.AgentMapper;
import com.uns.dao.B2cTermBinderMapper;
import com.uns.model.B2cFixedCode;
import com.uns.model.B2cTermBinder;
import com.uns.web.form.TerminalForm;

@Service
public class TerminalRepertoryService  {

	protected final Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	private B2cTermBinderMapper b2cTermBinderMapperDao;
	
	@Autowired
	private AgentMapper agentMapperDao;
	/**
	 * 查询所属自己的代理的
	 * @param agentNo
	 * @return
	 */
	public List<B2cTermBinder> findTermBatchList(String agentNo) {
		
		return this.b2cTermBinderMapperDao.findTermBatchList(agentNo);
	}
	/**
	 * 根据当前服务商编号查询记录
	 * @param agentNo
	 * @return
	 */
	public List<B2cTermBinder> findTermBatchByTermByAgentNo(String agentNo) {
		return this.b2cTermBinderMapperDao.findTermBatchByTermByAgentNo(agentNo);
	}
	/**
	 * 通过设备编号批量更新数据
	 * @param termNo
	 */
	public void updateBatchBinder(B2cTermBinder b2cTermBinder) {
		this.b2cTermBinderMapperDao.updateBatchBinder(b2cTermBinder);
		
	}

	/**
	 * 查询批次号是否存在
	 * @param termBatchNo
	 * @return
	 */
	public List findTermBatchNo(String termBatchNo) {
		return b2cTermBinderMapperDao.findTermBatchNo(termBatchNo);
	}
	/**
	 * 终端查询-登录非一级代理的
	 * @param mbForm
	 * @return
	 */
	public List<B2cTermBinder> findTerminalRepertoryInList(TerminalForm mbForm) {
		PageContext.initPageSize(Constants.page_size);
		return b2cTermBinderMapperDao.findTerminalRepertoryInList(mbForm);
	}
	/**
	 * 终端查询-登录为一级代理的
	 * @param mbForm
	 * @return
	 */
	public List<B2cTermBinder> findFirstTerminalInList(TerminalForm mbForm) {
		PageContext.initPageSize(Constants.page_size);
		return b2cTermBinderMapperDao.findFirstTerminalInList(mbForm);
	}
	/**
	 * 根据设备编号查询记录
	 * @param termNo
	 * @return
	 */
	public B2cTermBinder findTermBatchByTermNo(String termNo) {
		return this.b2cTermBinderMapperDao.findTermBatchByTermNo(termNo);
	}
	
	/**
	 * 获取一级服务商
	 * @param agent_no
	 * @return
	 */
	public String findFisrtAgentByNo(String agentNo) {
		// TODO Auto-generated method stub
		return agentMapperDao.findFisrtAgentByNo(agentNo);
	}
	/**
	 * 终端出库查询
	 * @param mbForm
	 * @return
	 */
	public List<B2cTermBinder> findTerminalRepertoryOutList(TerminalForm mbForm) {
		PageContext.initPageSize(Constants.page_size);
		return b2cTermBinderMapperDao.findTerminalRepertoryOutList(mbForm);
	}
	/**
	 * 更新数据-出库
	 * @param b2cTermBinder
	 */
	public void updateBatchBinderOut(B2cTermBinder b2cTermBinder) {
		this.b2cTermBinderMapperDao.updateBatchBinderOut(b2cTermBinder);
		
	}
	/**
	 * 终端退货
	 * @author yang.liu01
	 * @param retreatList
	 */
	public void updateTerminalRetreat(List<B2cTermBinder> retreatList) throws Exception{
		for (B2cTermBinder b2cTermBinder : retreatList) {
 			//执行插入
			this.b2cTermBinderMapperDao.updateTerminalRetreat(b2cTermBinder);
 		}
		
	}
	
	


}
