package com.uns.web;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.Page;
import com.uns.model.Users;
import com.uns.service.SplitService;
import com.uns.slx.common.mutidatasource.DataSourceSwitch;
import com.uns.util.ExcelUtils;
import com.uns.web.form.SplitForm;

@Controller
@RequestMapping("/smSplit.htm")
public class SmSplitController  extends BaseController{
	@Autowired
	private SplitService splitService;
		
	/**
	 * 更新批次状态 
	 */
	@RequestMapping(params = "method=auditSplit")
	public String auditSplit(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform){
		try {
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS_QRCODE.name());
			splitService.updateSmStatusByBatchNo(sform);
			request.setAttribute(Constants.MESSAGE_KEY,"操作成功");
			request.setAttribute("url","smSplit.htm?method=batchDetailList&batchNo="
					+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute(Constants.MESSAGE_KEY,"操作失败");
			request.setAttribute("url","smSplit.htm?method=batchDetailList&batchNo="
					+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		return "/returnPage";
	}
	
	/**batchDetailList
	 * 服务商疑议
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=toUpdateDoubt")
	public String toUpdateDoubt(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform) throws BusinessException{
		try{
		request.setAttribute("type", sform.getType());
		request.setAttribute("batchNo", sform.getBatchNo());
		request.setAttribute("status", sform.getStatus());
		request.setAttribute("id", sform.getId());
		if("1".equals(sform.getStatus())){
			return "splitProfit/smInsertDoubt";
		}else{
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS_QRCODE.name());
			Map<String,Object> map = splitService.selectDoubt(sform);
			request.setAttribute("bat", map);
			return "splitProfit/smUpdateDoubt";
		}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"服务商疑议错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
	}
	
	/**
	 * 添加疑议 
	 */
	@RequestMapping(params = "method=insertDoubt")
	public String insertDoubt(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform){
		sform.setStatus("2");
		sform.setCreateDate(new Date());
		try {
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS_QRCODE.name());
			splitService.smInsertDoubt(sform);
			request.setAttribute(Constants.MESSAGE_KEY, "操作成功");
			request.setAttribute("url","smSplit.htm?method=batchDetailList&batchNo="
					+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute(Constants.MESSAGE_KEY, "操作失败");
			request.setAttribute("url","smSplit.htm?method=batchDetailList&batchNo="
					+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		
		return "/returnPage";
	}
	
	/**
	 * 更新疑议 
	 */
	@RequestMapping(params = "method=updateDoubt")
	public String updateDoubt(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform){
		sform.setStatus("2");
		try {
		String str = sform.getDoubtHis();
		if(str != null && !"".equals(str) && !"null".equals(str)){
			sform.setDoubt(sform.getDoubtHis() + " || " + sform.getDoubt());
		}
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS_QRCODE.name());
			splitService.smUpdateDoubt(sform);
			request.setAttribute(Constants.MESSAGE_KEY, "操作成功");
			request.setAttribute("url","smSplit.htm?method=batchDetailList&batchNo="
					+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute(Constants.MESSAGE_KEY, "操作失败");
			request.setAttribute("url","smSplit.htm?method=batchDetailList&batchNo="
					+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		
		return "/returnPage";
	}
	
	/**
	 * 批量更新批次状态
	 */
	@RequestMapping(params = "method=batchUpdate")
	public String batchUpdate(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform){
		try {
			if(sform.getIds() != null){
				String ids = sform.getIds();
				String[] idsArr = ids.substring(1, ids.length()).split(",");
				List<String> list = Arrays.asList(idsArr);
				Map<String,Object> param = new HashMap<String, Object>();
				param.put("status", sform.getStatus());
				param.put("list", list);
				DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS_QRCODE.name());
				splitService.updateBatchSplitSm(param);
				DataSourceSwitch.clearDataSourceType();
			}
			request.setAttribute(Constants.MESSAGE_KEY, "操作成功");
			request.setAttribute("url", "smSplit.htm?method=findAgentSplitList");
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute(Constants.MESSAGE_KEY, "操作失败");
			request.setAttribute("url", "smSplit.htm?method=findAgentSplitList");
		}
		
		return "/returnPage";
	}
	/**
	 * 服务商扫码批次查询
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=findAgentSplitList")
	public String findAgentSmSplitList(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform) throws BusinessException{
		try{
			Users  sessionUser=(Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			if(sessionUser==null || StringUtils.isEmpty(Long.toString(sessionUser.getMerchantid()))){
				throw new BusinessException(ExceptionDefine.商户查询失败);
			}
			sform.setSessionUserNo(String.valueOf(sessionUser.getMerchantid()));
			if(sform.getEndDate() != null){
				Calendar c = Calendar.getInstance();
				c.setTime(sform.getEndDate());
				c.add(Calendar.DAY_OF_MONTH, 1);
				sform.setEndDate(c.getTime());
			}
			//切换数据库 
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS_QRCODE.name());
			List<Map<String,Object>> listData = splitService.selectSmBatchList(sform);
			
			for(Map<String,Object> map:listData){
				Date d1 = (Date)map.get("END_DATE");
				Calendar cal=Calendar.getInstance();
				cal.add(Calendar.WEEK_OF_MONTH, -4);
				cal.set(Calendar.DAY_OF_WEEK, 2);
				Date d2 = cal.getTime();
				if(d1.compareTo(d2) == -1 ){
					map.put("detailFlag", "0");
				}else{
					map.put("detailFlag", "1");
				}
			}
			//如果是下载
			if("1".equals(sform.getIfDownload())){
				//判断是否操作最大条数
				if(((Page)request.getAttribute("page")).getTotalRows()>Constants.MAX_DOWNLOAD_SIZE){
					request.setAttribute(Constants.MESSAGE_KEY,"单次最大下载条数为" + Constants.MAX_DOWNLOAD_SIZE + "条");
					request.setAttribute("url","smSplit.htm?method=findAgentSmSplitList");
					return "/returnPage";
				}
				listData = splitService.downSmBatchList(sform);
				for(Map<String,Object> map:listData){
					 map.put("STATUS", Constants.convertMap.get(map.get("STATUS")));
				}
				List<String> listHead = new ArrayList<String>();
				listHead.add("结算批次号");
				listHead.add("批次生成时间");
				listHead.add("服务商编号");
				listHead.add("服务商名称");
				listHead.add("交易笔数/笔");
				listHead.add("刷卡交易总金额/元");
				listHead.add("分润总金额/元");
				listHead.add("状态");
				List<String> listKey = new ArrayList<String>();
				listKey.add("BATCH_NO");
				listKey.add("CREATE_DATE");
				listKey.add("SHOPPERIDP");
				listKey.add("SCOMPANY");
				listKey.add("SUM_COUNT");
				listKey.add("SUM_AMOUNT");
				listKey.add("SUM_PROFIT");
				listKey.add("STATUS");
				try {
					ExcelUtils.downExcel(listData, listKey, listHead, "SM-BATCH", "扫码分润批次信息", response);
					return null;
				} catch (Exception e) {
					e.printStackTrace();
					return null;
				}
			}
			request.setAttribute("list", listData);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"服务商扫码批次查询 错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		return "splitProfit/smBatchList";
	}
	
	/**
	 * 服务商Sm批次详情查询
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=batchDetailList")
	public String BatchDetailList(HttpServletRequest request, HttpServletResponse response,
		SplitForm sform) throws BusinessException{
		try{
			request.setAttribute("batchNo", sform.getBatchNo());
			request.setAttribute("status", sform.getStatus());
			request.setAttribute("id", sform.getId());
			//切换数据库 
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS_QRCODE.name());
			List<Map<String,Object>> listData = splitService.selectSmSplitList(sform);
			
			//如果是下载
			if("1".equals(sform.getIfDownload())){
				if(((Page)request.getAttribute("page")).getTotalRows()>Constants.MAX_DOWNLOAD_SIZE){
					request.setAttribute(Constants.MESSAGE_KEY,"单次最大下载条数为" + Constants.MAX_DOWNLOAD_SIZE + "条");
					request.setAttribute("url","smSplit.htm?method=batchDetailList&batchNo="
							+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
					return "/returnPage";
				}
				listData = splitService.downSmSplitList(sform);
				List<String> listHead = new ArrayList<String>();
				listHead.add("订单号");
				listHead.add("服务商编号");
				listHead.add("服务商名称");
				listHead.add("商户号");
				listHead.add("商户名称");
				listHead.add("交易时间");
				listHead.add("通道类型");
				listHead.add("费率类型");
				listHead.add("提现费率(％)");
                listHead.add("服务商底价费率(％)");
				listHead.add("提现金额");
				listHead.add("手续费/元");
				listHead.add("到账金额/元");
				listHead.add("分润金额/元");
	
				List<String> listKey = new ArrayList<String>();
				listKey.add("OUTTRADENO");
				listKey.add("SHOPPERID_P");
				listKey.add("SCOMPANYP");
				listKey.add("SHOPPERID");
				listKey.add("SCOMPANY");
				listKey.add("OUTTRADETIME");
				listKey.add("CHANNEL_TYPE");
				listKey.add("FEE_TYPE");
				listKey.add("SM_FEE");
                listKey.add("AGENT_FEE");
				listKey.add("AMOUNT");
				listKey.add("COMMISSION");
				listKey.add("ARRIVALAMOUNT");
				listKey.add("PROFIT");
				try {
					for(Map<String,Object> map:listData){
						if("2".equals(map.get("CHANNEL_TYPE"))){
							map.put("CHANNEL_TYPE", "微信");
						}else if("3".equals(map.get("CHANNEL_TYPE"))){
							map.put("CHANNEL_TYPE", "支付宝");
						} else if("4".equals(map.get("CHANNEL_TYPE"))){
							map.put("CHANNEL_TYPE", "银联");
						} else if("5".equals(map.get("CHANNEL_TYPE"))){
							map.put("CHANNEL_TYPE", "快捷");
						} else if("6".equals(map.get("CHANNEL_TYPE"))){
							map.put("CHANNEL_TYPE", "B2C");
						}
						if("0".equals(map.get("FEE_TYPE"))){
							map.put("FEE_TYPE", "D0");
						}else if("1".equals(map.get("FEE_TYPE"))){
							map.put("FEE_TYPE", "T1");
						}
						String time = String.valueOf(map.get("OUTTRADETIME"));
						map.put("OUTTRADETIME", time.substring(0, 4) + "-" + time.substring(4, 6) + "-" + time.substring(6, 8) + "-" 
								 + time.substring(8, 10) + ":" + time.substring(10, 12) + ":" + time.substring(12, 14));
					}
					ExcelUtils.downExcel(listData, listKey, listHead, "SM-BATCH", "扫码分润批次信息", response);
					return null;
				} catch (Exception e) {
					e.printStackTrace();
					return null;
				}
			}
			request.setAttribute("list", listData);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"服务商Sm批次详情查询错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		return "splitProfit/smBatchDetailList";
	}
}
