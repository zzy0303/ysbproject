package com.uns.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.BankBranch;
@Repository
public interface BankBranchMapper {

    int insert(BankBranch record);

    int insertSelective(BankBranch record);
    
    List searchBankBranch(Map map);
    
    
    

}