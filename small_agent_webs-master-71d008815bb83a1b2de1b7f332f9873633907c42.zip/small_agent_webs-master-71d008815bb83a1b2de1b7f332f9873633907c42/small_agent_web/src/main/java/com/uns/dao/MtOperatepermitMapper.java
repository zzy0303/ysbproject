package com.uns.dao;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;
import org.springframework.stereotype.Repository;

import com.uns.model.MtOperatepermit;
@Repository
public interface MtOperatepermitMapper {

    List<MtOperatepermit> selectAllPermitTypeList();
}