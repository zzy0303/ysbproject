package com.uns.web.form;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.uns.model.AgentRatio;
import com.uns.model.AgentSplit;

public class AgentRatioForm {
	private Long agentid;
	private Long shopperid;
	private String scompany;
	private Long lowestamt;
	private String modeflag;
	private List<AgentRatio> ratiolist;
	private Double ratio;
	
	// AgentSplit
	private AgentSplit agentSplit;
	
	// 更新时间
	private String updatedate;
	// 分润规则条数
	private Long agentCount;
	// 预约生效时间
	private String effectdt;
	// 上级代理shopperid
	private Long shopperid_p;
	// 生效开始/结束时间
	private String effectdtStart;
	private String effectdtEnd;
	// 修改开始/结束时间
	private String updateStart;
	private String updateEnd;
	// 服务商备注
	private String remark;
	
	private String[] Mshopperid;
	
	private String shopperids;
	private String lowestamts;
	

	
	public Long getAgentid() {
		return agentid;
	}
	public void setAgentid(Long agentid) {
		this.agentid = agentid;
	}
	public Long getShopperid() {
		return shopperid;
	}
	public void setShopperid(Long shopperid) {
		this.shopperid = shopperid;
	}
	public String getScompany() {
		return scompany;
	}
	public void setScompany(String scompany) {
		this.scompany = scompany;
	}
	public Long getLowestamt() {
		return lowestamt;
	}
	public void setLowestamt(Long lowestamt) {
		this.lowestamt = lowestamt;
	}
	public String getModeflag() {
		return modeflag;
	}
	public void setModeflag(String modeflag) {
		this.modeflag = modeflag;
	}
	public List<AgentRatio> getRatiolist() {
		return ratiolist;
	}
	public void setRatiolist(List<AgentRatio> ratiolist) {
		this.ratiolist = ratiolist;
	}
	public Double getRatio() {
		return ratio;
	}
	public void setRatio(Double ratio) {
		this.ratio = ratio;
	}
	public AgentSplit getAgentSplit() {
		return agentSplit;
	}
	public void setAgentSplit(AgentSplit agentSplit) {
		this.agentSplit = agentSplit;
	}
	public String getUpdatedate() {
		return updatedate;
	}
	public void setUpdatedate(String updatedate) {
		this.updatedate = updatedate;
	}
	public Long getAgentCount() {
		return agentCount;
	}
	public void setAgentCount(Long agentCount) {
		this.agentCount = agentCount;
	}
	public String getEffectdt() {
		return effectdt;
	}
	public void setEffectdt(String effectdt) {
		this.effectdt = effectdt;
	}
	public Long getShopperid_p() {
		return shopperid_p;
	}
	public void setShopperid_p(Long shopperid_p) {
		this.shopperid_p = shopperid_p;
	}
	public String getEffectdtStart() {
		return effectdtStart;
	}
	public void setEffectdtStart(String effectdtStart) {
		this.effectdtStart = effectdtStart;
	}
	public String getEffectdtEnd() {
		return effectdtEnd;
	}
	public void setEffectdtEnd(String effectdtEnd) {
		this.effectdtEnd = effectdtEnd;
	}
	public String getUpdateStart() {
		return updateStart;
	}
	public void setUpdateStart(String updateStart) {
		this.updateStart = updateStart;
	}
	public String getUpdateEnd() {
		return updateEnd;
	}
	public void setUpdateEnd(String updateEnd) {
		this.updateEnd = updateEnd;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String[] getMshopperid() {
		return Mshopperid;
	}
	public void setMshopperid(String[] mshopperid) {
		Mshopperid = mshopperid;
	}
	public String getShopperids() {
		return shopperids;
	}
	public void setShopperids(String shopperids) {
		this.shopperids = shopperids;
	}
	public String getLowestamts() {
		return lowestamts;
	}
	public void setLowestamts(String lowestamts) {
		this.lowestamts = lowestamts;
	}
	public void trimUpdateDate(String start,String end){
		Pattern reg = Pattern.compile("^[0-9]{8}");
		if(start!=null){
			Matcher matcher1 = reg.matcher(start);
			boolean sflag = matcher1.matches();
			if(sflag){
				this.updateStart = start.substring(0,4)
									+"-"+start.substring(4,6)
									+"-"+start.substring(6,8)
									+" 00:00:00";
			}else{
				this.updateStart = null;
			}
		}else{
			this.updateStart = null;
		}
		if(end!=null){
			Matcher matcher2 = reg.matcher(end);
			boolean eflag = matcher2.matches();
			if(eflag){
				this.updateEnd = end.substring(0,4)
								  +"-"+end.substring(4,6)
								  +"-"+end.substring(6,8)
								  +" 23:59:59";
			}else{
				this.updateEnd = null;
			}
		}else{
			this.updateEnd = null;
		}
	}
	public void trimEffectdtDate(String start,String end){
		Pattern reg = Pattern.compile("^[0-9]{8}");
		if(start!=null){
			Matcher matcher1 = reg.matcher(start);
			boolean sflag = matcher1.matches();
			if(sflag){
				this.effectdtStart = start;
			}else{
				this.effectdtStart = null;
			}
		}else{
			this.effectdtStart = null;
		}
		if(end!=null){
			Matcher matcher2 = reg.matcher(end);
			boolean eflag = matcher2.matches();
			if(eflag){
				this.effectdtEnd = end;
			}else{
				this.effectdtEnd = null;
			}
		}else{
			this.effectdtEnd = null;
		}
	}
	
}
