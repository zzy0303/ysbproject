package com.uns.dao;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.MposMerchantFee;
@Repository
public interface MposMerchantFeeMapper {

    int deleteByPrimaryKey(BigDecimal id);

    int insert(MposMerchantFee record);

    int insertSelective(MposMerchantFee record);

    MposMerchantFee selectByPrimaryKey(BigDecimal id);

    int updateByPrimaryKeySelective(MposMerchantFee record);

    int updateByPrimaryKey(MposMerchantFee record);
    
    List<HashMap> selectByMerchantId(Long shopperid);
    
     List findbyshopperid(String shopperid);
    
    List queryfee(String shopperid);
    
    List<HashMap> selectByMerchantId1(Long shopperid);
    
    List findfee(Long shopperid);
    
    int deleteByshopperid(Long shopperid);


	List<MposMerchantFee> queryfee1(Map map);


	List findMposMerchantFee(String shopperid);

	List merchantfeelist(String shopperid);

	List findmerchantFeeList(String shopperid);

	List findQrPayMerchantFeeList(String shopperid);

	List findMposMerchantFeezhifu(String shopperid);

	String findQrPayMerchantFee(String shopperid);

	List findMerchantFee(Long shopperid);

	List findMerchantSkFee(Long shopperid);

	MposMerchantFee findRomteFeeTChannelType(Map params);

	List<MposMerchantFee> findMposMerchantFeeTempByType(Map<String, Object> paramsMap);

	MposMerchantFee findMerchantFeeTChannelType(Map params);

	List<Map<String, String>> findMposRemoteFeeByChannelType(Map params);

	List<MposMerchantFee> findMposMerchantFeeByType(Map<String, Object> paramsMap);

	List<Map<String, String>> findMposRemoteFeeByType(Map<String, Object> paramsMap);


    
}