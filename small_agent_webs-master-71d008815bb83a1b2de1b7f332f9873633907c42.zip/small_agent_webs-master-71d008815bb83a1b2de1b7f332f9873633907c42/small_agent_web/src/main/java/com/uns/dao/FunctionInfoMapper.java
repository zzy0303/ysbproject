package com.uns.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.FunctionInfo;
import com.uns.model.FunctionMerInfo;
@Repository
public interface FunctionInfoMapper {


    int deleteByPrimaryKey(BigDecimal id)throws Exception;
 
    int insert(FunctionInfo record)throws Exception;

    int insertSelective(FunctionInfo record)throws Exception;
  
    List<FunctionInfo> selectByPrimaryKey(Long roleId)throws Exception;

    int updateByPrimaryKeySelective(FunctionInfo record)throws Exception;

    int updateByPrimaryKey(FunctionInfo record)throws Exception;

	/**根据状态查出可以使用的权限
	 * @param conYes
	 * @return
	 */
	List<FunctionInfo> selectByStatus(Long status)throws Exception;

	List<FunctionInfo> selectFunctionByUsercode(String demo)throws Exception;


}