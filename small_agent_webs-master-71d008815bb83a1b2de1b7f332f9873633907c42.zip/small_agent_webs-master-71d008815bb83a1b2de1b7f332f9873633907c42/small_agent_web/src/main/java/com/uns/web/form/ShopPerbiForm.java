package com.uns.web.form;


import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.springframework.web.multipart.MultipartFile;


public class ShopPerbiForm {
	
	private String agentNo;
	
	private String shopperidq;
	private String shopperNameq;
	private String shoppercallingidq;
	private String transactidq;
	private String sagentidq;
	private String belongsAgentq;
	private Long   shopperid_q;
	private String createdStart;
	private String createdEnd;
	private String bargainedateStart;
	private String bargainedateEnd;
	private String bargainbdates;
	private String bargainedates; 
	private String writebargains;
	private String effectdt;
	private String belongsAgent;
	private Long shopperid_p;
	private MultipartFile stdFileNames;
	private MultipartFile addFileNames;
	private String stdfilenamesHidden;
	private String addFileNamesHidden;
	private MultipartFile termialfiles;
	private MultipartFile bankfiles;
	private String termialfilesHidden;
	private String bankfilesHidden;
	private Long currentid;//当前服务商id
	private String shopperid;
	private String taskidq;
	private String posCodeq;
	private String tranStart;
	private String evicenumber;
	private String parentid;
	private String stel;
	private String  examineresullt;
	private String cardType;
	
	private String open_create_start;
	private String open_create_end;
	
	private boolean checkAgents;
	
	private String recheckmerchantflag;
	
	private String tranEnd;
	private String settleStart;
	private String settleEnd;
	private String cardtypeq;
	private String tranStatusq;
	private String taskamountq;
	private String terminalNum;
	private String  hiddenNum;
	private String opencheckstatus;
	private String ifvalid;
	private String sifpactid;
	private String sprovince;
	private String city;
	private String termianlstatus;
	private Date worktime;
	private Short isformal;//判断正式表中是否有数据
	private Short isupdateshopper;//判断商户基本信息是否修改
	private Short isupdatebank;//开户信息是否修改
	private Long basecost;
	private String ifactivated; 
	private String ifacticreatedStart;
	private String ifacticreatedEnd;
	
	//zzh add
	private MultipartFile handidentitycardphoto;
	private MultipartFile frontidentitycardphoto;
	private MultipartFile reverseidentitycardphoto;
	private MultipartFile storephoto;
	private MultipartFile instorephoto;
	private MultipartFile checkstandphoto;
	private MultipartFile signaturephoto;
	private MultipartFile licensephoto;
	private MultipartFile  creditCardPhoto;
	private MultipartFile  settlementCardPhoto;
	
	
    private String photoCheckFlag;
    private String photoRecheckFlag;
    private String photoRecheckRemark;

	private String scompany;//商户名称 
	private String updatedStart;//修改时间下限
	private String updatedEnd;//修改时间下限
	private String province;//所在省份
	private String recheckDateStart;//审核时间下限
	private String recheckDateEnd;//审核时间上限
	private String checkstatus;//审核状态
	private String ifactivadateStart;//激活时间下限
	private String ifactivadateEnd;//激活时间上限

	private String reportResource;//报件来源
	private String shopperidP;//所属服务商
	
	private String haveInviteCodeP;//是否裂变商户

	public String getHaveInviteCodeP() {
		return haveInviteCodeP;
	}

	public void setHaveInviteCodeP(String haveInviteCodeP) {
		this.haveInviteCodeP = haveInviteCodeP;
	}

	public String getRecheckDateStart() {
		return recheckDateStart;
	}

	public void setRecheckDateStart(String recheckDateStart) {
		this.recheckDateStart = recheckDateStart;
	}

	public String getRecheckDateEnd() {
		return recheckDateEnd;
	}

	public void setRecheckDateEnd(String recheckDateEnd) {
		this.recheckDateEnd = recheckDateEnd;
	}

	public String getIfactivadateStart() {
		return ifactivadateStart;
	}

	public void setIfactivadateStart(String ifactivadateStart) {
		this.ifactivadateStart = ifactivadateStart;
	}

	public String getIfactivadateEnd() {
		return ifactivadateEnd;
	}

	public void setIfactivadateEnd(String ifactivadateEnd) {
		this.ifactivadateEnd = ifactivadateEnd;
	}

	public String getShopperidP() {
		return shopperidP;
	}

	public void setShopperidP(String shopperidP) {
		this.shopperidP = shopperidP;
	}

	public String getRecheckmerchantflag() {
		return recheckmerchantflag;
	}
	public void setRecheckmerchantflag(String recheckmerchantflag) {
		this.recheckmerchantflag = recheckmerchantflag;
	}
	public boolean isCheckAgents() {
		return checkAgents;
	}
	public void setCheckAgents(boolean checkAgents) {
		this.checkAgents = checkAgents;
	}
	public String getOpen_create_start() {
		return open_create_start;
	}
	public void setOpen_create_start(String open_create_start) {
		this.open_create_start = open_create_start;
	}
	public String getOpen_create_end() {
		return open_create_end;
	}
	public void setOpen_create_end(String open_create_end) {
		this.open_create_end = open_create_end;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public String getExamineresullt() {
		return examineresullt;
	}
	public void setExamineresullt(String examineresullt) {
		this.examineresullt = examineresullt;
	}
	public String getStel() {
		return stel;
	}
	public void setStel(String stel) {
		this.stel = StringUtils.isNumeric(stel) ? StringUtils.trim(stel) : null;
	}
	public String getEvicenumber() {
		return evicenumber;
	}
	public void setEvicenumber(String evicenumber) {
		this.evicenumber = evicenumber;
	}
	public String getParentid() {
		return parentid;
	}
	public void setParentid(String parentid) {
		this.parentid = parentid;
	}
	public String getTermianlstatus() {
		return termianlstatus;
	}
	public void setTermianlstatus(String termianlstatus) {
		this.termianlstatus = termianlstatus;
	}

	public String getScompany() {
		return scompany;
	}

	public void setScompany(String scompany) {
		this.scompany = StringUtils.isEmpty(scompany) ? null : StringUtils.trim(scompany);
	}

	public String getUpdatedStart() {
		return updatedStart;
	}

	public void setUpdatedStart(String updatedStart) {
		this.updatedStart = updatedStart;
	}

	public String getUpdatedEnd() {
		return updatedEnd;
	}

	public void setUpdatedEnd(String updatedEnd) {
		this.updatedEnd = updatedEnd;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCheckstatus() {
		return checkstatus;
	}

	public void setCheckstatus(String checkstatus) {
		this.checkstatus = checkstatus;
	}

	public String getReportResource() {
		return reportResource;
	}

	public void setReportResource(String reportResource) {
		this.reportResource = reportResource;
	}

	public MultipartFile getSettlementCardPhoto() {
		return settlementCardPhoto;
	}
	public void setSettlementCardPhoto(MultipartFile settlementCardPhoto) {
		this.settlementCardPhoto = settlementCardPhoto;
	}
	public MultipartFile getCreditCardPhoto() {
		return creditCardPhoto;
	}
	public void setCreditCardPhoto(MultipartFile creditCardPhoto) {
		this.creditCardPhoto = creditCardPhoto;
	}
	public MultipartFile getHandidentitycardphoto() {
		return handidentitycardphoto;
	}
	public void setHandidentitycardphoto(MultipartFile handidentitycardphoto) {
		this.handidentitycardphoto = handidentitycardphoto;
	}
	public MultipartFile getFrontidentitycardphoto() {
		return frontidentitycardphoto;
	}
	public void setFrontidentitycardphoto(MultipartFile frontidentitycardphoto) {
		this.frontidentitycardphoto = frontidentitycardphoto;
	}
	public MultipartFile getReverseidentitycardphoto() {
		return reverseidentitycardphoto;
	}
	public void setReverseidentitycardphoto(MultipartFile reverseidentitycardphoto) {
		this.reverseidentitycardphoto = reverseidentitycardphoto;
	}
	public MultipartFile getStorephoto() {
		return storephoto;
	}
	public void setStorephoto(MultipartFile storephoto) {
		this.storephoto = storephoto;
	}
	public MultipartFile getInstorephoto() {
		return instorephoto;
	}
	public void setInstorephoto(MultipartFile instorephoto) {
		this.instorephoto = instorephoto;
	}
	public MultipartFile getCheckstandphoto() {
		return checkstandphoto;
	}
	public void setCheckstandphoto(MultipartFile checkstandphoto) {
		this.checkstandphoto = checkstandphoto;
	}
	public MultipartFile getSignaturephoto() {
		return signaturephoto;
	}
	public void setSignaturephoto(MultipartFile signaturephoto) {
		this.signaturephoto = signaturephoto;
	}
	public MultipartFile getLicensephoto() {
		return licensephoto;
	}
	public void setLicensephoto(MultipartFile licensephoto) {
		this.licensephoto = licensephoto;
	}
	public String getPhotoCheckFlag() {
		return photoCheckFlag;
	}
	public void setPhotoCheckFlag(String photoCheckFlag) {
		this.photoCheckFlag = photoCheckFlag;
	}
	public String getPhotoRecheckFlag() {
		return photoRecheckFlag;
	}
	public void setPhotoRecheckFlag(String photoRecheckFlag) {
		this.photoRecheckFlag = photoRecheckFlag;
	}
	public String getPhotoRecheckRemark() {
		return photoRecheckRemark;
	}
	public void setPhotoRecheckRemark(String photoRecheckRemark) {
		this.photoRecheckRemark = photoRecheckRemark;
	}
	public Long getBasecost() {
		return basecost;
	}
	public void setBasecost(Long basecost) {
		this.basecost = basecost;
	}
	public Short getIsupdateshopper() {
		return isupdateshopper;
	}
	public void setIsupdateshopper(Short isupdateshopper) {
		this.isupdateshopper = isupdateshopper;
	}
	public Short getIsupdatebank() {
		return isupdatebank;
	}
	public void setIsupdatebank(Short isupdatebank) {
		this.isupdatebank = isupdatebank;
	}
	public Short getIsformal() {
		return isformal;
	}
	public void setIsformal(Short isformal) {
		this.isformal = isformal;
	}
	public Date getWorktime() {
		return worktime;
	}
	public void setWorktime(Date worktime) {
		this.worktime = worktime;
	}
	public MultipartFile getTermialfiles() {
		return termialfiles;
	}
	public String getAgentNo() {
		return agentNo;
	}
	public void setAgentNo(String agentNo) {
		this.agentNo = agentNo;
	}
	public void setTermialfiles(MultipartFile termialfiles) {
		this.termialfiles = termialfiles;
	}
	public MultipartFile getBankfiles() {
		return bankfiles;
	}
	public void setBankfiles(MultipartFile bankfiles) {
		this.bankfiles = bankfiles;
	}
	public String getTermialfilesHidden() {
		return termialfilesHidden;
	}
	public void setTermialfilesHidden(String termialfilesHidden) {
		this.termialfilesHidden = termialfilesHidden;
	}
	public String getBankfilesHidden() {
		return bankfilesHidden;
	}
	public void setBankfilesHidden(String bankfilesHidden) {
		this.bankfilesHidden = bankfilesHidden;
	}
	public String getHiddenNum() {
		return hiddenNum;
	}
	
	public void setHiddenNum(String hiddenNum) {
		this.hiddenNum = hiddenNum;
	}
	
	public String getSprovince() {
		return sprovince;
	}
	public void setSprovince(String sprovince) {
		this.sprovince = sprovince;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getSifpactid() {
		return sifpactid;
	}
	public void setSifpactid(String sifpactid) {
		this.sifpactid = sifpactid;
	}
	public String getifactivated() {
		return ifactivated;
	}
	public void setifactivated(String ifactivated) {
		this.ifactivated = ifactivated;
	}
	public String getOpencheckstatus() {
		return opencheckstatus;
	}
	public void setOpencheckstatus(String opencheckstatus) {
		this.opencheckstatus = opencheckstatus;
	}
	public String getIfvalid() {
		return ifvalid;
	}
	public void setIfvalid(String ifvalid) {
		this.ifvalid = ifvalid;
	}

	public String getTerminalNum() {
		return terminalNum;
	}
	public void setTerminalNum(String terminalNum) {
		this.terminalNum = terminalNum;
	}
	public String getEffectdt() {
		return effectdt;
	}
	public void setEffectdt(String effectdt) {
		this.effectdt = effectdt;
	}
	public String getTaskidq() {
		return taskidq;
	}
	public void setTaskidq(String taskidq) {
		this.taskidq = taskidq;
	}
	public String getPosCodeq() {
		return posCodeq;
	}
	public void setPosCodeq(String posCodeq) {
		this.posCodeq = posCodeq;
	}
	public String getTranStart() {
		return tranStart;
	}
	public void setTranStart(String tranStart) {
		this.tranStart = tranStart;
	}
	public String getTranEnd() {
		return tranEnd;
	}
	public void setTranEnd(String tranEnd) {
		this.tranEnd = tranEnd;
	}
	public String getSettleStart() {
		return settleStart;
	}
	public void setSettleStart(String settleStart) {
		this.settleStart = settleStart;
	}
	public String getSettleEnd() {
		return settleEnd;
	}
	public void setSettleEnd(String settleEnd) {
		this.settleEnd = settleEnd;
	}
	public String getCardtypeq() {
		return cardtypeq;
	}
	public void setCardtypeq(String cardtypeq) {
		this.cardtypeq = cardtypeq;
	}
	public String getTranStatusq() {
		return tranStatusq;
	}
	public void setTranStatusq(String tranStatusq) {
		this.tranStatusq = tranStatusq;
	}
	public String getTaskamountq() {
		return taskamountq;
	}
	public void setTaskamountq(String taskamountq) {
		this.taskamountq = taskamountq;
	}
	public String getShopperid() {
		return shopperid;
	}
	public void setShopperid(String shopperid) {
		this.shopperid = StringUtils.isNumeric(shopperid) ? StringUtils.trim(shopperid) : null;
	}
	
	
	public Long getCurrentid() {
		return currentid;
	}
	public void setCurrentid(Long currentid) {
		this.currentid = currentid;
	}
	public String getBelongsAgentq() {
		return belongsAgentq;
	}
	public void setBelongsAgentq(String belongsAgentq) {
		this.belongsAgentq = belongsAgentq;
	}
	public Long getShopperid_q() {
		return shopperid_q;
	}
	public void setShopperid_q(Long shopperid_q) {
		this.shopperid_q = shopperid_q;
	}
	public String getStdfilenamesHidden() {
		return stdfilenamesHidden;
	}
	public void setStdfilenamesHidden(String stdfilenamesHidden) {
		this.stdfilenamesHidden = stdfilenamesHidden;
	}
	public String getAddFileNamesHidden() {
		return addFileNamesHidden;
	}
	public void setAddFileNamesHidden(String addFileNamesHidden) {
		this.addFileNamesHidden = addFileNamesHidden;
	}
	public MultipartFile getStdFileNames() {
		return stdFileNames;
	}
	public void setStdFileNames(MultipartFile stdFileNames) {
		this.stdFileNames = stdFileNames;
	}
	public MultipartFile getAddFileNames() {
		return addFileNames;
	}
	public void setAddFileNames(MultipartFile addFileNames) {
		this.addFileNames = addFileNames;
	}
	
	public String getShopperidq() {
		return shopperidq;
	}
	public void setShopperidq(String shopperidq) {
		this.shopperidq = shopperidq.trim();
	}
	public String getShopperNameq() {
		return shopperNameq;
	}
	public void setShopperNameq(String shopperNameq) {
		this.shopperNameq = shopperNameq.trim();
	}
	public String getShoppercallingidq() {
		return shoppercallingidq;
	}
	public void setShoppercallingidq(String shoppercallingidq) {
		this.shoppercallingidq = shoppercallingidq;
	}
	public String getTransactidq() {
		return transactidq;
	}
	public void setTransactidq(String transactidq) {
		this.transactidq = transactidq;
	}
	public String getSagentidq() {
		return sagentidq;
	}
	public void setSagentidq(String sagentidq) {
		this.sagentidq = sagentidq;
	}
	
	public String getCreatedStart() {
		return createdStart;
	}
	public void setCreatedStart(String createdStart) {
		this.createdStart = createdStart;
	}
	public String getCreatedEnd() {
		return createdEnd;
	}
	public void setCreatedEnd(String createdEnd) {
		this.createdEnd = createdEnd;
	}
	public String getifacticreatedStart() {
		return ifacticreatedStart;
	}
	public void setifacticreatedStart(String ifacticreatedStart) {
		this.ifacticreatedStart = ifacticreatedStart;
	}
	public String getifacticreatedEnd() {
		return ifacticreatedEnd;
	}
	public void setifacticreatedEnd(String ifacticreatedEnd) {
		this.ifacticreatedEnd = ifacticreatedEnd;
	}
	public String getBargainedateStart() {
		return bargainedateStart;
	}
	public void setBargainedateStart(String bargainedateStart) {
		this.bargainedateStart = bargainedateStart;
	}
	public String getBargainedateEnd() {
		return bargainedateEnd;
	}
	public void setBargainedateEnd(String bargainedateEnd) {
		this.bargainedateEnd = bargainedateEnd;
	}
	public String getBelongsAgent() {
		return belongsAgent;
	}
	public void setBelongsAgent(String belongsAgent) {
		this.belongsAgent = belongsAgent;
	}
	
	public Long getShopperid_p() {
		return shopperid_p;
	}
	public void setShopperid_p(Long shopperid_p) {
		this.shopperid_p = shopperid_p;
	}
	public String getBargainbdates() {
		return bargainbdates;
	}
	public void setBargainbdates(String bargainbdates) {
		this.bargainbdates = bargainbdates;
	}
	public String getBargainedates() {
		return bargainedates;
	}
	public void setBargainedates(String bargainedates) {
		this.bargainedates = bargainedates;
	}
	public String getWritebargains() {
		return writebargains;
	}
	public void setWritebargains(String writebargains) {
		this.writebargains = writebargains;
	}

}
