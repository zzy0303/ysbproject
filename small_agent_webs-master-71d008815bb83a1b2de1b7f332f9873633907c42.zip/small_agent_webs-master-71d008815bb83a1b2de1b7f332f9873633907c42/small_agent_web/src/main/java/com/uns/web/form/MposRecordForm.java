package com.uns.web.form;

import java.util.Date;

public class MposRecordForm {
	
	private String minAmount;
	private String maxAmount;
	private String merchantId;
	private String status;
	private String shopperid_p;
	private String belongsAgent;
	private Date startTime;
	private Date endTime;
	
	private Date startDate;
	private Date endDate;
	private String flag;
	private String chargechannel;//通道类型
	
	
	
	public String getMinAmount() {
		return minAmount;
	}
	public void setMinAmount(String minAmount) {
		this.minAmount = minAmount;
	}
	public String getMaxAmount() {
		return maxAmount;
	}
	public void setMaxAmount(String maxAmount) {
		this.maxAmount = maxAmount;
	}
	public String getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getShopperid_p() {
		return shopperid_p;
	}
	public void setShopperid_p(String shopperid_p) {
		this.shopperid_p = shopperid_p;
	}
	public String getBelongsAgent() {
		return belongsAgent;
	}
	public void setBelongsAgent(String belongsAgent) {
		this.belongsAgent = belongsAgent;
	}
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public String getChargechannel() {
		return chargechannel;
	}
	public void setChargechannel(String chargechannel) {
		this.chargechannel = chargechannel;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	
	
	
	

}
