package com.uns.common;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import com.uns.inf.acms.client.DynamicConfigLoader;

public class Constants {
	
	/**
	 * 统一错误消息KEY
	 */
	public static final String MESSAGE_KEY="message";
	
	public static final String SESSION_VERIFY_CODE="sessionVerifycode";
	//操作员个人信息Session
	public static final String SESSION_KEY_USER="sessionUser";
	//商户绑定的终端Session
	public static final String SESSION_KEY_SHOPPER="b2cTermBinderNo";
	//服务商户编号
	public static final String SESSION_KEY_AGENT="agentNo";
	
	public static final String SESSION_KEY_APP_USER="sessionkeyappuser";

	//提示信息
	public static final String SAVE_MESSAGE = "保存成功!";
	//提示信息
	public static final String DEL_MESSAGE = "删除成功!";
	//退款策略
	public static final String CON_DICTCLS_RETURNPOLICY = "022";
	//结算策略
	public static final String CON_DICTCLS_FOOTFPOLICY = "023"; 
	//转帐费承担方
	public static final String CON_DICTCLS_FOOTTRANSAMOUNT = "024";
	//退款手续费策略
	public static final String CON_DICTCLS_RETURN_POUND = "030";
	//行业类型
	public static final String CON_DICTCLS_CALLING = "200";
	
	/*
	 * 服务商注册时，用于生成商户号的行业类型,暂时写为1
	 */
	public static final String CON_MCC = "1";
	/*
	 * 服务商是否准入,'N' 未准入 'Y' 已准入
	 */
	public static final String CON_AUDIT_YES = "Y";
	public static final String CON_AUDIT_NO = "N";
	
	public static final String 	CON_NO = "0";
	public static final String 	CON_YES = "1";

	public static final String PASSWORD_FOR_SHOW = "unspay";
	
	public static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd";
	
	public static final String DEFAULT_DATETIME_FORMAT = "yyyy-MM-dd hh:mm:ss";
	
	public static final String DEFAULT_DATE_FORMAT2 = "yyyyMMddHHmmss";
	
	public static final String WITHDRAW_STATUS1="1";
	public static final String WITHDRAW_STATUS2="2";
	public static final String WITHDRAW_STATUS5="5";
	public static final String WITHDRAW_STATUS6="6";
	
	public static final String HK_TYPE="bjhaike_mpos_all";
	
	public static final String HF_TYPE="hongpaydata";
	/**
	 * 网络连接错误!
	 */
	public static final String internet_err_2001="2001";
	
	/**
	 * 交易流水导出excel,每页3000行
	 */
	public static int excel_size=3000;
	
	/**
	 * 交易流水展示,每页20行
	 */
	public static final int page_size=20;
	public static final int page=2;
	
	/**
	 * 默认服务商与终端绑定状态
	 * 
	 */
	public static final String term_agent_binder="0";

	public static final String ERROR_MESSAGE = "errMsg";
	
	//获取基本路径
	
	private static ResourceBundle MSG = ResourceBundle.getBundle("messages");
	
	private static ResourceBundle MPOSMSG = ResourceBundle.getBundle("mposMessages");
	
	//获取商户鉴权返回信息配置文件
	private static ResourceBundle BANKCARDVAL = ResourceBundle.getBundle("bankCardValidateMsg");
	
	
	
	
	public static final String SUCCESS_CODE = "0000";
	//扫码修改返回码
	public static final String UPADTELIMIT_CODE="7899";

	public static final long TIME_DATE =1000*60*30;
	
	public static final long TIME_TEN =1000*60*10;

	public static final long TIME_ONE = 1000*60*1;
	

	
	public static final String MONEY_0 = "0.00";
	
	public static final String D0_CREDIT = "0.07";
	
	public static final String MONEY_2 = "2.00";
	
	public static final String MONEY_197 = "197.00";
	
	
	//个人 0 商户1 //状态为0 1 2 
	public static final String PERSONAL ="0";
	public static final String SHOPPER ="1";
	//  申请主题“开通商户”主题(1.商户开通2.变更开户信息	3.变更终端信息4.变更证照信息）
	public static final String STATUS1="1";
	public static final String STATUS2 ="2";
	public static final String STATUS3 ="3";
	public static final String STATUS4 ="4";
	public static final String STATUS0="0";
	public static final String STATUS5="5";
	public static final String STATUS6="6";
	public static final String STATUS7="7";
	public static final String 	REPEAL = "3";
	public static final Object 	PAST_STATUS = "4";
	public static final int 	PASTDATE = 2;
	//		
	public static final String TYPE_1="1";
	public static final String TYPE_2="2";
	public static final String TYPE_3="3";
	public static final String TYPE_4="4";
	public static final String TYPE_5="5";
	public static final String TYPE_6="6";
	public static final String TYPE_7="7";


    public static final String SMS_SUCCESS_KEY = "sms_success_key";
    
    public static final String SMS_FAILURE_KEY = "sms_failure_key";
    
  	
	///结算最小金额500
	public static final String MIN_SETTLE_MONEY="50000";
	
	/**
	 * add by FK
	 */
	//判断商户编号
	public static final String CON_FIGURE="^[-+]?(([0-9]+)([.]([0-9]+))?|([.]([0-9]+))?)$";
	
	//验证手机号
	public static final String CHECK_MOBILE = "^[1][3,4,5,8][0-9]{9}$";
	//验证密码格式  至少6位字母或数字
	public static final String CHECK_PWD = "^[0-9a-zA-Z]{6,}$";
	
	
	public static final String FEE_TYPE_WECHAT="WXZF";//微信支付
	public static final String FEE_TYPE_ALIPAY="ZFBZF";//支付宝支付
	public static final String D0="0";
	public static final String T1="1";
	
	
	public static enum DATASOURCE_INSTANCE{
		U3_SMALL,
		MPOS_QRCODE,
		MPOS
	}
	
	
	/**
	 * 二维码绑定URL
	 */
	public static final String QRCODE_BIND_URL = DynamicConfigLoader.getByEnv("qrcode_bind_url");
	
	
	//小商户功能账户秘钥
	
	public static final Map<String, String> bankCardValMsg = new HashMap<String, String>();
	static{
		bankCardValMsg.put("0000", BANKCARDVAL.getString("0000"));
		bankCardValMsg.put("1111", BANKCARDVAL.getString("1111"));
		bankCardValMsg.put("1000", BANKCARDVAL.getString("1000"));
		bankCardValMsg.put("1001", BANKCARDVAL.getString("1001"));
		bankCardValMsg.put("1002", BANKCARDVAL.getString("1002"));
		bankCardValMsg.put("1004", BANKCARDVAL.getString("1004"));
		bankCardValMsg.put("1005", BANKCARDVAL.getString("1005"));
		bankCardValMsg.put("1006", BANKCARDVAL.getString("1006"));
		bankCardValMsg.put("1007", BANKCARDVAL.getString("1007"));
		bankCardValMsg.put("1008", BANKCARDVAL.getString("1008"));
		bankCardValMsg.put("1009", BANKCARDVAL.getString("1009"));
		bankCardValMsg.put("1010", BANKCARDVAL.getString("1010"));
		bankCardValMsg.put("1011", BANKCARDVAL.getString("1011"));
		bankCardValMsg.put("1030", BANKCARDVAL.getString("1030"));
		bankCardValMsg.put("1099", BANKCARDVAL.getString("1099"));
		bankCardValMsg.put("2000", BANKCARDVAL.getString("2000"));
		bankCardValMsg.put("2001", BANKCARDVAL.getString("2001"));
		bankCardValMsg.put("2002", BANKCARDVAL.getString("2002"));
		bankCardValMsg.put("2003", BANKCARDVAL.getString("2003"));
		bankCardValMsg.put("2030", BANKCARDVAL.getString("2030"));
		bankCardValMsg.put("2033", BANKCARDVAL.getString("2033"));
		bankCardValMsg.put("2040", BANKCARDVAL.getString("2040"));
	}
	
	public static final Map<String, String> CZ_DATA = new HashMap<String, String>();
	
	public static final Map<String, String> mapReturnMsg = new HashMap<String, String>();
	static{
	    mapReturnMsg.put("0000", MPOSMSG.getString("0000")); 
	    mapReturnMsg.put("0001", MPOSMSG.getString("0001"));
		mapReturnMsg.put("1001", MPOSMSG.getString("1001"));
		mapReturnMsg.put("1000", MPOSMSG.getString("1000"));
		mapReturnMsg.put("2000", MPOSMSG.getString("2000"));
		mapReturnMsg.put("2100", MPOSMSG.getString("2100"));
		mapReturnMsg.put("2211", MPOSMSG.getString("2211"));
		mapReturnMsg.put("2215", MPOSMSG.getString("2215"));
		mapReturnMsg.put("2216", MPOSMSG.getString("2216"));
		mapReturnMsg.put("2217", MPOSMSG.getString("2217"));
		mapReturnMsg.put("2218", MPOSMSG.getString("2218"));
		mapReturnMsg.put("2200", MPOSMSG.getString("2200"));
		mapReturnMsg.put("3000", MPOSMSG.getString("3000"));
		mapReturnMsg.put("3001", MPOSMSG.getString("3001"));
		mapReturnMsg.put("3002", MPOSMSG.getString("3002"));
		mapReturnMsg.put("3005", MPOSMSG.getString("3005"));
		mapReturnMsg.put("3006", MPOSMSG.getString("3006"));
		mapReturnMsg.put("3007", MPOSMSG.getString("3007"));
		mapReturnMsg.put("5001", MPOSMSG.getString("5001"));
		mapReturnMsg.put("6004", MPOSMSG.getString("6004"));
		mapReturnMsg.put("6006", MPOSMSG.getString("6006"));
		mapReturnMsg.put("6011", MPOSMSG.getString("6011"));
		mapReturnMsg.put("7001", MPOSMSG.getString("7001"));
		mapReturnMsg.put("7002", MPOSMSG.getString("7002"));
		mapReturnMsg.put("7003", MPOSMSG.getString("7003"));
		mapReturnMsg.put("7005", MPOSMSG.getString("7005"));
		mapReturnMsg.put("7006", MPOSMSG.getString("7006"));
		mapReturnMsg.put("9001", MPOSMSG.getString("9001"));
		mapReturnMsg.put("9999", MPOSMSG.getString("9999"));
		mapReturnMsg.put("10100000", MPOSMSG.getString("10100000"));
		mapReturnMsg.put("10100001", MPOSMSG.getString("10100001"));
		mapReturnMsg.put("10100002", MPOSMSG.getString("10100002"));
		mapReturnMsg.put("10100003", MPOSMSG.getString("10100003"));
		mapReturnMsg.put("10100004", MPOSMSG.getString("10100004"));
		mapReturnMsg.put("10800000", MPOSMSG.getString("10800000"));
	  	mapReturnMsg.put("11110001", MPOSMSG.getString("11110001"));
		mapReturnMsg.put("11110002", MPOSMSG.getString("11110002"));
		mapReturnMsg.put("11110003", MPOSMSG.getString("11110003"));
		mapReturnMsg.put("11110004", MPOSMSG.getString("11110004"));
		mapReturnMsg.put("11110005", MPOSMSG.getString("11110005"));
		mapReturnMsg.put("11110006", MPOSMSG.getString("11110006"));
		mapReturnMsg.put("11110007", MPOSMSG.getString("11110007"));
		mapReturnMsg.put("11110008", MPOSMSG.getString("11110008"));
		mapReturnMsg.put("11110009", MPOSMSG.getString("11110009"));
		mapReturnMsg.put("11110010", MPOSMSG.getString("11110010"));	
	
	}
	
	
	//App版本号
	public static final String VERSION_1_0_0="1.0.0";
	public static final String VERSION_1_0_1="1.0.1";
	public static final String VERSION_2_0_0="2.0.0";
	public static final String VERSION_2_0_1="2.0.1";
	public static final String VERSION_2_1_0="2.1.0";
	
	public static final String TYPE_P="P";//个人
	public static final String TYPE_C="C";//C企业
	
	/**
	 * 二维码绑定URL
	 */
	
	public static final String TYPE_A="A";
	
	public static final String TYPE_I="I";
	
	
	
	public static Map<String, String> convertMap = new HashMap<String, String>();
	static{
	    convertMap.put("0", "未审核");
	    convertMap.put("1", "未确认");
	    convertMap.put("2", "有疑议");
	    convertMap.put("3", "未结算");
	    convertMap.put("4", "已结算");
	    convertMap.put("5", "审核不通过");
	    convertMap.put("6", "疑议已处理");
	}
	

	public static final SimpleDateFormat SF_YYYYMMDD = new SimpleDateFormat("yyyyMMdd");
	
	public static final SimpleDateFormat SF_YYYYMMDDHHMMSS = new SimpleDateFormat("yyyyMMddHHmmss");
	
	public static final Map<String,Date> TIME_LIMIT = new HashMap<String, Date>();

	
	public static final Object AGENTFEE = "0.0078";

	public static final Object TOPMAX = "35";

	public static final Object TOPMIN = "30";
		

	public static final String ORGTYPE = "1";

	public static final int UPLOAD_SIZE = 5001;


	public static  int HK_SERVERPORT = 8088;
	
	
	public static String QUERY_SUCCEEDED=MSG.getString("00003");
	
	public static String NO_RETURN_RESULTS=MSG.getString("00004");
	
	public static String LOSE_PARAMETER=MSG.getString("00005");

	public static String NO_RETURN_RESULTS_CODE="00004";
	
	public static String LOSE_PARAMETER_CODE="00005";

	
	
	
	//一级服务商不一致
	public static final String TERM_STATUS1="0001";
	//终端号不存在
	public static final String TERM_STATUS2="0002";
	//服务商不一致
	public static final String TERM_STATUS3="0003";
	//已经绑定商户
	public static final String TERM_STATUS4="0004";
	//终端已经入过库
	public static final String TERM_STATUS5="0005";
	
	
	
	
	public static final String CON_IN="0";//终端入库状态码

	public static final String CON_OUT="2";//终端出库状态码
	
	public static final String OPERATION="1";
	
	public static final String TERM_UNNUM="0006";//非法数字
	public static final String TERM_BIND = "0007";//终端已经绑定商户
	public static final int TERM_SIZE = 16;//终端序列号长度
	public static final String TERM_ISBIND="10017";
	
	
	//固定编码模块
	public static final String QRCODE_STATUS1="4051";
	public static final String QRCODE_STATUS2="4061";
	public static final String QRCODE_UN="4062";//编码未入库
	public static final String QRCODE_Y="4063";//编码已经出过库
	public static final String QRCODE_UNNUM="4064";//非法数字
	public static final String QRCODE_IN="0";//入库
	public static final String QRCODE_B="1";//绑定商户
	public static final int QRCODE_SIZE = 8;//固码长度
	public static final String QRCODE_NO = "NO.";//固码编号
	public static final String QRCODE_LONG="4066";//Excel长度错误限制
	public static final int MAX_DOWNLOAD_SIZE = 10000;//最大下载条数

	//下载条数
	public static final int EXCEL_SIZE = 10000;
	
	/**
	 * 正则模块
	 */
	public static final String TERM_REGULAR="^[0-9]*$";

	public static final String ADD = "add";
	public static final String EDIT= "edit";

	public static final String Sk = "sk";
	public static final String SM = "sm";
	
	
	public static final String FEE_TYPE_DEBIT = "0";
	public static final String FEE_TYPE_CREDIT = "1"; 
	public static final String FEE_TYPE_WECHAT2 = "2"; 
	public static final String FEE_TYPE_ALIPAY2 = "3";
	public static final String FEE_TYPE_YLPAY = "4";
	public static final String FEE_TYPE_SHORTCUTSHD0 = "7";
	
	public static final String S0_FEE_TYPE_DEBIT = "5";
	public static final String S0_FEE_TYPE_CREDIT = "6";
	public static final String T1_FEE_TYPE_DEBIT = "7";
	public static final String T1_FEE_TYPE_CREDIT = "8";

	public static final String S0_CHANNEL_TYPE = "1001";
	public static final String D0_CHANNEL_TYPE = "2001";
	public static final String T1_CHANNEL_TYPE = "2002";

	public static final String SS_FEE_TYPE = "1001";

	public static final String SI_FEE_TYPE = "2001";

	public static final String T1_FEE_TYPE = "2002";

	public static final String basePath=DynamicConfigLoader.getByEnv("PATH");
	public static final String PHOTO_URL=DynamicConfigLoader.getByEnv("PHOTO_URL");
	public static final String UPDATE_PHOTO=DynamicConfigLoader.getByEnv("UPDATE_PHOTO_URL");
	public static final String IMAGE_GET_URL=DynamicConfigLoader.getByEnv("IMAGE_GET_URL");
	
	
	
}
