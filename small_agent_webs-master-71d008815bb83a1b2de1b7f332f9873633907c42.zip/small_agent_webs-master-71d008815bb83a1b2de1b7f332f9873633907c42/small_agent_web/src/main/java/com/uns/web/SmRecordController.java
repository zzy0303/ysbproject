package com.uns.web;

import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.model.Agent;
import com.uns.model.Users;
import com.uns.service.AgentService;
import com.uns.service.SmRecordService;
import com.uns.slx.common.mutidatasource.DataSourceSwitch;
import com.uns.util.ExcelUtils;
import com.uns.util.StringUtils;
import com.uns.web.form.SmRecordForm;
import com.uns.web.form.SplitForm;

/**
 * 扫码记录
 * @author yang.liu01
 *
 */
@Controller
@RequestMapping(value = "/smRecord.htm")
public class SmRecordController extends BaseController {
	@Autowired
	private SmRecordService smRecordService;
	@Autowired
	private AgentService agentservice;
	
	
	/**扫码记录查询(按查询条件查询)
	 * @param request
	 * @param response
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=findSmRecordListByParam")
	public String findSmRecordListByParam(HttpServletRequest request, HttpServletResponse response,
			SmRecordForm smRecordForm)throws Exception {
		try{
			String shopperid_p = request.getParameter("shopperid_p");
			String belongsAgent = request.getParameter("belongsAgent");
			Users  sessionUser=(Users)request.getSession().getAttribute(Constants.SESSION_KEY_USER); 
			//当前登录商
			Long merchantId =sessionUser.getMerchantid();
			
			
			if(StringUtils.isEmpty(shopperid_p)) {
				smRecordForm.setShopperidP(merchantId);
			}else{
				smRecordForm.setShopperidP(Long.valueOf(shopperid_p));
			}
			List<Map<String,Object>> listData = getListData(smRecordForm);
			request.setAttribute("smRecordForm",smRecordForm);
			request.setAttribute("shopperid_p", shopperid_p);
			request.setAttribute("belongsAgent", belongsAgent);
			request.setAttribute("list", listData);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"扫码记录查询错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		return "smRecord/smRecordList";
	}
	
	
	
	
	/**
	 * 扫码记录查询(默认按照当天查询)
	 * @author yang.liu01
	 * @param request
	 * @param response
	 * @param smRecordForm
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=findSmRecordList")
	public String findSmRecordList(HttpServletRequest request, HttpServletResponse response,
			SmRecordForm smRecordForm) throws Exception{
		try {
			Users  sessionUser=(Users)request.getSession().getAttribute(Constants.SESSION_KEY_USER); 
			//当前登录商
			Long merchantId = sessionUser==null?null:sessionUser.getMerchantid();
			smRecordForm.setShopperidP(merchantId);
			SimpleDateFormat sf=new SimpleDateFormat("yyyy-MM-dd");
			Date date=new Date();
			String startTimeWithdraw=sf.format(date);
			String endTimeWithdraw=sf.format(date);
			if(StringUtils.isEmpty(smRecordForm.getStartTimeWithdraw())){
				smRecordForm.setStartTimeWithdraw(startTimeWithdraw);
			}
			if(StringUtils.isEmpty(smRecordForm.getEndTimeWithdraw())){
				smRecordForm.setEndTimeWithdraw(endTimeWithdraw);
			}
			List<Map<String,Object>> listData = getListData(smRecordForm);
			request.setAttribute("smRecordForm",smRecordForm);
			request.setAttribute("list", listData);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.查询出错);
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		
		return "smRecord/smRecordList";
	}
	
	/**
	 * 封装查询数据
	 * @author yang.liu01
	 * @param  smRecordForm
	 * @return listData
	 */
	public List<Map<String,Object>> getListData(SmRecordForm smRecordForm) {
		//切换数据库 
		DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS_QRCODE.name());
		List<Map<String,Object>> listData = smRecordService.selectsmRecordList(smRecordForm);
		return listData;
	}
	
	@RequestMapping(params="method=findorgByShopperidP")
	public String findorgByShopperidP(HttpServletRequest request) throws BusinessException{
		try {
			//切换数据库
			//DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.U3_SMALL.name());
			Agent agent = (Agent)request.getSession().getAttribute("agent");
			String shopperId=agent.getShopperid()==null?"":agent.getShopperid().toString();
		    List list = agentservice.findAgentByMerchantId(shopperId);
		    Map mapReturn = new HashMap();
			//循环遍历所有功能，放入map中，key为parentId_Id (上级功能Id和Id)
		    
			for(int i=0;i<list.size();i++){
				agent = (Agent)list.get(i);
				String strParentId="1";
		
				if(agent.getShopperidP()!=null&&!shopperId.equals(agent.getShopperid().toString())){
					strParentId=agent.getShopperidP().toString();
				}
				String strId = String.valueOf(agent.getShopperid());         //角色编号
				String strKey = strParentId + "_" + strId;
				mapReturn.put(strKey, agent);
				
				request.setAttribute("mapTree", mapReturn);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.查询出错);
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		return "agent/agent_trees";
	}
	
	
	/**
	 * 下载
	 * @param request
	 * @param response
	 * @param sform
	 * @return
	 * @throws InvocationTargetException 
	 * @throws IllegalAccessException 
	 */
	@RequestMapping(params = "method=downSmRecordListPage")
	public String downSmRecordListPage(HttpServletRequest request, HttpServletResponse response,
			SmRecordForm smRecordForm) throws Exception{
		try{
			String shopperid_p = request.getParameter("shopperid_p");
			Page page  = new Page();
			page.setPageSize(Constants.EXCEL_SIZE);
			PageContext context = PageContext.getContext();
			BeanUtils.copyProperties(context, page);
			context.setPagination(true);
			Users  sessionUser=(Users)request.getSession().getAttribute(Constants.SESSION_KEY_USER); 
			//当前登录商
			Long merchantId = sessionUser==null?null:sessionUser.getMerchantid();
			if(StringUtils.isEmpty(shopperid_p)) {
				smRecordForm.setShopperidP(merchantId);
			}else{
				smRecordForm.setShopperidP(Long.valueOf(shopperid_p));
			}
			//切换数据库 
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS_QRCODE.name());
			smRecordService.downSmRecordList(smRecordForm);
			
			BeanUtils.copyProperties(page, context);
			request.setAttribute("mbForm",smRecordForm);
			request.setAttribute("page",page);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"下载出错"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}	    
		return "smRecord/smRecordListPage";
	}
	
	
	/**
	 * 导出Excel
	 * @param request
	 * @param response
	 * @param smRecordForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=downSmRecordEcxel")
	public String downSmRecordEcxel(HttpServletRequest request,HttpServletResponse response,SmRecordForm smRecordForm)
	  throws Exception{
	try{
		String shopperid_p = request.getParameter("shopperid_p");
		String tPage = request.getParameter("page");
		if (StringUtils.isEmpty(tPage) || !org.apache.commons.lang3.StringUtils.isNumeric(tPage)){
			tPage = "1";
		}
		int currentPage = Integer.valueOf(tPage);
		Page page  = new Page();
		page.setPageSize(Constants.EXCEL_SIZE);
		PageContext context = PageContext.getContext();
		BeanUtils.copyProperties(context, page);
		context.setPagination(true);
		context.setCurrentPage(currentPage);
		
		Users  sessionUser=(Users)request.getSession().getAttribute(Constants.SESSION_KEY_USER); 
		//当前登录商
		Long merchantId = sessionUser.getMerchantid();
		
		
		if(StringUtils.isEmpty(shopperid_p)) {
			smRecordForm.setShopperidP(merchantId);
		}else{
			smRecordForm.setShopperidP(Long.valueOf(shopperid_p));
		}
		//切换数据库 
		DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS_QRCODE.name());
		List<Map<String,Object>> listData = smRecordService.downSmRecordList(smRecordForm);
		BeanUtils.copyProperties(page, context);
		request.setAttribute("page",page);
		
		List<String> listHead = new ArrayList<String>();
		listHead.add("商户编号");
		listHead.add("商户名称");
		listHead.add("所属服务商");
		listHead.add("收款方式");
		listHead.add("结算方式");
		listHead.add("费率(%)");
		listHead.add("交易时间");
		listHead.add("交易金额");
		listHead.add("手续费");
		listHead.add("到账金额");
		listHead.add("订单号");
		listHead.add("是否B扫C");
		List<String> listKey = new ArrayList<String>();
		listKey.add("SMALL_MERCH_NO");
		listKey.add("SCOMPANY");
		listKey.add("AGENT_SCOMPANY");
		listKey.add("PAY_WAY");
		listKey.add("D0_FLAG");
		listKey.add("FEERATE");
		listKey.add("TRAN_DATE");
		listKey.add("AMOUNT");
		listKey.add("FEE");
		listKey.add("ARRIVAL_AMOUNT");
		listKey.add("ORDER_ID");
		listKey.add("TRAN_TYPE");
		try {
			ExcelUtils.downExcel(listData, listKey, listHead, "SM-RECORD", "扫码记录", response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	} catch (Exception e) {
		e.printStackTrace();
		throw new BusinessException(ExceptionDefine.其他错误,new String[]{"扫码导出错误"});
	}finally {
		DataSourceSwitch.clearDataSourceType();
	}
	    return null;
	}
	
	
	
	/**
	 * 商户扫码记录查询
	 * @param request
	 * @param response
	 * @param smRecordForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=findMerSmRecordList")
	public String findMerSmRecordList(HttpServletRequest request, HttpServletResponse response,
			SmRecordForm smRecordForm) throws Exception{
		try {
			String shopperid_p = request.getParameter("shopperid_p");
			String belongsAgent = request.getParameter("belongsAgent");
			
			Users  sessionUser=(Users)request.getSession().getAttribute(Constants.SESSION_KEY_USER); 
			//当前登录商
			Long merchantId = sessionUser==null?null:sessionUser.getMerchantid();
			smRecordForm.setShopperidP(merchantId);
			
			SimpleDateFormat sf=new SimpleDateFormat("yyyy-MM-dd");
			Date date=new Date();
			
			String startTimeWithdraw=sf.format(date);
			String endTimeWithdraw=sf.format(date);
			if(StringUtils.isEmpty(smRecordForm.getStartTimeWithdraw())&&StringUtils.isEmpty(smRecordForm.getEndTimeWithdraw())){
				smRecordForm.setStartTimeWithdraw(startTimeWithdraw);
				smRecordForm.setEndTimeWithdraw(endTimeWithdraw);
			}
			if(StringUtils.isEmpty(shopperid_p)) {
				smRecordForm.setShopperidP(merchantId);
			}else{
				smRecordForm.setShopperidP(Long.valueOf(shopperid_p));
			}
			
			
			//切换数据库 
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS_QRCODE.name());
			List<Map<String,Object>> listData = smRecordService.selectMersmRecordList(smRecordForm);
			
			request.setAttribute("smRecordForm",smRecordForm);
			request.setAttribute("shopperid_p", shopperid_p);
			request.setAttribute("belongsAgent", belongsAgent);
			request.setAttribute("list", listData);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.查询出错);
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		
		return "smRecord/merSmRecordList";
	}
	
	
	
	/**
	 * 商户扫码下载
	 * @param request
	 * @param response
	 * @param sform
	 * @return
	 * @throws InvocationTargetException 
	 * @throws IllegalAccessException 
	 */
	@RequestMapping(params = "method=downMerSmRecordListPage")
	public String downMerSmRecordListPage(HttpServletRequest request, HttpServletResponse response,
			SmRecordForm smRecordForm) throws Exception{
		try{
			String shopperid_p = request.getParameter("shopperid_p");
			Page page  = new Page();
			page.setPageSize(Constants.EXCEL_SIZE);
			PageContext context = PageContext.getContext();
			BeanUtils.copyProperties(context, page);
			context.setPagination(true);
			Users  sessionUser=(Users)request.getSession().getAttribute(Constants.SESSION_KEY_USER); 
			//当前登录商
			Long merchantId = sessionUser==null?null:sessionUser.getMerchantid();
			if(StringUtils.isEmpty(shopperid_p)) {
				smRecordForm.setShopperidP(merchantId);
			}else{
				smRecordForm.setShopperidP(Long.valueOf(shopperid_p));
			}
			//切换数据库 
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS_QRCODE.name());
			smRecordService.selectDownMerSmRecordList(smRecordForm);
			
			BeanUtils.copyProperties(page, context);
			request.setAttribute("mbForm",smRecordForm);
			request.setAttribute("page",page);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"下载出错"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}	    
		return "smRecord/merSmRecordListPage";
	}
	
	
	/**
	 * 商户扫码导出Excel
	 * @param request
	 * @param response
	 * @param smRecordForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=downMerSmRecordEcxel")
	public String downMerSmRecordEcxel(HttpServletRequest request,HttpServletResponse response,SmRecordForm smRecordForm)
	  throws Exception{
		try{
			String shopperid_p = request.getParameter("shopperid_p");
			String tPage = request.getParameter("page");
			if (StringUtils.isEmpty(tPage) || !org.apache.commons.lang3.StringUtils.isNumeric(tPage)){
				tPage = "1";
			}
			int currentPage = Integer.valueOf(tPage);
			Page page  = new Page();
			page.setPageSize(Constants.EXCEL_SIZE);
			PageContext context = PageContext.getContext();
			BeanUtils.copyProperties(context, page);
			context.setPagination(true);
			context.setCurrentPage(currentPage);
			
			Users  sessionUser=(Users)request.getSession().getAttribute(Constants.SESSION_KEY_USER); 
			//当前登录商
			Long merchantId = sessionUser.getMerchantid();
			
			
			if(StringUtils.isEmpty(shopperid_p)) {
				smRecordForm.setShopperidP(merchantId);
			}else{
				smRecordForm.setShopperidP(Long.valueOf(shopperid_p));
			}
			//切换数据库 
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS_QRCODE.name());
			List<Map<String,Object>> listData = smRecordService.selectDownMerSmRecordList(smRecordForm);
			BeanUtils.copyProperties(page, context);
			request.setAttribute("page",page);
			
			List<String> listHead = new ArrayList<String>();
			listHead.add("商户编号");
			listHead.add("商户名称");
			listHead.add("固码编号");
			listHead.add("所属服务商");
			listHead.add("收款方式");
			listHead.add("结算方式");
			listHead.add("费率(%)");
			listHead.add("交易时间");
			listHead.add("交易金额");
			listHead.add("手续费");
			listHead.add("到账金额");
			listHead.add("订单号");
			listHead.add("是否B扫C");
			List<String> listKey = new ArrayList<String>();
			listKey.add("SMALL_MERCH_NO");
			listKey.add("SCOMPANY");
			listKey.add("TERMINAL_ID");
			listKey.add("AGENT_SCOMPANY");
			listKey.add("PAY_WAY");
			listKey.add("D0_FLAG");
			listKey.add("FEERATE");
			listKey.add("TRAN_DATE");
			listKey.add("AMOUNT");
			listKey.add("FEE");
			listKey.add("ARRIVAL_AMOUNT");
			listKey.add("ORDER_ID");
			listKey.add("TRAN_TYPE");
			try {
				ExcelUtils.downExcel(listData, listKey, listHead, "MER_SM-RECORD", "商户扫码记录", response);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"商户扫码导出错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
	    return null;
	}
}
