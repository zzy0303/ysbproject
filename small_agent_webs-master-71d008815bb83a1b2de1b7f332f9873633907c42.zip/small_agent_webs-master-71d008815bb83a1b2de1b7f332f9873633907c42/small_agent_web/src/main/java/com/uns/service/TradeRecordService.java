package com.uns.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.dao.TradeRecordMapper;
import com.uns.model.TradeRecord;

@Service
public class TradeRecordService {
	@Autowired
	private TradeRecordMapper tradeRecordMapper;
	
	/**
	 * 插入交易记录
	 * @param record
	 */
	public void insertSelective(TradeRecord record){
		tradeRecordMapper.insertSelective(record);
	}
	
	/**
	 * 查询序列值 
	 */
	public int getOrderId(){
		return tradeRecordMapper.getMposOrderId();
	}
	
}
