package com.uns.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.uns.model.B2cShopperVal;

@Repository
public interface B2cShopperValMapper {

	void saveShopperVal(B2cShopperVal b2cShopperVal);

	List<B2cShopperVal> queryByParam(B2cShopperVal b2cShopperVal);

	void delByParam(@Param("shopperValId") Long b2cShopperValId);

	void editByParam(B2cShopperVal b2cShopperVal);
}
