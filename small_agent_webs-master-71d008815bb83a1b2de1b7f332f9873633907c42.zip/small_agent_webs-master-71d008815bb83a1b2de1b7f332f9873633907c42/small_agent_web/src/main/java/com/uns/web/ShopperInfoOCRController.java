package com.uns.web;


import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.model.*;
import com.uns.service.ShopPerbiService;
import com.uns.util.StringUtils;
import com.uns.web.form.ShopPerbiForm;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.OutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller("shopperInfoOCRController")
@RequestMapping("/shopperInfoOCR.htm")
public class ShopperInfoOCRController extends BaseController{

    @Autowired
    ShopPerbiService shopPerbiService;

    /**
     * 商户预约信息列表
     *
     * @param request
     * @param response
     * @param mbForm
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=shopperTempList")
    @FormToken(save = true)
    public String shopperTempList(HttpServletRequest request, HttpServletResponse response, ShopPerbiForm mbForm) throws Exception {

        try {

            //当前登陆服务商
            Users sessionUser = (Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
            mbForm.setAgentNo(Long.toString(sessionUser.getMerchantid()));

            if (sessionUser == null || StringUtils.isEmpty(Long.toString(sessionUser.getMerchantid()))) {
                throw new BusinessException(ExceptionDefine.商户查询失败);
            }
            //获取省
            List<Area> Provincial = shopPerbiService.searchProvince();

            //获取市
            List<Area> list = shopPerbiService.searchArea();

            //所属代理商
            request.setAttribute("belongsAgent", mbForm.getBelongsAgent());

            List<B2cShopperbiTemp> shopPerbilist = shopPerbiService.findShopperTempList(mbForm);
            request.setAttribute("Provincial", Provincial);
            request.setAttribute("area", list);

            request.setAttribute("shopPerbilist", shopPerbilist);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "shopperOCRnew/shopperTempList";
    }

    /**
     * 商户预约详情查询
     *
     * @param request
     * @param response
     * @param mbForm
     * @return
     */
    @RequestMapping(params = "method=shopperTempDetails")
    public String shopperTempDetails(HttpServletRequest request, HttpServletResponse response, ShopPerbiForm mbForm) {
        //获取shopperid
        String shopperid = mbForm.getShopperid();
        B2cShopperbiTemp b2cShopperbiTemp = null;
        try {
            if (StringUtils.isEmpty(shopperid)) {
                request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url", "shopperInfoOCR.htm?method=shopperTempList");
                return "/returnPage";
            } else {
                b2cShopperbiTemp = shopPerbiService.queryShopPerbi(shopperid);
            }
            // 行业类型
            List<B2cDict> cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
            //获取银行
            B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbiTemp.getAccountbankdictval());
            if (null != dicbank) {
                request.setAttribute("accountBankDictvalName", dicbank.getDict());
            }
            request.setAttribute("creditBankDictvalName", b2cShopperbiTemp.getCreditBankDictval());

            //获取服务商
            if (b2cShopperbiTemp != null) {
                //获取服务商
                Long shopperId = b2cShopperbiTemp.getShopperidP();
                if (shopperId != null) {
                    Agent agent = shopPerbiService.searchAgent(shopperId);
                    request.setAttribute("agentName", agent.getScompany());
                    request.setAttribute("agentId", agent.getShopperid());
                }
            }
            //获取证照信息
            Long photoid = b2cShopperbiTemp.getPhotoid();
            MposPhotoTmp photo = shopPerbiService.selectPhotoTmpById(photoid);

            // 手续费
            String shopperTel = null;
            if (b2cShopperbiTemp != null) {
                shopperTel = b2cShopperbiTemp.getStel();
                if (b2cShopperbiTemp != null && shopperTel == null) {
                    shopperTel = b2cShopperbiTemp.getStel();
                }
            }
            // 手续费，临时表
            MposMerchantFee s0creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_CREDIT, Constants.S0_CHANNEL_TYPE);
            MposMerchantFee s0debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_DEBIT, Constants.S0_CHANNEL_TYPE);

            MposMerchantFee d0creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_CREDIT, Constants.D0_CHANNEL_TYPE);
            MposMerchantFee d0debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_DEBIT, Constants.D0_CHANNEL_TYPE);

            MposMerchantFee t1creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_CREDIT, Constants.T1_CHANNEL_TYPE);
            MposMerchantFee t1debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_DEBIT, Constants.T1_CHANNEL_TYPE);

            MposMerchantFee weChatMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_WECHAT2);
            MposMerchantFee alipayMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_ALIPAY2);
            MposMerchantFee ylpayMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_YLPAY);

            MposMerchantFee shortCutMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.STATUS5);

            MposMerchantFee shortCutSHMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.STATUS7);
            MposMerchantFee b2cMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.STATUS6);
            request.setAttribute("shortCutSHMerchantFeeTemp", shortCutSHMerchantFeeTemp);
            request.setAttribute("s0creditMerchantFeeTemp", s0creditMerchantFeeTemp);
            request.setAttribute("s0debitMerchantFeeTemp", s0debitMerchantFeeTemp);

            request.setAttribute("d0creditMerchantFeeTemp", d0creditMerchantFeeTemp);
            request.setAttribute("d0debitMerchantFeeTemp", d0debitMerchantFeeTemp);

            request.setAttribute("t1creditMerchantFeeTemp", t1creditMerchantFeeTemp);
            request.setAttribute("t1debitMerchantFeeTemp", t1debitMerchantFeeTemp);

            request.setAttribute("weChatMerchantFeeTemp", weChatMerchantFeeTemp);
            request.setAttribute("alipayMerchantFeeTemp", alipayMerchantFeeTemp);
            request.setAttribute("ylpayMerchantFeeTemp", ylpayMerchantFeeTemp);

            request.setAttribute("shortCutMerchantFeeTemp", shortCutMerchantFeeTemp);
            request.setAttribute("b2cMerchantFeeTemp", b2cMerchantFeeTemp);
            // 手续费
            MposMerchantFee s0creditMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_CREDIT, Constants.S0_CHANNEL_TYPE);
            if (s0creditMerchantFee == null && shopperTel != null) {
                s0creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel, Constants.FEE_TYPE_CREDIT, Constants.S0_CHANNEL_TYPE);
            }
            MposMerchantFee s0debitMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_DEBIT, Constants.S0_CHANNEL_TYPE);
            if (s0debitMerchantFee == null && shopperTel != null) {
                s0debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel, Constants.FEE_TYPE_DEBIT, Constants.S0_CHANNEL_TYPE);
            }

            MposMerchantFee d0creditMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_CREDIT, Constants.D0_CHANNEL_TYPE);
            if (d0creditMerchantFee == null && shopperTel != null) {
                d0creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel, Constants.FEE_TYPE_CREDIT, Constants.D0_CHANNEL_TYPE);
            }
            MposMerchantFee d0debitMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_DEBIT, Constants.D0_CHANNEL_TYPE);
            if (d0debitMerchantFee == null && shopperTel != null) {
                d0debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel, Constants.FEE_TYPE_DEBIT, Constants.D0_CHANNEL_TYPE);
            }

            MposMerchantFee t1creditMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_CREDIT, Constants.T1_CHANNEL_TYPE);
            if (t1creditMerchantFee == null && shopperTel != null) {
                t1creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel, Constants.FEE_TYPE_CREDIT, Constants.T1_CHANNEL_TYPE);
            }
            MposMerchantFee t1debitMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_DEBIT, Constants.T1_CHANNEL_TYPE);
            if (t1debitMerchantFee == null && shopperTel != null) {
                t1debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel, Constants.FEE_TYPE_DEBIT, Constants.T1_CHANNEL_TYPE);
            }

            MposMerchantFee weChatMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_WECHAT2);
            if (weChatMerchantFee == null && shopperTel != null) {
                weChatMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel, Constants.FEE_TYPE_WECHAT);
            }
            MposMerchantFee alipayMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_ALIPAY2);
            if (alipayMerchantFee == null && shopperTel != null) {
                alipayMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel, Constants.FEE_TYPE_ALIPAY);
            }
            MposMerchantFee ylpayMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_YLPAY);
            if (ylpayMerchantFee == null && shopperTel != null) {
                ylpayMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel, Constants.FEE_TYPE_YLPAY);
            }

            MposMerchantFee b2cMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.STATUS6);

            MposMerchantFee shortCutMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.STATUS5);
            MposMerchantFee shortCutSHMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.STATUS7);

            request.setAttribute("shortCutMerchantFee", shortCutMerchantFee);
            /**
             * 10月19号添加
             */
            request.setAttribute("shortCutSHMerchantFee", shortCutSHMerchantFee);

            request.setAttribute("b2cMerchantFee", b2cMerchantFee);

            request.setAttribute("s0creditMerchantFee", s0creditMerchantFee);
            request.setAttribute("s0debitMerchantFee", s0debitMerchantFee);

            request.setAttribute("d0creditMerchantFee", d0creditMerchantFee);
            request.setAttribute("d0debitMerchantFee", d0debitMerchantFee);

            request.setAttribute("t1creditMerchantFee", t1creditMerchantFee);
            request.setAttribute("t1debitMerchantFee", t1debitMerchantFee);

            request.setAttribute("weChatMerchantFee", weChatMerchantFee);
            request.setAttribute("alipayMerchantFee", alipayMerchantFee);
            request.setAttribute("ylpayMerchantFee", ylpayMerchantFee);

            request.setAttribute("b2cShopperbi", b2cShopperbiTemp);
            request.setAttribute("cillinglist", cillinglist);
            request.setAttribute("photo", photo);
            request.setAttribute("image_get_url", Constants.IMAGE_GET_URL);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "shopperOCRnew/shopperTempDetails";
    }

    /**
     * 商户信息列表导出页面
     * @return
     */
    @RequestMapping(params = "method=shopperExportPage")
    public String shopperExportPage(HttpServletRequest request, ShopPerbiForm mbForm){
        try {

            //当前登陆服务商
            Users sessionUser = (Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
            mbForm.setAgentNo(Long.toString(sessionUser.getMerchantid()));

            if (sessionUser == null || StringUtils.isEmpty(Long.toString(sessionUser.getMerchantid()))) {
                throw new BusinessException(ExceptionDefine.商户查询失败);
            }
            Page page  = new Page();
            page.setPageSize(Constants.excel_size);
            PageContext context = PageContext.getContext();
            BeanUtils.copyProperties(context, page);
            context.setPagination(true);
            List<B2cShopperbiTemp> shopPerbilist = shopPerbiService.findShopperTempList(mbForm);
            BeanUtils.copyProperties(page, context);
            
            //所属代理商
            request.setAttribute("shopPerbilist", shopPerbilist);
            request.setAttribute("page", page);
            request.setAttribute("mbForm", mbForm);
            
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "shopperOCRnew/excelPage";
    }

    /**
     * 商户信息列表导出
     */
    @RequestMapping(params = "method=shopperExport")
    public String shopperExport(HttpServletRequest request,HttpServletResponse response, ModelMap modelMap,
                                      @ModelAttribute("mb") ShopPerbiForm mbForm) throws ParseException, BusinessException {
        try{
            //当前登陆服务商
            Users sessionUser = (Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
            mbForm.setAgentNo(Long.toString(sessionUser.getMerchantid()));

            if (sessionUser == null || StringUtils.isEmpty(Long.toString(sessionUser.getMerchantid()))) {
                throw new BusinessException(ExceptionDefine.商户查询失败);
            }

            Page page  = new Page();
            page.setPageSize(Constants.excel_size);
            PageContext context = PageContext.getContext();
            BeanUtils.copyProperties(context, page);
            context.setPagination(true);
            List<HashMap> shopPerbilist = shopPerbiService.findShopperTempExportList(mbForm);
            BeanUtils.copyProperties(page, context);

            //所属代理商
            request.setAttribute("shopPerbilist", shopPerbilist);
            request.setAttribute("page", page);
            request.setAttribute("mbForm", mbForm);

            outExcel(shopPerbilist,response,"merchant_info",shopPerbilist.size());
        }catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.商户查询失败);
        }
        return null;
    }

    /**导出excel
     */
    private void outExcel(List<HashMap> excelList, HttpServletResponse response,String fileNames,
                          int totalRows) throws Exception {
        SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        response.setContentType("application/vnd.ms-excel");
        response.setHeader("content-disposition", "attachment;filename="+new String(fileNames.getBytes("GBK"),"iso8859-1")+".xls");
        response.setCharacterEncoding("UTF-8");

        OutputStream os = response.getOutputStream();
        WritableWorkbook wwb=Workbook.createWorkbook(os);
        WritableSheet sheet0 = wwb.createSheet(fileNames,0);
        sheet0.addCell(new Label(0,0, "总记录数"));
        sheet0.addCell(new Label(1,0, String.valueOf(totalRows)));
        sheet0.addCell(new Label(0,1, "商户编号"));
        sheet0.addCell(new Label(1,1, "商户名称"));
        sheet0.addCell(new Label(2,1, "是否裂变商户"));
        sheet0.addCell(new Label(3,1, "所属代理商"));
        sheet0.addCell(new Label(4,1, "手机号"));
        sheet0.addCell(new Label(5,1, "修改时间"));
        sheet0.addCell(new Label(6,1, "所在地区"));
        sheet0.addCell(new Label(7,1, "激活状态"));
        sheet0.addCell(new Label(8,1, "激活时间"));
        sheet0.addCell(new Label(9,1, "注册时间"));
        sheet0.addCell(new Label(10,1, "审核状态"));
        sheet0.addCell(new Label(11,1, "审核时间"));
        sheet0.addCell(new Label(12,1, "商户来源"));

        for (int i = 0; i < excelList.size(); i++) {
            //转换成map集合{activyName:测试功能,count:2}  
            Map<String,String> info = excelList.get(i);
            //循环输出map中的子集：既列值  
            String address = info.get("SPROVINCE")==null?"":String.valueOf(info.get("SPROVINCE")) + "," ;
            String city = info.get("SCITY")==null?"":String.valueOf(info.get("SCITY"));
            sheet0.addCell(new Label(0,i+2, info.get("SHOPPERID")==null?"":String.valueOf(info.get("SHOPPERID"))));
            sheet0.addCell(new Label(1,i+2, info.get("SCOMPANY")));
            sheet0.addCell(new Label(2,i+2, info.get("HAVEINVITECODEP")));
            sheet0.addCell(new Label(3,i+2, info.get("AGENTNAME")));
            sheet0.addCell(new Label(4,i+2, info.get("STEL")));
            sheet0.addCell(new Label(5,i+2, info.get("UPDATED")));
            sheet0.addCell(new Label(6,i+2, info.get("SPROVINCE") + " " + info.get("SCITY")));
            sheet0.addCell(new Label(7,i+2, info.get("IFACTIVATED")));
            sheet0.addCell(new Label(8,i+2, info.get("IFACTIVADATE")));
            sheet0.addCell(new Label(9,i+2, info.get("CREATED")));
            sheet0.addCell(new Label(10,i+2, info.get("CHECKSTATUS")));
            sheet0.addCell(new Label(11,i+2, info.get("RECHECK_DATE")==null?"":info.get("RECHECK_DATE")));
            sheet0.addCell(new Label(12,i+2, info.get("REPORT_RESOURCE")==null?"":info.get("REPORT_RESOURCE")));
        }
        //写入Exel工作表  
        wwb.write();
        //关闭Excel工作薄对象   
        wwb.close();
        //关闭流  
        os.flush();
        os.close();

        os =null;

    }
    
}
