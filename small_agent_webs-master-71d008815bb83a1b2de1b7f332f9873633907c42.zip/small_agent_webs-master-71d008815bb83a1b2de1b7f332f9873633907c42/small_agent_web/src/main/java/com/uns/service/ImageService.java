package com.uns.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.dao.ImageMapper;
import com.uns.model.Image;

@Service
public class ImageService {

	
	@Autowired
	private ImageMapper ImageMapper;

	public void insertSelective(Image image) {
		ImageMapper.insert(image);
	}

	public Image getImageByName(String targetFileName) {
		return ImageMapper.getImageByName(targetFileName);
	}
	
	
}
