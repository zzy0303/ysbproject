package com.uns.web.form;

public class MposRemoteInvitationForm {
	
	private String tels;
	private String statuss;
	private String startTime;
	private String endTime;
	private String salesmans;
	private String startpastdate;
	private String endpastdate;
	
	public String getStartpastdate() {
		return startpastdate;
	}
	public void setStartpastdate(String startpastdate) {
		this.startpastdate = startpastdate;
	}
	public String getEndpastdate() {
		return endpastdate;
	}
	public void setEndpastdate(String endpastdate) {
		this.endpastdate = endpastdate;
	}
	public String getTels() {
		return tels;
	}
	public void setTels(String tels) {
		this.tels = tels;
	}
	public String getStatuss() {
		return statuss;
	}
	public void setStatuss(String statuss) {
		this.statuss = statuss;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getSalesmans() {
		return salesmans;
	}
	public void setSalesmans(String salesmans) {
		this.salesmans = salesmans;
	}

}
