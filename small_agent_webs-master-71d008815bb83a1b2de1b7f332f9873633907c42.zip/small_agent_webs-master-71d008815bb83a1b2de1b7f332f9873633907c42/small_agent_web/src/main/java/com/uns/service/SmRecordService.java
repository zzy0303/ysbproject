package com.uns.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.common.page.PageContext;
import com.uns.dao.SmRecordMapper;
import com.uns.web.form.SmRecordForm;

@Service
public class SmRecordService {
	@Autowired
	private SmRecordMapper smRecordMapper;
	
	/**
	 * 扫码记录查询
	 * @author yang.liu01
	 * @param smRecordForm
	 * @return
	 */
	public List<Map<String, Object>>  selectsmRecordList(SmRecordForm smRecordForm){
		PageContext.initPageSize(20);
		return smRecordMapper.selectRecordList(smRecordForm);
	}
	/**
	 * 费率相关信息
	 * @author yang.liu01
	 * @param shopperid
	 * @return
	 */
	public List<Map<String, Object>> selectAgentFeeForQrcode(String shopperid) {
		return smRecordMapper.selectAgentFeeForQrcode(shopperid);
	}
	/**
	 * 下载扫码记录
	 * @param smRecordForm
	 * @return
	 */
	public  List<Map<String,Object>> downSmRecordList(SmRecordForm smRecordForm) {
		PageContext.initPageSize(Constants.EXCEL_SIZE);
		return smRecordMapper.downSmRecordList(smRecordForm);
		
	}
	/**
	 * 商户扫码记录
	 * @param smRecordForm
	 * @return
	 */
	public List<Map<String, Object>>  selectMersmRecordList(SmRecordForm smRecordForm){
		PageContext.initPageSize(20);
		return smRecordMapper.selectMersmRecordList(smRecordForm);
	}
	/**
	 * 下载商户扫码记录
	 * @param smRecordForm
	 * @return
	 */
	public  List<Map<String,Object>> selectDownMerSmRecordList(SmRecordForm smRecordForm) {
		PageContext.initPageSize(Constants.EXCEL_SIZE);
		return smRecordMapper.selectDownMerSmRecordList(smRecordForm);
		
	}
	
}
