package com.uns.web;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.service.QrCodeService;
import com.uns.util.StringUtils;

@Controller
@RequestMapping(value="/qrCodeController.htm")
public class QrCodeController extends BaseController{
	
	@Autowired
	private QrCodeService qrCodeService;

	@RequestMapping(params = "method=queryQrCodeInfo")
	public void queryQrCodeInfo(HttpServletRequest request, HttpServletResponse response){
		try {
			response.setContentType("UTF-8");
			Map<String, Object> resultMap = new HashMap<String, Object>();
			//判断参数是否为空
			String shopperid = request.getParameter("merchantId");
			if(!StringUtils.isEmpty(shopperid)){
			log.info("获取的商户号参数:" + shopperid);
			//根据shopperid查询 QRPAYNO,QRPAY_MERCHANT_KEY
			resultMap = qrCodeService.queryQrCodeInfoByShopperId(shopperid);
			if (resultMap!=null) {
				resultMap.put("rspCode", Constants.SUCCESS_CODE);
				resultMap.put("rspMsg", Constants.QUERY_SUCCEEDED);
			}else{
				resultMap = new HashMap<String, Object>();
				resultMap.put("rspCode", Constants.NO_RETURN_RESULTS_CODE);
				resultMap.put("rspMsg", Constants.NO_RETURN_RESULTS);
			}
			}else{
				log.info("参数商户号为空");
				resultMap.put("rspCode", Constants.LOSE_PARAMETER_CODE);
				resultMap.put("rspMsg", Constants.LOSE_PARAMETER);
			}
			JSONObject json = JSONObject.fromObject(resultMap);
			log.info("返回的扫码信息：" + json.toString());
			response.getWriter().write(json.toString());
		} catch (Exception e) {
		}
	}
	
}
