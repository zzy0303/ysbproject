package com.uns.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.page.PageContext;
import com.uns.dao.AgentSplitBatchMapper;
import com.uns.dao.AgentSplitProfitMapper;
import com.uns.util.HttpClientUtils;
import com.uns.web.form.SplitForm;

import net.sf.json.JSONObject;

@Service
public class AgentFissionFeeSplitService extends BaseService{
	
	@Autowired
	private AgentSplitBatchMapper agentSplitBatchMapper;
	
	@Autowired
	private AgentSplitProfitMapper agentSplitProfitMapper;

	public List<Map<String, Object>> findAgentFissionFeeSpList(SplitForm sform) {
		PageContext.initPageSize(20);
		return agentSplitBatchMapper.findAgentFissionFeeSpList(sform);
	}

	public List<Map<String, Object>> selectAgentFee(String shopperid,String trantype) {
		Map paramMap=new HashMap();
		paramMap.put("shopperid", shopperid);
		paramMap.put("trantype", trantype);
		return  agentSplitBatchMapper.selectAgentFee(paramMap);
	}

	public List<Map<String, Object>> downAgentFissionSplitList(SplitForm sform) {
		PageContext.initPageSize(Constants.EXCEL_SIZE);
		return agentSplitBatchMapper.findAgentFissionFeeSpList(sform);
	}

	public void batchUpdateAgFissFee(String status, List<String> list) {
		for(int i=0;i<list.size();i++){		
			String batchNo=(String)list.get(i);
				Map map=new HashMap();
				map.put("status", status);
				map.put("batchNo", batchNo);
				agentSplitBatchMapper.updateAgentProfitFissStatus(map);
			}
		}

}
