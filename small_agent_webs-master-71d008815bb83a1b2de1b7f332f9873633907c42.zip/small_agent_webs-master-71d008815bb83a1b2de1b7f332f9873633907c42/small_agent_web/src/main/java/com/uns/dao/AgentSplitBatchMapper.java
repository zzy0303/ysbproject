package com.uns.dao;

import com.uns.model.AgentSplitBatch;
import com.uns.web.form.SplitForm;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;
@Repository
public interface AgentSplitBatchMapper {
    int deleteByPrimaryKey(BigDecimal id);

    AgentSplitBatch selectByPrimaryKey(BigDecimal id);

    List<Map<String,Object>> selectBatchList(SplitForm param);
    
    List<Map<String,Object>> selectSubBatchList(SplitForm param);
    
    void updateStatusByBatchNo(SplitForm param);
    
    Map<String,Object> selectDoubt(SplitForm param);
    
    void updateDoubt(SplitForm param);
    
    void updateBatch(SplitForm param);
    
    AgentSplitBatch selectByPrimaryKey(SplitForm param);
    
    void batchUpdate(Map<String,Object> param);
    
    void updateBatchSplitSm(Map<String,Object> param);
    
    void insertDoubt(SplitForm param);

	List<Map<String, Object>> selectSmBatchList(SplitForm sform);

	List<Map<String, Object>> selectSmSubBatchList(SplitForm param);

	void updateSmStatusByBatchNo(SplitForm param);

	void updateSmBatch(SplitForm param);

	void smBatchUpdate(Map<String, Object> param);
	
	List<Map<String, Object>> selectProfitConfirmationList(SplitForm param);

	void updateSplitAgentStatus(Map<String, Object> map);

	List<Map<String, Object>> selectBatchNewList(SplitForm param);

	List<Map<String, Object>> selectSubBatchNewList(SplitForm param);

	List<Map<String, Object>> findAgentFissionFeeSpList(SplitForm sform);

	List<Map<String, Object>> selectAgentFee(Map paramMap);

	void updateAgentProfitFissStatus(Map map);
}