package com.uns.web.form;

import java.util.Date;

public class AgentRechargeForm {
   private String merchantId;
   private String minAmount;
   private String maxAmount;
   private int status;
   private Long shopperid_p;
   
   private String startTime;
   private String endTime;
  
   private Date startDate;
   private Date endDate;
   private String chargechannel;//通道类型
 
public String getMerchantId() {
	return merchantId;
}
public void setMerchantId(String merchantId) {
	this.merchantId = merchantId;
}
public String getMinAmount() {
	return minAmount;
}
public void setMinAmount(String minAmount) {
	this.minAmount = minAmount;
}
public String getMaxAmount() {
	return maxAmount;
}
public void setMaxAmount(String maxAmount) {
	this.maxAmount = maxAmount;
}

public int getStatus() {
	return status;
}
public void setStatus(int status) {
	this.status = status;
}
public Long getShopperid_p() {
	return shopperid_p;
}
public void setShopperid_p(Long shopperid_p) {
	this.shopperid_p = shopperid_p;
}
public String getStartTime() {
	return startTime;
}
public void setStartTime(String startTime) {
	this.startTime = startTime == null ? null : startTime.trim();
}
public String getEndTime() {
	return endTime;
}
public void setEndTime(String endTime) {
	this.endTime = endTime == null ? null : endTime.trim();
}
public Date getStartDate() {
	return startDate;
}
public void setStartDate(Date startDate) {
	this.startDate = startDate;
}
public Date getEndDate() {
	return endDate;
}
public void setEndDate(Date endDate) {
	this.endDate = endDate;
}
public String getChargechannel() {
	return chargechannel;
}
public void setChargechannel(String chargechannel) {
	this.chargechannel = chargechannel;
}





}
