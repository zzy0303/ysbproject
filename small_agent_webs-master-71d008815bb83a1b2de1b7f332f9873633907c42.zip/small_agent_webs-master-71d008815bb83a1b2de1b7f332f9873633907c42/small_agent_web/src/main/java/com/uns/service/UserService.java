package com.uns.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.dao.B2cShopperbiTempMapper;
import com.uns.dao.UsersMapper;
import com.uns.model.B2cShopperbi;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.Users;
import com.uns.util.Md5Encrypt;


@Service
public class UserService {
	@Autowired
	private UsersMapper usersmapper;
	
	@Autowired
	private B2cShopperbiTempMapper shoppermapper;
	
	public Users  findbytel(String tel){
		return usersmapper.findbytel(tel);
	}
	
	public Users  findbytelm(String tel){
		return usersmapper.findbytelm(tel);
	}
	
	public void updatepassword(Users user,B2cShopperbiTemp shoppertemp,String password){
		String mpassword=Md5Encrypt.md5(password);
		if(user!=null){
			user.setPassword(mpassword);
			usersmapper.updateByUsresId(user);
		}
		shoppertemp.setMpassword(mpassword);
		shoppermapper.updateByPrimaryKeySelective(shoppertemp);
		
	}

	public void updateUserPwd(Users users, String password) throws Exception {
		String mpassword=Md5Encrypt.md5(password);
		users.setPassword(mpassword);
		usersmapper.updateByUsresId(users);
	}
}
