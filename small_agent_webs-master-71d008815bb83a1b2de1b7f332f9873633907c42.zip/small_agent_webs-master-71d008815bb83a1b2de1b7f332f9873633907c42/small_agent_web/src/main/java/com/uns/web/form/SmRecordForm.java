package com.uns.web.form;

import java.util.Date;

public class SmRecordForm {

	private String shopperid;//商户编号
	private String scompany;//商户名称
	private String agentScompany;//所属服务商
	private String payWay;//收款方式
	private String d0Flag;//结算方式
	private Date tranDate;//交易时间
	private String amount;//交易金额
	private String fee;//手续费
	private String arrivalAmount;//到账金额
	private String orderId;//订单编号
	private String feeRate;//费率
	private String srcId;//服务商编号
	private String startTimeWithdraw;//提现开始时间
	private String endTimeWithdraw;//提现结束时间
	private String oramountStart;
	private String oramountEnd;
	private Long shopperidP;
	
	
	public String getShopperid() {
		return shopperid;
	}
	public void setShopperid(String shopperid) {
		this.shopperid = shopperid;
	}
	public String getScompany() {
		return scompany;
	}
	public void setScompany(String scompany) {
		this.scompany = scompany;
	}
	public String getAgentScompany() {
		return agentScompany;
	}
	public void setAgentScompany(String agentScompany) {
		this.agentScompany = agentScompany;
	}
	public String getPayWay() {
		return payWay;
	}
	public void setPayWay(String payWay) {
		this.payWay = payWay;
	}
	public String getD0Flag() {
		return d0Flag;
	}
	public void setD0Flag(String d0Flag) {
		this.d0Flag = d0Flag;
	}
	
	public Date getTranDate() {
		return tranDate;
	}
	public void setTranDate(Date tranDate) {
		this.tranDate = tranDate;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getFee() {
		return fee;
	}
	public void setFee(String fee) {
		this.fee = fee;
	}
	public String getArrivalAmount() {
		return arrivalAmount;
	}
	public void setArrivalAmount(String arrivalAmount) {
		this.arrivalAmount = arrivalAmount;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getFeeRate() {
		return feeRate;
	}
	public void setFeeRate(String feeRate) {
		this.feeRate = feeRate;
	}
	public String getSrcId() {
		return srcId;
	}
	public void setSrcId(String srcId) {
		this.srcId = srcId;
	}
	public String getStartTimeWithdraw() {
		return startTimeWithdraw;
	}
	public void setStartTimeWithdraw(String startTimeWithdraw) {
		this.startTimeWithdraw = startTimeWithdraw;
	}
	public String getEndTimeWithdraw() {
		return endTimeWithdraw;
	}
	public void setEndTimeWithdraw(String endTimeWithdraw) {
		this.endTimeWithdraw = endTimeWithdraw;
	}
	public String getOramountStart() {
		return oramountStart;
	}
	public void setOramountStart(String oramountStart) {
		this.oramountStart = oramountStart;
	}
	public String getOramountEnd() {
		return oramountEnd;
	}
	public void setOramountEnd(String oramountEnd) {
		this.oramountEnd = oramountEnd;
	}
	public Long getShopperidP() {
		return shopperidP;
	}
	public void setShopperidP(Long shopperidP) {
		this.shopperidP = shopperidP;
	}
	
	
	
	
	
	
	
	
	
}
