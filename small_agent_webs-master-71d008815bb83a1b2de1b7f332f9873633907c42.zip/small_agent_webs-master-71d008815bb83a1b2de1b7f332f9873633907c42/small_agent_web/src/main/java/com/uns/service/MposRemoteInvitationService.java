package com.uns.service;

import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.dao.AgentMapper;
import com.uns.dao.MposRemoteFeeMapper;
import com.uns.dao.MposRemoteInvitationMapper;
import com.uns.dao.UsersMapper;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.model.Agent;
import com.uns.model.MposRemoteFee;
import com.uns.model.MposRemoteInvitation;
import com.uns.model.Users;
import com.uns.util.DateUtil;
import com.uns.util.ToolsUtils;
import com.uns.web.form.MposRemoteInvitationForm;

@Service("mposRemoteInvitationService")
public class MposRemoteInvitationService {

	@Autowired
	private MposRemoteInvitationMapper  mposRemoteInvitationMapper;
	@Autowired
	private AgentMapper  agentMapper;
	
	@Autowired
	private UsersMapper usersMapper;
	
	@Autowired
	private MposRemoteFeeMapper  mposRemoteFeeMapper;
	
	String SMS_CONTENT=DynamicConfigLoader.getByEnv("SMS_CONTENT");

	
	/**
	 * 将已邀请单未提交注册申请的记录，按照过期时间设置成已过期
	 */
	public void updateData() throws Exception{
		SimpleDateFormat sf = new SimpleDateFormat(Constants.DEFAULT_DATE_FORMAT);
		
		HashMap map=new HashMap();
		map.put("status", Constants.CON_YES);
		map.put("statuss",Constants.PAST_STATUS);
		map.put("updateDate", new Date());
		map.put("pastDate", sf.format(new Date()));
		mposRemoteInvitationMapper.updateData(map);
	}
	
	
	
	/**查询当前记录
	 * @param mbform
	 * @return
	 */
	public List findMposRemoteInvitationList(MposRemoteInvitationForm mbform) {
		PageContext.initPageSize(Constants.page_size);
		return mposRemoteInvitationMapper.findMposRemoteInvitationList(mbform);
	}
	
	
	
	private void insertMposRemoteFee(MposRemoteInvitation mposRemoteInvitation,
			HttpServletRequest request) {
		String debitfeeT1=request.getParameter("debitfeeT1");
		String creditfeeT1=request.getParameter("creditfeeT1");
		
		String weChatfeeT1=request.getParameter("weChatfeeT1");
		String weChatfeeD0=request.getParameter("weChatfeeD0");
		String aliPayfeeT1=request.getParameter("aliPayfeeT1");
		String aliPayfeeD0=request.getParameter("aliPayfeeD0");
		
		
		MposRemoteFee mposDebitfee=new MposRemoteFee();
		mposDebitfee.setTel(mposRemoteInvitation.getTel());
		mposDebitfee.setFeetype(Constants.CON_NO);//借记卡
		mposDebitfee.setFee(debitfeeT1);
		mposDebitfee.setCreateDate(new Date());
		mposDebitfee.setStatus(Constants.CON_YES);
		mposDebitfee.setD0fee(ToolsUtils.div(Double.parseDouble(mposRemoteInvitation.getT0Fee()), 1, 4)+"");

		MposRemoteFee mposCreditFee=new MposRemoteFee();
		mposCreditFee.setTel(mposRemoteInvitation.getTel());
		mposCreditFee.setFeetype(Constants.CON_YES);//贷记卡
		mposCreditFee.setFee(creditfeeT1);
		mposCreditFee.setCreateDate(new Date());
		mposCreditFee.setStatus(Constants.CON_YES);
		mposCreditFee.setD0fee(ToolsUtils.div(Double.parseDouble(mposRemoteInvitation.getT0Fee()), 1, 4)+"");
		
		MposRemoteFee mweChatfee=new MposRemoteFee();
		mweChatfee.setTel(mposRemoteInvitation.getTel());
		mweChatfee.setFeetype(Constants.STATUS2);//
		mweChatfee.setFee(weChatfeeT1);
		mweChatfee.setCreateDate(new Date());
		mweChatfee.setStatus(Constants.CON_YES);
		mweChatfee.setD0fee(ToolsUtils.div(Double.parseDouble(weChatfeeD0), 1, 4)+"");
			
		MposRemoteFee mposAliPayFee=new MposRemoteFee();
		mposAliPayFee.setTel(mposRemoteInvitation.getTel());
		mposAliPayFee.setFeetype(Constants.STATUS3);//借记卡
		mposAliPayFee.setFee(aliPayfeeT1);
		mposAliPayFee.setCreateDate(new Date());
		mposAliPayFee.setStatus(Constants.CON_YES);
		mposAliPayFee.setD0fee(ToolsUtils.div(Double.parseDouble(aliPayfeeD0), 1, 4)+"");
		
		mposRemoteFeeMapper.insertSelective(mposDebitfee);
		
		mposCreditFee.setId(mposDebitfee.getId());
		mposRemoteFeeMapper.insert(mposCreditFee);
		
		mweChatfee.setId(mposDebitfee.getId());
		mposRemoteFeeMapper.insert(mweChatfee);
		
		mposAliPayFee.setId(mposDebitfee.getId());
		mposRemoteFeeMapper.insert(mposAliPayFee);
		
	}






	
	
	
	/**
	 * @param smsContent
	 * @param params
	 * @param mposRemote
	 * @return
	 */
	private String getContent(String smsContent, Map<String, String> params, MposRemoteInvitation mposRemote) {
		Map map=getMposRemoteInvitationValues(mposRemote);
		return this.replaceValues(smsContent, map);
	}

	private String getContentapp(String smsContent, Map<String, String> params, MposRemoteInvitation mposRemote) {
		Map map=getMposRemoteInvitationValuesapp(mposRemote);
		return this.replaceValues(smsContent, map);
	}
	/**
	 * @param mposremote
	 * @return
	 */
	private Map<String, String> getMposRemoteInvitationValues(MposRemoteInvitation mposremote) {

		Map<String, String> map = new HashMap<String, String>();
		Users user=usersMapper.selectByPrimaryId(mposremote.getSalesman()==null?"":mposremote.getSalesman().toString());
		map.put("${salesman}", user.getUserName() + "");
		map.put("${pastDate}", DateUtil.date2String(mposremote.getPastDate() , "yyyy-MM-dd HH:mm:ss")+ "");
		map.put("${agenttel}",user.getTel()+ "");
		map.put("${password}",mposremote.getPassword());
		return map;
	}

	
	private Map<String, String> getMposRemoteInvitationValuesapp(MposRemoteInvitation mposremote) {

		Map<String, String> map = new HashMap<String, String>();
		Users user=usersMapper.selectUsersByAgentNo(mposremote.getAgentId()==null?"":mposremote.getAgentId().toString());
		map.put("${salesman}", user.getUserName() + "");
		map.put("${pastDate}", DateUtil.date2String(mposremote.getPastDate() , "yyyy-MM-dd HH:mm:ss")+ "");
		map.put("${agenttel}",user.getTel()+ "");
		map.put("${password}",mposremote.getPassword());
		return map;
	}
	
	private String replaceValues(String mailContent, Map<String, String> values) {
		Set<String> set = values.keySet();
		for (String key : set){
			if(key.indexOf("${") != -1)
				mailContent = mailContent.replace(key, values.get(key) + "");
		}
		return mailContent;
	}
	public MposRemoteInvitation findMposRemoteInvitationById(Long remoteInvitationId) {
		return mposRemoteInvitationMapper.selectByPrimaryKey(remoteInvitationId);
	}
	/**根据tel获取记录
	 * @param tel
	 * @return
	 */
	public List findMposRemoteInvitationByTel(String tel) {
		HashMap map=new HashMap();
		map.put("tel", tel);
		map.put("status", Constants.CON_YES);
		return mposRemoteInvitationMapper.findMposRemoteInvitationByTel(map);
	}

	
	

	/**
	 * 修改MposRemoteInvitation 
	 */
	public void update(MposRemoteInvitation mposRemoteInvitation) {
		mposRemoteInvitationMapper.updateByPrimaryKeySelective(mposRemoteInvitation);
	}
	
	
	/**
	 * 撤回
	 */
	public void recall(MposRemoteInvitation mposRemoteInvitation) {
		mposRemoteInvitation.setUpdateDate(new Date());
		mposRemoteInvitation.setStatus(Constants.REPEAL);
		mposRemoteFeeMapper.delfee(mposRemoteInvitation.getTel());
		update(mposRemoteInvitation);
	}
	public void recallapp(MposRemoteInvitation mposRemoteInvitation,String tel) {
		mposRemoteInvitation.setUpdateDate(new Date());
		mposRemoteInvitation.setStatus(Constants.REPEAL);
		mposRemoteFeeMapper.delfee(tel);
		update(mposRemoteInvitation);
	}
	
	public MposRemoteInvitation findbytel(String tel){
		List list=mposRemoteInvitationMapper.findbytel(tel);
		MposRemoteInvitation remote=null;
		if(list!=null&&list.size()>0){
			remote=(MposRemoteInvitation)list.get(0);
		}
		return remote;  
		
	}
	
	public MposRemoteInvitation findbytelstauts(String tel){
		List list= mposRemoteInvitationMapper.findbytelstauts(tel);
		MposRemoteInvitation remote=null;
		if(list!=null&&list.size()>0){
			remote=(MposRemoteInvitation)list.get(0);
		}
		return remote;
	}
	
	public Agent findbyagent(String agentid){
		Agent agent=agentMapper.searchAgentByShopperid(agentid);
		return agent;  
		
	}



	public List findmposAgent(Long merchantid) {
		return usersMapper.findmposAgent(merchantid);
	}
	

	
	public Map findHisTranList(String agentid, String tPage, HttpServletRequest request) throws IllegalAccessException, InvocationTargetException {
		if (StringUtils.isEmpty(tPage) || !StringUtils.isNumeric(tPage)){
			tPage = "1";
		}
		int currentPage = Integer.valueOf(tPage);
		Page page  = new Page();

		PageContext context = PageContext.getContext();
		page.setCurrentPage(currentPage);
		BeanUtils.copyProperties(context, page);
		context.setPageSize(Constants.page_size);
		context.setPagination(true);
		
		
		List list=mposRemoteInvitationMapper.findbyagentList(agentid);
		
		Map map=new HashMap();
		map.put("list", list);
		map.put("page", context.getCurrentPage());
		map.put("pages",context.getTotalPages());
		map.put("count",context.getTotalRows());
		return map;
	}
    
	
	public MposRemoteInvitation selectByPrimaryKey(Long id) {
		return mposRemoteInvitationMapper.selectByPrimaryKey(id);
	}




}
