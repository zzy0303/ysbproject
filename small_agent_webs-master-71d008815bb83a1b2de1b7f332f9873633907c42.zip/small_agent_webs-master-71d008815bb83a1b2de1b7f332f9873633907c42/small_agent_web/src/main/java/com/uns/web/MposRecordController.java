package com.uns.web;

import java.io.OutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.model.Agent;
import com.uns.model.B2cShopperbi;
import com.uns.service.RecordService;
import com.uns.service.ShopPerbiService;
import com.uns.slx.common.mutidatasource.DataSourceSwitch;
import com.uns.util.DateUtil;
import com.uns.util.ExcelUtils;
import com.uns.util.Md5Encrypt;
import com.uns.web.form.MposRecordForm;

import jxl.SheetSettings;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

@Controller
@RequestMapping(value = "/mposRecordController.htm")
public class MposRecordController  extends BaseController{
	
	@Autowired
	private RecordService recordService;
	
	@Autowired
	private ShopPerbiService shopPerbiService;
	
	@InitBinder
    public void initBinder(HttpServletRequest request, ServletRequestDataBinder binder) throws Exception {
        binder.registerCustomEditor(Date.class, new CustomDateEditor(new SimpleDateFormat("yyyy-MM-dd"), true));
    }
	
	SimpleDateFormat sf = new SimpleDateFormat("yyyyMMddHHmmss");
	SimpleDateFormat sf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	SimpleDateFormat sf2 = new SimpleDateFormat("yyyy-MM-dd");
	SimpleDateFormat sf3 = new SimpleDateFormat("yyyyMMdd");
	
	/**
	 * 充值记录查询
	 * @throws BusinessException 
	 * @throws ParseException 
	 */
	@RequestMapping(params = "method=rechargeList1")
	public String rechargeList1(HttpServletRequest request,HttpServletResponse response,MposRecordForm mposRecForm) 
			throws BusinessException, ParseException {
		try {
			request.setAttribute("startTime", mposRecForm.getStartTime()==null?null:sf2.format(mposRecForm.getStartTime()));
			request.setAttribute("endTime", mposRecForm.getEndTime()==null?null:sf2.format(mposRecForm.getEndTime()));
			
			Agent agent = (Agent)request.getSession().getAttribute("agent");
			if(agent==null){
				throw new BusinessException(ExceptionDefine.session过期请重新登录);
			}
			Long shopperidp=agent.getShopperid();
			
			if(!val(mposRecForm.getMerchantId())){
				Map<String , Object> paramMap =  new HashMap<String, Object>();
				paramMap.put("shopperid", mposRecForm.getMerchantId());
				if(val(mposRecForm.getShopperid_p())){
					paramMap.put("shopperidp", shopperidp);
				}else{
					paramMap.put("shopperidp", mposRecForm.getShopperid_p());
				}
				try {
					List<B2cShopperbi> shopperbiList = shopPerbiService.judgeShopper(paramMap);
					if(shopperbiList.size()<=0){
						request.setAttribute("mposRecForm", mposRecForm);
						request.setAttribute("rspMsg","没有查到此商户。" );
						return "mpos/rechargeList";
					}
				} catch (Exception e) {
					e.printStackTrace();
					request.setAttribute("mposRecForm", mposRecForm);
					request.setAttribute("rspMsg","没有查到此商户。" );
					return "mpos/rechargeList";
				}
				
				
			}
		    
			Map<String, Object> qp = new HashMap<String, Object>();		
			qp.put("startDate", mposRecForm.getStartTime()==null?null:sf.format(mposRecForm.getStartTime()));
			qp.put("endDate", valDate(mposRecForm.getEndTime()));
			qp.put("minAmount", mposRecForm.getMinAmount());
			qp.put("maxAmount", mposRecForm.getMaxAmount());
			qp.put("actionType", 1);
			qp.put("status", mposRecForm.getStatus());
			qp.put("merchantId", mposRecForm.getMerchantId());
			/*qp.put("chargechannel", mposRecForm.getChargechannel());*/
			if(val(mposRecForm.getShopperid_p())){
				qp.put("shopperidp", shopperidp);
			}else{
				qp.put("shopperidp", mposRecForm.getShopperid_p());
			}
			try {
				DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
				List<Map<String,String>> records = recordService.selectRechargeList(qp);
				if(records.size() == 0){
					request.setAttribute("mposRecForm", mposRecForm);
					request.setAttribute("rspCode", "2222");
					request.setAttribute("rspMsg", "没有记录");
					
					return "mpos/rechargeList";
				}
				request.setAttribute("list", records);
			} catch (Exception e) {
				e.printStackTrace();
				request.setAttribute("mposRecForm", mposRecForm);
				request.setAttribute("rspMsg","查询出错！" );
				return "mpos/rechargeList";
			}
			
			request.setAttribute("rspCode", "0000");
			request.setAttribute("mposRecForm", mposRecForm);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"充值记录查询错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		return "mpos/rechargeList";
	}
	//设置默认时间为当天
	@RequestMapping(params = "method=rechargeList")
	public String rechargeList(HttpServletRequest request,HttpServletResponse response) 
			throws BusinessException, ParseException {
	    try {
			String date = sf2.format(new Date());
		    request.setAttribute("startTime", date);
		    request.setAttribute("endTime", date);
		
			
			Agent agent = (Agent)request.getSession().getAttribute("agent");
			if(agent==null){
				throw new BusinessException(ExceptionDefine.session过期请重新登录);
			}
			Long shopperidp=agent.getShopperid()==null?null:agent.getShopperid();
			
			Map<String, Object> qp = new HashMap<String, Object>();		
			
			qp.put("startDate",sf.format(sf2.parse(date)));
			qp.put("actionType", 1);
			qp.put("shopperidp", shopperidp);
			try {
				//切换数据库 
				DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
				List<Map<String,String>> records = recordService.selectRechargeList(qp);
				if(records.size() == 0){
					request.setAttribute("rspCode", "2222");
					request.setAttribute("rspMsg", "没有记录");
					
					return "mpos/rechargeList";
				}
				
				request.setAttribute("list", records);
			} catch (Exception e) {
				e.printStackTrace();
				request.setAttribute("rspMsg","查询出错！" );
				return "mpos/rechargeList";
			}
	    } catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"充值记录查询错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}	
		request.setAttribute("rspCode", "0000");
		return "mpos/rechargeList";
	}
	
	/**
	 * D0提现纪录查询
	 * @throws BusinessException 
	 * @throws ParseException 
	 */
	@RequestMapping(params = "method=t0withdrawRecordList1")                                    
	public String t0withdrawRecordList1(HttpServletRequest request,HttpServletResponse response,MposRecordForm mposRecForm) throws BusinessException, ParseException {
		try{
			request.setAttribute("startTime", mposRecForm.getStartTime()==null?null:sf2.format(mposRecForm.getStartTime()));
			request.setAttribute("endTime", mposRecForm.getEndTime()==null?null:sf2.format(mposRecForm.getEndTime()));
			Agent agent = (Agent)request.getSession().getAttribute("agent");
			if(agent==null){
				throw new BusinessException(ExceptionDefine.session过期请重新登录);
			}
			Long shopperidp=agent.getShopperid();
			if(!val(mposRecForm.getMerchantId())){
				Map<String , Object> paramMap =  new HashMap<String, Object>();
				paramMap.put("shopperid", mposRecForm.getMerchantId());
				if(val(mposRecForm.getShopperid_p())){
					paramMap.put("shopperidp", shopperidp);
				}else{
					paramMap.put("shopperidp", mposRecForm.getShopperid_p());
				}
				
				try {
					List<B2cShopperbi> shopperbiList = shopPerbiService.judgeShopper(paramMap);
					if(shopperbiList.size()<=0){
						request.setAttribute("mposRecForm", mposRecForm);
						request.setAttribute("rspMsg","没有查到此商户。" );
						return "mpos/t0withdrawRecordList";
					}
				} catch (Exception e) {
					e.printStackTrace();
					request.setAttribute("mposRecForm", mposRecForm);
					request.setAttribute("rspMsg","没有查到此商户。" );
					return "mpos/t0withdrawRecordList";
				}
				
			}
	
			Map<String, Object> qp = new HashMap<String, Object>();
			qp.put("startDate", mposRecForm.getStartTime()==null?null:sf.format(mposRecForm.getStartTime()));
			qp.put("endDate", valDate(mposRecForm.getEndTime()));
			qp.put("minAmount", mposRecForm.getMinAmount());
			qp.put("maxAmount", mposRecForm.getMaxAmount());
			qp.put("actionType", 2);
			qp.put("merchantId", mposRecForm.getMerchantId());
			qp.put("status", mposRecForm.getStatus());
			qp.put("chargechannel", mposRecForm.getChargechannel());
			if(val(mposRecForm.getShopperid_p())){
				qp.put("shopperidp", shopperidp);
			}else{
				qp.put("shopperidp", mposRecForm.getShopperid_p());
			}
			try {
				//切换数据库 
				DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
				List<Map<String,String>> records = recordService.selectWithdrawD0List(qp);
				if(records.size() == 0){
					request.setAttribute("mposRecForm", mposRecForm);
					request.setAttribute("rspCode", "2222");
					request.setAttribute("rspMsg", "没有记录");
					return "mpos/t0withdrawRecordList";
				}
				request.setAttribute("list", records);
				
			} catch (Exception e) {
				e.printStackTrace();
				request.setAttribute("mposRecForm", mposRecForm);
				request.setAttribute("rspMsg","查询出错！" );
				return "mpos/t0withdrawRecordList";
			}
			request.setAttribute("mposRecForm", mposRecForm);
			request.setAttribute("rspCode", "0000");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"D0提现纪录查询错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}	
		return "mpos/t0withdrawRecordList";
	
	}
	//设置日期默认为当天
	@RequestMapping(params = "method=t0withdrawRecordList")
	public String t0withdrawRecordList(HttpServletRequest request,HttpServletResponse response) 
		throws BusinessException, ParseException {
		try{ 
			String date = sf2.format(new Date());
			    request.setAttribute("startTime", date);
			    request.setAttribute("endTime", date);
			Agent agent = (Agent)request.getSession().getAttribute("agent");
			if(agent==null){
				throw new BusinessException(ExceptionDefine.session过期请重新登录);
			}
			Long shopperidp=agent.getShopperid()==null?null:agent.getShopperid();
			
			Map<String, Object> qp = new HashMap<String, Object>();
			
			qp.put("startDate",sf.format(sf2.parse(date)));
			qp.put("actionType", 2);
			qp.put("shopperidp", shopperidp);
			
			try {
				//切换数据库 
				DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
				List<Map<String,String>> records = recordService.selectWithdrawD0List(qp);
				/*Map  collectMap=recordService.selectWithdrawListSum(qp);*/
				if(records.size() == 0){
					request.setAttribute("rspCode", "2222");
					request.setAttribute("rspMsg", "没有记录");
					return "mpos/t0withdrawRecordList";
				}
				request.setAttribute("list", records);
				/*request.setAttribute("collectMap", collectMap);*/
				
			} catch (Exception e) {
				e.printStackTrace();
				request.setAttribute("rspMsg","查询出错！" );
				return "mpos/t0withdrawRecordList";
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"D0提现纪录查询错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}	
		request.setAttribute("rspCode", "0000");
		return "mpos/t0withdrawRecordList";
	
	}
	/**
	 * T+1提现纪录查询
	 * @throws BusinessException 
	 * @throws ParseException 
	 */
	@RequestMapping(params = "method=t1withdrawRecordList1")
	public String t1withdrawRecordList1(HttpServletRequest request,HttpServletResponse response,MposRecordForm mposRecForm) throws BusinessException, ParseException {
		try{
			request.setAttribute("startTime", mposRecForm.getStartTime()==null?null:sf2.format(mposRecForm.getStartTime()));
			request.setAttribute("endTime", mposRecForm.getEndTime()==null?null:sf2.format(mposRecForm.getEndTime()));
			
			Agent agent = (Agent)request.getSession().getAttribute("agent");
			if(agent==null){
				throw new BusinessException(ExceptionDefine.session过期请重新登录);
			}
			Long shopperidp=agent.getShopperid()==null?null:agent.getShopperid();
			if(!val(mposRecForm.getMerchantId())){
				Map<String , Object> paramMap =  new HashMap<String, Object>();
				paramMap.put("shopperid", mposRecForm.getMerchantId());
				if(val(mposRecForm.getShopperid_p())){
					paramMap.put("shopperidp", shopperidp);
				}else{
					paramMap.put("shopperidp", mposRecForm.getShopperid_p());
				}
				try {
					List<B2cShopperbi> shopperbiList = shopPerbiService.judgeShopper(paramMap);
					if(shopperbiList.size()<=0){
						request.setAttribute("mposRecForm", mposRecForm);
						request.setAttribute("rspMsg","没有查到此商户。" );
						return "mpos/rechargeList";
					}
				} catch (Exception e) {
					request.setAttribute("mposRecForm", mposRecForm);
					request.setAttribute("rspMsg","没有查到此商户。" );
					return "mpos/rechargeList";
				}
				
			}
			
			Map<String, Object> qp = new HashMap<String, Object>();
			qp.put("startDate", mposRecForm.getStartTime()==null?null:sf.format(mposRecForm.getStartTime()));
			qp.put("endDate", valDate(mposRecForm.getEndTime()));
			qp.put("minAmount", mposRecForm.getMinAmount());
			qp.put("maxAmount", mposRecForm.getMaxAmount());
			qp.put("actionType", 3);
			qp.put("merchantId", mposRecForm.getMerchantId());
			qp.put("status",mposRecForm.getStatus());
			/*qp.put("chargechannel", mposRecForm.getChargechannel());*/
			if(val(mposRecForm.getShopperid_p())){
				qp.put("shopperidp", shopperidp);
			}else{
				qp.put("shopperidp", mposRecForm.getShopperid_p());
			}
			try {
				//切换数据库 
				DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
				List<Map<String,String>> records = recordService.selectWithdrawT1List(qp);
				if(records.size() == 0){
					request.setAttribute("mposRecForm", mposRecForm);
					request.setAttribute("rspCode", "2222");
					request.setAttribute("rspMsg", "没有记录");
					return "mpos/t1withdrawRecordList";
				}
				request.setAttribute("list", records);
			} catch (Exception e) {
				request.setAttribute("mposRecForm", mposRecForm);
				request.setAttribute("rspMsg","查询出错！" );
				return "mpos/t1withdrawRecordList";
			}
			request.setAttribute("mposRecForm", mposRecForm);
			request.setAttribute("rspCode", "0000");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"T+1提现纪录查询错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		return "mpos/t1withdrawRecordList";
	}
	//设置日期默认为当天
	@RequestMapping(params = "method=t1withdrawRecordList")
	public String t1withdrawRecordList(HttpServletRequest request,HttpServletResponse response,String minAmount,String maxAmount,
			String merchantId,Date startTime,Date endTime,String status,String shopperid_p,String belongsAgent) throws BusinessException, ParseException {
		try{
			Date date=new Date();
			SimpleDateFormat sf=new SimpleDateFormat("yyyy-MM-dd");
			String startTime1=sf.format(date);
			String endTime1=sf.format(date);
			
			request.setAttribute("merchantId", merchantId);
			request.setAttribute("minAmount", minAmount);
			request.setAttribute("maxAmount", maxAmount);
			request.setAttribute("status", status);
			request.setAttribute("shopperid_p", shopperid_p);
			request.setAttribute("belongsAgent", belongsAgent);
			Agent agent = (Agent)request.getSession().getAttribute("agent");
			if(agent==null){
				throw new BusinessException(ExceptionDefine.session过期请重新登录);
			}
			Long shopperidp=agent.getShopperid()==null?null:agent.getShopperid();
			if(!val(merchantId)){
				Map<String , Object> paramMap =  new HashMap<String, Object>();
				paramMap.put("shopperid", merchantId);
				if(val(shopperid_p)){
					paramMap.put("shopperidp", shopperidp);
				}else{
					paramMap.put("shopperidp", shopperid_p);
				}
				List<B2cShopperbi> shopperbiList = shopPerbiService.judgeShopper(paramMap);
				if(shopperbiList.size()<=0){
					request.setAttribute("rspMsg","没有查到此商户。" );
					return "mpos/rechargeList";
				}
			}
			
			Map<String, Object> qp = new HashMap<String, Object>();
			if(startTime==null){
				request.setAttribute("startTime", startTime1);
				qp.put("startDate", startTime1);
			}else{
				request.setAttribute("startTime", sf2.format(startTime));
				qp.put("startDate", sf.format(startTime));
			}
			if(endTime==null){
				request.setAttribute("endTime", endTime1);
				qp.put("endDate", endTime1);
			}else{
				request.setAttribute("endTime", sf2.format(endTime));
				qp.put("endDate", sf.format(endTime));
			}
			qp.put("minAmount", minAmount);
			qp.put("maxAmount", maxAmount);
			qp.put("actionType", 3);
			qp.put("merchantId", merchantId);
			qp.put("status",status);
			if(val(shopperid_p)){
				qp.put("shopperidp", shopperidp);
			}else{
				qp.put("shopperidp", shopperid_p);
			}
			try {
				//切换数据库 
				DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
				List<Map<String,String>> records = recordService.selectWithdrawT1List(qp);
				if(records.size() == 0){
					request.setAttribute("rspCode", "2222");
					request.setAttribute("rspMsg", "没有记录");
					return "mpos/t1withdrawRecordList";
				}
				request.setAttribute("list", records);
			} catch (Exception e) {
				request.setAttribute("rspMsg","没有记录！" );
				return "mpos/t1withdrawRecordList";
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"T+1提现纪录查询错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		request.setAttribute("rspCode", "0000");
		return "mpos/t1withdrawRecordList";
	}
	/**
	 * 提现记录查询信息下载
	 * @throws Exception
	 */
	@RequestMapping(params = "method=findWithdrawPage")
	public String findWithdrawPage(HttpServletRequest request,HttpServletResponse response,MposRecordForm mposRecForm)throws Exception{
		try{
			request.setAttribute("startTime", mposRecForm.getStartTime()==null?null:sf2.format(mposRecForm.getStartTime()));
			request.setAttribute("endTime", mposRecForm.getEndTime()==null?null:sf2.format(mposRecForm.getEndTime()));
			
			Agent agent = (Agent)request.getSession().getAttribute("agent");
			if(agent==null){
				throw new BusinessException(ExceptionDefine.session过期请重新登录);
			}
			Long shopperidp=agent.getShopperid()==null?null:agent.getShopperid();
			/*if(!val(mposRecForm.getMerchantId())){
				Map<String , Object> paramMap =  new HashMap<String, Object>();
				paramMap.put("shopperid", mposRecForm.getMerchantId());
				if(val(mposRecForm.getShopperid_p())){
					paramMap.put("shopperidp", shopperidp);
				}else{
					paramMap.put("shopperidp", mposRecForm.getShopperid_p());
				}
				List<B2cShopperbi> shopperbiList = shopPerbiService.judgeShopper(paramMap);
				if(shopperbiList.size()<=0){
					request.setAttribute("rspMsg","没有查到此商户。" );
					return "mpos/rechargeList";
				}
			}*/
	
			Map<String, Object> qp = new HashMap<String, Object>();
			qp.put("startDate", mposRecForm.getStartTime()==null?null:sf.format(mposRecForm.getStartTime()));
			qp.put("endDate", valDate(mposRecForm.getEndTime()));
			qp.put("minAmount", mposRecForm.getMinAmount());
			qp.put("maxAmount", mposRecForm.getMaxAmount());
		/*	qp.put("chargechannel", mposRecForm.getChargechannel());*/
			if("T0".equals(mposRecForm.getFlag())){
				qp.put("actionType", 2);
			}else{
				qp.put("actionType", 3);
			}
			qp.put("merchantId", mposRecForm.getMerchantId());
			qp.put("status", mposRecForm.getStatus());
			if(val(mposRecForm.getShopperid_p())){
				qp.put("shopperidp", shopperidp);
			}else{
				qp.put("shopperidp", mposRecForm.getShopperid_p());
			}
			try {
				Page page  = new Page();
				page.setPageSize(Constants.excel_size);
				PageContext context = PageContext.getContext();
				BeanUtils.copyProperties(context, page);
				context.setPagination(true);
				//切换数据库 
				DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
				recordService.excelWithdrawT1List(qp);
				BeanUtils.copyProperties(page, context);
				request.setAttribute("page",page);
				
				
			} catch (Exception e) {
				request.setAttribute("rspMsg","查询出错！" );
				return "mpos/withdrawExcelPage";
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"提现记录查询信息下载错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		request.setAttribute("mposRecForm", mposRecForm);
		return "mpos/withdrawExcelPage";
	}
	
	/**
	 * t0提现记录查询信息下载
	 * @throws Exception
	 */
	@RequestMapping(params = "method=findWithdrawPaged0")
	public String findWithdrawPaged0(HttpServletRequest request,HttpServletResponse response,MposRecordForm mposRecordForm)throws Exception{
		try {
			request.setAttribute("startTime", mposRecordForm.getStartTime()==null?null:sf2.format(mposRecordForm.getStartTime()));
			request.setAttribute("endTime", mposRecordForm.getEndTime()==null?null:sf2.format(mposRecordForm.getEndTime()));
			
			Agent agent = (Agent)request.getSession().getAttribute("agent");
			if(agent==null){
				throw new BusinessException(ExceptionDefine.session过期请重新登录);
			}
			Long shopperidp=agent.getShopperid();
	
			Map<String, Object> qp = new HashMap<String, Object>();
			qp.put("startDate", mposRecordForm.getStartTime()==null?null:sf.format(mposRecordForm.getStartTime()));
			qp.put("endDate", valDate(mposRecordForm.getEndTime()));
			qp.put("minAmount", mposRecordForm.getMinAmount());
			qp.put("maxAmount", mposRecordForm.getMaxAmount());
			//qp.put("chargechannel", mposRecordForm.getChargechannel());
			if("T0".equals(mposRecordForm.getFlag())){
				qp.put("actionType", 2);
			}else{
				qp.put("actionType", 3);
			}
			qp.put("merchantId", mposRecordForm.getMerchantId());
			qp.put("status", mposRecordForm.getStatus());
			if(val(mposRecordForm.getShopperid_p())){
				qp.put("shopperidp", shopperidp);
			}else{
				qp.put("shopperidp", mposRecordForm.getShopperid_p());
			}
			try {
				Page page  = new Page();
				page.setPageSize(Constants.excel_size);
				PageContext context = PageContext.getContext();
				BeanUtils.copyProperties(context, page);
				context.setPagination(true);
				//切换数据库 
				DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
				recordService.excelWithdrawList(qp);
				BeanUtils.copyProperties(page, context);
				request.setAttribute("page",page);
				
				
			} catch (Exception e) {
				request.setAttribute("rspMsg","查询出错！" );
				return "mpos/d0withdrawExcel";
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"t0提现记录查询信息下载错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		request.setAttribute("mposRecordForm", mposRecordForm);
		return "mpos/d0withdrawExcel";
	}
	/**
	 * 算mac,并拼接好请求参数
	 */
	public String mac(String userId,String str,String key){
		return "userId=" + userId + str + "&mac=" + Md5Encrypt.md5("userId=" + userId + str + "&merchantKey=" + key).toLowerCase();
	}
	
	/**
	 * 拼接参数
	 * @param paramName 参数名
	 * @param param 参数值
	 * @return
	 */
	public String val(String paramName,String param){
		if(param != null && param != ""){
			return "&" + paramName + "=" + param ;
		}
		return "";
	}
	
	/**
	 * 验证非空
	 */
	public boolean val(String param){
		if(param == null || param == ""){
			return true;
		}
		return false;
	}
	
	/**
	 * 时间处理
	 * @throws ParseException 
	 */
	public String valDate(Date date) throws ParseException{
		if(date == null){
			return null;
		}else{
			return sf3.format(date) + "235959";
		}
	}
	/**
	 * 充值记录查询信息下载
	 * @throws Exception
	 */
	@RequestMapping(params = "method=findRechargePage")
	public String findRechargePage(HttpServletRequest request,HttpServletResponse response,MposRecordForm arForm)throws Exception{
		try {
			
			Agent agent = (Agent)request.getSession().getAttribute("agent");
			if(agent==null){
				throw new BusinessException(ExceptionDefine.session过期请重新登录);
			}
			Long shopperidp=agent.getShopperid();
			
			String status = request.getParameter("status");
			String startDate = arForm.getStartDate()==null?null:sf.format(arForm.getStartDate());
			String endDate = valDate(arForm.getEndDate());
			String shopperid_p =request.getParameter("shopperid_p");
			
			Map<String, Object> qp = new HashMap<String, Object>();
			qp.put("startDate", startDate);
			qp.put("endDate", endDate);
			qp.put("minAmount", arForm.getMinAmount());
			qp.put("maxAmount", arForm.getMaxAmount());
			qp.put("status", "-1".equals(status)?null:status);
			qp.put("merchantId", arForm.getMerchantId());
			/*qp.put("chargechannel", arForm.getChargechannel());*/
			if(val(shopperid_p)){
				qp.put("shopperidp", shopperidp);
			}else{
				qp.put("shopperidp", shopperid_p);
			}
			
			Page page=new Page();
			page.setPageSize(Constants.excel_size);
			PageContext context=PageContext.getContext();
			BeanUtils.copyProperties(context, page);
			context.setPagination(true);
			//切换数据库  
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
			recordService.findRechargePageList(qp);
			BeanUtils.copyProperties(page, context);
			request.setAttribute("status", status);
			request.setAttribute("startDate", startDate);
			request.setAttribute("endDate", endDate);
			request.setAttribute("shopperid_p", shopperid_p);
			request.setAttribute("arForm", arForm);
			request.setAttribute("page", page);
		
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("rspMsg", "查询出错");
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		
		
		return "mpos/rechargeExcelPage";
		
	}
	
	@RequestMapping(params = "method=downRechargeEcxel")
	public String downRechargeEcxel(HttpServletRequest request,HttpServletResponse response,MposRecordForm arForm)
	  throws Exception{
		try{
		 String tPage=request.getParameter("page");
		 if(StringUtils.isEmpty(tPage)||!StringUtils.isNumeric(tPage)){
			 tPage="1";
		 }
		 int currentPage=Integer.valueOf(tPage);
		 Page page=new Page();
		 page.setPageSize(Constants.excel_size);
		 PageContext context = PageContext.getContext();
		 BeanUtils.copyProperties(context, page);
		 context.setPagination(true);
		 context.setCurrentPage(currentPage);
		 
		Agent agent = (Agent)request.getSession().getAttribute("agent");
		if(agent==null){
			throw new BusinessException(ExceptionDefine.session过期请重新登录);
		}
		Long shopperidp=agent.getShopperid();
		String status = request.getParameter("status");
		String startDate = request.getParameter("startTimes");
		String endDate= request.getParameter("endTimes");
		/*if(!com.uns.util.StringUtils.isEmpty(arForm.getStartTime())) {
			startDate=sf.format(arForm.getStartTime());
			endDate=sf.format(arForm.getEndDate());
		}*/
		String shopperid_p =request.getParameter("shopperid_p");
		Map<String, Object> qp = new HashMap<String, Object>();
		qp.put("startDate", startDate);
		qp.put("endDate", endDate);
		qp.put("minAmount", arForm.getMinAmount());
		qp.put("maxAmount", arForm.getMaxAmount());
		qp.put("status", "-1".equals(status)?null:status);
		qp.put("merchantId", arForm.getMerchantId());
		/*qp.put("chargechannel", arForm.getChargechannel());*/
		if(val(shopperid_p)){
			qp.put("shopperidp", shopperidp);
		}else{
			qp.put("shopperidp", shopperid_p);
		}
		 //切换数据库 
		 DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name()); 
		 List<Map<String, Object>> list = recordService.findRechargePageList(qp);
		 
		 BeanUtils.copyProperties(page, context);
		 request.setAttribute("page", page);
		 Map<String,String> mapField=new LinkedHashMap<String,String>();
		 
			List<String> listHead = new ArrayList<String>();
			listHead.add("商户号");
			listHead.add("商户名称");
			listHead.add("服务商编号");
			listHead.add("服务商名称");
			listHead.add("到帐方式");
			listHead.add("费率(%)");
			listHead.add("刷卡记录状态");
			listHead.add("刷卡时间");
			listHead.add("刷卡金额");
			listHead.add("手续费");
			listHead.add("到账金额");
			listHead.add("订单号");
		
			List<String> listKey = new ArrayList<String>();
			listKey.add("SMALL_MERCH_NO");
			listKey.add("SCOMPANY");
			listKey.add("SRCID");
			listKey.add("AGENT_COMPANY");
			listKey.add("SETTLE_TYPE");
			listKey.add("FEE");
			listKey.add("STATUS");
			listKey.add("ORDER_TIME");
			listKey.add("AMOUNT");
			listKey.add("COMMISSION");
			listKey.add("ARRIVALAMOUNT");
			listKey.add("OUTTRADENO");
			
			
		 ExcelUtils.downExcel(list, listKey, listHead, "MPOS-RECORD", "MPOS_ORDER", response);
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		return null;
		
	}
	private void downExcel(List list,HttpServletResponse response,Map<String,String> mapField)
	  throws Exception{
		String fileNames=DateUtil.getDateType(new Date(),"yyyy-MM-dd");
		
		response.setContentType("application/vnd.ms-excel");
		response.setHeader("content-disposition", "attachment;filename=" + fileNames+"_Order" + ".xls");
		response.setCharacterEncoding("UTF-8");
		
		 OutputStream os = response.getOutputStream();
		 WritableWorkbook wwb=Workbook.createWorkbook(os);
		 WritableSheet sheet=wwb.createSheet(fileNames+"充值信息",0);
		 SheetSettings ss=sheet.getSettings();
		 ss.setVerticalFreeze(1);//冻结表头
		 
		 WritableCellFormat wcf=new WritableCellFormat();  //表头
		 WritableCellFormat wcf2=new WritableCellFormat();  //内容
		 
		 int flag=0;
		 int columnIndex=0;
		 List<String> methodNameList=new ArrayList<String>();
		 
		 if(mapField!=null&&mapField.size()>0){
			 String key="";
			 //循环写入表头
			 for(Iterator<String> i=mapField.keySet().iterator();i.hasNext();){
				key= i.next();
				sheet.addCell(new Label(columnIndex,0,mapField.get(key),wcf));
				methodNameList.add(key);
				columnIndex++;
				
			 }
			 //判断表中是否有数据
			 if(list!=null&&list.size()>0){
				 //循环写入表中
				 for(int i=0;i<list.size();i++){
					 //转换成map集合
					 Map<String, Object> map = (Map<String, Object>) list.get(i);
					 //循环输出map中的子集
					 for (Object o : map.keySet()) {
						 if (o.toString().equals("SHOPPERID")) {
								sheet.addCell(new Label(0, i + 1, String.valueOf(map.get(o)), wcf2));
						 }
						 if (o.toString().equals("SCOMPANY")) {
								sheet.addCell(new Label(1, i + 1, String.valueOf(map.get(o)), wcf2));
						 }
						 /*if (o.toString().equals("TERMDEVICEID")) {
								sheet.addCell(new Label(2, i + 1, String.valueOf(map.get(o)), wcf2));
						 }*/
						 if (o.toString().equals("AGENT_ID")) {
								sheet.addCell(new Label(2, i + 1, String.valueOf(map.get(o)), wcf2));
						 }
						 if (o.toString().equals("AGENT_COMPANY")) {
								sheet.addCell(new Label(3, i + 1, String.valueOf(map.get(o)), wcf2));
						 }
						 if (o.toString().equals("COMMISSIONTYPE")) {
							    
								 sheet.addCell(new Label(4, i + 1, String.valueOf(map.get(o)), wcf2));    
						 }
						 if (o.toString().equals("FEE")) {
							 
								sheet.addCell(new Label(5, i + 1, String.valueOf(map.get(o)), wcf2));
						 }
						 if (o.toString().equals("TOP_AMOUNT")) {
								sheet.addCell(new Label(6, i + 1, String.valueOf(map.get(o)), wcf2));
						 }
						 if (o.toString().equals("STATUS")) {
								sheet.addCell(new Label(7, i + 1, String.valueOf(map.get(o)), wcf2));
						 }
						 if (o.toString().equals("ORDER_TIME")) {
								sheet.addCell(new Label(8, i + 1, String.valueOf(map.get(o)), wcf2));
						 }
						 if (o.toString().equals("AMOUNT")) {
								sheet.addCell(new Label(9, i + 1, String.valueOf(map.get(o)), wcf2));
						 }
						 if (o.toString().equals("COMMISSION")) {
								sheet.addCell(new Label(10, i + 1, String.valueOf(map.get(o)), wcf2));
						 }
						 if (o.toString().equals("ARRIVALAMOUNT")) {
								sheet.addCell(new Label(11, i + 1, String.valueOf(map.get(o)), wcf2));
						 }
						 if (o.toString().equals("OUTTRADENO")) {
								sheet.addCell(new Label(12, i + 1, String.valueOf(map.get(o)), wcf2));
						 }
					 }
				 }
			 }
		 }else{
			 flag=-1;
		 }
		 //写入Excel工作表
		 wwb.write();
		 //关闭Excel工作簿对象
		 wwb.close();
		 os.flush();
		 os.close();
		 
		os=null; 
		 
	}
	/**
	 * 导出提现记录
	 */
	@RequestMapping(params = "method=downloadWithdrawList")
	public String downloadWithdrawList(HttpServletRequest request,HttpServletResponse response,
			MposRecordForm mposRecForm) throws ParseException, BusinessException {
		try{
			Agent agent = (Agent)request.getSession().getAttribute("agent");
			if(agent==null){
				throw new BusinessException(ExceptionDefine.session过期请重新登录);
			}
			Long shopperidp=agent.getShopperid()==null?null:agent.getShopperid();
			if(!val(mposRecForm.getMerchantId())){
				Map<String , Object> paramMap =  new HashMap<String, Object>();
				paramMap.put("shopperid", mposRecForm.getMerchantId());
				if(val(mposRecForm.getShopperid_p())){
					paramMap.put("shopperidp", shopperidp);
				}else{
					paramMap.put("shopperidp", mposRecForm.getShopperid_p());
				}
				List<B2cShopperbi> shopperbiList = shopPerbiService.judgeShopper(paramMap);
				if(shopperbiList.size()<=0){
					request.setAttribute("rspMsg","没有查到此商户。" );
					return "mpos/rechargeList";
				}
			}
	
			Map<String, Object> qp = new HashMap<String, Object>();
			qp.put("startDate", mposRecForm.getStartTime()==null?null:sf.format(mposRecForm.getStartTime()));
			qp.put("endDate", valDate(mposRecForm.getEndTime()));
			qp.put("minAmount", mposRecForm.getMinAmount());
			qp.put("maxAmount", mposRecForm.getMaxAmount());
			/*qp.put("chargechannel", mposRecForm.getChargechannel());*/
			if("T0".equals(mposRecForm.getFlag())){
				qp.put("actionType", 2);
			}else{
				qp.put("actionType", 3);
			}
			qp.put("merchantId", mposRecForm.getMerchantId());
			qp.put("status", mposRecForm.getStatus());
			if(val(mposRecForm.getShopperid_p())){
				qp.put("shopperidp", shopperidp);
			}else{
				qp.put("shopperidp", mposRecForm.getShopperid_p());
			}
			List<Map<String,String>> records = new ArrayList<Map<String,String>>();
			try {
				//切换数据库 
				DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
				records = recordService.excelWithdrawT1List(qp);
				if(records.size() == 0){
					request.setAttribute("rspCode", "2222");
					request.setAttribute("rspMsg", "没有记录");
					return "mpos/t1withdrawRecordList";
				}
				request.setAttribute("list", records);
			} catch (Exception e) {
				request.setAttribute("rspMsg","查询出错！" );
				return "mpos/t1withdrawRecordList";
			}
			
			try{
				outExcel(records,response,"T1_WITHDRAW",records.size());
			}catch (Exception e) {
				log.info("导出数据有误！");
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"导出提现记录错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		return null;
	}
	
	/**导出excel
	 * @param excelList T1提现记录list
	 * @param response 
	 * @throws Exception
	 */
	private void outExcel(List<Map<String,String>> excelList, HttpServletResponse response,String fileNames,
			int totalRows) throws Exception {
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		response.setContentType("application/vnd.ms-excel");
		response.setHeader("content-disposition", "attachment;filename="+new String(fileNames.getBytes("GBK"),"iso8859-1")+".xls");
		response.setCharacterEncoding("UTF-8");
	
        OutputStream os = response.getOutputStream(); 
		WritableWorkbook wwb=Workbook.createWorkbook(os);
		WritableSheet sheet0 = wwb.createSheet(fileNames,0);
		sheet0.addCell(new Label(0,0, "总记录数"));
		sheet0.addCell(new Label(1,0, String.valueOf(totalRows)));
		sheet0.addCell(new Label(0,1, "商户号"));
		sheet0.addCell(new Label(1,1, "商户名称"));
		sheet0.addCell(new Label(2,1, "服务商编号"));
        sheet0.addCell(new Label(3,1, "服务商名称"));
      /*  sheet0.addCell(new Label(4,1,"通道类型"));*/
        sheet0.addCell(new Label(4,1, "状态"));
        sheet0.addCell(new Label(5,1, "提现时间"));
        sheet0.addCell(new Label(6,1, "提现金额"));
        sheet0.addCell(new Label(7,1, "手续费/元"));
        sheet0.addCell(new Label(8,1, "到账金额/元"));
        sheet0.addCell(new Label(9,1, "订单号"));
        
        for (int i = 0; i < excelList.size(); i++) {  
            //转换成map集合{activyName:测试功能,count:2}  
        	Map<String,String> info = excelList.get(i);
        	String status = "";
        	if("1".equals(info.get("STATUS"))){
        		status = "提现失败";
        	}else if("2".equals(info.get("STATUS"))){
        		status = "提现成功";
        	}else if("5".equals(info.get("STATUS"))){
        		status = "待审核";
        	}else if("6".equals(info.get("STATUS"))){
        		status = "审核不通过";
			}
        /*	String chargechannel="";
        	if(Constants.HK_TYPE.equals(info.get("CHARGECHANNEL"))) {
        		chargechannel="北京海科";
        	}
        	if(Constants.HF_TYPE.equals(info.get("CHARGECHANNEL"))){
        		chargechannel="宏付";
        	}*/
            //循环输出map中的子集：既列值  
            sheet0.addCell(new Label(0,i+2, info.get("SHOPPERID")==null?"":String.valueOf(info.get("SHOPPERID"))));
            sheet0.addCell(new Label(1,i+2, info.get("SCOMPANY")));
            sheet0.addCell(new Label(2,i+2, info.get("AGENT_ID")==null?"":String.valueOf(info.get("AGENT_ID"))));
            sheet0.addCell(new Label(3,i+2, info.get("AGENT_COMPANY")));
           // sheet0.addCell(new Label(4,i+2, chargechannel));
        	//s.MICROMERCHANTNO shopperid,s.scompany,a.SRCID agent_id,a.scompany agent_company,
            sheet0.addCell(new Label(4,i+2, status));
            sheet0.addCell(new Label(5,i+2, sf.format(info.get("ORDER_TIME"))));
            sheet0.addCell(new Label(6,i+2, info.get("AMOUNT")==null?"":String.valueOf(info.get("AMOUNT"))));
            sheet0.addCell(new Label(7,i+2, info.get("COMMISSION")==null?"":String.valueOf(info.get("COMMISSION"))));
            sheet0.addCell(new Label(8,i+2, info.get("ARRIVALAMOUNT")==null?"":String.valueOf(info.get("ARRIVALAMOUNT"))));
            sheet0.addCell(new Label(9,i+2, info.get("OUTTRADENO")));
        }
        //写入Exel工作表  
        wwb.write();  
        //关闭Excel工作薄对象   
        wwb.close();  
        //关闭流  
        os.flush();  
        os.close();  
          
        os =null;  
       
	}
	//t0导出提现记录
	@RequestMapping(params = "method=d0downloadWithdrawList")
	public String d0downloadWithdrawList(HttpServletRequest request,HttpServletResponse response,MposRecordForm mposRecordForm) throws ParseException, BusinessException {
		try{
			Agent agent = (Agent)request.getSession().getAttribute("agent");
			if(agent==null){
				throw new BusinessException(ExceptionDefine.session过期请重新登录);
			}
			Long shopperidp=agent.getShopperid();
			if(!val(mposRecordForm.getMerchantId())){
				Map<String , Object> paramMap =  new HashMap<String, Object>();
				paramMap.put("shopperid", mposRecordForm.getMerchantId());
				if(val(mposRecordForm.getShopperid_p())){
					paramMap.put("shopperidp", shopperidp);
				}else{
					paramMap.put("shopperidp", mposRecordForm.getShopperid_p());
				}
				List<B2cShopperbi> shopperbiList = shopPerbiService.judgeShopper(paramMap);
				if(shopperbiList.size()<=0){
					request.setAttribute("rspMsg","没有查到此商户。" );
					return "mpos/t0withdrawRecordList";
				}
			}
	
			Map<String, Object> qp = new HashMap<String, Object>();
			qp.put("startDate", mposRecordForm.getStartTime()==null?null:sf.format(mposRecordForm.getStartTime()));
			qp.put("endDate", valDate(mposRecordForm.getEndTime()));
			qp.put("minAmount", mposRecordForm.getMinAmount());
			qp.put("maxAmount", mposRecordForm.getMaxAmount());
		/*	qp.put("chargechannel", mposRecordForm.getChargechannel());*/
			if("T0".equals(mposRecordForm.getFlag())){
				qp.put("actionType", 2);
			}else{
				qp.put("actionType", 3);
			}
			qp.put("merchantId", mposRecordForm.getMerchantId());
			qp.put("status", mposRecordForm.getStatus());
			if(val(mposRecordForm.getShopperid_p())){
				qp.put("shopperidp", shopperidp);
			}else{
				qp.put("shopperidp", mposRecordForm.getShopperid_p());
			}
			List<Map<String,String>> records = new ArrayList<Map<String,String>>();
			try {
				//切换数据库 
				DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
				records = recordService.excelWithdrawList(qp);
				if(records.size() == 0){
					request.setAttribute("rspCode", "2222");
					request.setAttribute("rspMsg", "没有记录");
					return "mpos/t0withdrawRecordList";
				}
				request.setAttribute("list", records);
				
			} catch (Exception e) {
				request.setAttribute("rspMsg","查询出错！" );
				return "mpos/t0withdrawRecordList";
			}
			
			try{
				d0outExcel(records,response,"D0_WITHDRAW",records.size());
			}catch (Exception e) {
				log.info("导出数据有误！");
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"t0导出提现记录错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		return null;
	}
	
	/**d0导出excel
	 * @param excelList T0提现记录list
	 * @param response 
	 * @throws Exception
	 */
	private void d0outExcel(List<Map<String,String>> excelList, HttpServletResponse response,String fileNames,
			int totalRows) throws Exception {
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		response.setContentType("application/vnd.ms-excel");
		response.setHeader("content-disposition", "attachment;filename="+new String(fileNames.getBytes("GBK"),"iso8859-1")+".xls");
		response.setCharacterEncoding("UTF-8");
		
        OutputStream os = response.getOutputStream(); 
		WritableWorkbook wwb=Workbook.createWorkbook(os);
		WritableSheet sheet0 = wwb.createSheet(fileNames,0);
		sheet0.addCell(new Label(0,0, "总记录数"));
		sheet0.addCell(new Label(1,0, String.valueOf(totalRows)));
		sheet0.addCell(new Label(0,1, "商户号"));
		sheet0.addCell(new Label(1,1, "商户名称"));
		sheet0.addCell(new Label(2,1, "服务商编号"));
        sheet0.addCell(new Label(3,1, "服务商名称"));
       /* sheet0.addCell(new Label(4,1, "通道类型"));*/
        sheet0.addCell(new Label(4,1, "到账方式"));
        sheet0.addCell(new Label(5,1, "状态"));
        sheet0.addCell(new Label(6,1, "提现时间"));
        sheet0.addCell(new Label(7,1, "提现金额"));
        sheet0.addCell(new Label(8,1, "D0提现费率(%)"));
        sheet0.addCell(new Label(9,1, "手续费/元"));
        sheet0.addCell(new Label(10,1, "到账金额/元"));
        sheet0.addCell(new Label(11,1, "订单号"));
        
        for (int i = 0; i < excelList.size(); i++) {  
            //转换成map集合{activyName:测试功能,count:2}  
        	Map<String,String> info = excelList.get(i);
        	String status = "";
        	if(Constants.WITHDRAW_STATUS1.equals(info.get("STATUS"))){
        		status = "提现失败";
        	}else if(Constants.WITHDRAW_STATUS2.equals(info.get("STATUS"))){
        		status = "提现成功";
        	}else if(Constants.WITHDRAW_STATUS5.equals(info.get("STATUS"))){
        		status = "待审核";
        	}else if(Constants.WITHDRAW_STATUS6.equals(info.get("STATUS"))){
        		status = "审核不通过";
			}
        	/*String chargechannel="";
        	if(Constants.HK_TYPE.equals(info.get("CHARGECHANNEL"))) {
        		chargechannel="北京海科";
        	}
        	if(Constants.HF_TYPE.equals(info.get("CHARGECHANNEL"))){
        		chargechannel="宏付";
        	}*/
        	
            //循环输出map中的子集：既列值  
            sheet0.addCell(new Label(0,i+2, info.get("SHOPPERID")==null?"":String.valueOf(info.get("SHOPPERID"))));
            sheet0.addCell(new Label(1,i+2, info.get("SCOMPANY")));
            sheet0.addCell(new Label(2,i+2, info.get("AGENT_ID")==null?"":String.valueOf(info.get("AGENT_ID"))));
            sheet0.addCell(new Label(3,i+2, info.get("AGENT_COMPANY")));
           /* sheet0.addCell(new Label(4,i+2, chargechannel));*/
            sheet0.addCell(new Label(4,i+2, info.get("SETTLETYPE")));
            sheet0.addCell(new Label(5,i+2, status));
            sheet0.addCell(new Label(6,i+2, sf.format(info.get("ORDER_TIME"))));
            sheet0.addCell(new Label(7,i+2, info.get("AMOUNT")==null?"":String.valueOf(info.get("AMOUNT"))));
            sheet0.addCell(new Label(8,i+2, info.get("WITHDRAWCOMMISSIONRATE")==null?"":String.valueOf(info.get("WITHDRAWCOMMISSIONRATE"))));
            sheet0.addCell(new Label(9,i+2, info.get("COMMISSION")==null?"":String.valueOf(info.get("COMMISSION"))));
            sheet0.addCell(new Label(10,i+2, info.get("ARRIVALAMOUNT")==null?"":String.valueOf(info.get("ARRIVALAMOUNT"))));
            sheet0.addCell(new Label(11,i+2, info.get("OUTTRADENO")));
        }
        //写入Exel工作表  
        wwb.write();  
        //关闭Excel工作薄对象   
        wwb.close();  
        //关闭流  
        os.flush();  
        os.close();  
          
        os =null;  
       
	}
}
