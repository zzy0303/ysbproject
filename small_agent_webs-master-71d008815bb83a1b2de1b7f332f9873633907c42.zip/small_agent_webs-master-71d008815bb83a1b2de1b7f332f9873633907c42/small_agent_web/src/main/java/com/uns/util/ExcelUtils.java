package com.uns.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import jxl.SheetSettings;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.apache.commons.collections.map.LinkedMap;
import org.apache.commons.lang3.StringUtils;

public class ExcelUtils {

	
	/**
	 * 将记录导出到csv文件
	 * @param columnMap,只适用于记录数据类型是map的情况。key是db的列名,value是csv的表格头(通常中文)
	 * @param dataList:记录集
	 * @param response
	 * @param fileName,下载的时候默认文件名
	 * @param charset:字符编码
	 * @throws Exception
	 */
	public static void export2csv(LinkedMap columnMap,List<Map<String,?>> dataList,HttpServletResponse response,String fileName,String charset) throws Exception{
		List<String> headerList = new ArrayList();
        List<String> columnList = columnMap.asList();
        
        String colName = null;
        for(int i=0;i<columnList.size();i++){
        	colName = columnList.get(i);
        	headerList.add((String)columnMap.get(colName));
        }
        
        StringBuffer sb = new StringBuffer();
        
		for(Map<String,?> i:dataList){
			for(int j=0;j<columnList.size();j++){
				sb.append(i.get(columnList.get(j))).append(",");
			}
			sb.append("\r\n");
		}
		
		response.setContentType("application/vnd.ms-excel");
		response.setHeader("content-disposition", "attachment;filename="+fileName);
        response.setCharacterEncoding(charset);
        response.getWriter().println(StringUtils.join(headerList.iterator(),","));
        response.getWriter().println("\r\n");
        response.getWriter().println(sb.toString());
        response.getWriter().flush();
        response.getWriter().close();
	}
	
	public static void export2LocalCsv(LinkedMap columnMap,List<Map<String,?>> dataList,String fileName,String charset) throws Exception{
        List<String> headerList = new ArrayList();
        List<String> columnList = columnMap.asList();
        
        String colName = null;
        for(int i=0;i<columnList.size();i++){
        	colName = columnList.get(i);
        	headerList.add((String)columnMap.get(colName));
        }
        
        StringBuffer sb = new StringBuffer();
        
		for(Map<String,?> i:dataList){
			for(int j=0;j<columnList.size();j++){
				sb.append(i.get(columnList.get(j))).append(",");
			}
			sb.append("\r\n");
		}
		
		OutputStreamWriter os = new OutputStreamWriter(new FileOutputStream(new File(fileName)),charset);
        os.write(StringUtils.join(headerList.iterator(),","));
        os.write("\r\n");
        os.write(sb.toString());
        os.flush();
        os.close();
	}
	
	/**
	 * 下载excel 
	 * @param listData 数据集（Map类型）
	 * @param listKey 从数据集中取值的Key
	 * @param listHead 标题列
	 * @param fileName 文件名
	 * @param sheetName 页名
	 * @param response 
	 * @throws Exception
	 */
	public static void downExcel(List<Map<String,Object>> listData,List<String> listKey,List<String> listHead,
			String fileName,String sheetName,HttpServletResponse response)
	  throws Exception{
		OutputStream  os = response.getOutputStream();
		 WritableWorkbook wwb=Workbook.createWorkbook(os);
		try {
			String date=DateUtil.getDateType(new Date(),"yyyy-MM-dd");
			
			response.setContentType("application/vnd.ms-excel");
			response.setHeader("content-disposition", "attachment;filename=" + fileName + "-" + date + ".xls");
			response.setCharacterEncoding("UTF-8");
		
			 WritableSheet sheet=wwb.createSheet(sheetName,0);
			 SheetSettings ss=sheet.getSettings();
			 ss.setVerticalFreeze(1);//冻结表头
			 
			 for(int i=0;i<listHead.size();i++){
				 sheet.addCell(new Label(i,0,listHead.get(i)));
			 }
		
			 for(int i=0;i<listData.size();i++){
				 for (int j=0;j<listKey.size();j++){
					 sheet.addCell(new Label(j, i+1, String.valueOf(listData.get(i).get(listKey.get(j))==null?"":listData.get(i).get(listKey.get(j)))));
				 }
			 }
			 wwb.write();
			 wwb.close();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			 os.flush();
			 os.close();
			
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public static void main(String[] args) throws Exception {
		LinkedMap columnMap=new LinkedMap();
		columnMap.put("userName", "用户名");
		columnMap.put("password", "密码");
		columnMap.put("age", "年龄");
		
		List<Map<String,?>> dataList = new ArrayList<Map<String,?>>();
		Map map0 = new HashMap();
		map0.put("userName", "lkujing");
		map0.put("password", "13434");
		map0.put("age", 30);
		Map map1 = new HashMap();
		map1.put("userName", "huangsan");
		map1.put("password", "123456");
		map1.put("age", 32);
		
		dataList.add(map0);
		dataList.add(map1);
		
		ExcelUtils.export2LocalCsv(columnMap, dataList, "c:/aaa.csv", "UTF-8");
	}
}
