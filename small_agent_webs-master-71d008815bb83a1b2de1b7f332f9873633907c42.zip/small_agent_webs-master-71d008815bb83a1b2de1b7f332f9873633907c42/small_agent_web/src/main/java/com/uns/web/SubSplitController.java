package com.uns.web;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.Page;
import com.uns.model.Users;
import com.uns.service.SplitService;
import com.uns.slx.common.mutidatasource.DataSourceSwitch;
import com.uns.util.ExcelUtils;
import com.uns.web.form.SplitForm;

@Controller
@RequestMapping("/subSplit.htm")
public class SubSplitController  extends BaseController{
	@Autowired
	private SplitService splitService;
	
	/**
	 * 服务商刷卡批次查询
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=findAgentSkSplitList")
	public String findAgentSkSplitList(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform) throws BusinessException{
		try{
			Users  sessionUser=(Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			if(sessionUser==null || StringUtils.isEmpty(Long.toString(sessionUser.getMerchantid()))){
				throw new BusinessException(ExceptionDefine.商户查询失败);
			}
			sform.setSessionUserNo(String.valueOf(sessionUser.getMerchantid()));
			//标识为刷卡批次
			sform.setTransType("1");
			if(sform.getEndDate() != null){
				Calendar c = Calendar.getInstance();
				c.setTime(sform.getEndDate());
				c.add(Calendar.DAY_OF_MONTH, 1);
				sform.setEndDate(c.getTime());
			}
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
			List<Map<String,Object>> listData = splitService.selectSubBatchList(sform);
			for(Map<String,Object> map:listData){
				Date d1 = (Date)map.get("END_DATE");
				Calendar cal=Calendar.getInstance();
				cal.add(Calendar.WEEK_OF_MONTH, -4);
				cal.set(Calendar.DAY_OF_WEEK, 2);
				Date d2 = cal.getTime();
				if(d1.compareTo(d2) == -1 ){
					map.put("detailFlag", "0");
				}else{
					map.put("detailFlag", "1");
				}
			}
			//如果是下载
			if("1".equals(sform.getIfDownload())){
				//判断是否操作最大条数
				if(((Page)request.getAttribute("page")).getTotalRows()>Constants.MAX_DOWNLOAD_SIZE){
					request.setAttribute(Constants.MESSAGE_KEY,"单次最大下载条数为" + Constants.MAX_DOWNLOAD_SIZE + "条");
					request.setAttribute("url","subSplit.htm?method=findAgentSkSplitList");
					return "/returnPage";
				}
				listData = splitService.downSubBatchList(sform);
				for(Map<String,Object> map:listData){
					 map.put("STATUS", Constants.convertMap.get(map.get("STATUS")));
				}
				List<String> listHead = new ArrayList<String>();
				listHead.add("结算批次号");
				listHead.add("结算日期");
				listHead.add("服务商编号");
				listHead.add("服务商名称");
				/*listHead.add("费率类-费率％");
				listHead.add("封顶类-费率％");
				listHead.add("封顶类-封顶值/元");*/
				listHead.add("贷记卡底价费率");
				listHead.add("借记卡底价费率");
				listHead.add("交易笔数/笔");
				listHead.add("刷卡交易总金额/元");
				listHead.add("分润总金额/元");
				listHead.add("状态");
				List<String> listKey = new ArrayList<String>();
				listKey.add("BATCH_NO");
				listKey.add("CREATE_DATE");
				listKey.add("SHOPPERIDP");
				listKey.add("SCOMPANY");
				/*listKey.add("SK_FEETYPE_FEE");
				listKey.add("SK_TOPTYPE_FEE");
				listKey.add("SK_TOPTYPE_TOP");*/
				listKey.add("SK_CREDIT_FEE");
				listKey.add("SK_DEBIT_FEE");
				listKey.add("SUM_COUNT");
				listKey.add("SUM_AMOUNT");
				listKey.add("SUM_PROFIT");
				listKey.add("STATUS");
				try {
					ExcelUtils.downExcel(listData, listKey, listHead, "SK-BATCH", "刷卡分润批次信息", response);
					return null;
				} catch (Exception e) {
					e.printStackTrace();
					return null;
				}
			}
			request.setAttribute("list", listData);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"服务商刷卡批次查询错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		return "subAgentProfit/skBatchList";
	}
	/**
	 * 服务商刷卡批次查询
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=findAgentSkSplitNewList")
	public String findAgentSkSplitNewList(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform) throws BusinessException{
		try{
			Users  sessionUser=(Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			if(sessionUser==null || StringUtils.isEmpty(Long.toString(sessionUser.getMerchantid()))){
				throw new BusinessException(ExceptionDefine.商户查询失败);
			}
			sform.setSessionUserNo(String.valueOf(sessionUser.getMerchantid()));
			//标识为刷卡批次
			sform.setTransType("1");
			if(sform.getEndDate() != null){
				Calendar c = Calendar.getInstance();
				c.setTime(sform.getEndDate());
				c.add(Calendar.DAY_OF_MONTH, 1);
				sform.setEndDate(c.getTime());
			}
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
			List<Map<String,Object>> listData = splitService.selectSubBatchNewList(sform);
			for(Map<String,Object> map:listData){
				Date d1 = (Date)map.get("END_DATE");
				Calendar cal=Calendar.getInstance();
				cal.add(Calendar.WEEK_OF_MONTH, -4);
				cal.set(Calendar.DAY_OF_WEEK, 2);
				Date d2 = cal.getTime();
				if(d1.compareTo(d2) == -1 ){
					map.put("detailFlag", "0");
				}else{
					map.put("detailFlag", "1");
				}
			}
			//如果是下载
			if("1".equals(sform.getIfDownload())){
				//判断是否操作最大条数
				if(((Page)request.getAttribute("page")).getTotalRows()>Constants.MAX_DOWNLOAD_SIZE){
					request.setAttribute(Constants.MESSAGE_KEY,"单次最大下载条数为" + Constants.MAX_DOWNLOAD_SIZE + "条");
					request.setAttribute("url","subSplit.htm?method=findAgentSkSplitList");
					return "/returnPage";
				}
				listData = splitService.downSubBatchNewList(sform);
				for(Map<String,Object> map:listData){
					 map.put("STATUS", Constants.convertMap.get(map.get("STATUS")));
				}
				List<String> listHead = new ArrayList<String>();
				listHead.add("结算批次号");
				listHead.add("结算日期");
				listHead.add("服务商编号");
				listHead.add("服务商名称");
				listHead.add("到帐方式");
				listHead.add("费率");
				listHead.add("交易笔数/笔");
				listHead.add("刷卡交易总金额/元");
				listHead.add("分润总金额/元");
				listHead.add("状态");
				List<String> listKey = new ArrayList<String>();
				listKey.add("BATCH_NO");
				listKey.add("CREATE_DATE");
				listKey.add("SHOPPERIDP");
				listKey.add("SCOMPANY");
				listKey.add("SETTLE_TYPE");
				listKey.add("FEE");
				listKey.add("SUM_COUNT");
				listKey.add("SUM_AMOUNT");
				listKey.add("SUM_PROFIT");
				listKey.add("STATUS");
				try {
					ExcelUtils.downExcel(listData, listKey, listHead, "SK-BATCH", "刷卡分润批次信息", response);
					return null;
				} catch (Exception e) {
					e.printStackTrace();
					return null;
				}
			}
			request.setAttribute("list", listData);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"服务商刷卡批次查询错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		return "subAgentProfit/skBatchNewList";
	}
	/**
	 *  服务商刷卡批次详情查询
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=skBatchDetailList")
	public String skBatchDetailList(HttpServletRequest request, HttpServletResponse response,
		SplitForm sform) throws BusinessException{
		try{
			request.setAttribute("batchNo", sform.getBatchNo());
			request.setAttribute("status", sform.getStatus());
			request.setAttribute("id", sform.getId());
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
			List<Map<String,Object>> listData = splitService.selectSplitList(sform);
			//如果是下载
			if("1".equals(sform.getIfDownload())){
				if(((Page)request.getAttribute("page")).getTotalRows()>Constants.MAX_DOWNLOAD_SIZE){
					request.setAttribute(Constants.MESSAGE_KEY,"单次最大下载条数为" + Constants.MAX_DOWNLOAD_SIZE + "条");
					request.setAttribute("url","subSplit.htm?method=skBatchDetailList&batchNo="
							+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
					return "/returnPage";
				}
				listData = splitService.downSplitList(sform);
				for(Map<String,Object> map:listData){
					 String time = String.valueOf(map.get("OUTTRADETIME"));
					 map.put("OUTTRADETIME", time.substring(0, 4) + "-" + time.substring(4, 6) + "-" + time.substring(6, 8) + "-" 
							 + time.substring(8, 10) + ":" + time.substring(10, 12) + ":" + time.substring(12, 14));
					 String fee = String.valueOf(map.get("SK_FEE"));
					 String feeType = String.valueOf(map.get("FEE_TYPE"));
					 String top = String.valueOf(map.get("SK_TOP"));
					 if("1".equals(feeType)){
						 map.put("SK_FEE", fee + "-" + top + "元封顶");
					 }
				}
				List<String> listHead = new ArrayList<String>();
				listHead.add("订单号");
				listHead.add("服务商编号");
				listHead.add("服务商名称");
				listHead.add("商户号");
				listHead.add("商户名称");
				listHead.add("交易时间");
				/*listHead.add("费率类型");*/
				listHead.add("费率(％)");
				listHead.add("刷卡金额");
				listHead.add("手续费/元");
				listHead.add("到账金额/元");
				listHead.add("分润金额/元");
	
				List<String> listKey = new ArrayList<String>();
				listKey.add("OUTTRADENO");
				listKey.add("SHOPPERID_P");
				listKey.add("SCOMPANYP");
				listKey.add("SHOPPERID");
				listKey.add("SCOMPANY");
				listKey.add("OUTTRADETIME");
				/*listKey.add("FEE_TYPE");*/
				listKey.add("SK_FEE");
				listKey.add("AMOUNT");
				listKey.add("COMMISSION");
				listKey.add("ARRIVALAMOUNT");
				listKey.add("PROFIT");
				try {
					ExcelUtils.downExcel(listData, listKey, listHead, "SK-BATCH", "刷卡分润批次信息", response);
					return null;
				} catch (Exception e) {
					e.printStackTrace();
					return null;
				}
			}
			request.setAttribute("list", listData);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"服务商刷卡批次详情查询错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}	
		return "subAgentProfit/skBatchDetailList";
	}
	
	/**
	 * 服务商D0提现批次查询
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=findAgentD0SplitList")
	public String findAgentD0SplitList(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform) throws BusinessException{
 		try{
			Users  sessionUser=(Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			if(sessionUser==null || StringUtils.isEmpty(Long.toString(sessionUser.getMerchantid()))){
				throw new BusinessException(ExceptionDefine.商户查询失败);
			}
			sform.setSessionUserNo(String.valueOf(sessionUser.getMerchantid()));
			//标识为D0批次
			sform.setTransType("2");
			if(sform.getEndDate() != null){
				Calendar c = Calendar.getInstance();
				c.setTime(sform.getEndDate());
				c.add(Calendar.DAY_OF_MONTH, 1);
				sform.setEndDate(c.getTime());
			}
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
			List<Map<String,Object>> listData = splitService.selectSubBatchList(sform);
			for(Map<String,Object> map:listData){
				Date d1 = (Date)map.get("END_DATE");
				Calendar cal=Calendar.getInstance();
				cal.add(Calendar.WEEK_OF_MONTH, -4);
				cal.set(Calendar.DAY_OF_WEEK, 2);
				Date d2 = cal.getTime();
				if(d1.compareTo(d2) == -1 ){
					map.put("detailFlag", "0");
				}else{
					map.put("detailFlag", "1");
				}
			}
			//如果是下载
			if("1".equals(sform.getIfDownload())){
				//判断是否操作最大条数
				if(((Page)request.getAttribute("page")).getTotalRows()>Constants.MAX_DOWNLOAD_SIZE){
					request.setAttribute(Constants.MESSAGE_KEY,"单次最大下载条数为" + Constants.MAX_DOWNLOAD_SIZE + "条");
					request.setAttribute("url","subSplit.htm?method=d0BatchDetailList&batchNo="
							+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
					return "/returnPage";
				}
				
				listData = splitService.downSubBatchList(sform);
				for(Map<String,Object> map:listData){
					 map.put("STATUS", Constants.convertMap.get(map.get("STATUS")));
				}
				List<String> listHead = new ArrayList<String>();
				listHead.add("结算批次号");
				listHead.add("结算日期");
				listHead.add("服务商编号");
				listHead.add("服务商名称");
				listHead.add("D0提现费率％");
				listHead.add("交易笔数/笔");
				listHead.add("交易总金额/元");
				listHead.add("分润总金额/元");
				listHead.add("状态");
				List<String> listKey = new ArrayList<String>();
				listKey.add("BATCH_NO");
				listKey.add("CREATE_DATE");
				listKey.add("SHOPPERIDP");
				listKey.add("SCOMPANY");
				listKey.add("D0_FEE");
				listKey.add("SUM_COUNT");
				listKey.add("SUM_AMOUNT");
				listKey.add("SUM_PROFIT");
				listKey.add("STATUS");
				try {
					ExcelUtils.downExcel(listData, listKey, listHead, "SK-BATCH", "刷卡分润批次信息", response);
					return null;
				} catch (Exception e) {
					e.printStackTrace();
					return null;
				}
			}
			request.setAttribute("list", listData);
			
 		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"服务商D0提现批次查询 错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		return "subAgentProfit/d0BatchList";
	}
	
	/**
	 * 服务商D0提现批次详情查询
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=d0BatchDetailList")
	public String d0BatchDetailList(HttpServletRequest request, HttpServletResponse response,
		SplitForm sform) throws BusinessException{
		try{
			request.setAttribute("batchNo", sform.getBatchNo());
			request.setAttribute("status", sform.getStatus());
			request.setAttribute("id", sform.getId());
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
			List<Map<String,Object>> listData = splitService.selectSplitList(sform);
			//如果是下载
			if("1".equals(sform.getIfDownload())){
				if(((Page)request.getAttribute("page")).getTotalRows()>Constants.MAX_DOWNLOAD_SIZE){
					request.setAttribute(Constants.MESSAGE_KEY,"单次最大下载条数为" + Constants.MAX_DOWNLOAD_SIZE + "条");
					request.setAttribute("url","subSplit.htm?method=d0BatchDetailList&batchNo="
							+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
					return "/returnPage";
				}
				listData = splitService.downSplitList(sform);
				for(Map<String,Object> map:listData){
					 String time = String.valueOf(map.get("OUTTRADETIME"));
					 map.put("OUTTRADETIME", time.substring(0, 4) + "-" + time.substring(4, 6) + "-" + time.substring(6, 8) + "-" 
							 + time.substring(8, 10) + ":" + time.substring(10, 12) + ":" + time.substring(12, 14));
				}
				List<String> listHead = new ArrayList<String>();
				listHead.add("订单号");
				listHead.add("服务商编号");
				listHead.add("服务商名称");
				listHead.add("商户号");
				listHead.add("商户名称");
				listHead.add("交易时间");
				/*listHead.add("费率类型");*/
				listHead.add("提现费率(％)");
				listHead.add("提现金额");
				listHead.add("手续费/元");
				listHead.add("到账金额/元");
				listHead.add("分润金额/元");
	
				List<String> listKey = new ArrayList<String>();
				listKey.add("OUTTRADENO");
				listKey.add("SHOPPERID_P");
				listKey.add("SCOMPANYP");
				listKey.add("SHOPPERID");
				listKey.add("SCOMPANY");
				listKey.add("OUTTRADETIME");
				/*listKey.add("FEE_TYPE");*/
				listKey.add("D0_FEE");
				listKey.add("AMOUNT");
				listKey.add("COMMISSION");
				listKey.add("ARRIVALAMOUNT");
				listKey.add("PROFIT");
				try {
					for(Map<String,Object> map:listData){
						map.put("FEE_TYPE", "0".equals(map.get("FEE_TYPE"))?"费率类":"封顶类");
					}
					ExcelUtils.downExcel(listData, listKey, listHead, "SK-BATCH", "刷卡分润批次信息", response);
					return null;
				} catch (Exception e) {
					e.printStackTrace();
					return null;
				}
			}
			request.setAttribute("list", listData);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"服务商D0提现批次详情查询错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		return "subAgentProfit/d0BatchDetailList";
	}
	
	/**
	 * 更新批次状态 
	 */
	@RequestMapping(params = "method=auditSplit")
	public String auditSplit(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform){
		try {
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
			splitService.updateStatusByBatchNo(sform);
			request.setAttribute(Constants.MESSAGE_KEY,"操作成功");
			if("d0".equals(sform.getType())){
				request.setAttribute("url","subSplit.htm?method=d0BatchDetailList&batchNo="
						+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
			}
			else if("sk".equals(sform.getType())){
				request.setAttribute("url","subSplit.htm?method=skBatchDetailList&batchNo="
						+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute(Constants.MESSAGE_KEY,"操作失败");
			if("d0".equals(sform.getType())){
				request.setAttribute("url","subSplit.htm?method=d0BatchDetailList&batchNo="
						+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
			}
			else if("sk".equals(sform.getType())){
				request.setAttribute("url","subSplit.htm?method=skBatchDetailList&batchNo="
						+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
			}
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		return "/returnPage";
	}
	
	/**
	 * 查看服务商疑议
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=toUpdateDoubt")
	public String toDoubt(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform) throws BusinessException{
		try{
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
			Map<String,Object> map = splitService.selectDoubt(sform);
			request.setAttribute("type", sform.getType());
			request.setAttribute("bat", map);
			request.setAttribute("batchNo", sform.getBatchNo());
			request.setAttribute("status", sform.getStatus());
			request.setAttribute("id", sform.getId());
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"查看服务商疑议错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		return "subAgentProfit/updateDoubt";
	}
	
	/**
	 * 更新疑议 
	 */
	@RequestMapping(params = "method=updateDoubt")
	public String updateDoubt(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform){
		try {
			sform.setStatus("6");
			String str = sform.getReplyHis();
			if(str != null && !"".equals(str) && !"null".equals(str)){
				sform.setReply(sform.getReplyHis() + " || " + sform.getReply());
			}
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
			splitService.updateDoubt(sform);
			DataSourceSwitch.clearDataSourceType();
			request.setAttribute(Constants.MESSAGE_KEY,"操作成功");
			if("d0".equals(sform.getType())){
				request.setAttribute("url","subSplit.htm?method=d0BatchDetailList&batchNo="
						+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
			}
			else if("sk".equals(sform.getType())){
				request.setAttribute("url","subSplit.htm?method=skBatchDetailList&batchNo="
						+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute(Constants.MESSAGE_KEY,"操作失败");
			if("d0".equals(sform.getType())){
				request.setAttribute("url","subSplit.htm?method=d0BatchDetailList&batchNo="
						+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
			}
			else if("sk".equals(sform.getType())){
				request.setAttribute("url","subSplit.htm?method=skBatchDetailList&batchNo="
						+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
			}
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		return "/returnPage";
	}
	
	/**
	 * 重新计算该批次的分润值
	 */
	@RequestMapping(params = "method=updateBatch")
	public String updateBatch(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform){
		
		try {
			//每个批次一小时只能重新计算一次。
			if(Constants.TIME_LIMIT.containsKey(sform.getBatchNo())){
				Date d1 = Constants.TIME_LIMIT.get(sform.getBatchNo());
				Date d2 = new Date();
				if((d2.getTime() - d1.getTime())/1000/60 < 60){
					request.setAttribute(Constants.MESSAGE_KEY,"单个批次每小时只能重新计算一次，还有" +
							(60 - (d2.getTime() - d1.getTime())/1000/60) + "分钟可重新计算！");
					if("d0".equals(sform.getType())){
						request.setAttribute("url","split.htm?method=d0BatchDetailList&batchNo="
								+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
					}
					else if("sk".equals(sform.getType())){
						request.setAttribute("url","split.htm?method=skBatchDetailList&batchNo="
								+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
					}
					return "/returnPage";
				}else{
					Constants.TIME_LIMIT.put(sform.getBatchNo(), new Date());
				}
			}else{
				Constants.TIME_LIMIT.put(sform.getBatchNo(), new Date());
			}
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
				//更新
				splitService.updateBatch(sform);
			request.setAttribute(Constants.MESSAGE_KEY,"操作成功");
			
			if("d0".equals(sform.getType())){
				request.setAttribute("url","subSplit.htm?method=d0BatchDetailList&batchNo="
						+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
			}
			else if("sk".equals(sform.getType())){
				request.setAttribute("url","subSplit.htm?method=skBatchDetailList&batchNo="
						+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute(Constants.MESSAGE_KEY,"操作失败");
			if("d0".equals(sform.getType())){
				request.setAttribute("url","subSplit.htm?method=d0BatchDetailList&batchNo="
						+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
			}
			else if("sk".equals(sform.getType())){
				request.setAttribute("url","subSplit.htm?method=skBatchDetailList&batchNo="
						+sform.getBatchNo()+"&status="+sform.getStatus()+"&id=" + sform.getId());
			}
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		return "/returnPage";
	}
	
	/**
	 * 批量更新批次状态
	 */
	@RequestMapping(params = "method=batchUpdate")
	public String batchUpdate(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform){
		try {
			if(sform.getIds() != null){
				String ids = sform.getIds();
				String[] idsArr = ids.substring(1, ids.length()).split(",");
				List<String> list = Arrays.asList(idsArr);
				Map<String,Object> param = new HashMap<String, Object>();
				param.put("status", sform.getStatus());
				param.put("list", list);
				DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
				splitService.batchUpdate(param);
			}
			request.setAttribute(Constants.MESSAGE_KEY,"操作成功");
			if("d0".equals(sform.getType())){
				request.setAttribute("url", "subSplit.htm?method=findAgentD0SplitList");
			}
			else if("sk".equals(sform.getType())){
				request.setAttribute("url", "subSplit.htm?method=findAgentSkSplitList");
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute(Constants.MESSAGE_KEY,"操作失败");
			if("d0".equals(sform.getType())){
				request.setAttribute("url", "subSplit.htm?method=findAgentD0SplitList");
			}
			else if("sk".equals(sform.getType())){
				request.setAttribute("url", "subSplit.htm?method=findAgentSkSplitList");
			}
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		return "/returnPage";
	}
	
	/**
	 * 服务商刷卡批次查询
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=findAgentSmSplitList")
	public String findAgentSmSplitList(HttpServletRequest request, HttpServletResponse response,
			SplitForm sform) throws BusinessException{
		try{
			Users  sessionUser=(Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			if(sessionUser==null || StringUtils.isEmpty(Long.toString(sessionUser.getMerchantid()))){
				throw new BusinessException(ExceptionDefine.商户查询失败);
			}
			sform.setSessionUserNo(String.valueOf(sessionUser.getMerchantid()));
			if(sform.getEndDate() != null){
				Calendar c = Calendar.getInstance();
				c.setTime(sform.getEndDate());
				c.add(Calendar.DAY_OF_MONTH, 1);
				sform.setEndDate(c.getTime());
			}
			DataSourceSwitch.setDataSourceType(Constants.DATASOURCE_INSTANCE.MPOS.name());
			List<Map<String,Object>> listData = splitService.selectSubBatchList(sform);
			for(Map<String,Object> map:listData){
				Date d1 = (Date)map.get("END_DATE");
				Calendar cal=Calendar.getInstance();
				cal.add(Calendar.WEEK_OF_MONTH, -4);
				cal.set(Calendar.DAY_OF_WEEK, 2);
				Date d2 = cal.getTime();
				if(d1.compareTo(d2) == -1 ){
					map.put("detailFlag", "0");
				}else{
					map.put("detailFlag", "1");
				}
			}
			//如果是下载
			if("1".equals(sform.getIfDownload())){
				//判断是否操作最大条数
				if(((Page)request.getAttribute("page")).getTotalRows()>Constants.MAX_DOWNLOAD_SIZE){
					request.setAttribute(Constants.MESSAGE_KEY,"单次最大下载条数为" + Constants.MAX_DOWNLOAD_SIZE + "条");
					request.setAttribute("url","subSplit.htm?method=findAgentSmSplitList");
					return "/returnPage";
				}
				listData = splitService.downSubBatchList(sform);
				for(Map<String,Object> map:listData){
					 map.put("STATUS", Constants.convertMap.get(map.get("STATUS")));
				}
				List<String> listHead = new ArrayList<String>();
				listHead.add("结算批次号");
				listHead.add("结算日期");
				listHead.add("服务商编号");
				listHead.add("服务商名称");
				listHead.add("交易笔数/笔");
				listHead.add("刷卡交易总金额/元");
				listHead.add("分润总金额/元");
				listHead.add("状态");
				List<String> listKey = new ArrayList<String>();
				listKey.add("BATCH_NO");
				listKey.add("CREATE_DATE");
				listKey.add("SHOPPERIDP");
				listKey.add("SCOMPANY");
				listKey.add("SUM_COUNT");
				listKey.add("SUM_AMOUNT");
				listKey.add("SUM_PROFIT");
				listKey.add("STATUS");
				try {
					ExcelUtils.downExcel(listData, listKey, listHead, "SM-BATCH", "扫码分润批次信息", response);
					return null;
				} catch (Exception e) {
					e.printStackTrace();
					return null;
				}
			}
			request.setAttribute("list", listData);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.其他错误,new String[]{"服务商刷卡批次查询错误"});
		}finally {
			DataSourceSwitch.clearDataSourceType();
		}
		
		return "subAgentProfit/smBatchList";
	}
	
}
