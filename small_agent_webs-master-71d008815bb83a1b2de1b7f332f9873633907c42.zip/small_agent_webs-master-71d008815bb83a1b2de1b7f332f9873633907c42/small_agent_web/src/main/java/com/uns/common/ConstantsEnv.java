package com.uns.common;

import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.util.AcmsMapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
public class ConstantsEnv {
	@Autowired
	public static AcmsMapUtils acmsMapUtils = new AcmsMapUtils();
	public static String getProperty(String key){
		String value = acmsMapUtils.getAcmsMap().get(key);
		if(null != value){
			return value;
		}
		return null;
	}



	public static final String TEST_URL = getProperty("test_url");

}
