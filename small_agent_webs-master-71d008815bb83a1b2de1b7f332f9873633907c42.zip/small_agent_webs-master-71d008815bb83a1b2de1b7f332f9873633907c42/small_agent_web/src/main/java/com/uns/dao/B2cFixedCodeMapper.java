package com.uns.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.Agent;
import com.uns.model.B2cFixedCode;
import com.uns.web.form.AgentForm;
import com.uns.web.form.AgentRatioForm;

@Repository
public interface B2cFixedCodeMapper extends BaseMapper<Object>{
	
	/**
	 * 固码入库列表
	 * @return
	 */
	public List<B2cFixedCode> findFixedCodeList(B2cFixedCode b2cFixedCode);
	/**
	 * 通过二维码编号查询
	 * @param qrCodeNo
	 * @return
	 */
	public B2cFixedCode findFixedCodeByParam(Map<String, Object> map);
	
	/**
	 * 批量插入
	 * @param bactList
	 */
	public void insertBatchModel(List<B2cFixedCode> bactList);
	/**
	 *  固码出库列表
	 * @param b2cFixedCode
	 * @return
	 */
	public List<B2cFixedCode> findFixedCodeOutList(B2cFixedCode b2cFixedCode);
	/**
	 * 批量出库
	 * @param bactList
	 */
	public void updateBatchModel(B2cFixedCode model);
	public int updateById(B2cFixedCode fixedCode);
	public List<B2cFixedCode> findFixedCodesByParam(B2cFixedCode b2cFixedCode);
	public void updateDefault(B2cFixedCode b2cFixedCode);
	public List<B2cFixedCode> findNoBindQrCode(Map map);
	public B2cFixedCode findModelByParam(B2cFixedCode b2cFixedCode);
	public List<B2cFixedCode> findModelByMerNo(String merchantid);		
	
}