package com.uns.dao;


import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import com.uns.web.form.AgentUserForm;

import org.springframework.stereotype.Repository;

import com.uns.model.Operator;
@Repository
public interface OperatorMapper {
	
     //运营后台登录
	public List findOperatorByCode(Map map);
    // 运营后台登录 修改最后登录时间
	public void  updateOperator(Operator operator);
	//添加商户
	public void addOperator(Map params);
	
	public Operator selectByOperatorIds(String shopperId);

    int deleteByPrimaryKey(BigDecimal id);

    int insert(Operator record);

    int insertSelective(Operator record);

    Operator selectByPrimaryKey(BigDecimal id);

    int updateByPrimaryKeySelective(Operator record);

    int updateByPrimaryKey(Operator record);
    /**
     * 获取操作员列表
     * @param form
     * @return
     */
    public List findOperatorList(AgentUserForm form );
    
    public List selectByUsersList(AgentUserForm form);
    
	public void deleteOperator(String usercode);
	
	public void updateUserByCode(Map params);
	
	public Operator findOperatorByShopperid(Long merchantid);
	
	public void updateUserByMerchantId(Operator user);
	
	public Operator selectUsersById(Long userId);
	
	public void update(Operator user);
	
	public Map getOperaterByUserName(String userName);
}