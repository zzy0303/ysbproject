package com.uns.model;

import java.io.Serializable;

public class MtOperateLog extends MtOperatepermit implements Serializable {
    private String logid;

    private String operatornum;

    private String ip;

    private String time;

    private String permitid;

    private String params;

    public String getLogid() {
        return logid;
    }

    public void setLogid(String logid) {
        this.logid = logid;
    }

    public String getOperatornum() {
        return operatornum;
    }

    public void setOperatornum(String operatornum) {
        this.operatornum = operatornum;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getPermitid() {
        return permitid;
    }

    public void setPermitid(String permitid) {
        this.permitid = permitid;
    }

    public String getParams() {
        return params;
    }

    public void setParams(String params) {
        this.params = params;
    }
}