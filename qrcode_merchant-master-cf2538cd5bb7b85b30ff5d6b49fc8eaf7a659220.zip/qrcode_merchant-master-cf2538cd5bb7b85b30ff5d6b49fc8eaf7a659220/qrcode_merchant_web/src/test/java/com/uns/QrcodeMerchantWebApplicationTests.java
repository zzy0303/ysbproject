package com.uns;

import com.uns.inf.acms.client.DynamicConfigLoader;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ImportResource;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
@ImportResource(locations = {"classpath:spring*.xml"})
public class QrcodeMerchantWebApplicationTests {

	@Test
	public void contextLoads() {
		System.out.println(DynamicConfigLoader.getByEnv("qrcode.datasource.url"));
	}

}
