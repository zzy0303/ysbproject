package com.uns.entity;

import java.math.BigDecimal;
import java.util.Date;

public class QrcodeRefund {
    private String id;

    private BigDecimal orderType;

    private String merchantCode;

    private String oriOrderNo;

    private String refundOrderNo;

    private BigDecimal status;

    private BigDecimal refundAmount;

    private BigDecimal realRefundAmount;

    private String remark;

    private String ext;

    private Date refundedTime;

    private Date createTime;

    private Date updateTime;

    private String resOrderNo;

    private String resCode;

    private String resMsg;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public BigDecimal getOrderType() {
        return orderType;
    }

    public void setOrderType(BigDecimal orderType) {
        this.orderType = orderType;
    }

    public String getMerchantCode() {
        return merchantCode;
    }

    public void setMerchantCode(String merchantCode) {
        this.merchantCode = merchantCode == null ? null : merchantCode.trim();
    }

    public String getOriOrderNo() {
        return oriOrderNo;
    }

    public void setOriOrderNo(String oriOrderNo) {
        this.oriOrderNo = oriOrderNo == null ? null : oriOrderNo.trim();
    }

    public String getRefundOrderNo() {
        return refundOrderNo;
    }

    public void setRefundOrderNo(String refundOrderNo) {
        this.refundOrderNo = refundOrderNo == null ? null : refundOrderNo.trim();
    }

    public BigDecimal getStatus() {
        return status;
    }

    public void setStatus(BigDecimal status) {
        this.status = status;
    }

    public BigDecimal getRefundAmount() {
        return refundAmount;
    }

    public void setRefundAmount(BigDecimal refundAmount) {
        this.refundAmount = refundAmount;
    }

    public BigDecimal getRealRefundAmount() {
        return realRefundAmount;
    }

    public void setRealRefundAmount(BigDecimal realRefundAmount) {
        this.realRefundAmount = realRefundAmount;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getExt() {
        return ext;
    }

    public void setExt(String ext) {
        this.ext = ext == null ? null : ext.trim();
    }

    public Date getRefundedTime() {
        return refundedTime;
    }

    public void setRefundedTime(Date refundedTime) {
        this.refundedTime = refundedTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getResOrderNo() {
        return resOrderNo;
    }

    public void setResOrderNo(String resOrderNo) {
        this.resOrderNo = resOrderNo == null ? null : resOrderNo.trim();
    }

    public String getResCode() {
        return resCode;
    }

    public void setResCode(String resCode) {
        this.resCode = resCode == null ? null : resCode.trim();
    }

    public String getResMsg() {
        return resMsg;
    }

    public void setResMsg(String resMsg) {
        this.resMsg = resMsg == null ? null : resMsg.trim();
    }
}