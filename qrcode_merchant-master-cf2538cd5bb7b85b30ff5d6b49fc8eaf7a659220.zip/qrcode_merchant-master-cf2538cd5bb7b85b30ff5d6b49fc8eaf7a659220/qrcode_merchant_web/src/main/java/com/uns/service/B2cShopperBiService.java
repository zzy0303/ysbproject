package com.uns.service;

import com.uns.dao.small.B2cShopperBiMapper;
import com.uns.entity.B2cShopperBi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/8/10
 * @Modifyed By:
 */
@Service
public class B2cShopperBiService {

    @Autowired
    private B2cShopperBiMapper b2cShopperBiMapper;

    public B2cShopperBi findShopperByTel(String tel) {
        return b2cShopperBiMapper.findShopperByTel(tel);
    }

    public B2cShopperBi findShopperByIdP(BigDecimal shopperidP) {
        return b2cShopperBiMapper.findShopperByIdP(shopperidP);
    }

}
