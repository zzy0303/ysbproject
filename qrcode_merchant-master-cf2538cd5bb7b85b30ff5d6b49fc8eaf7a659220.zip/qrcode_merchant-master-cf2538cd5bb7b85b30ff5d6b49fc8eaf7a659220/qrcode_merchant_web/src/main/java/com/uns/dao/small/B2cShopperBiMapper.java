package com.uns.dao.small;

import com.uns.entity.B2cShopperBi;
import org.apache.ibatis.annotations.Mapper;

import java.math.BigDecimal;

@Mapper
public interface B2cShopperBiMapper {

    int deleteByPrimaryKey(BigDecimal b2cShopperbiId);

    int insert(B2cShopperBi record);

    int insertSelective(B2cShopperBi record);

    B2cShopperBi selectByPrimaryKey(BigDecimal b2cShopperbiId);

    int updateByPrimaryKeySelective(B2cShopperBi record);

    int updateByPrimaryKey(B2cShopperBi record);

    B2cShopperBi findShopperByTel(String tel);

    B2cShopperBi findShopperByIdP(BigDecimal shopperidP);
}