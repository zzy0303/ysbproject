package com.uns.common.enums;

import org.apache.commons.lang3.StringUtils;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/8/15
 * @Modifyed By:
 */
public enum ErrorCodeEnum {

    验证码错误("0001", "验证码错误"),
    商户不存在("0002", "商户不存在"),
    密码错误("0003", "密码错误");


    ErrorCodeEnum(String code, String text) {
        this.code = code;
        this.text = text;
    }

    private String code;
    private String text;

    public String getText() {
        return text;
    }

    public String getCode() {
        return code;
    }

    public static ErrorCodeEnum fromCode(String code) {
        for (ErrorCodeEnum messageEnum : ErrorCodeEnum.values()) {
            if (StringUtils.equals(code, messageEnum.getCode())) {
                return messageEnum;
            }
        }
        return null;
    }

}
