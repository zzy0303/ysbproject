package com.uns.entity;

import com.uns.common.annotation.ExcelField;

import java.math.BigDecimal;
import java.util.Date;

public class TQrcodeRefund {
    private String id;

    private BigDecimal orderType;

    private String merchantCode;

    private String oriOrderNo;

    private String refundOrderNo;

    private BigDecimal status;

    private BigDecimal refundAmount;

    private BigDecimal realRefundAmount;

    private String remark;

    private String ext;

    private Date refundedTime;

    private Date createTime;

    private Date updateTime;

    private String resOrderNo;

    private String resCode;

    private String resMsg;

    private String smallMerchNo;

    private String name;

    private String scompany;

    private String srcId;

    private String cardType;

    private String cardTypeStr;

    private Date tranDate;

    private String statusStr;

    private String beginCreateTime;

    private String endCreateTime;

    private BigDecimal minRefundAmount;

    private BigDecimal maxRefundAmount;

    private BigDecimal minRealRefundAmount;

    private BigDecimal maxRealRefundAmount;

    private BigDecimal amountMax;

    private BigDecimal amountMin;

    private String tranDateBegin;

    private String tranDateEnd;

    @ExcelField(title = "收款方式", align = 1, sort = 9)
    public String getCardTypeStr() {
        return cardTypeStr;
    }

    public void setCardTypeStr(String cardTypeStr) {
        this.cardTypeStr = cardTypeStr;
    }

    public BigDecimal getMinRefundAmount() {
        return minRefundAmount;
    }

    public void setMinRefundAmount(BigDecimal minRefundAmount) {
        this.minRefundAmount = minRefundAmount;
    }

    public BigDecimal getMaxRefundAmount() {
        return maxRefundAmount;
    }

    public void setMaxRefundAmount(BigDecimal maxRefundAmount) {
        this.maxRefundAmount = maxRefundAmount;
    }

    public BigDecimal getMinRealRefundAmount() {
        return minRealRefundAmount;
    }

    public void setMinRealRefundAmount(BigDecimal minRealRefundAmount) {
        this.minRealRefundAmount = minRealRefundAmount;
    }

    public BigDecimal getMaxRealRefundAmount() {
        return maxRealRefundAmount;
    }

    public void setMaxRealRefundAmount(BigDecimal maxRealRefundAmount) {
        this.maxRealRefundAmount = maxRealRefundAmount;
    }

    @ExcelField(title = "商户名称", align = 1, sort = 2)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @ExcelField(title = "退款状态", align = 1, sort = 12)
    public String getStatusStr() {
        return statusStr;
    }

    public void setStatusStr(String statusStr) {
        this.statusStr = statusStr;
    }

    @ExcelField(title = "商户编号", align = 1, sort = 1)
    public String getSmallMerchNo() {
        return smallMerchNo;
    }

    public void setSmallMerchNo(String smallMerchNo) {
        this.smallMerchNo = smallMerchNo;
    }

    @ExcelField(title = "所属服务商", align = 1, sort = 3)
    public String getScompany() {
        return scompany;
    }

    public void setScompany(String scompany) {
        this.scompany = scompany;
    }

    @ExcelField(title = "服务商编号", align = 1, sort = 4)
    public String getSrcId() {
        return srcId;
    }

    public void setSrcId(String srcId) {
        this.srcId = srcId;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    @ExcelField(title = "交易时间", align = 1, sort = 10)
    public Date getTranDate() {
        return tranDate;
    }

    public void setTranDate(Date tranDate) {
        this.tranDate = tranDate;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public BigDecimal getOrderType() {
        return orderType;
    }

    public void setOrderType(BigDecimal orderType) {
        this.orderType = orderType;
    }

    public String getMerchantCode() {
        return merchantCode;
    }

    public void setMerchantCode(String merchantCode) {
        this.merchantCode = merchantCode == null ? null : merchantCode.trim();
    }

    public String getBeginCreateTime() {
        return beginCreateTime;
    }

    public void setBeginCreateTime(String beginCreateTime) {
        this.beginCreateTime = beginCreateTime;
    }

    public String getEndCreateTime() {
        return endCreateTime;
    }

    public void setEndCreateTime(String endCreateTime) {
        this.endCreateTime = endCreateTime;
    }

    @ExcelField(title = "订单编号", align = 1, sort = 5)
    public String getOriOrderNo() {
        return oriOrderNo;
    }

    public void setOriOrderNo(String oriOrderNo) {
        this.oriOrderNo = oriOrderNo == null ? null : oriOrderNo.trim();
    }

    @ExcelField(title = "退款订单号", align = 1, sort = 6)
    public String getRefundOrderNo() {
        return refundOrderNo;
    }

    public void setRefundOrderNo(String refundOrderNo) {
        this.refundOrderNo = refundOrderNo == null ? null : refundOrderNo.trim();
    }

    public BigDecimal getStatus() {
        return status;
    }

    public void setStatus(BigDecimal status) {
        this.status = status;
    }

    @ExcelField(title = "总订单金额", align = 1, sort = 8)
    public BigDecimal getRefundAmount() {
        return refundAmount;
    }

    public void setRefundAmount(BigDecimal refundAmount) {
        this.refundAmount = refundAmount;
    }

    @ExcelField(title = "退款金额", align = 1, sort = 7)
    public BigDecimal getRealRefundAmount() {
        return realRefundAmount;
    }

    public void setRealRefundAmount(BigDecimal realRefundAmount) {
        this.realRefundAmount = realRefundAmount;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getExt() {
        return ext;
    }

    public void setExt(String ext) {
        this.ext = ext == null ? null : ext.trim();
    }

    public Date getRefundedTime() {
        return refundedTime;
    }

    public void setRefundedTime(Date refundedTime) {
        this.refundedTime = refundedTime;
    }

    @ExcelField(title = "退款时间", align = 1, sort = 11)
    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getResOrderNo() {
        return resOrderNo;
    }

    public void setResOrderNo(String resOrderNo) {
        this.resOrderNo = resOrderNo == null ? null : resOrderNo.trim();
    }

    public String getResCode() {
        return resCode;
    }

    public void setResCode(String resCode) {
        this.resCode = resCode == null ? null : resCode.trim();
    }

    public String getResMsg() {
        return resMsg;
    }

    public void setResMsg(String resMsg) {
        this.resMsg = resMsg == null ? null : resMsg.trim();
    }

    public BigDecimal getAmountMax() {
        return amountMax;
    }

    public void setAmountMax(BigDecimal amountMax) {
        this.amountMax = amountMax;
    }

    public BigDecimal getAmountMin() {
        return amountMin;
    }

    public void setAmountMin(BigDecimal amountMin) {
        this.amountMin = amountMin;
    }

    public String getTranDateBegin() {
        return tranDateBegin;
    }

    public void setTranDateBegin(String tranDateBegin) {
        this.tranDateBegin = tranDateBegin;
    }

    public String getTranDateEnd() {
        return tranDateEnd;
    }

    public void setTranDateEnd(String tranDateEnd) {
        this.tranDateEnd = tranDateEnd;
    }
}