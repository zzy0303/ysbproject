package com.uns.model;

import com.uns.common.annotation.ExcelField;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/8/15
 * @Modifyed By:
 */
public class QrcodeTransModel {

    private String smallMerchNo;

    private String shopperName;

    private String agentName;

    private String shopperidP;

    private String orderId;

    private BigDecimal amount;

    private String cardType;

    private Date tranDate;

    private String orderStatus;

    @ExcelField(title="商户编号", align = 1, sort = 1)
    public String getSmallMerchNo() {
        return smallMerchNo;
    }

    public void setSmallMerchNo(String smallMerchNo) {
        this.smallMerchNo = smallMerchNo;
    }

    @ExcelField(title="商户名称", align = 1, sort = 2)
    public String getShopperName() {
        return shopperName;
    }

    public void setShopperName(String shopperName) {
        this.shopperName = shopperName;
    }

    @ExcelField(title="所属服务商", align = 1, sort = 3)
    public String getAgentName() {
        return agentName;
    }

    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }

    @ExcelField(title="服务商编号", align = 1, sort = 4)
    public String getShopperidP() {
        return shopperidP;
    }

    public void setShopperidP(String shopperidP) {
        this.shopperidP = shopperidP;
    }

    @ExcelField(title="订单编号", align = 1, sort = 5)
    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    @ExcelField(title="交易金额", align = 1, sort = 6)
    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    @ExcelField(title="收款方式", align = 1, sort = 7)
    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    @ExcelField(title="交易时间", align = 1, sort = 8)
    public Date getTranDate() {
        return tranDate;
    }

    public void setTranDate(Date tranDate) {
        this.tranDate = tranDate;
    }

    @ExcelField(title="交易状态", align = 1, sort = 9)
    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }
}
