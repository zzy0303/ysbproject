package com.uns.web;

import com.uns.common.Constants;
import com.uns.common.excel.ExportExcel;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.entity.B2cShopperBi;
import com.uns.entity.QrcodeTrans;
import com.uns.model.QrcodeTransModel;
import com.uns.service.QrcodeTransService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/8/15
 * @Modifyed By:
 */
@Controller
@RequestMapping(value = "qrcodeTrans")
public class QrcodeTransController extends BaseController {

    @Autowired
    private QrcodeTransService qrcodeTransService;

    /**
     * 交易汇总查询
     * @param qrcodeTrans
     * @param request
     * @return
     */
    @RequestMapping(value = "/qrcodeTransCollect")
    public String qrcodeTransCollect(QrcodeTrans qrcodeTrans, HttpServletRequest request, Model model) {
        try {
            B2cShopperBi b2cShopperBi = (B2cShopperBi) request.getSession().getAttribute(Constants.SESSION_KEY_SHOPPER);
            qrcodeTrans.setSmallMerchNo(b2cShopperBi.getShopperid().toString());
            Map<String, Object> transCollect = qrcodeTransService.qrcodeTransCollect(qrcodeTrans);
            request.setAttribute("transCollect", transCollect);
        } catch (Exception e) {
            logger.error("交易汇总查询失败,{}", e.getMessage());
            addErrorMsg(model, "交易汇总查询失败");
        }
        return "trans/transCollect";
    }

    /**
     * 交易记录查询
     * @param qrcodeTrans
     * @param request
     * @return
     */
    @RequestMapping(value = "/queryTransList")
    public String queryTransList(QrcodeTrans qrcodeTrans, HttpServletRequest request, Model model) {
        try {
            B2cShopperBi b2cShopperBi = (B2cShopperBi) request.getSession().getAttribute(Constants.SESSION_KEY_SHOPPER);
            qrcodeTrans.setSmallMerchNo(b2cShopperBi.getShopperid().toString());
            PageContext.initPageSize(Constants.QUERY_SIZE);
            List<QrcodeTransModel> qrcodeTransList = qrcodeTransService.queryTransList(qrcodeTrans);
            request.setAttribute("qrcodeTrans", qrcodeTrans);
            request.setAttribute("list", qrcodeTransList);
        } catch (Exception e) {
            logger.error("交易记录查询失败,{}", e.getMessage());
            addErrorMsg(model, "交易记录查询失败");
        }
        return "trans/transList";
    }

    /**
     * 跳转交易记录导出页
     * @param qrcodeTrans
     * @param request
     * @param model
     * @return
     */
    @RequestMapping(value = "/queryTransPageList")
    public String queryTransPageList(QrcodeTrans qrcodeTrans, HttpServletRequest request, Model model) {
        try {
            B2cShopperBi b2cShopperBi = (B2cShopperBi) request.getSession().getAttribute(Constants.SESSION_KEY_SHOPPER);
            qrcodeTrans.setSmallMerchNo(b2cShopperBi.getShopperid().toString());
            Page page  = new Page();
            page.setPageSize(Constants.EXCEL_SIZE);
            PageContext context = PageContext.getContext();
            BeanUtils.copyProperties(page, context);
            context.setPagination(true);
            qrcodeTransService.queryTransList(qrcodeTrans);
            BeanUtils.copyProperties(context, page);
            request.setAttribute("qrcodeTrans", qrcodeTrans);
            request.setAttribute("page",page);
        } catch (Exception e) {
            logger.error("跳转交易记录导出页失败,{}", e.getMessage());
            addErrorMsg(model, "跳转交易记录导出页失败");
        }
        return "trans/transListPage";
    }

    /**
     * 交易记录导出
     * @param qrcodeTrans
     * @param request
     * @param response
     */
    @RequestMapping(value = "/exportTransPageList")
    public void exportTransPageList(QrcodeTrans qrcodeTrans, HttpServletRequest request, HttpServletResponse response) {
        try {
            B2cShopperBi b2cShopperBi = (B2cShopperBi) request.getSession().getAttribute(Constants.SESSION_KEY_SHOPPER);
            qrcodeTrans.setSmallMerchNo(b2cShopperBi.getShopperid().toString());
            PageContext.initPageSize(Constants.EXCEL_SIZE);
            List<QrcodeTransModel> qrcodeTransList = qrcodeTransService.queryTransList(qrcodeTrans);
            String fileName = "交易记录.xlsx";
            new ExportExcel("交易记录", QrcodeTransModel.class).setDataList(qrcodeTransList).write(response, fileName).dispose();
        } catch (Exception e) {
            logger.error("交易记录导出失败,{}", e.getMessage());
        }
    }

}
