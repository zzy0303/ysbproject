package com.uns.config;

import com.alibaba.druid.pool.xa.DruidXADataSource;
import com.atomikos.jdbc.AtomikosDataSourceBean;
import com.uns.common.interceptor.PaginationInterceptor;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;

import javax.sql.DataSource;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/8/14
 * @Modifyed By:
 */
@Configuration
@MapperScan(basePackages = {"com.uns.dao.small"}, sqlSessionTemplateRef = "sqlSessionTemplateSmall")
public class DataSourceSmallConfig {

    @Bean(name = "dataSourceSmall")
    @Primary
    @ConfigurationProperties(prefix = "small.datasource")
    public DataSource dataSourceSmall(DataSourceSmallProperties dataSourceSmallProperties) {
        DruidXADataSource dataSource = new DruidXADataSource();
        BeanUtils.copyProperties(dataSourceSmallProperties, dataSource);
        AtomikosDataSourceBean dataSourceBean = new AtomikosDataSourceBean();
        dataSourceBean.setXaDataSource(dataSource);
        dataSourceBean.setUniqueResourceName("dataSourceSmall");
        return dataSourceBean;
    }

    @Bean
    public SqlSessionFactory sqlSessionFactorySmall(@Qualifier("dataSourceSmall") DataSource dataSource) throws Exception {
        SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
        bean.setDataSource(dataSource);
        ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        bean.setMapperLocations(resolver.getResources("classpath*:/mapper/small/**Mapper.xml"));
        bean.setPlugins(new Interceptor[]{paginationInterceptor()});
        return bean.getObject();
    }

    @Bean
    public SqlSessionTemplate sqlSessionTemplateSmall(@Qualifier("sqlSessionFactorySmall") SqlSessionFactory sqlSessionFactory) {
        SqlSessionTemplate sqlSessionTemplate = new SqlSessionTemplate(sqlSessionFactory);
        return sqlSessionTemplate;
    }

    @Bean
    public PaginationInterceptor paginationInterceptor() {
        return new PaginationInterceptor();
    }

}
