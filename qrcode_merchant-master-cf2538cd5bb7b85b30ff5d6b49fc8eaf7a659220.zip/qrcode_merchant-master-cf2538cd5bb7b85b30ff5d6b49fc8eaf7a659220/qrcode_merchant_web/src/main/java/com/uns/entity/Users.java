package com.uns.entity;

import java.math.BigDecimal;
import java.util.Date;

public class Users {
    private BigDecimal id;

    private BigDecimal merchantid;

    private String username;

    private String password;

    private BigDecimal enabled;

    private Date createdate;

    private Date lastlogindate;

    private BigDecimal results;

    private BigDecimal attempttimes;

    private BigDecimal locked;

    private String permits;

    private String roledesc;

    private String demo;

    private String usercode;

    private BigDecimal subsidiarid;

    private String isAgent;

    private String loginname;

    private String tel;

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public BigDecimal getMerchantid() {
        return merchantid;
    }

    public void setMerchantid(BigDecimal merchantid) {
        this.merchantid = merchantid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username == null ? null : username.trim();
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }

    public BigDecimal getEnabled() {
        return enabled;
    }

    public void setEnabled(BigDecimal enabled) {
        this.enabled = enabled;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public Date getLastlogindate() {
        return lastlogindate;
    }

    public void setLastlogindate(Date lastlogindate) {
        this.lastlogindate = lastlogindate;
    }

    public BigDecimal getResults() {
        return results;
    }

    public void setResults(BigDecimal results) {
        this.results = results;
    }

    public BigDecimal getAttempttimes() {
        return attempttimes;
    }

    public void setAttempttimes(BigDecimal attempttimes) {
        this.attempttimes = attempttimes;
    }

    public BigDecimal getLocked() {
        return locked;
    }

    public void setLocked(BigDecimal locked) {
        this.locked = locked;
    }

    public String getPermits() {
        return permits;
    }

    public void setPermits(String permits) {
        this.permits = permits == null ? null : permits.trim();
    }

    public String getRoledesc() {
        return roledesc;
    }

    public void setRoledesc(String roledesc) {
        this.roledesc = roledesc == null ? null : roledesc.trim();
    }

    public String getDemo() {
        return demo;
    }

    public void setDemo(String demo) {
        this.demo = demo == null ? null : demo.trim();
    }

    public String getUsercode() {
        return usercode;
    }

    public void setUsercode(String usercode) {
        this.usercode = usercode == null ? null : usercode.trim();
    }

    public BigDecimal getSubsidiarid() {
        return subsidiarid;
    }

    public void setSubsidiarid(BigDecimal subsidiarid) {
        this.subsidiarid = subsidiarid;
    }

    public String getIsAgent() {
        return isAgent;
    }

    public void setIsAgent(String isAgent) {
        this.isAgent = isAgent == null ? null : isAgent.trim();
    }

    public String getLoginname() {
        return loginname;
    }

    public void setLoginname(String loginname) {
        this.loginname = loginname == null ? null : loginname.trim();
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel == null ? null : tel.trim();
    }
}