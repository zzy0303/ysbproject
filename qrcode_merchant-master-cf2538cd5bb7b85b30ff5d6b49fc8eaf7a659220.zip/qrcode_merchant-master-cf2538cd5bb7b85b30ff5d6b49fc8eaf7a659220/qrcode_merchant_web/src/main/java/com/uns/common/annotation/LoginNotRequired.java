package com.uns.common.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @Author: KaiFeng
 * @Description:在不需登录验证的Controller方法上使用此注解
 * @Date: 2018/8/10
 * @Modifyed By:
 */
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface LoginNotRequired {
}
