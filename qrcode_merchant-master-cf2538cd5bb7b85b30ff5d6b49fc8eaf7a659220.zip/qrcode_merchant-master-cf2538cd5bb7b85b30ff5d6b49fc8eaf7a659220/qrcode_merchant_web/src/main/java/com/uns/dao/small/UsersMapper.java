package com.uns.dao.small;

import com.uns.entity.Users;
import org.apache.ibatis.annotations.Mapper;

import java.math.BigDecimal;

@Mapper
public interface UsersMapper {

    int deleteByPrimaryKey(BigDecimal id);

    int insert(Users record);

    int insertSelective(Users record);

    Users selectByPrimaryKey(BigDecimal id);

    int updateByPrimaryKeySelective(Users record);

    int updateByPrimaryKey(Users record);

    Users findUsersByParam(Users users);
}