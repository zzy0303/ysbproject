package com.uns.service;

import com.uns.dao.qrcode.QrcodeRefundMapper;
import com.uns.dao.qrcode.QrcodeTransMapper;
import com.uns.entity.QrcodeTrans;
import com.uns.model.QrcodeTransModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/8/14
 * @Modifyed By:
 */
@Service
public class QrcodeTransService {

    @Autowired
    private QrcodeTransMapper qrcodeTransMapper;

    @Autowired
    private QrcodeRefundMapper qrcodeRefundMapper;

    public Map<String, Object> qrcodeTransCollect(QrcodeTrans qrcodeTrans) throws Exception {
        Map<String, Object> transMap = new HashMap<>();
        Map<String, Object> chargeMap = qrcodeTransMapper.queryChargeCollect(qrcodeTrans);
        Map<String, Object> refundMap = qrcodeRefundMapper.queryRefundCollect(qrcodeTrans);
        transMap.putAll(chargeMap);
        transMap.putAll(refundMap);
        transMap.put("AMOUNT", new BigDecimal(String.valueOf(chargeMap.get("CHARGE_AMOUNT")))
                .subtract(new BigDecimal(String.valueOf(refundMap.get("REFUND_AMOUNT")))));
        return transMap;
    }

    public List<QrcodeTransModel> queryTransList(QrcodeTrans qrcodeTrans) throws Exception {
        return qrcodeTransMapper.queryTransList(qrcodeTrans);
    }
}
