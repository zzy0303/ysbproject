package com.uns.service;

import com.uns.dao.qrcode.TQrcodeRefundMapper;
import com.uns.entity.TQrcodeRefund;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/8/7
 * @Modifyed By:
 */
@Service
public class TqrcodeRefundService {

    @Autowired
    private TQrcodeRefundMapper tQrcodeRefundMapper;

    @Transactional
    public List<TQrcodeRefund> queryRefundList(TQrcodeRefund tQrcodeRefund) throws Exception {
        return tQrcodeRefundMapper.queryRefundList(tQrcodeRefund);
    }
}
