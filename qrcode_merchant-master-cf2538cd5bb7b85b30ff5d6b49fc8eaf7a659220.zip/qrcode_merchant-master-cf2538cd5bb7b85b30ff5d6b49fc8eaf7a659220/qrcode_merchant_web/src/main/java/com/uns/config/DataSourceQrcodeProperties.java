package com.uns.config;

import lombok.Data;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/8/10
 * @Modifyed By:
 */
@Data
public class DataSourceQrcodeProperties {

    private String driverClassName;
    private String url;
    private String username;
    private String password;
    private int initialSize;
    private int minIdle;
    private int maxActive;
    private int maxWait;
    private int timeBetweenEvictionRunsMillis;
    private int minEvictableIdleTimeMillis;
    private String validationQuery;
    private boolean testWhileIdle;
    private boolean testOnBorrow;
    private boolean testOnReturn;
    private int minPoolSize;
    private int maxPoolSize;
    private int borrowConnectionTimeout;
    private String testQuery;
    private int maintenanceInterval;
}
