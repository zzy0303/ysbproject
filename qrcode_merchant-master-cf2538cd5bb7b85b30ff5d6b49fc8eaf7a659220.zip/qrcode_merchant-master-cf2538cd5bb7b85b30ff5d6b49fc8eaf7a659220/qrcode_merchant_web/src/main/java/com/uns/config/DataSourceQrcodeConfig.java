package com.uns.config;

import com.alibaba.druid.pool.xa.DruidXADataSource;
import com.atomikos.jdbc.AtomikosDataSourceBean;
import com.uns.common.interceptor.PaginationInterceptor;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;

import javax.sql.DataSource;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/8/14
 * @Modifyed By:
 */
@Configuration
@MapperScan(basePackages = {"com.uns.dao.qrcode"}, sqlSessionTemplateRef = "sqlSessionTemplateQrcode")
public class DataSourceQrcodeConfig {

    @Bean(name = "dataSourceQrcode")
    @ConfigurationProperties(prefix = "qrcode.datasource")
    public DataSource dataSourceQrcode(DataSourceQrcodeProperties dataSourceQrcodeProperties) {
        DruidXADataSource dataSource = new DruidXADataSource();
        BeanUtils.copyProperties(dataSourceQrcodeProperties, dataSource);
        AtomikosDataSourceBean dataSourceBean = new AtomikosDataSourceBean();
        dataSourceBean.setXaDataSource(dataSource);
        dataSourceBean.setUniqueResourceName("dataSourceQrcode");
        return dataSourceBean;
    }

    @Bean
    public SqlSessionFactory sqlSessionFactoryQrcode(@Qualifier("dataSourceQrcode") DataSource dataSource) throws Exception {
        SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
        bean.setDataSource(dataSource);
        ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        bean.setMapperLocations(resolver.getResources("classpath*:/mapper/qrcode/**Mapper.xml"));
        bean.setPlugins(new Interceptor[]{paginationInterceptor()});
        return bean.getObject();
    }

    @Bean
    public SqlSessionTemplate sqlSessionTemplateQrcode(@Qualifier("sqlSessionFactoryQrcode") SqlSessionFactory sqlSessionFactory) {
        SqlSessionTemplate sqlSessionTemplate = new SqlSessionTemplate(sqlSessionFactory);
        return sqlSessionTemplate;
    }

    @Bean
    public PaginationInterceptor paginationInterceptor() {
        return new PaginationInterceptor();
    }

}
