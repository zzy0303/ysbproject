package com.uns.web;

import com.uns.common.Constants;
import com.uns.common.excel.ExportExcel;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.entity.B2cShopperBi;
import com.uns.entity.TQrcodeRefund;
import com.uns.service.TqrcodeRefundService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @Author: KaiFeng
 * @Description: 退款记录管理
 * @Date: 2018/8/7
 * @Modifyed By:
 */
@Controller
@RequestMapping(value = "refundTrans")
public class RefundController extends BaseController{

    @Autowired
    private TqrcodeRefundService tqrcodeRefundService;

    /**
     * 退款记录查询
     * @param tQrcodeRefund
     * @param request
     * @param model
     * @return
     */
    @RequestMapping(value = "queryRefundList")
    public String queryRefundList(TQrcodeRefund tQrcodeRefund, HttpServletRequest request, Model model) {
        try {
            B2cShopperBi b2cShopperBi = (B2cShopperBi) request.getSession().getAttribute(Constants.SESSION_KEY_SHOPPER);
            PageContext.initPageSize(Constants.QUERY_SIZE);
            tQrcodeRefund.setSmallMerchNo(b2cShopperBi.getShopperid().toString());
            List<TQrcodeRefund> list = tqrcodeRefundService.queryRefundList(tQrcodeRefund);
            request.setAttribute("tQrcodeRefund", tQrcodeRefund);
            request.setAttribute("list", list);
        } catch (Exception e) {
            logger.error("退款记录查询失败,{}", e.getMessage());
            addErrorMsg(model, "退款记录查询失败");
        }
        return "trans/refundList";
    }

    /**
     * 跳转退款记录下载页面
     * @param tQrcodeRefund
     * @param request
     * @return
     */
    @RequestMapping(value = "findRefundPageList")
    public String findRefundPageList(TQrcodeRefund tQrcodeRefund, HttpServletRequest request) {
        try {
            B2cShopperBi b2cShopperBi = (B2cShopperBi) request.getSession().getAttribute(Constants.SESSION_KEY_SHOPPER);
            tQrcodeRefund.setSmallMerchNo(b2cShopperBi.getShopperid().toString());
            Page page  = new Page();
            page.setPageSize(Constants.EXCEL_SIZE);
            PageContext context = PageContext.getContext();
            BeanUtils.copyProperties(page, context);
            context.setPagination(true);
            tqrcodeRefundService.queryRefundList(tQrcodeRefund);
            BeanUtils.copyProperties(context, page);
            request.setAttribute("tQrcodeRefund",tQrcodeRefund);
            request.setAttribute("page",page);
        } catch (Exception e) {
            logger.error("跳转退款记录导出页面失败,{}", e.getMessage());
        }
        return "trans/refundListPage";
    }

    /**
     * 退款记录导出
     * @param tQrcodeRefund
     * @param request
     * @param response
     */
    @RequestMapping(value = "exportRefundPageList")
    public void exportRefundPageList(TQrcodeRefund tQrcodeRefund, HttpServletRequest request, HttpServletResponse response) {
        try {
            PageContext.initPageSize(Constants.EXCEL_SIZE);
            B2cShopperBi b2cShopperBi = (B2cShopperBi) request.getSession().getAttribute(Constants.SESSION_KEY_SHOPPER);
            tQrcodeRefund.setSmallMerchNo(b2cShopperBi.getShopperid().toString());
            List<TQrcodeRefund> list = tqrcodeRefundService.queryRefundList(tQrcodeRefund);
            String fileName = "退款记录.xlsx";
            new ExportExcel("退款记录", TQrcodeRefund.class).setDataList(list).write(response, fileName).dispose();
        } catch (Exception e) {
            logger.error("退款记录导出失败,{}", e.getMessage());
        }
    }

}
