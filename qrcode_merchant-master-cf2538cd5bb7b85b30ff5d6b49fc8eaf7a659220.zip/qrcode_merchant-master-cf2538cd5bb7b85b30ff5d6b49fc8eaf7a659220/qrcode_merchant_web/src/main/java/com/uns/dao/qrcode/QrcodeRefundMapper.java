package com.uns.dao.qrcode;

import com.uns.entity.QrcodeRefund;
import com.uns.entity.QrcodeTrans;
import org.apache.ibatis.annotations.Mapper;

import java.util.Map;

@Mapper
public interface QrcodeRefundMapper {

    int deleteByPrimaryKey(String id);

    int insert(QrcodeRefund record);

    int insertSelective(QrcodeRefund record);

    QrcodeRefund selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(QrcodeRefund record);

    int updateByPrimaryKey(QrcodeRefund record);

    Map<String, Object> queryRefundCollect(QrcodeTrans qrcodeTrans);
}