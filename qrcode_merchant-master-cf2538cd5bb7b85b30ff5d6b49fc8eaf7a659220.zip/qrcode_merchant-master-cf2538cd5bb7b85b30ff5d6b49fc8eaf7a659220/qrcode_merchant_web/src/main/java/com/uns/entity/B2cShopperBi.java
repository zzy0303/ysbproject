package com.uns.entity;

import java.math.BigDecimal;
import java.util.Date;

public class B2cShopperBi {
    private BigDecimal b2cShopperbiId;

    private String scompany;

    private String gateway;

    private String sqcode;

    private String synum;

    private String sicp;

    private String saddress;

    private String szip;

    private String smanager;

    private String srelation;

    private String semail;

    private String stel;

    private String sfax;

    private String shandset;

    private String sqq;

    private String smsn;

    private BigDecimal sshopertypeid;

    private String sshopertype;

    private String sdomain;

    private BigDecimal sshoppertypeid;

    private String sshoppertype;

    private String scity;

    private String city;

    private String sprovince;

    private String province;

    private BigDecimal transactid;

    private String transactsub;

    private String transact;

    private String operid;

    private String oper;

    private BigDecimal sifpactid;

    private String sifpact;

    private String spactoperid;

    private String spactoper;

    private BigDecimal sisnew;

    private String shoppercallingid;

    private String shoppercalling;

    private Date created;

    private BigDecimal shopperid;

    private BigDecimal sagentid;

    private BigDecimal battalion;

    private BigDecimal persentid;

    private BigDecimal ifattend;

    private BigDecimal ifagent;

    private BigDecimal shoppertypeid;

    private String srelationcredno;

    private String legalentity;

    private String srelationcrededate;

    private String legalecredno;

    private String legalecrededate;

    private String synumedate;

    private String licenseno;

    private String taxregisterno;

    private String remark;

    private String upoperid;

    private String upoper;

    private Date updated;

    private String grade;

    private String division;

    private BigDecimal shopperidP;

    private String shortname;

    private String levels;

    private String muserid;

    private String mpassword;

    private BigDecimal ifvalid;

    private String accountBankDictval;

    private String accountBankName;

    private String accountBankProv;

    private String accountBankClientName;

    private String accountBankNo;

    private String accountBankOther;

    private String settleFrequency;

    private String isTopMerchant;

    private BigDecimal topFee;

    private BigDecimal minSettleMoney;

    private String ysbscompany;

    private String settlementtype;

    private String ysbno;

    private BigDecimal photoId;

    private String merchantType;

    private String name;

    private String idNo;

    private String licenseNo;

    private String industry;

    private String billProvince;

    private String billProvinceCode;

    private String billCity;

    private String billCityCode;

    private String billAddress;

    private String billName;

    private String isSupportT0;

    private String isIcApplyT0;

    private BigDecimal t0Fee;

    private BigDecimal t0SingleDayLimit;

    private String accountBankProvCode;

    private String accountBankCity;

    private String accountBankCityCode;

    private String reportResource;

    private String evicenumber;

    private String shopperlimit;

    private String fee;

    private String orgNo;

    private String parentId;

    private String factoringNo;

    private BigDecimal t1Fee;

    private String t0type;

    private String merchantKey;

    private String cardtype;

    private String t1type;

    private BigDecimal t0fixedamount;

    private BigDecimal t0topamount;

    private BigDecimal t0additionfee;

    private BigDecimal t0minamount;

    private BigDecimal t0maxamount;

    private BigDecimal t1topamount;

    private String firstFeeCheck;

    private String firstFeeCheckResult;

    private String feeRecheck;

    private String feeRecheckResult;

    private String ifactivated;

    private String currentLocation;

    private String longitude;

    private String latitude;

    private String aiflag;

    private Date openMposCreateDate;

    private Date ifactivadate;

    private String qrpayno;

    private String qrpayMerchantKey;

    private String hfFlag;

    private String hfPsam;

    private String fixedQrcodeUrl;

    private String fixedQrcodeFlag;

    private String hfPsamD0;

    private String fixQrcodeCustomerName;

    private String isExternalRevenue;

    private String settleType;

    private BigDecimal creditlines;

    private String agentProfitRatio;

    private String merchProfitRatio1;

    private String merchProfitRatio2;

    private String merchProfitRatio3;

    private String profitowner;

    private String inviteCode;

    private String inviteCodeP;

    private String blackflag;

    private String sex;

    private String nation;

    private String signunit;

    private String usefullife;

    private String creditBankDictval;

    private String creditBankNo;

    private String creditBankUsefullife;

    private String accountBankClientTel;

    private String creditBankClientTel;

    private String creditBankClientName;

    private String creditBankClientIdNo;

    private String checkstatus;

    private Date toManualauditDate;

    private String visualCheckStatus;

    private String notPassReason;

    private String notPassStep;

    private Date birthday;

    private String licensename;

    private String accountBankLineNumber;

    private String licenseaddress;

    public BigDecimal getB2cShopperbiId() {
        return b2cShopperbiId;
    }

    public void setB2cShopperbiId(BigDecimal b2cShopperbiId) {
        this.b2cShopperbiId = b2cShopperbiId;
    }

    public String getScompany() {
        return scompany;
    }

    public void setScompany(String scompany) {
        this.scompany = scompany == null ? null : scompany.trim();
    }

    public String getGateway() {
        return gateway;
    }

    public void setGateway(String gateway) {
        this.gateway = gateway == null ? null : gateway.trim();
    }

    public String getSqcode() {
        return sqcode;
    }

    public void setSqcode(String sqcode) {
        this.sqcode = sqcode == null ? null : sqcode.trim();
    }

    public String getSynum() {
        return synum;
    }

    public void setSynum(String synum) {
        this.synum = synum == null ? null : synum.trim();
    }

    public String getSicp() {
        return sicp;
    }

    public void setSicp(String sicp) {
        this.sicp = sicp == null ? null : sicp.trim();
    }

    public String getSaddress() {
        return saddress;
    }

    public void setSaddress(String saddress) {
        this.saddress = saddress == null ? null : saddress.trim();
    }

    public String getSzip() {
        return szip;
    }

    public void setSzip(String szip) {
        this.szip = szip == null ? null : szip.trim();
    }

    public String getSmanager() {
        return smanager;
    }

    public void setSmanager(String smanager) {
        this.smanager = smanager == null ? null : smanager.trim();
    }

    public String getSrelation() {
        return srelation;
    }

    public void setSrelation(String srelation) {
        this.srelation = srelation == null ? null : srelation.trim();
    }

    public String getSemail() {
        return semail;
    }

    public void setSemail(String semail) {
        this.semail = semail == null ? null : semail.trim();
    }

    public String getStel() {
        return stel;
    }

    public void setStel(String stel) {
        this.stel = stel == null ? null : stel.trim();
    }

    public String getSfax() {
        return sfax;
    }

    public void setSfax(String sfax) {
        this.sfax = sfax == null ? null : sfax.trim();
    }

    public String getShandset() {
        return shandset;
    }

    public void setShandset(String shandset) {
        this.shandset = shandset == null ? null : shandset.trim();
    }

    public String getSqq() {
        return sqq;
    }

    public void setSqq(String sqq) {
        this.sqq = sqq == null ? null : sqq.trim();
    }

    public String getSmsn() {
        return smsn;
    }

    public void setSmsn(String smsn) {
        this.smsn = smsn == null ? null : smsn.trim();
    }

    public BigDecimal getSshopertypeid() {
        return sshopertypeid;
    }

    public void setSshopertypeid(BigDecimal sshopertypeid) {
        this.sshopertypeid = sshopertypeid;
    }

    public String getSshopertype() {
        return sshopertype;
    }

    public void setSshopertype(String sshopertype) {
        this.sshopertype = sshopertype == null ? null : sshopertype.trim();
    }

    public String getSdomain() {
        return sdomain;
    }

    public void setSdomain(String sdomain) {
        this.sdomain = sdomain == null ? null : sdomain.trim();
    }

    public BigDecimal getSshoppertypeid() {
        return sshoppertypeid;
    }

    public void setSshoppertypeid(BigDecimal sshoppertypeid) {
        this.sshoppertypeid = sshoppertypeid;
    }

    public String getSshoppertype() {
        return sshoppertype;
    }

    public void setSshoppertype(String sshoppertype) {
        this.sshoppertype = sshoppertype == null ? null : sshoppertype.trim();
    }

    public String getScity() {
        return scity;
    }

    public void setScity(String scity) {
        this.scity = scity == null ? null : scity.trim();
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city == null ? null : city.trim();
    }

    public String getSprovince() {
        return sprovince;
    }

    public void setSprovince(String sprovince) {
        this.sprovince = sprovince == null ? null : sprovince.trim();
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province == null ? null : province.trim();
    }

    public BigDecimal getTransactid() {
        return transactid;
    }

    public void setTransactid(BigDecimal transactid) {
        this.transactid = transactid;
    }

    public String getTransactsub() {
        return transactsub;
    }

    public void setTransactsub(String transactsub) {
        this.transactsub = transactsub == null ? null : transactsub.trim();
    }

    public String getTransact() {
        return transact;
    }

    public void setTransact(String transact) {
        this.transact = transact == null ? null : transact.trim();
    }

    public String getOperid() {
        return operid;
    }

    public void setOperid(String operid) {
        this.operid = operid == null ? null : operid.trim();
    }

    public String getOper() {
        return oper;
    }

    public void setOper(String oper) {
        this.oper = oper == null ? null : oper.trim();
    }

    public BigDecimal getSifpactid() {
        return sifpactid;
    }

    public void setSifpactid(BigDecimal sifpactid) {
        this.sifpactid = sifpactid;
    }

    public String getSifpact() {
        return sifpact;
    }

    public void setSifpact(String sifpact) {
        this.sifpact = sifpact == null ? null : sifpact.trim();
    }

    public String getSpactoperid() {
        return spactoperid;
    }

    public void setSpactoperid(String spactoperid) {
        this.spactoperid = spactoperid == null ? null : spactoperid.trim();
    }

    public String getSpactoper() {
        return spactoper;
    }

    public void setSpactoper(String spactoper) {
        this.spactoper = spactoper == null ? null : spactoper.trim();
    }

    public BigDecimal getSisnew() {
        return sisnew;
    }

    public void setSisnew(BigDecimal sisnew) {
        this.sisnew = sisnew;
    }

    public String getShoppercallingid() {
        return shoppercallingid;
    }

    public void setShoppercallingid(String shoppercallingid) {
        this.shoppercallingid = shoppercallingid == null ? null : shoppercallingid.trim();
    }

    public String getShoppercalling() {
        return shoppercalling;
    }

    public void setShoppercalling(String shoppercalling) {
        this.shoppercalling = shoppercalling == null ? null : shoppercalling.trim();
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public BigDecimal getShopperid() {
        return shopperid;
    }

    public void setShopperid(BigDecimal shopperid) {
        this.shopperid = shopperid;
    }

    public BigDecimal getSagentid() {
        return sagentid;
    }

    public void setSagentid(BigDecimal sagentid) {
        this.sagentid = sagentid;
    }

    public BigDecimal getBattalion() {
        return battalion;
    }

    public void setBattalion(BigDecimal battalion) {
        this.battalion = battalion;
    }

    public BigDecimal getPersentid() {
        return persentid;
    }

    public void setPersentid(BigDecimal persentid) {
        this.persentid = persentid;
    }

    public BigDecimal getIfattend() {
        return ifattend;
    }

    public void setIfattend(BigDecimal ifattend) {
        this.ifattend = ifattend;
    }

    public BigDecimal getIfagent() {
        return ifagent;
    }

    public void setIfagent(BigDecimal ifagent) {
        this.ifagent = ifagent;
    }

    public BigDecimal getShoppertypeid() {
        return shoppertypeid;
    }

    public void setShoppertypeid(BigDecimal shoppertypeid) {
        this.shoppertypeid = shoppertypeid;
    }

    public String getSrelationcredno() {
        return srelationcredno;
    }

    public void setSrelationcredno(String srelationcredno) {
        this.srelationcredno = srelationcredno == null ? null : srelationcredno.trim();
    }

    public String getLegalentity() {
        return legalentity;
    }

    public void setLegalentity(String legalentity) {
        this.legalentity = legalentity == null ? null : legalentity.trim();
    }

    public String getSrelationcrededate() {
        return srelationcrededate;
    }

    public void setSrelationcrededate(String srelationcrededate) {
        this.srelationcrededate = srelationcrededate == null ? null : srelationcrededate.trim();
    }

    public String getLegalecredno() {
        return legalecredno;
    }

    public void setLegalecredno(String legalecredno) {
        this.legalecredno = legalecredno == null ? null : legalecredno.trim();
    }

    public String getLegalecrededate() {
        return legalecrededate;
    }

    public void setLegalecrededate(String legalecrededate) {
        this.legalecrededate = legalecrededate == null ? null : legalecrededate.trim();
    }

    public String getSynumedate() {
        return synumedate;
    }

    public void setSynumedate(String synumedate) {
        this.synumedate = synumedate == null ? null : synumedate.trim();
    }

    public String getLicenseno() {
        return licenseno;
    }

    public void setLicenseno(String licenseno) {
        this.licenseno = licenseno == null ? null : licenseno.trim();
    }

    public String getTaxregisterno() {
        return taxregisterno;
    }

    public void setTaxregisterno(String taxregisterno) {
        this.taxregisterno = taxregisterno == null ? null : taxregisterno.trim();
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getUpoperid() {
        return upoperid;
    }

    public void setUpoperid(String upoperid) {
        this.upoperid = upoperid == null ? null : upoperid.trim();
    }

    public String getUpoper() {
        return upoper;
    }

    public void setUpoper(String upoper) {
        this.upoper = upoper == null ? null : upoper.trim();
    }

    public Date getUpdated() {
        return updated;
    }

    public void setUpdated(Date updated) {
        this.updated = updated;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade == null ? null : grade.trim();
    }

    public String getDivision() {
        return division;
    }

    public void setDivision(String division) {
        this.division = division == null ? null : division.trim();
    }

    public BigDecimal getShopperidP() {
        return shopperidP;
    }

    public void setShopperidP(BigDecimal shopperidP) {
        this.shopperidP = shopperidP;
    }

    public String getShortname() {
        return shortname;
    }

    public void setShortname(String shortname) {
        this.shortname = shortname == null ? null : shortname.trim();
    }

    public String getLevels() {
        return levels;
    }

    public void setLevels(String levels) {
        this.levels = levels == null ? null : levels.trim();
    }

    public String getMuserid() {
        return muserid;
    }

    public void setMuserid(String muserid) {
        this.muserid = muserid == null ? null : muserid.trim();
    }

    public String getMpassword() {
        return mpassword;
    }

    public void setMpassword(String mpassword) {
        this.mpassword = mpassword == null ? null : mpassword.trim();
    }

    public BigDecimal getIfvalid() {
        return ifvalid;
    }

    public void setIfvalid(BigDecimal ifvalid) {
        this.ifvalid = ifvalid;
    }

    public String getAccountBankDictval() {
        return accountBankDictval;
    }

    public void setAccountBankDictval(String accountBankDictval) {
        this.accountBankDictval = accountBankDictval == null ? null : accountBankDictval.trim();
    }

    public String getAccountBankName() {
        return accountBankName;
    }

    public void setAccountBankName(String accountBankName) {
        this.accountBankName = accountBankName == null ? null : accountBankName.trim();
    }

    public String getAccountBankProv() {
        return accountBankProv;
    }

    public void setAccountBankProv(String accountBankProv) {
        this.accountBankProv = accountBankProv == null ? null : accountBankProv.trim();
    }

    public String getAccountBankClientName() {
        return accountBankClientName;
    }

    public void setAccountBankClientName(String accountBankClientName) {
        this.accountBankClientName = accountBankClientName == null ? null : accountBankClientName.trim();
    }

    public String getAccountBankNo() {
        return accountBankNo;
    }

    public void setAccountBankNo(String accountBankNo) {
        this.accountBankNo = accountBankNo == null ? null : accountBankNo.trim();
    }

    public String getAccountBankOther() {
        return accountBankOther;
    }

    public void setAccountBankOther(String accountBankOther) {
        this.accountBankOther = accountBankOther == null ? null : accountBankOther.trim();
    }

    public String getSettleFrequency() {
        return settleFrequency;
    }

    public void setSettleFrequency(String settleFrequency) {
        this.settleFrequency = settleFrequency == null ? null : settleFrequency.trim();
    }

    public String getIsTopMerchant() {
        return isTopMerchant;
    }

    public void setIsTopMerchant(String isTopMerchant) {
        this.isTopMerchant = isTopMerchant == null ? null : isTopMerchant.trim();
    }

    public BigDecimal getTopFee() {
        return topFee;
    }

    public void setTopFee(BigDecimal topFee) {
        this.topFee = topFee;
    }

    public BigDecimal getMinSettleMoney() {
        return minSettleMoney;
    }

    public void setMinSettleMoney(BigDecimal minSettleMoney) {
        this.minSettleMoney = minSettleMoney;
    }

    public String getYsbscompany() {
        return ysbscompany;
    }

    public void setYsbscompany(String ysbscompany) {
        this.ysbscompany = ysbscompany == null ? null : ysbscompany.trim();
    }

    public String getSettlementtype() {
        return settlementtype;
    }

    public void setSettlementtype(String settlementtype) {
        this.settlementtype = settlementtype == null ? null : settlementtype.trim();
    }

    public String getYsbno() {
        return ysbno;
    }

    public void setYsbno(String ysbno) {
        this.ysbno = ysbno == null ? null : ysbno.trim();
    }

    public BigDecimal getPhotoId() {
        return photoId;
    }

    public void setPhotoId(BigDecimal photoId) {
        this.photoId = photoId;
    }

    public String getMerchantType() {
        return merchantType;
    }

    public void setMerchantType(String merchantType) {
        this.merchantType = merchantType == null ? null : merchantType.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getIdNo() {
        return idNo;
    }

    public void setIdNo(String idNo) {
        this.idNo = idNo == null ? null : idNo.trim();
    }

    public String getLicenseNo() {
        return licenseNo;
    }

    public void setLicenseNo(String licenseNo) {
        this.licenseNo = licenseNo == null ? null : licenseNo.trim();
    }

    public String getIndustry() {
        return industry;
    }

    public void setIndustry(String industry) {
        this.industry = industry == null ? null : industry.trim();
    }

    public String getBillProvince() {
        return billProvince;
    }

    public void setBillProvince(String billProvince) {
        this.billProvince = billProvince == null ? null : billProvince.trim();
    }

    public String getBillProvinceCode() {
        return billProvinceCode;
    }

    public void setBillProvinceCode(String billProvinceCode) {
        this.billProvinceCode = billProvinceCode == null ? null : billProvinceCode.trim();
    }

    public String getBillCity() {
        return billCity;
    }

    public void setBillCity(String billCity) {
        this.billCity = billCity == null ? null : billCity.trim();
    }

    public String getBillCityCode() {
        return billCityCode;
    }

    public void setBillCityCode(String billCityCode) {
        this.billCityCode = billCityCode == null ? null : billCityCode.trim();
    }

    public String getBillAddress() {
        return billAddress;
    }

    public void setBillAddress(String billAddress) {
        this.billAddress = billAddress == null ? null : billAddress.trim();
    }

    public String getBillName() {
        return billName;
    }

    public void setBillName(String billName) {
        this.billName = billName == null ? null : billName.trim();
    }

    public String getIsSupportT0() {
        return isSupportT0;
    }

    public void setIsSupportT0(String isSupportT0) {
        this.isSupportT0 = isSupportT0 == null ? null : isSupportT0.trim();
    }

    public String getIsIcApplyT0() {
        return isIcApplyT0;
    }

    public void setIsIcApplyT0(String isIcApplyT0) {
        this.isIcApplyT0 = isIcApplyT0 == null ? null : isIcApplyT0.trim();
    }

    public BigDecimal getT0Fee() {
        return t0Fee;
    }

    public void setT0Fee(BigDecimal t0Fee) {
        this.t0Fee = t0Fee;
    }

    public BigDecimal getT0SingleDayLimit() {
        return t0SingleDayLimit;
    }

    public void setT0SingleDayLimit(BigDecimal t0SingleDayLimit) {
        this.t0SingleDayLimit = t0SingleDayLimit;
    }

    public String getAccountBankProvCode() {
        return accountBankProvCode;
    }

    public void setAccountBankProvCode(String accountBankProvCode) {
        this.accountBankProvCode = accountBankProvCode == null ? null : accountBankProvCode.trim();
    }

    public String getAccountBankCity() {
        return accountBankCity;
    }

    public void setAccountBankCity(String accountBankCity) {
        this.accountBankCity = accountBankCity == null ? null : accountBankCity.trim();
    }

    public String getAccountBankCityCode() {
        return accountBankCityCode;
    }

    public void setAccountBankCityCode(String accountBankCityCode) {
        this.accountBankCityCode = accountBankCityCode == null ? null : accountBankCityCode.trim();
    }

    public String getReportResource() {
        return reportResource;
    }

    public void setReportResource(String reportResource) {
        this.reportResource = reportResource == null ? null : reportResource.trim();
    }

    public String getEvicenumber() {
        return evicenumber;
    }

    public void setEvicenumber(String evicenumber) {
        this.evicenumber = evicenumber == null ? null : evicenumber.trim();
    }

    public String getShopperlimit() {
        return shopperlimit;
    }

    public void setShopperlimit(String shopperlimit) {
        this.shopperlimit = shopperlimit == null ? null : shopperlimit.trim();
    }

    public String getFee() {
        return fee;
    }

    public void setFee(String fee) {
        this.fee = fee == null ? null : fee.trim();
    }

    public String getOrgNo() {
        return orgNo;
    }

    public void setOrgNo(String orgNo) {
        this.orgNo = orgNo == null ? null : orgNo.trim();
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId == null ? null : parentId.trim();
    }

    public String getFactoringNo() {
        return factoringNo;
    }

    public void setFactoringNo(String factoringNo) {
        this.factoringNo = factoringNo == null ? null : factoringNo.trim();
    }

    public BigDecimal getT1Fee() {
        return t1Fee;
    }

    public void setT1Fee(BigDecimal t1Fee) {
        this.t1Fee = t1Fee;
    }

    public String getT0type() {
        return t0type;
    }

    public void setT0type(String t0type) {
        this.t0type = t0type == null ? null : t0type.trim();
    }

    public String getMerchantKey() {
        return merchantKey;
    }

    public void setMerchantKey(String merchantKey) {
        this.merchantKey = merchantKey == null ? null : merchantKey.trim();
    }

    public String getCardtype() {
        return cardtype;
    }

    public void setCardtype(String cardtype) {
        this.cardtype = cardtype == null ? null : cardtype.trim();
    }

    public String getT1type() {
        return t1type;
    }

    public void setT1type(String t1type) {
        this.t1type = t1type == null ? null : t1type.trim();
    }

    public BigDecimal getT0fixedamount() {
        return t0fixedamount;
    }

    public void setT0fixedamount(BigDecimal t0fixedamount) {
        this.t0fixedamount = t0fixedamount;
    }

    public BigDecimal getT0topamount() {
        return t0topamount;
    }

    public void setT0topamount(BigDecimal t0topamount) {
        this.t0topamount = t0topamount;
    }

    public BigDecimal getT0additionfee() {
        return t0additionfee;
    }

    public void setT0additionfee(BigDecimal t0additionfee) {
        this.t0additionfee = t0additionfee;
    }

    public BigDecimal getT0minamount() {
        return t0minamount;
    }

    public void setT0minamount(BigDecimal t0minamount) {
        this.t0minamount = t0minamount;
    }

    public BigDecimal getT0maxamount() {
        return t0maxamount;
    }

    public void setT0maxamount(BigDecimal t0maxamount) {
        this.t0maxamount = t0maxamount;
    }

    public BigDecimal getT1topamount() {
        return t1topamount;
    }

    public void setT1topamount(BigDecimal t1topamount) {
        this.t1topamount = t1topamount;
    }

    public String getFirstFeeCheck() {
        return firstFeeCheck;
    }

    public void setFirstFeeCheck(String firstFeeCheck) {
        this.firstFeeCheck = firstFeeCheck == null ? null : firstFeeCheck.trim();
    }

    public String getFirstFeeCheckResult() {
        return firstFeeCheckResult;
    }

    public void setFirstFeeCheckResult(String firstFeeCheckResult) {
        this.firstFeeCheckResult = firstFeeCheckResult == null ? null : firstFeeCheckResult.trim();
    }

    public String getFeeRecheck() {
        return feeRecheck;
    }

    public void setFeeRecheck(String feeRecheck) {
        this.feeRecheck = feeRecheck == null ? null : feeRecheck.trim();
    }

    public String getFeeRecheckResult() {
        return feeRecheckResult;
    }

    public void setFeeRecheckResult(String feeRecheckResult) {
        this.feeRecheckResult = feeRecheckResult == null ? null : feeRecheckResult.trim();
    }

    public String getIfactivated() {
        return ifactivated;
    }

    public void setIfactivated(String ifactivated) {
        this.ifactivated = ifactivated == null ? null : ifactivated.trim();
    }

    public String getCurrentLocation() {
        return currentLocation;
    }

    public void setCurrentLocation(String currentLocation) {
        this.currentLocation = currentLocation == null ? null : currentLocation.trim();
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude == null ? null : longitude.trim();
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude == null ? null : latitude.trim();
    }

    public String getAiflag() {
        return aiflag;
    }

    public void setAiflag(String aiflag) {
        this.aiflag = aiflag == null ? null : aiflag.trim();
    }

    public Date getOpenMposCreateDate() {
        return openMposCreateDate;
    }

    public void setOpenMposCreateDate(Date openMposCreateDate) {
        this.openMposCreateDate = openMposCreateDate;
    }

    public Date getIfactivadate() {
        return ifactivadate;
    }

    public void setIfactivadate(Date ifactivadate) {
        this.ifactivadate = ifactivadate;
    }

    public String getQrpayno() {
        return qrpayno;
    }

    public void setQrpayno(String qrpayno) {
        this.qrpayno = qrpayno == null ? null : qrpayno.trim();
    }

    public String getQrpayMerchantKey() {
        return qrpayMerchantKey;
    }

    public void setQrpayMerchantKey(String qrpayMerchantKey) {
        this.qrpayMerchantKey = qrpayMerchantKey == null ? null : qrpayMerchantKey.trim();
    }

    public String getHfFlag() {
        return hfFlag;
    }

    public void setHfFlag(String hfFlag) {
        this.hfFlag = hfFlag == null ? null : hfFlag.trim();
    }

    public String getHfPsam() {
        return hfPsam;
    }

    public void setHfPsam(String hfPsam) {
        this.hfPsam = hfPsam == null ? null : hfPsam.trim();
    }

    public String getFixedQrcodeUrl() {
        return fixedQrcodeUrl;
    }

    public void setFixedQrcodeUrl(String fixedQrcodeUrl) {
        this.fixedQrcodeUrl = fixedQrcodeUrl == null ? null : fixedQrcodeUrl.trim();
    }

    public String getFixedQrcodeFlag() {
        return fixedQrcodeFlag;
    }

    public void setFixedQrcodeFlag(String fixedQrcodeFlag) {
        this.fixedQrcodeFlag = fixedQrcodeFlag == null ? null : fixedQrcodeFlag.trim();
    }

    public String getHfPsamD0() {
        return hfPsamD0;
    }

    public void setHfPsamD0(String hfPsamD0) {
        this.hfPsamD0 = hfPsamD0 == null ? null : hfPsamD0.trim();
    }

    public String getFixQrcodeCustomerName() {
        return fixQrcodeCustomerName;
    }

    public void setFixQrcodeCustomerName(String fixQrcodeCustomerName) {
        this.fixQrcodeCustomerName = fixQrcodeCustomerName == null ? null : fixQrcodeCustomerName.trim();
    }

    public String getIsExternalRevenue() {
        return isExternalRevenue;
    }

    public void setIsExternalRevenue(String isExternalRevenue) {
        this.isExternalRevenue = isExternalRevenue == null ? null : isExternalRevenue.trim();
    }

    public String getSettleType() {
        return settleType;
    }

    public void setSettleType(String settleType) {
        this.settleType = settleType == null ? null : settleType.trim();
    }

    public BigDecimal getCreditlines() {
        return creditlines;
    }

    public void setCreditlines(BigDecimal creditlines) {
        this.creditlines = creditlines;
    }

    public String getAgentProfitRatio() {
        return agentProfitRatio;
    }

    public void setAgentProfitRatio(String agentProfitRatio) {
        this.agentProfitRatio = agentProfitRatio == null ? null : agentProfitRatio.trim();
    }

    public String getMerchProfitRatio1() {
        return merchProfitRatio1;
    }

    public void setMerchProfitRatio1(String merchProfitRatio1) {
        this.merchProfitRatio1 = merchProfitRatio1 == null ? null : merchProfitRatio1.trim();
    }

    public String getMerchProfitRatio2() {
        return merchProfitRatio2;
    }

    public void setMerchProfitRatio2(String merchProfitRatio2) {
        this.merchProfitRatio2 = merchProfitRatio2 == null ? null : merchProfitRatio2.trim();
    }

    public String getMerchProfitRatio3() {
        return merchProfitRatio3;
    }

    public void setMerchProfitRatio3(String merchProfitRatio3) {
        this.merchProfitRatio3 = merchProfitRatio3 == null ? null : merchProfitRatio3.trim();
    }

    public String getProfitowner() {
        return profitowner;
    }

    public void setProfitowner(String profitowner) {
        this.profitowner = profitowner == null ? null : profitowner.trim();
    }

    public String getInviteCode() {
        return inviteCode;
    }

    public void setInviteCode(String inviteCode) {
        this.inviteCode = inviteCode == null ? null : inviteCode.trim();
    }

    public String getInviteCodeP() {
        return inviteCodeP;
    }

    public void setInviteCodeP(String inviteCodeP) {
        this.inviteCodeP = inviteCodeP == null ? null : inviteCodeP.trim();
    }

    public String getBlackflag() {
        return blackflag;
    }

    public void setBlackflag(String blackflag) {
        this.blackflag = blackflag == null ? null : blackflag.trim();
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex == null ? null : sex.trim();
    }

    public String getNation() {
        return nation;
    }

    public void setNation(String nation) {
        this.nation = nation == null ? null : nation.trim();
    }

    public String getSignunit() {
        return signunit;
    }

    public void setSignunit(String signunit) {
        this.signunit = signunit == null ? null : signunit.trim();
    }

    public String getUsefullife() {
        return usefullife;
    }

    public void setUsefullife(String usefullife) {
        this.usefullife = usefullife == null ? null : usefullife.trim();
    }

    public String getCreditBankDictval() {
        return creditBankDictval;
    }

    public void setCreditBankDictval(String creditBankDictval) {
        this.creditBankDictval = creditBankDictval == null ? null : creditBankDictval.trim();
    }

    public String getCreditBankNo() {
        return creditBankNo;
    }

    public void setCreditBankNo(String creditBankNo) {
        this.creditBankNo = creditBankNo == null ? null : creditBankNo.trim();
    }

    public String getCreditBankUsefullife() {
        return creditBankUsefullife;
    }

    public void setCreditBankUsefullife(String creditBankUsefullife) {
        this.creditBankUsefullife = creditBankUsefullife == null ? null : creditBankUsefullife.trim();
    }

    public String getAccountBankClientTel() {
        return accountBankClientTel;
    }

    public void setAccountBankClientTel(String accountBankClientTel) {
        this.accountBankClientTel = accountBankClientTel == null ? null : accountBankClientTel.trim();
    }

    public String getCreditBankClientTel() {
        return creditBankClientTel;
    }

    public void setCreditBankClientTel(String creditBankClientTel) {
        this.creditBankClientTel = creditBankClientTel == null ? null : creditBankClientTel.trim();
    }

    public String getCreditBankClientName() {
        return creditBankClientName;
    }

    public void setCreditBankClientName(String creditBankClientName) {
        this.creditBankClientName = creditBankClientName == null ? null : creditBankClientName.trim();
    }

    public String getCreditBankClientIdNo() {
        return creditBankClientIdNo;
    }

    public void setCreditBankClientIdNo(String creditBankClientIdNo) {
        this.creditBankClientIdNo = creditBankClientIdNo == null ? null : creditBankClientIdNo.trim();
    }

    public String getCheckstatus() {
        return checkstatus;
    }

    public void setCheckstatus(String checkstatus) {
        this.checkstatus = checkstatus == null ? null : checkstatus.trim();
    }

    public Date getToManualauditDate() {
        return toManualauditDate;
    }

    public void setToManualauditDate(Date toManualauditDate) {
        this.toManualauditDate = toManualauditDate;
    }

    public String getVisualCheckStatus() {
        return visualCheckStatus;
    }

    public void setVisualCheckStatus(String visualCheckStatus) {
        this.visualCheckStatus = visualCheckStatus == null ? null : visualCheckStatus.trim();
    }

    public String getNotPassReason() {
        return notPassReason;
    }

    public void setNotPassReason(String notPassReason) {
        this.notPassReason = notPassReason == null ? null : notPassReason.trim();
    }

    public String getNotPassStep() {
        return notPassStep;
    }

    public void setNotPassStep(String notPassStep) {
        this.notPassStep = notPassStep == null ? null : notPassStep.trim();
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getLicensename() {
        return licensename;
    }

    public void setLicensename(String licensename) {
        this.licensename = licensename == null ? null : licensename.trim();
    }

    public String getAccountBankLineNumber() {
        return accountBankLineNumber;
    }

    public void setAccountBankLineNumber(String accountBankLineNumber) {
        this.accountBankLineNumber = accountBankLineNumber == null ? null : accountBankLineNumber.trim();
    }

    public String getLicenseaddress() {
        return licenseaddress;
    }

    public void setLicenseaddress(String licenseaddress) {
        this.licenseaddress = licenseaddress == null ? null : licenseaddress.trim();
    }
}