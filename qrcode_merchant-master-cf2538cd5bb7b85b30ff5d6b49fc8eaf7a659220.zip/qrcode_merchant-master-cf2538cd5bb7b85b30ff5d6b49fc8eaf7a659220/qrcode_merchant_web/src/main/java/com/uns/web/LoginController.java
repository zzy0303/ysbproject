package com.uns.web;

import com.uns.common.Constants;
import com.uns.common.annotation.LoginNotRequired;
import com.uns.common.enums.ErrorCodeEnum;
import com.uns.common.exception.BusinessException;
import com.uns.common.util.Md5Encrypt;
import com.uns.entity.B2cShopperBi;
import com.uns.entity.Users;
import com.uns.service.B2cShopperBiService;
import com.uns.service.UsersService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/8/9
 * @Modifyed By:
 */
@Controller
public class LoginController extends BaseController {

    @Autowired
    private UsersService usersService;

    @Autowired
    private B2cShopperBiService b2cShopperBiService;

    @LoginNotRequired
    @RequestMapping(value = "/login")
    public String login (HttpServletRequest request, HttpServletResponse response, RedirectAttributes redirectAttributes, String password, String verycode, String tel){
        try {
            Users sessionUser = (Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
            if (null != sessionUser){
                request.getRequestDispatcher("/home").forward(request, response);
                return null;
            }

            if(StringUtils.isEmpty(verycode)){
                return "redirect:/";
            }
            if (!verycode.equals( request.getSession().getAttribute(Constants.SESSION_VERIFY_CODE))) {
                throw new BusinessException(ErrorCodeEnum.验证码错误.getText());
            }

            Users users = usersService.findUsersByTel(tel);
            if (null == users){
                throw new BusinessException(ErrorCodeEnum.商户不存在.getText());
            }

            B2cShopperBi b2cShopperBi = b2cShopperBiService.findShopperByTel(tel);
            if (null == b2cShopperBi){
                throw new BusinessException(ErrorCodeEnum.商户不存在.getText());
            }
            if (StringUtils.isNotEmpty(password)){
                if (!Md5Encrypt.md5(password).equals(users.getPassword())){
                    throw new BusinessException(ErrorCodeEnum.密码错误.getText());
                }
            }
            B2cShopperBi agent = null;
            if (StringUtils.isNotEmpty(b2cShopperBi.getShopperidP().toString())){
                agent = b2cShopperBiService.findShopperByIdP(b2cShopperBi.getShopperidP());
            }
            users.setUsername(b2cShopperBi.getName());
            request.getSession().setAttribute(Constants.SESSION_KEY_USER, users);
            request.getSession().setAttribute(Constants.SESSION_KEY_SHOPPER, b2cShopperBi);
            request.getSession().setAttribute(Constants.SESSION_KEY_AGENT, agent);
        } catch (Exception e) {
            logger.error("登录失败,{}", e.getMessage());
            addErrorMsg(redirectAttributes, "登录失败," + e.getMessage());
            return "redirect:/";
        }
        return "home";
    }

    /**
     * 跳转到主界面
     *
     * @return
     */
    @RequestMapping(value = "/home")
    public String home() {
        return "home";
    }

    /**
     * 跳转到主界面
     *
     * @return
     */
    @RequestMapping(value = "/logout")
    public String logout(HttpServletRequest request) {
        request.getSession().invalidate();
        return "index";
    }

}
