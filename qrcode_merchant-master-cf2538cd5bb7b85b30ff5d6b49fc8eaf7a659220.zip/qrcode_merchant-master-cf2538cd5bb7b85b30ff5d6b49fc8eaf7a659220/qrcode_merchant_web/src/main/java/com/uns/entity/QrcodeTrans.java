package com.uns.entity;

import java.math.BigDecimal;

public class QrcodeTrans {
    private String id;

    private String proVer;

    private String msgType;

    private String orderId;

    private String payWay;

    private String orderStatus;

    private String traceNo;

    private String subject;

    private String merchantCode;

    private String smzfMsgId;

    private String qrCode;

    private BigDecimal fee;

    private String reqDate;

    private String tranDate;

    private String tranDateBegin;

    private String tranDateEnd;

    private String bankDate;

    private String smallMerchNo;

    private String customerNo;

    private String commitionId;

    private BigDecimal amount;

    private BigDecimal amountMax;

    private BigDecimal amountMin;

    private String d0Flag;

    private String settleDate;

    private String orderDesc;

    private String operatorId;

    private String storeId;

    private String terminalId;

    private String limitPay;

    private String respType;

    private String respCode;

    private String respMsg;

    private BigDecimal buyerPayamount;

    private BigDecimal pointAmount;

    private String buyerId;

    private String buyerAccount;

    private String isclearorcancel;

    private String extend1;

    private String extend2;

    private String extend3;

    private BigDecimal arrivalAmount;

    private String chargeStatus;

    private String withdrawStatus;

    private BigDecimal d0Fee;

    private BigDecimal cardType;

    private String bankId;

    private String feever;

    private String tranType;

    private String bankCode;

    private String payCardType;

    private String insNo;

    private String callbackUrl;

    private String settleKey;

    private String voucherNum;

    private String withDrawD0flag;

    private BigDecimal auditStatus;

    private String merchantUrl;

    private BigDecimal tradeSource;

    private BigDecimal refundingAmount;

    private BigDecimal refundedAmount;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProVer() {
        return proVer;
    }

    public void setProVer(String proVer) {
        this.proVer = proVer == null ? null : proVer.trim();
    }

    public String getMsgType() {
        return msgType;
    }

    public void setMsgType(String msgType) {
        this.msgType = msgType == null ? null : msgType.trim();
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId == null ? null : orderId.trim();
    }

    public String getPayWay() {
        return payWay;
    }

    public void setPayWay(String payWay) {
        this.payWay = payWay == null ? null : payWay.trim();
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus == null ? null : orderStatus.trim();
    }

    public String getTraceNo() {
        return traceNo;
    }

    public void setTraceNo(String traceNo) {
        this.traceNo = traceNo == null ? null : traceNo.trim();
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject == null ? null : subject.trim();
    }

    public String getMerchantCode() {
        return merchantCode;
    }

    public void setMerchantCode(String merchantCode) {
        this.merchantCode = merchantCode == null ? null : merchantCode.trim();
    }

    public String getSmzfMsgId() {
        return smzfMsgId;
    }

    public void setSmzfMsgId(String smzfMsgId) {
        this.smzfMsgId = smzfMsgId == null ? null : smzfMsgId.trim();
    }

    public String getQrCode() {
        return qrCode;
    }

    public void setQrCode(String qrCode) {
        this.qrCode = qrCode == null ? null : qrCode.trim();
    }

    public BigDecimal getFee() {
        return fee;
    }

    public void setFee(BigDecimal fee) {
        this.fee = fee;
    }

    public String getReqDate() {
        return reqDate;
    }

    public void setReqDate(String reqDate) {
        this.reqDate = reqDate == null ? null : reqDate.trim();
    }

    public String getTranDate() {
        return tranDate;
    }

    public void setTranDate(String tranDate) {
        this.tranDate = tranDate == null ? null : tranDate.trim();
    }

    public String getBankDate() {
        return bankDate;
    }

    public void setBankDate(String bankDate) {
        this.bankDate = bankDate == null ? null : bankDate.trim();
    }

    public String getSmallMerchNo() {
        return smallMerchNo;
    }

    public void setSmallMerchNo(String smallMerchNo) {
        this.smallMerchNo = smallMerchNo == null ? null : smallMerchNo.trim();
    }

    public String getCustomerNo() {
        return customerNo;
    }

    public void setCustomerNo(String customerNo) {
        this.customerNo = customerNo == null ? null : customerNo.trim();
    }

    public String getCommitionId() {
        return commitionId;
    }

    public void setCommitionId(String commitionId) {
        this.commitionId = commitionId == null ? null : commitionId.trim();
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getD0Flag() {
        return d0Flag;
    }

    public void setD0Flag(String d0Flag) {
        this.d0Flag = d0Flag == null ? null : d0Flag.trim();
    }

    public String getSettleDate() {
        return settleDate;
    }

    public void setSettleDate(String settleDate) {
        this.settleDate = settleDate == null ? null : settleDate.trim();
    }

    public String getOrderDesc() {
        return orderDesc;
    }

    public void setOrderDesc(String orderDesc) {
        this.orderDesc = orderDesc == null ? null : orderDesc.trim();
    }

    public String getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(String operatorId) {
        this.operatorId = operatorId == null ? null : operatorId.trim();
    }

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId == null ? null : storeId.trim();
    }

    public String getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId == null ? null : terminalId.trim();
    }

    public String getLimitPay() {
        return limitPay;
    }

    public void setLimitPay(String limitPay) {
        this.limitPay = limitPay == null ? null : limitPay.trim();
    }

    public String getRespType() {
        return respType;
    }

    public void setRespType(String respType) {
        this.respType = respType == null ? null : respType.trim();
    }

    public String getRespCode() {
        return respCode;
    }

    public void setRespCode(String respCode) {
        this.respCode = respCode == null ? null : respCode.trim();
    }

    public String getRespMsg() {
        return respMsg;
    }

    public void setRespMsg(String respMsg) {
        this.respMsg = respMsg == null ? null : respMsg.trim();
    }

    public BigDecimal getBuyerPayamount() {
        return buyerPayamount;
    }

    public void setBuyerPayamount(BigDecimal buyerPayamount) {
        this.buyerPayamount = buyerPayamount;
    }

    public BigDecimal getPointAmount() {
        return pointAmount;
    }

    public void setPointAmount(BigDecimal pointAmount) {
        this.pointAmount = pointAmount;
    }

    public String getBuyerId() {
        return buyerId;
    }

    public void setBuyerId(String buyerId) {
        this.buyerId = buyerId == null ? null : buyerId.trim();
    }

    public String getBuyerAccount() {
        return buyerAccount;
    }

    public void setBuyerAccount(String buyerAccount) {
        this.buyerAccount = buyerAccount == null ? null : buyerAccount.trim();
    }

    public String getIsclearorcancel() {
        return isclearorcancel;
    }

    public void setIsclearorcancel(String isclearorcancel) {
        this.isclearorcancel = isclearorcancel == null ? null : isclearorcancel.trim();
    }

    public String getExtend1() {
        return extend1;
    }

    public void setExtend1(String extend1) {
        this.extend1 = extend1 == null ? null : extend1.trim();
    }

    public String getExtend2() {
        return extend2;
    }

    public void setExtend2(String extend2) {
        this.extend2 = extend2 == null ? null : extend2.trim();
    }

    public String getExtend3() {
        return extend3;
    }

    public void setExtend3(String extend3) {
        this.extend3 = extend3 == null ? null : extend3.trim();
    }

    public BigDecimal getArrivalAmount() {
        return arrivalAmount;
    }

    public void setArrivalAmount(BigDecimal arrivalAmount) {
        this.arrivalAmount = arrivalAmount;
    }

    public String getChargeStatus() {
        return chargeStatus;
    }

    public void setChargeStatus(String chargeStatus) {
        this.chargeStatus = chargeStatus == null ? null : chargeStatus.trim();
    }

    public String getWithdrawStatus() {
        return withdrawStatus;
    }

    public void setWithdrawStatus(String withdrawStatus) {
        this.withdrawStatus = withdrawStatus == null ? null : withdrawStatus.trim();
    }

    public BigDecimal getD0Fee() {
        return d0Fee;
    }

    public void setD0Fee(BigDecimal d0Fee) {
        this.d0Fee = d0Fee;
    }

    public BigDecimal getCardType() {
        return cardType;
    }

    public void setCardType(BigDecimal cardType) {
        this.cardType = cardType;
    }

    public String getBankId() {
        return bankId;
    }

    public void setBankId(String bankId) {
        this.bankId = bankId == null ? null : bankId.trim();
    }

    public String getFeever() {
        return feever;
    }

    public void setFeever(String feever) {
        this.feever = feever == null ? null : feever.trim();
    }

    public String getTranType() {
        return tranType;
    }

    public void setTranType(String tranType) {
        this.tranType = tranType == null ? null : tranType.trim();
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode == null ? null : bankCode.trim();
    }

    public String getPayCardType() {
        return payCardType;
    }

    public void setPayCardType(String payCardType) {
        this.payCardType = payCardType == null ? null : payCardType.trim();
    }

    public String getInsNo() {
        return insNo;
    }

    public void setInsNo(String insNo) {
        this.insNo = insNo == null ? null : insNo.trim();
    }

    public String getCallbackUrl() {
        return callbackUrl;
    }

    public void setCallbackUrl(String callbackUrl) {
        this.callbackUrl = callbackUrl == null ? null : callbackUrl.trim();
    }

    public String getSettleKey() {
        return settleKey;
    }

    public void setSettleKey(String settleKey) {
        this.settleKey = settleKey == null ? null : settleKey.trim();
    }

    public String getVoucherNum() {
        return voucherNum;
    }

    public void setVoucherNum(String voucherNum) {
        this.voucherNum = voucherNum == null ? null : voucherNum.trim();
    }

    public String getWithDrawD0flag() {
        return withDrawD0flag;
    }

    public void setWithDrawD0flag(String withDrawD0flag) {
        this.withDrawD0flag = withDrawD0flag == null ? null : withDrawD0flag.trim();
    }

    public BigDecimal getAuditStatus() {
        return auditStatus;
    }

    public void setAuditStatus(BigDecimal auditStatus) {
        this.auditStatus = auditStatus;
    }

    public String getMerchantUrl() {
        return merchantUrl;
    }

    public void setMerchantUrl(String merchantUrl) {
        this.merchantUrl = merchantUrl == null ? null : merchantUrl.trim();
    }

    public BigDecimal getTradeSource() {
        return tradeSource;
    }

    public void setTradeSource(BigDecimal tradeSource) {
        this.tradeSource = tradeSource;
    }

    public BigDecimal getRefundingAmount() {
        return refundingAmount;
    }

    public void setRefundingAmount(BigDecimal refundingAmount) {
        this.refundingAmount = refundingAmount;
    }

    public BigDecimal getRefundedAmount() {
        return refundedAmount;
    }

    public void setRefundedAmount(BigDecimal refundedAmount) {
        this.refundedAmount = refundedAmount;
    }

    public String getTranDateBegin() {
        return tranDateBegin;
    }

    public void setTranDateBegin(String tranDateBegin) {
        this.tranDateBegin = tranDateBegin;
    }

    public String getTranDateEnd() {
        return tranDateEnd;
    }

    public void setTranDateEnd(String tranDateEnd) {
        this.tranDateEnd = tranDateEnd;
    }

    public BigDecimal getAmountMax() {
        return amountMax;
    }

    public void setAmountMax(BigDecimal amountMax) {
        this.amountMax = amountMax;
    }

    public BigDecimal getAmountMin() {
        return amountMin;
    }

    public void setAmountMin(BigDecimal amountMin) {
        this.amountMin = amountMin;
    }
}