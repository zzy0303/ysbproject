package com.uns.dao.qrcode;

import com.uns.entity.TQrcodeRefund;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface TQrcodeRefundMapper {

    int deleteByPrimaryKey(String id);

    int insert(TQrcodeRefund record);

    int insertSelective(TQrcodeRefund record);

    TQrcodeRefund selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TQrcodeRefund record);

    int updateByPrimaryKey(TQrcodeRefund record);

    List<TQrcodeRefund> queryRefundList(TQrcodeRefund tQrcodeRefund);

    List<Map<String,Object>> findRefundPageList(TQrcodeRefund tQrcodeRefund);
}