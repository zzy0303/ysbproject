package com.uns.common;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/8/9
 * @Modifyed By:
 */
public class Constants {
    public static final String SESSION_VERIFY_CODE="sessionVerifycode";

    public static final String SESSION_KEY_USER="sessionUser";
    public static final String SESSION_KEY_SHOPPER= "shopper";
    public static final String SESSION_KEY_AGENT = "agent";

    public static final String ERROR_MESSAGE = "errMsg";

    public static final int EXCEL_SIZE = 10000;
    public static final int QUERY_SIZE = 20;
}
