package com.uns.service;

import com.uns.dao.small.UsersMapper;
import com.uns.entity.Users;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/8/10
 * @Modifyed By:
 */
@Service
public class UsersService {

    @Autowired
    private UsersMapper usersMapper;

    public Users findUsersByTel(String tel) {
        Users users = new Users();
        users.setTel(tel);
        return usersMapper.findUsersByParam(users);
    }
}
