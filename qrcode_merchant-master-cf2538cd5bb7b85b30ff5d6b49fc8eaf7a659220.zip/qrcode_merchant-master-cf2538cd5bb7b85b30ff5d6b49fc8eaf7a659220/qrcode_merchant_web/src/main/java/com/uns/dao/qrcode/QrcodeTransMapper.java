package com.uns.dao.qrcode;

import com.uns.entity.QrcodeTrans;
import com.uns.model.QrcodeTransModel;
import org.apache.ibatis.annotations.Mapper;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Mapper
public interface QrcodeTransMapper {

    int deleteByPrimaryKey(BigDecimal id);

    int insert(QrcodeTrans record);

    int insertSelective(QrcodeTrans record);

    QrcodeTrans selectByPrimaryKey(BigDecimal id);

    int updateByPrimaryKeySelective(QrcodeTrans record);

    int updateByPrimaryKey(QrcodeTrans record);

    List<QrcodeTrans> findQrcodeTransList();

    Map<String, Object> queryChargeCollect(QrcodeTrans qrcodeTrans);

    List<QrcodeTransModel> queryTransList(QrcodeTrans qrcodeTrans);
}