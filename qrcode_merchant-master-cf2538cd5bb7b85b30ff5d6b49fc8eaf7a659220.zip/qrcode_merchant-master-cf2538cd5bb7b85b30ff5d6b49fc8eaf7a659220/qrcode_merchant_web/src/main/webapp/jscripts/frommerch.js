function myReturn( )
{
	window.history.back( );
	//document.location.reload( );
	return;
}