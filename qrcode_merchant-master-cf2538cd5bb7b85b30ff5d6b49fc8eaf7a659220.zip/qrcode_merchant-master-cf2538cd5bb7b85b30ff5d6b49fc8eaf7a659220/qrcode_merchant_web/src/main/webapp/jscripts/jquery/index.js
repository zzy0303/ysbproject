$().ready(function() {
	// validate the comment form when it is submitted
	$("#commentForm").validate();

	// validate signup form on keyup and submit
	$("#signupForm").validate({
		rules: {
			tel: {
				required: true,
				user: true,
			},
			pasword: {
				required: true,
				pasw: true,
			},
			password: {
				required: true,
				pasw: true,
				rangelength: [8, 20]

			},
			repassword: {
				required: true,
				equalTo: "#pasword"
			},
			verycode: "required",
			jine: {
				required: true,
				num: true,
			},
			beizhu:"required",
		},
		messages: {
			tel: {
				required: "请输入手机号码",
				user: "请输入正确的手机号码",
			},
			pasword: {
				required: "请输入登录密码",
				pasw: "请输入6-20位数字和字母",
			},
			password: {
				required: "请输入您的新密码",
				pasw: "密码必须由8-20位，英文字母、数字和特殊字符组成",
				rangelength: "密码格式不正确，请重新输入"

			},
			repassword: {
				required: "请确认您的新密码",
				equalTo: "两次输入密码不一致"
			},
			verycode: {
				required:"请输入验证码",
				code:"请输入六位验证码"
			},
			jine:{
				required: "请输入订单金额",
				num: "请输入正确的订单金额",
			},
			beizhu:"请填写订单备注",
		}
	});

	//  手机或者邮箱
	jQuery.validator.addMethod("user", function(value, element) {
		var length = value.length;
		return this.optional(element) || /^1[34578]\d{9}$/.test(value);
	}, "请正确填写您的手机号码");
	//  密码验证
	jQuery.validator.addMethod("pasw", function(value, element) {
		return this.optional(element) || /^[a-zA-Z0-9]{6,20}$/.test(value);
	}, "格式错误");
	//  订单备注
   jQuery.validator.addMethod("zhongwen", function(value, element) {
        var length = value.length;
        return this.optional(element) || (length<= 30 && /[\u4e00-\u9fa5]+/.test(value));
    });
    //  订单金额
   jQuery.validator.addMethod("num", function(value, element) {
        var length = value.length;
        return this.optional(element) || (/^(?:50000(\.0{0,2})?|(0|[1-9]\d{0,3}|[1-9]\d{4})(\.\d{0,2})?)$/g.test(value));
    });
    jQuery.validator.addMethod("code", function(value, element) {
        return this.optional(element) || (/^\d{6}$/g.test(value));
    });
});