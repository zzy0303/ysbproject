var ProvinceArray = new Array;
ProvinceArray[0] = "选择";
ProvinceArray[1] = "北京";
ProvinceArray[2] = "上海";
ProvinceArray[3] = "天津";
ProvinceArray[4] = "重庆";
ProvinceArray[5] = "广东";
ProvinceArray[6] = "山西";
ProvinceArray[7] = "河北";
ProvinceArray[8] = "黑龙江";
ProvinceArray[9] = "辽宁";
ProvinceArray[10] = "吉林";
ProvinceArray[11] = "江苏";
ProvinceArray[12] = "安徽";
ProvinceArray[13] = "山东";
ProvinceArray[14] = "浙江";
ProvinceArray[15] = "江西";
ProvinceArray[16] = "福建";
ProvinceArray[17] = "湖南";
ProvinceArray[18] = "湖北";
ProvinceArray[19] = "河南";
ProvinceArray[20] = "内蒙古";
ProvinceArray[21] = "海南";
ProvinceArray[22] = "广西";
ProvinceArray[23] = "贵州";
ProvinceArray[24] = "四川";
ProvinceArray[25] = "云南";
ProvinceArray[26] = "陕西";
ProvinceArray[27] = "甘肃";
ProvinceArray[28] = "宁夏";
ProvinceArray[29] = "青海";
ProvinceArray[30] = "新疆";
ProvinceArray[31] = "西藏";
ProvinceArray[32] = "香港";
ProvinceArray[33] = "台湾";
ProvinceArray[34] = "澳门";
tCitys = new Array; 
tCitys[1] = new Array;
tCitys[1][0] = "北京崇文区";
tCitys[1][1] = "北京宣武区";
tCitys[1][2] = "北京东城区";
tCitys[1][3] = "北京西城区";
tCitys[1][4] = "北京海淀区";
tCitys[1][5] = "北京朝阳区";
tCitys[1][6] = "北京丰台区";
tCitys[1][7] = "北京石景山区";
tCitys[1][8] = "北京其他地区";
tCitys[2] = new Array;
tCitys[2][0] = "上海";
tCitys[3] = new Array;
tCitys[3][0] = "天津";
tCitys[4] = new Array;
tCitys[4][0] = "重庆";
tCitys[5] = new Array;
tCitys[5][0] = "广东广州";
tCitys[5][1] = "广东深圳";
tCitys[5][2] = "广东珠海";
tCitys[5][3] = "广东潮州";
tCitys[5][4] = "广东东莞";
tCitys[5][5] = "广东湛江";
tCitys[5][6] = "广东肇庆";
tCitys[5][7] = "广东佛山";
tCitys[5][8] = "广东中山";
tCitys[5][9] = "广东江门";
tCitys[5][10] = "广东韶关";
tCitys[5][11] = "广东英德";
tCitys[5][12] = "广东梅州";
tCitys[5][13] = "广东汕头";
tCitys[5][14] = "广东惠州";
tCitys[5][15] = "广东河源";
tCitys[5][16] = "广东茂名";
tCitys[5][17] = "广东顺德";
tCitys[5][18] = "广东其他城市";
tCitys[6] = new Array;
tCitys[6][0] = "山西太原";
tCitys[6][1] = "山西大同";
tCitys[6][2] = "山西晋城";
tCitys[6][3] = "山西运城";
tCitys[6][4] = "山西临汾";
tCitys[6][5] = "山西长治";
tCitys[6][6] = "山西析州";
tCitys[6][7] = "山西阳泉";
tCitys[6][8] = "山西候马";
tCitys[6][9] = "山西宁武";
tCitys[6][10] = "山西朔州";
tCitys[6][11] = "山西其他城市";
tCitys[7] = new Array;
tCitys[7][0] = "河北石家庄";
tCitys[7][1] = "河北承德";
tCitys[7][2] = "河北唐山";
tCitys[7][3] = "河北秦皇岛";
tCitys[7][4] = "河北沧州";
tCitys[7][5] = "河北张家口";
tCitys[7][6] = "河北保定";
tCitys[7][7] = "河北衡水";
tCitys[7][8] = "河北邢台";
tCitys[7][9] = "河北邯郸";
tCitys[7][10] = "河北廊坊";
tCitys[7][11] = "河北其他城市";
tCitys[8] = new Array;
tCitys[8][0] = "黑龙江哈尔滨";
tCitys[8][1] = "黑龙江齐齐哈尔";
tCitys[8][2] = "黑龙江大庆市";
tCitys[8][3] = "黑龙江佳木斯";
tCitys[8][4] = "黑龙江牡丹江";
tCitys[8][5] = "黑龙江伊春";
tCitys[8][6] = "黑龙江绥化";
tCitys[8][7] = "黑龙江黑河";
tCitys[8][8] = "黑龙江鸡西";
tCitys[8][9] = "黑龙江大兴安岭";
tCitys[8][10] = "黑龙江鹤岗市";
tCitys[8][11] = "黑龙江其他城市";
tCitys[9] = new Array;
tCitys[9][0] = "辽宁沈阳";
tCitys[9][1] = "辽宁大连";
tCitys[9][2] = "辽宁抚顺";
tCitys[9][3] = "辽宁鞍山";
tCitys[9][4] = "辽宁锦州";
tCitys[9][5] = "辽宁营口";
tCitys[9][6] = "辽宁本溪";
tCitys[9][7] = "辽宁丹东";
tCitys[9][8] = "辽宁辽阳";
tCitys[9][9] = "辽宁铁岭";
tCitys[9][10] = "辽宁其他城市";
tCitys[10] = new Array;
tCitys[10][0] = "吉林长春";
tCitys[10][1] = "吉林吉林";
tCitys[10][2] = "吉林通化";
tCitys[10][3] = "吉林四平";
tCitys[10][4] = "吉林延吉";
tCitys[10][5] = "吉林其他城市";
tCitys[11] = new Array;
tCitys[11][0] = "江苏南京";
tCitys[11][1] = "江苏无锡";
tCitys[11][2] = "江苏苏州";
tCitys[11][3] = "江苏徐州";
tCitys[11][4] = "江苏常州";
tCitys[11][5] = "江苏连云港";
tCitys[11][6] = "江苏南通";
tCitys[11][7] = "江苏淮阴";
tCitys[11][8] = "江苏镇江";
tCitys[11][9] = "江苏扬州";
tCitys[11][10] = "江苏泰州";
tCitys[11][11] = "江苏盐城";
tCitys[11][12] = "江苏常熟";
tCitys[11][13] = "江苏沭阳";
tCitys[11][14] = "江苏宿迁";
tCitys[11][15] = "江苏其他城市";
tCitys[12] = new Array;
tCitys[12][0] = "安徽合肥";
tCitys[12][1] = "安徽蚌埠";
tCitys[12][2] = "安徽芜湖";
tCitys[12][3] = "安徽马鞍山";
tCitys[12][4] = "安徽黄山";
tCitys[12][5] = "安徽淮南";
tCitys[12][6] = "安徽淮北";
tCitys[12][7] = "安徽淮化";
tCitys[12][8] = "安徽阜阳";
tCitys[12][9] = "安徽安庆";
tCitys[12][10] = "安徽六安";
tCitys[12][11] = "安徽其他城市";
tCitys[13] = new Array;
tCitys[13][0] = "山东济南";
tCitys[13][1] = "山东青岛";
tCitys[13][2] = "山东烟台";
tCitys[13][3] = "山东淄博";
tCitys[13][4] = "山东东营";
tCitys[13][5] = "山东潍坊";
tCitys[13][6] = "山东德州";
tCitys[13][7] = "山东泰安";
tCitys[13][8] = "山东济宁";
tCitys[13][9] = "山东荷泽";
tCitys[13][10] = "山东临沂";
tCitys[13][11] = "山东威海";
tCitys[13][12] = "山东日照";
tCitys[13][13] = "山东莱芜";
tCitys[13][14] = "山东滨州";
tCitys[13][15] = "山东聊城";
tCitys[13][16] = "山东其他城市";
tCitys[14] = new Array;
tCitys[14][0] = "浙江杭州";
tCitys[14][1] = "浙江宁波";
tCitys[14][2] = "浙江温州";
tCitys[14][3] = "浙江嘉兴";
tCitys[14][4] = "浙江金华";
tCitys[14][5] = "浙江湖州";
tCitys[14][6] = "浙江丽水";
tCitys[14][7] = "浙江衢州";
tCitys[14][8] = "浙江台州";
tCitys[14][9] = "浙江绍兴";
tCitys[14][10] = "浙江临海";
tCitys[14][11] = "浙江舟山";
tCitys[14][12] = "浙江其他城市";
tCitys[15] = new Array;
tCitys[15][0] = "江西南昌";
tCitys[15][1] = "江西九江";
tCitys[15][2] = "江西赣州";
tCitys[15][3] = "江西上饶";
tCitys[15][4] = "江西鹰潭";
tCitys[15][5] = "江西景德镇";
tCitys[15][6] = "江西井冈山";
tCitys[15][7] = "江西宜春";
tCitys[15][8] = "江西抚州";
tCitys[15][9] = "江西吉安";
tCitys[15][10] = "江西其他城市";
tCitys[16] = new Array;
tCitys[16][0] = "福建福州";
tCitys[16][1] = "福建厦门";
tCitys[16][2] = "福建泉州";
tCitys[16][3] = "福建龙岩";
tCitys[16][4] = "福建莆田";
tCitys[16][5] = "福建漳州";
tCitys[16][6] = "福建南平";
tCitys[16][7] = "福建福安";
tCitys[16][8] = "福建三明";
tCitys[16][9] = "福建永安";
tCitys[16][10] = "福建其他城市";
tCitys[17] = new Array;
tCitys[17][0] = "湖南长沙";
tCitys[17][1] = "湖南株洲";
tCitys[17][2] = "湖南湘潭";
tCitys[17][3] = "湖南衡阳";
tCitys[17][4] = "湖南岳阳";
tCitys[17][5] = "湖南益阳";
tCitys[17][6] = "湖南常德";
tCitys[17][7] = "湖南张家界";
tCitys[17][8] = "湖南邵阳";
tCitys[17][9] = "湖南怀化";
tCitys[17][10] = "湖南郴州";
tCitys[17][11] = "湖南其他城市";
tCitys[18] = new Array;
tCitys[18][0] = "湖北武汉";
tCitys[18][1] = "湖北宜昌";
tCitys[18][2] = "湖北十堰";
tCitys[18][3] = "湖北襄樊";
tCitys[18][4] = "湖北黄石";
tCitys[18][5] = "湖北荆门";
tCitys[18][6] = "湖北鄂州";
tCitys[18][7] = "湖北荆洲";
tCitys[18][8] = "湖北孝感";
tCitys[18][9] = "湖北黄岗";
tCitys[18][10] = "湖北其他城市";
tCitys[19] = new Array;
tCitys[19][0] = "河南郑州";
tCitys[19][1] = "河南洛阳";
tCitys[19][2] = "河南开封";
tCitys[19][3] = "河南安阳";
tCitys[19][4] = "河南许昌";
tCitys[19][5] = "河南信阳";
tCitys[19][6] = "河南周口";
tCitys[19][7] = "河南商丘";
tCitys[19][8] = "河南平顶山";
tCitys[19][9] = "河南焦作";
tCitys[19][10] = "河南鹤壁";
tCitys[19][11] = "河南新乡";
tCitys[19][12] = "河南濮阳";
tCitys[19][13] = "河南漯河";
tCitys[19][14] = "河南三门峡";
tCitys[19][15] = "河南驻马店";
tCitys[19][16] = "河南南阳";
tCitys[19][17] = "河南其他城市";
tCitys[20] = new Array;
tCitys[20][0] = "内蒙古呼和浩特";
tCitys[20][1] = "内蒙古包头";
tCitys[20][2] = "内蒙古赤峰";
tCitys[20][3] = "内蒙古临河";
tCitys[20][4] = "内蒙古乌海";
tCitys[20][5] = "内蒙古其他城市";
tCitys[21] = new Array;
tCitys[21][0] = "海南海口";
tCitys[21][1] = "海南三亚";
tCitys[21][2] = "海南其他城市";
tCitys[22] = new Array;
tCitys[22][0] = "广西南宁";
tCitys[22][1] = "广西桂林";
tCitys[22][2] = "广西梧州";
tCitys[22][3] = "广西柳州";
tCitys[22][4] = "广西玉林";
tCitys[22][5] = "广西百色";
tCitys[22][6] = "广西北海";
tCitys[22][7] = "广西其他城市";
tCitys[23] = new Array;
tCitys[23][0] = "贵州贵阳";
tCitys[23][1] = "贵州六盘水";
tCitys[23][2] = "贵州玉屏";
tCitys[23][3] = "贵州凯里";
tCitys[23][4] = "贵州遵义";
tCitys[23][5] = "贵州铜仁";
tCitys[23][6] = "贵州安顺";
tCitys[23][7] = "贵州其他城市";
tCitys[24] = new Array;
tCitys[24][0] = "四川成都";
tCitys[24][1] = "四川绵阳";
tCitys[24][2] = "四川乐山";
tCitys[24][3] = "四川攀枝花";
tCitys[24][4] = "四川自贡";
tCitys[24][5] = "四川宜宾";
tCitys[24][6] = "四川南充";
tCitys[24][7] = "四川内江";
tCitys[24][8] = "四川泸州";
tCitys[24][9] = "四川涪陵";
tCitys[24][10] = "四川德阳";
tCitys[24][11] = "四川其他城市";
tCitys[25] = new Array;
tCitys[25][0] = "云南昆明";
tCitys[25][1] = "云南大理";
tCitys[25][2] = "云南楚雄";
tCitys[25][3] = "云南玉溪";
tCitys[25][4] = "云南丽江";
tCitys[25][5] = "云南曲靖";
tCitys[25][6] = "云南个旧";
tCitys[25][7] = "云南其他城市";
tCitys[26] = new Array;
tCitys[26][0] = "陕西西安";
tCitys[26][1] = "陕西咸阳";
tCitys[26][2] = "陕西渭南";
tCitys[26][3] = "陕西汉中";
tCitys[26][4] = "陕西宝鸡";
tCitys[26][5] = "陕西铜川";
tCitys[26][6] = "陕西延安";
tCitys[26][7] = "陕西其他城市";
tCitys[27] = new Array;
tCitys[27][0] = "甘肃兰州";
tCitys[27][1] = "甘肃酒泉";
tCitys[27][2] = "甘肃天水";
tCitys[27][3] = "甘肃西峰";
tCitys[27][4] = "甘肃其他城市";
tCitys[28] = new Array;
tCitys[28][0] = "宁夏银川";
tCitys[28][1] = "宁夏石嘴山";
tCitys[28][2] = "宁夏固源";
tCitys[28][3] = "宁夏吴忠";
tCitys[28][4] = "宁夏其他城市";
tCitys[29] = new Array;
tCitys[29][0] = "青海西宁";
tCitys[29][1] = "青海玉树";
tCitys[29][2] = "青海海东";
tCitys[29][3] = "青海其他城市";
tCitys[30] = new Array;
tCitys[30][0] = "新疆乌鲁木齐";
tCitys[30][1] = "新疆克拉玛依";
tCitys[30][2] = "新疆石河子";
tCitys[30][3] = "新疆库尔勒";
tCitys[30][4] = "新疆吐鲁番";
tCitys[30][5] = "新疆哈密";
tCitys[30][6] = "新疆喀什";
tCitys[30][7] = "新疆伊宁";
tCitys[30][8] = "新疆其他城市";
tCitys[31] = new Array;
tCitys[31][0] = "西藏拉萨";
tCitys[31][1] = "西藏其他城市";
tCitys[32] = new Array;
tCitys[32][0] = "香港";
tCitys[33] = new Array;
tCitys[33][0] = "台湾台北";
tCitys[33][1] = "台湾基隆";
tCitys[33][2] = "台湾台南";
tCitys[33][3] = "台湾台中";
tCitys[33][4] = "台湾其他城市";
tCitys[34] = new Array;
tCitys[34][0] = "澳门";


function ProvinceOptionMenu(){        
        var i;
        provincebox = document.forms["info"].elements["provicend"];
        for(i = 0; i < ProvinceArray.length; i++)
        {
          provincebox.options[i] = new Option(ProvinceArray[i],ProvinceArray[i]);
	}
	provincebox.length = i;
}

function ProvinceOptionMenu(str){              
        var i;
        provincebox = document.forms["info"].elements["provicend"];
        for(i = 0; i < ProvinceArray.length; i++)
        {
          provincebox.options[i] = new Option(ProvinceArray[i],ProvinceArray[i]);
          if(str==ProvinceArray[i]){
          	provincebox.options[i].selected=true;
          }
	    }
	provincebox.length = i;
}

function selectcity(){  

	provincebox = document.forms["info"].elements["provicend"];
	selcity = parseInt(provincebox.selectedIndex);
	tCity = tCitys[selcity];
    citybox = document.forms["info"].elements["city"];
	if(tCity != null){
       citybox = document.forms["info"].elements["city"];
       if (tCity.length>1){
           citybox.options[0] = new Option("请选择","选择");
           for(i = 0; i < tCity.length; i++) {
			     str = tCity[i];
                 citybox.options[i+1] = new Option(str, str);
			}
			citybox.length = i+1;
       }else{
           str = tCity[0];
           citybox.options[0] = new Option(str,str);
           citybox.length=1;
           citybox.options[0].selected;
       }  
    }
    else{
       if (citybox != null){
       citybox.options[0] = new Option("请选择","选择");
       citybox.length = 1;}
   }
}

//注册用户页面
function ProvinceOptionMenu_addpage(){  
        var i;
        provincebox = document.forms["shxx"].elements["provicend"];
        for(i = 0; i < ProvinceArray.length; i++)
        {
          provincebox.options[i] = new Option(ProvinceArray[i],ProvinceArray[i]);
	}
	provincebox.length = i;
}

function selectcity_addpage()
{  
	provincebox = document.forms["shxx"].elements["provicend"];
	selcity = parseInt(provincebox.selectedIndex);
	tCity = tCitys[selcity];
    citybox = document.forms["shxx"].elements["city"];
	if(tCity != null)
		{
                       citybox = document.forms["shxx"].elements["city"];
                       if (tCity.length>1){
                          citybox.options[0] = new Option("请选择","选择");
                          for(i = 0; i < tCity.length; i++)
		  	  {
			     str = tCity[i];
                             citybox.options[i+1] = new Option(str, str);
			  }
			  citybox.length = i+1;
                        }
                        else
                        {
                          str = tCity[0];
                          citybox.options[0] = new Option(str,str);
                          citybox.length=1;
                          citybox.options[0].selected;
                        }
                       
	               

		}
        else{
          if (citybox != null){
            citybox.options[0] = new Option("请选择","选择");
	  citybox.length = 1;}
         }
}