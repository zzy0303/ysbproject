function allJS()
{
	window.location.href = document.forms[0].action;
}

function searchJS()
{
	try{
    	document.forms[0].elements["page"].value = "1";
    }
    catch(e){}
    
    document.forms[0].method = "post";
    document.forms[0].submit();
}

function pageJS(page)
{
    document.getElementById("page").value = page;
    document.forms[0].method = "post";
    document.forms[0].submit();
}

function pagePlusJS(pages)
{
    var page = document.getElementById("page").value;
    var flag = true;
    
    if(isNaN(page) || page < 1 || page > pages || page.indexOf(".") == 1)
    {
        flag = false;
        alert("请输入正确的页数");
    }
    
    if(flag)
    {
        document.forms[0].method = "post";
        document.forms[0].submit();
    }
    else
    {
        document.getElementById("page").focus();
    }
}