package com.uns.util;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.myenum.MessageEnum;
import com.uns.dao.*;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.model.Area;
import com.uns.model.B2cShopperbiTemp;
import com.uns.service.AppOpenRegService;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 注册MPOS和扫码
 */
@Component
public class RegMposAndQrcode {

    private Logger Log = LoggerFactory.getLogger(AppOpenRegService.class);

    @Autowired
    private B2cShopperbiMapper b2cShopperbiMapper;
    
    @Autowired
    private AreaMapper areaMapper;
    
    @Autowired
    private B2cDictMapper dictMapper;
    
    @Autowired
    private MposMerchantFeeMapper mposMerchantFeeMapper;
    
    @Autowired
    private B2cShopperbiTempMapper b2cShopperbiTempMapper;
    
    /**
     * 转化商户类型（个人和企业）
     *
     * @param merchantType
     * @return
     */
    public String getType(String merchantType) {
        String type = "";
        if (Constants.CON_NO.equals(merchantType)) {
            type = Constants.TYPE_P;
        } else {
            type = Constants.TYPE_C;
        }
        return type;
    }


    /**
     * 注册MPOS
     * @param userType
     * @param b2cShopperbi
     * @return
     * @throws Exception
     */
    public HashMap regMposMerchant(String userType, B2cShopperbiTemp b2cShopperbi) throws Exception {
        HashMap hashMap = new HashMap();
        net.sf.json.JSONObject ob = null;
        String rspCode = "";
        String ysbNo = "";
        String factoringNo = "";

        // 区分企业还是个人
        Map ysbMap = null;
        if (Constants.TYPE_P.equals(userType)) {
            ysbMap = regMerchant(b2cShopperbi, userType);
        } else {
            ysbMap = regCompany(b2cShopperbi, userType);
        }

        Log.info("银生宝注册返回码:" + ysbMap);
        ob = net.sf.json.JSONObject.fromObject(ysbMap);
        rspCode = (String) ob.get(Constants.RSP_CODE);

        if (Constants.SUCCESS_CODE.equals(rspCode)) {
            ysbNo = (String) ob.get("userId");
            factoringNo = (String) ob.get("factor_userId");
            b2cShopperbi.setYsbNo(ysbNo);
            b2cShopperbi.setFactoringno(factoringNo);
            b2cShopperbi.setOpen_mpos_create_date(new Date());
            hashMap.put(Constants.RSP_CODE, MessageEnum.成功.getCode());
            hashMap.put(Constants.RSP_MSG, MessageEnum.成功.getText());
        } else {
            if (rspCode.equals(MessageEnum.实名认证失败.getCode())) {
                Log.info("实名认证失败6012");
                hashMap.put(Constants.RSP_CODE,MessageEnum.实名认证失败.getCode());
                hashMap.put(Constants.RSP_MSG,MessageEnum.实名认证失败.getText());
            } else if (rspCode.equals("6013")) {
                Log.info("实名认证失败6013");
                hashMap.put(Constants.RSP_CODE,MessageEnum.实名认证失败.getCode());
                hashMap.put(Constants.RSP_MSG,MessageEnum.实名认证失败.getText());

            } else if (rspCode.equals("6014")) {
                Log.info("实名认证失败6014");
                hashMap.put(Constants.RSP_CODE,MessageEnum.实名认证失败.getCode());
                hashMap.put(Constants.RSP_MSG,MessageEnum.实名认证失败.getText());
            }
        }
        return hashMap;
    }

    /**
     * 个人商户注册（注册参数）
     *
     * @param b2cShopperbi
     * @return
     * @throws Exception
     */
    private Map regMerchant(B2cShopperbiTemp b2cShopperbi, String userTypes)
            throws Exception {
        HashMap params = new HashMap();

        Date dates = new Date();
        String mradom = RandomStringUtils.randomNumeric(6);
        String orderId = DateUtil.getTypeDate(dates, "yyyyMMdd") + mradom + b2cShopperbi.getShopperid();
        String orderTime = DateUtil.getTypeDate(dates, "yyyyMMddhhmmss");
        // 基本信息
        String userType = userTypes;
        String linkName = b2cShopperbi.getName();
        String idCard = b2cShopperbi.getIDNo();
        String tel = b2cShopperbi.getStel();
        String merchantNo = b2cShopperbi.getShopperid() == null ? "" : b2cShopperbi.getShopperid().toString();
        Long agentNo = b2cShopperbi.getShopperidP();
        String institutionNo = b2cShopperbi.getOrgNo();
        String platformType = "";
        if (agentNo != null) {
            platformType = Constants.CON_NO;// 0 自有
        } else {
            platformType = Constants.CON_YES;// 机构
        }
        // 结算信息
        String settlementType = b2cShopperbi.getSettlementType();
        String accountbankname = b2cShopperbi.getAccountbankname();
        String accountbankprovCode = b2cShopperbi.getAccountBankProvCode();
        String accountBankCityCode = b2cShopperbi.getAccountBankCityCode();
        String accountbankclientname = b2cShopperbi.getAccountbankclientname();
        String accountbankno = b2cShopperbi.getAccountbankno();
        String superShopperId = "";
        String ifInvite = "0";
        if (StringUtils.isNotEmpty(b2cShopperbi.getInviteCodeP())) {
            B2cShopperbiTemp b2cShopperbiTempNew = b2cShopperbiTempMapper.findShopperByInviteCode(b2cShopperbi.getInviteCodeP());
            if (null != b2cShopperbiTempNew) {
                superShopperId = b2cShopperbiTempNew.getShopperid().toString();
                ifInvite = "1";
            }
        }

        // 刷卡手续费
        List merchantFeeList = mposMerchantFeeMapper.findmerchantFeeList2(b2cShopperbi.getShopperid().toString());

        // t1type
        params.put("t1Type", b2cShopperbi.getT1type() == null ? "0" : b2cShopperbi.getT1type());
        params.put("t1topamount", b2cShopperbi.getT1topamount() == null ? "0" : b2cShopperbi.getT1topamount());

        // t+0手续费
        String issupportt0 = b2cShopperbi.getIsSupportT0(); // 0支持
        String isicapplyt0 = "";
        Double t0singledaylimit = 0.00;
        if (Constants.CON_NO.equals(issupportt0)) {
            isicapplyt0 = b2cShopperbi.getIsIcApplyT0();
            t0singledaylimit = b2cShopperbi.getT0SingleDayLimit();
            params.put("t0Type", b2cShopperbi.getT0type() == null ? "0" : b2cShopperbi.getT0type());
            params.put("t0fee", Constants.T0_FEE);
            params.put("t0fixedamount", Constants.T0_FIXED_AMOUNT);
            params.put("t0minamount", b2cShopperbi.getT0minamount());
            params.put("t0maxamount", b2cShopperbi.getT0maxamount());
            params.put("creditAmount", t0singledaylimit == null ? "" : t0singledaylimit);
        } else {
            params.put("t0Type", "0");
            params.put("t0fee", "0");
            params.put("t0fixedamount", "0");
            params.put("t0minamount", "0");
            params.put("t0maxamount", "0");
            params.put("creditAmount", "0");
        }
        params.put("userType", userType == null ? "" : userType);
        params.put("orderId", orderId == null ? "" : orderId);
        params.put("orderTime", orderTime == null ? "" : orderTime);
        params.put("name", linkName == null ? "" : URLDecoder.decode(linkName, "UTF-8"));
        params.put("idNum", idCard == null ? "" : idCard);
        params.put("mobilePhoneNum", tel == null ? "" : tel);
        String bankCode = this.dictMapper.findDictBankName(b2cShopperbi.getAccountbankdictval()) == null ? "" : URLDecoder.decode(
                dictMapper.findDictBankName(b2cShopperbi.getAccountbankdictval()).getDictid(), "UTF-8");
        params.put("bankCode", bankCode == null ? "" : bankCode);
        params.put("bankNo", accountbankno == null ? "" : accountbankno);
        params.put("bankName", accountbankname == null ? "" : URLDecoder.decode(accountbankname, "UTF-8"));
        params.put("prov", accountbankprovCode == null ? "" : accountbankprovCode);
        params.put("city", accountBankCityCode == null ? "" : accountBankCityCode);

        params.put("merchantNo", merchantNo == null ? "" : merchantNo);
        params.put("proxyId", agentNo == null ? "" : agentNo);
        params.put("institutionNo", institutionNo == null ? "" : institutionNo);
        params.put("platformType", platformType == null ? "" : platformType);

        params.put("commissionIds", merchantFeeList);
        params.put("issupportt0", issupportt0 == null ? "" : issupportt0);// 是否支持T0提现

        params.put("scompany", b2cShopperbi.getName());
        params.put("agentNo", b2cShopperbi.getShopperidP());
        params.put("terminalNo", b2cShopperbi.getHfpsamd0()); //弘付psamD0
        params.put("pscmNo", b2cShopperbi.getHfpsam() == null ? "" : b2cShopperbi.getHfpsam()); //弘付psamD1
        params.put("superShopperId", superShopperId); //上级商户ID(裂变)
        params.put("ifInvite", ifInvite); //是否裂变商户（1：是 0：否）

        params.put("profitOwner", b2cShopperbi.getProfitOwner());//分润给那个代理商
        params.put("agentProfitRatio", b2cShopperbi.getAgentProfitRatio()); //代理商分润百分比
        params.put("merchProfitRatio1", b2cShopperbi.getMerchProfitRatio1());//商户分润方案1
        params.put("merchProfitRatio2", b2cShopperbi.getMerchProfitRatio2()); //商户分润方案2
        params.put("merchProfitRatio3", b2cShopperbi.getMerchProfitRatio3()); //商户分润方案3
        net.sf.json.JSONObject obs = net.sf.json.JSONObject.fromObject(params);

        System.out.println("注册银生宝个人：" + ConstantsEnv.SIMPLE_REGISTER_URL + obs.toString());
        String resultString = HttpClientUtils.REpostRequestStr1(
                ConstantsEnv.SIMPLE_REGISTER_URL, obs.toString());
        Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);

        return resultMap;
    }

    /**
     * 注册企业
     *
     * @param b2cShopperbi
     * @param userType
     * @return
     * @throws Exception
     */
    private Map regCompany(B2cShopperbiTemp b2cShopperbi, String userType)
            throws Exception {
        HashMap params = new HashMap();
        Date dates = new Date();
        String mradom = RandomStringUtils.randomNumeric(6);
        String orderId = DateUtil.getTypeDate(dates, "yyyyMMdd") + mradom + b2cShopperbi.getShopperid();
        String orderTime = DateUtil.getTypeDate(dates, "yyyyMMddhhmmss");

        // 基本信息
        String name = b2cShopperbi.getName();
        String idCard = b2cShopperbi.getIDNo();
        String tel = b2cShopperbi.getStel();
        String merchantNo = b2cShopperbi.getShopperid() == null ? "" : b2cShopperbi.getShopperid().toString();
        Long agentNo = b2cShopperbi.getShopperidP();
        String institutionNo = b2cShopperbi.getOrgNo();
        String platformType = "";
        if (agentNo != null) {
            platformType = Constants.CON_NO;// 0 自有
        } else {
            platformType = Constants.CON_YES;// 机构
        }
        // 结算信息
        String settlementType = b2cShopperbi.getSettlementType();
        String accountBankDictval = b2cShopperbi.getAccountbankdictval();
        String accountbankname = b2cShopperbi.getAccountbankname();
        String accountbankprovCode = b2cShopperbi.getAccountBankProvCode();
        String accountBankCityCode = b2cShopperbi.getAccountBankCityCode();
        String accountbankclientname = b2cShopperbi.getAccountbankclientname();
        String accountbankno = b2cShopperbi.getAccountbankno();

        String superShopperId = "";
        String ifInvite = "0";
        if (StringUtils.isNotEmpty(b2cShopperbi.getInviteCodeP())) {
            B2cShopperbiTemp b2cShopperbiTempNew = b2cShopperbiTempMapper.findShopperByInviteCode(b2cShopperbi.getInviteCodeP());
            if (null != b2cShopperbiTempNew) {
                superShopperId = b2cShopperbiTempNew.getShopperid().toString();
                ifInvite = "1";
            }
        }

        // 刷卡手续费
        List merchantFeeList = mposMerchantFeeMapper.findmerchantFeeList(b2cShopperbi.getShopperid().toString());
        // t1type
        params.put("t1Type", b2cShopperbi.getT1type() == null ? "0" : b2cShopperbi.getT1type());
        params.put("t1topamount", b2cShopperbi.getT1topamount() == null ? "0" : b2cShopperbi.getT1topamount());// t+1提现手续费
        // t+0手续费
        String issupportt0 = b2cShopperbi.getIsSupportT0(); // 0支持
        String isicapplyt0 = "";
        Double t0singledaylimit = 0.00;
        if (Constants.CON_NO.equals(issupportt0)) {
            isicapplyt0 = b2cShopperbi.getIsIcApplyT0();
            t0singledaylimit = b2cShopperbi.getT0SingleDayLimit();
            params.put("t0Type", b2cShopperbi.getT0type() == null ? "0" : b2cShopperbi.getT0type());
            params.put("t0fee", Constants.T0_FEE);
            params.put("t0fixedamount", Constants.T0_FIXED_AMOUNT);
            params.put("t0minamount", b2cShopperbi.getT0minamount());
            params.put("t0maxamount", b2cShopperbi.getT0maxamount());
            params.put("creditAmount", t0singledaylimit == null ? "" : t0singledaylimit);
            params.put("t0singledaylimit", t0singledaylimit == null ? "" : t0singledaylimit);
        } else {
            params.put("t0Type", "0");
            params.put("t0fee", "0");
            params.put("t0fixedamount", "0");
            params.put("t0minamount", "0");
            params.put("t0maxamount", "0");
            params.put("creditAmount", "0");
            params.put("t0singledaylimit", "0");
        }
        params.put("userType", userType == null ? "" : userType);
        params.put("orderId", orderId == null ? "" : orderId);
        params.put("orderTime", orderTime == null ? "" : orderTime);
        params.put("idNum", idCard == null ? "" : idCard);
        params.put("register_corpTel", tel == null ? "" : tel);
        params.put("register_prinName", URLDecoder.decode(name == null ? "" : name, "UTF-8"));
        params.put("prov", accountbankprovCode == null ? "" : accountbankprovCode);
        params.put("city", accountBankCityCode == null ? "" : accountBankCityCode);
        String bankCode = this.dictMapper.findDictBankName(b2cShopperbi.getAccountbankdictval()) == null ? "" :
                URLDecoder.decode(dictMapper.findDictBankName(b2cShopperbi.getAccountbankdictval()).getDictid(), "UTF-8");
        params.put("bankCode", bankCode);
        params.put("bankNo", accountbankno == null ? "" : accountbankno);
        params.put("bankName", accountbankname == null ? "" : URLDecoder.decode(accountbankname, "UTF-8"));
        params.put("register_corpFinanceName", URLDecoder.decode(name, "UTF-8"));
        params.put("linkman", name == null ? "" : URLDecoder.decode(name, "UTF-8"));
        params.put("register_corpLicenceNo", b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi.getLicenseNo());
        params.put("register_corpName", accountbankclientname == null ? "" : URLDecoder.decode(accountbankclientname, "UTF-8"));
        params.put("register_email", b2cShopperbi.getSemail() == null ? "" : b2cShopperbi.getSemail());
        params.put("register_corpAccountLicenceNo", b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi.getLicenseNo());
        params.put("register_corpOrganizeNo", b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi.getLicenseNo());
        params.put("register_corpTaxId", b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi.getLicenseNo());
        params.put("register_corpAddr", b2cShopperbi.getSaddress() == null ? "" : URLDecoder.decode(b2cShopperbi.getSaddress(), "UTF-8"));
        params.put("register_corpZip", b2cShopperbi.getSzip() == null ? "" : b2cShopperbi.getSzip());
        params.put("proxyId", agentNo == null ? "" : agentNo);
        params.put("merchantNo", merchantNo == null ? "" : merchantNo);
        params.put("institutionNo", institutionNo == null ? "" : institutionNo);
        params.put("commissionIds", merchantFeeList);
        params.put("issupportt0", issupportt0 == null ? "" : issupportt0);// 是否支持T0提现
        params.put("scompany", b2cShopperbi.getScompany());
        params.put("agentNo", b2cShopperbi.getShopperidP());
        params.put("terminalNo", b2cShopperbi.getHfpsamd0()); //弘付psam D0
        params.put("pscmNo", b2cShopperbi.getHfpsam() == null ? "" : b2cShopperbi.getHfpsam()); //弘付psam D1

        params.put("superShopperId", superShopperId); //上级商户ID(裂变)
        params.put("ifInvite", ifInvite); //是否裂变商户（1：是 0：否）

        params.put("profitOwner", b2cShopperbi.getProfitOwner());//分润给那个代理商
        params.put("agentProfitRatio", b2cShopperbi.getAgentProfitRatio()); //代理商分润百分比
        params.put("merchProfitRatio1", b2cShopperbi.getMerchProfitRatio1());//商户分润方案1
        params.put("merchProfitRatio2", b2cShopperbi.getMerchProfitRatio2()); //商户分润方案2
        params.put("merchProfitRatio3", b2cShopperbi.getMerchProfitRatio3()); //商户分润方案3
        net.sf.json.JSONObject obs = net.sf.json.JSONObject.fromObject(params);
        System.out.println("注册银生宝企业：" + ConstantsEnv.SIMPLE_REGISTER_COMPANY_URL + obs.toString());
        String resultString = HttpClientUtils.REpostRequestStr1(ConstantsEnv.SIMPLE_REGISTER_COMPANY_URL, obs.toString());
        Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);

        return resultMap;
    }

    /**
     * 注册扫码支付
     *
     * @return
     */
    public HashMap regQrcodeMerchant(HttpServletRequest request, String userType, B2cShopperbiTemp b2cShopperbiTemp) throws Exception {
        HashMap hashMap = new HashMap();
        //注册扫码
        Map qrcodeMap = saveQrCode(request, null, userType, b2cShopperbiTemp);
        if (null != qrcodeMap && Constants.SUCCESS_CODE.equals(qrcodeMap.get("flag"))) {
            hashMap.put(Constants.RSP_CODE, Constants.SUCCESS_CODE);
            hashMap.put(Constants.RSP_MSG, "注册扫码成功");
            hashMap.put("shopperid", b2cShopperbiTemp.getShopperid());
            hashMap.put("scompany", b2cShopperbiTemp.getScompany());
            hashMap.put("merchantKey", b2cShopperbiTemp.getMerchantKey());
            hashMap.put("qrpayMerchantkey", qrcodeMap.get("qrpayMerchantkey"));
        } else {
            hashMap.put(Constants.RSP_CODE, "0001");
            hashMap.put(Constants.RSP_MSG, "注册扫码失败");
            hashMap.put("shopperid", b2cShopperbiTemp.getShopperid());
            hashMap.put("scompany", b2cShopperbiTemp.getScompany());
            hashMap.put("merchantKey", b2cShopperbiTemp.getMerchantKey());
            hashMap.put("qrpayMerchantkey", "");
        }
        return hashMap;
    }

    /**
     * 注册扫码支付
     *
     * @param response
     * @param request
     * @param request
     * @param response
     * @param userType
     * @param b2cShopperbi
     * @return
     * @throws Exception
     */
    public Map saveQrCode(HttpServletRequest request, HttpServletResponse response, String userType,
                          B2cShopperbiTemp b2cShopperbi) throws Exception {
        Map map = new HashMap();
        //扫码支付
        String flag = "";
        Map qrMap = saveQrPay(userType, b2cShopperbi);
        if (Constants.SUCCESS_CODE.equals(qrMap.get(Constants.RSP_CODE))) {
            String qrPayNo = qrMap.get("qrPayNo") == null ? "" : qrMap.get("qrPayNo").toString();
            String qrpayMerchantkey = qrMap.get("qrpayMerchantkey") == null ? "" : qrMap.get("qrpayMerchantkey").toString();
            b2cShopperbi.setQrPayNo(qrPayNo);//扫码支付的账号
            b2cShopperbi.setQrpayMerchantkey(qrpayMerchantkey);//扫码支付的密钥

            Map map1 = new HashMap();
            map1.put("qrPayNo", b2cShopperbi.getQrPayNo());
            map1.put("qrpayMerchantkey", b2cShopperbi.getQrpayMerchantkey());
            map1.put("merchantNo", b2cShopperbi.getShopperid());
            map1.put("settleType", b2cShopperbi.getSettleType());//默认扫码1普通
            map1.put("creditLines", b2cShopperbi.getCreditLines());//扫码授信额度


            b2cShopperbiMapper.updateQrPayCode(map1);//修改正式表添加扫码支付的账号和密钥
            b2cShopperbiTempMapper.updateQrPayCode(map1);//修改临时表添加扫码支付的账号和密钥

            map.put("flag", "0000");
            map.put("qrPayNo", qrPayNo);
            map.put("qrpayMerchantkey", qrpayMerchantkey);
            flag = "0000";
            Log.info("=======扫码支付注册成功!==============");
        } else {
            map.put("flag", "6015");
        }
        return map;
    }

    /**
     * 扫码支付
     *
     * @param userType
     * @param b2cShopperbi
     * @return
     * @throws Exception
     */
    private Map saveQrPay(String userType,
                          B2cShopperbiTemp b2cShopperbi) throws Exception {
        String qrpayMerchantkey = RandomStringUtils.random(32, "0123456789ABCDEF");
        b2cShopperbi.setQrpayMerchantkey(qrpayMerchantkey);
        Map map = new HashMap();
        String flag = "";
        net.sf.json.JSONObject ob = null;
        String rspCode = "";
        String qrPayNo = "";
        // 区分企业还是个人
        Map ysbMap = null;
        if (Constants.TYPE_P.equals(userType)) {
            ysbMap = regQrPayMerchant(b2cShopperbi, userType);
        }
        if (Constants.TYPE_C.equals(userType)) {
            ysbMap = regQrPayCompany(b2cShopperbi, userType);
        }
        Log.info("扫码支付注册返回码:" + ysbMap);
        ob = net.sf.json.JSONObject.fromObject(ysbMap);
        rspCode = (String) ob.get(Constants.RSP_CODE);
        if (!Constants.SUCCESS_CODE.equals(rspCode)) {
            /****/
            map.put(Constants.RSP_CODE, rspCode);
            return map;
        } else {
            Log.info("扫码支付实名认证成功" + ob.toString());
            qrPayNo = (String) ob.get("userId");

            map.put("qrPayNo", qrPayNo);
            map.put("qrpayMerchantkey", qrpayMerchantkey);
            map.put(Constants.RSP_CODE, rspCode);
            flag = rspCode;
            return map;
        }
    }

    /**
     * 扫码支付
     *
     * @param b2cShopperbi
     * @param userType
     * @return
     * @throws Exception
     */
    public Map regQrPayMerchant(B2cShopperbiTemp b2cShopperbi, String userType) throws Exception {

        HashMap params = new HashMap();

        Date dates = new Date();
        String mradom = RandomStringUtils.randomNumeric(6);
        String orderId = DateUtil.getTypeDate(dates, "yyyyMMdd") + mradom + b2cShopperbi.getShopperid();
        String orderTime = DateUtil.getTypeDate(dates, "yyyyMMddhhmmss");
        // 基本信息
        String linkName = b2cShopperbi.getName();
        String idCard = b2cShopperbi.getIDNo();
        String tel = b2cShopperbi.getStel();
        String merchantNo = b2cShopperbi.getShopperid() == null ? "" : b2cShopperbi.getShopperid().toString();
        Long agentNo = b2cShopperbi.getShopperidP();
        String institutionNo = b2cShopperbi.getOrgNo();
        String platformType = "";
        platformType = Constants.CON_NO;
		/*if (agentNo != null) {
			platformType = Constants.CON_NO;// 0 自有
		} else {
			platformType = Constants.CON_YES;// 机构
		}*/
        // 结算信息
        String settlementType = b2cShopperbi.getSettlementType();
        String accountbankname = b2cShopperbi.getAccountbankname();
        String accountbankprovCode = b2cShopperbi.getAccountBankProvCode();
        String accountBankCityCode = b2cShopperbi.getAccountBankCityCode();
        String accountbankclientname = b2cShopperbi.getAccountbankclientname();
        String accountbankno = b2cShopperbi.getAccountbankno();

        String superShopperId = "";
        String ifInvite = "0";
        if (StringUtils.isNotEmpty(b2cShopperbi.getInviteCodeP())) {
            B2cShopperbiTemp b2cShopperbiTempNew = b2cShopperbiTempMapper.findShopperByInviteCode(b2cShopperbi.getInviteCodeP());
            if (null != b2cShopperbiTempNew) {
                superShopperId = b2cShopperbiTempNew.getShopperid().toString();
                ifInvite = "1";
            }
        }

        //省市
        String accountBankCity = b2cShopperbi.getAccountBankCity();
        String accountbankprov = b2cShopperbi.getAccountbankprov();
        // 扫码支付
        List merchantFeeList = mposMerchantFeeMapper.findQrPayMerchantFeeList2(b2cShopperbi.getShopperid().toString());

        String qrD0fee = mposMerchantFeeMapper.findQrPayMerchantFee(b2cShopperbi.getShopperid().toString());


        // t+0手续费
        String issupportt0 = b2cShopperbi.getIsSupportT0(); // 0支持
        String isicapplyt0 = "";
        Double t0singledaylimit = 0.00;
        if (Constants.CON_NO.equals(issupportt0)) {
            isicapplyt0 = b2cShopperbi.getIsIcApplyT0();
            t0singledaylimit = b2cShopperbi.getT0SingleDayLimit();
            params.put("t0fee", qrD0fee);
            params.put("t0fixedamount", b2cShopperbi.getT0fixedamount());
            params.put("t0minamount", b2cShopperbi.getT0minamount());
            params.put("t0maxamount", b2cShopperbi.getT0maxamount());
            params.put("creditAmount", t0singledaylimit == null ? "" : t0singledaylimit);
        } else {
            params.put("t0fee", "0");
            params.put("t0fixedamount", "0");
            params.put("t0minamount", "0");
            params.put("t0maxamount", "0");
            params.put("creditAmount", "0");
        }
        params.put("userType", userType == null ? "" : userType);
        params.put("orderId", orderId == null ? "" : orderId);
        params.put("orderTime", orderTime == null ? "" : orderTime);
        params.put("name", linkName == null ? "" : URLDecoder.decode(linkName, "UTF-8"));
        params.put("idNum", idCard == null ? "" : idCard);
        params.put("mobilePhoneNum", tel == null ? "" : tel);
        String bankCode = this.dictMapper.findDictBankName(b2cShopperbi.getAccountbankdictval()) == null ? "" : URLDecoder.decode(
                dictMapper.findDictBankName(b2cShopperbi.getAccountbankdictval()).getDictid(), "UTF-8");
        params.put("bankCode", bankCode == null ? "" : bankCode);
        params.put("bankNo", accountbankno == null ? "" : accountbankno);
        params.put("bankName", accountbankname == null ? "" : URLDecoder.decode(accountbankname, "UTF-8"));
        params.put("prov", accountbankprovCode == null ? "" : accountbankprovCode);
        params.put("city", accountBankCityCode == null ? "" : accountBankCityCode);
        //开户银行
        String openingBankName = dictMapper.findDictBankName(b2cShopperbi.getAccountbankdictval()) == null ? "" : dictMapper.findDictBankName(b2cShopperbi.getAccountbankdictval()).getDict();
        params.put("openingBankName", openingBankName);
        params.put("cityName", accountBankCity);
        params.put("provinceName", accountbankprov);
        params.put("merchantNo", merchantNo == null ? "" : merchantNo);
        params.put("proxyId", agentNo == null ? "" : agentNo);
        params.put("institutionNo", institutionNo == null ? "" : institutionNo);
        params.put("platformType", platformType == null ? "" : platformType);
        //params.put("settlementType", settlementType == null ? "": settlementType);
        params.put("commissionIds", merchantFeeList);
        params.put("issupportt0", issupportt0 == null ? "" : issupportt0);// 是否支持T0提现

        String scompany = b2cShopperbi.getScompany();//商户名称
        String qrMerchantKey = b2cShopperbi.getQrpayMerchantkey();//扫码秘钥
        params.put("scompany", null == scompany ? "" : scompany);
        params.put("qrMerchantKey", null == qrMerchantKey ? "" : qrMerchantKey);
        params.put("agentNo", agentNo);


        params.put("fixQrcodePic", "");
        params.put("fixQrcodeCustomerName", b2cShopperbi.getFixqrcodecustomername());
        params.put("isExternalRevenue", b2cShopperbi.getIsexternalrevenue());

        params.put("superShopperId", superShopperId); //上级商户ID(裂变)
        params.put("ifInvite", ifInvite); //是否裂变商户（1：是 0：否）

        params.put("settleType", b2cShopperbi.getSettleType());//1是普通
        params.put("creditLines", b2cShopperbi.getCreditLines().toString());//5万

        params.put("profitOwner", b2cShopperbi.getProfitOwner());//分润给那个代理商
        params.put("agentProfitRatio", b2cShopperbi.getAgentProfitRatio()); //代理商分润百分比
        params.put("merchProfitRatio1", b2cShopperbi.getMerchProfitRatio1());//商户分润方案1
        params.put("merchProfitRatio2", b2cShopperbi.getMerchProfitRatio2()); //商户分润方案2
        params.put("merchProfitRatio3", b2cShopperbi.getMerchProfitRatio3()); //商户分润方案3


        //扫码注册睿付添加四个字段
        String unionBankCode = dictMapper.findUnionBankCode(b2cShopperbi.getAccountbankdictval());
        String cityCode = b2cShopperbi.getCity();
        Area area1 = areaMapper.findPayeeBankProvinceAndCity(cityCode);

        params.put("merchAddress", b2cShopperbi.getSaddress());//商户地址
        params.put("payeeBankId", unionBankCode);//银行卡所在联行总行号
        params.put("payeeBankProvince", area1.getShProvincial());//睿付开户行省份编码
        params.put("payeeBankCity", area1.getShCity());//睿付开户行城市编码


        net.sf.json.JSONObject obs = net.sf.json.JSONObject.fromObject(params);
        Log.info("注册扫码支付个人：" + ConstantsEnv.REG_QR_PAY_MERCHANT_URL + obs.toString());
        String resultString = HttpClientUtils.REpostRequestStr1(
                ConstantsEnv.REG_QR_PAY_MERCHANT_URL, obs.toString());
        Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);

        return resultMap;

    }

    /**
     * 扫码支付企业注册
     *
     * @param b2cShopperbi
     * @param userType
     * @return
     * @throws UnsupportedEncodingException
     */
    public Map regQrPayCompany(B2cShopperbiTemp b2cShopperbi, String userType) throws Exception {

        HashMap params = new HashMap();
        Date dates = new Date();
        String mradom = RandomStringUtils.randomNumeric(6);
        String orderId = DateUtil.getTypeDate(dates, "yyyyMMdd") + mradom + b2cShopperbi.getShopperid();
        String orderTime = DateUtil.getTypeDate(dates, "yyyyMMddhhmmss");

        // 基本信息
        String name = b2cShopperbi.getName();
        String idCard = b2cShopperbi.getIDNo();
        String tel = b2cShopperbi.getStel();
        String merchantNo = b2cShopperbi.getShopperid() == null ? "" : b2cShopperbi.getShopperid().toString();
        Long agentNo = b2cShopperbi.getShopperidP();
        String institutionNo = b2cShopperbi.getOrgNo();
        String platformType = "";

        if (agentNo != null) {
            platformType = Constants.CON_NO;// 0 自有
        } else {
            platformType = Constants.CON_YES;// 机构
        }
        // 结算信息
        String settlementType = b2cShopperbi.getSettlementType();
        String accountBankDictval = b2cShopperbi.getAccountbankdictval();
        String accountbankname = b2cShopperbi.getAccountbankname();
        String accountbankprovCode = b2cShopperbi.getAccountBankProvCode();
        String accountBankCityCode = b2cShopperbi.getAccountBankCityCode();
        String accountbankclientname = b2cShopperbi.getAccountbankclientname();
        String accountbankno = b2cShopperbi.getAccountbankno();

        String superShopperId = "";
        String ifInvite = "0";
        if (StringUtils.isNotEmpty(b2cShopperbi.getInviteCodeP())) {
            B2cShopperbiTemp b2cShopperbiTempNew = b2cShopperbiTempMapper.findShopperByInviteCode(b2cShopperbi.getInviteCodeP());
            if (null != b2cShopperbiTempNew) {
                superShopperId = b2cShopperbiTempNew.getShopperid().toString();
                ifInvite = "1";
            }
        }

        //省市
        String accountBankCity = b2cShopperbi.getAccountBankCity();
        String accountbankprov = b2cShopperbi.getAccountbankprov();
        // 刷卡手续费
        List merchantFeeList = mposMerchantFeeMapper.findQrPayMerchantFeeList(b2cShopperbi.getShopperid().toString());
        String qrD0fee = mposMerchantFeeMapper.findQrPayMerchantFee(b2cShopperbi.getShopperid().toString());
        String issupportt0 = b2cShopperbi.getIsSupportT0(); // 0支持
        String isicapplyt0 = "";
        Double t0singledaylimit = 0.00;
        if (Constants.CON_NO.equals(issupportt0)) {
            isicapplyt0 = b2cShopperbi.getIsIcApplyT0();
            t0singledaylimit = b2cShopperbi.getT0SingleDayLimit();
            params.put("t0fee", qrD0fee);
            params.put("t0fixedamount", b2cShopperbi.getT0fixedamount());
            params.put("t0minamount", b2cShopperbi.getT0minamount());
            params.put("t0maxamount", b2cShopperbi.getT0maxamount());
            params.put("creditAmount", t0singledaylimit == null ? "" : t0singledaylimit);
            params.put("t0singledaylimit", t0singledaylimit == null ? "" : t0singledaylimit);
        } else {
            params.put("t0fee", "0");
            params.put("t0fixedamount", "0");
            params.put("t0minamount", "0");
            params.put("t0maxamount", "0");
            params.put("creditAmount", "0");
            params.put("t0singledaylimit", "0");
        }
        params.put("userType", userType == null ? "" : userType);
        params.put("orderId", orderId == null ? "" : orderId);
        params.put("orderTime", orderTime == null ? "" : orderTime);
        params.put("idNum", idCard == null ? "" : idCard);
        params.put("register_corpTel", tel == null ? "" : tel);
        params.put("register_prinName", URLDecoder.decode(name == null ? "" : name, "UTF-8"));
        params.put("prov", accountbankprovCode == null ? "" : accountbankprovCode);
        params.put("city", accountBankCityCode == null ? "" : accountBankCityCode);
        String bankCode = dictMapper.findDictBankName(b2cShopperbi.getAccountbankdictval()) == null ? "" :
                URLDecoder.decode(dictMapper.findDictBankName(b2cShopperbi.getAccountbankdictval()).getDictid(), "UTF-8");
        params.put("bankCode", bankCode);
        params.put("bankNo", accountbankno == null ? "" : accountbankno);
        params.put("bankName", accountbankname == null ? "" : URLDecoder.decode(accountbankname, "UTF-8"));
        params.put("cityName", accountBankCity);
        params.put("provinceName", accountbankprov);
        //开户银行
        String openingBankName = dictMapper.findDictBankName(b2cShopperbi.getAccountbankdictval()) == null ? "" : dictMapper.findDictBankName(b2cShopperbi.getAccountbankdictval()).getDict();
        params.put("openingBankName", openingBankName);
        params.put("register_corpFinanceName", URLDecoder.decode(name, "UTF-8"));
        params.put("linkman", name == null ? "" : URLDecoder.decode(name, "UTF-8"));
        params.put("register_corpLicenceNo", b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi.getLicenseNo());
        params.put("register_corpName", accountbankclientname == null ? "" : URLDecoder.decode(accountbankclientname, "UTF-8"));
        params.put("register_email", b2cShopperbi.getSemail() == null ? "" : b2cShopperbi.getSemail());
        params.put("register_corpAccountLicenceNo", b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi.getLicenseNo());
        params.put("register_corpOrganizeNo", b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi.getLicenseNo());
        params.put("register_corpTaxId", b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi.getLicenseNo());
        params.put("register_corpAddr", b2cShopperbi.getSaddress() == null ? "" : URLDecoder.decode(b2cShopperbi.getSaddress(), "UTF-8"));
        params.put("register_corpZip", b2cShopperbi.getSzip() == null ? "" : b2cShopperbi.getSzip());
        params.put("proxyId", agentNo == null ? "" : agentNo);
        params.put("merchantNo", merchantNo == null ? "" : merchantNo);
        params.put("institutionNo", institutionNo == null ? "" : institutionNo);
        //params.put("settlementType", settlementType == null ? "": settlementType);
        params.put("commissionIds", merchantFeeList);
        params.put("issupportt0", issupportt0 == null ? "" : issupportt0);// 是否支持T0提现

        String qrMerchantKey = b2cShopperbi.getQrpayMerchantkey();
        params.put("qrMerchantKey", null == qrMerchantKey ? "" : qrMerchantKey);
        params.put("agentNo", agentNo);

        params.put("fixQrcodePic", "");
        params.put("fixQrcodeCustomerName", b2cShopperbi.getFixqrcodecustomername());
        params.put("isExternalRevenue", b2cShopperbi.getIsexternalrevenue());
        params.put("settleType", Constants.CON_NO);

        params.put("superShopperId", superShopperId); //上级商户ID(裂变)
        params.put("ifInvite", ifInvite); //是否裂变商户（1：是 0：否）

        params.put("settleType", b2cShopperbi.getSettleType());//1是普通
        params.put("creditLines", b2cShopperbi.getCreditLines().toString());//5万


        //扫码注册睿付添加四个字段
        String unionBankCode = dictMapper.findUnionBankCode(b2cShopperbi.getAccountbankdictval());
        String cityCode = b2cShopperbi.getCity();
        Area area1 = areaMapper.findPayeeBankProvinceAndCity(cityCode);

        params.put("merchAddress", b2cShopperbi.getSaddress());//商户地址
        params.put("payeeBankId", unionBankCode);//银行卡所在联行总行号
        params.put("payeeBankProvince", area1.getShProvincial());//睿付开户行省份编码
        params.put("payeeBankCity", area1.getShCity());//睿付开户行城市编码


        params.put("profitOwner", b2cShopperbi.getProfitOwner());//分润给那个代理商
        params.put("agentProfitRatio", b2cShopperbi.getAgentProfitRatio()); //代理商分润百分比
        params.put("merchProfitRatio1", b2cShopperbi.getMerchProfitRatio1());//商户分润方案1
        params.put("merchProfitRatio2", b2cShopperbi.getMerchProfitRatio2()); //商户分润方案2
        params.put("merchProfitRatio3", b2cShopperbi.getMerchProfitRatio3()); //商户分润方案3
        net.sf.json.JSONObject obs = net.sf.json.JSONObject.fromObject(params);
        System.out.println("扫码支付企业注册：" + ConstantsEnv.REG_QR_PAY_COMPANY_URL + obs.toString());
        String resultString = HttpClientUtils.REpostRequestStr1(ConstantsEnv.REG_QR_PAY_COMPANY_URL, obs.toString());
        Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);

        return resultMap;

    }

    /**
     * 激活mpos和扫码
     */
    public Map activateMposAndQrcode(B2cShopperbiTemp b2cShopperbi) throws Exception {
        //激活MPOS
        Map activateMposResultMap = activateMerchantPort(b2cShopperbi);
        JSONObject ob= JSONObject.fromObject(activateMposResultMap);
        String rspCode=(String)ob.get("rspCode");
        String rspMsg=(String)ob.get("rspMsg");
        Log.info("激活MPOS结果：" + rspCode + rspMsg);

        //激活扫码
        Map activateQrPayResultMap = activateQrPayMerchantPort(b2cShopperbi);
        JSONObject qrpay= JSONObject.fromObject(activateQrPayResultMap);
        String qrpayRspCode=(String)qrpay.get("rspCode");
        Log.info("激活扫码结果：" + qrpayRspCode);
        
        Map resultMap = new HashMap();
        resultMap.put("rspCode", rspCode);
        resultMap.put("qrpayRspCode", qrpayRspCode);
        return resultMap;
    }

    /**
     * 激活MPOS
     * @throws Exception
     */
    private Map activateMerchantPort(B2cShopperbiTemp b2cShopperbiTemp) throws Exception {
        HashMap params=new HashMap();

        Date dates = new Date();
        String mradom = org.apache.commons.lang.RandomStringUtils.randomNumeric(6);
        String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbiTemp.getB2cShopperbiId();
        String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");

        params.put("orderId", orderId);
        params.put("userId", b2cShopperbiTemp.getYsbNo());
        params.put("activeStatus", Constants.TYPE_2);//已激活

        JSONObject obs = JSONObject.fromObject(params);
        String request = "activeStatus=" + Constants.TYPE_2 + "&orderId="+orderId+"&userId="+ b2cShopperbiTemp.getYsbNo() ;
        Log.info("请求激活银生宝账号请求参数："+request);
        Log.info("请求激活银生宝账号："+DynamicConfigLoader.getByEnv("update_user_status_url")+request);
        String result = HttpClientUtils.REpostRequestStrNormal(DynamicConfigLoader.getByEnv("update_user_status_url"), request);
        Map resultMap = JsonUtil.jsonStrToMap(result);

        return resultMap;

    }

    /**激活扫码
     * @param b2cShopperbi
     * @return
     * @throws Exception
     */
    private Map activateQrPayMerchantPort(B2cShopperbiTemp b2cShopperbi) throws Exception {

        HashMap params=new HashMap();

        Date dates = new Date();
        String mradom = org.apache.commons.lang.RandomStringUtils.randomNumeric(6);
        String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbi.getB2cShopperbiId();
        String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");

        params.put("orderId", orderId);
        params.put("userId", b2cShopperbi.getQrPayNo());
        params.put("activeStatus", Constants.TYPE_2);//已激活

        JSONObject obs = JSONObject.fromObject(params);
        String request = "activeStatus=" + Constants.TYPE_2 + "&orderId="+orderId+"&userId="+ b2cShopperbi.getQrPayNo();
        Log.info("请求激活扫码支付账号："+DynamicConfigLoader.getByEnv("update_qrpay_user_status_url")+request.toString());
        String result = HttpClientUtils.REpostRequestStrNormal(DynamicConfigLoader.getByEnv("update_qrpay_user_status_url"), request);

        Map resultMap = JsonUtil.jsonStrToMap(result);
        Log.info("请求激活扫码支付账号返回码："+resultMap.toString());
        return resultMap;
    }

}
