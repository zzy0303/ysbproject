package com.uns.dao;

import java.math.BigDecimal;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.TAppGrantAuthorization;
@Repository
public interface TAppGrantAuthorizationMapper {


    int deleteByPrimaryKey(BigDecimal authorizationId);

    int insert(TAppGrantAuthorization record);

    int insertSelective(TAppGrantAuthorization record);

    TAppGrantAuthorization selectByPrimaryKey(BigDecimal authorizationId);

    int updateByPrimaryKeySelective(TAppGrantAuthorization record);

    int updateByPrimaryKey(TAppGrantAuthorization record);

	TAppGrantAuthorization findTAppGrantAuthorization(Map map);

	void updateAuthorization(TAppGrantAuthorization tAppGrantAuthorization);

	TAppGrantAuthorization findTAppGrantAuthorizationUuid(Map map);

}