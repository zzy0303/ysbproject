package com.uns.dao;

import com.uns.model.B2cShopperbargainTemp;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

@Repository
public interface B2cShopperbargainTempMapper {

    int deleteByPrimaryKey(BigDecimal b2cShopperbargainId);

    int insert(B2cShopperbargainTemp record);

    int insertSelective(B2cShopperbargainTemp record);

    B2cShopperbargainTemp selectByPrimaryKey(BigDecimal b2cShopperbargainId);

    int updateByPrimaryKeySelective(B2cShopperbargainTemp record);

    int updateByPrimaryKey(B2cShopperbargainTemp record);

    B2cShopperbargainTemp selectByShopperbiId(Long shopperbiId);

	void updateByShopperId(B2cShopperbargainTemp b2cShopperbargain);
	
}