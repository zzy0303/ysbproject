package com.uns.bean;

import java.util.List;

public class PageBean {
	private int totalPage;
	private int previous;
	private int next;
	private int curPage;
	private int length;
	private int totalCount;
	private int first;
	private List data;
	public PageBean(){
	}
	        
	/**
	 * 构造方法
	 * 
	 * @param count		总记录数
	 * @param currPage		当前页
	 * @param pageSize  每页记录数
	 */
	public PageBean(int count,int currPage,int pageSize){
		int pg = (int)Math.ceil(new Double(count).doubleValue()/pageSize);//pg 总页数
        this.setTotalCount(count);
		this.setTotalPage(pg);
		this.setLength(pageSize);
		
		if(pg == 0){
			this.setCurPage(0);
		}
		else{
			this.setCurPage(currPage);
		}
		if(currPage == pg){
			this.setNext(pg);
		}
		else{
			this.setNext(currPage + 1);
		}
		if(currPage == 1){
			this.setPrevious(1);
		}
		else{
			this.setPrevious(currPage - 1);
		}
		if(totalCount == 0) {
			this.setFirst(0);
		} else {
			this.setFirst(1);
		}
	}
	
	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	public int getCurPage() {
		return curPage;
	}
	public void setCurPage(int curPage) {
		this.curPage = curPage;
	}
	public List getData() {
		return data;
	}
	public void setData(List data) {
		this.data = data;
	}
	public int getNext() {
		return next;
	}
	public void setNext(int next) {
		this.next = next;
	}
	public int getPrevious() {
		return previous;
	}
	public void setPrevious(int previous) {
		this.previous = previous;
	}
	public int getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}

	public int getFirst() {
		return first;
	}

	public void setFirst(int first) {
		this.first = first;
	}

}
