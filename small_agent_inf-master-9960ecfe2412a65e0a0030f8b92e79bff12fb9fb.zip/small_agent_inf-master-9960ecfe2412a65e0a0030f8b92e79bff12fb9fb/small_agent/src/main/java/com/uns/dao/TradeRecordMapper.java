package com.uns.dao;

import com.uns.model.TradeRecord;
import org.springframework.stereotype.Repository;

@Repository
public interface TradeRecordMapper {
	int deleteByPrimaryKey(String id);

    int insert(TradeRecord record);

    int insertSelective(TradeRecord record);

    TradeRecord selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TradeRecord record);

    int updateByPrimaryKey(TradeRecord record);
    
    int getMposOrderId();
}