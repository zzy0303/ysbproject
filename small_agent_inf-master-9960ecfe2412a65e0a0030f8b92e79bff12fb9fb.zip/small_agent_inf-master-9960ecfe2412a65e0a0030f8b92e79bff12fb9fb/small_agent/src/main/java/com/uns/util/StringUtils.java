/**
 * Copyright (c) 2006-2009 by Shanghai UnuTrip Network Technology Development Co.,Ltd
 * All rights reserved.
 */

package com.uns.util;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.regex.Pattern;


/**
 * 
 * @author danson 2009-11-19
 */
public abstract class StringUtils {

	/**
	 * 将 TEXT 文本转换为 HTML 代码, 已便于网页正确的显示出来.
	 * 
	 * @param input
	 *            输入的文本字符串
	 * @return 转换后的 HTML 代码
	 */
	public static String textToHtml(String input) {
		if (isEmpty(input)) {
			return "";
		}

		input = replace(input, "<", "&#60;");
		input = replace(input, ">", "&#62;");

		input = replace(input, "\n", "<br>\n");
		input = replace(input, "\t", "&nbsp;&nbsp;&nbsp;&nbsp;");
		input = replace(input, "  ", "&nbsp;&nbsp;");

		return input;
	}

	// ------------------------------------ 字符串处理方法
	// ----------------------------------------------

	/**
	 * 将字符串 source 中的 oldStr 替换为 newStr, 并以大小写敏感方式进行查找
	 * 
	 * @param source
	 *            需要替换的源字符串
	 * @param oldStr
	 *            需要被替换的老字符串
	 * @param newStr
	 *            替换为的新字符串
	 */
	public static String replace(String source, String oldStr, String newStr) {
		return replace(source, oldStr, newStr, true);
	}

	/**
	 * 将字符串 source 中的 oldStr 替换为 newStr, matchCase 为是否设置大小写敏感查找
	 * 
	 * @param source
	 *            需要替换的源字符串
	 * @param oldStr
	 *            需要被替换的老字符串
	 * @param newStr
	 *            替换为的新字符串
	 * @param matchCase
	 *            是否需要按照大小写敏感方式查找
	 */
	public static String replace(String source, String oldStr, String newStr,
			boolean matchCase) {
		if (source == null) {
			return null;
		}
		// 首先检查旧字符串是否存在, 不存在就不进行替换
		if (source.toLowerCase().indexOf(oldStr.toLowerCase()) == -1) {
			return source;
		}
		int findStartPos = 0;
		int a = 0;
		while (a > -1) {
			int b = 0;
			String str1, str2, str3, str4, strA, strB;
			str1 = source;
			str2 = str1.toLowerCase();
			str3 = oldStr;
			str4 = str3.toLowerCase();
			if (matchCase) {
				strA = str1;
				strB = str3;
			} else {
				strA = str2;
				strB = str4;
			}
			a = strA.indexOf(strB, findStartPos);
			if (a > -1) {
				b = oldStr.length();
				findStartPos = a + b;
				StringBuffer bbuf = new StringBuffer(source);
				source = bbuf.replace(a, a + b, newStr) + "";
				// 新的查找开始点位于替换后的字符串的结尾
				findStartPos = findStartPos + newStr.length() - b;
			}
		}
		return source;
	}

	/**
	 * 
	 * @param arg
	 * @return
	 */
	public static boolean isTrimNotEmpty(String arg) {
		if (arg != null && !arg.trim().isEmpty()) {
			return true;
		} else {
			return false;
		}
	}

	public static String add(String arg1, String arg2) {
		String result = null;
		if (arg1 != null || arg2 != null) {
			if (arg1 == null) {
				result = arg2;
			} else if (arg2 == null) {
				result = arg1;
			} else {
				result = arg1 + arg2;
			}
		}
		return result;
	}

	/**
	 * 截取从one到two中间的字符
	 * 
	 * @param source
	 * @param one
	 * @param two
	 * @return
	 */
	public static String subStringBychar(String source, String one, String two) {
		int ione = source.lastIndexOf(one);
		int itwo = source.lastIndexOf(two);
		String result = source.substring(ione + 1, itwo);
		return result;
	}

	/**
	 * 判断字符是否为空
	 * 
	 * @param s
	 * @return boolean
	 */
	public static boolean isEmpty(String s) {
		return s == null || "".equals(s);
	}
	
	/**
	 * 数据组装字符串
	 * @param object
	 * @return
	 */
	public static String arrayToString(Object[] object) {
		 String str = "";
		 if(object != null && object.length > 0) {
	    	for(int i=0; i<object.length; i++) {
	    		if(i == object.length-1) {
	    			str+= object[i];
	    		} else {
	    			str+= object[i]+",";
	    		}
		    }
		 }
		 return str;
	}
	
	/**
	 * 正则匹配是否是手机号码格式
	 * @param mobile
	 * @return
	 */
	public static boolean isMobile(String mobile) {
		boolean flag = Pattern.compile("^[0-9]{11}$").matcher(mobile).matches();
		return flag;
	}
	
	public static String[] list4strings(List<String> lists) throws Exception{
		String[] strs = {};
		for(int i=0;i<lists.size();i++){
			strs[i]=lists.get(i);
		}
		return strs;
	}
	/**
	 * 获取24小时制的当前时间
	 * @return
	 */
	public static String getToday(){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		return sdf.format(new Date());
	}
	
	/**
	 * 获取24小时制的当前时间
	 * 格式：yyyy/MM/dd HH:mm:ss
	 * @return
	 * @throws ParseException
	 */
	public static Date getToday1() throws ParseException{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		String date = sdf.format(new Date());
		return sdf.parse(date);
	}
	
	public String dateFormat(String date){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		Date d =null;
		try {
			d = sdf.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return sdf.format(d);
	}
	
	
	/**随机生成数字与字母组合
	 * @param length
	 * @return
	 */
	public static String getCharAndNumr(int length)     
	{     
	    String val = "";     
	             
	    Random random = new Random();     
	    for(int i = 0; i < length; i++)     
	    {     
	        String charOrNum = random.nextInt(2) % 2 == 0 ? "char" : "num"; // 输出字母还是数字     
	                 
	        if("char".equalsIgnoreCase(charOrNum)) // 字符串     
	        {     
	            int choice = random.nextInt(2) % 2 == 0 ? 65 : 97; //取得大写字母还是小写字母     
	            val += (char) (choice + random.nextInt(26));     
	        }     
	        else if("num".equalsIgnoreCase(charOrNum)) // 数字     
	        {     
	            val += String.valueOf(random.nextInt(10));     
	        }     
	    }     
	             
	    return val;     
	}  
	
	static SimpleDateFormat sf = new SimpleDateFormat("yyyyMMddHHmmss");
	/**
	 * mpos生成定单号 
	 */
    public static String getOrderId(int param){
    	DecimalFormat df=new DecimalFormat("000000");
        String str=df.format(param);
        return sf.format(new Date()) + str;
    }

	/**
	 * 字符串指定位置替换字符
	 *
	 * @param index
	 * @param res
	 * @param str
	 * @return
	 */
	public static String replaceIndex(int index, String res, String str) {
		return res.substring(0, index) + str + res.substring(index + 1);
	}
}
