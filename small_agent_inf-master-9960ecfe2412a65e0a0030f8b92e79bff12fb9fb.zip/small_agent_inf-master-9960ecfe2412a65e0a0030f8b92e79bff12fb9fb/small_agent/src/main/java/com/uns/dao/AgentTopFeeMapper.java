package com.uns.dao;

import com.uns.model.AgentTopFee;
import org.springframework.stereotype.Repository;

@Repository
public interface AgentTopFeeMapper {


    int insert(AgentTopFee record);

    int insertSelective(AgentTopFee record);
    
    void updateById(AgentTopFee agenttopfee);
    
    AgentTopFee findbyid();


}