package com.uns.model;

import java.util.ArrayList;
import java.util.List;

public class AgentSplit {
	private Long agentid;
	private Long lowestamt;
	private String modeflag;
	private String updatedate;
	private String updatemaker;
	private String remark;
	private List<AgentMcc> agentMccs = new ArrayList<AgentMcc>();
	//TMP
	private String effectdt;
	private String auditFlag;
	
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getEffectdt() {
		return effectdt;
	}
	public void setEffectdt(String effectdt) {
		this.effectdt = effectdt;
	}
	public String getAuditFlag() {
		return auditFlag;
	}
	public void setAuditFlag(String auditFlag) {
		this.auditFlag = auditFlag;
	}
	public List<AgentMcc> getAgentMccs() {
		return agentMccs;
	}
	public void setAgentMccs(List<AgentMcc> agentMccs) {
		this.agentMccs = agentMccs;
	}
	public Long getAgentid() {
		return agentid;
	}
	public void setAgentid(Long agentid) {
		this.agentid = agentid;
	}
	public Long getLowestamt() {
		return lowestamt;
	}
	public void setLowestamt(Long lowestamt) {
		this.lowestamt = lowestamt;
	}
	public String getModeflag() {
		return modeflag;
	}
	public void setModeflag(String modeflag) {
		this.modeflag = modeflag;
	}
	public String getUpdatedate() {
		return updatedate;
	}
	public void setUpdatedate(String updatedate) {
		this.updatedate = updatedate;
	}
	public String getUpdatemaker() {
		return updatemaker;
	}
	public void setUpdatemaker(String updatemaker) {
		this.updatemaker = updatemaker;
	}
	
}
