package com.uns.dao;

import com.uns.model.FixAmaount;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FixAmaountMapper {

    int insert(FixAmaount record);
    
    
    List searchFixAmaount();


}