package com.uns.model;


public class MposPhotoTmp {
    private Long photoId;

    private String handIdentityCardPhoto;

    private String frontIdentityCardPhoto;

    private String reverseIdentityCardPhoto;

    private String storePhoto;

    private String licensePhoto;

    private String instorePhoto;

    private String checkstandPhoto;

    private String signaturePhoto;
    
    
    private String checkFlag;
    
    private String identityid;
    
    private String creditCardPhoto;
    
    
    private String settlementCardPhoto;
    
    private String fixphoto;
    
    //11月3号添加
    private String livingBodyFacePhoto;//活体正面
    
    private String livingBodyLeftPhoto;//活体左转
    
    private String livingBodyReturnPhoto;//活体回正
    
    private String livingBodyRightPhoto;//活体右转
    
    private String idCardHeadPhoto;//身份证正面

	//新加商户认证
	private String lobbyPhoto; //大堂照片
	private String openLicensePhoto; //开户许可证
	private String merchantType; //商户类型

	public String getMerchantType() {
		return merchantType;
	}

	public void setMerchantType(String merchantType) {
		this.merchantType = merchantType;
	}

	public String getOpenLicensePhoto() {
		return openLicensePhoto;
	}

	public void setOpenLicensePhoto(String openLicensePhoto) {
		this.openLicensePhoto = openLicensePhoto;
	}

	public String getLobbyPhoto() {
		return lobbyPhoto;
	}

	public void setLobbyPhoto(String lobbyPhoto) {
		this.lobbyPhoto = lobbyPhoto;
	}

	public String getLivingBodyFacePhoto() {
		return livingBodyFacePhoto;
	}


	public void setLivingBodyFacePhoto(String livingBodyFacePhoto) {
		this.livingBodyFacePhoto = livingBodyFacePhoto;
	}


	public String getLivingBodyLeftPhoto() {
		return livingBodyLeftPhoto;
	}


	public void setLivingBodyLeftPhoto(String livingBodyLeftPhoto) {
		this.livingBodyLeftPhoto = livingBodyLeftPhoto;
	}


	public String getLivingBodyReturnPhoto() {
		return livingBodyReturnPhoto;
	}


	public void setLivingBodyReturnPhoto(String livingBodyReturnPhoto) {
		this.livingBodyReturnPhoto = livingBodyReturnPhoto;
	}


	public String getLivingBodyRightPhoto() {
		return livingBodyRightPhoto;
	}


	public void setLivingBodyRightPhoto(String livingBodyRightPhoto) {
		this.livingBodyRightPhoto = livingBodyRightPhoto;
	}


	public String getIdCardHeadPhoto() {
		return idCardHeadPhoto;
	}


	public void setIdCardHeadPhoto(String idCardHeadPhoto) {
		this.idCardHeadPhoto = idCardHeadPhoto;
	}


	public String getFixphoto() {
		return fixphoto;
	}


	public void setFixphoto(String fixphoto) {
		this.fixphoto = fixphoto;
	}


	public String getSettlementCardPhoto() {
		return settlementCardPhoto;
	}


	public void setSettlementCardPhoto(String settlementCardPhoto) {
		this.settlementCardPhoto = settlementCardPhoto;
	}


	public String getCreditCardPhoto() {
		return creditCardPhoto;
	}


	public void setCreditCardPhoto(String creditCardPhoto) {
		this.creditCardPhoto = creditCardPhoto;
	}


	public String getIdentityid() {
		return identityid;
	}


	public void setIdentityid(String identityid) {
		this.identityid = identityid;
	}


	public Long getPhotoId() {
		return photoId;
	}


	public void setPhotoId(Long photoId) {
		this.photoId = photoId;
	}


	public String getHandIdentityCardPhoto() {
		return handIdentityCardPhoto;
	}


	public void setHandIdentityCardPhoto(String handIdentityCardPhoto) {
		this.handIdentityCardPhoto = handIdentityCardPhoto;
	}


	public String getFrontIdentityCardPhoto() {
		return frontIdentityCardPhoto;
	}


	public void setFrontIdentityCardPhoto(String frontIdentityCardPhoto) {
		this.frontIdentityCardPhoto = frontIdentityCardPhoto;
	}


	public String getReverseIdentityCardPhoto() {
		return reverseIdentityCardPhoto;
	}


	public void setReverseIdentityCardPhoto(String reverseIdentityCardPhoto) {
		this.reverseIdentityCardPhoto = reverseIdentityCardPhoto;
	}


	public String getStorePhoto() {
		return storePhoto;
	}


	public void setStorePhoto(String storePhoto) {
		this.storePhoto = storePhoto;
	}


	public String getLicensePhoto() {
		return licensePhoto;
	}


	public void setLicensePhoto(String licensePhoto) {
		this.licensePhoto = licensePhoto;
	}


	public String getInstorePhoto() {
		return instorePhoto;
	}


	public void setInstorePhoto(String instorePhoto) {
		this.instorePhoto = instorePhoto;
	}


	public String getCheckstandPhoto() {
		return checkstandPhoto;
	}


	public void setCheckstandPhoto(String checkstandPhoto) {
		this.checkstandPhoto = checkstandPhoto;
	}


	public String getSignaturePhoto() {
		return signaturePhoto;
	}


	public void setSignaturePhoto(String signaturePhoto) {
		this.signaturePhoto = signaturePhoto;
	}


	public String getCheckFlag() {
		return checkFlag;
	}


	public void setCheckFlag(String checkFlag) {
		this.checkFlag = checkFlag;
	}

    
    
   
}