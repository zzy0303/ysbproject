package com.uns.dao;

import org.springframework.stereotype.Repository;

import java.util.Map;

@Repository
public interface QrCodeMapper {

	//根据shopperid查询QRPAYNO,QRPAY_MERCHANT_KEY
	Map<String, Object> queryQrCodeInfoByShopperId(String shopperid);

}
