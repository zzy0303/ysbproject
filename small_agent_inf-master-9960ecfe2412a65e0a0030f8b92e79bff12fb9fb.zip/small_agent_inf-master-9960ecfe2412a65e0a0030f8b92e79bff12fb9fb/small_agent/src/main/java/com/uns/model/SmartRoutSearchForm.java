package com.uns.model;


/**
 * 智能路由查询接口form
 * The type Smart rout search form.
 */
public class SmartRoutSearchForm {
    private String accountId;   //商户编号
    private String actionName;  //商户名称
    private String prov;        //所在地省份
    private String city;        //所在地城市
    private String agency;      //所属代理商
    private String accountType; //商户类型 1：支持mpos 2：支持二维码 3：支持mpos和二维码
    private String pageNo;      //当前页
    private String pageSize;    //每页数量
    private String count;   //总条数

    public String getPageNo() {
        return pageNo;
    }

    public void setPageNo(String pageNo) {
        this.pageNo = pageNo;
    }

    public String getPageSize() {
        return pageSize;
    }

    public void setPageSize(String pageSize) {
        this.pageSize = pageSize;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getActionName() {
        return actionName;
    }

    public void setActionName(String actionName) {
        this.actionName = actionName;
    }

    public String getProv() {
        return prov;
    }

    public void setProv(String prov) {
        this.prov = prov;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAgency() {
        return agency;
    }

    public void setAgency(String agency) {
        this.agency = agency;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }
}
