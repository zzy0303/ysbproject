package com.uns.common.page;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

public class PageContext extends Page {
	/**
	 * 
	 */
	protected Logger log = LoggerFactory.getLogger(this.getClass());

	private static ThreadLocal<PageContext> context = new ThreadLocal<PageContext>();

	private static String lastUrl;

	public static PageContext getContext() {
		PageContext ci = context.get();
		if (ci == null) {
			ci = new PageContext();
			context.set(ci);
		}
		return ci;
	}
	
	public static void initPageSize(int pageSize){
		PageContext.getContext().setPageSize(pageSize);
	}

	public static void removeContext() {
		context.remove();
	}

	protected void initialize() {
		
	}

	public static String getLastUrl() {
		return lastUrl;
	}

	public static void setLastUrl(String lastUrl) {
		PageContext.lastUrl = lastUrl;
	}
	
	/**
	 * Filter中调用的
	 * @param field
	 */
	public static void initSort(String field) {
		PageContext context = PageContext.getContext();
		
		if(field == null || "".equals(field))
			return;
		
		if(field.equals(context.sortField))
			context.sortDESC = !context.sortDESC;
		context.sortField = field;
	}
	
	/**
	 * Controller中调用的
	 * @param mapper
	 */
	public static void processSort(Map<String,String> mapper) {
		PageContext context = PageContext.getContext();
		
		if(context.sortField == null || "".equals(context.sortField) || mapper == null){
			context.orderBy = null;
			return;
		}
		
		//如果存在排序字段就处理
		String columnName = mapper.get(context.sortField);
		if(columnName != null && !"".equals(columnName))
			context.orderBy = columnName + " " + (context.sortDESC?"DESC":"ASC");
	}

}
