package com.uns.web;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.model.B2cShopperbi;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.B2cTempTermBinder;
import com.uns.model.B2cTermBinder;
import com.uns.service.AppBundlingService;
import com.uns.service.ShopPerbiService;
import com.uns.util.HkMerchantUtils;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Controller
@RequestMapping(value = "/appBundlingController.htm")
public class AppBundlingController extends BaseController {
	@Autowired
	private ShopPerbiService shopperbiservice; 
	
	@Autowired
	private AppBundlingService appBundlingService;
	
	
	@Autowired
	private HkMerchantUtils hkMerchantUtils;
	
	
	
   
	/**绑定设备号
	 * @param request
	 * @param response
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=devicenumbunding")
	public void devicenumbunding(HttpServletRequest request,HttpServletResponse response) throws Exception {
			String version=request.getParameter("version");
			String type=request.getParameter("type");
//			if(Constants.VERSION_2_0_0.equals(version)||Constants.VERSION_2_0_1.equals(version)){
				if(Constants.TYPE_A.equals(type)){
					boundDevienNoAndroid200(request,response);
				}else{
					boundDevienNoISO200(request,response);
				}
		/*	}else{
				boundDevienNo(request,response);
			}*/
		
	}
	
	private void boundDevienNo(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Map hashMap=new HashMap();
		try{
		String tel=request.getParameter("tel") == null ? "" : request.getParameter("tel");
		String deviceNum=request.getParameter("deviceNum")==null?"":request.getParameter("deviceNum");
		log.info("绑定终端："+"tel:	"+tel+"	deviceNum:"+deviceNum);
		B2cTermBinder termno=null;
		if(StringUtils.isEmpty(deviceNum)){
			 hashMap.put("returnCode", "1111");
			 hashMap.put("msg", "设备号为空");
		     response.setContentType("UTF-8");
			 JSONObject json = JSONObject.fromObject(hashMap);
			 log.info("设备号为空:" + json.toString());
			 response.getWriter().write(json.toString());
			 return;
		 }else{
			 termno=appBundlingService.findB2cTermBinderByTermNo(deviceNum.trim());
			 B2cShopperbiTemp shopper=shopperbiservice.findbytel(tel);
			 //终端的自动绑定：
			 if(shopper!=null){
				 String shopperid=shopper.getShopperid().toString();
				 String merchantAgentNo=shopperbiservice.findFisrtAgentByNo(shopper.getShopperidP()==null?"":shopper.getShopperidP().toString());
				 if(termno==null){
					 hashMap.put("returnCode", "1115");
					 hashMap.put("msg", "该终端没有入库！");
					 response.setContentType("UTF-8");
					 JSONObject json = JSONObject.fromObject(hashMap);
					 log.info("绑定失败:" + json.toString());
					 response.getWriter().write(json.toString());
					 return;
				 }
				 if(!(merchantAgentNo.equals(termno.getParent_agent_no()))){
					 hashMap.put("returnCode", "1113");
					 hashMap.put("msg", "请绑定该代理商下的终端设备！");
					 response.setContentType("UTF-8");
					 JSONObject json = JSONObject.fromObject(hashMap);
					 log.info("绑定失败:" + json.toString());
					 response.getWriter().write(json.toString());
					 return;
				 }
				 if(Constants.CON_YES.equals(termno.getInventory_status())){
					 hashMap.put("returnCode", "1114");
					 hashMap.put("msg", "已注销的设备不能绑定！");
					 response.setContentType("UTF-8");
					 JSONObject json = JSONObject.fromObject(hashMap);
					 log.info("绑定失败:" + json.toString());
					 response.getWriter().write(json.toString());
					 return;
				 }

				 if(termno!=null){
					 //调用moto_merchant远程接口
					 Map returnMap=boundTerminalPort(shopperid, deviceNum, shopper);
					 JSONObject ob= JSONObject.fromObject(returnMap);
					 System.out.println("绑定终端iso*************："+ob.toString());
					 String rspCode=ob.get("rspCode")==null?"":ob.get("rspCode").toString();
					 String returnMesg=ob.get("rspMsg")==null?"":ob.get("rspMsg").toString();
					 if(Constants.SUCCESS_CODE.equals(rspCode)){
						 appBundlingService.updateTermBinder(shopper,termno);
						 hashMap.put("returnCode", "0000");
						 hashMap.put("msg", "绑定成功");
						 response.setContentType("UTF-8");
						 JSONObject json = JSONObject.fromObject(hashMap);
						 log.info("绑定成功:" + json.toString());
						 response.getWriter().write(json.toString());
						 return;
					}else{
						 hashMap.put("returnCode", rspCode);
						 hashMap.put("msg", returnMesg);
						 response.setContentType("UTF-8");
						 JSONObject json = JSONObject.fromObject(hashMap);
						 log.info("绑定失败:" + json.toString());
						 response.getWriter().write(json.toString());
						 return;
					}
				 }else{
					 	hashMap.put("returnCode", "3333");
				    	hashMap.put("msg", "设备号不存在");
						response.setContentType("UTF-8");
						JSONObject json = JSONObject.fromObject(hashMap);
						log.info("设备号已存在:" + json.toString());
						response.getWriter().write(json.toString());
						return;
				 }
			 }else{
				    hashMap.put("returnCode", "1112");
				    hashMap.put("msg", "商户不存在");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("绑定失败:" + json.toString());
					response.getWriter().write(json.toString());
					return;
			 }
		 }
		}catch(Exception e){
		    e.printStackTrace();
			hashMap.put("returnCode", "2222");
			hashMap.put("msg", "绑定出错");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("绑定失败:" + json.toString());
			response.getWriter().write(json.toString());
	 }




	}

	private Map boundTerminalPort(String shopperid, String deviceNum,B2cShopperbiTemp shopper) throws Exception {
		Map regMap=new HashMap();
		B2cShopperbi b2cShopperbi=shopperbiservice.selectFormalShopperId(shopperid);
		regMap.put("deviceNumber", deviceNum);
		regMap.put("scompay", URLEncoder.encode(b2cShopperbi.getScompany(), "UTF-8"));
		regMap.put("youngMerchant",shopperid);
		regMap.put("ysbNo", b2cShopperbi.getYsbNo());
		regMap.put("merchantType", Constants.TYPE_2);//机构为1
		regMap.put("cardType",  shopper.getCardType()); //0 费率 1是封顶
		regMap.put("shopperbiType",  shopper.getMerchantType()); //0 个人 1是企业
		regMap.put("version", Constants.VERSION_2_0_0);
		regMap.put("type",  Constants.TYPE_I);
		regMap.put("sprovince",  URLEncoder.encode(shopper.getSprovince(), "UTF-8")); //终端所属 地区
		regMap.put("province",  shopper.getProvince()); //终端所属 地区

		//
		List list=shopperbiservice.findMposMerchantFee(shopperid);
		regMap.put("fee", list);
		String deviceNo="";
		B2cTermBinder b2cTermBinder=getDiveceNo(shopperid);
		if(b2cTermBinder!=null){
			deviceNo=b2cTermBinder.getTermNo();
		}
		regMap.put("deviceNo", deviceNo);

		JSONObject obs = JSONObject.fromObject(regMap);
		String url= ConstantsEnv.REG_SHOUDAN_URL+obs.toString()+"";
		org.apache.http.client.HttpClient httpclient=new DefaultHttpClient();
		url=url.replace("\"", "%22");
		url=url.replace("{", "%7B");
		url=url.replace("}", "%7D");
		HttpPost httpget=new HttpPost(url);

		HttpResponse httprespone;

		httprespone = httpclient.execute(httpget);

		String str = EntityUtils.toString(httprespone.getEntity());
		Map map1 = com.uns.util.JsonUtil.jsonStrToMap(str);
		return map1;
	}


	private void boundDevienNoISO200(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Map hashMap=new HashMap();
		try{
		String tel=request.getParameter("tel") == null ? "" : request.getParameter("tel");
		String deviceNum=request.getParameter("deviceNum")==null?"":request.getParameter("deviceNum");
		log.info("绑定终端："+"tel:	"+tel+"	deviceNum:"+deviceNum);
		B2cTermBinder termno=null;
		if(StringUtils.isEmpty(deviceNum)){
			 hashMap.put("rspCode", "1111");
			 hashMap.put("rspMsg", "设备号为空");
		     response.setContentType("UTF-8");
			 JSONObject json = JSONObject.fromObject(hashMap);
			 log.info("设备号为空:" + json.toString());
			 response.getWriter().write(json.toString());
			 return;
		 }else{
			 termno=appBundlingService.findB2cTermBinderByTermNo(deviceNum.trim());
			 B2cShopperbiTemp shopper=shopperbiservice.findbytel(tel);
			 //终端的自动绑定：
			 if(shopper!=null){
				 String shopperid=shopper.getShopperid().toString();
				 String merchantAgentNo=shopperbiservice.findFisrtAgentByNo(shopper.getShopperidP()==null?"":shopper.getShopperidP().toString());
				 if(termno==null){
					 hashMap.put("rspCode", "1115");
					 hashMap.put("rspMsg", "该终端没有入库！");
					 response.setContentType("UTF-8");
					 JSONObject json = JSONObject.fromObject(hashMap);
					 log.info("绑定失败:" + json.toString());
					 response.getWriter().write(json.toString());
					 return;
				 }
				 if(!(merchantAgentNo.equals(termno.getParent_agent_no()))){
					 hashMap.put("rspCode", "1113");
					 hashMap.put("rspMsg", "请绑定该代理商下的终端设备！");
					 response.setContentType("UTF-8");
					 JSONObject json = JSONObject.fromObject(hashMap);
					 log.info("绑定失败:" + json.toString());
					 response.getWriter().write(json.toString());
					 return;
				 }
				 if(Constants.CON_YES.equals(termno.getInventory_status())){
					 hashMap.put("rspCode", "1114");
					 hashMap.put("rspMsg", "已注销的设备不能绑定！");
					 response.setContentType("UTF-8");
					 JSONObject json = JSONObject.fromObject(hashMap);
					 log.info("绑定失败:" + json.toString());
					 response.getWriter().write(json.toString());
					 return;
				 }

				 if(termno!=null){
					 //调用moto_merchant远程接口
					 Map returnMap=boundTerminalPort200(request,shopperid,deviceNum,shopper);
					 JSONObject ob= JSONObject.fromObject(returnMap);
					 System.out.println("绑定终端iso*************："+ob.toString());
					 String rspCode=ob.get("rspCode")==null?"":ob.get("rspCode").toString();
					 String returnMesg=ob.get("rspMsg")==null?"":ob.get("rspMsg").toString();
					 String terminalNo=ob.get("terminalNo")==null?"":ob.get("terminalNo").toString();
					 String mianKey=ob.get("mianKey")==null?"":ob.get("mianKey").toString();
					 if(Constants.SUCCESS_CODE.equals(rspCode)){
						 //调用海科终端主密钥报备
						 String hkCOde=hkMerchantUtils.addHkTerminalPort(shopperid,terminalNo,mianKey);
						 if("00".equals(hkCOde)){
							 appBundlingService.updateTermBinder(shopper,termno);
							 hashMap.put("rspCode", "0000");
							 hashMap.put("rspMsg", "绑定成功");
							 response.setContentType("UTF-8");
							 JSONObject json = JSONObject.fromObject(hashMap);
							 log.info("绑定成功:" + json.toString());
							 response.getWriter().write(json.toString());
							 return;
						 }else{
							 hashMap.put("rspCode", "1115");
							 hashMap.put("rspMsg", "绑定失败");
							 response.setContentType("UTF-8");
							 JSONObject json = JSONObject.fromObject(hashMap);
							 log.info("绑定成功:" + json.toString());
							 response.getWriter().write(json.toString());
							 return;
						 }
					}else{
						 hashMap.put("rspCode", rspCode);
						 hashMap.put("rspMsg", returnMesg);
						 response.setContentType("UTF-8");
						 JSONObject json = JSONObject.fromObject(hashMap);
						 log.info("绑定失败:" + json.toString());
						 response.getWriter().write(json.toString());
						 return;
					}
				 }else{
					 	hashMap.put("rspCode", "3333");
				    	hashMap.put("rspMsg", "设备号不存在");
						response.setContentType("UTF-8");
						JSONObject json = JSONObject.fromObject(hashMap);
						log.info("设备号已存在:" + json.toString());
						response.getWriter().write(json.toString());
						return;
				 }
			 }else{
				    hashMap.put("rspCode", "1112");
				    hashMap.put("rspMsg", "商户不存在");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("绑定失败:" + json.toString());
					response.getWriter().write(json.toString());
					return;
			 }
		 }
		}catch(Exception e){
		    e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "绑定出错");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("绑定失败:" + json.toString());
			response.getWriter().write(json.toString());
	 }

	}

	/*private void boundDevienNoISO200(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Map hashMap=new HashMap();
		try{
		String tel=request.getParameter("tel") == null ? "" : request.getParameter("tel");
		String deviceNum=request.getParameter("deviceNum")==null?"":request.getParameter("deviceNum");
		log.info("绑定终端："+"tel:"+tel+"deviceNum:"+deviceNum);
		B2cTermBinder termno=null;
		if(org.apache.commons.lang.StringUtils.isEmpty(deviceNum)){
			 hashMap.put("rspCode", "1111");
			 hashMap.put("rspMsg", "设备号为空");
		     response.setContentType("UTF-8");
			 JSONObject json = JSONObject.fromObject(hashMap);
			 log.info("设备号为空:" + json.toString());
			 response.getWriter().write(json.toString());
			 return;
		 }else{
			 termno=appBundlingService.findB2cTermBinderByTermNo(deviceNum.trim());
			 B2cShopperbiTemp shopper=shopperbiservice.findbytel(tel);
			 //终端的自动绑定：
			 if(shopper!=null){
				 String shopperid=shopper.getShopperid().toString();
				 String merchantAgentNo=shopperbiservice.findFisrtAgentByNo(shopper.getShopperidP()==null?"":shopper.getShopperidP().toString());
				 if(!(merchantAgentNo.equals(termno.getParent_agent_no()))){
					 hashMap.put("rspCode", "1113");
					 hashMap.put("rspMsg", "请绑定该代理商下的终端设备！");
					 response.setContentType("UTF-8");
					 JSONObject json = JSONObject.fromObject(hashMap);
					 log.info("绑定失败:" + json.toString());
					 response.getWriter().write(json.toString());
					 return;
				 }
				 if(Constants.CON_YES.equals(termno.getInventory_status())){
					 hashMap.put("rspCode", "1114");
					 hashMap.put("rspMsg", "已注销的设备不能绑定！");
					 response.setContentType("UTF-8");
					 JSONObject json = JSONObject.fromObject(hashMap);
					 log.info("绑定失败:" + json.toString());
					 response.getWriter().write(json.toString());
					 return;
				 }
				 if(termno!=null){
					 //调用moto_merchant远程接口
					 Map returnMap=boundTerminalPort200(request,shopperid,deviceNum,shopper);
					 JSONObject ob= JSONObject.fromObject(returnMap);
					 String rspCode=ob.get("rspCode")==null?"":ob.get("rspCode").toString();
					 String returnMesg=ob.get("rspMsg")==null?"":ob.get("resMsg").toString();
					 if(Constants.SUCCESS_CODE.equals(rspCode)){
						 appBundlingService.updateTermBinder(shopper,termno);
						 hashMap.put("rspCode", "0000");
						 hashMap.put("rspMsg", "绑定成功");
						 response.setContentType("UTF-8");
						 JSONObject json = JSONObject.fromObject(hashMap);
						 log.info("绑定成功:" + json.toString());
						 response.getWriter().write(json.toString());
						 return;
					}else{
						 hashMap.put("rspCode", rspCode);
						 hashMap.put("rspMsg", returnMesg);
						 response.setContentType("UTF-8");
						 JSONObject json = JSONObject.fromObject(hashMap);
						 log.info("绑定失败:" + json.toString());
						 response.getWriter().write(json.toString());
						 return;
					}
				 }else{
					 	hashMap.put("rspCode", "3333");
				    	hashMap.put("rspMsg", "设备号不存在");
						response.setContentType("UTF-8");
						JSONObject json = JSONObject.fromObject(hashMap);
						log.info("设备号已存在:" + json.toString());
						response.getWriter().write(json.toString());
						return;
				 }
			 }else{
				    hashMap.put("rspCode", "1112");
				    hashMap.put("rspMsg", "商户不存在");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("绑定失败:" + json.toString());
					response.getWriter().write(json.toString());
					return;
			 }
		 }
		}catch(Exception e){
		    e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "绑定出错");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("绑定失败:" + json.toString());
			response.getWriter().write(json.toString());
	 }
	}*/



	/**绑定终端2.0.0
	 * 1.根据终端设备序列号，查询一级代理商。
	 * 2.根据电话号码查询商户，根据商户号，查询一级代理商。
	 * 3.比较两个一家代理商是否一致，不一致绑定失败。
	 * 4.绑定终端
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	private void boundDevienNoAndroid200(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Map hashMap=new HashMap();
		try{
		String tel=request.getParameter("tel") == null ? "" : request.getParameter("tel");
		String deviceNum=request.getParameter("deviceNum")==null?"":request.getParameter("deviceNum");
		log.info("绑定终端："+"tel:	"+tel+"	deviceNum:"+deviceNum);
		B2cTermBinder termno=null;
		if(StringUtils.isEmpty(deviceNum)){
			 hashMap.put("rspCode", "1111");
			 hashMap.put("rspMsg", "设备号为空");
		     response.setContentType("UTF-8");
			 JSONObject json = JSONObject.fromObject(hashMap);
			 log.info("设备号为空:" + json.toString());
			 response.getWriter().write(json.toString());
			 return;
		 }else{
			 termno=appBundlingService.findB2cTermBinderByTermNo(deviceNum.trim());
			 B2cShopperbiTemp shopper=shopperbiservice.findbytel(tel);
			 //终端的自动绑定：
			 if(shopper!=null){
				 String shopperid=shopper.getShopperid().toString();
				 String merchantAgentNo=shopperbiservice.findFisrtAgentByNo(shopper.getShopperidP()==null?"":shopper.getShopperidP().toString());
				 if(termno==null){
					 hashMap.put("rspCode", "1115");
					 hashMap.put("rspMsg", "该终端没有入库！");
					 response.setContentType("UTF-8");
					 JSONObject json = JSONObject.fromObject(hashMap);
					 log.info("绑定失败:" + json.toString());
					 response.getWriter().write(json.toString());
					 return;
				 }
				 if(!(merchantAgentNo.equals(termno.getParent_agent_no()))){
					 hashMap.put("rspCode", "1113");
					 hashMap.put("rspMsg", "请绑定该代理商下的终端设备！");
					 response.setContentType("UTF-8");
					 JSONObject json = JSONObject.fromObject(hashMap);
					 log.info("绑定失败:" + json.toString());
					 response.getWriter().write(json.toString());
					 return;
				 }
				 if(Constants.CON_YES.equals(termno.getInventory_status())){
					 hashMap.put("rspCode", "1114");
					 hashMap.put("rspMsg", "已注销的设备不能绑定！");
					 response.setContentType("UTF-8");
					 JSONObject json = JSONObject.fromObject(hashMap);
					 log.info("绑定失败:" + json.toString());
					 response.getWriter().write(json.toString());
					 return;
				 }

				 if(termno!=null){
					 //调用moto_merchant远程接口
					 Map returnMap=boundTerminalPort200(request,shopperid,deviceNum,shopper);
					 JSONObject ob= JSONObject.fromObject(returnMap);
					 String rspCode=ob.get("rspCode")==null?"":ob.get("rspCode").toString();
					 String returnMesg=ob.get("rspMsg")==null?"":ob.get("rspMsg").toString();
					 String terminalNo=ob.get("terminalNo")==null?"":ob.get("terminalNo").toString();
					 String mianKey=ob.get("mianKey")==null?"":ob.get("mianKey").toString();
					 if(Constants.SUCCESS_CODE.equals(rspCode)){
						 //调用海科终端主密钥报备
						 String hkCOde=hkMerchantUtils.addHkTerminalPort(shopperid,terminalNo,mianKey);
						 if("00".equals(hkCOde)){
							 appBundlingService.updateTermBinder(shopper,termno);
							 hashMap.put("rspCode", "0000");
							 hashMap.put("rspMsg", "绑定成功");
							 response.setContentType("UTF-8");
							 JSONObject json = JSONObject.fromObject(hashMap);
							 log.info("绑定成功:" + json.toString());
							 response.getWriter().write(json.toString());
							 return;
						 }else{
							 hashMap.put("rspCode", "1115");
							 hashMap.put("rspMsg", "绑定失败");
							 response.setContentType("UTF-8");
							 JSONObject json = JSONObject.fromObject(hashMap);
							 log.info("绑定成功:" + json.toString());
							 response.getWriter().write(json.toString());
							 return;
						 }
					}else{
						 hashMap.put("rspCode", rspCode);
						 hashMap.put("rspMsg", returnMesg);
						 response.setContentType("UTF-8");
						 JSONObject json = JSONObject.fromObject(hashMap);
						 log.info("绑定失败:" + json.toString());
						 response.getWriter().write(json.toString());
						 return;
					}
				 }else{
					 	hashMap.put("rspCode", "3333");
				    	hashMap.put("rspMsg", "设备号不存在");
						response.setContentType("UTF-8");
						JSONObject json = JSONObject.fromObject(hashMap);
						log.info("设备号已存在:" + json.toString());
						response.getWriter().write(json.toString());
						return;
				 }
			 }else{
				    hashMap.put("rspCode", "1112");
				    hashMap.put("rspMsg", "商户不存在");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("绑定失败:" + json.toString());
					response.getWriter().write(json.toString());
					return;
			 }
		 }
		}catch(Exception e){
		    e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "绑定出错");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("绑定失败:" + json.toString());
			response.getWriter().write(json.toString());
	 }

	}





	/**绑定终端
	 * @param request
	 * @param b2cShopperbi
	 * @return
	 * @throws Exception
	 */
	private Map boundTerminalPort200(HttpServletRequest request, String shopperid,String deviceNum, B2cShopperbiTemp shopper) throws Exception {
		Map regMap=new HashMap();
		B2cShopperbi b2cShopperbi=shopperbiservice.selectFormalShopperId(shopperid);
		regMap.put("deviceNumber", deviceNum);
		regMap.put("scompay", URLEncoder.encode(b2cShopperbi.getScompany(), "UTF-8"));
		regMap.put("youngMerchant",shopperid);
		regMap.put("ysbNo", b2cShopperbi.getYsbNo());
		regMap.put("merchantType", Constants.TYPE_2);//机构为1
		regMap.put("version", request.getParameter("version")==""?"2.0.0":request.getParameter("version"));
		regMap.put("type",  request.getParameter("type")==""?"I":request.getParameter("type"));
		regMap.put("cardType",  Constants.CON_NO); //0 费率 1是封顶
		regMap.put("shopperbiType",  shopper.getMerchantType()); //0 个人 1是企业
		regMap.put("sprovince",  URLEncoder.encode(shopper.getSprovince(), "UTF-8")); //终端所属 地区
		regMap.put("province",  shopper.getProvince()); //终端所属 地区


		//
		List list=shopperbiservice.findMposMerchantFeezhifu(shopperid);
		regMap.put("fee", list);
		String deviceNo="";
		B2cTermBinder b2cTermBinder=getDiveceNo(shopperid);
		if(b2cTermBinder!=null){
			deviceNo=b2cTermBinder.getTermNo();
		}
		regMap.put("deviceNo", deviceNo);

		JSONObject obs = JSONObject.fromObject(regMap);
		String url= ConstantsEnv.REG_SHOUDAN_URL+obs.toString()+"";
		log.info("绑定终端请求："+url);
		org.apache.http.client.HttpClient httpclient=new DefaultHttpClient();
		url=url.replace("\"", "%22");
		url=url.replace("{", "%7B");
		url=url.replace("}", "%7D");
		HttpPost httpget=new HttpPost(url);

		HttpResponse httprespone;

		httprespone = httpclient.execute(httpget);

		String str = EntityUtils.toString(httprespone.getEntity());
		Map map1 = com.uns.util.JsonUtil.jsonStrToMap(str);
		return map1;
	}

	/**
	 * @param merchantNo
	 * @return
	 */
	public B2cTermBinder getDiveceNo(String merchantNo) {
		List list=shopperbiservice.findDiveceNo(merchantNo);
		B2cTermBinder b2cTermBinder=null;
		if(list!=null&&list.size()>0){
			b2cTermBinder=(B2cTermBinder)list.get(0);
		}
		return b2cTermBinder;
	}

	/**终端正式信息绑定
	 * @param shopperid
	 * @param deviceNum
	 * @return
	 */
	private B2cTermBinder createB2cTermBinder(String shopperid, String deviceNum) {
		B2cTermBinder b2cTermBinder=new B2cTermBinder();
		b2cTermBinder.setMerchantNo(shopperid);
		b2cTermBinder.setTermNo(deviceNum);
		b2cTermBinder.setCreateDate(new Date());
		b2cTermBinder.setStatus(Constants.STATUS0);
		return b2cTermBinder;
	}


	/**终端信息临时绑定表
	 * @param shopperid
	 * @param deviceNum
	 * @return
	 */
	private B2cTempTermBinder createB2cTempTermBinder(String shopperid,
			String deviceNum) {
		B2cTempTermBinder binder=new B2cTempTermBinder();
		binder.setMerchantNo(shopperid);
    	binder.setTermNo(deviceNum);
    	binder.setCreateDate(new Date());
    	binder.setStatus(Constants.STATUS1);
    	binder.setFirstVerify(Constants.STATUS1);
    	binder.setLastVerify(Constants.STATUS1);
		return binder;
	}


	/**查询已绑定的终端
	 * @param request
	 * @param response
	 * @throws Exception 绑定设备号
	 */
	@RequestMapping(params = "method=selectdevice")
	public void selectdevice(HttpServletRequest request,HttpServletResponse response) throws Exception {
		String version=request.getParameter("version");
		String type=request.getParameter("type");
		if(Constants.VERSION_2_0_0.equals(version)|| Constants.VERSION_2_0_1.equals(version) || Constants.VERSION_2_1_0.equals(version)){
			 if(Constants.TYPE_A.equals(type)){
				 findBoundDeviceNumberAndroid200(request,response);
			 }else{
				 findBoundDeviceNumberiSO200(request,response);
			 }
		}else{
			if(Constants.TYPE_A.equals(type)){
				findBoundDeviceNumberAndroid200(request,response);
			}else{
				findBoundDeviceNumberiSO200(request,response);
			}
		}


	}



	private void findBoundDeviceNumberiSO200(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Map hashMap=new HashMap();
		try{
			String tel=request.getParameter("tel") == null ? "" : request.getParameter("tel");
			B2cShopperbiTemp shopper=shopperbiservice.findbytel(tel);
			String merchantNo=shopper.getShopperid().toString();
			if(StringUtils.isNotEmpty(merchantNo)){
				String page = request.getParameter("page");
				Map curTranMap = shopperbiservice.findHisTranList(merchantNo, page, request);
				hashMap.put("devicelist", curTranMap.get("list"));
				hashMap.put("page", curTranMap.get("page"));
				hashMap.put("pages", curTranMap.get("pages"));
				hashMap.put("count", curTranMap.get("count"));
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "查询成功");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("查询成功:" + json.toString());
				response.getWriter().write(json.toString());
			}else{
				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "查询失败");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("查询失败:" + json.toString());
				response.getWriter().write(json.toString());
			}

		}catch(Exception e){
			    e.printStackTrace();
				hashMap.put("rspCode", "2222");
				hashMap.put("rspMsg", "ISO查询出错");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("查询失败:" + json.toString());
				response.getWriter().write(json.toString());
		 }

	}

	private void findBoundDeviceNumberAndroid200(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Map hashMap=new HashMap();
		try{
			String tel=request.getParameter("tel") == null ? "" : request.getParameter("tel");
			B2cShopperbiTemp shopper=shopperbiservice.findbytel(tel);
			String merchantNo=shopper.getShopperid().toString();
			if(StringUtils.isNotEmpty(merchantNo)){
				String page = request.getParameter("page");
				Map curTranMap = shopperbiservice.findHisTranList(merchantNo, page, request);
				hashMap.put("devicelist", curTranMap.get("list"));
				hashMap.put("page", curTranMap.get("page"));
				hashMap.put("pages", curTranMap.get("pages"));
				hashMap.put("count", curTranMap.get("count"));
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "查询成功");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("查询成功:" + json.toString());
				response.getWriter().write(json.toString());
			}else{
				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "查询失败");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("查询失败:" + json.toString());
				response.getWriter().write(json.toString());
			}

		}catch(Exception e){
			    e.printStackTrace();
				hashMap.put("rspCode", "2222");
				hashMap.put("rspMsg", "查询失败Android出错");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("查询失败:" + json.toString());
				response.getWriter().write(json.toString());
		 }

	}

	/**已绑定终端
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	private void findBoundDeviceNumber(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Map hashMap=new HashMap();
		try{
			String tel=request.getParameter("tel") == null ? "" : request.getParameter("tel");
			if(StringUtils.isNotEmpty(tel)){
				B2cShopperbiTemp shopper=shopperbiservice.findbytel(tel);
				String merchantNo=shopper.getShopperid().toString();
				if(StringUtils.isNotEmpty(merchantNo)){
					String page = request.getParameter("page");
					Map curTranMap = shopperbiservice.findHisTranList(merchantNo, page, request);
					hashMap.put("devicelist", curTranMap.get("list"));
					hashMap.put("page", curTranMap.get("page"));
					hashMap.put("pages", curTranMap.get("pages"));
					hashMap.put("count", curTranMap.get("count"));
					hashMap.put("returnCode", "0000");
					hashMap.put("msg", "查询成功");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("查询成功:" + json.toString());
					response.getWriter().write(json.toString()); 
				}else{
					hashMap.put("returnCode", "1111");
					hashMap.put("msg", "查询失败");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("查询失败:" + json.toString());
					response.getWriter().write(json.toString()); 
				}
			}else{
				hashMap.put("returnCode", "1002");
				hashMap.put("msg", "参数为空，查询失败");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("查询失败:" + json.toString());
				response.getWriter().write(json.toString()); 
			}
			
			
		}catch(Exception e){
			    e.printStackTrace();
				hashMap.put("returnCode", "2222");
				hashMap.put("msg", "查询出错");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("查询失败:" + json.toString());
				response.getWriter().write(json.toString()); 
		 }
		
	}

	public  String getPosShopperId(String area, String mcc) throws Exception {
        String organization="800"; 
        String areacold="";
        if (area.length()>4) {
            areacold=area.substring(0,4);
        }else {
            areacold=area;
        }   
        String mcccold="";  
        if (mcc.length()==1) {
            mcccold="000"+mcc;
        }else {
            mcccold="00"+mcc;
        }
        String merchantRadom=RandomStringUtils.randomNumeric(4);
        String posMerchantId=organization+areacold+mcccold+merchantRadom;
        B2cShopperbiTemp b2cShopperbi=shopperbiservice.queryShopPerbi(posMerchantId);
        if(b2cShopperbi!=null){
            return getPosShopperId(area,mcc);
        }
        return posMerchantId;
    }

	


}
