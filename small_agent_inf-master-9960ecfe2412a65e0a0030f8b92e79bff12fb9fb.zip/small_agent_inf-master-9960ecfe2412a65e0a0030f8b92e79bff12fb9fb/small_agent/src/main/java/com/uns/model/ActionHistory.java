package com.uns.model;

import java.io.Serializable;
import java.util.Date;

public class ActionHistory extends B2cTerminal implements Serializable {
    private Short id;

    private String changeType;

    private String oldVest;

    private String newVest;

    private Date createDate;

    private Date updateDate;

    private Date checkDate;

    private String checkStatus;

    private String terminalId;

    private String comments;
    
    private String oldscompany;
    private String newscompany;
    private String bankfiles;
    private String pnewscompany;
    private String poldscompany;

    public String getPnewscompany() {
		return pnewscompany;
	}

	public void setPnewscompany(String pnewscompany) {
		this.pnewscompany = pnewscompany;
	}

	public String getPoldscompany() {
		return poldscompany;
	}

	public void setPoldscompany(String poldscompany) {
		this.poldscompany = poldscompany;
	}

	public Short getId() {
        return id;
    }

    public void setId(Short id) {
        this.id = id;
    }

    public String getChangeType() {
        return changeType;
    }

    public void setChangeType(String changeType) {
        this.changeType = changeType;
    }

    public String getOldVest() {
        return oldVest;
    }

    public void setOldVest(String oldVest) {
        this.oldVest = oldVest;
    }

    public String getNewVest() {
        return newVest;
    }

    public void setNewVest(String newVest) {
        this.newVest = newVest;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public Date getCheckDate() {
        return checkDate;
    }

    public void setCheckDate(Date checkDate) {
        this.checkDate = checkDate;
    }

    public String getCheckStatus() {
        return checkStatus;
    }

    public void setCheckStatus(String checkStatus) {
        this.checkStatus = checkStatus;
    }

    public String getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

	public String getOldscompany() {
		return oldscompany;
	}

	public void setOldscompany(String oldscompany) {
		this.oldscompany = oldscompany;
	}

	public String getNewscompany() {
		return newscompany;
	}

	public void setNewscompany(String newscompany) {
		this.newscompany = newscompany;
	}

	public String getBankfiles() {
		return bankfiles;
	}

	public void setBankfiles(String bankfiles) {
		this.bankfiles = bankfiles;
	}
}