package com.uns.dao;

import com.uns.model.AgentRatio;
import com.uns.model.AgentSplit;
import com.uns.web.form.AgentForm;
import com.uns.web.form.AgentMccForm;
import com.uns.web.form.AgentRatioForm;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface AgentSplitMapper {


	//public List<AgentSplit> findAgentSplit();
	
	public List<AgentSplit> findAgentSplit(AgentForm form);

	public List<Map> isSplitTmp(Long shopperid);

	public List<Map> isSplit(Long shopperid);

	public AgentSplit findAgentSplitTmp(Long shopperid);

	public AgentSplit findAgentSplit1(Long shopperid);
	
	

	public AgentSplit searchAgentSplitTmpCP(AgentSplit agentSplit);

	public AgentSplit searchAgentSplitTmpCP2(AgentSplit agentSplit);

	public List<AgentSplit> getAgentSplit(Map map);
	

	public void saveEAgentSplit(AgentSplit agentSplit);

	public void saveEAgentMcc(AgentMccForm mccform);

	public void saveEAgentRatio(AgentRatio ratio);

	public void delESplitTmp(Long agentid);

	public void delEMccTmp(Long agentid);

	public void delERatioTmp(Long agentid);

	public void saveEAgentSplitTmp(AgentSplit agentSplit);

	public void saveEAgentMccTmp(AgentMccForm mccform);

	public void saveEAgentRatioTmp(AgentRatio ratio);

	public AgentSplit getAgentSplitByAgentid(String shopperid);

	public List<Map> findAgentSplitList(AgentRatioForm agentRatioForm);

	public List<AgentSplit> getAgentSplitTmp(AgentRatioForm agentRatioForm);

	public AgentSplit searchAgentSplit(Long agentid);

	public Map getAgentSplitByShoperid(String shopperid);

	public Map getAgentSplitTmp(Long shopperid);


}
