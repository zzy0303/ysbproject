package com.uns.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.inf.acms.client.config.ConfigInitLoadingConfigurer;

@Component
public class AcmsMapUtils {
	protected Logger logger = LoggerFactory.getLogger(this.getClass());
	
	private Map<String, String> acmsMap = new HashMap<String, String>();

	public Map<String, String> getAcmsMap() {
		return acmsMap;
	}

	public void setDcServiceUrl(Map<String, String> serviceUrl) {
		this.acmsMap = serviceUrl;
	}

	@PostConstruct
	public void init() {
		logger.info("{}参数MAP初始化...........init",ConfigInitLoadingConfigurer.getAppEnv());
		String env = ConfigInitLoadingConfigurer.getAppEnv();
		String key = env + ".";
		HashMap<String, String> map = DynamicConfigLoader.getMulti(key + "*");
		acmsMap.clear();
		Iterator<Map.Entry<String, String>> iter = map.entrySet().iterator();
		while (iter.hasNext()) {
			Map.Entry<String, String> entry = (Map.Entry<String, String>) iter.next();
			String mapKey = entry.getKey();
			String mapVal = entry.getValue();
			mapKey = mapKey.replaceAll(key, "");
			logger.info("参数初始化...........{} = {}",mapKey,mapVal);
			acmsMap.put(mapKey, mapVal);
		}
	}
}