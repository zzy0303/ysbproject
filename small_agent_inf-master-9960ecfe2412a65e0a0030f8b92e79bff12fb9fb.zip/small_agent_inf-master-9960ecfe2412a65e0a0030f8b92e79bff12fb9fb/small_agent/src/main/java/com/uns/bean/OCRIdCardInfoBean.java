package com.uns.bean;


/**
 * OCR上传身份证信息实体类
 * @author Administrator
 *
 */
public class OCRIdCardInfoBean {
	private String IDNo;//身份证ID
	private String name;//身份证姓名
	private String sex;//性别
	private String birthday;//生日
	private String nation;//民族
	private String saddress;//住址
	private String signUnit;//身份证签发机关
	private String usefulLife;//身份证有效期限
	private String sprovince;//身份证省名称
	private String scity;//身份证市名称
	private String stel;//联系电话
	private String province;//省编码
	private String city;//市编码
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getIDNo() {
		return IDNo;
	}
	public void setIDNo(String iDNo) {
		IDNo = iDNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getNation() {
		return nation;
	}
	public void setNation(String nation) {
		this.nation = nation;
	}
	public String getSaddress() {
		return saddress;
	}
	public void setSaddress(String saddress) {
		this.saddress = saddress;
	}
	public String getSignUnit() {
		return signUnit;
	}
	public void setSignUnit(String signUnit) {
		this.signUnit = signUnit;
	}
	public String getUsefulLife() {
		return usefulLife;
	}
	public void setUsefulLife(String usefulLife) {
		this.usefulLife = usefulLife;
	}
	public String getSprovince() {
		return sprovince;
	}
	public void setSprovince(String sprovince) {
		this.sprovince = sprovince;
	}
	public String getScity() {
		return scity;
	}
	public void setScity(String scity) {
		this.scity = scity;
	}
	public String getStel() {
		return stel;
	}
	public void setStel(String stel) {
		this.stel = stel;
	}
	@Override
	public String toString() {
		return "OCRIdCardInfoBean [IDNo=" + IDNo + ", name=" + name + ", sex="
				+ sex + ", birthday=" + birthday + ", nation=" + nation
				+ ", saddress=" + saddress + ", signUnit=" + signUnit
				+ ", usefulLife=" + usefulLife + ", sprovince=" + sprovince
				+ ", scity=" + scity + ", stel=" + stel + ", province="
				+ province + ", city=" + city + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
	
	
}
