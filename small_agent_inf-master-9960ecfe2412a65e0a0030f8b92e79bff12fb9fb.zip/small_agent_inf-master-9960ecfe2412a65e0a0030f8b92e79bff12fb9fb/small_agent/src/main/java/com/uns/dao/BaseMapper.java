package com.uns.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * dao的父接口,定义dao操作的基本规范。
 * @author Administrator
 *
 * @param <T>
 */
public interface BaseMapper<T> {

	int insert(T record);

	int insertSelective(T record);

	int updateByPrimaryKey(T record);

	int updateByPrimaryKeySelective(T record);

	void deleteByPrimaryKey(Serializable id);

	T selectByPrimaryKey(Serializable id);

	List selectListByMap(Map params);

	List selectListByObj(T record);
}
