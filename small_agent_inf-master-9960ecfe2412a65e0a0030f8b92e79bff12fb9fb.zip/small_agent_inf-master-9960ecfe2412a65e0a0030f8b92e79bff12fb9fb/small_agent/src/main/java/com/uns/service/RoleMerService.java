package com.uns.service;

import com.uns.common.Constants;
import com.uns.common.page.PageContext;
import com.uns.dao.FunctionMerInfoMapper;
import com.uns.dao.RoleMerFunctionMerMapper;
import com.uns.dao.RoleMerInfoMapper;
import com.uns.model.FunctionMerInfo;
import com.uns.model.RoleMerFunctionMer;
import com.uns.model.RoleMerInfo;
import com.uns.web.form.RoleForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Component
public class RoleMerService {
	
	@Autowired
	private FunctionMerInfoMapper functionMerInfoMapper;

	@Autowired
	private RoleMerFunctionMerMapper roleMerFunctionMerMapper;
	
	@Autowired
	private RoleMerInfoMapper roleMerInfoMapper;
	
	/**代理商角色查询
	 * @param mbForm
	 * @return
	 */
	public List selectRoleMerList(RoleForm mbForm)throws Exception {
		PageContext.initPageSize(20);
		return roleMerInfoMapper.selectRoleMerList(mbForm);
	}

	/**代理商权限查询
	 * @return
	 */
	public Map findAllFunction() throws Exception{
		List<FunctionMerInfo> functionMerInfoList=functionMerInfoMapper.selectByStatus(Long.valueOf(Constants.CON_YES));
		
		Map mapReturn = new HashMap();
		//循环遍历所有功能，放入map中，key为parentId_Id (上级功能Id和Id)
		for(Iterator iter = functionMerInfoList.iterator(); iter.hasNext();){
			FunctionMerInfo func = (FunctionMerInfo) iter.next();
			String strId = String.valueOf(func.getId());         //角色编号
			
			String strParentId = "1";          //初始值设为1
			if(func.getFunctionId()!= null){
				strParentId = String.valueOf(func.getFunctionId());
			}
			String strKey = strParentId + "_" + strId;
			mapReturn.put(strKey, func);
		}
		return mapReturn;
	}

	/**验证角色名称是否重复
	 * @param roleName
	 * @param operatorId
	 * @return
	 * @throws Exception
	 */
	public List<RoleMerInfo> getRoleInfoByName(String roleName,
			String operatorId)throws Exception {
		Map map=new HashMap();
		map.put("roleName", roleName.trim());
		map.put("createUser", Long.valueOf(operatorId));
		return roleMerInfoMapper.selectByMap(map);
	}

	/**添加角色和权限
	 * @param roleInfo
	 * @param ids
	 * @throws Exception
	 */
	public void insert(RoleMerInfo roleInfo, Long[] ids)throws Exception {
		roleMerInfoMapper.insert(roleInfo);
		for(int i=0;i<ids.length;i++){
			if(ids[i]!=null){
				RoleMerFunctionMer roleMerFunctionMer=new RoleMerFunctionMer();
				roleMerFunctionMer.setRoleId(roleInfo.getId());
				roleMerFunctionMer.setFunctionId(ids[i]);
				roleMerFunctionMerMapper.insert(roleMerFunctionMer);
			}
		}
		
	}
	/**根据主键查询角色
	 * @param id
	 * @return
	 * @throws Exception 
	 * @throws NumberFormatException 
	 */
	public RoleMerInfo selectByRoleId(String id)throws Exception {
		return roleMerInfoMapper.selectByPrimaryKey(Long.valueOf(id));
	}
	/**根据角色值返回权限
	 * @param id
	 * @return
	 * @throws Exception 
	 * @throws NumberFormatException 
	 */
	public List selectById(String id)throws Exception{
		List<FunctionMerInfo> functionInfoList=functionMerInfoMapper.selectByPrimaryKey(Long.valueOf(id));
		return functionInfoList;
	}
	/**修改角色权限
	 * @param roleInfo
	 * @param ids
	 * @throws Exception
	 */
	public void update(RoleMerInfo roleInfo, Long[] ids)throws Exception {
		roleMerInfoMapper.updateByPrimaryKey(roleInfo);
		roleMerFunctionMerMapper.deleteByRoleId(roleInfo.getId());
		RoleMerFunctionMer roleFunction=null;
		//保存角色权限表
		for(int i=0;i<ids.length;i++){
			if(ids[i]!=null){
				roleFunction=new RoleMerFunctionMer();
				roleFunction.setFunctionId(ids[i]);
				roleFunction.setRoleId(roleInfo.getId());
				roleMerFunctionMerMapper.insert(roleFunction);
			}
		}
	}

	/**删除角色和权限
	 * @param roleId
	 */
	public void delete(Long roleId)throws Exception {
		roleMerInfoMapper.deleteByPrimaryKey(roleId);
		roleMerFunctionMerMapper.deleteByRoleId(roleId);
	}
	/**查询角色
	 * @param operator 
	 * @param conYes
	 * @return
	 */
	public List<RoleMerInfo> selectRoleInfo(String status) {
		return roleMerInfoMapper.selectRoleInfo(status);
	}

}
