package com.uns.service;

import com.uns.dao.B2cShopperValMapper;
import com.uns.dao.B2cShopperbiTempMapper;
import com.uns.dao.UsersMapper;
import com.uns.model.B2cShopperVal;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.Users;
import com.uns.util.Md5Encrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class UserService {
	@Autowired
	private UsersMapper usersmapper;
	
	@Autowired
	private B2cShopperbiTempMapper shoppermapper;

	@Autowired
	private B2cShopperValMapper b2cShopperValMapper;
	
	public Users findbytel(String tel){
		return usersmapper.findbytel(tel);
	}
	
	public Users findbytelm(String tel){
		return usersmapper.findbytelm(tel);
	}
	
	public void updatepassword(Users user,B2cShopperbiTemp shoppertemp,String password){
		String mpassword=Md5Encrypt.md5(password);
		if(user!=null){
			user.setPassword(mpassword);
			usersmapper.updateByUsresId(user);
		}
		shoppertemp.setMpassword(mpassword);
		shoppermapper.updateByPrimaryKeySelective(shoppertemp);

		B2cShopperVal b2cShopperVal = new B2cShopperVal();
		b2cShopperVal.setTel(shoppertemp.getStel());
		b2cShopperVal.setPassword(password);
		b2cShopperValMapper.editByParam(b2cShopperVal);
	}
}
