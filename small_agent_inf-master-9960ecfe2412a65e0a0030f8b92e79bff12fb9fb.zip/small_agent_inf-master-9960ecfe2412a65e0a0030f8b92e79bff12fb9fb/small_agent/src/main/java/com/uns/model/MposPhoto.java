package com.uns.model;

public class MposPhoto {
    private Long photoId;

    private String handIdentityCardPhoto;

    private String frontIdentityCardPhoto;

    private String reverseIdentityCardPhoto;

    private String storePhoto;

    private String licensePhoto;

    private String instorePhoto;

    private String checkstandPhoto;
    
    private String signaturePhoto;
    
    
  
    public String getSignaturePhoto() {
		return signaturePhoto;
	}

	public void setSignaturePhoto(String signaturePhoto) {
		this.signaturePhoto = signaturePhoto;
	}

	public Long getPhotoId() {
        return photoId;
    }

    public void setPhotoId(Long photoId) {
        this.photoId = photoId;
    }

    public String getHandIdentityCardPhoto() {
        return handIdentityCardPhoto;
    }

    public void setHandIdentityCardPhoto(String handIdentityCardPhoto) {
        this.handIdentityCardPhoto = handIdentityCardPhoto == null ? null : handIdentityCardPhoto.trim();
    }

    public String getFrontIdentityCardPhoto() {
        return frontIdentityCardPhoto;
    }

    public void setFrontIdentityCardPhoto(String frontIdentityCardPhoto) {
        this.frontIdentityCardPhoto = frontIdentityCardPhoto == null ? null : frontIdentityCardPhoto.trim();
    }

    public String getReverseIdentityCardPhoto() {
        return reverseIdentityCardPhoto;
    }

    public void setReverseIdentityCardPhoto(String reverseIdentityCardPhoto) {
        this.reverseIdentityCardPhoto = reverseIdentityCardPhoto == null ? null : reverseIdentityCardPhoto.trim();
    }

    public String getStorePhoto() {
        return storePhoto;
    }

    public void setStorePhoto(String storePhoto) {
        this.storePhoto = storePhoto == null ? null : storePhoto.trim();
    }

    public String getLicensePhoto() {
        return licensePhoto;
    }

    public void setLicensePhoto(String licensePhoto) {
        this.licensePhoto = licensePhoto == null ? null : licensePhoto.trim();
    }

    public String getInstorePhoto() {
        return instorePhoto;
    }

    public void setInstorePhoto(String instorePhoto) {
        this.instorePhoto = instorePhoto == null ? null : instorePhoto.trim();
    }

    public String getCheckstandPhoto() {
        return checkstandPhoto;
    }

    public void setCheckstandPhoto(String checkstandPhoto) {
        this.checkstandPhoto = checkstandPhoto == null ? null : checkstandPhoto.trim();
    }
}