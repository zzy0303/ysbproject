package com.uns.dao;

import com.uns.web.form.AccountForm;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;


@Repository
public interface B2cSettleDetailMapper {
	
	/**结算统计信息汇总
	 * @param accountForm
	 * @return
	 */
	List<HashMap> selectHistoryList(AccountForm accountForm);
	
	List<HashMap> selectAllList(AccountForm accountForm);
	
	/**
	 * 
	 * 明细结算列表信息
	 * @return
	 */
	List<HashMap>  selectDetailsList(AccountForm accountForm);
	/**
	 * 
	 * 下载结算列表信息
	 * @return
	 */
	List<HashMap> getAccountList(AccountForm accountForm);
	/**
	 * 
	 * 下载未结算列表信息
	 * @return
	 */
	List<HashMap> getNotAccountList(AccountForm accountForm);
	/**
	 * 
	 * 下载ysb批付结算列表信息
	 * @return
	 */
	List<HashMap> getysbList(AccountForm accountForm);

	List<HashMap> outUnbalancedAcounntExcelList(
			AccountForm accountForm);
   

}
 

   