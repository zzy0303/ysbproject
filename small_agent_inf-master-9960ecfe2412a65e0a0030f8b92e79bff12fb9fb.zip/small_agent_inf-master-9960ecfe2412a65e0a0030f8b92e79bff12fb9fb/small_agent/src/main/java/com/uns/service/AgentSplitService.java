package com.uns.service;

import com.uns.common.page.PageContext;
import com.uns.dao.AgentMapper;
import com.uns.dao.AgentSplitMapper;
import com.uns.model.AgentRatio;
import com.uns.model.AgentSplit;
import com.uns.web.form.AgentForm;
import com.uns.web.form.AgentMccForm;
import com.uns.web.form.AgentRatioForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AgentSplitService {
	@Autowired
	private AgentSplitMapper agentSplitMapper;

	@Autowired
	private AgentMapper agentMapper;
	
	
	//查出所有代理商
	public List<AgentRatioForm> findB2cAgentList(Long shopperid) {
		PageContext.initPageSize(20);
		return agentMapper.findB2cAgentList(shopperid);
	}
	
	//查出所有代理商和对应分润设置
	public List<AgentSplit> findAgentSplitList(String shopperids) {
		AgentForm form=new AgentForm();
		form.setShopperids(shopperids);
		return agentSplitMapper.findAgentSplit(form);
	}

	public Boolean isSplitTmp(Long shopperid) {
		List<Map> list = agentSplitMapper.isSplitTmp(shopperid);
		if(list!=null && list.size()>0)
			return true;
		else 
			return false;
	}

	public Boolean isSplit(Long shopperid) {
		List<Map> list = agentSplitMapper.isSplit(shopperid);
		if(list!=null && list.size()>0)
			return true;
		else 
			return false;
	}

	public AgentSplit findAgentSplitTmp(Long shopperid) {
		return agentSplitMapper.findAgentSplitTmp(shopperid);
	}

	public AgentSplit findAgentSplit(Long shopperid) {
		return agentSplitMapper.findAgentSplit1(shopperid);
	}

	public AgentSplit searchAgentSplitTmpCP(Long agentid){
		AgentSplit agentSplit = new AgentSplit();
		agentSplit.setAgentid(agentid);
		return agentSplitMapper.searchAgentSplitTmpCP(agentSplit);
	}
	public AgentSplit searchAgentSplitTmpCP2(Long agentid){
		AgentSplit agentSplit = new AgentSplit();
		agentSplit.setAgentid(agentid);
		return agentSplitMapper.searchAgentSplitTmpCP2(agentSplit);
	}

	public List<AgentSplit> getAgentSplit(Long agentid) {
		Map map = new HashMap();
		map.put("shopperid", agentid);
		return agentSplitMapper.getAgentSplit(map);
	}

	public void editRatio(List<AgentMccForm> mccforms, AgentSplit agentSplit) {
		agentSplitMapper.saveEAgentSplit(agentSplit);
		for(AgentMccForm mccform:mccforms){
			agentSplitMapper.saveEAgentMcc(mccform);
			List<AgentRatio> ratios = mccform.getAgentRatios();
			for(AgentRatio ratio:ratios){
				agentSplitMapper.saveEAgentRatio(ratio);
			}
		}
		
	}

	public void editRatioTmp(List<AgentMccForm> mccforms, AgentSplit agentSplit) {
		agentSplitMapper.delESplitTmp(agentSplit.getAgentid());
		agentSplitMapper.delEMccTmp(agentSplit.getAgentid());
		agentSplitMapper.delERatioTmp(agentSplit.getAgentid());
		agentSplitMapper.saveEAgentSplitTmp(agentSplit);
		for(AgentMccForm mccform:mccforms){
			agentSplitMapper.saveEAgentMccTmp(mccform);
			List<AgentRatio> ratios = mccform.getAgentRatios();
			for(AgentRatio ratio:ratios){
				agentSplitMapper.saveEAgentRatioTmp(ratio);
			}
		}
	}

	public AgentSplit getAgentSplitByAgentid(String shopperid) {
		return agentSplitMapper.getAgentSplitByAgentid(shopperid);
	}

	public AgentSplit getAgentSplitByAgentidTmp(String shopperid) {
		return agentSplitMapper.findAgentSplitTmp(Long.valueOf(shopperid));
	}

	public List<Map> findAgentSplitList(AgentRatioForm agentRatioForm) {
		PageContext.initPageSize(20);
		return agentSplitMapper.findAgentSplitList(agentRatioForm);
	}

	public Map getAgentSplitTmp(Long shopperid) {
		return agentSplitMapper.getAgentSplitTmp(shopperid);
	}

	public AgentSplit searchAgentSplit(Long shopperid) {
		return agentSplitMapper.searchAgentSplit(shopperid);
	}

	public Map getAgentSplitByShoperid(String shopperid) {
		 return agentSplitMapper.getAgentSplitByShoperid(shopperid);
	}

	public List<AgentRatioForm> findB2cAgentFormList(String agentId) {
		return agentMapper.findB2cAgentFormList(agentId);
	}
	
	
}
