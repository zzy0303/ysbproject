package com.uns.web;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.JsonObject;
import com.uns.util.FastJson;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uns.common.myenum.MessageEnum;
import com.uns.model.*;
import com.uns.service.*;
import oracle.jdbc.driver.Const;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.model.Agent;
import com.uns.model.B2cDict;
import com.uns.model.B2cShopperbi;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.FixAmaount;
import com.uns.model.MposRemoteFee;
import com.uns.model.MposRemoteInvitation;
import com.uns.model.TAppGrantAuthorization;
import com.uns.model.Users;
import com.uns.service.AgentService;
import com.uns.service.AppAuthorizationService;
import com.uns.service.AppInformationService;
import com.uns.service.MposRemoteFeeService;
import com.uns.service.MposRemoteInvitationService;
import com.uns.service.ShopPerbiService;
import com.uns.service.UserService;
import com.uns.util.AcmsMapUtils;
import com.uns.util.AesEncrypt;
import com.uns.util.DateUtil;
import com.uns.util.HttpClientUtils;
import com.uns.util.Md5Encrypt;
import com.uns.util.ToolsUtils;
import com.unspay.base64.Base64Utils;
import com.unspay.rsa.RSAUtils;

import net.sf.json.JSONObject;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value = "/appLogin.htm")
public class AppLoginController extends BaseController {

	@Autowired
	private UserService userService;

	@Autowired
	private ShopPerbiService merchantregservice;

	@Autowired
	private MposRemoteInvitationService remotesrevice;

	@Autowired
	private MposRemoteFeeService remotefeeservice;
	
	
	@Autowired
	private AppInformationService appInformationService;

	@Autowired
	private B2cShopperValService b2cShopperValService;

	@Autowired
	private  AgentService   agentService;

	@Autowired
	private AcmsMapUtils acmsMapUtils;

	@Autowired
	private AppAuthorizationService appAuthorizationService;

	/**
	 * 开放注册商户登录
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(params = "method=openMerchantLogin")
	public void openMerchantLogin(HttpServletRequest request, HttpServletResponse response) throws IOException{
		String version = request.getParameter("version") == null ? "" : request.getParameter("version").trim();
		Map hashMap=new HashMap();
		if(Constants.VERSION_2_2_0.equals(version)){
			merchantlogin220(request, response);
		}else{
		    String merchantType = request.getParameter("merchantType") == null ? "" : request.getParameter("merchantType");
			if(Constants.VERSION_2_4_0.equals(version)){
			    if(Constants.TYPE_0.equals(merchantType)){ //个人
                    merchantlogin230(request, response);
                } else if(Constants.TYPE_2.equals(merchantType)){ //商户
                    merchantlogin240(request, response);
                }
			} else if(Constants.VERSION_2_3_0.equals(version)){ //2.3.0版本都为个人版
                merchantlogin230(request, response);
            } else{
				//			merchantlogin210(request, response);
				//收款方式判断
				List<Map<String, Object>> gatheringMethod = merchantregservice.findGatheringMethod();
				hashMap.put("gatheringMethod", gatheringMethod);

				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "请升级APP!");
				response.setContentType(Constants.CONTENT_TYPE_UTF8);
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("登录拦截:" + json.toString());
				response.getWriter().write(json.toString());
			}
		}
	}

	/**
	 * 查询用户认证信息
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(params = "method=findAttestation")
    @ResponseBody
	public Map findAttestation(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String version = request.getParameter("version") == null ? "" : request.getParameter("version").trim();
		String tel = request.getParameter("tel") == null ? "" : request.getParameter("tel").trim();
		Map hashMap = new HashMap();
		if(Constants.VERSION_2_4_0.equals(version)){
            hashMap = merchantregservice.findAttestationInfo(tel);
            log.info("查询用户认证状态:" + FastJson.toJson(hashMap));
		} else {
			hashMap.put("rspCode","1111");
			hashMap.put("rspMsg", "请升级APP!");
			response.setContentType(Constants.CONTENT_TYPE_UTF8);
			log.info("登录拦截:" + FastJson.toJson(hashMap));
		}
		return hashMap;
	}

	/**修改密码
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(params = "method=updatepassword")
	public void updatepassword(HttpServletRequest request,HttpServletResponse response) throws IOException {
		String version = request.getParameter("version") == null ? "" : request.getParameter("version");
		updatepassword220(request, response);
    }

	/**修改密码
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	public void updatepassword220(HttpServletRequest request, HttpServletResponse response) throws IOException {
		Map hashMap = new HashMap();
		try {
			String tel = request.getParameter("tel") == null ? "" : request	.getParameter("tel");
			String password=AesEncrypt.decryptAES(URLDecoder.decode(request.getParameter("password"), Constants.CONTENT_TYPE_UTF8),ConstantsEnv.APP_AES_KEY);
			if(StringUtils.isNotEmpty(tel)&& StringUtils.isNotEmpty(password)){
				Users user=userService.findbytelm(tel);
				B2cShopperbiTemp shoppertemp=merchantregservice.findbytel(tel);

				//判断是否为裂变商户
				if (null == shoppertemp){
					B2cShopperVal b2cShopperVal = new B2cShopperVal();
					b2cShopperVal.setTel(tel);
					List<B2cShopperVal> b2cShopperVals = b2cShopperValService.queryByParam(b2cShopperVal);
					if (null != b2cShopperVals && b2cShopperVals.size() > 0){
						b2cShopperVal = b2cShopperVals.get(0);
						if (StringUtils.isNotEmpty(b2cShopperVal.getInviteCodeP()) || StringUtils.isNotEmpty(b2cShopperVal.getPassword())){
							b2cShopperVal.setPassword(password);
							b2cShopperValService.editByParam(b2cShopperVal);

							hashMap.put("returnCode", MessageEnum.成功.getCode());
							response.setContentType(Constants.CONTENT_TYPE_UTF8);
							JSONObject json = JSONObject.fromObject(hashMap);
							log.info("修改成功:" + json.toString());
							response.getWriter().write(json.toString());
							return;
						}
					}
				}

				userService.updatepassword(user,shoppertemp,password);

				hashMap.put("returnCode", MessageEnum.成功.getCode());
				response.setContentType(Constants.CONTENT_TYPE_UTF8);
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("修改成功:" + json.toString());
				response.getWriter().write(json.toString());
			}else{
				hashMap.put("returnCode", "2222");
				response.setContentType(Constants.CONTENT_TYPE_UTF8);
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("修改失败:" + json.toString());
				response.getWriter().write(json.toString());
			}
		}catch (Exception e) {
			e.printStackTrace();
			hashMap.put("returnCode", "2222");
			response.setContentType(Constants.CONTENT_TYPE_UTF8);
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("修改失败:" + json.toString());
			response.getWriter().write(json.toString());
		}
	}

	public void updatepassword210(HttpServletRequest request, HttpServletResponse response) throws IOException {
		Map hashMap = new HashMap();
		try {
			String tel = request.getParameter("tel") == null ? "" : request	.getParameter("tel");
			String password=URLDecoder.decode(request.getParameter("password"),Constants.CONTENT_TYPE_UTF8);
			if(StringUtils.isNotEmpty(tel)&& StringUtils.isNotEmpty(password)){
				Users user=userService.findbytelm(tel);
				B2cShopperbiTemp shoppertemp=merchantregservice.findbytel(tel);
				B2cShopperbi shopper=merchantregservice.findtelbytel(tel);
				userService.updatepassword(user,shoppertemp,password);

				hashMap.put("returnCode", "0000");
				response.setContentType(Constants.CONTENT_TYPE_UTF8);
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("修改成功:" + json.toString());
				response.getWriter().write(json.toString());
			}else{
				hashMap.put("returnCode", "2222");
				response.setContentType(Constants.CONTENT_TYPE_UTF8);
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("修改失败:" + json.toString());
				response.getWriter().write(json.toString());
			}


		}catch (Exception e) {
			e.printStackTrace();
			hashMap.put("returnCode", "2222");
			response.setContentType(Constants.CONTENT_TYPE_UTF8);
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("修改失败:" + json.toString());
			response.getWriter().write(json.toString());
		}
	}
	
	
	/**实名认证
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(params = "method=ajaxsid")
	public void ajaxsid(HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		Map hashMap = new HashMap();
		try {
			String identityId =request.getParameter("identityId").toUpperCase();
			String name=request.getParameter("name");
			B2cShopperbiTemp shopper = this.merchantregservice.findbysid(identityId);
			boolean flag=false;
			if(StringUtils.isNotEmpty(name)){
				flag=ValidationIdentityId(name,identityId);
			}else{
				flag=true;
			}
					
			if (shopper != null) {
				hashMap.put("returnCode", "1111");
				hashMap.put("msg", "该身份证号码注册过");
				response.setContentType(Constants.CONTENT_TYPE_UTF8);
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("该身份证号码注册过:" + json.toString());
				response.getWriter().write(json.toString());
			} else if(!identityId.equals("")){
				if(flag==true){
					hashMap.put("returnCode", "0000");
					hashMap.put("msg", "该身份证号码未注册过");
					response.setContentType(Constants.CONTENT_TYPE_UTF8);
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("该手机号码未注册过可以使用:" + json.toString());
					response.getWriter().write(json.toString());
				}else{
					hashMap.put("returnCode", "1112");
					hashMap.put("msg", "实名认证失败");
					response.setContentType(Constants.CONTENT_TYPE_UTF8);
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("实名认证失败:" + json.toString());
					response.getWriter().write(json.toString());

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("returnCode", "2222");
			hashMap.put("msg", "出错");
			response.setContentType(Constants.CONTENT_TYPE_UTF8);
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("出错:" + json.toString());
			response.getWriter().write(json.toString());
		}

	}
	
	
	/**身份证实名认证
	 * @param name
	 * @param identityId
	 * @return
	 * @throws Exception
	 */
	public boolean ValidationIdentityId(String name, String identityId) throws Exception {
		if(StringUtils.isNotEmpty(name)&&StringUtils.isNotEmpty(identityId)){
			Map<String, String> param = new HashMap<String, String>();
			String privateKey= ConstantsEnv.VI_PRIVATEKEY;
			String merchantId= ConstantsEnv.VI_MERCHANTID;
			Date dates = new Date();
			String orderId = DateUtil.getTypeDate(dates, "yyyyMMddhhmmss");
			String orderTime = DateUtil.getTypeDate(dates, "yyyyMMdd hh:mm:ss");
			
			String data =name.trim()+"|"+identityId.trim();
			
			log.info("实名认证："+data.length()+"	data:"+data.getBytes(Constants.CONTENT_TYPE_UTF8)+"	privateKey："+privateKey);
			
			byte[] bt=data.getBytes();
			
			//私钥加密
			byte[] encodedData = RSAUtils.encryptByPrivateKey(data.getBytes(Constants.CONTENT_TYPE_UTF8), privateKey);
			
			log.info("encodedData:"+encodedData);
			String dat = Base64Utils.encode(encodedData);
			String signs =orderId+"&"+merchantId+"&"+orderTime;
			String signss = signs + "&" + dat;
			//私钥数字签名
			String sign = RSAUtils.sign(signss.getBytes(), privateKey);
			//保存到一个map里面
			param.put("orderId",orderId);
			param.put("merchantId",merchantId);
			param.put("orderTime",orderTime);
			param.put("data", dat);
			param.put("sign",sign); 
			
			JSONObject obs = JSONObject.fromObject(param);
	        log.info("实名认证请求："+ ConstantsEnv.VALIDATION_IDENTITYID_URL+param.toString());
	        String resultMap = HttpClientUtils.REpostRequestStrJson(ConstantsEnv.VALIDATION_IDENTITYID_URL, obs.toString());
			
			byte[] decodedData = RSAUtils.decryptByPrivateKey(Base64Utils.decode(resultMap), privateKey);
			//解密出来的字符串，以|隔开的
			String target = new String(decodedData);
			log.info("实名认证返回码解密:"+target);
			String resultCode=target.substring(target.indexOf("result")+7,target.lastIndexOf("message")-1);
			log.info("实名认证返回码:"+resultCode);
			if(Constants.SUCCESS_CODE.equals(resultCode)){
				return true;
			}else{
				return false;
			}
			
		}else{
			log.info("姓名或身份证为空："+"name:"+name+" identityId:"+identityId);
			return false;
		}
		
	}
	
	/**
	 * 开放注册商户登录
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	public void merchantlogin210(HttpServletRequest request, HttpServletResponse response) throws IOException{
		String type = request.getParameter("type") == null ? "" : request.getParameter("type").trim();
		if(Constants.TYPE_A.equals(type)){
			merchantlogin210A(request, response);
		}else if(Constants.TYPE_I.equals(type)){
			merchantlogin210I(request, response);
		}
	}
	/**
	 * 开放注册商户登录220
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	public void merchantlogin220(HttpServletRequest request, HttpServletResponse response) throws IOException{
		String type = request.getParameter("type") == null ? "" : request.getParameter("type").trim();
		if(Constants.TYPE_A.equals(type)){
			merchantlogin220A(request, response);
		}else if(Constants.TYPE_I.equals(type)){
			merchantlogin220I(request, response);
		}
	}

	/**
	 * 开放注册商户登录230
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	public void merchantlogin230(HttpServletRequest request, HttpServletResponse response) throws IOException{
		String type = request.getParameter("type") == null ? "" : request.getParameter("type").trim();
		if(Constants.TYPE_A.equals(type)){
			merchantlogin230A(request, response);
		}else if(Constants.TYPE_I.equals(type)){
			merchantlogin230I(request, response);
		}
	}


	/**
	 * 开放注册OCR版本登陆2.3.0
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	private void merchantlogin230I(HttpServletRequest request, HttpServletResponse response) throws IOException{
		Map hashMap = new HashMap();
		response.setContentType(Constants.CONTENT_TYPE_UTF8);
		JSONObject json = null;
		try {
			String tel = request.getParameter("tel") == null ? "" : request	.getParameter("tel");
			String password = request.getParameter("password") == null ? "" : AesEncrypt.decryptAES(request.getParameter("password"),ConstantsEnv.APP_AES_KEY);
			String type=request.getParameter("type") == null ? ""	: request.getParameter("type");//IOS或者安卓用户登陆

			String up = Md5Encrypt.md5(password);
			Users user = userService.findbytelm(tel);
			B2cShopperbiTemp shopper = merchantregservice.findbytel(tel);
			B2cShopperbi keyshopper = merchantregservice.findtelbytel(tel);
			FixAmaount fix=merchantregservice.searchFixAmaount();
			
			//判断用户和正式商户是否存在
			if(user == null && keyshopper == null){
				
				//如果都不存在，走验证码登陆
				B2cShopperVal b2cShopperVal = new B2cShopperVal();
				b2cShopperVal.setTel(tel);
				b2cShopperVal.setPassword(password);
				List<B2cShopperVal> b2cShopperVals = b2cShopperValService.queryByParam(b2cShopperVal);
				if (null != b2cShopperVals && b2cShopperVals.size() > 0){
					b2cShopperVal = b2cShopperVals.get(0);
					hashMap.put("rspCode", MessageEnum.成功.getCode());
					hashMap.put("rspMsg", MessageEnum.成功.getText());
					hashMap.put("inviteFirstLogin", Constants.STATUS1); //裂变商户首次登陆 1:首次登陆 0:非首次登陆
					hashMap.put("inviteCodeP", b2cShopperVal.getInviteCodeP()); //上级商户邀请码
					json = JSONObject.fromObject(hashMap);
					log.info("裂变商户首次登陆I：" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				
				//找不到对应验证码表信息，登陆失败
				hashMap.put("rspCode", Constants.APP_LOGIN_FAILED);
				hashMap.put("rspMsg", "手机号或密码错误！");
				json = JSONObject.fromObject(hashMap);
				log.info("不存在的手机号:" + json.toString());
				response.getWriter().write(json.toString());
				return;
			}else {//如果存在已经注册用户，则登陆
				if(shopper.getSifpactid() != null && shopper.getSifpactid() ==1){
					hashMap.put("rspCode", MessageEnum.商户已冻结.getCode());
					hashMap.put("rspMsg",MessageEnum.商户已冻结.getText());
					json = JSONObject.fromObject(hashMap);
					log.info("该商户被冻结:" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				if(shopper.getSifpactid() != null && shopper.getSifpactid() ==2){
					hashMap.put("rspCode", MessageEnum.商户已注销.getCode());
					hashMap.put("rspMsg",MessageEnum.商户已注销.getText());
					json = JSONObject.fromObject(hashMap);
					log.info("该商户被注销:" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				shopper.setAiflag(type);
				//最大，最小 金额
				hashMap.put("T0minamount", shopper.getT0minamount());
				hashMap.put("T0maxamount", shopper.getT0maxamount());

				if (user.getPassword().equals(up)) {//如果密码匹配
					hashMap.put("inviteCodeP", keyshopper.getInviteCodeP()); //上级商户邀请码
					hashMap.put("inviteCode", keyshopper.getInviteCode()); //商户邀请码
					hashMap.put("idNo", ToolsUtils.getSubStr(keyshopper.getIDNo()));
					//完整身份证号
					hashMap.put("idNoClear", AesEncrypt.encryptAES(keyshopper.getIDNo(), ConstantsEnv.APP_AES_KEY));
					hashMap.put("name",keyshopper.getName());
					
					//获取个人端uuid
					TAppGrantAuthorization tAppGrantAuthorization=appAuthorizationService.findTAppGrantAuthorization(shopper.getShopperid().toString(),tel);
					hashMap.put("uuid", tAppGrantAuthorization==null?null:tAppGrantAuthorization.getUuid());

					if(keyshopper.getShopperidP() == null || "".equals(keyshopper.getShopperidP())){
						hashMap.put("ifHavaAgent", Constants.TYPE_0);
					}else{
						hashMap.put("ifHavaAgent", Constants.TYPE_1);
					}
                    hashMap.put("qrpayMerchantkey", keyshopper.getQrpayMerchantkey());//扫码支付密钥
                    hashMap.put("fixamount", fix.getFixamaount());//固定金额
                    hashMap.put("fixedQrCodeUrl", keyshopper.getFixedqrcodeurl());
                    hashMap.put("fixedQrCodeFlag", keyshopper.getFixedqrcodeflag()==null? Constants.CON_NO:keyshopper.getFixedqrcodeflag());
					
					//审核通过（自动或者人工）
					if(Constants.TYPE_5.equals(shopper.getCheckstatus()) || Constants.TYPE_2.equals(shopper.getCheckstatus())){
						B2cDict bankname=merchantregservice.findBankName(keyshopper.getAccountbankdictval().toString());
						
						hashMap.put("scompany", keyshopper.getScompany());//商户名称
						hashMap.put("merchantKey", keyshopper.getMerchantKey());//key值
						hashMap.put("shoppertype", keyshopper.getMerchantType());//商户类型
						hashMap.put("bankno", AesEncrypt.encryptAES(keyshopper.getAccountbankno(),ConstantsEnv.APP_AES_KEY));//结算卡银行卡号
						hashMap.put("shopperid",keyshopper.getShopperid());//小商户号
						hashMap.put("name",keyshopper.getName());//姓名
						hashMap.put("bankname", bankname.getDict());//银行名称
						hashMap.put("cardprovince", keyshopper.getAccountbankprov());//结算卡省份
						hashMap.put("cardcity", keyshopper.getAccountBankCity());//结算卡城市
						hashMap.put("branchBankName", keyshopper.getAccountbankname());//支行名称
						hashMap.put("openT+0",keyshopper.getIsSupportT0() == null ? "" : keyshopper.getIsSupportT0());//是否支持T+0

						//最大，最小 金额
						hashMap.put("T0minamount", keyshopper.getT0minamount());//T0提现单笔最小金额
						hashMap.put("T0maxamount", keyshopper.getT0maxamount());//T0提现单笔最大金额

						hashMap.put("firstLogin","false");
						hashMap.put("rspCode", Constants.SUCCESS_CODE);
						hashMap.put("rspMsg", "审核已通过");
						hashMap.put("flag", Constants.TYPE_0);

						json = JSONObject.fromObject(hashMap);
						log.info("登录成功:" + json.toString());
					}else{
						hashMap.put("shopperid",shopper.getShopperid());
						hashMap.put("merchantKey", shopper.getMerchantKey());
						hashMap.put("scompany", shopper.getScompany());
						
						hashMap.put("firstLogin","false");
						hashMap.put("rspCode", Constants.SUCCESS_CODE);
						//获取商户OCR审核状态
						String shopperChekcstatus = StringUtils.trim(shopper.getCheckstatus());
						switch(shopperChekcstatus){
							case Constants.STATUS3:{
								hashMap.put("rspMsg", "信息已注册，审核不通过："+shopper.getNotPassReason());
								hashMap.put("flag", Constants.TYPE_2);
								json = JSONObject.fromObject(hashMap);
								log.info("审核不通过:" + json.toString());
								break;
							}
							case Constants.STATUS0:{
								hashMap.put("rspMsg", "信息已经注册过,未审核");
								hashMap.put("flag", Constants.TYPE_3);
								json = JSONObject.fromObject(hashMap);
								log.info("信息已经注册过,未审核:" + json.toString());
								break;
							}
							case Constants.STATUS1:{
								hashMap.put("rspMsg", "信息已经注册过,自动审核中");
								hashMap.put("flag", Constants.TYPE_3);
								json = JSONObject.fromObject(hashMap);
								log.info("自动审核中:" + json.toString());
								break;
							}
							case Constants.STATUS4:{
								hashMap.put("rspMsg", "信息已注册，人工审核中");
								hashMap.put("flag", Constants.TYPE_3);
								json = JSONObject.fromObject(hashMap);
								log.info("人工审核中:" + json.toString());
								break;
							}
						}
					}
					merchantregservice.updateB2cShopperbiTemp(shopper);
				} else {
					hashMap.put("rspCode", Constants.APP_LOGIN_FAILED);
					hashMap.put("rspMsg", "手机号或密码错误！");
					json = JSONObject.fromObject(hashMap);
					log.info("密码错误:" + json.toString());
				}
				response.getWriter().write(json.toString());
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "登录异常");
			json = JSONObject.fromObject(hashMap);
			log.info("登录异常:" + json.toString());
			response.getWriter().write(json.toString());
			return;
		}
	}

	/**
	 * 开放注册2.1.0
	 * @param request
	 * @param response
	 * @throws IOException 
	 */
	private void merchantlogin210I(HttpServletRequest request, HttpServletResponse response) throws IOException{
		Map hashMap = new HashMap();
		try {
			Map shopperMap = new HashMap();
			String tel = request.getParameter("tel") == null ? "" : request	.getParameter("tel");
			String password = request.getParameter("password") == null ? ""	: request.getParameter("password");
			String type=request.getParameter("type") == null ? ""	: request.getParameter("type");
			String version  = request.getParameter("version") == null ? "" : request.getParameter("version");
			MposRemoteInvitation remote = remotesrevice.findbytelstauts(tel);
			MposRemoteFee remotefee = remotefeeservice.findbytel(tel);

			String up = Md5Encrypt.md5(password);
			Users user = userService.findbytelm(tel);
			B2cShopperbiTemp shopper = this.merchantregservice.findbytel(tel);
			FixAmaount fix=this.merchantregservice.searchFixAmaount();
			//是否支持扫码支付
			String qrpayflag=merchantregservice.findB2cDictQrPAY();
			hashMap.put("QRPayflag", qrpayflag);
			//收款方式判断
			List<Map<String, Object>> gatheringMethod = merchantregservice.findGatheringMethod();
			hashMap.put("gatheringMethod", gatheringMethod);

			//扫码支付方式判断
			hashMap.put(Constants.WX_FLAG, acmsMapUtils.getAcmsMap().get(Constants.WX_FLAG));
			hashMap.put(Constants.ZFB_FLAG, acmsMapUtils.getAcmsMap().get(Constants.ZFB_FLAG));
			hashMap.put(Constants.YL_FLAG, acmsMapUtils.getAcmsMap().get(Constants.YL_FLAG));

			if(user == null && shopper == null){
				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "手机号或密码错误！");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("不存在的手机号:" + json.toString());
				response.getWriter().write(json.toString());
				return;
			}else {
				shopper.setAiflag(type);

				B2cShopperbi keyshopper=this.merchantregservice.selectFormalShopperId(shopper.getShopperid().toString());
				if (user.getPassword().equals(up)) {
					//判断是否有新消息
					String informationCount=appInformationService.findinformationCount(shopper.getShopperid());
					hashMap.put("informationCount", informationCount);

					//审核通过
					if(("1").equals(shopper.getRecheckmerchantflag())){
						B2cDict bankname=this.merchantregservice.findBankName(keyshopper.getAccountbankdictval().toString());
						hashMap.put("fixamount", fix.getFixamaount());
						hashMap.put("scompany", keyshopper.getScompany());
						hashMap.put("merchantKey", keyshopper.getMerchantKey());//key值
						hashMap.put("shoppertype", keyshopper.getMerchantType());//商户类型
						hashMap.put("idNo", ToolsUtils.getSubStr(keyshopper.getIDNo()));
						hashMap.put("bankno", keyshopper.getAccountbankno());
						hashMap.put("shopperid",keyshopper.getShopperid());
						hashMap.put("name",keyshopper.getName());
						hashMap.put("bankname", bankname.getDict());
						hashMap.put("cardprovince", keyshopper.getAccountbankprov());
						hashMap.put("cardcity", keyshopper.getAccountBankCity());
						hashMap.put("branchBankName", keyshopper.getAccountbankname());

						hashMap.put("openT+0",keyshopper.getIsSupportT0() == null ? "" : keyshopper.getIsSupportT0());
						hashMap.put("qrpayMerchantkey", keyshopper.getQrpayMerchantkey());

						hashMap.put("fixedQrCodeUrl", keyshopper.getFixedqrcodeurl());
						hashMap.put("fixedQrCodeFlag", keyshopper.getFixedqrcodeflag()==null? Constants.CON_NO:keyshopper.getFixedqrcodeflag());

						hashMap.put("firstLogin","false");
						hashMap.put("rspCode", "0000");
						hashMap.put("rspMsg", "审核已通过");
						hashMap.put("flag", "0");

						if(keyshopper.getShopperidP() == null || "".equals(keyshopper.getShopperidP())){
							hashMap.put("ifHavaAgent", "0");
						}else{
							hashMap.put("ifHavaAgent", "1");
						}

						response.setContentType(Constants.CONTENT_TYPE_UTF8);
						JSONObject json = JSONObject.fromObject(hashMap);
						log.info("登录成功:" + json.toString());
						response.getWriter().write(json.toString());
						this.merchantregservice.updateB2cShopperbiTemp(shopper);
						return;
					}else{
						if(Constants.STATUS2.equals(shopper.getIfvalid()==null?"":shopper.getIfvalid().toString().trim())){
							hashMap.put("shopperid",shopper.getShopperid());
							hashMap.put("merchantKey", shopper.getMerchantKey());
							hashMap.put("scompany", shopper.getScompany());
							hashMap.put("fixamount", fix.getFixamaount());
							hashMap.put("qrpayMerchantkey", keyshopper.getQrpayMerchantkey());
							hashMap.put("fixedQrCodeUrl", keyshopper.getFixedqrcodeurl());
							hashMap.put("fixedQrCodeFlag", keyshopper.getFixedqrcodeflag()==null? Constants.CON_NO:keyshopper.getFixedqrcodeflag());


							hashMap.put("firstLogin","false");
							hashMap.put("rspCode", "0000");
							hashMap.put("rspMsg", "信息已注册，初审不通过："+shopper.getExamineresullt());
							hashMap.put("flag", "2");

							if(keyshopper.getShopperidP() == null || "".equals(keyshopper.getShopperidP())){
								hashMap.put("ifHavaAgent", "0");
							}else{
								hashMap.put("ifHavaAgent", "1");
							}

							response.setContentType(Constants.CONTENT_TYPE_UTF8);
							JSONObject json = JSONObject.fromObject(hashMap);
							log.info("初审不通过:" + json.toString());
							response.getWriter().write(json.toString());
							this.merchantregservice.updateB2cShopperbiTemp(shopper);
							return ;
						}else if(Constants.STATUS0.equals(shopper.getIfvalid()==null?"":shopper.getIfvalid().toString().trim())){
							hashMap.put("scompany", shopper.getScompany());
							hashMap.put("shopperid",shopper.getShopperid());
							hashMap.put("merchantKey", shopper.getMerchantKey());
							hashMap.put("fixamount", fix.getFixamaount());
							hashMap.put("qrpayMerchantkey", keyshopper.getQrpayMerchantkey());
							hashMap.put("fixedQrCodeUrl", keyshopper.getFixedqrcodeurl());
							hashMap.put("fixedQrCodeFlag", keyshopper.getFixedqrcodeflag()==null? Constants.CON_NO:keyshopper.getFixedqrcodeflag());


							hashMap.put("firstLogin","false");
							hashMap.put("rspCode", "0000");
							hashMap.put("rspMsg", "信息已经注册过,未审核");
							hashMap.put("flag", "3");

							if(keyshopper.getShopperidP() == null || "".equals(keyshopper.getShopperidP())){
								hashMap.put("ifHavaAgent", "0");
							}else{
								hashMap.put("ifHavaAgent", "1");
							}

							response.setContentType(Constants.CONTENT_TYPE_UTF8);
							JSONObject json = JSONObject.fromObject(hashMap);
							log.info("信息已经注册过,未审核:" + json.toString());
							response.getWriter().write(json.toString());
							this.merchantregservice.updateB2cShopperbiTemp(shopper);
							return;
						}else  if(Constants.STATUS1.equals(shopper.getIfvalid()==null?"":shopper.getIfvalid().toString().trim())&&
								Constants.STATUS0.equals(shopper.getRecheckmerchantflag()==null?"":shopper.getRecheckmerchantflag().toString().trim())){
							hashMap.put("scompany", shopper.getScompany());
							hashMap.put("shopperid",shopper.getShopperid());
							hashMap.put("merchantKey", shopper.getMerchantKey());
							hashMap.put("fixamount", fix.getFixamaount());
							hashMap.put("qrpayMerchantkey", keyshopper.getQrpayMerchantkey());
							hashMap.put("fixedQrCodeUrl", keyshopper.getFixedqrcodeurl());
							hashMap.put("fixedQrCodeFlag", keyshopper.getFixedqrcodeflag()==null? Constants.CON_NO:keyshopper.getFixedqrcodeflag());


							hashMap.put("firstLogin","false");
							hashMap.put("rspCode", "0000");
							hashMap.put("rspMsg", "信息已经注册过,未审核");
							hashMap.put("flag", "3");

							if(keyshopper.getShopperidP() == null || "".equals(keyshopper.getShopperidP())){
								hashMap.put("ifHavaAgent", "0");
							}else{
								hashMap.put("ifHavaAgent", "1");
							}

							response.setContentType(Constants.CONTENT_TYPE_UTF8);
							JSONObject json = JSONObject.fromObject(hashMap);
							log.info("信息已经注册过,未审核:" + json.toString());
							response.getWriter().write(json.toString());
							this.merchantregservice.updateB2cShopperbiTemp(shopper);
							return;
					   }else if(Constants.STATUS1.equals(shopper.getIfvalid()==null?"":shopper.getIfvalid().toString().trim())&&
								Constants.STATUS2.equals(shopper.getRecheckmerchantflag()==null?"":shopper.getRecheckmerchantflag().toString().trim())){
							hashMap.put("shopperid",shopper.getShopperid());
							hashMap.put("merchantKey", shopper.getMerchantKey());
							hashMap.put("scompany", shopper.getScompany());
							hashMap.put("fixamount", fix.getFixamaount());
							hashMap.put("qrpayMerchantkey", keyshopper.getQrpayMerchantkey());
							hashMap.put("fixedQrCodeUrl", keyshopper.getFixedqrcodeurl());
							hashMap.put("fixedQrCodeFlag", keyshopper.getFixedqrcodeflag()==null? Constants.CON_NO:keyshopper.getFixedqrcodeflag());


							hashMap.put("firstLogin","false");
							hashMap.put("rspCode", "0000");
							hashMap.put("rspMsg", "信息已注册，复审不通过："+shopper.getRecheckmerchantremark());
							hashMap.put("flag", "2");

							if(keyshopper.getShopperidP() == null || "".equals(keyshopper.getShopperidP())){
								hashMap.put("ifHavaAgent", "0");
							}else{
								hashMap.put("ifHavaAgent", "1");
							}

							response.setContentType(Constants.CONTENT_TYPE_UTF8);
							JSONObject json = JSONObject.fromObject(hashMap);
							log.info("复审不通过:" + json.toString());
							response.getWriter().write(json.toString());
							this.merchantregservice.updateB2cShopperbiTemp(shopper);
							return ;
					   }
					}

				} else {
					hashMap.put("rspCode", "1111");
					hashMap.put("rspMsg", "手机号或密码错误！");
					response.setContentType(Constants.CONTENT_TYPE_UTF8);
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("密码错误:" + json.toString());
					response.getWriter().write(json.toString());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "登录异常");
			response.setContentType(Constants.CONTENT_TYPE_UTF8);
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("登录异常:" + json.toString());
			response.getWriter().write(json.toString());
		}
	}

	/**
	 * 开放注册2.2.0
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	private void merchantlogin220I(HttpServletRequest request, HttpServletResponse response) throws IOException{
		Map hashMap = new HashMap();
		try {
			Map shopperMap = new HashMap();
			String tel = request.getParameter("tel") == null ? "" : request	.getParameter("tel");
			String password = request.getParameter("password") == null ? ""	:
					AesEncrypt.decryptAES(request.getParameter("password"),ConstantsEnv.APP_AES_KEY);
			String type=request.getParameter("type") == null ? ""	: request.getParameter("type");
			String version  = request.getParameter("version") == null ? "" : request.getParameter("version");
			MposRemoteInvitation remote = remotesrevice.findbytelstauts(tel);
			MposRemoteFee remotefee = remotefeeservice.findbytel(tel);

			String up = Md5Encrypt.md5(password);
			Users user = userService.findbytelm(tel);
			B2cShopperbiTemp shopper = this.merchantregservice.findbytel(tel);
			FixAmaount fix=this.merchantregservice.searchFixAmaount();
			//是否支持扫码支付
			String qrpayflag=merchantregservice.findB2cDictQrPAY();
			hashMap.put("QRPayflag", qrpayflag);
			//收款方式判断
			List<Map<String, Object>> gatheringMethod = merchantregservice.findGatheringMethod();
			hashMap.put("gatheringMethod", gatheringMethod);

			//扫码支付方式判断
			hashMap.put(Constants.WX_FLAG, acmsMapUtils.getAcmsMap().get(Constants.WX_FLAG));
			hashMap.put(Constants.ZFB_FLAG, acmsMapUtils.getAcmsMap().get(Constants.ZFB_FLAG));
			hashMap.put(Constants.YL_FLAG, acmsMapUtils.getAcmsMap().get(Constants.YL_FLAG));

			//多接触方式
			List<Map<String, Object>> mposPayTypeList=merchantregservice.findB2cDictMposPayType();
			hashMap.put("mposPayTypeList", mposPayTypeList);
			hashMap.put("inviteFirstLogin", Constants.STATUS0);
			if(user == null && shopper == null){

				//判断商户注册临时表是否有此信息
				//如果有此信息 并且上级商户邀请码不为空 则此商户为裂变商户
				B2cShopperVal b2cShopperVal = new B2cShopperVal();
				b2cShopperVal.setTel(tel);
				b2cShopperVal.setPassword(password);
				List<B2cShopperVal> b2cShopperVals = b2cShopperValService.queryByParam(b2cShopperVal);
				if (null != b2cShopperVals && b2cShopperVals.size() > 0){
					b2cShopperVal = b2cShopperVals.get(0);
					/*if (StringUtils.isNotEmpty(b2cShopperVal.getInviteCodeP())){*/
						hashMap.put("rspCode", MessageEnum.成功.getCode());
						hashMap.put("rspMsg", MessageEnum.成功.getText());
						hashMap.put("inviteFirstLogin", Constants.STATUS1); //裂变商户首次登陆 1:首次登陆 0:非首次登陆
						hashMap.put("inviteCodeP", b2cShopperVal.getInviteCodeP()); //上级商户邀请码
						JSONObject json = JSONObject.fromObject(hashMap);
						log.info("裂变商户首次登陆I：" + json.toString());
						response.getWriter().write(json.toString());
						return;
					/*}*/
				}

				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "手机号或密码错误！");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("不存在的手机号:" + json.toString());
				response.getWriter().write(json.toString());
				return;
			}else {
				if(shopper.getSifpactid() != null && shopper.getSifpactid() ==1){
					hashMap.put("rspCode", MessageEnum.商户已冻结.getCode());
					hashMap.put("rspMsg",MessageEnum.商户已冻结.getText());
					response.setContentType(Constants.CONTENT_TYPE_UTF8);
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("该商户被注销:" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				if(shopper.getSifpactid() != null && shopper.getSifpactid() ==2){
					hashMap.put("rspCode", MessageEnum.商户已注销.getCode());
					hashMap.put("rspMsg",MessageEnum.商户已注销.getText());
					response.setContentType(Constants.CONTENT_TYPE_UTF8);
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("该商户被注销:" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				shopper.setAiflag(type);
				//最大，最小 金额
				hashMap.put("T0minamount", shopper.getT0minamount());
				hashMap.put("T0maxamount", shopper.getT0maxamount());

				if (user.getPassword().equals(up)) {
					B2cShopperbi keyshopper=this.merchantregservice.selectFormalShopperId(shopper.getShopperid().toString());
					hashMap.put("inviteCodeP", keyshopper.getInviteCodeP()); //上级商户邀请码
					hashMap.put("inviteCode", keyshopper.getInviteCode()); //商户邀请码
					hashMap.put("idNo", ToolsUtils.getSubStr(keyshopper.getIDNo()));
					//明文身份证号
					hashMap.put("idNoClear", AesEncrypt.encryptAES(keyshopper.getIDNo(), ConstantsEnv.APP_AES_KEY));
					hashMap.put("name",keyshopper.getName());
					//判断是否有新消息
					String informationCount=appInformationService.findinformationCount(shopper.getShopperid());
					hashMap.put("informationCount", informationCount);

					TAppGrantAuthorization tAppGrantAuthorization=appAuthorizationService.findTAppGrantAuthorization(shopper.getShopperid().toString(),tel);
			        hashMap.put("uuid", tAppGrantAuthorization==null?null:tAppGrantAuthorization.getUuid());

			        //审核通过
					if(("1").equals(shopper.getRecheckmerchantflag())){
						B2cDict bankname=this.merchantregservice.findBankName(keyshopper.getAccountbankdictval().toString());
						hashMap.put("fixamount", fix.getFixamaount());
						hashMap.put("scompany", keyshopper.getScompany());
						hashMap.put("merchantKey", keyshopper.getMerchantKey());//key值
						hashMap.put("shoppertype", keyshopper.getMerchantType());//商户类型
						hashMap.put("idNo", ToolsUtils.getSubStr(keyshopper.getIDNo()));
						hashMap.put("bankno", AesEncrypt.encryptAES(keyshopper.getAccountbankno(),ConstantsEnv.APP_AES_KEY));
						hashMap.put("shopperid",keyshopper.getShopperid());
						hashMap.put("name",keyshopper.getName());
						hashMap.put("bankname", bankname.getDict());
						hashMap.put("cardprovince", keyshopper.getAccountbankprov());
						hashMap.put("cardcity", keyshopper.getAccountBankCity());
						hashMap.put("branchBankName", keyshopper.getAccountbankname());

						hashMap.put("openT+0",keyshopper.getIsSupportT0() == null ? "" : keyshopper.getIsSupportT0());
						hashMap.put("qrpayMerchantkey", keyshopper.getQrpayMerchantkey());

						hashMap.put("fixedQrCodeUrl", keyshopper.getFixedqrcodeurl());
						hashMap.put("fixedQrCodeFlag", keyshopper.getFixedqrcodeflag()==null? Constants.CON_NO:keyshopper.getFixedqrcodeflag());


						//最大，最小 金额
						hashMap.put("T0minamount", keyshopper.getT0minamount());
						hashMap.put("T0maxamount", keyshopper.getT0maxamount());
						
						hashMap.put("firstLogin","false");
						hashMap.put("rspCode", "0000");
						hashMap.put("rspMsg", "审核已通过");
						hashMap.put("flag", "0");

						if(keyshopper.getShopperidP() == null || "".equals(keyshopper.getShopperidP())){
							hashMap.put("ifHavaAgent", "0");
						}else{
							hashMap.put("ifHavaAgent", "1");
						}

						response.setContentType(Constants.CONTENT_TYPE_UTF8);
						JSONObject json = JSONObject.fromObject(hashMap);
						log.info("登录成功:" + json.toString());
						response.getWriter().write(json.toString());
						this.merchantregservice.updateB2cShopperbiTemp(shopper);
						return;
					}else{
						if(Constants.STATUS2.equals(shopper.getIfvalid()==null?"":shopper.getIfvalid().toString().trim())){
							hashMap.put("shopperid",shopper.getShopperid());
							hashMap.put("merchantKey", shopper.getMerchantKey());
							hashMap.put("scompany", shopper.getScompany());
							hashMap.put("fixamount", fix.getFixamaount());
							hashMap.put("qrpayMerchantkey", keyshopper.getQrpayMerchantkey());
							hashMap.put("fixedQrCodeUrl", keyshopper.getFixedqrcodeurl());
							hashMap.put("fixedQrCodeFlag", keyshopper.getFixedqrcodeflag()==null? Constants.CON_NO:keyshopper.getFixedqrcodeflag());


							hashMap.put("firstLogin","false");
							hashMap.put("rspCode", "0000");
							hashMap.put("rspMsg", "信息已注册，初审不通过："+shopper.getExamineresullt());
							hashMap.put("flag", "2");

							if(keyshopper.getShopperidP() == null || "".equals(keyshopper.getShopperidP())){
								hashMap.put("ifHavaAgent", "0");
							}else{
								hashMap.put("ifHavaAgent", "1");
							}

							response.setContentType(Constants.CONTENT_TYPE_UTF8);
							JSONObject json = JSONObject.fromObject(hashMap);
							log.info("初审不通过:" + json.toString());
							response.getWriter().write(json.toString());
							this.merchantregservice.updateB2cShopperbiTemp(shopper);
							return ;
						}else if(Constants.STATUS0.equals(shopper.getIfvalid()==null?"":shopper.getIfvalid().toString().trim())){
							hashMap.put("scompany", shopper.getScompany());
							hashMap.put("shopperid",shopper.getShopperid());
							hashMap.put("merchantKey", shopper.getMerchantKey());
							hashMap.put("fixamount", fix.getFixamaount());
							hashMap.put("qrpayMerchantkey", keyshopper.getQrpayMerchantkey());
							hashMap.put("fixedQrCodeUrl", keyshopper.getFixedqrcodeurl());
							hashMap.put("fixedQrCodeFlag", keyshopper.getFixedqrcodeflag()==null? Constants.CON_NO:keyshopper.getFixedqrcodeflag());


							hashMap.put("firstLogin","false");
							hashMap.put("rspCode", "0000");
							hashMap.put("rspMsg", "信息已经注册过,未审核");
							hashMap.put("flag", "3");

							if(keyshopper.getShopperidP() == null || "".equals(keyshopper.getShopperidP())){
								hashMap.put("ifHavaAgent", "0");
							}else{
								hashMap.put("ifHavaAgent", "1");
							}

							response.setContentType(Constants.CONTENT_TYPE_UTF8);
							JSONObject json = JSONObject.fromObject(hashMap);
							log.info("信息已经注册过,未审核:" + json.toString());
							response.getWriter().write(json.toString());
							this.merchantregservice.updateB2cShopperbiTemp(shopper);
							return;
						}else  if(Constants.STATUS1.equals(shopper.getIfvalid()==null?"":shopper.getIfvalid().toString().trim())&&
								Constants.STATUS0.equals(shopper.getRecheckmerchantflag()==null?"":shopper.getRecheckmerchantflag().toString().trim())){
							hashMap.put("scompany", shopper.getScompany());
							hashMap.put("shopperid",shopper.getShopperid());
							hashMap.put("merchantKey", shopper.getMerchantKey());
							hashMap.put("fixamount", fix.getFixamaount());
							hashMap.put("qrpayMerchantkey", keyshopper.getQrpayMerchantkey());
							hashMap.put("fixedQrCodeUrl", keyshopper.getFixedqrcodeurl());
							hashMap.put("fixedQrCodeFlag", keyshopper.getFixedqrcodeflag()==null? Constants.CON_NO:keyshopper.getFixedqrcodeflag());


							hashMap.put("firstLogin","false");
							hashMap.put("rspCode", "0000");
							hashMap.put("rspMsg", "信息已经注册过,未审核");
							hashMap.put("flag", "3");

							if(keyshopper.getShopperidP() == null || "".equals(keyshopper.getShopperidP())){
								hashMap.put("ifHavaAgent", "0");
							}else{
								hashMap.put("ifHavaAgent", "1");
							}

							response.setContentType(Constants.CONTENT_TYPE_UTF8);
							JSONObject json = JSONObject.fromObject(hashMap);
							log.info("信息已经注册过,未审核:" + json.toString());
							response.getWriter().write(json.toString());
							this.merchantregservice.updateB2cShopperbiTemp(shopper);
							return;
						}else if(Constants.STATUS1.equals(shopper.getIfvalid()==null?"":shopper.getIfvalid().toString().trim())&&
								Constants.STATUS2.equals(shopper.getRecheckmerchantflag()==null?"":shopper.getRecheckmerchantflag().toString().trim())){
							hashMap.put("shopperid",shopper.getShopperid());
							hashMap.put("merchantKey", shopper.getMerchantKey());
							hashMap.put("scompany", shopper.getScompany());
							hashMap.put("fixamount", fix.getFixamaount());
							hashMap.put("qrpayMerchantkey", keyshopper.getQrpayMerchantkey());
							hashMap.put("fixedQrCodeUrl", keyshopper.getFixedqrcodeurl());
							hashMap.put("fixedQrCodeFlag", keyshopper.getFixedqrcodeflag()==null? Constants.CON_NO:keyshopper.getFixedqrcodeflag());


							hashMap.put("firstLogin","false");
							hashMap.put("rspCode", "0000");
							hashMap.put("rspMsg", "信息已注册，复审不通过："+shopper.getRecheckmerchantremark());
							hashMap.put("flag", "2");

							if(keyshopper.getShopperidP() == null || "".equals(keyshopper.getShopperidP())){
								hashMap.put("ifHavaAgent", "0");
							}else{
								hashMap.put("ifHavaAgent", "1");
							}

							response.setContentType(Constants.CONTENT_TYPE_UTF8);
							JSONObject json = JSONObject.fromObject(hashMap);
							log.info("复审不通过:" + json.toString());
							response.getWriter().write(json.toString());
							this.merchantregservice.updateB2cShopperbiTemp(shopper);
							return ;
						}
					}

				} else {
					hashMap.put("rspCode", "1111");
					hashMap.put("rspMsg", "手机号或密码错误！");
					response.setContentType(Constants.CONTENT_TYPE_UTF8);
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("密码错误:" + json.toString());
					response.getWriter().write(json.toString());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "登录异常");
			response.setContentType(Constants.CONTENT_TYPE_UTF8);
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("登录异常:" + json.toString());
			response.getWriter().write(json.toString());
		}
	}

	/**
	 * 开放注册登录2.1.0
	 * @param request
	 * @param response
	 * @throws IOException 
	 */
	private void merchantlogin210A(HttpServletRequest request, HttpServletResponse response) throws IOException{
		Map hashMap = new HashMap();
		try {
			Map shopperMap = new HashMap();
			String tel = request.getParameter("tel") == null ? "" : request	.getParameter("tel");
			String password = request.getParameter("password") == null ? ""	: request.getParameter("password");
			String type=request.getParameter("type") == null ? ""	: request.getParameter("type");
			String version  = request.getParameter("version") == null ? "" : request.getParameter("version");

			String up = Md5Encrypt.md5(password);
			Users user = userService.findbytelm(tel);
			B2cShopperbiTemp shopper = this.merchantregservice.findbytel(tel);
			FixAmaount fix=this.merchantregservice.searchFixAmaount();
			//是否支持扫码支付
			String qrpayflag=merchantregservice.findB2cDictQrPAY();
			hashMap.put("QRPayflag", qrpayflag);
			//收款方式判断
			List<Map<String, Object>> gatheringMethod = merchantregservice.findGatheringMethod();
			hashMap.put("gatheringMethod", gatheringMethod);

			//扫码支付方式判断
			hashMap.put(Constants.WX_FLAG, acmsMapUtils.getAcmsMap().get(Constants.WX_FLAG));
			hashMap.put(Constants.ZFB_FLAG, acmsMapUtils.getAcmsMap().get(Constants.ZFB_FLAG));
			hashMap.put(Constants.YL_FLAG, acmsMapUtils.getAcmsMap().get(Constants.YL_FLAG));

			if(user == null && shopper == null){
				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "手机号或密码错误！");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("不存在的手机号:" + json.toString());
				response.getWriter().write(json.toString());
				return;
			}else {
				if(shopper.getSifpactid() != null && shopper.getSifpactid() ==1){
					hashMap.put("rspCode", "3333");
					hashMap.put("rspMsg","您的商户已冻结，请联系所属服务商或客服！");
					response.setContentType(Constants.CONTENT_TYPE_UTF8);
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("该商户被注销:" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				if(shopper.getSifpactid() != null && shopper.getSifpactid() ==2){
					hashMap.put("rspCode", "3333");
					hashMap.put("rspMsg","您的商户已注销，请联系所属服务商或客服！");
					response.setContentType(Constants.CONTENT_TYPE_UTF8);
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("该商户被注销:" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				shopper.setAiflag(type);

				B2cShopperbi keyshopper=this.merchantregservice.selectFormalShopperId(shopper.getShopperid().toString());
				if (user.getPassword().equals(up)) {
					//判断是否有新消息
					String informationCount=appInformationService.findinformationCount(shopper.getShopperid());
					hashMap.put("informationCount", informationCount);
					hashMap.put("idNo", ToolsUtils.getSubStr(keyshopper.getIDNo()));
					hashMap.put("name",keyshopper.getName());
					//审核通过
					if(("1").equals(shopper.getRecheckmerchantflag())){
						B2cDict bankname=this.merchantregservice.findBankName(keyshopper.getAccountbankdictval().toString());
						hashMap.put("fixamount", fix.getFixamaount());
						hashMap.put("scompany", keyshopper.getScompany());
						hashMap.put("merchantKey", keyshopper.getMerchantKey());//key值
						hashMap.put("shoppertype", keyshopper.getMerchantType());//商户类型
						hashMap.put("bankno", keyshopper.getAccountbankno());
						hashMap.put("shopperid",keyshopper.getShopperid());
						hashMap.put("bankname", bankname.getDict());
						hashMap.put("cardprovince", keyshopper.getAccountbankprov());
						hashMap.put("cardcity", keyshopper.getAccountBankCity());
						hashMap.put("branchBankName", keyshopper.getAccountbankname());
						hashMap.put("openT+0",keyshopper.getIsSupportT0() == null ? "" : keyshopper.getIsSupportT0());
						hashMap.put("qrpayMerchantkey", keyshopper.getQrpayMerchantkey());
						hashMap.put("fixedQrCodeUrl", keyshopper.getFixedqrcodeurl());
						hashMap.put("fixedQrCodeFlag", keyshopper.getFixedqrcodeflag()==null? Constants.CON_NO:keyshopper.getFixedqrcodeflag());

						hashMap.put("firstLogin","false");
						hashMap.put("rspCode", "0000");
						hashMap.put("rspMsg", "审核已通过");
						hashMap.put("flag", "0");

						if(keyshopper.getShopperidP() == null || "".equals(keyshopper.getShopperidP())){
							hashMap.put("ifHavaAgent", "0");
						}else{
							hashMap.put("ifHavaAgent", "1");
						}

						response.setContentType(Constants.CONTENT_TYPE_UTF8);
						JSONObject json = JSONObject.fromObject(hashMap);
						log.info("登录成功:" + json.toString());
						response.getWriter().write(json.toString());
						this.merchantregservice.updateB2cShopperbiTemp(shopper);
						return;
					}else{
						if(Constants.STATUS2.equals(shopper.getIfvalid()==null?"":shopper.getIfvalid().toString().trim())){
							hashMap.put("shopperid",shopper.getShopperid());
							hashMap.put("merchantKey", shopper.getMerchantKey());
							hashMap.put("scompany", shopper.getScompany());
							hashMap.put("fixamount", fix.getFixamaount());
							hashMap.put("qrpayMerchantkey", keyshopper.getQrpayMerchantkey());
							hashMap.put("fixedQrCodeUrl", keyshopper.getFixedqrcodeurl());
							hashMap.put("fixedQrCodeFlag", keyshopper.getFixedqrcodeflag()==null? Constants.CON_NO:keyshopper.getFixedqrcodeflag());


							hashMap.put("firstLogin","false");
							hashMap.put("rspCode", "0000");
							hashMap.put("rspMsg", "信息已注册，初审不通过："+shopper.getExamineresullt());
							hashMap.put("flag", "2");

							if(keyshopper.getShopperidP() == null || "".equals(keyshopper.getShopperidP())){
								hashMap.put("ifHavaAgent", "0");
							}else{
								hashMap.put("ifHavaAgent", "1");
							}

							response.setContentType(Constants.CONTENT_TYPE_UTF8);
							JSONObject json = JSONObject.fromObject(hashMap);
							log.info("初审不通过:" + json.toString());
							response.getWriter().write(json.toString());
							this.merchantregservice.updateB2cShopperbiTemp(shopper);
							return ;
						}else if(Constants.STATUS0.equals(shopper.getIfvalid()==null?"":shopper.getIfvalid().toString().trim())){
							hashMap.put("scompany", shopper.getScompany());
							hashMap.put("shopperid",shopper.getShopperid());
							hashMap.put("merchantKey", shopper.getMerchantKey());
							hashMap.put("fixamount", fix.getFixamaount());
							hashMap.put("qrpayMerchantkey", keyshopper.getQrpayMerchantkey());
							hashMap.put("fixedQrCodeUrl", keyshopper.getFixedqrcodeurl());
							hashMap.put("fixedQrCodeFlag", keyshopper.getFixedqrcodeflag()==null? Constants.CON_NO:keyshopper.getFixedqrcodeflag());


							hashMap.put("firstLogin","false");
							hashMap.put("rspCode", "0000");
							hashMap.put("rspMsg", "信息已经注册过,未审核");
							hashMap.put("flag", "3");

							if(keyshopper.getShopperidP() == null || "".equals(keyshopper.getShopperidP())){
								hashMap.put("ifHavaAgent", "0");
							}else{
								hashMap.put("ifHavaAgent", "1");
							}

							response.setContentType(Constants.CONTENT_TYPE_UTF8);
							JSONObject json = JSONObject.fromObject(hashMap);
							log.info("信息已经注册过,未审核:" + json.toString());
							response.getWriter().write(json.toString());
							this.merchantregservice.updateB2cShopperbiTemp(shopper);
							return;
						}else  if(Constants.STATUS1.equals(shopper.getIfvalid()==null?"":shopper.getIfvalid().toString().trim())&&
								Constants.STATUS0.equals(shopper.getRecheckmerchantflag()==null?"":shopper.getRecheckmerchantflag().toString().trim())){
							hashMap.put("scompany", shopper.getScompany());
							hashMap.put("shopperid",shopper.getShopperid());
							hashMap.put("merchantKey", shopper.getMerchantKey());
							hashMap.put("fixamount", fix.getFixamaount());
							hashMap.put("qrpayMerchantkey", keyshopper.getQrpayMerchantkey());
							hashMap.put("fixedQrCodeUrl", keyshopper.getFixedqrcodeurl());
							hashMap.put("fixedQrCodeFlag", keyshopper.getFixedqrcodeflag()==null? Constants.CON_NO:keyshopper.getFixedqrcodeflag());


							hashMap.put("firstLogin","false");
							hashMap.put("rspCode", "0000");
							hashMap.put("rspMsg", "信息已经注册过,未审核");
							hashMap.put("flag", "3");

							if(keyshopper.getShopperidP() == null || "".equals(keyshopper.getShopperidP())){
								hashMap.put("ifHavaAgent", "0");
							}else{
								hashMap.put("ifHavaAgent", "1");
							}

							response.setContentType(Constants.CONTENT_TYPE_UTF8);
							JSONObject json = JSONObject.fromObject(hashMap);
							log.info("信息已经注册过,未审核:" + json.toString());
							response.getWriter().write(json.toString());
							this.merchantregservice.updateB2cShopperbiTemp(shopper);
							return;
					   }else if(Constants.STATUS1.equals(shopper.getIfvalid()==null?"":shopper.getIfvalid().toString().trim())&&
								Constants.STATUS2.equals(shopper.getRecheckmerchantflag()==null?"":shopper.getRecheckmerchantflag().toString().trim())){
							hashMap.put("shopperid",shopper.getShopperid());
							hashMap.put("merchantKey", shopper.getMerchantKey());
							hashMap.put("scompany", shopper.getScompany());
							hashMap.put("fixamount", fix.getFixamaount());
							hashMap.put("qrpayMerchantkey", keyshopper.getQrpayMerchantkey());
							hashMap.put("fixedQrCodeUrl", keyshopper.getFixedqrcodeurl());
							hashMap.put("fixedQrCodeFlag", keyshopper.getFixedqrcodeflag()==null? Constants.CON_NO:keyshopper.getFixedqrcodeflag());


							hashMap.put("firstLogin","false");
							hashMap.put("rspCode", "0000");
							hashMap.put("rspMsg", "信息已注册，复审不通过："+shopper.getRecheckmerchantremark());
							hashMap.put("flag", "2");

							if(keyshopper.getShopperidP() == null || "".equals(keyshopper.getShopperidP())){
								hashMap.put("ifHavaAgent", "0");
							}else{
								hashMap.put("ifHavaAgent", "1");
							}

							response.setContentType(Constants.CONTENT_TYPE_UTF8);
							JSONObject json = JSONObject.fromObject(hashMap);
							log.info("复审不通过:" + json.toString());
							response.getWriter().write(json.toString());
							this.merchantregservice.updateB2cShopperbiTemp(shopper);
							return ;
					   }
					}

				} else {
					hashMap.put("rspCode", "1111");
					hashMap.put("rspMsg", "手机号或密码错误！");
					response.setContentType(Constants.CONTENT_TYPE_UTF8);
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("密码错误:" + json.toString());
					response.getWriter().write(json.toString());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "登录异常");
			response.setContentType(Constants.CONTENT_TYPE_UTF8);
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("登录异常:" + json.toString());
			response.getWriter().write(json.toString());
		}
	}

	/**
	 * 开放注册登录2.2.0
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	private void merchantlogin220A(HttpServletRequest request, HttpServletResponse response) throws IOException{
		Map hashMap = new HashMap();
		try {
			Map shopperMap = new HashMap();
			String tel = request.getParameter("tel") == null ? "" : request	.getParameter("tel");
			String password = request.getParameter("password") == null ? ""	:
					AesEncrypt.decryptAES(request.getParameter("password"),ConstantsEnv.APP_AES_KEY);
			String type=request.getParameter("type") == null ? ""	: request.getParameter("type");
			String version  = request.getParameter("version") == null ? "" : request.getParameter("version");

			String up = Md5Encrypt.md5(password);
			Users user = userService.findbytelm(tel);
			B2cShopperbiTemp shopper = this.merchantregservice.findbytel(tel);
			FixAmaount fix=this.merchantregservice.searchFixAmaount();
			//是否支持扫码支付
			String qrpayflag=merchantregservice.findB2cDictQrPAY();
			hashMap.put("QRPayflag", qrpayflag);
			//收款方式判断
			List<Map<String, Object>> gatheringMethod = merchantregservice.findGatheringMethod();
			hashMap.put("gatheringMethod", gatheringMethod);

			//扫码支付方式判断
			hashMap.put(Constants.WX_FLAG, acmsMapUtils.getAcmsMap().get(Constants.WX_FLAG));
			hashMap.put(Constants.ZFB_FLAG, acmsMapUtils.getAcmsMap().get(Constants.ZFB_FLAG));
			hashMap.put(Constants.YL_FLAG, acmsMapUtils.getAcmsMap().get(Constants.YL_FLAG));
			
			//多结算方式
			List<Map<String, Object>> mposPayTypeList=merchantregservice.findB2cDictMposPayType();
			hashMap.put("mposPayTypeList", mposPayTypeList);
			hashMap.put("inviteFirstLogin", Constants.STATUS0);
			if(user == null && shopper == null){
				//判断商户注册临时表是否有此信息
				//如果有此信息 并且上级商户邀请码不为空 则此商户为裂变商户
				B2cShopperVal b2cShopperVal = new B2cShopperVal();
				b2cShopperVal.setTel(tel);
				b2cShopperVal.setPassword(password);
				List<B2cShopperVal> b2cShopperVals = b2cShopperValService.queryByParam(b2cShopperVal);
				if (null != b2cShopperVals && b2cShopperVals.size() > 0){
					b2cShopperVal = b2cShopperVals.get(0);
					/*if (StringUtils.isNotEmpty(b2cShopperVal.getInviteCodeP())){*/
						hashMap.put("rspCode", MessageEnum.成功.getCode());
						hashMap.put("rspMsg", MessageEnum.成功.getText());
						hashMap.put("inviteFirstLogin", Constants.STATUS1); //裂变商户首次登陆 1:首次登陆 0:非首次登陆
						hashMap.put("inviteCodeP", b2cShopperVal.getInviteCodeP()); //上级商户邀请码
						JSONObject json = JSONObject.fromObject(hashMap);
						log.info("裂变商户首次登陆A：" + json.toString());
						response.getWriter().write(json.toString());
						return;
					/*}*/
				}

				hashMap.put("rspCode", MessageEnum.手机号或密码错误.getCode());
				hashMap.put("rspMsg", MessageEnum.手机号或密码错误.getText());
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("不存在的手机号:" + json.toString());
				response.getWriter().write(json.toString());
				return;
			}else {
				if(shopper.getSifpactid() != null && shopper.getSifpactid() ==1){
					hashMap.put("rspCode", MessageEnum.商户已冻结.getCode());
					hashMap.put("rspMsg",MessageEnum.商户已冻结.getText());
					response.setContentType(Constants.CONTENT_TYPE_UTF8);
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("该商户被注销:" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				if(shopper.getSifpactid() != null && shopper.getSifpactid() ==2){
					hashMap.put("rspCode", MessageEnum.商户已注销.getCode());
					hashMap.put("rspMsg",MessageEnum.商户已注销.getText());
					response.setContentType(Constants.CONTENT_TYPE_UTF8);
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("该商户被注销:" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				shopper.setAiflag(type);
				
				//最大，最小 金额
				hashMap.put("T0minamount", shopper.getT0minamount());
				hashMap.put("T0maxamount", shopper.getT0maxamount());

				B2cShopperbi keyshopper=this.merchantregservice.selectFormalShopperId(shopper.getShopperid().toString());
				
				TAppGrantAuthorization tAppGrantAuthorization=appAuthorizationService.findTAppGrantAuthorization(shopper.getShopperid().toString(),tel);
				hashMap.put("uuid", tAppGrantAuthorization==null?null:tAppGrantAuthorization.getUuid());

				if (user.getPassword().equals(up)) {
					//判断是否有新消息
					String informationCount=appInformationService.findinformationCount(shopper.getShopperid());
					hashMap.put("informationCount", informationCount);

					hashMap.put("inviteCodeP", keyshopper.getInviteCodeP()); //上级商户邀请码
					hashMap.put("inviteCode", keyshopper.getInviteCode()); //商户邀请码
					hashMap.put("idNo", ToolsUtils.getSubStr(keyshopper.getIDNo()));
					//明文身份证号
					hashMap.put("idNoClear", AesEncrypt.encryptAES(keyshopper.getIDNo(), ConstantsEnv.APP_AES_KEY));
					hashMap.put("name",keyshopper.getName());
					//审核通过
					if(("1").equals(shopper.getRecheckmerchantflag())){
						B2cDict bankname=this.merchantregservice.findBankName(keyshopper.getAccountbankdictval().toString());
						hashMap.put("fixamount", fix.getFixamaount());
						hashMap.put("scompany", keyshopper.getScompany());
						hashMap.put("merchantKey", keyshopper.getMerchantKey());//key值
						hashMap.put("shoppertype", keyshopper.getMerchantType());//商户类型
						hashMap.put("idNo", ToolsUtils.getSubStr(keyshopper.getIDNo()));
						hashMap.put("bankno", AesEncrypt.encryptAES(keyshopper.getAccountbankno(),ConstantsEnv.APP_AES_KEY));
						hashMap.put("shopperid",keyshopper.getShopperid());
						hashMap.put("name",keyshopper.getName());
						hashMap.put("bankname", bankname.getDict());
						hashMap.put("cardprovince", keyshopper.getAccountbankprov());
						hashMap.put("cardcity", keyshopper.getAccountBankCity());
						hashMap.put("branchBankName", keyshopper.getAccountbankname());

						hashMap.put("openT+0",keyshopper.getIsSupportT0() == null ? "" : keyshopper.getIsSupportT0());
						hashMap.put("qrpayMerchantkey", keyshopper.getQrpayMerchantkey());

						hashMap.put("fixedQrCodeUrl", keyshopper.getFixedqrcodeurl());
						hashMap.put("fixedQrCodeFlag", keyshopper.getFixedqrcodeflag()==null? Constants.CON_NO:keyshopper.getFixedqrcodeflag());

						
						
						
						hashMap.put("firstLogin","false");
						hashMap.put("rspCode", "0000");
						hashMap.put("rspMsg", "审核已通过");
						hashMap.put("flag", "0");

						if(keyshopper.getShopperidP() == null || "".equals(keyshopper.getShopperidP())){
							hashMap.put("ifHavaAgent", "0");
						}else{
							hashMap.put("ifHavaAgent", "1");
						}

						response.setContentType(Constants.CONTENT_TYPE_UTF8);
						JSONObject json = JSONObject.fromObject(hashMap);
						log.info("登录成功:" + json.toString());
						response.getWriter().write(json.toString());
						this.merchantregservice.updateB2cShopperbiTemp(shopper);
						return;
					}else{
						if(Constants.STATUS2.equals(shopper.getIfvalid()==null?"":shopper.getIfvalid().toString().trim())){
							hashMap.put("shopperid",shopper.getShopperid());
							hashMap.put("merchantKey", shopper.getMerchantKey());
							hashMap.put("scompany", shopper.getScompany());
							hashMap.put("fixamount", fix.getFixamaount());
							hashMap.put("qrpayMerchantkey", keyshopper.getQrpayMerchantkey());
							hashMap.put("fixedQrCodeUrl", keyshopper.getFixedqrcodeurl());
							hashMap.put("fixedQrCodeFlag", keyshopper.getFixedqrcodeflag()==null? Constants.CON_NO:keyshopper.getFixedqrcodeflag());


							hashMap.put("firstLogin","false");
							hashMap.put("rspCode", "0000");
							hashMap.put("rspMsg", "信息已注册，初审不通过："+shopper.getExamineresullt());
							hashMap.put("flag", "2");

							if(keyshopper.getShopperidP() == null || "".equals(keyshopper.getShopperidP())){
								hashMap.put("ifHavaAgent", "0");
							}else{
								hashMap.put("ifHavaAgent", "1");
							}

							response.setContentType(Constants.CONTENT_TYPE_UTF8);
							JSONObject json = JSONObject.fromObject(hashMap);
							log.info("初审不通过:" + json.toString());
							response.getWriter().write(json.toString());
							this.merchantregservice.updateB2cShopperbiTemp(shopper);
							return ;
						}else if(Constants.STATUS0.equals(shopper.getIfvalid()==null?"":shopper.getIfvalid().toString().trim())){
							hashMap.put("scompany", shopper.getScompany());
							hashMap.put("shopperid",shopper.getShopperid());
							hashMap.put("merchantKey", shopper.getMerchantKey());
							hashMap.put("fixamount", fix.getFixamaount());
							hashMap.put("qrpayMerchantkey", keyshopper.getQrpayMerchantkey());
							hashMap.put("fixedQrCodeUrl", keyshopper.getFixedqrcodeurl());
							hashMap.put("fixedQrCodeFlag", keyshopper.getFixedqrcodeflag()==null? Constants.CON_NO:keyshopper.getFixedqrcodeflag());


							hashMap.put("firstLogin","false");
							hashMap.put("rspCode", "0000");
							hashMap.put("rspMsg", "信息已经注册过,未审核");
							hashMap.put("flag", "3");

							if(keyshopper.getShopperidP() == null || "".equals(keyshopper.getShopperidP())){
								hashMap.put("ifHavaAgent", "0");
							}else{
								hashMap.put("ifHavaAgent", "1");
							}

							response.setContentType(Constants.CONTENT_TYPE_UTF8);
							JSONObject json = JSONObject.fromObject(hashMap);
							log.info("信息已经注册过,未审核:" + json.toString());
							response.getWriter().write(json.toString());
							this.merchantregservice.updateB2cShopperbiTemp(shopper);
							return;
						}else  if(Constants.STATUS1.equals(shopper.getIfvalid()==null?"":shopper.getIfvalid().toString().trim())&&
								Constants.STATUS0.equals(shopper.getRecheckmerchantflag()==null?"":shopper.getRecheckmerchantflag().toString().trim())){
							hashMap.put("scompany", shopper.getScompany());
							hashMap.put("shopperid",shopper.getShopperid());
							hashMap.put("merchantKey", shopper.getMerchantKey());
							hashMap.put("fixamount", fix.getFixamaount());
							hashMap.put("qrpayMerchantkey", keyshopper.getQrpayMerchantkey());
							hashMap.put("fixedQrCodeUrl", keyshopper.getFixedqrcodeurl());
							hashMap.put("fixedQrCodeFlag", keyshopper.getFixedqrcodeflag()==null? Constants.CON_NO:keyshopper.getFixedqrcodeflag());


							hashMap.put("firstLogin","false");
							hashMap.put("rspCode", "0000");
							hashMap.put("rspMsg", "信息已经注册过,未审核");
							hashMap.put("flag", "3");

							if(keyshopper.getShopperidP() == null || "".equals(keyshopper.getShopperidP())){
								hashMap.put("ifHavaAgent", "0");
							}else{
								hashMap.put("ifHavaAgent", "1");
							}

							response.setContentType(Constants.CONTENT_TYPE_UTF8);
							JSONObject json = JSONObject.fromObject(hashMap);
							log.info("信息已经注册过,未审核:" + json.toString());
							response.getWriter().write(json.toString());
							this.merchantregservice.updateB2cShopperbiTemp(shopper);
							return;
						}else if(Constants.STATUS1.equals(shopper.getIfvalid()==null?"":shopper.getIfvalid().toString().trim())&&
								Constants.STATUS2.equals(shopper.getRecheckmerchantflag()==null?"":shopper.getRecheckmerchantflag().toString().trim())){
							hashMap.put("shopperid",shopper.getShopperid());
							hashMap.put("merchantKey", shopper.getMerchantKey());
							hashMap.put("scompany", shopper.getScompany());
							hashMap.put("fixamount", fix.getFixamaount());
							hashMap.put("qrpayMerchantkey", keyshopper.getQrpayMerchantkey());
							hashMap.put("fixedQrCodeUrl", keyshopper.getFixedqrcodeurl());
							hashMap.put("fixedQrCodeFlag", keyshopper.getFixedqrcodeflag()==null? Constants.CON_NO:keyshopper.getFixedqrcodeflag());


							hashMap.put("firstLogin","false");
							hashMap.put("rspCode", "0000");
							hashMap.put("rspMsg", "信息已注册，复审不通过："+shopper.getRecheckmerchantremark());
							hashMap.put("flag", "2");

							if(keyshopper.getShopperidP() == null || "".equals(keyshopper.getShopperidP())){
								hashMap.put("ifHavaAgent", "0");
							}else{
								hashMap.put("ifHavaAgent", "1");
							}

							response.setContentType(Constants.CONTENT_TYPE_UTF8);
							JSONObject json = JSONObject.fromObject(hashMap);
							log.info("复审不通过:" + json.toString());
							response.getWriter().write(json.toString());
							this.merchantregservice.updateB2cShopperbiTemp(shopper);
							return ;
						}
					}

				} else {
					hashMap.put("rspCode", MessageEnum.手机号或密码错误.getCode());
					hashMap.put("rspMsg", MessageEnum.手机号或密码错误.getText());
					response.setContentType(Constants.CONTENT_TYPE_UTF8);
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("密码错误:" + json.toString());
					response.getWriter().write(json.toString());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "登录异常");
			response.setContentType(Constants.CONTENT_TYPE_UTF8);
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("登录异常:" + json.toString());
			response.getWriter().write(json.toString());
		}
	}

	/**
	 * 开放注册登录2.3.0
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	private void merchantlogin230A(HttpServletRequest request, HttpServletResponse response) throws IOException{
		Map hashMap = new HashMap();
		response.setContentType(Constants.CONTENT_TYPE_UTF8);
		JSONObject json = null;
		try {
			String tel = request.getParameter("tel") == null ? "" : request	.getParameter("tel");
			String password = request.getParameter("password") == null ? "" : AesEncrypt.decryptAES(request.getParameter("password"),ConstantsEnv.APP_AES_KEY);
			String type=request.getParameter("type") == null ? ""	: request.getParameter("type");//IOS或者安卓用户登陆

			String up = Md5Encrypt.md5(password);
			Users user = userService.findbytelm(tel);
			B2cShopperbiTemp shopper = merchantregservice.findbytel(tel);
			B2cShopperbi keyshopper = merchantregservice.findtelbytel(tel);
			FixAmaount fix=merchantregservice.searchFixAmaount();

			//判断用户和正式商户是否存在
			if(user == null && keyshopper == null){

				//如果都不存在，走验证码登陆
				B2cShopperVal b2cShopperVal = new B2cShopperVal();
				b2cShopperVal.setTel(tel);
				b2cShopperVal.setPassword(password);
				List<B2cShopperVal> b2cShopperVals = b2cShopperValService.queryByParam(b2cShopperVal);
				if (null != b2cShopperVals && b2cShopperVals.size() > 0){
					b2cShopperVal = b2cShopperVals.get(0);
					hashMap.put("rspCode", MessageEnum.成功.getCode());
					hashMap.put("rspMsg", MessageEnum.成功.getText());
					hashMap.put("inviteFirstLogin", Constants.STATUS1); //裂变商户首次登陆 1:首次登陆 0:非首次登陆
					hashMap.put("inviteCodeP", b2cShopperVal.getInviteCodeP()); //上级商户邀请码
					json = JSONObject.fromObject(hashMap);
					log.info("裂变商户首次登陆A：" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}

				//找不到对应验证码表信息，登陆失败
				hashMap.put("rspCode", Constants.APP_LOGIN_FAILED);
				hashMap.put("rspMsg", "手机号或密码错误！");
				json = JSONObject.fromObject(hashMap);
				log.info("不存在的手机号:" + json.toString());
				response.getWriter().write(json.toString());
				return;
			}else {//如果存在已经注册用户，则登陆
				if(shopper.getSifpactid() != null && shopper.getSifpactid() ==1){
					hashMap.put("rspCode", MessageEnum.商户已冻结.getCode());
					hashMap.put("rspMsg",MessageEnum.商户已冻结.getText());
					json = JSONObject.fromObject(hashMap);
					log.info("该商户被冻结:" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				if(shopper.getSifpactid() != null && shopper.getSifpactid() ==2){
					hashMap.put("rspCode", MessageEnum.商户已注销.getCode());
					hashMap.put("rspMsg",MessageEnum.商户已注销.getText());
					json = JSONObject.fromObject(hashMap);
					log.info("该商户被注销:" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				shopper.setAiflag(type);
				//最大，最小 金额
				hashMap.put("T0minamount", shopper.getT0minamount());
				hashMap.put("T0maxamount", shopper.getT0maxamount());

				if (user.getPassword().equals(up)) {//如果密码匹配
					hashMap.put("inviteCodeP", keyshopper.getInviteCodeP()); //上级商户邀请码
					hashMap.put("inviteCode", keyshopper.getInviteCode()); //商户邀请码
					hashMap.put("idNo", ToolsUtils.getSubStr(keyshopper.getIDNo()));
					//完整身份证号
					hashMap.put("idNoClear", AesEncrypt.encryptAES(keyshopper.getIDNo(), ConstantsEnv.APP_AES_KEY));
					hashMap.put("name",keyshopper.getName());

					//获取个人端uuid
					TAppGrantAuthorization tAppGrantAuthorization=appAuthorizationService.findTAppGrantAuthorization(shopper.getShopperid().toString(),tel);
					hashMap.put("uuid", tAppGrantAuthorization==null?null:tAppGrantAuthorization.getUuid());

					if(keyshopper.getShopperidP() == null || "".equals(keyshopper.getShopperidP())){
						hashMap.put("ifHavaAgent", Constants.TYPE_0);
					}else{
						hashMap.put("ifHavaAgent", Constants.TYPE_1);
					}

                    hashMap.put("fixedQrCodeUrl", keyshopper.getFixedqrcodeurl());
                    hashMap.put("fixedQrCodeFlag", keyshopper.getFixedqrcodeflag()==null? Constants.CON_NO:keyshopper.getFixedqrcodeflag());
                    hashMap.put("qrpayMerchantkey", keyshopper.getQrpayMerchantkey());//扫码支付密钥
                    hashMap.put("fixamount", fix.getFixamaount());

                    //审核通过（自动或者人工）
					if(Constants.TYPE_5.equals(shopper.getCheckstatus()) || Constants.TYPE_2.equals(shopper.getCheckstatus())){
						B2cDict bankname=merchantregservice.findBankName(keyshopper.getAccountbankdictval().toString());
						hashMap.put("scompany", keyshopper.getScompany());//商户名称
						hashMap.put("shoppertype", keyshopper.getMerchantType());//商户类型
						hashMap.put("bankno", AesEncrypt.encryptAES(keyshopper.getAccountbankno(),ConstantsEnv.APP_AES_KEY));//结算卡银行卡号
						hashMap.put("shopperid",keyshopper.getShopperid());//小商户号
						hashMap.put("name",keyshopper.getName());//姓名
						hashMap.put("bankname", bankname.getDict());//银行名称
						hashMap.put("cardprovince", keyshopper.getAccountbankprov());//结算卡省份
						hashMap.put("cardcity", keyshopper.getAccountBankCity());//结算卡城市
						hashMap.put("branchBankName", keyshopper.getAccountbankname());//支行名称
						hashMap.put("openT+0",keyshopper.getIsSupportT0() == null ? "" : keyshopper.getIsSupportT0());//是否支持T+0
                        hashMap.put("merchantKey", keyshopper.getMerchantKey());//key值

						//最大，最小 金额
						hashMap.put("T0minamount", keyshopper.getT0minamount());//T0提现单笔最小金额
						hashMap.put("T0maxamount", keyshopper.getT0maxamount());//T0提现单笔最大金额

						hashMap.put("firstLogin","false");
						hashMap.put("rspCode", Constants.SUCCESS_CODE);
						hashMap.put("rspMsg", "审核已通过");
						hashMap.put("flag", Constants.TYPE_0);

						json = JSONObject.fromObject(hashMap);
						log.info("登录成功:" + json.toString());
					}else{
						hashMap.put("shopperid",shopper.getShopperid());
						hashMap.put("scompany", shopper.getScompany());
                        hashMap.put("merchantKey", shopper.getMerchantKey());//key值
						
						hashMap.put("firstLogin","false");
						hashMap.put("rspCode", Constants.SUCCESS_CODE);
						//获取商户OCR审核状态
						String shopperChekcstatus = StringUtils.trim(shopper.getCheckstatus());
						switch(shopperChekcstatus){
							case Constants.STATUS3:{
								hashMap.put("rspMsg", "信息已注册，审核不通过："+shopper.getNotPassReason());
								hashMap.put("flag", Constants.TYPE_2);
								json = JSONObject.fromObject(hashMap);
								log.info("审核不通过:" + json.toString());
								break;
							}
							case Constants.STATUS0:{
								hashMap.put("rspMsg", "信息已经注册过,未审核");
								hashMap.put("flag", Constants.TYPE_3);
								json = JSONObject.fromObject(hashMap);
								log.info("信息已经注册过,未审核:" + json.toString());
								break;
							}
							case Constants.STATUS1:{
								hashMap.put("rspMsg", "信息已经注册过,自动审核中");
								hashMap.put("flag", Constants.TYPE_3);
								json = JSONObject.fromObject(hashMap);
								log.info("自动审核中:" + json.toString());
								break;
							}
							case Constants.STATUS4:{
								hashMap.put("rspMsg", "信息已注册，人工审核中");
								hashMap.put("flag", Constants.TYPE_3);
								json = JSONObject.fromObject(hashMap);
								log.info("人工审核中:" + json.toString());
								break;
							}
						}
					}
					merchantregservice.updateB2cShopperbiTemp(shopper);
				} else {
					hashMap.put("rspCode", Constants.APP_LOGIN_FAILED);
					hashMap.put("rspMsg", "手机号或密码错误！");
					json = JSONObject.fromObject(hashMap);
					log.info("密码错误:" + json.toString());
				}
				response.getWriter().write(json.toString());
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "登录异常");
			json = JSONObject.fromObject(hashMap);
			log.info("登录异常:" + json.toString());
			response.getWriter().write(json.toString());
			return;
		}
	}

	
	/** 登录控制
	 * 1.九宫格 （首页）
	 * 2.多结算（秒到，即时，T1）
	 * 3.扫码（支付宝，微信，银联）
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(params = "method=controlLogin")
	public void controlLogin(HttpServletRequest request, HttpServletResponse response) throws Exception{
		Map hashMap=new HashMap();
		Map paramMap=new HashMap<>();
		response.setContentType(Constants.CONTENT_TYPE_UTF8);
		try {
			//主页 九宫格 控制 600
			List<Map<String, Object>> homeTypeList=merchantregservice.findB2cDictHomeType();
			hashMap.put("homeTypeList", homeTypeList);
			//多结算 到账方式 501
			List<Map<String, Object>> mposPayTypeList=merchantregservice.findMposPayType();
			hashMap.put("mposPayTypeList", mposPayTypeList);

			String version  = request.getParameter("version") == null ? "" : request.getParameter("version");
			//兼容老版本快捷收款方式
			List<Map<String, Object>> kjCollectionTypeList = null;
			if(Constants.VERSION_2_3_0.equals(version)){
				kjCollectionTypeList = merchantregservice.findKjCollectionType();
			}else{
				kjCollectionTypeList = merchantregservice.findKjCollectionType220();
			}
			hashMap.put("kjCollectionTypeList", kjCollectionTypeList);
			
			//快捷收款方式
			/*List<Map<String, Object>> kjCollectionTypeList = merchantregservice.findKjCollectionType();
			hashMap.put("kjCollectionTypeList", kjCollectionTypeList);*/
			//扫码 收款方式 502
			List<Map<String, Object>>  qrCollectionTypeList=merchantregservice.findQrCollectionType();
			//扫码 结算方式 500
			List<Map<String, Object>> qrSettlementTypeList=merchantregservice.findQrSettlementType();

			paramMap.put("qrCollectionTypeList", qrCollectionTypeList);
			paramMap.put("qrSettlementTypeList", qrSettlementTypeList);
			hashMap.put("qrPayTypeList", paramMap);
			try{
				String creditAmountRestoreTime = null;
				Map<String, String> param = new HashMap();
				param.put("configKey", "creditAmountRestoreTime");
				log.info("查询mpos_qrcode配置请求参数：{}", FastJson.toJson(param));
				Map<String, Object> result = FastJson.fromJson(HttpClientUtils.REpostRequestStrJson(ConstantsEnv.HTTP_PROTOCOL + ConstantsEnv.MPOS_QRCODE_URL + ConstantsEnv.MPOS_QRCODE_QUERY_CONFIG, FastJson.toJson(param)));
				log.info("查询mpos_qrcode配置返回：{}", result.toString());
				if (result != null && Constants.SUCCESS_CODE_0000.equals(result.get("rspCode"))) {
					List sysConfigs = FastJson.jsonToList(result.get("data").toString());
					creditAmountRestoreTime = FastJson.fromJson(((com.alibaba.fastjson.JSONObject) sysConfigs.get(0)).toString()).get("keyValue").toString();
				}
				paramMap.put("creditAmountRestoreTime", creditAmountRestoreTime);
			}catch(Exception e){
				e.printStackTrace();
			}

			hashMap.put("rspCode", "0000");
			hashMap.put("rspMsg", "登录控制成功！");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("登录控制查询:" + json.toString());
			response.getWriter().write(json.toString());
			
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "1111");
			hashMap.put("rspMsg", "登录控制 查询报错！");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("登录控制 错误:" + json.toString());
			response.getWriter().write(json.toString());
		}
		
	}

	/** 商户版登录控制
	 * 1.九宫格 （首页）
	 * 2.结算（T1）
	 * 3.扫码（支付宝，微信）
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(params = "method=controlMerLogin")
	public void controlMerLogin(HttpServletRequest request, HttpServletResponse response) throws Exception{
		Map hashMap=new HashMap();
        Map qrMap1 = new HashMap();
        Map qrMap2 = new HashMap();
        Map qrPayTypeMap = new HashMap();
		response.setContentType(Constants.CONTENT_TYPE_UTF8);
		try {
            String version  = request.getParameter("version") == null ? "" : request.getParameter("version");
            //商户版主页九宫格控制 620
            List<Map<String, Object>> homeTypeList=merchantregservice.findB2cDictMerchantType(Constants.MERCHANT_HOME_DICTCLSID);
            hashMap.put("homeTypeList", homeTypeList);
            //多结算 到账方式 501
            List<Map<String, Object>> mposPayTypeList=merchantregservice.findB2cDictMerchantType(Constants.MERCHANT_MPOSPAY_DICTCLSID);
            hashMap.put("mposPayTypeList", mposPayTypeList);

			//扫码 支付方式 720
			List<Map<String, Object>> qrCollectionTypeList=merchantregservice.findMerCollectionType();
			//扫码 结算方式 500
            List<Map<String, Object>> qrSettlementTypeList=merchantregservice.findQrSettlementType();
            //扫码收款方式
            List<Map<String, Object>> qrTypeList=merchantregservice.findQrType();

			qrMap1.put("qrCollectionTypeList",qrCollectionTypeList);
			qrMap1.put("qrSettlementTypeList", qrSettlementTypeList);

			qrMap2.put("qrCollectionTypeList",qrCollectionTypeList);
            qrMap2.put("qrSettlementTypeList", qrSettlementTypeList);

            qrPayTypeMap.put("qrTypeList",qrTypeList);
            qrPayTypeMap.put("qrB2CList",qrMap1);
            qrPayTypeMap.put("qrC2BList",qrMap2);

			//paramMap.put("qrSettlementTypeList", qrSettlementTypeList);
			hashMap.put("qrPayTypeList", qrPayTypeMap);
			hashMap.put("rspCode", "0000");
			hashMap.put("rspMsg", "登录控制成功！");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("登录控制查询:" + json.toString());
			response.getWriter().write(json.toString());

		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "1111");
			hashMap.put("rspMsg", "登录控制 查询报错！");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("登录控制 错误:" + json.toString());
			response.getWriter().write(json.toString());
		}

	}


	/**
	 * 代理商登录
	 */
	@RequestMapping(params = "method=agentlogin")
	public void agentlogin(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		String version  = request.getParameter("version") == null ? "" : request.getParameter("version");
		agentlogin210(request,response);
	}
	
	/**
	 * @param request
	 * @param response
	 * @throws IOException 代理商登录
	 * App版本2.1.0
	 */
	public void agentlogin210(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
			Map hashMap = new HashMap();
		try {

			String tel = request.getParameter("tel") == null ? "" : request	.getParameter("tel");
			String password = request.getParameter("password") == null ? ""	:
					AesEncrypt.decryptAES(request.getParameter("password"), ConstantsEnv.APP_AES_KEY);
			log.info("##############password"+request.getParameter("password"));
			Users user = userService.findbytel(tel);
			if (user != null) {
				String shoper=user.getMerchantid().toString();
				Agent agent=agentService.findbyshopperidp(shoper);
				if(agent.getTransactid() != null && agent.getTransactid() ==2){
					hashMap.put("rspCode", "3333");
					hashMap.put("rspMsg","该代理商被冻结!");
					response.setContentType(Constants.CONTENT_TYPE_UTF8);
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("该代理商被冻结:" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				
				if(agent.getTransactid() != null && agent.getTransactid() ==0){
					hashMap.put("rspCode", "4444");
					hashMap.put("rspMsg","该代理商未开通!");
					response.setContentType(Constants.CONTENT_TYPE_UTF8);
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("该代理商未开通:" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				List agentFeeList =agentService.findAgentTopFeeList();
				String up = Md5Encrypt.md5(password);
				if (user.getPassword().equals(up)) {
					hashMap.put("merchantid",user.getMerchantid() == null ? "" : user.getMerchantid());// 代理商
					hashMap.put("tel",user.getTel());
					hashMap.put("name",agent.getScompany());

					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg","登录成功");
					response.setContentType(Constants.CONTENT_TYPE_UTF8);
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("登录成功:" + json.toString());
					response.getWriter().write(json.toString());
				} else {
					hashMap.put("rspCode", "1111");
					hashMap.put("rspMsg","手机号密码错误！请认真核对后输入，谢谢！");
					response.setContentType(Constants.CONTENT_TYPE_UTF8);
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("密码错误:" + json.toString());
					response.getWriter().write(json.toString());
				}

			} else {
				hashMap.put("rspCode", "1112");
				hashMap.put("rspMsg","手机号密码错误！请认真核对后输入，谢谢！");
				response.setContentType(Constants.CONTENT_TYPE_UTF8);
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("电话号码不存在:" + json.toString());
				response.getWriter().write(json.toString());
			}

		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg","登录异常");
			response.setContentType(Constants.CONTENT_TYPE_UTF8);
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("登录异常:" + json.toString());
			response.getWriter().write(json.toString());
		}
	}


    /**
     * 聚合支付商户登录2.4.0
     * @param request
     * @param response
     * @throws IOException
     */
    private void merchantlogin240(HttpServletRequest request, HttpServletResponse response) throws IOException{
        Map hashMap = new HashMap();
        response.setContentType(Constants.CONTENT_TYPE_UTF8);
        JSONObject json = null;
        try {
            String tel = request.getParameter("tel") == null ? "" : request	.getParameter("tel");
            String password = request.getParameter("password") == null ? "" : AesEncrypt.decryptAES(request.getParameter("password"),ConstantsEnv.APP_AES_KEY);
            String type=request.getParameter("type") == null ? ""	: request.getParameter("type");//IOS或者安卓用户登陆

            String up = Md5Encrypt.md5(password);
            Users user = userService.findbytelm(tel);
            //查询商户类型
            B2cShopperbiTemp shopper = merchantregservice.findByAggteltemp(tel);//商户预约信息
            B2cShopperbi keyshopper = merchantregservice.findByAggtel(tel);//商户正式信息
            FixAmaount fix=merchantregservice.searchFixAmaount();
            //未完成认证
            if(shopper == null && user != null){
                hashMap.put("rspCode","1222");
                hashMap.put("rspMsg","未进行商户认证");
                json = JSONObject.fromObject(hashMap);
                log.info("已实名认证，未进行商户认证：" + json.toString());
                response.getWriter().write(json.toString());
                return;
            }

            /*//用户有注册信息且未进行商户认证
            if(user != null && keyshopper == null){
                //查询实名认证
                shopper = merchantregservice.findbytel(tel);
                keyshopper = merchantregservice.findtelbytel(tel);
            }*/

            //判断用户和正式商户是否存在
            if(user == null && keyshopper == null){

                //如果都不存在，走验证码登陆
                B2cShopperVal b2cShopperVal = new B2cShopperVal();
                b2cShopperVal.setTel(tel);
                b2cShopperVal.setPassword(password);
                List<B2cShopperVal> b2cShopperVals = b2cShopperValService.queryByParam(b2cShopperVal);
                if (null != b2cShopperVals && b2cShopperVals.size() > 0){
                    b2cShopperVal = b2cShopperVals.get(0);
                    hashMap.put("rspCode", MessageEnum.成功.getCode());
                    hashMap.put("rspMsg", MessageEnum.成功.getText());
                    hashMap.put("inviteFirstLogin", Constants.STATUS1); //商户首次登陆 1:首次登陆 0:非首次登陆
                    hashMap.put("inviteCodeP", b2cShopperVal.getInviteCodeP()); //上级商户邀请码
                    json = JSONObject.fromObject(hashMap);
                    log.info("商户首次登陆：" + json.toString());
                    response.getWriter().write(json.toString());
                    return;
                }

                //找不到对应验证码表信息，登陆失败
                hashMap.put("rspCode", Constants.APP_LOGIN_FAILED);
                hashMap.put("rspMsg", "手机号或密码错误！");
                json = JSONObject.fromObject(hashMap);
                log.info("不存在的手机号:" + json.toString());
                response.getWriter().write(json.toString());
                return;
            }else {//如果存在已经注册用户，则登陆
                if(shopper.getSifpactid() != null && shopper.getSifpactid() ==1){
                    hashMap.put("rspCode", MessageEnum.商户已冻结.getCode());
                    hashMap.put("rspMsg",MessageEnum.商户已冻结.getText());
                    json = JSONObject.fromObject(hashMap);
                    log.info("该商户被冻结:" + json.toString());
                    response.getWriter().write(json.toString());
                    return;
                }
                if(shopper.getSifpactid() != null && shopper.getSifpactid() ==2){
                    hashMap.put("rspCode", MessageEnum.商户已注销.getCode());
                    hashMap.put("rspMsg",MessageEnum.商户已注销.getText());
                    json = JSONObject.fromObject(hashMap);
                    log.info("该商户被注销:" + json.toString());
                    response.getWriter().write(json.toString());
                    return;
                }
                shopper.setAiflag(type);
                //最大，最小 金额
                hashMap.put("T0minamount", shopper.getT0minamount());
                hashMap.put("T0maxamount", shopper.getT0maxamount());

                if (user.getPassword().equals(up)) {//如果密码匹配
                    hashMap.put("inviteCodeP", keyshopper.getInviteCodeP()); //上级商户邀请码
                    hashMap.put("inviteCode", keyshopper.getInviteCode()); //商户邀请码
                    hashMap.put("idNo", ToolsUtils.getSubStr(keyshopper.getIDNo()));
                    //完整身份证号
                    hashMap.put("idNoClear", AesEncrypt.encryptAES(keyshopper.getIDNo(), ConstantsEnv.APP_AES_KEY));
                    hashMap.put("name",keyshopper.getName());

                    //获取个人端uuid
                    TAppGrantAuthorization tAppGrantAuthorization=appAuthorizationService.findTAppGrantAuthorization(shopper.getShopperid().toString(),tel);
                    hashMap.put("uuid", tAppGrantAuthorization==null?null:tAppGrantAuthorization.getUuid());

                    if(keyshopper.getShopperidP() == null || "".equals(keyshopper.getShopperidP())){
                        hashMap.put("ifHavaAgent", Constants.TYPE_0);
                    }else{
                        hashMap.put("ifHavaAgent", Constants.TYPE_1);
                    }

                    hashMap.put("fixedQrCodeUrl", keyshopper.getFixedqrcodeurl());
                    hashMap.put("fixedQrCodeFlag", keyshopper.getFixedqrcodeflag()==null? Constants.CON_NO:keyshopper.getFixedqrcodeflag());
                    hashMap.put("qrpayMerchantkey", keyshopper.getQrpayMerchantkey());//扫码支付密钥
                    hashMap.put("fixamount", fix.getFixamaount());

                    //商户审核通过（复审通过）
                    if(Constants.CHECK_STATUS_10.equals(shopper.getCheckstatus())){
                        hashMap.put("scompany", keyshopper.getScompany());//商户名称
                        hashMap.put("shoppertype", keyshopper.getMerchantType());//商户类型
                        hashMap.put("bankno", AesEncrypt.encryptAES(keyshopper.getAccountbankno(),ConstantsEnv.APP_AES_KEY));//结算卡银行卡号
                        hashMap.put("shopperid",keyshopper.getShopperid());//小商户号
                        hashMap.put("name",keyshopper.getName());//姓名
                        //hashMap.put("bankname", bankname.getDict());//银行名称
                        hashMap.put("branchBankName", keyshopper.getAccountbankname());//支行名称
                        hashMap.put("openT+0",keyshopper.getIsSupportT0() == null ? "" : keyshopper.getIsSupportT0());//是否支持T+0
                        hashMap.put("merchantKey", keyshopper.getMerchantKey());//key值


                        hashMap.put("firstLogin","false");
                        hashMap.put("rspCode", Constants.SUCCESS_CODE);
                        hashMap.put("rspMsg", "商户审核已通过");
                        hashMap.put("flag", Constants.TYPE_0);

                        json = JSONObject.fromObject(hashMap);
                        log.info("登录成功:" + json.toString());
                    }else{
                        hashMap.put("shopperid",shopper.getShopperid());
                        hashMap.put("scompany", shopper.getScompany());
                        hashMap.put("merchantKey", shopper.getMerchantKey());//key值

                        hashMap.put("firstLogin","false");
                        hashMap.put("rspCode", Constants.SUCCESS_CODE);
                        //获取商户审核状态
                        String shopperChekcstatus = StringUtils.trim(shopper.getCheckstatus());
                        if(shopperChekcstatus.equals(Constants.CHECK_STATUS_6) || shopperChekcstatus.equals(Constants.CHECK_STATUS_7)
                                    || shopperChekcstatus.equals(Constants.CHECK_STATUS_8)){
                            hashMap.put("rspMsg", "信息已注册，审核中");
                            hashMap.put("flag", Constants.TYPE_3);
                            json = JSONObject.fromObject(hashMap);
                            log.info("审核中:" + json.toString());
                        }
                        if(shopperChekcstatus.equals(Constants.CHECK_STATUS_9) || shopperChekcstatus.equals(Constants.CHECK_STATUS_11)){
                            hashMap.put("rspMsg", "信息已注册，审核不通过："+shopper.getNotPassReason());
                            hashMap.put("flag", Constants.TYPE_2);
                            json = JSONObject.fromObject(hashMap);
                            log.info("审核不通过:" + json.toString());
                        }
                    }
                    //merchantregservice.updateB2cShopperbiTemp(shopper);
                } else {
                    hashMap.put("rspCode", Constants.APP_LOGIN_FAILED);
                    hashMap.put("rspMsg", "手机号或密码错误！");
                    json = JSONObject.fromObject(hashMap);
                    log.info("密码错误:" + json.toString());
                }
                response.getWriter().write(json.toString());
                return;
            }
        } catch (Exception e) {
            e.printStackTrace();
            hashMap.put("rspCode", "2222");
            hashMap.put("rspMsg", "登录异常");
            json = JSONObject.fromObject(hashMap);
            log.info("登录异常:" + json.toString());
            response.getWriter().write(json.toString());
            return;
        }
    }



}
