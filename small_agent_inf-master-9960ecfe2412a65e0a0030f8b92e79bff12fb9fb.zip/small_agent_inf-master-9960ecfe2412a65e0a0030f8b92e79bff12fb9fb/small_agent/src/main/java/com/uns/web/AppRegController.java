package com.uns.web;

import com.uns.common.exception.BusinessException;
import com.uns.model.Area;
import com.uns.model.B2cDict;
import com.uns.service.AppRegService;
import com.uns.service.ShopPerbiService;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * app报件
 *
 */
@Controller("AppRegController")
@RequestMapping("/appReg.htm")
public class AppRegController extends BaseController {

	@Autowired
	private AppRegService appRegService;
	
	@Autowired
	private ShopPerbiService shopPerbiService;
	

	/**查询省市区，结算银行
	 * @param request
	 * @param response
	 * @throws BusinessException
	 * @throws Exception
	 */
	@RequestMapping(params = "method=findparam")
	public void findparam(HttpServletRequest request, HttpServletResponse response)
		throws BusinessException, Exception{
		log.info("查询省份，城市，编码...");
		Map hashMap=new HashMap();
		JSONObject jsons =null;
		try {
			//获取省
			List<Area> Provincial=shopPerbiService.searchProvince();
			//获取市
			List<Area> list = shopPerbiService.searchArea();
	    	//获取银行
			List<B2cDict> dicbank = shopPerbiService.searchBank();
	    	
	    	hashMap.put("ProvincialList", Provincial);
	    	hashMap.put("cityList", list);
	    	hashMap.put("bankList", dicbank);
		
			jsons = JSONObject.fromObject(hashMap);
			response.setContentType("UTF-8");
			response.getWriter().write(jsons.toString());
			log.info("查询省份，城市，编码已返回...");
			
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("returnCode", "2222");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("查询省市出错:"+json.toString());
			response.getWriter().write(json.toString());
		}
	
	}
	
	/**小商户注册
	 * @param request
	 * @param response
	 * @throws BusinessException
	 * @throws Exception
	 */
	@RequestMapping(params = "method=saveReg")
	public void saveReg(HttpServletRequest request, HttpServletResponse response)
		throws BusinessException, Exception{
		Map hashMap=new HashMap();
		JSONObject jsons =null;
		try {
			Map map=appRegService.saveReg(request);
			jsons = JSONObject.fromObject(map);
			response.setContentType("UTF-8");
			log.info("注册成功:"+jsons.toString());
			response.getWriter().write(jsons.toString());
			
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("returnCode", "2222");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("注册出错:"+json.toString());
			response.getWriter().write(json.toString());
		}
	
	}
	
	
}
