package com.uns.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtils {

	
	public static String getTypeDate(Date datess, String type) {
		SimpleDateFormat str = new SimpleDateFormat(type);
		String strDates = str.format(datess);
		return strDates;
	}
	
	
	public static void main(String[] args) {
		SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd");
		Date date=new Date();
		System.out.print(dateFormater.format(date));
	}
	
	/**
	 * 日期格式化
	 * @author yang.liu01
	 * @param date
	 * @param format
	 * @return
	 */
	public static String getFormatDate(Date date,String format) {
		String str="";
		if(date!=null && !StringUtils.isEmpty(format)){
			SimpleDateFormat dateFormater = new SimpleDateFormat(format);
			str = dateFormater.format(date);
			return str;
		}
		return null;
	}
}
