package com.uns.web;

import com.uns.common.Constants;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.MposApplicationProgress;
import com.uns.model.MposMerchantFee;
import com.uns.model.MposRemoteFee;
import com.uns.service.MposApplicationProgressService;
import com.uns.service.MposRemoteFeeService;
import com.uns.service.MposmerchantfeeService;
import com.uns.service.ShopPerbiService;
import com.uns.util.StringUtils;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Controller
@RequestMapping(value = "/appprogressController.htm")

public class AppProgressController extends BaseController{
	@Autowired
	private MposApplicationProgressService progressservice;
	@Autowired
	private MposRemoteFeeService remotefeeservice;
	@Autowired
	private MposmerchantfeeService merchantfeeservice;
	@Autowired
	private ShopPerbiService shopperservice;

	@RequestMapping(params = "method=progressbyStatus")
	public void progressbyStatus(HttpServletResponse response,
			HttpServletRequest request) throws IOException {
		Map hashMap = new HashMap();
		try {
			String shopperidP = URLDecoder.decode(request.getParameter("shopperidp") == null ? "" : request.getParameter("shopperidp"), "UTF-8");
			String status = URLDecoder.decode(request.getParameter("status") == null ? "" : request.getParameter("status"), "UTF-8");
			
			if (org.apache.commons.lang.StringUtils.isNotEmpty(shopperidP)&&org.apache.commons.lang.StringUtils.isNotEmpty(status)) {
				String page = request.getParameter("page");
				Map curTranMap = progressservice.findHisTranList(status,shopperidP, page, request);
				hashMap.put("progress", curTranMap.get("list"));
				hashMap.put("page", curTranMap.get("page"));
				hashMap.put("pages", curTranMap.get("pages"));
				hashMap.put("count", curTranMap.get("count"));
				hashMap.put("returnCode", "0000");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("查询成功:" + json.toString());
				response.getWriter().write(json.toString());
			} 
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("returnCode", "2222");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("查询失败:" + json.toString());
			response.getWriter().write(json.toString());
		}

	}
	
	/**
	 * 申请详情
	 * 
	 * @param response
	 * @param request
	 * @throws IOException
	 */
	@RequestMapping(params = "method=progressdetails")
	public void progressdetails(HttpServletResponse response,
			HttpServletRequest request) throws IOException {
		String version  = request.getParameter("version") == null ? "" : request.getParameter("version");
		progressdetails201(response,request);
	}
	
	public void progressdetails201(HttpServletResponse response,
			HttpServletRequest request) throws IOException {
		

		Map hashMap = new HashMap();
		try {
			String shopperid =request.getParameter("shopperid") ;
			String id=request.getParameter("id").trim();
			if(StringUtils.isEmpty(shopperid)||StringUtils.isEmpty(id)){
				hashMap.put("rspCode", "3333");
				hashMap.put("rspMsg", "申请详情失败,参数为空");
				return;
			}else{
				MposApplicationProgress progress=progressservice.findbyid(Long.parseLong(id));
				B2cShopperbiTemp shopper=shopperservice.findbyshopperid(shopperid);
				if (shopper == null) {
					hashMap.put("rspCode", "1111");
					hashMap.put("rspMsg", "详情信息不存在");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("详情信息不存在:" + json.toString());
					response.getWriter().write(json.toString());
				} else {
					MposRemoteFee remotefee = remotefeeservice.findbytel(shopper.getStel());
					MposMerchantFee merchantfee=merchantfeeservice.findbyshopperid(shopperid);
					Map detailMap = new HashMap();
					SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					String dateString = formatter.format(shopper.getCreated() == null ? "" : shopper.getCreated());
					detailMap.put("remoteInvitation", dateString);
					detailMap.put("tel", shopper.getStel() == null ? "": shopper.getStel());
					detailMap.put("openToFlag", shopper.getIsSupportT0());
					detailMap.put("t0Fee",shopper.getT0fee());
					detailMap.put("t0fixedamount",shopper.getT0fixedamount());
					detailMap.put("t0maxamount",shopper.getT0maxamount());
					detailMap.put("t0minamount",shopper.getT0minamount());
					detailMap.put("shopperLimit",shopper.getT0SingleDayLimit() == null ? "" : shopper.getT0SingleDayLimit());
					detailMap.put("status",progress.getApplicationStatus() == null ? ""	: progress.getApplicationStatus());
					
					
					List merchantfeelist = merchantfeeservice.merchantfeelist(shopperid);
					if(merchantfeelist!=null){
						detailMap.put("feelist", merchantfeelist);
					}else{
						List remotefeeList = remotefeeservice.remotefeeList(shopper.getStel());
						detailMap.put("feelist", remotefeeList);
					}
					
					
					hashMap.put("agentdetails", detailMap);
					
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "申请详情成功");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("申请进度详情:" + json.toString());
					response.getWriter().write(json.toString());
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "申请详情失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("邀请详情失败:" + json.toString());
			response.getWriter().write(json.toString());
		}
	}
	
	
	

}
