package com.uns.web;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.exception.BusinessException;
import com.uns.model.B2cShopperbi;
import com.uns.model.TradeRecord;
import com.uns.service.RecordService;
import com.uns.service.TradeRecordService;
import com.uns.util.HttpClientUtils;
import com.uns.util.Md5Encrypt;
import com.uns.util.StringUtils;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 机构t0提现和查询余额 
 */
@Controller
@RequestMapping(value = "/recordController")
public class RecordController extends BaseController{
	@Autowired
	private RecordService recordService;
	@Autowired
	private TradeRecordService tradeRecordService;
	
	SimpleDateFormat sf = new SimpleDateFormat("yyyyMMddHHmmss");
	
	/**
	 * 查询余额和授信额度
	 * @param merchantId 商户号
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="balance.htm",method=RequestMethod.POST)
	public void balance(HttpServletRequest request,HttpServletResponse response,String merchantId,String mac
			,String traceNo) throws IOException{
		response.setContentType("UTF-8");
		Map<String, String[]> params = request.getParameterMap();  
        String queryString = "";  
        for (String key : params.keySet()) {  
            String[] values = params.get(key);  
            for (int i = 0; i < values.length; i++) {  
                String value = values[i];  
                queryString += key + "=" + value + "&";  
            }  
        }  
        // 去掉最后一个空格  
        queryString = queryString.substring(0, queryString.length() - 1);  
        log.info("机构--查询余额和授信额度：" + queryString);
        //生成订单号
        String orderId = StringUtils.getOrderId(tradeRecordService.getOrderId());
    	String orderTime = sf.format(new Date());
		
		if(val(merchantId) || val(traceNo)){
			response.getWriter().write(errorMsg("11110001",orderId,orderTime,traceNo));
			return;
		}else{
			//验证是否有上送流水号
			if(!validTraceNo(traceNo)){
				response.getWriter().write(errorMsg("11110008",orderId,orderTime,traceNo));
				return;
			}
			
			//验证提现请求是否过快
			if(!repeatSubmit(traceNo, merchantId)){
				response.getWriter().write(errorMsg("11110009",orderId,orderTime,traceNo));
				//保存提现记录，用于判断重复提交
				Constants.CZ_DATA.put(merchantId, traceNo);
				return;
			}
			
			//保存提现记录，用于判断重复提交
			Constants.CZ_DATA.put(merchantId, traceNo);
			
			String record = null;
			B2cShopperbi b2cShopperbi = recordService.findFactoringNoByShopperid(merchantId);
			//如果根据商户号查不到商户信息
			if(b2cShopperbi==null){
				response.getWriter().write(errorMsg("11110005",orderId,orderTime,traceNo));
				return;
			}
			//验证mac
			if(!valMac(mac, merchantId, "&traceNo=" + traceNo,b2cShopperbi.getMerchantKey())){
				response.getWriter().write(errorMsg("11110003",orderId,orderTime,traceNo));
				return;
			}
			//如果查到的商户没有保理账户ID
			String userId = b2cShopperbi.getFactoringno();
			if(val(userId)){
				response.getWriter().write(errorMsg("11110006",orderId,orderTime,traceNo));
				return;
			}
			try {
				//发送请求并接收
				String str =  "&orderId=" + orderId + "&orderTime=" +orderTime;
				String requestStr = mac(userId, str);
				log.info("请求保理平台："+ ConstantsEnv.BALANCE_URL+"   "+requestStr);
				record = HttpClientUtils.REpostRequestStr(ConstantsEnv.BALANCE_URL, requestStr);
				log.info("响应："+record);
				JSONObject  json = JSONObject.fromObject(record);
				
				//收到返回消息，验证mac
				String str2 = "rspCode="+json.get("rspCode")+"&rspMsg="+json.get("rspMsg") +
					val("balance", json.get("balance")==null?null:json.get("balance").toString()) +
					val("creditLine", json.get("creditLine")==null?null:json.get("creditLine").toString()) +
					val("orderId", json.get("orderId")==null?null:json.get("orderId").toString()) +
					"&merchantKey="+ ConstantsEnv.BLZH_KEY;
				if(!json.get("mac").toString().equals(Md5Encrypt.md5(str2))){
					response.getWriter().write(errorMsg("11110007",orderId,orderTime,traceNo));
					return;
				}
				
				if(Constants.mapReturnMsg.containsKey(json.get("rspCode"))){
					json.put("rspMsg", Constants.mapReturnMsg.get(json.get("rspCode")));
					if("2211".equals(json.get("rspCode"))){
						Map<String,String> map = selectD0Time();
						json.put("rspMsg", Constants.mapReturnMsg.get(json.get("rspCode")) + map.get("t0starttime") + " - " + map.get("t0endtime"));
					}
				}
				json.put("orderTime", orderTime);
				json.put("traceNo", traceNo);
				//修改mac值
				String str3 = "rspCode="+json.get("rspCode")+"&rspMsg="+json.get("rspMsg") +
				val("balance", json.get("balance")==null?null:json.get("balance").toString()) +
				"&orderId=" + json.get("orderId") +
				"&orderTime=" + orderTime +
				"&traceNo=" + traceNo +
				"&merchantKey="+ ConstantsEnv.BLZH_KEY;
				json.put("mac", Md5Encrypt.md5(str3));
				
				json.remove("creditLine");
				record = json.toString();
			} catch (BusinessException e) {
				response.getWriter().write(errorMsg("11110002",orderId,orderTime,traceNo));
				return;
			}
			response.getWriter().write(record);
			return;
		}
	}
	
	/**
	 * t0提现
	 * @param merchantId 商户号
	 * @param curType 币种
	 * @param amount 订单金额
	 * @param remark 备注
	 * @param mac 报文鉴别码
	 * @throws IOException
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="t0withdraw.htm",method=RequestMethod.POST)
	public void t0withdraw(HttpServletRequest request,HttpServletResponse response,String merchantId,String curType,
			String amount,String remark,String mac,String traceNo) throws IOException{
		response.setContentType("UTF-8");
		Map<String, String[]> params = request.getParameterMap();  
	        String queryString = "";  
	        for (String key : params.keySet()) {  
	            String[] values = params.get(key);  
	            for (int i = 0; i < values.length; i++) {  
	                String value = values[i];  
	                queryString += key + "=" + value + "&";  
	            }  
	        }  
	    // 去掉最后一个空格  
	    queryString = queryString.substring(0, queryString.length() - 1);  
	    log.info("机构t0提现：" + queryString); 
	    //生成订单号
        String orderId = StringUtils.getOrderId(tradeRecordService.getOrderId());
    	String orderTime = sf.format(new Date());
		//接受到请求后，保存请求数据
		TradeRecord t = new TradeRecord("0","0",orderId, orderTime, curType, amount, remark, mac, new Date());
		t.setMerchantId(merchantId);
		
		//验证有没有缺少必填参数
		if(val(merchantId) || val(curType) || val(amount) || val(traceNo) || val(remark) || val(mac)){
			insert(t,"11110001");
			response.getWriter().write(errorMsg("11110001",orderId,orderTime,traceNo));
			return;
		}else{
			t.setTraceNo(traceNo);
			//验证是否有上送流水号
			if(!validTraceNo(traceNo)){
				insert(t,"11110008");
				response.getWriter().write(errorMsg("11110008",orderId,orderTime,traceNo));
				return;
			}
			
			//验证提现请求是否过快
			if(!repeatSubmit(traceNo, merchantId)){
				insert(t,"11110009");
				response.getWriter().write(errorMsg("11110009",orderId,orderTime,traceNo));
				//保存提现记录，用于判断重复提交
				Constants.CZ_DATA.put(merchantId, traceNo);
				return;
			}
			
			//保存提现记录，用于判断重复提交
			Constants.CZ_DATA.put(merchantId, traceNo);
			
			if(Double.parseDouble(amount)<=0){
				insert(t,"11110004");
				response.getWriter().write(errorMsg("11110004",orderId,orderTime,traceNo));
				return;
			}
			
			String record = null;
			//根据商户号查询商户信息
			B2cShopperbi b2cShopperbi = recordService.findFactoringNoByShopperid(merchantId);
			//如果根据商户号查不到商户信息
			if(b2cShopperbi==null){
				insert(t,"11110005");
				response.getWriter().write(errorMsg("11110005",orderId,orderTime,traceNo));
				return;
			}
			//验证mac
			String str = "&curType=" + curType + "&amount=" + amount + "&remark=" + remark + "&traceNo=" + traceNo;
			if(!valMac(mac, merchantId, str,b2cShopperbi.getMerchantKey())){
				insert(t,"11110003");
				response.getWriter().write(errorMsg("11110003",orderId,orderTime,traceNo));
				return;
			}
			//如果查到的商户没有保理账户ID
			String userId = b2cShopperbi.getFactoringno();
			if(val(userId)){
				insert(t,"11110006");
				response.getWriter().write(errorMsg("11110006",orderId,orderTime,traceNo));
				return;
			}
			t.setUserId(userId);
			
			try {
				
				//发送请求并接收
				String str1 = "&curType=" + curType + "&amount=" + amount + "&orderId=" + orderId + "&orderTime=" +orderTime  + "&remark=" + remark;
				String requestStr = mac(userId, str1);
				log.info("请求保理平台："+ ConstantsEnv.T0WITHDRAW_URL+"   "+requestStr);
				record = HttpClientUtils.REpostRequestStr(ConstantsEnv.T0WITHDRAW_URL, requestStr);
				log.info("响应："+record);
				JSONObject  json = JSONObject.fromObject(record);
				
				//保存返回结果
				t.setRspCode(json.get("rspCode")==null?null:json.get("rspCode").toString());
				t.setRspCodeTrue(json.get("rspCode")==null?null:json.get("rspCode").toString());
				t.setRspMsg(json.get("rspMsg")==null?null:json.get("rspMsg").toString());
				t.setRspMac(json.get("mac")==null?null:json.get("mac").toString());
				t.setRspAmount(json.get("amount")==null?null:json.get("amount").toString());
				
				//收到返回消息，验证mac
				String str2 = "rspCode="+json.get("rspCode")+"&rspMsg="+json.get("rspMsg")+
					val("amount", json.get("amount")==null?null:json.get("amount").toString())+
					val("orderId", json.get("orderId")==null?null:json.get("orderId").toString()) +
					"&merchantKey="+ ConstantsEnv.BLZH_KEY;
				if(!json.get("mac").toString().equals(Md5Encrypt.md5(str2))){
					insert(t,"11110007"); 
					response.getWriter().write(errorMsg("11110007",orderId,orderTime,traceNo));
					return;
				}
				
				t.setRspCodeTrue(json.get("rspCode").toString());
				tradeRecordService.insertSelective(t);
				
				if(Constants.mapReturnMsg.containsKey(json.get("rspCode"))){
					json.put("rspMsg", Constants.mapReturnMsg.get(json.get("rspCode")));
					if("2211".equals(json.get("rspCode"))){
						Map<String,String> map = selectD0Time();
						json.put("rspMsg", Constants.mapReturnMsg.get(json.get("rspCode")) + map.get("t0starttime") + " - " + map.get("t0endtime"));
					}
				}
				json.put("orderTime", orderTime);
				json.put("traceNo", traceNo);
				//修改mac值
				String str3 = "rspCode="+json.get("rspCode")+"&rspMsg="+json.get("rspMsg") +
				val("amount", json.get("amount")==null?null:json.get("amount").toString()) + 
				"&orderId=" + json.get("orderId") +
				"&orderTime=" + orderTime +
				"&traceNo=" + traceNo +
				"&merchantKey="+ ConstantsEnv.BLZH_KEY;
				json.put("mac", Md5Encrypt.md5(str3));
				
				record = json.toString();
				response.getWriter().write(record);
				return;
			} catch (Exception  e) {
				insert(t,"11110002");
				response.getWriter().write(errorMsg("11110002",orderId,orderTime,traceNo));
				e.printStackTrace();
				return;
			}
		}
	}
	
	/**
	 * 拼接参数
	 * @param paramName 参数名
	 * @param param 参数值
	 * @return
	 */
	public String val(String paramName,String param){
		if(param != null && param != "" && !"null".endsWith(param)){
			return "&" + paramName + "=" + param ;
		}
		return "";
	}
	
	/**
	 * 验证非空
	 */
	public boolean val(String param){
		if(param == null || param == ""){
			return true;
		}
		return false;
	}
	
	/**
	 * 验证mac
	 */
	public boolean valMac(String mac,String merchantId,String str,String key){
		return mac.equalsIgnoreCase(Md5Encrypt.md5("merchantId=" + merchantId + str + "&merchantKey=" + key).toLowerCase());
	} 

	/**
	 * 算mac,并拼接好请求参数
	 */
	public String mac(String userId,String str){
		return "userId=" + userId + str + "&mac=" + Md5Encrypt.md5("userId=" + userId + str + "&merchantKey=" + ConstantsEnv.BLZH_KEY).toLowerCase();
	}
	
	/**
	 *  根据返回码，生成返回值
	 */
	public String errorMsg(String code){
		HashMap<String,String> hashMap = new HashMap<String, String>();
		hashMap.put("rspCode", code);
		hashMap.put("rspMsg", Constants.mapReturnMsg.get(code));
		String mac = Md5Encrypt.md5("rspCode=" + code + "&rspMsg=" + Constants.mapReturnMsg.get(code));
	    hashMap.put("mac", mac);
		return JSONObject.fromObject(hashMap).toString();
	}
	
	/**
	 *  根据返回码，生成返回值
	 */
	public String errorMsg(String code,String orderId,String orderTime,String traceNo){
		HashMap<String,String> hashMap = new HashMap<String, String>();
		hashMap.put("rspCode", code);
		hashMap.put("rspMsg", Constants.mapReturnMsg.get(code));
		hashMap.put("orderId", orderId);
		hashMap.put("orderTime", orderTime);
		hashMap.put("traceNo", traceNo);
		String mac = Md5Encrypt.md5("rspCode=" + code + "&rspMsg=" + Constants.mapReturnMsg.get(code) +
				"&orderId=" + orderId + "&orderTime=" + orderTime + "&traceNo=" + traceNo);
	    hashMap.put("mac", mac);
		return JSONObject.fromObject(hashMap).toString();
	}
	
	/**
	 * 保存t0提现记录
	 * @param t
	 * @param code
	 */
	public void insert(TradeRecord t,String code){
		t.setRspCodeTrue(code);
		if(Constants.mapReturnMsg.containsKey(code))
		{
			t.setRspMsg(Constants.mapReturnMsg.get(code));
		}
		tradeRecordService.insertSelective(t);
	}
	
	private static boolean validTraceNo(String traceNo){
		if(traceNo==null || traceNo.length()!=16){
			return false;
		}
		
		Pattern pattern = Pattern.compile("LS[0-9]{14}");
		Matcher matcher = pattern.matcher(traceNo);
		
		return matcher.matches();
	}
	
	/**
	 * 
	 * @param traceNo
	 * @param merchantId
	 * @return true:重复提交,false:否
	 */
	private static boolean repeatSubmit(String traceNo,String merchantId){
		String lastTime = Constants.CZ_DATA.get(merchantId);
		//如果不存在，则说明没有体现过，则不继续验证
		if(lastTime == null){
			return true;
		}
		
		//否则验证  是否是3秒内的请求
		Long last = new Long(lastTime.substring(2));
		Long now = new Long(traceNo.substring(2));
		if((last+3)>now){
			return false;
		}
		return true;
	}
	
	public Map<String,String> selectD0Time(){
		Map<String,String> result = new HashMap<String, String>();
		List<Map<String,String>> list = recordService.selectD0Time();
		for (Map<String, String> map : list) {
			result.put(map.get("KEY"), map.get("VALUE"));
		}
		return result;
	}
}
