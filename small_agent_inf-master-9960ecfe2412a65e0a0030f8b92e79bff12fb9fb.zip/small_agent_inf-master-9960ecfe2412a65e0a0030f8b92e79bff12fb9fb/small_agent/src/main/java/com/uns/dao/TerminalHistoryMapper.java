package com.uns.dao;

import com.uns.model.TerminalHistory;
import org.springframework.stereotype.Repository;

@Repository
public interface TerminalHistoryMapper {


    int insert(TerminalHistory record);

    int insertSelective(TerminalHistory record);

}