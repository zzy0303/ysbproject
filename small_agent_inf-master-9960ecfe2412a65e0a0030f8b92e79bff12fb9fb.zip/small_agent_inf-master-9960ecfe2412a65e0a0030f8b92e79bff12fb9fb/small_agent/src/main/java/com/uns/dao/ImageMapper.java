package com.uns.dao;

import com.uns.model.Image;
import org.springframework.stereotype.Repository;

@Repository
public interface ImageMapper {


    int deleteByPrimaryKey(byte[] uuid);

    int insert(Image record);

    int insertSelective(Image record);

    Image selectByPrimaryKey(byte[] uuid);


    int updateByPrimaryKeySelective(Image record);

    int updateByPrimaryKey(Image record);

	Image getImageByName(String targetFileName);
}