package com.uns.dao;

import com.uns.common.exception.BusinessException;
import com.uns.model.B2cDict;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface B2cDictMapper {


	 /**根据分类编码，查询行业类型
	 * @return
	 */
	List<B2cDict> searchDictCls(String dictclsid)throws BusinessException;
	
	/* (non-Javadoc)根据分类编码和外部编码，获取对象
	 */
	public List searchDictName(Map<String, String> map)throws BusinessException;
	
	/**
	 * 查询银行
	 */
	public List searchDictBank();
	/**
	 * 查询银行名字
	 */
	public B2cDict findDictBankName(String b2cDictId);
	
	
	
	
	List findbyB2Cname(String dict);
    
	
	List findbyhCname(String dict);
	
	public List queryBank();


	String findB2cDictQrPAY();

	List<Map<String, Object>> findGatheringMethod();

	public B2cDict findDictByBankName(String accountbankdictval);

	List<Map<String, Object>> findB2cDictMposPayType();

	String findB2cDictBank(String b2cDictId);

	List<Map<String, Object>> findB2cDictHomeType();

	List<Map<String, Object>> findQrCollectionType();

	List<Map<String, Object>> findQrSettlementType();

	List<Map<String, Object>> findMposPayType();

    List<Map<String,Object>> findKjCollectionType();
    
    String findUnionBankCode(String accountbankdictval);

	B2cDict findBankDictById(String accountbankdictval);

	List<Map<String,Object>> findKjCollectionType220();
	
	B2cDict findBankByNote(String note);

	List<Map<String, Object>> findB2cDictMerHomeType(String dictclsid);

	List<Map<String, Object>> findMerCollectionType();

	List<Map<String,Object>> findQrType();

}