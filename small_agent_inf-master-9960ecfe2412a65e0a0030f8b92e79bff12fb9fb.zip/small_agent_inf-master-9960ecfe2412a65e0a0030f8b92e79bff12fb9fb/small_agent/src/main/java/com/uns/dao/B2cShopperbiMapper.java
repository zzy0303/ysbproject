package com.uns.dao;


import com.uns.model.B2cShopperbi;
import com.uns.model.B2cShopperbiTemp;
import com.uns.web.form.ShopPerbiForm;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public interface B2cShopperbiMapper {


    int insert(B2cShopperbiTemp record);
    
    
    int insertSelective(B2cShopperbiTemp record);


	List<HashMap> ShopFormalManageList(ShopPerbiForm mbForm);

	B2cShopperbi selectFormalshoppId(String b2cShopperbiId);


	void updateFormalBankInfo(B2cShopperbiTemp b2cShopperbi);
	
	void updateShoppbiTemp(B2cShopperbiTemp b2cShopperbi);
	
	B2cShopperbi findregajax(Map map);
	 
	 List findtelbytel(String tel);
	 
	 List findbyid(String identityId);
	 
	 B2cShopperbi findFactoringNoByShopperid(String shopperid);

	 List<B2cShopperbi> judgeShopper(Map map);
	 
	 void updateIfActivedByYsbno(Map<String, Object> param);


	void updateQrCode(Map map);


	void updateQrPayCode(Map map);

    List<String> findAllInviteCode();

	List<B2cShopperbi> findNoInvite();

	void updateInviteCode(Map<String, Object> param);
	List findBySearchFromList(Map map);

    B2cShopperbi queryByShopperid(String shopperid);

    void updateConfigByShopperid(B2cShopperbi b2cShopperbi);

	public void deleteByIdNo(String idNo);
	
	void updateShopperActive(B2cShopperbiTemp b2cShopperbiTemp);

	Integer findSIdNo(String idNo);

	B2cShopperbi findByAggtel(String stel);
}