package com.uns.service;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.dao.*;
import com.uns.model.Agent;
import com.uns.model.B2cShopperVal;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.Users;
import com.uns.util.AesEncrypt;
import com.uns.util.Md5Encrypt;
import com.uns.util.RegularUtils;
import com.uns.web.form.AgentForm;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.shiro.crypto.hash.Hash;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AgentService {
	
	@Autowired
	private AgentMapper agentMapper;
	
	@Autowired
	private AgentOperatorMapper agentOperatorMapper;
	@Autowired
	private B2cShopperbiTempMapper b2cShopperbiTempMapper;
	
	@Autowired
	private UsersMapper usermapper;

	@Autowired
	private B2cShopperValMapper shopperValMapper;

	@Autowired
	private MposMerchantFeeMapper merchantfeeMapper;

	@Autowired
	private MposRemoteFeeMapper remotefeemapper;
	
	private SimpleDateFormat format=new SimpleDateFormat(Constants.DEFAULT_DATE_FORMAT);



	/**
	 * 查询申请进度详情
	 * @param request
	 * @return
	 */
	public HashMap applicationProInfo(HttpServletRequest request) {
		HashMap hashMap = new HashMap();
		String shopperid =request.getParameter("shopperid") == null ? "" : request.getParameter("shopperid").trim();
		try {
			if("".equals(shopperid)){
				hashMap.put("rspCode","1001");
				hashMap.put("rspMsg","商户号为空");
				return hashMap;
			}
			List list=b2cShopperbiTempMapper.findbyshopperid(shopperid);
			B2cShopperbiTemp shopper=null;
			if(list!=null&&list.size()>0){
				shopper=(B2cShopperbiTemp)list.get(0);
			}
			Map detailMap = new HashMap();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String dateString = shopper.getCreated() == null ? "" :formatter.format( shopper.getCreated());
			detailMap.put("remoteInvitation", dateString);
			detailMap.put("stel", shopper.getStel() == null ? "": shopper.getStel());
			detailMap.put("openT0Flag", shopper.getIsSupportT0());
			detailMap.put("t0Fee",shopper.getT0fee());
			detailMap.put("t0fixedamount",shopper.getT0fixedamount());
			detailMap.put("t0maxamount",shopper.getT0maxamount());
			detailMap.put("t0minamount",shopper.getT0minamount());
			detailMap.put("shopperLimit",shopper.getT0SingleDayLimit() == null ? "" : shopper.getT0SingleDayLimit());
			detailMap.put("status",shopper.getCheckstatus());//OCR审核进度
			if(null != shopper.getRecheckDate()){
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				detailMap.put("checkDate", sdf.format(shopper.getRecheckDate()));
			}
			detailMap.put("notPassReason", shopper.getNotPassReason());

			List merchantfeelist =merchantfeeMapper.merchantfeelist(shopperid);
			if(merchantfeelist!=null){
				detailMap.put("feelist", merchantfeelist);
			}else{
				List remotefeeList = remotefeemapper.remotefeeList(shopper.getStel());
				detailMap.put("feelist", remotefeeList);
			}
			hashMap.put("shopperDetails", detailMap);
			hashMap.put("rspCode", "0000");
			hashMap.put("rspMsg", "成功");
			return hashMap;
		} catch (Exception e){
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "出错");
			return hashMap;
		}
	}

	/**
	 * 查询申请进度列表
	 * @param request
	 * @return
	 */
	public HashMap applicationProList(HttpServletRequest request) {
		HashMap hashMap = new HashMap();
		String shopperidp = request.getParameter("shopperidp") == null ? "" : request.getParameter("shopperidp").trim();
		String status = request.getParameter("status") == null ? "" : request.getParameter("status").trim();//用于筛选的商户审核状态
		String tpage = request.getParameter("page") == null ? "1" : request.getParameter("page").trim();
		try {
			if("".equals(shopperidp)){
				hashMap.put("rspCode","1001");
				hashMap.put("rspMsg","服务商编号为空");
				return hashMap;
			}
			int currentPage = Integer.valueOf(tpage);
			Page page  = new Page();
			PageContext context = PageContext.getContext();
			page.setCurrentPage(currentPage);
			BeanUtils.copyProperties(context, page);
			context.setPageSize(Constants.page_size);
			context.setPagination(true);
			Map<String, String> map=new HashMap<String, String>();
			map.put("status", status);
			map.put("shopperidP", shopperidp);
			
			//查询未申请实名认证的商户
			List noOCRList = shopperValMapper.findNoOCRVal();
			List list = b2cShopperbiTempMapper.findApplicationProOCRList(map);
			hashMap.put("noOCRList",noOCRList);
			hashMap.put("progress",list);
			hashMap.put("page",context.getCurrentPage());
			hashMap.put("pages",context.getTotalPages());
			hashMap.put("count",context.getTotalRows());
			hashMap.put("rspCode","0000");
			hashMap.put("rspMsg","成功");
			return hashMap;
		}catch (Exception e){
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "出错");
			return hashMap;
		}
	}


	public HashMap agentUpdatePwd(HttpServletRequest request) {
		HashMap hashMap = new HashMap();
		String tel = request.getParameter("tel") == null ? "" : request.getParameter("tel").trim(); //手机号
		String password = request.getParameter("password") == null ? "" :
				AesEncrypt.decryptAES(request.getParameter("password"), ConstantsEnv.APP_AES_KEY); //密码
		try {
			if ("".equals(tel)) {
				hashMap.put("rspCode", "1001");
				hashMap.put("rspMsg", "手机号码为空");
				return hashMap;
			}
			if("".equals(password)){
				hashMap.put("rspCode", "1002");
				hashMap.put("rspMsg", "密码为空");
				return hashMap;
			}
			Users user = usermapper.findbytel(tel);
			if(null == user){
				hashMap.put("rspCode", "1003");
				hashMap.put("rspMsg", "用户不存在");
				return hashMap;
			}
			List<Agent> agents = agentMapper.findbytel(tel);
			if(null == agents || agents.size() <= 0){
				hashMap.put("rspCode", "1004");
				hashMap.put("rspMsg", "手机号未注册");
				return hashMap;
			}

			String mpassword= Md5Encrypt.md5(password);
			user.setPassword(mpassword);
			usermapper.updateByUsresId(user);

			hashMap.put("rspCode", "0000");
			hashMap.put("rspMsg", "成功");
			return hashMap;

		}catch (Exception e){
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "出错");
			return hashMap;
		}
	}

	public HashMap agentCheckCode(HttpServletRequest request) {
		HashMap hashMap = new HashMap();
		String tel = request.getParameter("tel") == null ? "" : request.getParameter("tel").trim(); //手机号
		String smsCode = request.getParameter("smsCode") == null ? "" : request.getParameter("smsCode"); //验证码
		try {
			if ("".equals(tel)) {
				hashMap.put("rspCode", "1001");
				hashMap.put("rspMsg", "手机号码为空");
				return hashMap;
			}
			if ("".equals(smsCode)) {
				hashMap.put("rspCode", "1002");
				hashMap.put("rspMsg", "验证码为空");
				return hashMap;
			}
			B2cShopperVal b2cShopperVal = new B2cShopperVal();
			b2cShopperVal.setTel(tel);
			b2cShopperVal.setSmsCode(smsCode);
			List<B2cShopperVal> shopperVals = shopperValMapper.queryByParam(b2cShopperVal);
			if (shopperVals != null && shopperVals.size() > 0) {
				Date curDate = new Date();
				Long time = curDate.getTime() - shopperVals.get(0).getSmsCodeDate().getTime();
				if(time > Constants.TIME_TEN){
					hashMap.put("rspCode", "1004");
					hashMap.put("rspMsg", "验证码过期");
					return hashMap;
				}
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "成功");
				return hashMap;
			}else {
				hashMap.put("rspCode", "1003");
				hashMap.put("rspMsg", "验证码错误,请重新输入");
				return hashMap;
			}
		}catch (Exception e){
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "出错");
			return hashMap;
		}
	}

	public HashMap checkTel(String tel, String smsCode) {
		HashMap hashMap = new HashMap();
		try {
			if ("".equals(tel)) {
				hashMap.put("rspCode", "1001");
				hashMap.put("rspMsg", "手机号码为空");
				return hashMap;
			}
			if (!RegularUtils.isMobile(tel)) {
				hashMap.put("rspCode", "1002");
				hashMap.put("rspMsg", "手机号码格式不对");
				return hashMap;
			}
			List<Agent> agents = agentMapper.findbytel(tel);
			Agent agent = null;
			if(agents != null && agents.size() > 0){
				agent = agents.get(0);
			}

			if (agent == null) {
				hashMap.put("rspCode", "1003");
				hashMap.put("rspMsg", "手机号未注册");
				return hashMap;
			}else {
				B2cShopperVal b2cShopperVal = new B2cShopperVal();
				b2cShopperVal.setTel(tel);
				List<B2cShopperVal> shopperVals = shopperValMapper.queryByParam(b2cShopperVal);
				if (shopperVals != null && shopperVals.size() > 0) {
					shopperValMapper.delByParam(shopperVals.get(0).getB2cShopperValId());
				}

				b2cShopperVal.setSmsCode(smsCode);
				b2cShopperVal.setSmsCodeDate(new Date());
				shopperValMapper.saveShopperVal(b2cShopperVal);

				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "可发送验证码");
				return hashMap;
			}
		}catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "出错");
			return hashMap;
		}
	}

	/**
	 * 查询代理商
	 * @param agent
	 * @return
	 * @throws ParseException 
	 */
	public List<Agent> queryAgentList(AgentForm agentForm) throws ParseException{
		PageContext.initPageSize(20);
		List<Agent> agentList = agentMapper.searchAgentList(agentForm);
		return agentList;
	}
	
	public List<Agent> selectAgentList(AgentForm agentForm) throws ParseException{
		PageContext.initPageSize(20);
		List<Agent> agentList = agentMapper.selectAgentList(agentForm);
		return agentList;
	}
	
	
	/**
	 * 查询商户
	 * @param shopperUser
	 * @return
	 * @throws ParseException 
	 */
	public B2cShopperbiTemp queryShopPerbi(String b2cShopperbiId)throws Exception {
		return b2cShopperbiTempMapper.selectByshopperId(Long.valueOf(b2cShopperbiId));
	}
	
	/**
	 * 查询代理商的信息
	 * @param agentid
	 * @return
	 * @throws ParseException 
	 */
	public Map queryAgentInfo(String agentid) throws ParseException{
		Map agentinfo = agentMapper.agentInfo(agentid);
		return agentinfo;
	}
	
	/**
	 * 查询代理商的信息根据手机号码
	 * @param agentid
	 * @return
	 * @throws ParseException 
	 */
	public Map queryAgentInfotel(String stel) throws ParseException{
		Map agentinfo = agentMapper.agentInfotel(stel);
		return agentinfo;
	}
	
	/**
	 * 查询代理商树
	 * @return
	 */
	public List<Agent> searchAgentTree(AgentForm agentForm){
		return agentMapper.searchAgentTree(agentForm);
	}
	
	public List<Agent> findAgentByMerchantId(String shopperbiid){
		return agentMapper.findAgentByMerchantId(shopperbiid);
	}
	
	public void updateUser(Users agentUser){
		agentOperatorMapper.updateOperator(agentUser);
	}
	
	public Agent searchAgentById(String id) {
		return agentMapper.searchAgentById(id);
	}
	
	public Agent searchAgentByShopperId(String shopperId) {
		return agentMapper.searchAgentByShopperid(shopperId);
	}
	public Agent searchAgentByName(String scompany) {
		return agentMapper.searchAgentByName(scompany);
	}
	
	public Long searchUserByNameAndShopperid(Map params){
		return agentMapper.searchUserByNameAndShopperid(params);
	}
	public void updateAgent(Agent agent){
		agentMapper.updateAgent(agent);
	}
	/**代理商地图
	 * @param merchantId
	 * @return
	 */
	public List findAgentByMerchantIdMap(String merchantId) {
		return agentMapper.findAgentByMerchantIdMap(merchantId);
	}
	public List updateAgentByMerchantId(String merchantId, String shopperid) {
		Map map=new HashMap();
		map.put("merchantId", Long.valueOf(merchantId));
		map.put("shopperid", Long.valueOf(shopperid));
		return agentMapper.updateAgentByMerchantId(map);
	}
	
	public Agent findbyshopperidp(String shopperidp){
		return agentMapper.findbyshopperidp(shopperidp);
	}
	
	
	public Agent findbytel(String tel){
		List list=agentMapper.findbytel(tel);
  		Agent agent=null;
		if(list!=null&&list.size()>0){
			agent=(Agent)list.get(0);
		}
		return agent;
	}
	
	public void updateuseragent(Users users,Agent agent, Users sessionUser){
		//判断有没有修改费率,如果修改了费率，需要在保存修改日志
		Map<String, Object> param = new HashMap<String, Object>();
		Agent a = agentMapper.searchAgentByShopperid(String.valueOf(agent.getShopperid()));
		boolean flag = false;
		if(a.getSkDebitFee() == null || "".equals(a.getSkDebitFee()) || !agent.getSkDebitFee().equals(a.getSkDebitFee())){
			flag = true;
			param.put("skDebitFee", agent.getSkDebitFee());
		}
		if(a.getSkCreditFee() == null || "".equals(a.getSkCreditFee()) || !agent.getSkCreditFee().equals(a.getSkCreditFee())){
			flag = true;
			param.put("skCreditFee", agent.getSkCreditFee());
		}
		if(a.getD0Fee() == null || "".equals(a.getD0Fee()) || !agent.getD0Fee().equals(a.getD0Fee())){
			flag = true;
			param.put("d0Fee", agent.getD0Fee());
		}
		if(a.getSmWechatD0Fee() == null || "".equals(a.getSmWechatD0Fee()) || !agent.getSmWechatD0Fee().equals(a.getSmWechatD0Fee())){
			flag = true;
			param.put("smWechatD0Fee", agent.getSmWechatD0Fee());
		}
		if(a.getSmWechatT1Fee() == null || "".equals(a.getSmWechatT1Fee()) || !agent.getSmWechatT1Fee().equals(a.getSmWechatT1Fee())){
			flag = true;
			param.put("smWechatT1Fee", agent.getSmWechatT1Fee());
		}
		if(a.getSmAlipayD0Fee() == null || "".equals(a.getSmAlipayD0Fee()) || !agent.getSmAlipayD0Fee().equals(a.getSmAlipayD0Fee())){
			flag = true;
			param.put("smAlipayD0Fee", agent.getSmAlipayD0Fee());
		}
		if(a.getSmAlipayT1Fee() == null || "".equals(a.getSmAlipayT1Fee()) || !agent.getSmAlipayT1Fee().equals(a.getSmAlipayT1Fee())){
			flag = true;
			param.put("smAlipayT1Fee", agent.getSmAlipayT1Fee());
		}
		if(flag){
			param.put("createDate", new Date());
			param.put("updateUser", a.getShopperidP());
			param.put("shopperid", a.getShopperid());
			param.put("updateScompany", sessionUser.getUserName() );
			agentMapper.insertUpdateAgentfeeAlog(param);
		}
		
		agentMapper.updateAgent(agent);
		users.setIsAgent(Short.valueOf(Constants.CON_YES));
		usermapper.updateByUsresId(users);
	}
	
	public List<Map<String,Object>> selectUpdateAgentfeeAlogList(String shopperid){
		PageContext.initPageSize(20);
		return agentMapper.selectUpdateAgentfeeAlogList(shopperid);
	}

	public List findAgentTopFee() {
		return agentMapper.findAgentTopFee();
	}

	public List findAgentByScompay(String shopperId, String scompay) {
		Map map=new HashMap();
		map.put("shopperId", shopperId);
		map.put("scompay", scompay);
		return agentMapper.findAgentByScompay(map);
	}

	public List findAgentTopFeeList() {
		return agentMapper.findAgentTopFeeList();
	}

	public List findAgentTopFeeByType(String type) {
		return agentMapper.findAgentTopFeeByType(type);
	}
	
	/**
	 * 库存管理终端出库用到的树结构 
	 * @param shopperId
	 * @return
	 */
	public List<Agent>findAgentForTermOutTree(String shopperId){
		return this.agentMapper.findAgentForTermOutTree(shopperId);
	}



}
