package com.uns.service;

import com.uns.common.myenum.MessageEnum;
import com.uns.dao.B2cShopperbiShareMapper;
import com.uns.dao.B2cShopperbiTempMapper;
import com.uns.model.B2cShopperbiShare;
import com.uns.model.B2cShopperbiTemp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Administrator on 2017/6/21.
 */
@Service
public class B2cShopperbiShareService {

    @Autowired
    private B2cShopperbiShareMapper b2cShopperbiShareMapper;

    @Autowired
    private B2cShopperbiTempMapper b2cShopperbiTempMapper;

    public HashMap shareOperator(HttpServletRequest request) {
        HashMap hashMap = new HashMap();
        try {
            String operType = request.getParameter("operType") == null ? "" : request.getParameter("operType"); //操作类型(share:分享   visit:访问   reg:注册)
            String operChannel = request.getParameter("operChannel") == null ? "" : request.getParameter("operChannel"); //操作渠道(wx:微信    qq:qq    zfb:支付宝)
            String operContent = request.getParameter("operContent") == null ? "" : request.getParameter("operContent"); //操作内容(link:链接文案   qrcode:二维码)
            String operTel = request.getParameter("operTel") == null ? "" : request.getParameter("operTel"); //操作人手机号

            B2cShopperbiShare b2cShopperbiShare = new B2cShopperbiShare();
            b2cShopperbiShare.setOperType(operType);
            b2cShopperbiShare.setOperChannel(operChannel);
            b2cShopperbiShare.setOperContent(operContent);
            b2cShopperbiShare.setOperTel(operTel);
            b2cShopperbiShare.setOperDate(new Date());
            b2cShopperbiShareMapper.insertSelective(b2cShopperbiShare);
            hashMap.put("rspCode", MessageEnum.成功.getCode());
            hashMap.put("rspMsg", MessageEnum.成功.getText());

        } catch (Exception e) {
            e.printStackTrace();
            hashMap.put("rspCode", MessageEnum.出错.getCode());
            hashMap.put("rspMsg", MessageEnum.出错.getText());
        }
        return hashMap;
    }

    public HashMap collectShareOper(HttpServletRequest request) {
        HashMap hashMap = new HashMap();
        String shopperid = request.getParameter("shopperid");
        try {
            B2cShopperbiTemp b2cShopperbiTemp = b2cShopperbiTempMapper.findShopperbiTempByShopperid(shopperid);
            Map map = b2cShopperbiShareMapper.collectShareOper(b2cShopperbiTemp.getStel());
            hashMap.put("rspCode", MessageEnum.成功.getCode());
            hashMap.put("rspMsg", MessageEnum.成功.getText());
            hashMap.put("data", map);
            return hashMap;
        } catch (Exception e){
            e.printStackTrace();
            hashMap.put("rspCode", MessageEnum.出错.getCode());
            hashMap.put("rspMsg", MessageEnum.出错.getText());
            return hashMap;
        }
    }
}
