package com.uns.dao;

import com.uns.model.SInfomationMerchantRelation;
import org.springframework.stereotype.Repository;

import java.util.Map;

@Repository
public interface SInfomationMerchantRelationMapper {

    int insert(SInfomationMerchantRelation record);

    int insertSelective(SInfomationMerchantRelation record);

	void updateInfomationMerchant(Map map);

}