package com.uns.service;

import com.uns.dao.B2cShopperValMapper;
import com.uns.model.B2cShopperVal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class B2cShopperValService {

	@Autowired
	private B2cShopperValMapper b2cShopperValMapper;
	
	public void saveShopperVal(B2cShopperVal b2cShopperVal) {
		b2cShopperValMapper.saveShopperVal(b2cShopperVal);
	}

	public List<B2cShopperVal> queryByParam(B2cShopperVal b2cShopperVal) {
		return b2cShopperValMapper.queryByParam(b2cShopperVal);
	}

	public void delByParam(Long b2cShopperValId) {
		b2cShopperValMapper.delByParam(b2cShopperValId);
	}

	public void editByParam(B2cShopperVal b2cShopperVal) {
		b2cShopperValMapper.editByParam(b2cShopperVal);
	}
}
