package com.uns.infimpl;

import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.dao.B2cShopperbiMapper;
import com.uns.inf.SmartRoutInf;
import com.uns.util.FastJson;
import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 智能路由接口
 * The type Smart rout face.
 */
@Service("smartRoutInfImpl")
public class SmartRoutInfImpl implements SmartRoutInf {

    private Logger log = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private B2cShopperbiMapper b2cShopperbiMapper;


    /**
     * Search shoppper string.
     * 查询商户
     * @param map the map
     * @return the string
     */
    @Override
    public String searchShoppper(Map map) {
        HashMap hashMap = new HashMap();
        log.info("##########线下智能路由查询商户###########");
        try {
            log.info("查询商户请求参数：{}", FastJson.toJson(map));
            if(map.get("pageNo") == null || "".equals(map.get("pageNo"))){
                map.put("pageNo","1");
            }
            if(map.get("pageSize") == null || "".equals(map.get("pageSize"))){
                map.put("pageSize","10");
            }
            int currentPage = Integer.parseInt(map.get("pageNo").toString());
            Page page = new Page();
            PageContext context = PageContext.getContext();
            page.setCurrentPage(currentPage);
            BeanUtils.copyProperties(context, page);
            context.setPageSize(Integer.parseInt(map.get("pageSize").toString()));
            context.setPagination(true);

            List list = b2cShopperbiMapper.findBySearchFromList(map);
            hashMap.put("rspCode","0000");
            hashMap.put("rspMsg","成功");
            hashMap.put("pageNo",String.valueOf(context.getCurrentPage()));
            hashMap.put("pageSize",String.valueOf(context.getPageSize()));
            hashMap.put("count",String.valueOf(context.getTotalRows()));
            hashMap.put("smartRoutForm",list);
        }catch (Exception e){
            log.error("{}",e);
            hashMap.put("rspCode","2222");
            hashMap.put("rspMsg","系统错误");
        }
        log.info("查询商户返回参数：{}",FastJson.toJson(hashMap));
        return FastJson.toJson(hashMap);
    }
}
