package com.uns.service;

import java.io.InputStream;

public interface ImageInterfaceService {

	public String saveImage(String moduleName, String path, String imageFrom, InputStream input) throws Exception;

	public String saveAppImage(String moduleName, String imageFrom, String StringStream) throws Exception;
}
