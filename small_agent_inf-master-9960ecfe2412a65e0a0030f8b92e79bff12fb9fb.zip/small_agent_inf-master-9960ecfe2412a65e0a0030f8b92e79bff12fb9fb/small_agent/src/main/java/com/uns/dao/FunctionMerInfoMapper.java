package com.uns.dao;

import com.uns.model.FunctionMerInfo;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FunctionMerInfoMapper {

    int deleteByPrimaryKey(Long id);

    int insert(FunctionMerInfo record);
    
    int insertSelective(FunctionMerInfo record);
    
    List<FunctionMerInfo> selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(FunctionMerInfo record);

    int updateByPrimaryKey(FunctionMerInfo record);
    //查询有效的权限
	List<FunctionMerInfo> selectByStatus(Long valueOf);

	List<FunctionMerInfo> selectFunctionByUsercode1(String usercode);
}