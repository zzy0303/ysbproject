package com.uns.util;

import com.slx.hsm.HsmUtils;
import com.uns.utils.ISOUtils;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOUtil;

public class HkUtils {

	public static String macCalc(String param, String macKey) throws Exception {
		byte[] b = param.getBytes("UTF-8");
		int pbLength = b.length;
		pbLength = (b.length%8==0?b.length:b.length + 8-b.length%8);
		byte[] mabStrTemp = new byte[pbLength];
		System.arraycopy(b, 0, mabStrTemp, 0, b.length);
		byte[] macByte = new byte[8];
		byte[] tempByte = new byte[8];
		System.arraycopy(b, 0, macByte, 0, macByte.length);
		//1.异或0-63域
		for(int i=1;i<pbLength/8;i++){
			System.arraycopy(mabStrTemp, i*8, tempByte, 0, tempByte.length);
			macByte = ISOUtil.xor(macByte, tempByte);
		}
		//2.将异或的结果展开
		String tempStr = ISOUtil.hexString(macByte);
		//3.取前8位
		byte[] before8Byte = tempStr.substring(0,8).getBytes();
		//4.取后8位
		byte[] after8Byte = tempStr.substring(8,16).getBytes();
		//5.将前8位进行加密
		macByte = ISOUtil.hex2byte(HsmUtils.desCalc(macKey, ISOUtil.hexString(before8Byte)));
		//6.将加密结果与后8位进行异或
		macByte = ISOUtil.xor(macByte, after8Byte);
		//7.将异或结果进行加密
		macByte = ISOUtil.hex2byte(HsmUtils.desCalc(macKey, ISOUtil.hexString(macByte)));
		return ISOUtils.hexString(macByte).substring(0, 8);
	}

		/**
         * 计算MAC
         * @param msg
         * @param macKey
         * @throws ISOException
         */
	public static void macCalc(ISOMsg msg, String macKey) throws Exception {
		try {
			//设置默认的64域
			msg.set(64,new byte[]{0,0,0,0,0,0,0,0});
			//重新 算MAC(总共有8步）
			byte[] b = msg.pack();
			int pbLength = b.length;
			pbLength = (b.length%8==0?b.length-8:b.length-b.length%8);
			byte[] mabStrTemp = new byte[pbLength];
			System.arraycopy(b, 0, mabStrTemp, 0, pbLength);
			byte[] macByte = new byte[8];
			byte[] tempByte = new byte[8];
			System.arraycopy(b, 0, macByte, 0, macByte.length);
			//1.异或0-63域
			for(int i=1;i<pbLength/8;i++){
				System.arraycopy(b, i*8, tempByte, 0, tempByte.length);
				macByte = ISOUtil.xor(macByte, tempByte);
			}
			//2.将异或的结果展开
			String tempStr = ISOUtil.hexString(macByte);
			//3.取前8位
			byte[] before8Byte = tempStr.substring(0,8).getBytes();
			//4.取后8位
			byte[] after8Byte = tempStr.substring(8,16).getBytes();
			//5.将前8位进行加密
//			macByte = DesUtil.encrypt(before8Byte, ISOUtil.hex2byte(macKey));
			macByte = ISOUtil.hex2byte(HsmUtils.desCalc(macKey, ISOUtil.hexString(before8Byte)));
			//6.将加密结果与后8位进行异或
			macByte = ISOUtil.xor(macByte, after8Byte);
			//7.将异或结果进行加密
//			macByte = DesUtil.encrypt(macByte, ISOUtil.hex2byte(macKey));
			macByte = ISOUtil.hex2byte(HsmUtils.desCalc(macKey, ISOUtil.hexString(macByte)));
			
			String macStr = ISOUtil.hexString(macByte);
			//8.展开加密结果，取前8位
			msg.set(64,macStr.substring(0,8).getBytes());
		} catch (Exception e) {
			e.printStackTrace();
//			throw new InnerException("数据加密异常");
		}
	}
	
}
