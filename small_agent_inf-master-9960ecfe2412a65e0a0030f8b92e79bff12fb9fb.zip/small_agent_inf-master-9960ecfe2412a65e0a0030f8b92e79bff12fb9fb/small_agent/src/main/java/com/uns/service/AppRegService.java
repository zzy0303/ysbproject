package com.uns.service;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.dao.AreaMapper;
import com.uns.dao.B2cShopperbiTempMapper;
import com.uns.model.Area;
import com.uns.model.B2cShopperbiTemp;
import com.uns.util.Md5Encrypt;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AppRegService {

	protected Logger log = LoggerFactory.getLogger(this.getClass());	
	@Autowired
	private B2cShopperbiTempMapper b2cShopperbiTempMapper;
	
	@Autowired
	private AreaMapper areaMapper;
	
	/**
	 * 	App注册：
	 *  1.判断商户名称是否重复
	 *  2.调用远程接口是否成功（绑定终端与设备）
	 *  3.注册商户信息
	 * @throws Exception 
	 * 
	 */
	public Map saveReg(HttpServletRequest request) throws Exception {
		log.info("app注册...");
		HashMap map=new HashMap();
		String scompany=URLDecoder.decode(request.getParameter("scompany")==null?"":request.getParameter("scompany"),"UTF-8");
		String city=request.getParameter("city")==null?"":request.getParameter("city");//城市编码
		String province=request.getParameter("province")==null?"":request.getParameter("province");//省份编码
		String saddress=URLDecoder.decode(request.getParameter("saddress")==null?"":request.getParameter("saddress"),"UTF-8");//地址
		String stel=request.getParameter("stel")==null?"":request.getParameter("stel");//联系电话
		
		String settlementType= Constants.CON_NO;//结算至银行
		String accountbankdictval=request.getParameter("accountbankdictval")==null?"":request.getParameter("accountbankdictval");//开户银行
		String accountbankprov=request.getParameter("accountbankprov")==null?"":request.getParameter("accountbankprov");//开户省份
		String accountbankname=URLDecoder.decode(request.getParameter("accountbankname")==null?"":request.getParameter("accountbankname"),"UTF-8");//开户地址
		String accountbankclientname=URLDecoder.decode(request.getParameter("accountbankclientname")==null?"":request.getParameter("accountbankclientname"),"UTF-8");//开户姓名
		String accountbankno=request.getParameter("accountbankno")==null?"":request.getParameter("accountbankno");//银行卡号
		//暂无
		String username=request.getParameter("username")==null?"":request.getParameter("username");//密码
		String password=request.getParameter("password")==null?"":request.getParameter("password");//密码
		
		String deviceNumber=request.getParameter("deviceNumber")==null?"":request.getParameter("deviceNumber");//设备号
		
		//验证用户名是否重复
		B2cShopperbiTemp  b2cShopperbi=b2cShopperbiTempMapper.selectByScompany(scompany);
		if(b2cShopperbi!=null){
			log.info("商户名称重复...");
			map.put("returnCode", "0001");
			map.put("reason", "scompany is exist");
			return map;
		}
		if(!StringUtils.isNotEmpty(accountbankclientname)&&!StringUtils.isNotEmpty(scompany)&&!StringUtils.isNotEmpty(deviceNumber)){
			map.put("returnCode", "0002");
			map.put("reason", "param is null");
		}
		
		String shopperid = getPosShopperId(city, Constants.CON_MCC);
		//调用app接口
		Map regMap=new HashMap();
		regMap.put("deviceNumber", deviceNumber);
		regMap.put("scompay", URLEncoder.encode(scompany, "GBK"));
		regMap.put("youngMerchant",shopperid);
		
		
		JSONObject obs = JSONObject.fromObject(regMap);
		String url=ConstantsEnv.REG_URL+obs.toString()+"";
		org.apache.http.client.HttpClient httpclient=new DefaultHttpClient();
		url=url.replace("\"", "%22");
		url=url.replace("{", "%7B");
		url=url.replace("}", "%7D");
		log.info("设备绑定终端..."+url);
		HttpPost httpget=new HttpPost(url);
		
		HttpResponse httprespone;
		
		httprespone = httpclient.execute(httpget);
		
		String str = EntityUtils.toString(httprespone.getEntity());
		Map map1 = com.uns.util.JsonUtil.jsonStrToMap(str);
		JSONObject ob = JSONObject.fromObject(map1);
		String code=(String) ob.get("returnCode");
		log.info("终端绑定设备..."+code);
		if(Constants.SUCCESS_CODE.equals(code)){
			B2cShopperbiTemp b2cShopperbiTemp=new B2cShopperbiTemp();
		
			b2cShopperbiTemp.setShopperid(Long.valueOf(shopperid));
			b2cShopperbiTemp.setScompany(scompany);
			b2cShopperbiTemp.setProvince(province);
			b2cShopperbiTemp.setCity(city);
			b2cShopperbiTemp.setStel(stel);
			b2cShopperbiTemp.setSaddress(saddress);
			b2cShopperbiTemp.setSettlementType(settlementType);
			b2cShopperbiTemp.setAccountbankdictval(accountbankdictval);
			b2cShopperbiTemp.setAccountbankprov(accountbankprov);
			b2cShopperbiTemp.setAccountbankname(accountbankname);
			b2cShopperbiTemp.setAccountbankclientname(accountbankclientname);
			b2cShopperbiTemp.setAccountbankno(accountbankno);
			String Md5pwd=Md5Encrypt.md5(password);
			b2cShopperbiTemp.setMuserid(username);
			b2cShopperbiTemp.setMpassword(Md5pwd);
			b2cShopperbiTemp.setIsformal(Short.valueOf(Constants.CON_NO));
			
			if(StringUtils.isNotEmpty(province)){
				List searchProvincialList=searchProvincial(province);
	    		if(searchProvincialList!=null&&searchProvincialList.size()>0){
	    			Area spro=(Area)searchProvincialList.get(0);
	        		if(spro!=null){
	        			String sprov=spro.getProvincialname();
	        			b2cShopperbiTemp.setSprovince(sprov);
	        		}
	    		}
			}
			if(StringUtils.isNotEmpty(city)){
				List cityList = searchCity(city);
				if (cityList != null && cityList.size() > 0) {
					Area area = (Area) cityList.get(0);
					if (area != null) {
						String cityName = (String) area.getCityname();
						b2cShopperbiTemp.setScity(cityName);
					}
				}
			}
			
			b2cShopperbiTempMapper.insert(b2cShopperbiTemp);
			map.put("returnCode", "0000");
			map.put("merchantNo", shopperid);
			map.put("reason", "reg successful!");
			
			log.info("app成功...");
		}else{
			return map1;
		}
		return map;
	}

	/**
	 * @param province
	 * @return
	 * @throws Exception
	 */
	public List searchProvincial(String province)throws Exception {
		Area area=new Area();
		area.setProvincial(province);
		return areaMapper.searchProvincial(area);
	}
	
	/**
	 * @param city
	 * @return
	 * @throws Exception
	 */
	public List searchCity(String city)throws Exception {
		Area area=new Area();
		area.setCity(city);
		return areaMapper.searchCity(area);
	}
	
	/**
	 * @param area
	 * @param mcc
	 * @return
	 * @throws Exception
	 */
	public  String getPosShopperId(String area, String mcc) throws Exception {
        String organization="800"; 
        String areacold="";
        if (area.length()>4) {
            areacold=area.substring(0,4);
        }else {
            areacold=area;
        }   
        String mcccold="";  
        if (mcc.length()==1) {
            mcccold="000"+mcc;
        }else {
            mcccold="00"+mcc;
        }
        String merchantRadom=RandomStringUtils.randomNumeric(4);
        String posMerchantId=organization+areacold+mcccold+merchantRadom;
        B2cShopperbiTemp b2cShopperbi=b2cShopperbiTempMapper.selectByshopperId(Long.valueOf(posMerchantId));
        if(b2cShopperbi!=null){
        	return getPosShopperId(area,mcc);
        }
        return posMerchantId;
    }
	
	
	
}
