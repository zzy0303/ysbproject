package com.uns.web;

import com.uns.common.Constants;
import com.uns.model.B2cShopperVal;
import com.uns.service.AppOpenRegService;
import com.uns.service.SendMessageService;
import net.sf.json.JSONObject;
import org.apache.commons.lang.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;


/**
 * 商户开放注册
 * 
 * @author FK
 *
 */
@Controller
@RequestMapping("/appOpenReg.htm")
@SuppressWarnings({ "rawtypes", "unchecked" })
public class AppOpenRegController extends BaseController {

	@Autowired
	private AppOpenRegService appOpenRegService;

	@Autowired
	private SendMessageService sendMessageService;

	/**
	 * 统计申请信用卡最小数量
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(params = "method=countCreditMin")
	public void countCreditMin(HttpServletRequest request,HttpServletResponse response) throws IOException {
		response.setContentType("UTF-8");
		HashMap hashMap = appOpenRegService.countCreditMin(request);
		JSONObject json = JSONObject.fromObject(hashMap);
		log.info("统计申请信用卡最小数量:{}",json.toString());
		response.getWriter().write(json.toString());
	}

	/**
	 * 设置默认收款码
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(params="method=setDefaultQrCode")
	public void setDefaultQrCode(HttpServletRequest request, HttpServletResponse response) throws IOException{
		response.setContentType("UTF-8");
		HashMap hashMap = appOpenRegService.setDefaultQrCode(request);
		JSONObject json = JSONObject.fromObject(hashMap);
		log.info("设置默认收款码:"+json.toString());
		response.getWriter().write(json.toString());
	}
	
	/**
	 * 查询二维码详情
	 * @param request
	 * @param response
	 * @throws IOException 
	 */
	@RequestMapping(params="method=queryQrCodeByNo")
	public void queryQrCodeByNo(HttpServletRequest request, HttpServletResponse response) throws IOException{
		response.setContentType("UTF-8");
		HashMap hashMap = appOpenRegService.queryQrCodeByNo(request);
		JSONObject json = JSONObject.fromObject(hashMap);
		log.info("查询二维码详情:"+json.toString());
		response.getWriter().write(json.toString());
	}
	
	/**
	 * 查询商户已绑定二维码
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(params = "method=queryQrCodeList")
	public void queryQrCodeList(HttpServletRequest request, HttpServletResponse response) throws IOException{
		response.setContentType("UTF-8");
		HashMap hashMap = appOpenRegService.queryQrCodeList(request);
		JSONObject json = JSONObject.fromObject(hashMap);
		log.info("查询商户已绑定二维码:"+json.toString());
		response.getWriter().write(json.toString());
	}

	/**
	 * 商户二维码绑定
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(params = "method=qrCodeBind")
	public void qrCodeBind(HttpServletRequest request, HttpServletResponse response) throws IOException{
		response.setContentType("UTF-8");
		HashMap hashMap = appOpenRegService.qrCodeBind(request);
		JSONObject json = JSONObject.fromObject(hashMap);
		log.info("商户二维码绑定:"+json.toString());
		response.getWriter().write(json.toString());
	}

	/**
	 * 商户终端绑定
	 * @param request
	 * @param response
	 * @throws IOException 
	 */
	@RequestMapping(params = "method=devicenumbunding")
	public void devicenumbunding(HttpServletRequest request, HttpServletResponse response) throws IOException{
		response.setContentType("UTF-8");
		HashMap hashMap = appOpenRegService.appOpenRegService(request);
		JSONObject json = JSONObject.fromObject(hashMap);
		log.info("商户终端绑定:"+json.toString());
		response.getWriter().write(json.toString());
	}
	
	/**
	 * 商户认证 注册
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(params = "method=merchantCA")
	public void merchantCA(HttpServletRequest request, HttpServletResponse response) throws Exception{
		response.setContentType("UTF-8");
		HashMap map = appOpenRegService.merchantCA(request);
		JSONObject json = JSONObject.fromObject(map);
		log.info("商户认证:"+json.toString());
		response.getWriter().write(json.toString());
	}

	/**
	 * 实名认证
     * 聚合支付版：添加结算信息
	 * @param request
	 * @param response
	 * @throws IOException 
	 */
	@RequestMapping(params = "method=checkRelIdentity")
	public void checkRelIdentity(HttpServletRequest request, HttpServletResponse response) throws IOException{
		response.setContentType("UTF-8");
		String version = request.getParameter("version") == null ? "" : request.getParameter("version");
		String merchantType = request.getParameter("merchantType") == null ? "" : request.getParameter("merchantType");
		HashMap hashMap = new HashMap();
		//APP版本为2.4.0 、商户类型 2
        if(Constants.VERSION_2_4_0.equals(version) && Constants.ATTESTATION_2.equals(merchantType)){
            hashMap = appOpenRegService.checkSettleCustomer(request);
        } else {
            hashMap = appOpenRegService.checkRelIdentity220(request);

        }

		JSONObject json = JSONObject.fromObject(hashMap);
		log.info("实名认证:"+json.toString());
		response.getWriter().write(json.toString());
	}
	
	
	
	/**
	 * 注册验证
	 * 两次密码输入是否一致
	 * 验证验证码是否过期
	 * 验证手机号和验证码是否对应
	 *
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	
	@RequestMapping(params = "method=checkRegInfo")
	public void checkRegInfo(HttpServletRequest request, HttpServletResponse response) throws IOException {
		response.setContentType("UTF-8");
		response.setHeader("Access-Control-Allow-Origin","*");
		response.setHeader("Access-Control-Allow-Methods","GET,POST");
		String version = request.getParameter("version") == null ? "" : request.getParameter("version");
		HashMap hashMap = new HashMap();
		hashMap = appOpenRegService.checkRegInfo220(request);
		JSONObject json = JSONObject.fromObject(hashMap);
		log.info("注册验证:"+json.toString());
		response.getWriter().write(json.toString());
	}

	/**
	 * 验证注册商户账号是否存在
	 * 如果手机号可以注册发送短信验证码
	 * 
	 * @param request
	 * @param response
	 * @throws IOException
	 * @throws InterruptedException
	 */
	@RequestMapping(params = "method=checkRegTel")
	@ResponseBody
	public void checkRegTel(HttpServletRequest request, HttpServletResponse response)
			throws InterruptedException, IOException {
		response.setContentType("UTF-8");
		response.setHeader("Access-Control-Allow-Origin","*");
		response.setHeader("Access-Control-Allow-Methods","GET,POST");
		String tel = request.getParameter("tel") == null ? "" : request.getParameter("tel").trim();
		HashMap hashMap = new HashMap();
		try {
			String smsCode = RandomStringUtils.randomNumeric(4);
			hashMap = appOpenRegService.checkRegTel(tel,smsCode);
			
			if("0000".equals(hashMap.get("rspCode"))){
				// 发送短信验证码
				B2cShopperVal b2cShopperVal = new B2cShopperVal();
				b2cShopperVal.setTel(tel);
				b2cShopperVal.setSmsCode(smsCode);
				sendMessageService.sendCodeMessage(b2cShopperVal,request);
			}
			hashMap.put("smsCode", smsCode);
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("验证手机号:"+json.toString());
			response.getWriter().write(json.toString());
			
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "出错");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info(json.toString());
			response.getWriter().write(json.toString());
		}
	}


}
