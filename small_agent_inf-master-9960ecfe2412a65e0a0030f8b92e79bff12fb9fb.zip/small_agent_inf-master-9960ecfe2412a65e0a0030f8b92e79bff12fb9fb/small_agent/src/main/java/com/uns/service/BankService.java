package com.uns.service;

import com.uns.dao.B2cDictMapper;
import com.uns.dao.BankBranchMapper;
import com.uns.model.B2cDict;
import com.uns.model.BankBranch;
import com.uns.model.SupportBankForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class BankService {
	
	@Autowired
	private B2cDictMapper b2cDictMapper;
	
	@Autowired
	private BankBranchMapper bankbranchMapper;
	
	
	
	/** 查询银行
	 * @return
	 */
	public List<B2cDict> searchBank()throws Exception {
		List<B2cDict> list=b2cDictMapper.searchDictBank();
		return list;
	}
	
	
	public List<B2cDict> queryBank()throws Exception {
		List<B2cDict> list=b2cDictMapper.queryBank();
		return list;
	}
	
	public List<BankBranch> searchBankBranch(String city,String province,String bankname)throws Exception{
		     Map map=new HashMap();       
		    map.put("city", city);
		    map.put("province", province);
		    map.put("bankname", bankname);
		    return bankbranchMapper.searchBankBranch(map);
	}

    /**
     * 查询快捷支持银行列表
     * @return
     */
	public List<SupportBankForm> querySupportBankList(){
	    List<SupportBankForm> list = bankbranchMapper.querySupportBankList();
	    return list;
    }
}
