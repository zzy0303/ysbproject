package com.uns.web;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.model.B2cFixedCode;
import com.uns.model.B2cShopperbi;
import com.uns.service.B2cFixedCodeService;
import com.uns.service.ShopPerbiService;
import com.uns.util.FastJson;
import com.uns.util.HttpClientUtils;
import com.uns.util.Md5Encrypt;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping(value = "/appFixedQrCodeUrl.htm")
public class AppFixedQrCodeUrlController extends BaseController {
	
	@Autowired
	private ShopPerbiService shopPerbiService;
	
	@Autowired
	private B2cFixedCodeService fixedCodeService;
	
	@RequestMapping(params = "method=createFixedQrCodeUrl")
	public void createFixedQrCodeUrl(HttpServletRequest request,HttpServletResponse response) throws Exception {
		String merchantNo=request.getParameter("merchantNo");
		String merchantType = request.getParameter("merchantType") == null ? "" : request.getParameter("merchantType").toString();
		Map hashMap = new HashMap();
		response.setContentType("UTF-8");
		try {
			if(StringUtils.isEmpty(merchantNo)){
				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg","参数为空");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("生成固定二维码" + json.toString());
				response.getWriter().write(json.toString());
				return;
			}
			B2cShopperbi b2cShopperbi=shopPerbiService.selectFormalShopperId(merchantNo);
			if(b2cShopperbi==null){
				hashMap.put("rspCode", "1112");
				hashMap.put("rspMsg","参数有误");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("生成固定二维码" + json.toString());
				response.getWriter().write(json.toString());
				return;
			}
			
			if("".equals(b2cShopperbi.getShopperidP()) || null == b2cShopperbi.getShopperidP()){
				hashMap.put("rspCode", "1113");
				hashMap.put("rspMsg","商户未绑定服务商");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("生成固定二维码" + json.toString());
				response.getWriter().write(json.toString());
				return;
			}
			//判断是否申请过固码

            B2cFixedCode b2cFixedCode = new B2cFixedCode();
            b2cFixedCode.setMerchantid(merchantNo);
            List<B2cFixedCode> fixedCodes = fixedCodeService.findFixedCodesByParam(b2cFixedCode);

			//如果申请过固码 取默认固码返回
			if(null != fixedCodes && fixedCodes.size() > 0){
				for (B2cFixedCode b2cFixedCode2 : fixedCodes) {
					if(Constants.STATUS1.equals(b2cFixedCode2.getIfDefault())){
						b2cFixedCode = b2cFixedCode2;
					}
				}
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg","二维码申请成功");
				//聚合支付版新加商户固码url绑定
				if(merchantType.equals(Constants.TYPE_2)){
					hashMap.put("fixedQrCodeUrl", getMerQrCodeUrl(b2cFixedCode.getQrCodeNo()));
				} else {
					hashMap.put("fixedQrCodeUrl", getQrCodeUrl(b2cFixedCode.getQrCodeNo()));
				}
				hashMap.put("fixedQrCodeFlag", Constants.CON_YES);
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("申请二维码:"+json.toString());
				response.getWriter().write(json.toString());
				return;
			}else{ //如果没有申请过固码  则取对应服务商固码 进行绑定
				Map map = new HashMap();
				map.put("agentNo", b2cShopperbi.getShopperidP());

				//获取查询二维码排除参数
				if(!"".equals(Constants.FIXEDCODE_NO_QUERY)){
					List noQueryList = FastJson.jsonToList(Constants.FIXEDCODE_NO_QUERY);
					map.put("noQueryList", noQueryList);
				}
				
				List<B2cFixedCode> b2cFixedCodes = fixedCodeService.findNoBindQrCode(map);
				if(null != b2cFixedCodes && b2cFixedCodes.size() > 0){
					b2cFixedCode = b2cFixedCodes.get(0);
					
					Map params = new HashMap();
					params.put("qrCode", b2cFixedCode.getQrCodeNo());
					params.put("smallMerchNo", merchantNo);
					JSONObject obs = JSONObject.fromObject(params);
					log.info("mpos_qrcode商户绑定二维码请求参数:"+obs.toString());
					String resultString = HttpClientUtils.REpostRequestStrJson(
							ConstantsEnv.QRCODE_BIND_URL, obs.toString());
					Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);
					log.info("mpos_qrcode商户绑定二维码响应参数:"+com.alibaba.fastjson.JSONObject.toJSONString(resultMap));
					
					b2cFixedCode.setBindingDate(new Date());
					b2cFixedCode.setIfDefault(Constants.STATUS1);
					b2cFixedCode.setMerchantid(merchantNo);
					b2cFixedCode.setTel(b2cShopperbi.getStel());
					b2cFixedCode.setScompany(b2cShopperbi.getScompany());
					fixedCodeService.updateById(b2cFixedCode); //二维码绑定
                    String fixedQrCodeUrl = "";
                    //聚合支付版新加商户固码url绑定
                    if(merchantType.equals(Constants.TYPE_2)){
                        fixedQrCodeUrl = getMerQrCodeUrl(b2cFixedCode.getQrCodeNo());
                    } else {
                        fixedQrCodeUrl = getQrCodeUrl(b2cFixedCode.getQrCodeNo());
                    }

					shopPerbiService.updateQrCode(fixedQrCodeUrl,merchantNo);
					
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg","二维码申请成功");
					hashMap.put("fixedQrCodeUrl", fixedQrCodeUrl);
					hashMap.put("fixedQrCodeFlag", Constants.CON_YES);
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("申请二维码:"+json.toString());
					response.getWriter().write(json.toString());
					return;
				}else{
					hashMap.put("rspCode", "1114");
					hashMap.put("rspMsg","二维码库存不足,请联系所属服务商");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("申请二维码:"+json.toString());
					response.getWriter().write(json.toString());
					return;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg","系统错误");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("生成固定二维码" + json.toString());
			response.getWriter().write(json.toString());
			return;
		}
	}
	
	/**
	 * 密钥处理
	 * @param qrCode
	 * @return
	 */
	public String getQrCodeUrl(String qrCode) {
		StringBuffer sBuffer=new StringBuffer();
		sBuffer.append(qrCode);
		sBuffer.append(ConstantsEnv.MERCHANTKEY);
		String smacs=Md5Encrypt.md5(sBuffer.toString());
		
		return ConstantsEnv.Fixed_Qr_Code_Url+"qrCode="+qrCode+"&mac="+smacs;
	}

	/**
	 * 商户密钥处理
	 * @param qrCode
	 * @return
	 */
	public String getMerQrCodeUrl(String qrCode) {
	    log.info("商户密钥处理");
		StringBuffer sBuffer=new StringBuffer();
		sBuffer.append("qrCode=" + qrCode);
		String smacs=Md5Encrypt.md5(sBuffer.toString());
		return ConstantsEnv.MER_FIXED_QR_CODE_URL+ "qrCode=" + qrCode+"&mac="+smacs;
	}


}
