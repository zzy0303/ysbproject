package com.uns.model;

import java.io.Serializable;
import java.util.Date;

public class B2cAgentBinder extends B2cTerminal implements Serializable {
    private String agentNo;

    private String termNo;

    private Date createDate;

    private String status;
    
    private String flag;
    
    private String agentscompany;
    
    private String num;
    public String getAgentNo() {
        return agentNo;
    }

    public void setAgentNo(String agentNo) {
        this.agentNo = agentNo;
    }

    public String getTermNo() {
        return termNo;
    }

    public void setTermNo(String termNo) {
        this.termNo = termNo;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getAgentscompany() {
		return agentscompany;
	}

	public void setAgentscompany(String agentscompany) {
		this.agentscompany = agentscompany;
	}

	public String getNum() {
		return num;
	}

	public void setNum(String num) {
		this.num = num;
	}
}