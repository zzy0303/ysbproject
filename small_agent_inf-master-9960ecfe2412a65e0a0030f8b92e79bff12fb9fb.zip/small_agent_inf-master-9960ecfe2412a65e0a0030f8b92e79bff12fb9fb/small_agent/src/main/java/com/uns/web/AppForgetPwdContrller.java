package com.uns.web;

import com.uns.common.Constants;
import com.uns.dao.B2cShopperValMapper;
import com.uns.model.B2cShopperVal;
import com.uns.model.B2cShopperbiTemp;
import com.uns.service.B2cShopperValService;
import com.uns.service.SendMessageService;
import com.uns.service.ShopPerbiService;
import com.uns.util.StringUtils;
import net.sf.json.JSONObject;
import org.apache.commons.lang.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 忘记密码
 *   临时表中有记录，就可以重新设置
 * 1.根据手机号码判断商户是否注册过。
 * 2.获取短信验证码。
 * 3.修改密码。
 *
 */
@Controller
@RequestMapping(value = "/appForgetPwd.htm")
public class AppForgetPwdContrller extends BaseController {

	
	@Autowired
	private ShopPerbiService shopPerbiService;
	
	@Autowired
	private SendMessageService sendMessageService;

	@Autowired
	private B2cShopperValService b2cShopperValService;

	
	/**验证手机号码是否存在，并返回短信验证码
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(params = "method=telvalidate")
	public void telvalidate(HttpServletRequest request,HttpServletResponse response) throws Exception {
		String tel = request.getParameter("tel") == null ? "" : request	.getParameter("tel");
		Map hashMap = new HashMap();
		try{
			if(StringUtils.isTrimNotEmpty(tel)){
				B2cShopperbiTemp b2cShopperbi=shopPerbiService.findbytel(tel);
				if(b2cShopperbi!=null){
				    //生成短信验证码
					String smsCode=RandomStringUtils.randomNumeric(6);
					b2cShopperbi.setSmsCode(smsCode);
					b2cShopperbi.setSmsCodeDate(new Date());
					sendMessageService.sendMessage(b2cShopperbi, smsCode, request);
					shopPerbiService.updateB2cShopperbiTempSmsCode(b2cShopperbi);
					hashMap.put("returnCode", "0000");
					hashMap.put("msg","成功");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("验证成功:" + json.toString());
					response.getWriter().write(json.toString());
				}else{
					//判断是否为裂变商户  如果为裂变商户则在B2cShopperVal表进行短信验证码修改 校验
					B2cShopperVal b2cShopperVal = new B2cShopperVal();
					b2cShopperVal.setTel(tel);
					List<B2cShopperVal> b2cShopperVals = b2cShopperValService.queryByParam(b2cShopperVal);
					if (null != b2cShopperVals && b2cShopperVals.size() > 0){
						b2cShopperVal = b2cShopperVals.get(0);

						if (StringUtils.isTrimNotEmpty(b2cShopperVal.getInviteCodeP())||StringUtils.isTrimNotEmpty(b2cShopperVal.getPassword())){
							b2cShopperbi = new B2cShopperbiTemp();
							b2cShopperbi.setStel(tel);
							//生成短信验证码
							String smsCode=RandomStringUtils.randomNumeric(6);
							sendMessageService.sendMessage(b2cShopperbi, smsCode, request);

							b2cShopperVal.setSmsCode(smsCode);
							b2cShopperVal.setSmsCodeDate(new Date());
							b2cShopperValService.editByParam(b2cShopperVal);

							hashMap.put("returnCode", "0000");
							hashMap.put("msg","成功");
							response.setContentType("UTF-8");
							JSONObject json = JSONObject.fromObject(hashMap);
							log.info("验证成功:" + json.toString());
							response.getWriter().write(json.toString());
							return;
						}
					}

					hashMap.put("returnCode", "1111");
					hashMap.put("msg","该手机号，未注册");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("该手机号未注册:" + json.toString());
					response.getWriter().write(json.toString());
				}
			}else{
				hashMap.put("returnCode", "3333");
				hashMap.put("msg","手机号码为空");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("手机号码为空:" + json.toString());
				response.getWriter().write(json.toString());
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("returnCode", "2222");
			hashMap.put("msg","手机号验证用户是否存在报错");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("手机号验证用户是否存在报错:" + json.toString());
			response.getWriter().write(json.toString());
		}
		
	}
	
	
	/**验证短信验证码，是否正确
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(params = "method=validateSmsCode")
	public void validateSmsCode(HttpServletRequest request,HttpServletResponse response) throws Exception {
		String tel = request.getParameter("tel") == null ? "" : request	.getParameter("tel");
		String smsCode = request.getParameter("smsCode") == null ? "" : request	.getParameter("smsCode");
		Map hashMap = new HashMap();
	    try {
			if(StringUtils.isEmpty(tel)){
				hashMap.put("returnCode", "3331");
				hashMap.put("msg","手机号码为空");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("手机号码为空:" + json.toString());
				response.getWriter().write(json.toString());
			}else if(StringUtils.isEmpty(smsCode)){
				hashMap.put("returnCode", "3332");
				hashMap.put("msg","短信验证码为空");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("短信验证码为空:" + json.toString());
				response.getWriter().write(json.toString());
			}else{
				B2cShopperbiTemp b2cShopperbi=shopPerbiService.findbytel(tel);
				if(b2cShopperbi!=null){
					if(smsCode.equals(b2cShopperbi.getSmsCode())){
						Date curDtae=new Date();
					    Long datetime=curDtae.getTime()-b2cShopperbi.getSmsCodeDate().getTime();
						if(datetime> Constants.TIME_TEN){
							hashMap.put("returnCode", "1113");
							hashMap.put("msg","短信验证码过期");
							response.setContentType("UTF-8");
							JSONObject json = JSONObject.fromObject(hashMap);
							log.info("短信验证码过期:" + json.toString());
							response.getWriter().write(json.toString());
						}else{
							hashMap.put("returnCode", "0000");
							hashMap.put("msg","短信验证码成功");
							response.setContentType("UTF-8");
							JSONObject json = JSONObject.fromObject(hashMap);
							log.info("验证短信验证码:" + json.toString());
							response.getWriter().write(json.toString());
						}
					}else{
						hashMap.put("returnCode", "1112");
						hashMap.put("msg","短信验证码错误");
						response.setContentType("UTF-8");
						JSONObject json = JSONObject.fromObject(hashMap);
						log.info("短信验证码错误:" + json.toString());
						response.getWriter().write(json.toString());
					}
				}else{
					//判断是否为裂变商户  如果为裂变商户则在B2cShopperVal表进行短信验证码修改 校验
					B2cShopperVal b2cShopperVal = new B2cShopperVal();
					b2cShopperVal.setTel(tel);
					List<B2cShopperVal> b2cShopperVals = b2cShopperValService.queryByParam(b2cShopperVal);
					if (null != b2cShopperVals && b2cShopperVals.size() > 0){
						b2cShopperVal = b2cShopperVals.get(0);
						if (StringUtils.isTrimNotEmpty(b2cShopperVal.getInviteCodeP()) || StringUtils.isTrimNotEmpty(b2cShopperVal.getPassword())){
							//为裂变商户
							if(smsCode.equals(b2cShopperVal.getSmsCode())){
								Date curDtae=new Date();
								Long datetime=curDtae.getTime()-b2cShopperVal.getSmsCodeDate().getTime();
								if(datetime> Constants.TIME_TEN){
									hashMap.put("returnCode", "1113");
									hashMap.put("msg","短信验证码过期");
									response.setContentType("UTF-8");
									JSONObject json = JSONObject.fromObject(hashMap);
									log.info("短信验证码过期:" + json.toString());
									response.getWriter().write(json.toString());
									return;
								}else{
									hashMap.put("returnCode", "0000");
									hashMap.put("msg","短信验证码成功");
									response.setContentType("UTF-8");
									JSONObject json = JSONObject.fromObject(hashMap);
									log.info("验证短信验证码:" + json.toString());
									response.getWriter().write(json.toString());
									return;
								}
							}else{
								hashMap.put("returnCode", "1112");
								hashMap.put("msg","短信验证码错误");
								response.setContentType("UTF-8");
								JSONObject json = JSONObject.fromObject(hashMap);
								log.info("短信验证码错误:" + json.toString());
								response.getWriter().write(json.toString());
								return;
							}
						}
					}

					hashMap.put("returnCode", "1111");
					hashMap.put("msg","该手机号，未注册");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("验证短信验证码：该手机号未注册:" + json.toString());
					response.getWriter().write(json.toString());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("returnCode", "2222");
			hashMap.put("msg","短信验证码出错");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("验证短信验证码出错:" + json.toString());
			response.getWriter().write(json.toString());
		}
	
	}
	
	
}
