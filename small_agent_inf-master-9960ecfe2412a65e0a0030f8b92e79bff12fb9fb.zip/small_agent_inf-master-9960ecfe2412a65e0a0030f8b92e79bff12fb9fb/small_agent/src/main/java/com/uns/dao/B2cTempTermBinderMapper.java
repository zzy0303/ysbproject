package com.uns.dao;


import com.uns.model.B2cTempTermBinder;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;


@Repository
public interface B2cTempTermBinderMapper {

    int insert(B2cTempTermBinder record);
//
//    int insertSelective(B2cTermBinder record);
//
//
//    int deleteByShopperId(String shopperId);
//
	List<HashMap> selectTempBinderList(String shopperId);
	//更加termNo查询绑定表
	B2cTempTermBinder selectByTempBinder(String termNo);
	//修改绑定表中得status
	void updateTermBinder(B2cTempTermBinder record);
	
	void deleteByTermno(String termNo);
	
	void deleteByMerchantNo(String MerchantNo);
	
	List<HashMap> selectNewBinder(String shoppId);
    
}