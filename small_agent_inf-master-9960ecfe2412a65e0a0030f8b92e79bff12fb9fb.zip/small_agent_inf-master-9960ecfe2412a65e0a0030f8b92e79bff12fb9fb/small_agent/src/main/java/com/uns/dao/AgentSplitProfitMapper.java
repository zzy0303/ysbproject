package com.uns.dao;

import com.uns.model.AgentSplitProfit;
import com.uns.web.form.SplitForm;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Repository
public interface AgentSplitProfitMapper {
    int deleteByPrimaryKey(BigDecimal id);

    AgentSplitProfit selectByPrimaryKey(BigDecimal id); 

    List<Map<String,Object>> selectSplitList(SplitForm param);

	List<Map<String, Object>> selectSmSplitList(SplitForm sform);
}