package com.uns.dao;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.IdCardArea;
@Repository
public interface IdCardAreaMapper {


    int insert(IdCardArea record);

    int insertSelective(IdCardArea record);
    
    IdCardArea selectByCounty(String county);
}