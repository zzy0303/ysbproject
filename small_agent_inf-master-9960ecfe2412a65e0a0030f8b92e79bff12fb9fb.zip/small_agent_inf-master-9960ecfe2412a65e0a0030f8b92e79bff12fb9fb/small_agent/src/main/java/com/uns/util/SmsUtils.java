package com.uns.util;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class SmsUtils {
	/**
	 * 根据map转换成string
	 * @param map
	 * @return
	 */
	public static String convertMap2String(Map map) {
		StringBuffer params = new StringBuffer();
		if(map != null) {
			Set keySet = map.keySet();
			if(keySet != null) {
				Iterator it = keySet.iterator();
				while(it.hasNext()) {
					String key = (String)it.next();
					params.append("&");
					params.append(key);
					params.append("=");
					params.append(map.get(key));
				}
			}
		}
		params.replace(0, 1, "?");
		return params.toString();
	}
}
