package com.uns.dao;

import com.uns.model.Area;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface AreaMapper {
	/**
	 * 查询区域
	 */
	public List<Area> searchArea();
	
	/**
	 * 查询省份
	 */
	public List searchProvince();

	/**
	 * 查询城市
	 * @param city
	 */
	public List searchCity(Area area);
	/**
	 * 查询省份
	 * @param sql
	 * @return
	 */
	public List searchProvincial(Area area);
	
	/**
	 * 查询单个省份 
	 */
	public Area searchBankProvince(String provincial);
	
	
	List findcityname(Map map);
	 List findcity(String cityname);
	List findbyname(Map map);
	List findbyareaid(Map map);
	Area findPayeeBankProvinceAndCity(String cityCode);
	
	Area findByCityAndProvince(Map cityAndProvince);
	
	Area findByProvinceOtherCity(String provincialname);
}
