package com.uns.web;

import com.uns.service.B2cShopperbiShareService;
import net.sf.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;

/**
 * 商户分享推送
 * Created by Administrator on 2017/6/21.
 */
@Controller
@RequestMapping(value = "/appShare.htm")
public class AppShareController {

    private Logger log = LoggerFactory.getLogger(AppShareController.class);

    @Autowired
    private B2cShopperbiShareService b2cShopperbiShareService;

    /**
     * 商户分享推送汇总
     * @param request
     * @param response
     */
    @RequestMapping(params = "method=collectShareOper")
    public void collectShareOper(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("UTF-8");
        HashMap hashMap = b2cShopperbiShareService.collectShareOper(request);
        JSONObject json = JSONObject.fromObject(hashMap);
        log.info("商户分享推送汇总：{}",json.toString());
        response.getWriter().write(json.toString());
    }

    /**
     * 商户分享推送
     * @param request
     * @param response
     */
    @RequestMapping(params = "method=shareOperator")
    public void shareOperator(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("UTF-8");
        response.setHeader("Access-Control-Allow-Origin","*");
        response.setHeader("Access-Control-Allow-Methods","GET,POST");
        HashMap hashMap = b2cShopperbiShareService.shareOperator(request);
        JSONObject json = JSONObject.fromObject(hashMap);
        log.info("商户分享推送:"+json.toString());
        response.getWriter().write(json.toString());
    }
}
