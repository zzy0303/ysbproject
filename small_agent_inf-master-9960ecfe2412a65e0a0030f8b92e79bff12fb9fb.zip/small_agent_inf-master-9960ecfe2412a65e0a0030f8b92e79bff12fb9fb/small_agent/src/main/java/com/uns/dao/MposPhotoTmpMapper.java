package com.uns.dao;

import com.uns.model.MposPhotoTmp;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface MposPhotoTmpMapper {


    int deleteByPrimaryKey(String identityid);

    int insert(MposPhotoTmp record);

    int insertSelective(MposPhotoTmp record);

    MposPhotoTmp selectByPrimaryKey(BigDecimal photoId);

    int updateByPrimaryKeySelective(MposPhotoTmp record);

    int updateByPrimaryKey(MposPhotoTmp record);
    
    int updatePhotoTmpById(MposPhotoTmp record);
    
    List findbysid(String sid);
    
    MposPhotoTmp findbyphotoid(String photoId);

	void updatePhotoTmpByIdNo(MposPhotoTmp photo);

    MposPhotoTmp selectByIdNo(String identityid);
    int deleteByAggMerTmp(String identityid);

    List findByAggsid(String sid);

    MposPhotoTmp selectByMerIdNo(String identityid);
}