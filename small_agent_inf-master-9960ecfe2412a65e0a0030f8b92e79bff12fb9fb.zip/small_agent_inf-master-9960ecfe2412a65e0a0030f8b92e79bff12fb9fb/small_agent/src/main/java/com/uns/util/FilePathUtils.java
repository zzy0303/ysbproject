package com.uns.util;

import javax.servlet.http.HttpServletRequest;
import java.io.File;

/**
 * @author yang.liu01
 *
 */
public class FilePathUtils {

	/**
	 * 
	 * @param request
	 * @param folder1      文件夹1
	 * @param folder2      文件夹2
	 * @param fileName 文件名称
	 * @return 需要的文件路径
	 */
	public static String getContextPath(HttpServletRequest request,String folder1,String folder2,String fileName) {
		String resultPath =request.getSession().getServletContext().getRealPath("/")
				+folder1+File.separator+folder2+File.separator+fileName ;
		
		
		return resultPath;
	}
}
