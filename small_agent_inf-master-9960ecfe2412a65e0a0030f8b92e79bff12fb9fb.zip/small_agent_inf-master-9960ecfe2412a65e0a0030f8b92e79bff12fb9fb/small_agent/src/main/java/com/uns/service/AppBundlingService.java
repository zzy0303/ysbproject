package com.uns.service;

import com.uns.common.Constants;
import com.uns.dao.B2cTermBinderMapper;
import com.uns.dao.TerminalHistoryMapper;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.B2cTermBinder;
import com.uns.model.TerminalHistory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class AppBundlingService {
	
	@Autowired
	private B2cTermBinderMapper b2cTermBinderMapper;
	
	@Autowired
	private TerminalHistoryMapper terminalHistoryMapper;
	
	

	public B2cTermBinder findB2cTermBinderByTermNo(String TermNo) {
		return b2cTermBinderMapper.findB2cTermBinderByTermNo(TermNo);
	}

	/**
	 * @param shopperid
	 * @param termno
	 */
	public void updateTermBinder(B2cShopperbiTemp shopper, B2cTermBinder termno) {
		
		termno.setUpdate_date(new Date());
		termno.setUpdate_user(shopper.getShopperid()==null?"":shopper.getShopperid().toString());
		termno.setMerchantNo(shopper.getShopperid()==null?"":shopper.getShopperid().toString());
		termno.setStatus(Constants.CON_NO);
		termno.setAgent_no(shopper.getShopperidP()==null?"":shopper.getShopperidP().toString());
		termno.setBinder_date(new Date());
		termno.setBinder_user(shopper.getShopperid()==null?"":shopper.getShopperid().toString());
		
		TerminalHistory  terminalHistory=new TerminalHistory();
		terminalHistory.setCreateDate(new Date());
		terminalHistory.setCreateUser(shopper.getShopperid()==null?"":shopper.getShopperid().toString());
		terminalHistory.setStatus(Constants.STATUS3);
		terminalHistory.setTermNo(termno.getTermNo());
		
		updateOrInsert(termno,terminalHistory);
		
	}

	private void updateOrInsert(B2cTermBinder termno,
			TerminalHistory terminalHistory) {
		b2cTermBinderMapper.updateBundling(termno);
		terminalHistoryMapper.insertSelective(terminalHistory);
	}
	

}
