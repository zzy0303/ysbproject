package com.uns.dao;

import com.uns.web.form.AgentRechargeForm;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface OrderInfoMapper {
	List<Map<String,String>> selectRechargeList(Map<String, Object> param);
	//刷卡总计
	Map selectRechargeListSum(Map<String, Object> param);
	
	List<Map<String,String>> selectWithdrawList(Map<String, Object> param);
	
	//T0提现总计
   Map selectWithdrawListSum(Map<String, Object> param);
		
	int judgeShopper(Map<String, Object> map);
	
	List<String> selectYsbno(Long shopperidp);
	
	List<String> selectYsbnoByAmount(Map<String, Object> param);
	//充值记录查询下载
	List findRechargePageList(AgentRechargeForm arForm);
	
	Map findRechargeById(String orderId);
	    
	List<Map<String,String>> selectD0Time();
}