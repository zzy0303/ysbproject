package com.uns.model;

public class Area {
	private String zonecode;
	private String zonename;
	private String provincial;
	private String provincialname;
	private String city;
	private String cityname;
	private String status;
	private Long areaid;
	private String shProvincial;//睿付开户行省份编码
	private String shCity;//睿付开户行城市编码
	
	public String getShProvincial() {
		return shProvincial;
	}
	public void setShProvincial(String shProvincial) {
		this.shProvincial = shProvincial;
	}
	public String getShCity() {
		return shCity;
	}
	public void setShCity(String shCity) {
		this.shCity = shCity;
	}
	
	public String getZonecode() {
		return zonecode;
	}
	public void setZonecode(String zonecode) {
		this.zonecode = zonecode;
	}
	public String getZonename() {
		return zonename;
	}
	public void setZonename(String zonename) {
		this.zonename = zonename;
	}
	public String getProvincial() {
		return provincial;
	}
	public void setProvincial(String provincial) {
		this.provincial = provincial;
	}
	public String getProvincialname() {
		return provincialname;
	}
	public void setProvincialname(String provincialname) {
		this.provincialname = provincialname;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCityname() {
		return cityname;
	}
	public void setCityname(String cityname) {
		this.cityname = cityname;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Long getAreaid() {
		return areaid;
	}
	public void setAreaid(Long areaid) {
		this.areaid = areaid;
	}
	
}
