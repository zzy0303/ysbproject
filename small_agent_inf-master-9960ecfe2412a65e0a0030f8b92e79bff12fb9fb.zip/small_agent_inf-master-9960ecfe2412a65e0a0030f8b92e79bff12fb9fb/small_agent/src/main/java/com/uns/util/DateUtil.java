package com.uns.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtil {

	
	/**根据当前日期算出2天后的时间
	 * @param date
	 * @param i
	 * @return
	 * @throws ParseException
	 */
	public final static Date calculateDate(Date date, int i) throws ParseException {
		  SimpleDateFormat sdf =   new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss" );
		  Calendar cal = Calendar.getInstance(); 
		  cal.setTime(date); 
		  cal.add(Calendar.DATE, i);
		  cal.set(Calendar.HOUR_OF_DAY, 23);
		  cal.set(Calendar.MINUTE, 59);
		  cal.set(Calendar.SECOND, 59);
		  Date dates=sdf.parse(sdf.format(cal.getTime()));
		  return dates;
	}

	
	
	 /**将时间转化成对应格式的字符串
	 * @param date
	 * @param format
	 * @return
	 */
	public static final String date2String(Date date, String format) {
	        if (date == null) {
	            return "";
	        }
	        DateFormat df = new SimpleDateFormat(format);
	        return df.format(date);
	}
	
	
	public static String getTypeDate(Date datess, String type) {
		SimpleDateFormat str = new SimpleDateFormat(type);
		String strDates = str.format(datess);
		return strDates;
	}
	/**
	 * 日期格式
	 * 
	 */
	public static String getDateType(Date date,String type){
		SimpleDateFormat str=new SimpleDateFormat(type);
		String strDates=str.format(date);
		return strDates;
		
	}
}
