package com.uns.dao;

import com.uns.model.AgentMcc;
import com.uns.model.AgentSplit;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface AgentMccMapper {
	
	List searchAgentMccList(String agentId);

	AgentMcc findAgentMcc(Long amid);

	List<Map> isMcc(Long agentidP);

	List<Map> isMccTmp(Long agentidP);

	List<AgentSplit> findAgentMcc6(Long agentid);
	
	List<AgentMcc> findAgentMccMccid(Long agentid);

	List<AgentMcc> findAgentMccTmpMccid(Long agentid);
	
	AgentMcc findAgentMccTmp(Long amid);
	AgentMcc findAgentMccTmp2(Long amid);

	Long findAgentMccSq();
	
	Map searchAgentMccById(Long amid);

	List findAgentMccTmpBySgentId(Long editAgentid);

	List<AgentMcc> findAgentMccByAgentid(Long agentid);

	List<AgentMcc> findAgentMccTmpByAgentid(Long agentid);
	
}
