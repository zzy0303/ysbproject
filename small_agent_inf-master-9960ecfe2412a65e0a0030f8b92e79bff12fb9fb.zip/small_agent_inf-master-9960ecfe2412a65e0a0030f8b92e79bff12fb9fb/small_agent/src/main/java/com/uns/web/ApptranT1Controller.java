package com.uns.web;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.model.B2cShopperbi;
import com.uns.service.RecordService;
import com.uns.util.HttpClientUtils;
import com.uns.util.Md5Encrypt;
import com.uns.util.ToolsUtils;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * t1结算数据查询
 *
 */
@Controller
@RequestMapping(value = "/apptranT1")
public class ApptranT1Controller extends BaseController {
	
	@Autowired
	private RecordService recordService;
	
	/**查询t1结算列表
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="t_1.htm",method=RequestMethod.POST)
	public void findTranT1List(HttpServletRequest request,HttpServletResponse response) throws IOException{
		Map hashMap = new HashMap(); 
		response.setContentType("UTF-8");
		String merchantId=request.getParameter("merchantId");
		String page=request.getParameter("page");
		String pageSize=request.getParameter("pageSize");
		String minAmount=request.getParameter("minAmount");
		String maxAmount=request.getParameter("maxAmount");
		String startTime=request.getParameter("startTime");
		String endTime=request.getParameter("endTime");
		String mac=request.getParameter("mac");
		try {
			//验证参数是否为空
			if(StringUtils.isEmpty(merchantId)||StringUtils.isEmpty(page)||StringUtils.isEmpty(pageSize)||StringUtils.isEmpty(mac)){
				response.getWriter().write(ToolsUtils.errorMsg("11110001"));
				return ;
			}
			B2cShopperbi b2cShopperbi = recordService.findFactoringNoByShopperid(merchantId);
			//如果根据商户号查不到商户信息
			if(b2cShopperbi==null){
				response.getWriter().write(ToolsUtils.errorMsg("11110005"));
				return;
			}
			//如果查到的商户没有银生宝账号
			if(StringUtils.isEmpty(b2cShopperbi.getYsbNo())){
				response.getWriter().write(ToolsUtils.errorMsg("11110010"));
				return;
			}
			if(!valMac(merchantId,page,pageSize,minAmount,maxAmount,startTime,endTime,b2cShopperbi,mac)){
				response.getWriter().write(ToolsUtils.errorMsg("11110003"));
				return;
			}
			String requestStr=getRequestStr(merchantId,page,pageSize,minAmount,maxAmount,startTime,endTime,b2cShopperbi);
			log.info("请求："+ ConstantsEnv.T1_TRAN_LIST_URL+"   "+requestStr);
			String record = HttpClientUtils.REpostRequestStr(ConstantsEnv.T1_TRAN_LIST_URL, requestStr);
			log.info("响应："+record);
			JSONObject  json = JSONObject.fromObject(record);
			json.put("rspMsg", Constants.mapReturnMsg.get(json.get("rspCode")));
			log.info("查询结果："+json.toString());
			response.getWriter().write(json.toString());
			
			
		} catch (Exception e) {
			e.printStackTrace();
			response.getWriter().write(ToolsUtils.errorMsg("11110002"));
		}
		
		
		
	}

	/**请求到mpos功能平台
	 * @param merchantId
	 * @param page
	 * @param pageSize
	 * @param minAmount
	 * @param maxAmount
	 * @param startTime
	 * @param endTime
	 * @param b2cShopperbi
	 * @return
	 */
	private String getRequestStr(String merchantId, String page,
			String pageSize, String minAmount, String maxAmount,
			String startTime, String endTime, B2cShopperbi b2cShopperbi) {
		StringBuffer buffer=new StringBuffer();
		buffer.append("userId="+b2cShopperbi.getYsbNo());
		buffer.append("&page="+page);
		buffer.append("&pageSize="+pageSize);
		if(StringUtils.isNotEmpty(minAmount)){
			buffer.append("&minAmount="+minAmount);
		}
		if(StringUtils.isNotEmpty(maxAmount)){
			buffer.append("&maxAmount="+maxAmount);
		}
		if(StringUtils.isNotEmpty(startTime)){
			buffer.append("&startTime="+startTime);
		}
		if(StringUtils.isNotEmpty(endTime)){
			buffer.append("&endTime="+endTime);
		}
		return buffer.toString();
	}

	
	/**mac验证
	 * @param merchantId
	 * @param page
	 * @param pageSize
	 * @param minAmount
	 * @param maxAmount
	 * @param startTime
	 * @param endTime
	 * @param b2cShopperbi
	 * @param mac
	 * @return
	 */
	private boolean valMac(String merchantId, String page, String pageSize,
			String minAmount, String maxAmount, String startTime,
			String endTime, B2cShopperbi b2cShopperbi, String mac) {
		StringBuffer buffer=new StringBuffer();
		buffer.append("merchantId="+merchantId);
		buffer.append("&page="+page);
		buffer.append("&pageSize="+pageSize);
		buffer.append("&minAmount="+minAmount);
		buffer.append("&maxAmount="+maxAmount);
		buffer.append("&startTime="+startTime);
		buffer.append("&endTime="+endTime);
		buffer.append("&merchantKey="+b2cShopperbi.getMerchantKey());
		//logger.info("mac: 加密前："+buffer.toString()+"加密后："+Md5Encrypt.md5(buffer.toString()).toLowerCase());
		return mac.equalsIgnoreCase(Md5Encrypt.md5(buffer.toString()).toLowerCase());
	}

}
