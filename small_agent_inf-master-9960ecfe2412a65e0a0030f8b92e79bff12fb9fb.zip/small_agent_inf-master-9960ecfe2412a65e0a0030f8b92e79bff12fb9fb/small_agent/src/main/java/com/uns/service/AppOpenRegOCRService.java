package com.uns.service;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uns.dao.*;
import com.uns.model.*;
import com.uns.util.*;
import oracle.jdbc.driver.Const;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.uns.bean.BankCardValBean;
import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.myenum.MessageEnum;

/**
 * OCR 处理service
 *
 * @author Administrator
 */
@Service
public class AppOpenRegOCRService {

    @Autowired
    private AcmsMapUtils acmsMapUtils;

    @Autowired
    AppOpenRegService appOpenRegService;

    @Autowired
    B2cShopperValMapper b2cShopperValMapper;

    @Autowired
    private MposPhotoMapper mposPhotoMapper;

    @Autowired
    private MposPhotoTmpMapper mposPhotoTmpMapper;

    @Autowired
    private IdCardAreaMapper idCardAreaMapper;

    @Autowired
    private AreaMapper areaMapper;

    @Autowired
    private B2cDictMapper dictMapper;

    @Autowired
    private MposMerchantFeeMapper mposMerchantFeeMapper;

    @Autowired
    private UsersMapper usersMapper;

    @Autowired
    private B2cShopperbiMapper b2cShopperbiMapper;

    @Autowired
    private B2cShopperbiTempMapper b2cShopperbiTempMapper;

    @Autowired
    private SweepCodeProductMapper sweepCodeProductMapper;

    @Autowired
    private ReportHFAndHK reportHFandHK;

    @Autowired
    private RegMposAndQrcode regMposAndQrcode;

    private Logger Log = LoggerFactory.getLogger(AppOpenRegService.class);

    private ISO8583Packager pack = new ISO8583Packager();


    /**
     * 上传身份证2.3.0
     *
     * @throws Exception
     */

    public HashMap uploadIdCardInfo(HttpServletRequest request) throws Exception {

        //返回处理结果的hashMap
        HashMap hashMap = new HashMap();

        HashMap areaMap = null;

        B2cShopperbiTemp b2cShopperbiTemp = null;

        String IDNo = AesEncrypt.decryptAES(request.getParameter("IDNo") == null ? "" : request.getParameter("IDNo"), ConstantsEnv.APP_AES_KEY);
        String name = request.getParameter("name") == null ? "" : request.getParameter("name");
        String sex = request.getParameter("sex") == null ? "" : request.getParameter("sex");
        String birthday = request.getParameter("birthday") == null ? "" : request.getParameter("birthday");
        String nation = request.getParameter("nation") == null ? "" : request.getParameter("nation");
        String saddress = request.getParameter("saddress") == null ? "" : request.getParameter("saddress");
        String signUnit = request.getParameter("signUnit") == null ? "" : request.getParameter("signUnit");
        String usefulLife = request.getParameter("usefulLife") == null ? "" : request.getParameter("usefulLife");
        String stel = request.getParameter("stel") == null ? "" : request.getParameter("stel");

        Log.info("请求参数" + request.getQueryString());
        List oldB2cShopperbiList = b2cShopperbiMapper.findbyid(IDNo);//根据身份证号查询到正式商户信息
        if (null != oldB2cShopperbiList && oldB2cShopperbiList.size() > Constants.INT_0) {//正式表中有信息不允许注册
            hashMap.put(Constants.RSP_CODE, MessageEnum.身份证号已被注册.getCode());
            hashMap.put(Constants.RSP_MSG, MessageEnum.身份证号已被注册.getText());
            return hashMap;
        } else {//正式表中没有信息，删除预约信息
            List oldB2cShopperbiTempList = b2cShopperbiTempMapper.findbysid(IDNo);
            if (null != oldB2cShopperbiTempList && oldB2cShopperbiTempList.size() > 0) {
                b2cShopperbiTempMapper.deleteByIdCard(IDNo);
            }
        }

        String idCardTopSix = IDNo.substring(0, 6);
        areaMap = getAreaByIdCardTopSix(idCardTopSix);

        b2cShopperbiTemp = new B2cShopperbiTemp();
        b2cShopperbiTemp.setIDNo(IDNo);
        b2cShopperbiTemp.setName(name);
        b2cShopperbiTemp.setSex(sex);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date birthdate = sdf.parse(birthday);
        b2cShopperbiTemp.setBirthday(birthdate);
        b2cShopperbiTemp.setNation(nation);
        b2cShopperbiTemp.setSaddress(saddress);
        b2cShopperbiTemp.setSignUnit(signUnit);
        b2cShopperbiTemp.setUsefulLife(solveUsefullife(usefulLife));
        b2cShopperbiTemp.setSprovince((String) areaMap.get("sprovince"));
        b2cShopperbiTemp.setScity((String) areaMap.get("scity"));
        b2cShopperbiTemp.setStel(stel);
        b2cShopperbiTemp.setProvince((String) areaMap.get("province"));
        b2cShopperbiTemp.setCity((String) areaMap.get("city"));
        b2cShopperbiTemp.setMerchantType(Constants.TYPE_0); //实名个人用户

        B2cShopperbiTemp oldB2cShopperbiTemp = b2cShopperbiTempMapper.findBySid(IDNo);//根据身份证查询到商户信息

        b2cShopperbiTempMapper.deleteByStel(stel);//根据手机号删除商户
        if (null != oldB2cShopperbiTemp) {
            mposMerchantFeeMapper.deleteByshopperid(oldB2cShopperbiTemp.getShopperid());//根据商户号删除商户费率
            mposMerchantFeeMapper.deleteTempByshopperid(oldB2cShopperbiTemp.getShopperid());//删除预约费率
            Long photoid = oldB2cShopperbiTemp.getPhotoid();
            if (null != photoid) {
                mposPhotoMapper.deleteByPrimaryKey(BigDecimal.valueOf(photoid));
                mposPhotoTmpMapper.deleteByPrimaryKey(IDNo);
            }
        }
        Long shopperid = Long.valueOf(appOpenRegService.getPosShopperId((String) areaMap.get("city"), Constants.CON_MCC));//生成小商户号
        b2cShopperbiTemp.setShopperid(shopperid);
        b2cShopperbiTemp.setCreated(new Date());//创建时间
        b2cShopperbiTemp.setNotPassStep(Constants.NOT_PASS_STEP_ID_CARD);//OCR错误步骤（上传了身份证）
        b2cShopperbiTempMapper.insertSelective(b2cShopperbiTemp);

        hashMap.put(Constants.RSP_CODE, MessageEnum.成功.getCode());
        hashMap.put(Constants.RSP_MSG, MessageEnum.成功.getText());
        return hashMap;
    }

    /**
     * 身份证补件
     *
     * @param request
     * @return
     */
    public HashMap updateIdCardInfo(HttpServletRequest request) throws Exception {
        //返回处理结果的hashMap
        HashMap hashMap = new HashMap();
        HashMap areaMap = null;
        B2cShopperbiTemp b2cShopperbiTemp = null;

        String IDNo = AesEncrypt.decryptAES(request.getParameter("IDNo") == null ? "" : request.getParameter("IDNo"), ConstantsEnv.APP_AES_KEY);
        String name = request.getParameter("name") == null ? "" : request.getParameter("name");
        String sex = request.getParameter("sex") == null ? "" : request.getParameter("sex");
        String birthday = request.getParameter("birthday") == null ? "" : request.getParameter("birthday");
        String nation = request.getParameter("nation") == null ? "" : request.getParameter("nation");
        String saddress = request.getParameter("saddress") == null ? "" : request.getParameter("saddress");
        String signUnit = request.getParameter("signUnit") == null ? "" : request.getParameter("signUnit");
        String usefulLife = request.getParameter("usefulLife") == null ? "" : request.getParameter("usefulLife");
        String stel = request.getParameter("stel") == null ? "" : request.getParameter("stel");

        Log.info("请求参数" + request.getQueryString());

        B2cShopperbiTemp oldB2cShopperbiTemp = b2cShopperbiTempMapper.findBySid(IDNo);//根据身份证查询到商户信息
        if (null == oldB2cShopperbiTemp) {
            hashMap.put(Constants.RSP_CODE, MessageEnum.商户不存在.getCode());
            hashMap.put(Constants.RSP_MSG, MessageEnum.商户不存在.getText());
            return hashMap;
        }

        String idCardTopSix = IDNo.substring(0, 6);
        areaMap = getAreaByIdCardTopSix(idCardTopSix);

        b2cShopperbiTemp = new B2cShopperbiTemp();
        b2cShopperbiTemp.setIDNo(IDNo);
        b2cShopperbiTemp.setName(name);
        b2cShopperbiTemp.setSex(sex);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date birthdate = sdf.parse(birthday);
        b2cShopperbiTemp.setBirthday(birthdate);
        b2cShopperbiTemp.setNation(nation);
        b2cShopperbiTemp.setSaddress(saddress);
        b2cShopperbiTemp.setSignUnit(signUnit);
        b2cShopperbiTemp.setUsefulLife(solveUsefullife(usefulLife));
        b2cShopperbiTemp.setSprovince((String) areaMap.get("sprovince"));
        b2cShopperbiTemp.setScity((String) areaMap.get("scity"));
        b2cShopperbiTemp.setStel(stel);
        b2cShopperbiTemp.setProvince((String) areaMap.get("province"));
        b2cShopperbiTemp.setCity((String) areaMap.get("city"));

        //错误步骤记录
        String oldNotPassStep = null;
        oldNotPassStep = oldB2cShopperbiTemp.getNotPassStep();
        oldNotPassStep = com.uns.util.StringUtils.replaceIndex(Constants.INT_0, oldNotPassStep, Constants.TYPE_1);
        //更新错误步骤记录
        b2cShopperbiTemp.setNotPassStep(oldNotPassStep);
        //如果错误步骤全部重新提交，那么设置商户审核状态为人工审核中
        if (!oldNotPassStep.contains(Constants.TYPE_0)) {
            b2cShopperbiTemp.setCheckstatus(Constants.TYPE_4);
        }
        b2cShopperbiTemp.setShopperid(oldB2cShopperbiTemp.getShopperid());
        b2cShopperbiTemp.setUpdated(new Date());
        //更新身份证信息
        b2cShopperbiTempMapper.updateOCRIdCardInfo(b2cShopperbiTemp);

        hashMap.put(Constants.RSP_CODE, MessageEnum.成功.getCode());
        hashMap.put(Constants.RSP_MSG, MessageEnum.成功.getText());
        return hashMap;
    }

    /**
     * 处理身份证有效期（加点）
     *
     * @param oriUsefullife
     * @return
     */
    private String solveUsefullife(String oriUsefullife) {
        return oriUsefullife.substring(0, 4) + "." + oriUsefullife.substring(4, 6) + "." + oriUsefullife.substring(6, 8) + "-" +
                oriUsefullife.substring(9, 13) + "." + oriUsefullife.substring(13, 15) + "." + oriUsefullife.substring(15, 17);
    }

    /**
     * 根据身份证号前6位获取省市信息放入param
     *
     * @param idCardTopSix
     */
    public HashMap getAreaByIdCardTopSix(String idCardTopSix) {
        HashMap hashMap = new HashMap();
        //根据省份和城市名称找到对应的编码（要改为身份证前6位匹配）
        Map proAndCityMap = new HashMap();
        //查询身份证号前六位对应省市名称
        IdCardArea idCardArea = idCardAreaMapper.selectByCounty(idCardTopSix);
        String provinceName = idCardArea.getProvincialname();
        String cityName = idCardArea.getCityname();
        proAndCityMap.put("province", provinceName);
        proAndCityMap.put("city", cityName);
        hashMap.put("sprovince", provinceName);
        hashMap.put("scity", cityName);
        //查询地区表，找到对应省市编码
        Area area = areaMapper.findByCityAndProvince(proAndCityMap);
        if (null == area) {
            area = areaMapper.findByProvinceOtherCity(provinceName);
        }
        String city = area.getCity();
        String province = area.getProvincial();
        hashMap.put("province", province);
        hashMap.put("city", city);
        return hashMap;
    }

    /**
     * 上传结算卡（借记卡）信息
     *
     * @param request
     * @return
     */
    public HashMap uploadDebitCardInfo(HttpServletRequest request) {
        HashMap hashMap = new HashMap();
        String IDNo = AesEncrypt.decryptAES(request.getParameter("IDNo") == null ? "" : request.getParameter("IDNo"), ConstantsEnv.APP_AES_KEY);
        String accountbankclientname = request.getParameter("accountbankclientname") == null ? "" : request.getParameter("accountbankclientname");
        String accountBankClientTel = request.getParameter("accountBankClientTel") == null ? "" : request.getParameter("accountBankClientTel");
        String accountbankno = AesEncrypt.decryptAES(request.getParameter("accountbankno") == null ? "" : request.getParameter("accountbankno"), ConstantsEnv.APP_AES_KEY);
        String headOfficeCode = request.getParameter("headOfficeCode") == null ? "" : request.getParameter("headOfficeCode");
        String accountbankname = request.getParameter("accountbankname") == null ? "" : request.getParameter("accountbankname");
        String accountbankprov = request.getParameter("accountbankprov") == null ? "" : request.getParameter("accountbankprov");
        String accountBankCity = request.getParameter("accountBankCity") == null ? "" : request.getParameter("accountBankCity");
        String stel = request.getParameter("stel") == null ? "" : request.getParameter("stel");

        Log.info("上传结算卡参数：" + request.getQueryString());

        //四要素鉴权
        hashMap = authentication4(accountbankno, accountbankclientname, IDNo, accountBankClientTel);
        if (null == hashMap.get(Constants.RSP_CODE) || !Constants.SUCCESS_CODE.equals(hashMap.get(Constants.RSP_CODE))) {
            return hashMap;
        }

        //数据更新实体
        B2cShopperbiTemp b2cShopperbiTemp = new B2cShopperbiTemp();
        //根据开户行省市名称名称查询开户行省和市(如果查询不到则返回找不到)
        String flag = getAreaByProvAndCity(accountbankprov, accountBankCity, b2cShopperbiTemp);
        if (Constants.TYPE_1.equals(flag)) {
            hashMap.put(Constants.RSP_CODE, MessageEnum.找不到银行.getCode());
            hashMap.put(Constants.RSP_MSG, MessageEnum.找不到银行.getText());
            return hashMap;
        }

        //查询并设置小商户号
        Long shopperid = b2cShopperbiTempMapper.findBySid(IDNo).getShopperid();
        b2cShopperbiTemp.setShopperid(shopperid);

        //设置结算卡信息
        b2cShopperbiTemp.setAccountbankclientname(accountbankclientname);
        b2cShopperbiTemp.setAccountBankClientTel(accountBankClientTel);
        b2cShopperbiTemp.setAccountbankno(accountbankno);
        b2cShopperbiTemp.setAccountbankname(accountbankname);
        b2cShopperbiTemp.setAccountbankprov(accountbankprov);
        b2cShopperbiTemp.setAccountBankCity(accountBankCity);
        b2cShopperbiTemp.setBankUpdateDate(new Date());

        //根据总行名称查询总行编码
        B2cDict b2cDict = dictMapper.findBankByNote(headOfficeCode);
        b2cShopperbiTemp.setAccountbankdictval(String.valueOf(b2cDict.getB2cDictId()));

        String oldNotPassStep = null;
        B2cShopperbiTemp oldB2cShopperbiTemp = b2cShopperbiTempMapper.findByTel(stel);//根据身份证查询到商户信息
        oldNotPassStep = oldB2cShopperbiTemp.getNotPassStep();
        oldNotPassStep = com.uns.util.StringUtils.replaceIndex(Constants.INT_2, oldNotPassStep, Constants.TYPE_1);
        b2cShopperbiTemp.setNotPassStep(oldNotPassStep);
        //如果错误步骤全部重新提交，那么设置商户审核状态为人工审核中
        if (!oldNotPassStep.contains(Constants.TYPE_0)) {
            b2cShopperbiTemp.setCheckstatus(Constants.TYPE_4);
        }
        b2cShopperbiTemp.setUpdated(new Date());
        //更新实体
        b2cShopperbiTempMapper.updateOCRDebitCardInfo(b2cShopperbiTemp);

        hashMap.put(Constants.RSP_CODE, MessageEnum.成功.getCode());
        hashMap.put(Constants.RSP_MSG, MessageEnum.成功.getText());
        return hashMap;
    }

    /**
     * 根据省市名称查询省市编码
     */
    public String getAreaByProvAndCity(String sprovince, String scity, B2cShopperbiTemp b2cShopperbiTemp) {
        Map hashMap = new HashMap();
        hashMap.put("province", sprovince);
        hashMap.put("city", scity);
        Area area = areaMapper.findByCityAndProvince(hashMap);
        if (null == area) {
            return Constants.TYPE_1;
        }
        b2cShopperbiTemp.setAccountBankProvCode(area.getProvincial());
        b2cShopperbiTemp.setAccountBankCityCode(area.getCity());
        return Constants.TYPE_0;
    }


    /**
     * 上传贷记卡信息
     *
     * @param request
     * @return
     * @throws UnsupportedEncodingException
     */
    public HashMap uploadCreditCardInfo(HttpServletRequest request) throws Exception {
        HashMap hashMap = new HashMap();

        //准备商户预约更新实体
        B2cShopperbiTemp b2cShopperbiTemp = new B2cShopperbiTemp();

        String creditBankClientIdNo = AesEncrypt.decryptAES(request.getParameter("creditBankClientIdNo") == null ? "" : request.getParameter("creditBankClientIdNo"), ConstantsEnv.APP_AES_KEY);
        String creditBankClientName = request.getParameter("creditBankClientName") == null ? "" : request.getParameter("creditBankClientName");
        String creditBankName = request.getParameter("creditBankName") == null ? "" : request.getParameter("creditBankName");
        String creditBankNo = AesEncrypt.decryptAES(request.getParameter("creditBankNo") == null ? "" : request.getParameter("creditBankNo"), ConstantsEnv.APP_AES_KEY);
        String creditBankClientTel = request.getParameter("creditBankClientTel") == null ? "" : request.getParameter("creditBankClientTel");
        String stel = request.getParameter("stel") == null ? "" : request.getParameter("stel");

        Log.info("请求参数" + request.getQueryString());

        //四要素鉴权
        hashMap = authentication4(creditBankNo, creditBankClientName, creditBankClientIdNo, creditBankClientTel);
        if (null == hashMap.get(Constants.RSP_CODE) || !Constants.SUCCESS_CODE.equals(hashMap.get(Constants.RSP_CODE))) {
            return hashMap;
        }

        b2cShopperbiTemp.setCreditBankDictval(creditBankName);
        b2cShopperbiTemp.setCreditBankClientIdNo(creditBankClientIdNo);
        b2cShopperbiTemp.setCreditBankClientName(creditBankClientName);
        b2cShopperbiTemp.setCreditBankNo(creditBankNo);
        b2cShopperbiTemp.setCreditBankClientTel(creditBankClientTel);

        //设置shopperid
        Long shopperid = b2cShopperbiTempMapper.findBySid(creditBankClientIdNo).getShopperid();
        b2cShopperbiTemp.setShopperid(shopperid);

        B2cShopperbiTemp oldB2cShopperbiTemp = b2cShopperbiTempMapper.findByTel(stel);//根据手机号查询到商户信息
        String oldNotPassStep = oldB2cShopperbiTemp.getNotPassStep();
        oldNotPassStep = com.uns.util.StringUtils.replaceIndex(Constants.INT_4, oldNotPassStep, Constants.TYPE_1);
        b2cShopperbiTemp.setNotPassStep(oldNotPassStep);
        //如果错误步骤全部重新提交，那么设置商户审核状态为人工审核中
        if (!oldNotPassStep.contains(Constants.TYPE_0)) {
            b2cShopperbiTemp.setCheckstatus(Constants.TYPE_4);
        }
        b2cShopperbiTemp.setUpdated(new Date());
        //更新实体
        b2cShopperbiTempMapper.updateOCRCreditCardInfo(b2cShopperbiTemp);
        hashMap.put(Constants.RSP_CODE, MessageEnum.成功.getCode());
        hashMap.put(Constants.RSP_MSG, MessageEnum.成功.getText());
        return hashMap;
    }

    /**
     * 默认费率插入and商户完成注册（点击提交签名之后）
     *
     * @throws Exception
     */
    public HashMap saveConfirmInfo(HttpServletRequest request) throws Exception {
        HashMap hashMap = new HashMap();
        //获取商户手机号
        String stel = request.getParameter("stel") == null ? "" : request.getParameter("stel");
        //根据手机号查询到商户
        B2cShopperbiTemp b2cShopperbiTemp = b2cShopperbiTempMapper.findByTel(stel);
        //删除费率（中断注册）
        mposMerchantFeeMapper.deleteByshopperid(b2cShopperbiTemp.getShopperid());
        mposMerchantFeeMapper.deleteTempByshopperid(b2cShopperbiTemp.getShopperid());
        //插入默认费率（mpos和扫码）
        insertSweepCodeProducts(String.valueOf(b2cShopperbiTemp.getShopperid()));
        //商户其他信息添加
        saveOtherInfo(request, b2cShopperbiTemp);
        //报备弘付和海科（不一定成功）
        if (Constants.CON_YES.equals(acmsMapUtils.getAcmsMap().get("hf_open_flg"))) {
            hashMap = reportHFandHK.reportHF(b2cShopperbiTemp);
        }
        if (Constants.CON_YES.equals(acmsMapUtils.getAcmsMap().get("hk_open_flg"))) {
            hashMap = reportHFandHK.reportHK(b2cShopperbiTemp);//报备海科
        }

        //获取用户类型
        String userType = regMposAndQrcode.getType(b2cShopperbiTemp.getMerchantType());
        //注册mpos
        hashMap = regMposAndQrcode.regMposMerchant(userType, b2cShopperbiTemp);
        if (Constants.SUCCESS_CODE.equals(hashMap.get(Constants.RSP_CODE))) {
            //注册扫码
            hashMap = regMposAndQrcode.regQrcodeMerchant(request, userType, b2cShopperbiTemp);
            if (Constants.SUCCESS_CODE.equals(hashMap.get(Constants.RSP_CODE))) {
                //新建用户、预约信息更新和正式信息表的插入
                saveshopper(b2cShopperbiTemp);
                hashMap.put(Constants.RSP_CODE, MessageEnum.成功.getCode());
                hashMap.put(Constants.RSP_MSG, MessageEnum.成功.getText());
            } else {
                return hashMap;
            }
        } else if (MessageEnum.实名认证失败.getCode().equals(hashMap.get(Constants.RSP_CODE))) {
            hashMap.put(Constants.RSP_CODE, MessageEnum.实名认证失败.getCode());
            hashMap.put(Constants.RSP_MSG, MessageEnum.实名认证失败.getText());
        } else if (MessageEnum.注册银生宝失败.getCode().equals(hashMap.get(Constants.RSP_CODE))) {
            hashMap.put(Constants.RSP_CODE, MessageEnum.注册银生宝失败.getCode());
            hashMap.put(Constants.RSP_MSG, MessageEnum.注册银生宝失败.getText());
        } else if (MessageEnum.已注册成功请登录.getCode().equals(hashMap.get(Constants.RSP_CODE))) {
            hashMap.put(Constants.RSP_CODE, MessageEnum.已注册成功请登录.getCode());
            hashMap.put(Constants.RSP_MSG, MessageEnum.已注册成功请登录.getText());
        } else {
            hashMap.put(Constants.RSP_CODE, MessageEnum.扫码支付注册失败.getCode());
            hashMap.put(Constants.RSP_MSG, MessageEnum.扫码支付注册失败.getText());
        }
        return hashMap;
    }


    public void saveshopper(B2cShopperbiTemp shopperbiTemp) {
        List b2cShopperbiList = b2cShopperbiMapper.findtelbytel(shopperbiTemp.getStel());
        if (b2cShopperbiList == null || b2cShopperbiList.size() == 0) {

            Users user = usersMapper.findbytelm(shopperbiTemp.getStel());
            if(user == null){
                shopperbiTemp.setShopperid(shopperbiTemp.getShopperid());
                Users usres = saveUsers(user, shopperbiTemp);
                //添加用户
                usersMapper.insert(usres);
            }
            //更新预约信息
            b2cShopperbiTempMapper.updateByPrimaryKeySelective(shopperbiTemp);
            //插入正式表
            b2cShopperbiMapper.insert(shopperbiTemp);
        }
    }

    /**
     * 保存用户名密码
     *
     * @param user
     * @param b2cShopperbi
     * @return
     */
    private Users saveUsers(Users user, B2cShopperbiTemp b2cShopperbi) {
        user = new Users();
        user.setMerchantid(b2cShopperbi.getShopperid());
        user.setUserName(b2cShopperbi.getMuserid());
        user.setPassword(b2cShopperbi.getMpassword());
        user.setTel(b2cShopperbi.getStel());
        user.setEnabled(Short.valueOf(Constants.CON_YES));
        user.setCreatedate(new Date());
        user.setLocked(Long.valueOf(b2cShopperbi.getSifpactid() == null ? Constants.CON_NO : b2cShopperbi.getSifpactid().toString()));
        user.setIsAgent(Short.valueOf(Constants.CON_NO));
        return user;
    }

    /**
     * 插入默认费率
     */
    public void insertSweepCodeProducts(String shopperid) {

        //添加扫码费率
        List<SweepCodeProduct> sweepCodeProducts = sweepCodeProductMapper.findCodeProductSm();
        MposMerchantFee mposMerchantFee = null;
        MposMerchantFee mposMerchantFeeMpos = null;
        //初始费率表id设置为0
        Long id = new Long(Constants.INT_0);
        for (SweepCodeProduct sweepCodeProduct : sweepCodeProducts) {
            mposMerchantFee = new MposMerchantFee();
            mposMerchantFee.setShopperid(Long.valueOf(shopperid));
            mposMerchantFee.setFeetype(sweepCodeProduct.getProFeeType());//费率类型
            mposMerchantFee.setFee(sweepCodeProduct.getProT1Fee());//t1费率
            mposMerchantFee.setD0fee(sweepCodeProduct.getProD0Fee());//DO费率
            mposMerchantFee.setStatus(Constants.CON_YES);
            mposMerchantFee.setCreateDate(new Date());
            mposMerchantFee.setProType(sweepCodeProduct.getProType());
            //如果id不为0，即id已经通过序列生成，则设置id然后插入
            if (id != Constants.INT_0) {
                mposMerchantFee.setId(id);
                mposMerchantFeeMapper.insert(mposMerchantFee);
                mposMerchantFeeMapper.insertTemp(mposMerchantFee);
            }
            //如果是第一次插入，即id为初始设置的0，则通过序列生成id
            else {
                mposMerchantFeeMapper.insertSelective(mposMerchantFee);
                mposMerchantFeeMapper.insertTempSelective(mposMerchantFee);
                //将id设置为序列生成的id
                id = mposMerchantFee.getId();
            }
        }

        //添加mpos费率
        List<SweepCodeProduct> sweepCodeProductsMpos = sweepCodeProductMapper.findCodeProductMpos();
        for (SweepCodeProduct sweepCodeProductsM : sweepCodeProductsMpos) {
            mposMerchantFeeMpos = new MposMerchantFee();
            mposMerchantFeeMpos.setId(id);
            mposMerchantFeeMpos.setShopperid(Long.valueOf(shopperid));
            mposMerchantFeeMpos.setFeetype(sweepCodeProductsM.getProFeeType());
            mposMerchantFeeMpos.setFee(sweepCodeProductsM.getProT1Fee());
            mposMerchantFeeMpos.setD0fee(sweepCodeProductsM.getProD0Fee());
            mposMerchantFeeMpos.setStatus(Constants.CON_YES);
            mposMerchantFeeMpos.setCreateDate(new Date());
            mposMerchantFeeMpos.setChannelType(sweepCodeProductsM.getChannelType());
            mposMerchantFeeMpos.setEachamount(sweepCodeProductsM.getEachamount());
            mposMerchantFeeMpos.setProType(sweepCodeProductsM.getProType());
            mposMerchantFeeMapper.insert(mposMerchantFeeMpos);
            mposMerchantFeeMapper.insertTemp(mposMerchantFeeMpos);
        }
    }

    /**
     * 插入商户其他信息
     */
    public void saveOtherInfo(HttpServletRequest request, B2cShopperbiTemp b2cShopperbiTemp) {

        //获取是否手动修改过OCR扫描出来的信息
        String ifEdit = request.getParameter("ifEdit") == null ? "" : request.getParameter("ifEdit");

        String inviteCode = getShopperInviteCode();//获取商户邀请码
        b2cShopperbiTemp.setInviteCode(inviteCode);//设置新商户的邀请码
        b2cShopperbiTemp.setReportResource(Constants.TYPE_4);// 设置报件来源为开放注册
        b2cShopperbiTemp.setCreated(new Date());//设置创建时间

        b2cShopperbiTemp.setMerchantType(Constants.CON_NO);//个人
        b2cShopperbiTemp.setStel(b2cShopperbiTemp.getStel());
        if(null == b2cShopperbiTemp.getCreditBankNo() || "".equals(b2cShopperbiTemp.getCreditBankNo())){
            b2cShopperbiTemp.setIsSupportT0(Constants.STATUS1);//支持T+0 0支持1不支持
        }else{
            b2cShopperbiTemp.setIsSupportT0(Constants.STATUS0);
        }

        //个人
        b2cShopperbiTemp.setScompany(b2cShopperbiTemp.getName());
        b2cShopperbiTemp.setName(b2cShopperbiTemp.getName());// 姓名
        b2cShopperbiTemp.setFixqrcodecustomername(Constants.FIX_NAME + b2cShopperbiTemp.getName().substring(0, 1) + "**");

        b2cShopperbiTemp.setIsexternalrevenue(Constants.CON_NO);

        // 所在城市票据
        b2cShopperbiTemp.setBillCity(b2cShopperbiTemp.getScity());
        b2cShopperbiTemp.setBillCityCode(b2cShopperbiTemp.getCity());
        b2cShopperbiTemp.setBillProvince(b2cShopperbiTemp.getSprovince());
        b2cShopperbiTemp.setBillProvinceCode(b2cShopperbiTemp.getProvince());

        // 票据地址
        b2cShopperbiTemp.setBillAddress(b2cShopperbiTemp.getSaddress());
        //设置行业
        b2cShopperbiTemp.setIndustry(Constants.DEFAULT_INDUSTRY);//默认行业为其他(160)

        // 默认添加字段
        b2cShopperbiTemp.setIfvalid(Short.valueOf(Constants.STATUS0));
        b2cShopperbiTemp.setOpencheckstatus(Short.valueOf(Constants.STATUS0));
        b2cShopperbiTemp.setIsformal(Short.valueOf(Constants.STATUS0));
        b2cShopperbiTemp.setIsupdateshopper(Short.valueOf(Constants.STATUS0));
        b2cShopperbiTemp.setSifpactid(Long.valueOf(Constants.STATUS0));
        b2cShopperbiTemp.setRecheckmerchantflag(Constants.STATUS0);
        b2cShopperbiTemp.setPhotoCheckFlag(Constants.STATUS0);
        b2cShopperbiTemp.setPhotoRecheckFlag(Constants.STATUS0);
        b2cShopperbiTemp.setTransact(Constants.STATUS1);//设置未审核

        b2cShopperbiTemp.setT0topamount(Double.parseDouble(Constants.MONEY_0));
        b2cShopperbiTemp.setT1type(Constants.STATUS0);
        b2cShopperbiTemp.setT0type(Constants.STATUS0);
        b2cShopperbiTemp.setCardType(Constants.STATUS0);
        b2cShopperbiTemp.setT0additionfee(Double.parseDouble(Constants.MONEY_0));
        b2cShopperbiTemp.setT1topamount(Double.parseDouble(Constants.MONEY_0));
        b2cShopperbiTemp.setIsIcApplyT0(Constants.STATUS0);
        b2cShopperbiTemp.setT0minamount(Double.parseDouble(Constants.MONEY_197));
        b2cShopperbiTemp.setT0maxamount(Double.parseDouble(Constants.MIN_SETTLE_MONEY));
        b2cShopperbiTemp.setT0SingleDayLimit(Double.parseDouble(Constants.MIN_SETTLE_MONEY));
        b2cShopperbiTemp.setSettleType(Constants.CON_YES);//1是普通
        b2cShopperbiTemp.setCreditLines(Double.parseDouble(Constants.MIN_SETTLE_MONEY));//扫码授信额度5W

        //添加分润方案
        b2cShopperbiTemp.setAgentProfitRatio(ConstantsEnv.AGENT_PROFIT_RATIO);
        b2cShopperbiTemp.setProfitOwner(ConstantsEnv.PROFIT_OWNER);
        b2cShopperbiTemp.setMerchProfitRatio1(ConstantsEnv.MERCH_PROFIT_RATIO1);
        b2cShopperbiTemp.setMerchProfitRatio2(ConstantsEnv.MERCH_PROFIT_RATIO2);
        b2cShopperbiTemp.setMerchProfitRatio3(ConstantsEnv.MERCH_PROFIT_RATIO3);

        //如果商户手动修改过信息，设置商户状态为人工审核中
        if (null != ifEdit && Constants.TYPE_1.equals(ifEdit)) {
            b2cShopperbiTemp.setCheckstatus(Constants.TYPE_4);//审核状态设置为4（人工审核中）
            b2cShopperbiTemp.setToManualauditDate(new Date());
        } else {
            b2cShopperbiTemp.setCheckstatus(Constants.TYPE_1);//审核状态设置为1（自动审核中）
        }
        b2cShopperbiTemp.setVisualCheckStatus(Constants.TYPE_0);//设置人工检查状态为0

        //添加merchantKey值
        String merchantKey = com.uns.util.StringUtils.getCharAndNumr(8);
        b2cShopperbiTemp.setMerchantKey(merchantKey);

        //OCR错误步骤
        String oldNotPassStep = b2cShopperbiTemp.getNotPassStep();
        oldNotPassStep = com.uns.util.StringUtils.replaceIndex(Constants.INT_10, oldNotPassStep, Constants.TYPE_1);
        b2cShopperbiTemp.setNotPassStep(oldNotPassStep);

        //添加商户的muser和mpassword（从商户验证码表中）
        B2cShopperVal b2cShopperVal = new B2cShopperVal();
        b2cShopperVal.setTel(b2cShopperbiTemp.getStel());
        List<B2cShopperVal> b2cShopperValList = b2cShopperValMapper.queryByParam(b2cShopperVal);
        if (null != b2cShopperValList) {
            b2cShopperVal = b2cShopperValList.get(0);
        }
        //设置商户登陆用户名和密码
        b2cShopperbiTemp.setMuserid(b2cShopperVal.getTel());
        b2cShopperbiTemp.setMpassword(Md5Encrypt.md5(b2cShopperVal.getPassword()));
        if(null != b2cShopperVal.getInviteCodeP()){
            b2cShopperbiTemp.setInviteCodeP(b2cShopperVal.getInviteCodeP());
        }
        b2cShopperbiTemp.setShopperidP(b2cShopperVal.getShopperidP() == null ? null : b2cShopperVal.getShopperidP());
        b2cShopperbiTemp.setSagentid(b2cShopperVal.getShopperidP() == null ? null : b2cShopperVal.getShopperidP());
        //设置商户图片id
        if (StringUtils.isNotEmpty(b2cShopperbiTemp.getIDNo())) {
            MposPhotoTmp mposPhotoTmp = mposPhotoTmpMapper.selectByIdNo(b2cShopperbiTemp.getIDNo());
            b2cShopperbiTemp.setPhotoid(mposPhotoTmp.getPhotoId());
        }
    }


    /**
     * 查询默认费率的方法
     *
     * @return
     */
    public List getSweepCodeProduct() {

        //返回的数据hashMap
        List<SweepCodeProduct> sweepCodeProductList = sweepCodeProductMapper.findAllSweepCodeProduct();

        return sweepCodeProductList;
    }

    /**
     * 新商户获取自己的邀请码
     */
    private String getShopperInviteCode() {
        String inviteCode = "";
        List<String> inviteCodes = b2cShopperbiMapper.findAllInviteCode();
        while (1 == 1) {
            String inviteCode1 = RandomStringUtils.random(2, "ABCDEFGHJKMNPQRSTUVWXYZ");
            String inviteCode2 = String.valueOf((int) ((Math.random() * 9 + 1) * 100000));
            inviteCode = inviteCode1 + inviteCode2;
            if (!inviteCodes.contains(inviteCode)) {
                break;
            }
        }
        return inviteCode;
    }

    /**
     * 四要素鉴权
     */
    public HashMap authentication4(String bankNo, String bankClientName, String idNo, String bankClientTel) {
        HashMap hashMap = new HashMap();
        //四要素鉴权
        String authResult = AuthenticAtionUtils.authentication4(bankNo, bankClientName, idNo, bankClientTel);//银行卡号，姓名，身份证号，手机号
        BankCardValBean bankCardValBean = JSONObject.parseObject(authResult, BankCardValBean.class);
        Log.info("四要素鉴权返回结果:{}", FastJson.toJson(bankCardValBean));
        if ("1111".equals(bankCardValBean.getResult_code())) {
            hashMap.put(Constants.RSP_CODE, "1009");
            hashMap.put(Constants.RSP_MSG, "系统异常");
            return hashMap;
        } else if ("2033".equals(bankCardValBean.getResult_code())) {
            hashMap.put(Constants.RSP_CODE, "1010");
            hashMap.put(Constants.RSP_MSG, "网络繁忙");
            return hashMap;
        } else if ("1005".equals(bankCardValBean.getResult_code())) {
            hashMap.put(Constants.RSP_CODE, "1011");
            hashMap.put(Constants.RSP_MSG, "身份证号格式不正确");
            return hashMap;
        } else if ("0000".equals(bankCardValBean.getResult_code())) {
            if ("20".equals(bankCardValBean.getStatus())) {
                hashMap.put(Constants.RSP_CODE, "1012");
                hashMap.put(Constants.RSP_MSG, "信息不匹配,持卡人身份信息输入不正确");
                return hashMap;
            }
            //鉴权通过
            else if (!"00".equals(bankCardValBean.getStatus())) {
                hashMap.put(Constants.RSP_CODE, MessageEnum.出错.getCode());
                hashMap.put(Constants.RSP_MSG, MessageEnum.出错.getText());
                return hashMap;
            } else {
                hashMap.put(Constants.RSP_CODE, MessageEnum.成功.getCode());
                hashMap.put(Constants.RSP_MSG, MessageEnum.成功.getText());
                return hashMap;
            }
        } else {
            hashMap.put(Constants.RSP_CODE, MessageEnum.出错.getCode());
            hashMap.put(Constants.RSP_MSG, MessageEnum.出错.getText());
            return hashMap;
        }
    }

    /**
     * APP获取错误OCR步骤列表
     */
    public HashMap getNotPassStep(HttpServletRequest request) {
        HashMap hashMap = new HashMap();
        String stel = request.getParameter("stel") == null ? "" : (String) request.getParameter("stel");
        List<String> list = null;
        B2cShopperbiTemp b2cShopperbiTemp = null;
        String flag = null;
        b2cShopperbiTemp = b2cShopperbiTempMapper.findByTel(stel);
        if (null != b2cShopperbiTemp) {
            String notPassStep = b2cShopperbiTemp.getNotPassStep();
            String[] arr = notPassStep.split(",");
            list = new ArrayList<String>();
            for (String str : arr) {
                list.add(str);
            }
            if (Constants.STATUS3.equals(b2cShopperbiTemp.getCheckstatus() == null ? "" : b2cShopperbiTemp.getCheckstatus().toString().trim())) {
                flag = Constants.TYPE_2;
            }
            if (Constants.STATUS0.equals(b2cShopperbiTemp.getCheckstatus() == null ? "" : b2cShopperbiTemp.getCheckstatus().toString().trim())) {
                flag = Constants.TYPE_3;
            }
            if (Constants.STATUS1.equals(b2cShopperbiTemp.getCheckstatus() == null ? "" : b2cShopperbiTemp.getCheckstatus().toString().trim())) {
                flag = Constants.TYPE_3;
            }
            if (Constants.STATUS0.equals(b2cShopperbiTemp.getCheckstatus() == null ? "" : b2cShopperbiTemp.getCheckstatus().toString().trim())) {
                flag = Constants.TYPE_1;
            }
            if (Constants.STATUS2.equals(b2cShopperbiTemp.getCheckstatus() == null ? "" : b2cShopperbiTemp.getCheckstatus().toString().trim())) {
                flag = Constants.TYPE_0;
            }
            if (Constants.STATUS4.equals(b2cShopperbiTemp.getCheckstatus() == null ? "" : b2cShopperbiTemp.getCheckstatus().toString().trim())) {
                flag = Constants.TYPE_3;
            }
            if (Constants.STATUS5.equals(b2cShopperbiTemp.getCheckstatus() == null ? "" : b2cShopperbiTemp.getCheckstatus().toString().trim())) {
                flag = Constants.TYPE_0;
            }
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        hashMap.put("accountBankNo", AesEncrypt.encryptAES(b2cShopperbiTemp.getAccountbankno(), ConstantsEnv.APP_AES_KEY));
        hashMap.put("notPassReason", b2cShopperbiTemp.getNotPassReason());
        if (null != b2cShopperbiTemp.getRecheckDate()) {
            hashMap.put("lastCheckTime", sdf.format(b2cShopperbiTemp.getRecheckDate()));
        }
        if (null != b2cShopperbiTemp.getUpdated()) {
            hashMap.put("updateTime", sdf.format(b2cShopperbiTemp.getUpdated()));
        }else{
            hashMap.put("updateTime", sdf.format(b2cShopperbiTemp.getCreated()));
        }

        hashMap.put("notPassReason", b2cShopperbiTemp.getNotPassReason());
        hashMap.put("notPassStep", list);
        hashMap.put("flag", flag);
        hashMap.put(Constants.RSP_CODE, MessageEnum.成功.getCode());
        hashMap.put(Constants.RSP_MSG, MessageEnum.成功.getText());
        return hashMap;
    }

    /**
     * 更新商户错误步骤
     */
    public void updateNotPassStep(String identityid, int step) {
        B2cShopperbiTemp oldB2cShopperbiTemp = b2cShopperbiTempMapper.findBySid(identityid);//根据身份证查询到商户信息
        String notPassStep = oldB2cShopperbiTemp.getNotPassStep();
        notPassStep = com.uns.util.StringUtils.replaceIndex(step, notPassStep, Constants.TYPE_1);
        oldB2cShopperbiTemp.setNotPassStep(notPassStep);
        //如果错误步骤全部重新提交，那么设置商户审核状态为人工审核中
        if (!notPassStep.contains(Constants.TYPE_0)) {
            oldB2cShopperbiTemp.setCheckstatus(Constants.TYPE_4);
        }
        b2cShopperbiTempMapper.updateByPrimaryKeySelective(oldB2cShopperbiTemp);
    }

}
