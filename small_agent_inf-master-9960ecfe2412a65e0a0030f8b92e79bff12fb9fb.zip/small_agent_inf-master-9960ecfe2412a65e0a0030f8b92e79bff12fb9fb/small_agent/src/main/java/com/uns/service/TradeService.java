package com.uns.service;

import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.PageContext;
import com.uns.dao.B2cTranhisMapper;
import com.uns.model.B2cTranhis;
import com.uns.web.form.TradeForm;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class TradeService {
	@Autowired
	private B2cTranhisMapper tradeMapper;
	
	/**商户交易详情
	 * @param tranid
	 * @return
	 * @throws BusinessException
	 * @throws Exception
	 */
	public Map getTradeView(String tranid) throws BusinessException, Exception
	{
		
		if(StringUtils.isBlank(tranid))
		{
			throw new BusinessException(ExceptionDefine.交易流水的ID不存在);
		}
		List trades = tradeMapper.findTradeById(tranid);
		if(trades!=null && trades.size()==1)
		{
			return (Map) trades.get(0);
		}
		if(trades!=null && trades.size()>1)
		{
			throw new BusinessException(ExceptionDefine.交易流水重复);
		}		
		return new HashMap();
	}
	
	public List<String> getTerminalSb(String shopperid) throws BusinessException, Exception{
		
		if(StringUtils.isBlank(shopperid))
		{
			throw new BusinessException(ExceptionDefine.获取商户POS终端号失败无效商户号);
		}
		List<String> terminals = tradeMapper.getTerminalSb(shopperid);
		if(terminals!=null)
		{
			return terminals;
		}
		return new ArrayList<String>();
	}
	
	public List<B2cTranhis> findTradeAgentList(TradeForm tradeForm) throws BusinessException, Exception
	{
		
		PageContext.initPageSize(20);
		List<B2cTranhis> trades = tradeMapper.findTradeAgentList(tradeForm);
		if(trades!=null && trades.size()!=0)
		{
			return trades;
		}
		return new ArrayList<B2cTranhis>();
	}
	
	public List findTradeExcelAgentList(TradeForm tradeForm) throws BusinessException, Exception
	{
		
		PageContext.initPageSize(3000);
		List<B2cTranhis> trades = tradeMapper.findTradeAgentList(tradeForm);
		if(trades!=null && trades.size()!=0)
		{
			return trades;
		}
		return new ArrayList<B2cTranhis>();
	}
	//笔数
	public HashMap getb2cTranhisAgent(TradeForm tradeForm) {
		return tradeMapper.getb2cTranhisAgent(tradeForm);
	}

	public List<B2cTranhis> getTradeList(String terId) {
		PageContext.initPageSize(20);
		return tradeMapper.getTradeList(terId);
	}

	/**金额
	 * @param tradeForm
	 * @return
	 */
	public HashMap getb2cTranhisAmount(TradeForm tradeForm) {
		return tradeMapper.getb2cTranhisAmount(tradeForm);
	}
}	
