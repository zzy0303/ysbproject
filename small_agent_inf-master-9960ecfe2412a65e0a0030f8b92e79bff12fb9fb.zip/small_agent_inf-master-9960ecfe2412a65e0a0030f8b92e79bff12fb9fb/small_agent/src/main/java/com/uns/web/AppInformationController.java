package com.uns.web;

import com.uns.common.Constants;
import com.uns.model.MposSystemInformation;
import com.uns.service.AppInformationService;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping(value = "/appInformation.htm")
public class AppInformationController extends BaseController {
	
	@Autowired
	private AppInformationService appInformationService;
	
	/**查询消息主题（分页）
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(params = "method=findAppInformationTheme")
	public void findAppInformationTheme(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Map hashMap = new HashMap();
		Map appInformationThemeMap = null;
		String page=request.getParameter("page");
		String version  = request.getParameter("version") == null ? "" : request.getParameter("version");
		String type = request.getParameter("type") == null ? "" : request.getParameter("type");
		try {
			if ((Constants.TYPE_A).equals(type)) {
				log.info("#########################Android:查询消息##########################");
				appInformationThemeMap=appInformationService.findAppInformationTheme(request,page);
				hashMap.put("appInformationThemeMap", appInformationThemeMap);
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "查询成功");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("消息查询成功Android:" + json.toString());
				response.getWriter().write(json.toString());
				
			}else{
				log.info("#########################IOS:查询消息##########################");
				appInformationThemeMap=appInformationService.findAppInformationTheme(request,page);
				hashMap.put("appInformationThemeMap", appInformationThemeMap);
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "查询成功");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("消息查询成功ios:" + json.toString());
				response.getWriter().write(json.toString());
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "系统错误");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("消息查询异常:" + json.toString());
			response.getWriter().write(json.toString());
		}
		
		
	}
	
	
	/**根据id查询消息详情,修改消息是否阅读标志
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(params = "method=findAppInformationDetails")
	public void findAppInformationDetails(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Map hashMap = new HashMap();
		Map appInformationDetailsMap = null;
		String version  = request.getParameter("version") == null ? "" : request.getParameter("version");
		String type = request.getParameter("type") == null ? "" : request.getParameter("type");
		try {
			if ((Constants.TYPE_A).equals(type)) {
				log.info("#########################Android:查询消息详情##########################");
				appInformationDetailsMap=appInformationService.findAppInformationDetails(request);
				hashMap.put("appInformationDetailsMap", appInformationDetailsMap);
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "查询成功");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("消息详情查询成功Android:" + json.toString());
				response.getWriter().write(json.toString());
				
			}else{
				log.info("#########################IOS:查询消息详情##########################");
				appInformationDetailsMap=appInformationService.findAppInformationDetails(request);
				hashMap.put("appInformationDetailsMap", appInformationDetailsMap);
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "查询成功");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("消息详情查询成功ios:" + json.toString());
				response.getWriter().write(json.toString());
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "系统错误");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("消息详情查询异常:" + json.toString());
			response.getWriter().write(json.toString());
		}
		
	}
	
	
	
	/**固码消息查询接口
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(params = "method=finInformationTheme")
	public void finInformationTheme(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Map hashMap = new HashMap();
		String theme=null;
		try {
				log.info("#########################固码消息查询接口##########################");
				theme=appInformationService.finInformationTheme();
				hashMap.put("theme", theme);
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "查询成功");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("消息查询成功Android:" + json.toString());
				response.getWriter().write(json.toString());
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "系统错误");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("固码消息查询接口:" + json.toString());
			response.getWriter().write(json.toString());
		}
		
		
	}

}
