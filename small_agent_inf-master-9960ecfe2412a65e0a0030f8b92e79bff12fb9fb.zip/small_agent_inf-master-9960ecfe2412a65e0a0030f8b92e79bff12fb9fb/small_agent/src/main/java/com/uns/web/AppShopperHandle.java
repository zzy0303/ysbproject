package com.uns.web;

import com.uns.common.myenum.MessageEnum;
import com.uns.service.AppShopperHandleService;
import net.sf.json.JSONObject;
import org.apache.shiro.crypto.hash.Hash;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

/**
 * 存量商户数据处理
 * Created by Administrator on 2017/6/29.
 */
@Controller
@RequestMapping(value = "shopperHandle.htm")
public class AppShopperHandle extends BaseController {

    @Autowired
    private AppShopperHandleService appShopperHandleService;

    /**
     * 存量商户邀请码处理
     */
    @RequestMapping(params = "method=inviteHandle")
    public void ShopperInviteHandle(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HashMap hashMap = new HashMap();
        response.setContentType("UTF-8");
        try {
            hashMap = appShopperHandleService.inviteHandle();
        } catch (Exception e) {
            e.printStackTrace();
            hashMap.put("rspCode", MessageEnum.出错.getCode());
            hashMap.put("rspMsg", MessageEnum.出错.getText());
        }
        JSONObject json = JSONObject.fromObject(hashMap);
        log.info("存量商户邀请码处理:" + json.toString());
        response.getWriter().write(json.toString());
    }















}
