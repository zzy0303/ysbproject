package com.uns.model;

public class AgentRatio{
	//key
	private Long phyid;

	// fields
	private Long agentid;
	private Double rangeamt;
	private Double ratio;
	private String updatedate;
	private String updatemaker;
	private String modeflag;
	private Long amid;

	public Long getAmid() {
		return amid;
	}
	public void setAmid(Long amid) {
		this.amid = amid;
	}
	public Long getPhyid() {
		return phyid;
	}
	public void setPhyid(Long phyid) {
		this.phyid = phyid;
	}
	public Double getRangeamt() {
		return rangeamt;
	}
	public void setRangeamt(Double rangeamt) {
		this.rangeamt = rangeamt;
	}
	public String getModeflag() {
		return modeflag;
	}
	public void setModeflag(String modeflag) {
		this.modeflag = modeflag;
	}
	public Long getAgentid() {
		return agentid;
	}
	public void setAgentid(Long agentid) {
		this.agentid = agentid;
	}

	public Double getRatio() {
		return ratio;
	}
	public void setRatio(Double ratio) {
		this.ratio = ratio;
	}
	public String getUpdatedate() {
		return updatedate;
	}
	public void setUpdatedate(String updatedate) {
		this.updatedate = updatedate;
	}
	public String getUpdatemaker() {
		return updatemaker;
	}
	public void setUpdatemaker(String updatemaker) {
		this.updatemaker = updatemaker;
	}
}