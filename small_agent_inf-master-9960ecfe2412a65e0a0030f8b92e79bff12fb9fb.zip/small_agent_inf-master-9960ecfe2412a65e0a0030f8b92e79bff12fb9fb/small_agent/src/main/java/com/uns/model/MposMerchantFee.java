package com.uns.model;

import java.math.BigDecimal;
import java.util.Date;

public class MposMerchantFee {
    private Long id;

    private Long shopperid;

    private String fee;

    private String topAmount;

    private String status;

    private Date createDate;

    private Date updateDate;
    
    private String feetype;
    
    private String d0fee;
    
    private String channelType;

    private String proType;

    private BigDecimal eachamount;
    

    public String getChannelType() {
		return channelType;
	}

	public void setChannelType(String channelType) {
		this.channelType = channelType;
	}

	public String getProType() {
		return proType;
	}

	public void setProType(String proType) {
		this.proType = proType;
	}

	public BigDecimal getEachamount() {
		return eachamount;
	}

	public void setEachamount(BigDecimal eachamount) {
		this.eachamount = eachamount;
	}

	public String getD0fee() {
		return d0fee;
	}

	public void setD0fee(String d0fee) {
		this.d0fee = d0fee;
	}

	public String getFeetype() {
		return feetype;
	}

	public void setFeetype(String feetype) {
		this.feetype = feetype;
	}

	public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    
    public Long getShopperid() {
		return shopperid;
	}

	public void setShopperid(Long shopperid) {
		this.shopperid = shopperid;
	}

	public String getFee() {
        return fee;
    }

    public void setFee(String fee) {
        this.fee = fee == null ? null : fee.trim();
    }
    public String getTopAmount() {
        return topAmount;
    }

    public void setTopAmount(String topAmount) {
        this.topAmount = topAmount == null ? null : topAmount.trim();
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
}