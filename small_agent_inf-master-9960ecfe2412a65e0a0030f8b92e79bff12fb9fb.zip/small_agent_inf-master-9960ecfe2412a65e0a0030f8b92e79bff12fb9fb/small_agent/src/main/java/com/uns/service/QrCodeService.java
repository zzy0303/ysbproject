package com.uns.service;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.exception.BusinessException;
import com.uns.common.myenum.MessageEnum;
import com.uns.dao.B2cFixedCodeMapper;
import com.uns.dao.B2cShopperbiMapper;
import com.uns.dao.B2cShopperbiTempMapper;
import com.uns.dao.QrCodeMapper;
import com.uns.model.B2cFixedCode;
import com.uns.model.B2cShopperbi;
import com.uns.model.B2cShopperbiTemp;
import com.uns.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class QrCodeService {

    @Autowired
    private QrCodeMapper qrCodeMapper;

    @Autowired
    private B2cFixedCodeMapper fixedCodeMapper;

    @Autowired
    private B2cShopperbiTempMapper b2cShopperbiTempMapper;

    @Autowired
    private B2cShopperbiMapper b2cShopperbiMapper;
    
    @Autowired
    private RegMposAndQrcode regMposAndQrcode;

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    public Map<String, Object> queryQrCodeInfoByShopperId(String shopperid) {
        return qrCodeMapper.queryQrCodeInfoByShopperId(shopperid);
    }

    /**
     * 商户二维码绑定
     *
     * @param request
     * @return
     */
    public HashMap qrCodeBind(HttpServletRequest request) {
        HashMap hashMap = new HashMap();
        String version = request.getParameter("version");
        String type = request.getParameter("type");
        try {
            if (Constants.TYPE_A.equals(type)) {
                hashMap = qrCodeBindAndroid210(request);
            } else {
                hashMap = qrCodeBindIos210(request);
            }
            return hashMap;
        } catch (Exception e) {
            e.printStackTrace();
            hashMap.put("rspCode", "2222");
            hashMap.put("rspMsg", "绑定出错");
            return hashMap;
        }
    }

    /**
     * 商户二维码绑定Ios210
     *
     * @param request
     * @return
     */
    public HashMap qrCodeBindIos210(HttpServletRequest request) throws Exception {
        HashMap hashMap = new HashMap();
        String merchantNo = request.getParameter("merchantNo") == null ? "" : request.getParameter("merchantNo").trim(); //商户号
        B2cShopperbiTemp b2cShopperbiTemp = b2cShopperbiTempMapper.findShopperbiTempByShopperid(merchantNo);
       
        logger.info("商户二维码绑定Ios210............");
        String bindType = request.getParameter("bindType") == null ? "" : request.getParameter("bindType").trim(); //绑定类型
        if (Constants.BIND_TYPE_PLAIN.equals(bindType)) { //绑定普通商户固码
            hashMap = qrCodeBindPlain(request);
        } else if (Constants.BIND_TYPE_INVITE.equals(bindType)) { //根据邀请码绑定商户固码
            hashMap = qrCodeBindInvite(request);
        } else if (Constants.BIND_TYPE_DIRECT.equals(bindType)) { //绑定直营固码
            hashMap = qrCodeBindDirect(request);
        }
        if(null != hashMap.get("rspCode") && !Constants.SUCCESS_CODE.equals(hashMap.get("rspCode"))){
            return hashMap;
        }
        Map resultMap = regMposAndQrcode.activateMposAndQrcode(b2cShopperbiTemp);
        String rspCode = (String)resultMap.get("rspCode");
        String qrpayRspCode = (String)resultMap.get("qrpayRspCode");
        if (Constants.SUCCESS_CODE.equals(rspCode) && Constants.SUCCESS_CODE.equals(qrpayRspCode)) {
            b2cShopperbiTemp.setIfactivated(Constants.CON_YES);
            b2cShopperbiTemp.setIfactivadate(new Date());
            b2cShopperbiTemp.setTransact(Constants.TYPE_2);//已激活
            updateActiveStatus(b2cShopperbiTemp);
        }else{
            hashMap.put("rspCode", MessageEnum.激活商户失败.getCode());
            hashMap.put("rspMsg", MessageEnum.激活商户失败.getText());
        }
        return hashMap;
    }

    /**
     * 商户二维码绑定Android210
     *
     * @param request
     * @return
     */
    public HashMap qrCodeBindAndroid210(HttpServletRequest request) throws Exception {
        HashMap hashMap = new HashMap();
        String merchantNo = request.getParameter("merchantNo") == null ? "" : request.getParameter("merchantNo").trim(); //商户号
        B2cShopperbiTemp b2cShopperbiTemp = b2cShopperbiTempMapper.findShopperbiTempByShopperid(merchantNo);
       
        logger.info("商户二维码绑定Android210............");
        String bindType = request.getParameter("bindType") == null ? "" : request.getParameter("bindType").trim(); //绑定类型
        if (Constants.BIND_TYPE_PLAIN.equals(bindType)) { //绑定普通商户固码
            hashMap = qrCodeBindPlain(request);
        } else if (Constants.BIND_TYPE_INVITE.equals(bindType)) { //根据邀请码绑定商户固码
            hashMap = qrCodeBindInvite(request);
        } else if (Constants.BIND_TYPE_DIRECT.equals(bindType)) { //绑定直营固码
            hashMap = qrCodeBindDirect(request);
        }
        if(null != hashMap.get("rspCode") && !Constants.SUCCESS_CODE.equals(hashMap.get("rspCode"))){
            return hashMap;
        }
        Map resultMap = regMposAndQrcode.activateMposAndQrcode(b2cShopperbiTemp);
        String rspCode = (String)resultMap.get("rspCode");
        String qrpayRspCode = (String)resultMap.get("qrpayRspCode");
        logger.info("激活MPOS结果：" + rspCode + "激活扫码结果：" + qrpayRspCode);
        if (Constants.SUCCESS_CODE.equals(rspCode) && Constants.SUCCESS_CODE.equals(qrpayRspCode)) {
            b2cShopperbiTemp.setIfactivated(Constants.CON_YES);
            b2cShopperbiTemp.setIfactivadate(new Date());
            b2cShopperbiTemp.setTransact(Constants.TYPE_2);//已激活
            updateActiveStatus(b2cShopperbiTemp);
        }else{
            hashMap.put("rspCode", MessageEnum.激活商户失败.getCode());
            hashMap.put("rspMsg", MessageEnum.激活商户失败.getText());
        }
        return hashMap;
    }


    /**
     * 更新商户激活状态
     * @param b2cShopperbiTemp
     */
    private void updateActiveStatus(B2cShopperbiTemp b2cShopperbiTemp){
        b2cShopperbiTempMapper.updateShopperActive(b2cShopperbiTemp);
        b2cShopperbiMapper.updateShopperActive(b2cShopperbiTemp);
    }
    
    private HashMap qrCodeBindPlain(HttpServletRequest request) throws Exception {
        HashMap hashMap = new HashMap();
        String merchantNo = request.getParameter("merchantNo") == null ? "" : request.getParameter("merchantNo").trim();
        String qrCodeNo = request.getParameter("qrCodeNo") == null ? "" : request.getParameter("qrCodeNo").trim();

        if (merchantNo.isEmpty()) {
            hashMap.put("rspCode", MessageEnum.商户号为空.getCode());
            hashMap.put("rspMsg", MessageEnum.商户号为空.getText());
            return hashMap;
        }
        if (qrCodeNo.isEmpty()) {
            hashMap.put("rspCode", MessageEnum.二维码编号为空.getCode());
            hashMap.put("rspMsg", MessageEnum.二维码编号为空.getText());
            return hashMap;
        }

        Map map = new HashMap();
        map.put("qrCodeNo", qrCodeNo);
        B2cFixedCode b2cFixedCode = fixedCodeMapper.findFixedCodeByParam(map);

        if (b2cFixedCode == null) {
            hashMap.put("rspCode", MessageEnum.该二维码未入库.getCode());
            hashMap.put("rspMsg", MessageEnum.该二维码未入库.getText());
            return hashMap;
        }

        if (b2cFixedCode.getShopperidP() == null || "".equals(b2cFixedCode.getShopperidP())) {
            hashMap.put("rspCode", MessageEnum.该二维码未出库.getCode());
            hashMap.put("rspMsg", MessageEnum.该二维码未出库.getText());
            return hashMap;
        }

        if (b2cFixedCode.getMerchantid() != null && !"".equals(b2cFixedCode.getMerchantid())) {
            hashMap.put("rspCode", MessageEnum.二维码已被绑定.getCode());
            hashMap.put("rspMsg", MessageEnum.二维码已被绑定.getText());
            return hashMap;
        }

        hashMap = qrCodeBindMpos(qrCodeNo, merchantNo, null, null);

        return hashMap;
    }

    private HashMap qrCodeBindInvite(HttpServletRequest request) throws Exception {
        HashMap hashMap = new HashMap();
        String merchantNo = request.getParameter("merchantNo") == null ? "" : request.getParameter("merchantNo").trim(); //商户号
        String inviteCodeP = request.getParameter("inviteCodeP") == null ? "" : request.getParameter("inviteCodeP").trim().toUpperCase(); //商户邀请码
        //根据邀请码查询上级商户
        B2cShopperbiTemp b2cShopperbiTemp = b2cShopperbiTempMapper.findShopperByInviteCode(inviteCodeP);

        if (null == b2cShopperbiTemp){
            hashMap.put("rspCode", MessageEnum.邀请码不存在请确认后重输.getCode());
            hashMap.put("rspMsg", MessageEnum.邀请码不存在请确认后重输.getText());
            return hashMap;
        }


        if (merchantNo.toString().equals(b2cShopperbiTemp.getShopperid().toString())) {
            hashMap.put("rspCode", MessageEnum.不能绑定自己的邀请码.getCode());
            hashMap.put("rspMsg", MessageEnum.不能绑定自己的邀请码.getText());
            return hashMap;
        }
        List<B2cFixedCode> b2cFixedCodes = null;
        //如果上级商户没有服务商 则绑定直营服务商固码
        if(null == b2cShopperbiTemp.getShopperidP()){
            String directAgentNo = ConstantsEnv.DIRECT_AGENTNO;
            //根据服务商ID查询未被绑定固码
            b2cFixedCodes = fixedCodeMapper.findNoBindCodeByAgentNo(Long.valueOf(directAgentNo));
        } else {
            //根据服务商ID查询未被绑定固码
            b2cFixedCodes = fixedCodeMapper.findNoBindCodeByAgentNo(b2cShopperbiTemp.getShopperidP());
        }

        if (null == b2cFixedCodes || b2cFixedCodes.size() == 0) {
            hashMap.put("rspCode", MessageEnum.固码库存不足.getCode());
            hashMap.put("rspMsg", MessageEnum.固码库存不足.getText());
            return hashMap;
        }
        hashMap = qrCodeBindMpos(b2cFixedCodes.get(0).getQrCodeNo(), merchantNo, b2cShopperbiTemp, Constants.STATUS1);
        return hashMap;
    }

    private HashMap qrCodeBindDirect(HttpServletRequest request) throws Exception {
        HashMap hashMap = new HashMap();
        String merchantNo = request.getParameter("merchantNo") == null ? "" : request.getParameter("merchantNo").trim(); //商户号
        String directAgentNo = ConstantsEnv.DIRECT_AGENTNO;
        //根据服务商ID查询未被绑定固码
        List<B2cFixedCode> b2cFixedCodes = fixedCodeMapper.findNoBindCodeByAgentNo(Long.valueOf(directAgentNo));
        if (null == b2cFixedCodes || b2cFixedCodes.size() == 0) {
            hashMap.put("rspCode", MessageEnum.固码库存不足.getCode());
            hashMap.put("rspMsg", MessageEnum.固码库存不足.getText());
            return hashMap;
        }
        hashMap = qrCodeBindMpos(b2cFixedCodes.get(0).getQrCodeNo(), merchantNo, null, null);
        return hashMap;
    }

    /**
     * 调用二维码\mpos接口绑定固码 修改代理商
     * @param qrCodeNo 二维码编号
     * @param merchantNo 商户编号
     * @param supperShopperTemp 上级商户
     * @param ifInvite 是否裂变商户 1裂变 0非裂变
     * @return
     * @throws Exception
     */
    public HashMap qrCodeBindMpos(String qrCodeNo, String merchantNo, B2cShopperbiTemp supperShopperTemp, String ifInvite) throws Exception {

        HashMap hashMap = new HashMap();

        Map map = new HashMap();
        map.put("qrCodeNo", qrCodeNo);
        B2cFixedCode b2cFixedCode = fixedCodeMapper.findFixedCodeByParam(map);

        Map params = new HashMap();
        params.put("qrCode", qrCodeNo);
        params.put("smallMerchNo", merchantNo);
        net.sf.json.JSONObject obs = net.sf.json.JSONObject.fromObject(params);
        logger.info("mpos_qrcode商户绑定二维码请求参数:" + obs.toString());
        String resultString = HttpClientUtils.REpostRequestStrJson(
                ConstantsEnv.QRCODE_BIND_URL, obs.toString());
        Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);
        logger.info("商户绑定二维码响应参数:" + FastJson.fromJson(resultString));
        if (Constants.SUCCESS_CODE.equals(resultMap.get("rspCode"))) {
            //查询商户信息
            B2cShopperbi shopperbi = b2cShopperbiMapper.findFactoringNoByShopperid(merchantNo);
            //修改商户服务商
            Map params1 = new HashMap();
            params.put("merchantNo", shopperbi.getShopperid());
            params.put("agentNo", b2cFixedCode.getAgentNo());
            obs = net.sf.json.JSONObject.fromObject(params);
            logger.info("修改代理商请求参数:" + obs.toString());
            resultString = HttpClientUtils.REpostRequestStrJson(
                    ConstantsEnv.MPOS_AGENT_UPDATE_URL, obs.toString());
            resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);
            logger.info("MPOS_ACCOUNT修改代理商请求结果：" + FastJson.fromJson(resultString));

            params.put("superShopperId", supperShopperTemp == null ? null : supperShopperTemp.getShopperid());
            params.put("ifInvite", ifInvite == null ? null : ifInvite);
            obs = net.sf.json.JSONObject.fromObject(params);
            resultString = HttpClientUtils.REpostRequestStrJson(ConstantsEnv.QRCODE_AGENT_UPDATE_URL, obs.toString());
            resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);
            logger.info("QR_CODE修改代理商请求结果：" + FastJson.fromJson(resultString));

            if (Constants.SUCCESS_CODE.equals(resultMap.get("rspCode"))) {
                //查询商户已绑定二维码
                b2cFixedCode = new B2cFixedCode();
                b2cFixedCode.setMerchantid(merchantNo);
                List<B2cFixedCode> fixedCodes = fixedCodeMapper.findFixedCodesByParam(b2cFixedCode);

                //查询二维码信息
                Map map1 = new HashMap();
                map1.put("qrCodeNo", qrCodeNo);
                B2cFixedCode fixedCode = fixedCodeMapper.findFixedCodeByParam(map1);
                fixedCode.setMerchantid(merchantNo);
                fixedCode.setBindingDate(new Date());
                fixedCode.setTel(shopperbi.getStel());
                fixedCode.setScompany(shopperbi.getScompany());
                //判断是否已绑定二维码  如果没有绑定过  则二维码设为默认
                if (fixedCodes == null || fixedCodes.size() == 0) {
                    //设置二维码为默认
                    fixedCode.setIfDefault(Constants.STATUS1);
                }
                //修改二维码信息
                fixedCodeMapper.updateById(fixedCode);

                //修改商户信息中二维码信息
                Map map2 = new HashMap();
                map2.put("fixedQrCodeUrl", getQrCodeUrl(qrCodeNo));
                map2.put("fixedQrCodeFlag", Constants.CON_YES);
                map2.put("merchantNo", merchantNo);
                map2.put("agentNo", fixedCode.getAgentNo());
                map2.put("inviteCodeP", supperShopperTemp == null ? null : supperShopperTemp.getInviteCode().toUpperCase()); //上级商户邀请码

                b2cShopperbiMapper.updateQrCode(map2);
                b2cShopperbiTempMapper.updateQrCode(map2);

                hashMap.put("rspCode", MessageEnum.成功.getCode());
                hashMap.put("rspMsg", MessageEnum.成功.getText());
                hashMap.put("qrCodeUrl", getQrCodeUrl(qrCodeNo));
                return hashMap;
            } else {
                hashMap.put("rspCode", MessageEnum.出错.getCode());
                hashMap.put("rspMsg", MessageEnum.出错.getText());
                return hashMap;
            }
        } else {
            hashMap.put("rspCode", resultMap.get("rspCode"));
            hashMap.put("rspMsg", resultMap.get("rspMsg"));
            return hashMap;
        }
    }

    /**
     * 密钥处理
     *
     * @param qrCode
     * @return
     */
    public String getQrCodeUrl(String qrCode) {
        StringBuffer sBuffer = new StringBuffer();
        sBuffer.append(qrCode);
        sBuffer.append(ConstantsEnv.MERCHANTKEY);
        String smacs = Md5Encrypt.md5(sBuffer.toString());

        return ConstantsEnv.Fixed_Qr_Code_Url + "qrCode=" + qrCode + "&mac=" + smacs;
    }

}
