package com.uns.web;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uns.common.Constants;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.myenum.MessageEnum;
import com.uns.dao.B2cDictMapper;
import com.uns.dao.B2cShopperbiTempMapper;
import com.uns.model.B2cDict;
import com.uns.model.B2cShopperbiTemp;
import com.uns.util.HkMerchantUtils;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uns.bean.OCRCreditCardInfoBean;
import com.uns.bean.OCRDebitCardInfoBean;
import com.uns.bean.OCRIdCardInfoBean;
import com.uns.model.MposMerchantFee;
import com.uns.model.SweepCodeProduct;
import com.uns.service.AppOpenRegOCRService;
import com.uns.service.AppOpenRegService;

/**
 * 实名认证2.3.0
 * @author Administrator
 *
 */

@Controller
@RequestMapping(value = "/appOpenRegOCR")
@SuppressWarnings({ "rawtypes", "unchecked" })
public class AppOpenRegOCRController  extends BaseController {
	
	@Autowired
	private AppOpenRegOCRService appOpenRegOCRService;
	
	/**
	 * 上传身份证信息
	 * @throws Exception 
	 */
	@Transactional(rollbackFor = Exception.class)
	@RequestMapping(value = "uploadIdCardInfo.htm")
	public void uploadIdCardInfo(HttpServletRequest request,HttpServletResponse response) throws Exception{
		HashMap hashMap = new HashMap();
		JSONObject json = null;
		response.setContentType(Constants.CONTENT_TYPE_UTF8);
		try {
			hashMap = appOpenRegOCRService.uploadIdCardInfo(request);
			json = JSONObject.fromObject(hashMap);
			log.info("上传身份证信息验证:"+json.toString());
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put(Constants.RSP_CODE, MessageEnum.出错.getCode());
			hashMap.put(Constants.RSP_MSG, MessageEnum.出错.getText());
		}finally {
			response.getWriter().write(json.toString());
		}
	}

	/**
	 * 身份证补件
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@Transactional(rollbackFor = Exception.class)
	@RequestMapping(value = "updateIdCardInfo.htm")
	public void updateIdCardInfo(HttpServletRequest request,HttpServletResponse response) throws IOException {
		HashMap hashMap = new HashMap();
		JSONObject json = null;
		response.setContentType(Constants.CONTENT_TYPE_UTF8);
		try {
			hashMap = appOpenRegOCRService.updateIdCardInfo(request);
			json = JSONObject.fromObject(hashMap);
			log.info("更新身份证信息验证:"+json.toString());
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put(Constants.RSP_CODE, MessageEnum.出错.getCode());
			hashMap.put(Constants.RSP_MSG, MessageEnum.出错.getText());
		}finally {
			response.getWriter().write(json.toString());
		}
	}
	
	/**
	 * 上传结算卡（借记卡）信息
	 */
	@Transactional(rollbackFor = Exception.class)
	@RequestMapping(value = "uploadDebitCardInfo.htm")
	public void uploadDebitCardInfo(HttpServletRequest request,HttpServletResponse response) throws IOException{
		HashMap hashMap = new HashMap();
		JSONObject json = null;
		response.setContentType(Constants.CONTENT_TYPE_UTF8);
		try {
			hashMap = appOpenRegOCRService.uploadDebitCardInfo(request);
			json = JSONObject.fromObject(hashMap);
			log.info("上传结算卡信息验证:"+json.toString());
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put(Constants.RSP_CODE, MessageEnum.出错.getCode());
			hashMap.put(Constants.RSP_MSG, MessageEnum.出错.getText());
		}finally {
			response.getWriter().write(json.toString());
		}
	}
	
	/**
	 * 上传贷记卡信息
	 */
	@Transactional(rollbackFor = Exception.class)
	@RequestMapping(value = "uploadCreditCardInfo.htm")
	public void uploadCreditCardInfo(HttpServletRequest request,HttpServletResponse response) throws IOException{
		HashMap hashMap = new HashMap();
		JSONObject json = null;
		response.setContentType(Constants.CONTENT_TYPE_UTF8);
		try {
			hashMap = appOpenRegOCRService.uploadCreditCardInfo(request);
			json = JSONObject.fromObject(hashMap);
			log.info("上传贷记卡信息验证:"+json.toString());
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put(Constants.RSP_CODE, MessageEnum.出错.getCode());
			hashMap.put(Constants.RSP_MSG, MessageEnum.出错.getText());
		}finally {
			response.getWriter().write(json.toString());
		}
	}
	
	/**
	 * 跳转签名界面前费率查询
	 */
	@RequestMapping(value = "getMposMerchantFee.htm")
    public void getMposMerchantFee(HttpServletRequest request,HttpServletResponse response) throws IOException{
        response.setContentType(Constants.CONTENT_TYPE_UTF8);
        List<SweepCodeProduct> mposMerchantFeeList = appOpenRegOCRService.getSweepCodeProduct();
        JSONArray jsonArray = JSONArray.fromObject(mposMerchantFeeList);
        log.info("跳转签名界面前费率查询验证:"+jsonArray.toString());
        response.getWriter().write(jsonArray.toString());
    }
	
	/**
	 * 默认费率插入and商户完成注册（点击提交签名之后）
	 * @throws Exception 
	 */
	@Transactional(rollbackFor = Exception.class)
	@RequestMapping(value = "uploadSignInfo.htm")
	public void uploadSignInfo(HttpServletRequest request,HttpServletResponse response) throws Exception{
		HashMap hashMap = new HashMap();
		JSONObject json = null;
		response.setContentType(Constants.CONTENT_TYPE_UTF8);
		try {
			hashMap = appOpenRegOCRService.saveConfirmInfo(request);
			json = JSONObject.fromObject(hashMap);
			log.info("上传签名和费率确认信息验证:"+json.toString());
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put(Constants.RSP_CODE, MessageEnum.出错.getCode());
			hashMap.put(Constants.RSP_MSG, MessageEnum.出错.getText());
		}finally {
			response.getWriter().write(json.toString());
		}
	}

	@Autowired
	private B2cShopperbiTempMapper b2cShopperbiTempMapper;

	@Autowired
	private B2cDictMapper b2cDictMapper;

	@Autowired
	private HkMerchantUtils hkMerchantUtils;

	@RequestMapping(value = "hkReport.htm")
	public void hkReport() {
		B2cShopperbiTemp b2cShopperbiTemp = b2cShopperbiTempMapper.findShopperbiTempByShopperid("800111000017862");
		B2cDict b2cDict = b2cDictMapper.findDictBankName(b2cShopperbiTemp.getAccountbankdictval());
		try {
			hkMerchantUtils.updateHkMerchantPort(b2cShopperbiTemp, b2cDict);
			/*hkMerchantUtils.queryJq(b2cShopperbiTemp);*/
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 获取错误OCR步骤
	 * @param request  
	 * @param response
	 * @throws IOException
	 */
	@Transactional(rollbackFor = Exception.class)
	@RequestMapping(value = "getNotPassStep.htm")
	public void getNotPassStep(HttpServletRequest request, HttpServletResponse response) throws IOException {
		HashMap hashMap = new HashMap();
		JSONObject json = null;
		response.setContentType(Constants.CONTENT_TYPE_UTF8);
		try {
			hashMap = appOpenRegOCRService.getNotPassStep(request);
			json = JSONObject.fromObject(hashMap);
			log.info("查询OCR错误步骤接口验证:"+json.toString());
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put(Constants.RSP_CODE, MessageEnum.出错.getCode());
			hashMap.put(Constants.RSP_MSG, MessageEnum.出错.getText());
		}finally {
			response.getWriter().write(json.toString());
		}
	}

	@RequestMapping(value = "merchantAuthenticationQuery.htm")
	public void merchantAuthenticationQuery (HttpServletRequest request, HttpServletResponse response) throws IOException {
		HashMap hashMap = new HashMap();
		JSONObject json = null;
		response.setContentType(Constants.CONTENT_TYPE_UTF8);
		try {
			String res = hkMerchantUtils.queryJq(request.getParameter("merchantNo"));
			hashMap.put("rspMsg", res);
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put(Constants.RSP_CODE, MessageEnum.出错.getCode());
			hashMap.put(Constants.RSP_MSG, MessageEnum.出错.getText());
		}finally {
			response.getWriter().write(json.toString());
		}
	}

}
