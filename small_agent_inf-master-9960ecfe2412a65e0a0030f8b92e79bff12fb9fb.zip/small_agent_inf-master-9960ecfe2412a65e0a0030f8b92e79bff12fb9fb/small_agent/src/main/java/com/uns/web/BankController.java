package com.uns.web;

import com.uns.model.SupportBankForm;
import com.uns.service.BankService;
import com.uns.util.FastJson;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping(value = "/bankController.htm")
public class BankController extends BaseController {
	@Autowired
	private BankService bankservice;
	
	
	/**
	 * 查询银行信息
	 * 
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(params ="method=querybank")
	public void querybank(HttpServletRequest request,HttpServletResponse response) throws IOException {
		Map hashMap = new HashMap();
		try {
			List list=bankservice.queryBank();
			hashMap.put("bank", list);    
			hashMap.put("rspCode", "0000");
			hashMap.put("rspMsg", "银行信息查询成功");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("银行信息查询成功:" + json.toString());
			response.getWriter().write(json.toString());

		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "银行信息查询失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("银行信息查询出错:" + json.toString());
			response.getWriter().write(json.toString());
		}

	}
	
	
	/**
	 * @param request
	 * @param response  其他银行信息接口
	 * @throws IOException
	 */
	@RequestMapping(params ="method=querybankother")
	public void querybankother(HttpServletRequest request,HttpServletResponse response) throws IOException {
		Map hashMap = new HashMap();
		try {
			List list=bankservice.queryBank();
			hashMap.put("bank", list);    
			hashMap.put("rspCode", "0000");
			hashMap.put("rspMsg", "查询成功");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("查询成功:" + json.toString());
			response.getWriter().write(json.toString());

		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "查询失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("查询出错:" + json.toString());
			response.getWriter().write(json.toString());
		}

	}
	
	/**
	 * 查询支行信息
	 * 
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(params = "method=querybankbranch")
	public void querybankbranch(HttpServletRequest request,HttpServletResponse response) throws IOException {
		Map hashMap = new HashMap();
		try {
			String city = URLDecoder.decode(request.getParameter("city") == null ? "" : request.getParameter("city"), "UTF-8");
			String province=URLDecoder.decode(request.getParameter("province") == null ? "" : request.getParameter("province"), "UTF-8");
			String bankname=URLDecoder.decode(request.getParameter("bankname") == null ? "" : request.getParameter("bankname"), "UTF-8");
			List list=bankservice.searchBankBranch(city, province, bankname);
			hashMap.put("bankbranch", list);    
			hashMap.put("rspCode", "0000");
			hashMap.put("rspMsg", "银行支行信息查询成功");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("银行支行信息查询成功:" + json.toString());
			response.getWriter().write(json.toString());

		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "银行支行信息查询失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("银行支行信息查询出错:" + json.toString());
			response.getWriter().write(json.toString());
		}

	}


	/**
	 * 查询快捷支持银行列表
	 *
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(params = "method=querySupportBank")
	@ResponseBody
	public Map querySupportBank(HttpServletRequest request,HttpServletResponse response) throws Exception{
		Map map = new HashMap();
		try {
			List<SupportBankForm> list =  bankservice.querySupportBankList();
			map.put("supportBank",list);
			map.put("rspCode","0000");
			map.put("rspMsg","快捷支持银行列表查询成功");
			log.info("快捷支持银行列表查询成功:" + FastJson.toJson(map));
		} catch (Exception e){
			e.printStackTrace();
			map.put("rspCode","2222");
			map.put("rspMsg","查询失败");
			log.info("快捷支持银行列表查询出错:" +FastJson.toJson(map));
		}

		return map;
	}
	
}
