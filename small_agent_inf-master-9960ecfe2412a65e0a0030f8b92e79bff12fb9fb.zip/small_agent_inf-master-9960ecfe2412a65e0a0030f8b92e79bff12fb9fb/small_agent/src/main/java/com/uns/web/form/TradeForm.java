package com.uns.web.form;

import com.uns.model.B2cTranhis;

public class TradeForm extends B2cTranhis{

	private static final long serialVersionUID = 1L;
	
	private String ser_shopperid;
	private String ser_shopperids;
	private String ser_tranid;
	private String ser_oldtranid;
	private String ser_cardno;
	private String ser_terminalid;
	private String ser_transtart;
	private String ser_tranend;
	private String ser_trantype;
	private String ser_tranflag;
	private String ser_amount_start;
	private String ser_amount_end;
	private String ser_bankfee_start;
	private String ser_bankfee_end;
	
	private String[] ser_real_posids;
	private String ser_real_tranid;
	private String ser_agentid;
	
	public String getSer_agentid() {
		return ser_agentid;
	}
	public void setSer_agentid(String ser_agentid) {
		this.ser_agentid = ser_agentid.trim();
	}
	public String getSer_shopperid() {
		return ser_shopperid;
	}
	public void setSer_shopperid(String ser_shopperid) {
		this.ser_shopperid = ser_shopperid.trim();
	}
	public String getSer_shopperids() {
		return ser_shopperids;
	}
	public void setSer_shopperids(String ser_shopperids) {
		this.ser_shopperids = ser_shopperids.trim();
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getSer_tranid() {
		return ser_tranid;
	}
	public void setSer_tranid(String ser_tranid) {
		this.ser_tranid = ser_tranid.trim();
	}
	public String getSer_oldtranid() {
		return ser_oldtranid;
	}
	public void setSer_oldtranid(String ser_oldtranid) {
		this.ser_oldtranid = ser_oldtranid.trim();
	}
	public String getSer_cardno() {
		return ser_cardno;
	}
	public void setSer_cardno(String ser_cardno) {
		this.ser_cardno = ser_cardno.trim();
	}
	public String getSer_terminalid() {
		return ser_terminalid;
	}
	public void setSer_terminalid(String ser_terminalid) {
		this.ser_terminalid = ser_terminalid.trim();
	}
	public String getSer_transtart() {
		return ser_transtart;
	}
	public void setSer_transtart(String ser_transtart) {
		this.ser_transtart = ser_transtart.trim();
	}
	public String getSer_tranend() {
		return ser_tranend;
	}
	public void setSer_tranend(String ser_tranend) {
		this.ser_tranend = ser_tranend.trim();
	}
	public String getSer_trantype() {
		return ser_trantype;
	}
	public void setSer_trantype(String ser_trantype) {
		this.ser_trantype = ser_trantype.trim();
	}
	public String getSer_tranflag() {
		return ser_tranflag;
	}
	public void setSer_tranflag(String ser_tranflag) {
		this.ser_tranflag = ser_tranflag.trim();
	}
	public String getSer_amount_start() {
		return ser_amount_start;
	}
	public void setSer_amount_start(String ser_amount_start) {
		this.ser_amount_start = ser_amount_start.trim();
	}
	public String getSer_amount_end() {
		return ser_amount_end;
	}
	public void setSer_amount_end(String ser_amount_end) {
		this.ser_amount_end = ser_amount_end.trim();
	}
	public String getSer_bankfee_start() {
		return ser_bankfee_start;
	}
	public void setSer_bankfee_start(String ser_bankfee_start) {
		this.ser_bankfee_start = ser_bankfee_start.trim();
	}
	public String getSer_bankfee_end() {
		return ser_bankfee_end;
	}
	public void setSer_bankfee_end(String ser_bankfee_end) {
		this.ser_bankfee_end = ser_bankfee_end.trim();
	}
	public String[] getSer_real_posids() {
		return ser_real_posids;
	}
	public void setSer_real_posids(String[] ser_real_posids) {
		this.ser_real_posids = ser_real_posids;
	}
	public String getSer_real_tranid() {
		return ser_real_tranid;
	}
	public void setSer_real_tranid(String ser_real_tranid) {
		this.ser_real_tranid = ser_real_tranid.trim();
	} 
	
}
