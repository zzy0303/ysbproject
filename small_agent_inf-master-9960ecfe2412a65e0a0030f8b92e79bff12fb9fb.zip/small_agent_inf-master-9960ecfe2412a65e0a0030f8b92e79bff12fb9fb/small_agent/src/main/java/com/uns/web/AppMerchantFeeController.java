package com.uns.web;

import com.uns.common.Constants;
import com.uns.model.B2cShopperbiTemp;
import com.uns.service.MposRemoteFeeService;
import com.uns.service.MposmerchantfeeService;
import com.uns.service.ShopPerbiService;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author peng.du
 *费率查询表
 */
@Controller
@RequestMapping(value = "/appMerchantFee.htm")
public class AppMerchantFeeController extends BaseController {
	
	@Autowired
	private ShopPerbiService shopPerbiService;
	
	@Autowired
	private MposRemoteFeeService mposRemoteFeeService;
	
	@Autowired
	private MposmerchantfeeService mposmerchantfeeService;
	
	
	/**
	 * 查询手续费费率
	 *
	 * 2018-08-22 新加商户认证手续费费率(version:2.4.0)
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(params = "method=findMerchantFee")
	public void findMerchantFee(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String version = request.getParameter("version") == null ? "" : request.getParameter("version");
		String merchantType = request.getParameter("merchantType")==null?"":request.getParameter("merchantType").trim();

		if(Constants.VERSION_2_4_0.equals(version) && Constants.TYPE_2.equals(merchantType)){
			findMerchantFee240(request, response);
		}else{
			findMerchantFee220(request, response);
		}
		
	}


	private void findMerchantFee220(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String type = request.getParameter("type") == null ? "" : request.getParameter("type");
		if ((Constants.TYPE_A).equals(type)) {
			merchantFee220A(request, response);
		} else if ((Constants.TYPE_I).equals(type)) {
			merchantFee220I(request, response);
		}
		
	}


	private void merchantFee220I(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Map hashMap = new HashMap();
		try {
			String tel = request.getParameter("tel")==null?"":request.getParameter("tel").trim();
			if(StringUtils.isNotEmpty(tel)){
				B2cShopperbiTemp b2cShopperbiTemp = shopPerbiService.findbytel(tel);
				if(b2cShopperbiTemp!=null){
					List mposmerchantfeeList=mposmerchantfeeService.mposmerchantfeelist(b2cShopperbiTemp.getShopperid()+"");
					hashMap.put("mposmerchantfeeList", mposmerchantfeeList);
					List smMerchantFeeList=mposmerchantfeeService.findsmMerchantFeelist(b2cShopperbiTemp.getShopperid()+"");
					hashMap.put("merchantfeeList", smMerchantFeeList);
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "查询成功");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("查询费率ios:" + json.toString());
					response.getWriter().write(json.toString());
					return ;
				}else{
					List mposRemoteFeeList=mposRemoteFeeService.remotefeeList(tel);
					hashMap.put("merchantfeeList", mposRemoteFeeList);
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "查询成功");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("查询费率ios:" + json.toString());
					response.getWriter().write(json.toString());
					return ;
					
				}
			}else{
				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "参数错误");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("查询费率ios:" + json.toString());
				response.getWriter().write(json.toString());
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "系统错误");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("查询费率ios:" + json.toString());
			response.getWriter().write(json.toString());
		}
		
	}


	private void merchantFee220A(HttpServletRequest request, HttpServletResponse response) throws IOException {
		Map hashMap = new HashMap();
		try {
			String tel = request.getParameter("tel")==null?"":request.getParameter("tel").trim();

			if(StringUtils.isNotEmpty(tel)){
				B2cShopperbiTemp b2cShopperbiTemp = shopPerbiService.findbytel(tel);
				if(b2cShopperbiTemp!=null){
					List mposmerchantfeeList=mposmerchantfeeService.mposmerchantfeelist(b2cShopperbiTemp.getShopperid()+"");
					hashMap.put("mposmerchantfeeList", mposmerchantfeeList);
					List smMerchantFeeList=mposmerchantfeeService.findsmMerchantFeelist(b2cShopperbiTemp.getShopperid()+"");
					hashMap.put("merchantfeeList", smMerchantFeeList);
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "查询成功");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("查询费率android:" + json.toString());
					response.getWriter().write(json.toString());
					return ;
				}else{
					List mposRemoteFeeList=mposRemoteFeeService.remotefeeList(tel);
					hashMap.put("merchantfeeList", mposRemoteFeeList);
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "查询成功");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("查询费率android:" + json.toString());
					response.getWriter().write(json.toString());
					return ;
					
				}
			}else{
				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "参数错误");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("查询费率android:" + json.toString());
				response.getWriter().write(json.toString());
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "系统错误");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("查询费率android:" + json.toString());
			response.getWriter().write(json.toString());
		}
		
	}


	/**
	 * 版本 2.0.1
	 * @param request
	 * @param response
	 * @throws Exception 
	 */
	private void findMerchantFee201(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String type = request.getParameter("type") == null ? "" : request.getParameter("type");
		if ((Constants.TYPE_A).equals(type)) {
			merchantFee201A(request, response);
		} else if ((Constants.TYPE_I).equals(type)) {
			merchantFee201I(request, response);
		}
		
	}


	private void merchantFee201I(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Map hashMap = new HashMap();
		try {
			String tel = request.getParameter("tel")==null?"":request.getParameter("tel").trim();
			if(StringUtils.isNotEmpty(tel)){
				B2cShopperbiTemp b2cShopperbiTemp=shopPerbiService.findbytel(tel);
				if(b2cShopperbiTemp!=null){
					List mposmerchantfeeList=mposmerchantfeeService.merchantfeelist201(b2cShopperbiTemp.getShopperid()+"");
					hashMap.put("merchantfeeList", mposmerchantfeeList);
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "查询成功");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("查询费率ios:" + json.toString());
					response.getWriter().write(json.toString());
					return ;
				}else{
					List mposRemoteFeeList=mposRemoteFeeService.remotefeeList(tel);
					hashMap.put("merchantfeeList", mposRemoteFeeList);
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "查询成功");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("查询费率ios:" + json.toString());
					response.getWriter().write(json.toString());
					return ;
					
				}
			}else{
				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "参数错误");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("查询费率ios:" + json.toString());
				response.getWriter().write(json.toString());
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "系统错误");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("查询费率ios:" + json.toString());
			response.getWriter().write(json.toString());
		}
		
		
	}


	private void merchantFee201A(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		Map hashMap = new HashMap();
		try {
			String tel = request.getParameter("tel")==null?"":request.getParameter("tel").trim();
			if(StringUtils.isNotEmpty(tel)){
				B2cShopperbiTemp b2cShopperbiTemp=shopPerbiService.findbytel(tel);
				if(b2cShopperbiTemp!=null){
					List mposmerchantfeeList=mposmerchantfeeService.merchantfeelist201(b2cShopperbiTemp.getShopperid()+"");
					hashMap.put("merchantfeeList", mposmerchantfeeList);
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "查询成功");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("查询费率android:" + json.toString());
					response.getWriter().write(json.toString());
					return ;
				}else{
					List mposRemoteFeeList=mposRemoteFeeService.remotefeeList(tel);
					hashMap.put("merchantfeeList", mposRemoteFeeList);
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "查询成功");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("查询费率android:" + json.toString());
					response.getWriter().write(json.toString());
					return ;
					
				}
			}else{
				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "参数错误");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("查询费率android:" + json.toString());
				response.getWriter().write(json.toString());
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "系统错误");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("查询费率android:" + json.toString());
			response.getWriter().write(json.toString());
		}
		
	}

	/**
	 * 聚合支付版
	 * 查询商户手续费费率
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	private void findMerchantFee240(HttpServletRequest request, HttpServletResponse response) throws IOException {
		Map hashMap = new HashMap();
		JSONObject json = new JSONObject();
		try {
			String tel = request.getParameter("tel")==null?"":request.getParameter("tel").trim();
			if(StringUtils.isNotEmpty(tel)){
				B2cShopperbiTemp b2cShopperbiTemp = shopPerbiService.findByAggteltemp(tel);
				if(b2cShopperbiTemp!=null){
					List mposmerchantfeeList=mposmerchantfeeService.aggMerchantFeeList(b2cShopperbiTemp.getShopperid()+"");
					hashMap.put("mposmerchantfeeList", mposmerchantfeeList);
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "查询成功");
				}else{
					hashMap.put("rspCode","1222");
					hashMap.put("rspMsg","查询费率有误，请核实前面步骤是否成功");
				}
			}else{
				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "参数错误");
			}
			response.setContentType("UTF-8");
			json = JSONObject.fromObject(hashMap);
			log.info("查询商户版费率:" + json.toString());
			response.getWriter().write(json.toString());
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "系统错误");
			json = JSONObject.fromObject(hashMap);
			log.info("查询费率:" + json.toString());
			response.getWriter().write(json.toString());
		}

	}

}
