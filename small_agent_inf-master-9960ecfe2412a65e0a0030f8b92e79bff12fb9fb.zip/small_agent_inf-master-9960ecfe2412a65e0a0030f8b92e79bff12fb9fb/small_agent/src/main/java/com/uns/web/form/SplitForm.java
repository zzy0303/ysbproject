package com.uns.web.form;

import com.uns.common.Constants;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Date;

public class SplitForm {
	private BigDecimal id;
	private String ids;
	private String shopperidp;
	private String scompany;
	private Date startDate;
	private Date endDate;
	private String status;
	private String batchNo;
	private String transType;
	private String replyHis;
	private String reply;
	private String doubt;
	private String doubtHis;
	private String doubtId;
	private String type;
	private String ifDownload;
	private String sessionUserNo;
	private String contact;
	private Date createDate;
	
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public String getDoubt() {
		return doubt;
	}
	public void setDoubt(String doubt) {
		this.doubt = doubt;
	}
	public String getSessionUserNo() {
		return sessionUserNo;
	}
	public void setSessionUserNo(String sessionUserNo) {
		this.sessionUserNo = sessionUserNo;
	}
	public String getIfDownload() {
		return ifDownload;
	}
	public void setIfDownload(String ifDownload) {
		this.ifDownload = ifDownload;
	}
	public String getReplyHis() {
		return replyHis;
	}
	public void setReplyHis(String replyHis) {
		this.replyHis = replyHis;
	}
	public String getDoubtHis() {
		return doubtHis;
	}
	public void setDoubtHis(String doubtHis) {
		this.doubtHis = doubtHis;
	}
	public String getIds() {
		return ids;
	}
	public void setIds(String ids) {
		this.ids = ids;
	}
	public BigDecimal getId() {
		return id;
	}
	public void setId(BigDecimal id) {
		this.id = id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDoubtId() {
		return doubtId;
	}
	public void setDoubtId(String doubtId) {
		this.doubtId = doubtId;
	}
	public String getTransType() {
		return transType;
	}
	public void setTransType(String transType) {
		this.transType = transType;
	}
	public String getShopperidp() {
		return shopperidp;
	}
	public void setShopperidp(String shopperidp) {
		this.shopperidp = shopperidp;
	}
	public String getScompany() {
		return scompany;
	}
	public void setScompany(String scompany) {
		this.scompany = scompany;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		if(endDate != null && !"".equals(endDate)){
			String tmp = Constants.SF_YYYYMMDD.format(endDate);
			try {
				endDate = Constants.SF_YYYYMMDDHHMMSS.parse(tmp + "235959");
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		this.endDate = endDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getBatchNo() {
		return batchNo;
	}
	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}
	public String getReply() {
		return reply;
	}
	public void setReply(String reply) {
		this.reply = reply;
	}
	
}
