package com.uns.dao;

import com.uns.model.MtOperateLog;
import com.uns.web.form.OperateLogForm;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MtOperateLogMapper {

    List<MtOperateLog> selectAccesslogList(OperateLogForm form);

    boolean insert(MtOperateLog record);

    MtOperateLog selectByPrimaryKey(String logid);
}