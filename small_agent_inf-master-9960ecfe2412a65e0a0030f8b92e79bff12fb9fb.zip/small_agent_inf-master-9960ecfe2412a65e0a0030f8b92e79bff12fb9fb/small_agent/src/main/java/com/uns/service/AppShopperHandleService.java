package com.uns.service;

import com.uns.common.myenum.MessageEnum;
import com.uns.dao.B2cShopperbiMapper;
import com.uns.dao.B2cShopperbiTempMapper;
import com.uns.model.B2cShopperbi;
import com.uns.model.B2cShopperbiTemp;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2017/6/29.
 */
@Service
public class AppShopperHandleService {

    @Autowired
    private B2cShopperbiMapper b2cShopperbiMapper;

    @Autowired
    private B2cShopperbiTempMapper b2cShopperbiTempMapper;

    public HashMap inviteHandle() throws Exception {
        HashMap hashMap = new HashMap();
        //查询无邀请码存量商户
        List<B2cShopperbi> b2cShopperbis = b2cShopperbiMapper.findNoInvite();
        //查询已存在邀请码
        List<String> inviteCodes = b2cShopperbiMapper.findAllInviteCode();
        String inviteCode;
        Map<String, Object> param = null;
        for (B2cShopperbi b2cShopperbi : b2cShopperbis) {
            inviteCode = getShopperInviteCode(inviteCodes);
            inviteCodes.add(inviteCode);
            param = new HashMap<>();
            param.put("shopperid", b2cShopperbi.getShopperid());
            param.put("inviteCode", inviteCode);
            b2cShopperbiMapper.updateInviteCode(param);
            b2cShopperbiTempMapper.updateInviteCode(param);
        }
        hashMap.put("rspCode", MessageEnum.成功.getCode());
        hashMap.put("rspMsg", MessageEnum.成功.getText());
        return hashMap;
    }

    private String getShopperInviteCode(List<String> inviteCodes) throws Exception {
        String inviteCode = "";
        while (1==1){
            String inviteCode1 = RandomStringUtils.random(2, "ABCDEFGHJKMNPQRSTUVWXYZ");
			String inviteCode2 = String.valueOf((int)((Math.random()*9+1)*100000));
			inviteCode=inviteCode1+inviteCode2;
            if (!inviteCodes.contains(inviteCode)){
                break;
            }
        }
        return inviteCode;
    }
}
