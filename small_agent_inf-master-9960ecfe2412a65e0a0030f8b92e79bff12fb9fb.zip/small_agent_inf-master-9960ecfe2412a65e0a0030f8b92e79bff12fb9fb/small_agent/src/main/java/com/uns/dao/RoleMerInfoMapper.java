package com.uns.dao;

import com.uns.model.RoleMerInfo;
import com.uns.web.form.RoleForm;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface RoleMerInfoMapper {
   
    int deleteByPrimaryKey(Long id);
   
    int insert(RoleMerInfo record);
   
    int insertSelective(RoleMerInfo record);

    RoleMerInfo selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(RoleMerInfo record);

    int updateByPrimaryKey(RoleMerInfo record);
    //查询角色列表
	List selectRoleMerList(RoleForm mbForm);
	//验证角色名
	List<RoleMerInfo> selectByMap(Map map);

	List<RoleMerInfo> selectRoleInfo(String status);
	
	List<RoleMerInfo> selectByRoleInfo();
	
}