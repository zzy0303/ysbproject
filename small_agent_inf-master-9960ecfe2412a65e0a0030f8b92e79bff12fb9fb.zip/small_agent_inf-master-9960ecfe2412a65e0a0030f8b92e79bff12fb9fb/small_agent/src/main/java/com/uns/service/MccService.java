package com.uns.service;

import com.uns.dao.MccMapper;
import com.uns.model.Mcc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MccService {
	@Autowired
	private MccMapper mccMapper;

	/*
	 * 遍历mcc
	 */
	public List<Mcc> searchMcc() {
		return mccMapper.searchMcc();
	}
	
}
