package com.uns.web;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.inf.notify.request.NotifyResult;
import com.uns.model.B2cShopperbi;
import com.uns.service.SendMessageService;
import com.uns.service.ShopPerbiService;
import com.uns.util.Md5Encrypt;
import com.uns.util.SmsReturnObj;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Controller
@RequestMapping(value = "/appSmsController.htm")
public class AppSmsController extends BaseController {
	
	@Autowired
	private ShopPerbiService shopPerbiService;
	@Autowired
	private SendMessageService sendMessageService;
	
	
	/**发送短信通道
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(params = "method=sendAppTranSms")
	public void sendAppTranSms(HttpServletRequest request,HttpServletResponse response) throws Exception{
		Map hashMap = new HashMap();
		Map map=new HashMap();
		String version=request.getParameter("version");
		String type =request.getParameter("type");
		String shopperid =request.getParameter("shopperid");
		String tel=request.getParameter("tel");
		String batch_number=request.getParameter("batch_number");//批次号
		String pos_traceno=request.getParameter("pos_traceno");//pos流水号
		String merchant_no=request.getParameter("merchant_no");//大商户号
		String termianl_no=request.getParameter("termianl_no");//终端号
		String mac=request.getParameter("mac");
		try {
			B2cShopperbi b2cShopperbi=shopPerbiService.selectFormalShopperId(shopperid);
			if(b2cShopperbi!=null){
				String md5mac=getSendAppSmsMac(shopperid,b2cShopperbi.getMerchantKey(),tel,
						batch_number,pos_traceno,merchant_no,termianl_no);
				if(md5mac.equals(mac)){
					    Map transvalidateMap=transvalidateSms(batch_number,pos_traceno,merchant_no,termianl_no);
					    String rspCode=transvalidateMap.get("rspCode")==null?"":transvalidateMap.get("rspCode").toString();
					  	String rspMsg=transvalidateMap.get("rspMsg")==null?"":URLDecoder.decode(transvalidateMap.get("rspMsg").toString(),"UTF-8");
						if(Constants.SUCCESS_CODE.equals(rspCode)){
							  String tranId=transvalidateMap.get("tranId")==null?"":transvalidateMap.get("tranId").toString();
							  String trannumber=transvalidateMap.get("trannumber")==null?"":transvalidateMap.get("trannumber").toString();
							  String tranDate=transvalidateMap.get("tranDate")==null?"":transvalidateMap.get("tranDate").toString();
							  String tranTime=transvalidateMap.get("tranTime")==null?"":transvalidateMap.get("tranTime").toString();
							  Double amount=(Double) (transvalidateMap.get("amount")==null?"":Double.parseDouble(transvalidateMap.get("amount").toString())/100);
							  if(StringUtils.isNotEmpty(tranDate)){
								  tranDate=tranDate.substring(0, 4)+"-"+tranDate.substring(4, 6)+"-"+tranDate.substring(6, 8);
							  }
							  if(StringUtils.isNotEmpty(tranTime)){
								  tranTime=tranTime.substring(0, 2)+":"+tranTime.substring(2, 4)+":"+tranTime.substring(4, 6);
							  }
							  
							  map.put("tel", tel);
							  map.put("tranId", tranId);
							  map.put("tranDate", tranDate);
							  map.put("tranTime", tranTime);
							  map.put("amount", amount);
							  map.put("name", b2cShopperbi.getName());
							Map returnMap=null;
							if(Constants.TYPE_A.equals(type)){
								returnMap=sendAppAndroidTranSms(request,response,map);
							}else{
								returnMap=sendAppIsoTranSms(request,response,map);
							}
							List failureMsg=(List)returnMap.get("sms_failure_key");
							List successMsg=(List)returnMap.get("sms_success_key");
							if(failureMsg.size()>0){
								hashMap.put("rspCode", "1115");
								hashMap.put("rspMsg", "短信发送失败");
							}
							if(successMsg.size()>0){	
								SmsReturnObj smsReturnObj=(SmsReturnObj)successMsg.get(0);
								String returnCode=smsReturnObj.getReturnCode();
								if(Constants.STATUS0.equals(returnCode)){
									hashMap.put("rspCode", "0000");
									hashMap.put("rspMsg", "短信发送成功");
								}else{
									hashMap.put("rspCode", "1114");
									hashMap.put("rspMsg", "短信发送失败");
									
								}
							}
						}else{
							hashMap.put("rspCode", rspCode);
							hashMap.put("rspMsg", rspMsg);
						}
					}else {
						hashMap.put("rspCode", "3331");
						hashMap.put("rspMsg", "mac验证失败");
					}
				}else{
					hashMap.put("rspCode", "1116");
					hashMap.put("rspMsg", "该商户不存在");
			}
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("app发送短信:" + json.toString());
			response.getWriter().write(json.toString());
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "发送短信错误");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("app发送短信:" + json.toString());
			response.getWriter().write(json.toString());
		}

	}


	private Map transvalidateSms(String batch_number, String pos_traceno,
			String merchant_no, String termianl_no) throws Exception {
		Map regMap=new HashMap();
		
		regMap.put("batch_number", batch_number);
		regMap.put("pos_traceno",pos_traceno);
		regMap.put("merchant_no",merchant_no);
		regMap.put("termianl_no", termianl_no);
		
		JSONObject obs = JSONObject.fromObject(regMap);
		String url= ConstantsEnv.TRANS_VALIDATE_SMS+obs.toString()+"";
		org.apache.http.client.HttpClient httpclient=new DefaultHttpClient();
		url=url.replace("\"", "%22");
		url=url.replace("{", "%7B");
		url=url.replace("}", "%7D");
		HttpPost httpget=new HttpPost(url);
		
		HttpResponse httprespone;
		
		httprespone = httpclient.execute(httpget);
		
		String str = EntityUtils.toString(httprespone.getEntity());
		Map map1 = com.uns.util.JsonUtil.jsonStrToMap(str);
		return map1;
	}


	public Map sendAppIsoTranSms(HttpServletRequest request,
			HttpServletResponse response, Map maps) throws BusinessException {
		Map map = new HashMap();
		List successList = new ArrayList();//成功List
		List failureList = new ArrayList();//失败List
		map.put(Constants.SMS_SUCCESS_KEY,successList);
		map.put(Constants.SMS_FAILURE_KEY,failureList);
		try {
			Map<String,String> params = new HashMap<String,String>();
			String content=getContentapp(ConstantsEnv.SMS_APP_CONTENT_TRAN,params,maps);
			String tel = maps.get("tel").toString();
			SmsReturnObj smsReturnObj = new SmsReturnObj();
			smsReturnObj.setMobile(tel);
			smsReturnObj.setContent(content);
			NotifyResult notifyResult = sendMessageService.sendSmsMessage(tel, content);
			if (null == notifyResult || !"success".equals(notifyResult.getState() + "")) {
				failureList.add(smsReturnObj);
			}else{
				smsReturnObj.setReturnCode(Constants.STATUS0);
				successList.add(smsReturnObj);
			}
	    	return map;
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.发送短信失败);
		}
	}


	private String getSendAppSmsMac(String shopperid,
			String merchantKey, String tel, String batch_number,String pos_traceno,String merchant_no,
			String termianl_no) {
		StringBuffer sb=new StringBuffer();
		sb.append("shopperid="+shopperid);
		sb.append("&tel="+tel);
		sb.append("&batch_number="+batch_number);
		sb.append("&pos_traceno="+pos_traceno);
		sb.append("&merchant_no="+merchant_no);
		sb.append("&termianl_no="+termianl_no);
		sb.append("&merchantKey="+merchantKey);
		log.info("md5字符串:"+sb.toString());
		log.info("mac:"+Md5Encrypt.md5(sb.toString()));
		return Md5Encrypt.md5(sb.toString());
	}


	/**
	 * @param request
	 * @param response
	 * @return 
	 * @throws BusinessException 
	 */
	public Map sendAppAndroidTranSms(HttpServletRequest request,
			HttpServletResponse response,Map maps) throws BusinessException {
		Map map = new HashMap();
		List successList = new ArrayList();//成功List
		List failureList = new ArrayList();//失败List
		map.put(Constants.SMS_SUCCESS_KEY,successList);
		map.put(Constants.SMS_FAILURE_KEY,failureList);
		try {
			Map<String,String> params = new HashMap<String,String>();
			String content=getContentapp(ConstantsEnv.SMS_APP_CONTENT_TRAN,params,maps);
			String tel = maps.get("tel").toString();
			NotifyResult notifyResult = sendMessageService.sendSmsMessage(tel, content);
			SmsReturnObj smsReturnObj = new SmsReturnObj();
			smsReturnObj.setMobile(tel);
			smsReturnObj.setContent(content);
			if (null == notifyResult || !"success".equals(notifyResult.getState() + "")) {
				failureList.add(smsReturnObj);
			}else{
				smsReturnObj.setReturnCode(Constants.STATUS0);
				successList.add(smsReturnObj);
			}
	    	return map;
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.发送短信失败);
		}
		
	}


	private String getContentapp(String smsContent,
			Map<String, String> params, Map maps) {
		Map map=getAppTranValuesapp(maps);
		return this.replaceValues(smsContent, map);
	}


	private Map getAppTranValuesapp(Map maps) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("${tranDate}",maps.get("tranDate")+ "");
		map.put("${tranTime}",maps.get("tranTime")+ "");
		map.put("${name}",maps.get("name")+ "");
		map.put("${amount}",maps.get("amount")+ "");
		map.put("${tranId}",maps.get("tranId")+ "");
		return map;
	}


	private String replaceValues(String mailContent, Map<String, String> values) {
		Set<String> set = values.keySet();
		for (String key : set){
			if(key.indexOf("${") != -1)
				mailContent = mailContent.replace(key, values.get(key) + "");
		}
		return mailContent;
	}
	
	

}
