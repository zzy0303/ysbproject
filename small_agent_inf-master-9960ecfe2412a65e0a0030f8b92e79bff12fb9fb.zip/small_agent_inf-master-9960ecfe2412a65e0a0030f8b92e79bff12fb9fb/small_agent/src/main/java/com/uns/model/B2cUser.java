package com.uns.model;

import java.math.BigDecimal;
import java.util.Date;

public class B2cUser {

    private BigDecimal b2cUserId;
    private String userid;
    private BigDecimal departid;
    private BigDecimal status;
    private String username;
    private String enname;
    private Date brithday;
    private String extension;
    private String mobilenum;
    private String email;
    private String business;
    private String office;
    private BigDecimal level1;
    private String trade;
    private String helpcode;
    
	public BigDecimal getB2cUserId() {
		return b2cUserId;
	}
	public void setB2cUserId(BigDecimal b2cUserId) {
		this.b2cUserId = b2cUserId;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public BigDecimal getDepartid() {
		return departid;
	}
	public void setDepartid(BigDecimal departid) {
		this.departid = departid;
	}
	public BigDecimal getStatus() {
		return status;
	}
	public void setStatus(BigDecimal status) {
		this.status = status;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEnname() {
		return enname;
	}
	public void setEnname(String enname) {
		this.enname = enname;
	}
	public Date getBrithday() {
		return brithday;
	}
	public void setBrithday(Date brithday) {
		this.brithday = brithday;
	}
	public String getExtension() {
		return extension;
	}
	public void setExtension(String extension) {
		this.extension = extension;
	}
	public String getMobilenum() {
		return mobilenum;
	}
	public void setMobilenum(String mobilenum) {
		this.mobilenum = mobilenum;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getBusiness() {
		return business;
	}
	public void setBusiness(String business) {
		this.business = business;
	}
	public String getOffice() {
		return office;
	}
	public void setOffice(String office) {
		this.office = office;
	}
	public BigDecimal getLevel1() {
		return level1;
	}
	public void setLevel1(BigDecimal level1) {
		this.level1 = level1;
	}
	public String getTrade() {
		return trade;
	}
	public void setTrade(String trade) {
		this.trade = trade;
	}
	public String getHelpcode() {
		return helpcode;
	}
	public void setHelpcode(String helpcode) {
		this.helpcode = helpcode;
	}
	public B2cUser() {
		super();
	}
   
}