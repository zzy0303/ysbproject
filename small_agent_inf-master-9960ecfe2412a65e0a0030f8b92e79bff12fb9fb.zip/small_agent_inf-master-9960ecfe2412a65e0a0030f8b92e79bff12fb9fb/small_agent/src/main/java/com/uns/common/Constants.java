package com.uns.common;

import com.uns.inf.acms.client.DynamicConfigLoader;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

public class Constants {
	
	/**
	 * 统一错误消息KEY
	 */
	public static final String MESSAGE_KEY="message";
	
	public static final String SESSION_VERIFY_CODE="sessionVerifycode";
	//操作员个人信息Session
	public static final String SESSION_KEY_USER="sessionUser";
	//商户绑定的终端Session
	public static final String SESSION_KEY_SHOPPER="b2cTermBinderNo";
	//代理商户编号
	public static final String SESSION_KEY_AGENT="agentNo";
	
	public static final String SESSION_KEY_APP_USER="sessionkeyappuser";

	//提示信息
	public static final String SAVE_MESSAGE = "保存成功!";
	//提示信息
	public static final String DEL_MESSAGE = "删除成功!";
	//退款策略
	public static final String CON_DICTCLS_RETURNPOLICY = "022";
	//结算策略
	public static final String CON_DICTCLS_FOOTFPOLICY = "023"; 
	//转帐费承担方
	public static final String CON_DICTCLS_FOOTTRANSAMOUNT = "024";
	//退款手续费策略
	public static final String CON_DICTCLS_RETURN_POUND = "030";
	//行业类型
	public static final String CON_DICTCLS_CALLING = "200";
	
	/*
	 * 代理商注册时，用于生成商户号的行业类型,暂时写为1
	 */
	public static final String CON_MCC = "1";
	/*
	 * 代理商是否准入,'N' 未准入 'Y' 已准入
	 */
	public static final String CON_AUDIT_YES = "Y";
	public static final String CON_AUDIT_NO = "N";
	
	public static final String 	CON_NO = "0";
	public static final String 	CON_YES = "1";
	public static final String 	CON_SH = "2";

	public static final String PASSWORD_FOR_SHOW = "unspay";
	
	public static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd";
	
	public static final String DEFAULT_DATETIME_FORMAT = "yyyy-MM-dd hh:mm:ss";
	
	/**
	 * 网络连接错误!
	 */
	public static final String internet_err_2001="2001";
	
	/**
	 * 交易流水导出excel,每页3000行
	 */
	public static int excel_size=3000;
	
	/**
	 * 交易流水展示,每页20行
	 */
	public static final int page_size=20;
	public static final int page=2;
	
	/**
	 * 默认代理商与终端绑定状态
	 * 
	 */
	public static final String term_agent_binder="0";

	public static final String ERROR_MESSAGE = "errMsg";
	
	//获取基本路径
	private static ResourceBundle CONF = ResourceBundle.getBundle("conf");
	
	private static ResourceBundle MSG = ResourceBundle.getBundle("messages");
	
	private static ResourceBundle MPOSMSG = ResourceBundle.getBundle("mposMessages");
	
	public static final String PATH = DynamicConfigLoader.getByEnv("basePath.url");
	
	//申请二维码排除条件
	public static final String FIXEDCODE_NO_QUERY = DynamicConfigLoader.getByEnv("qrcode_no_query");
	
	/*private static ResourceBundle PROPS_URL = ResourceBundle.getBundle("url");*/
	
	public static final String SUCCESS_CODE = "0000";
	//扫码修改返回码
	public static final String UPADTELIMIT_CODE="7899";

	public static final long TIME_DATE =1000*60*30;
	
	public static final long TIME_TEN =1000*60*10;

	public static final long TIME_ONE = 1000*60*1;
	
	

	
	
	public static final String MONEY_0 = "0.00";
	
	public static final String D0_CREDIT = "0.07";
	
	public static final String MONEY_2 = "2.00";
	
	public static final String MONEY_197 = "197.00";
	
	
	//个人 0 商户1 //状态为0 1 2 
	public static final String PERSONAL ="0";
	public static final String SHOPPER ="1";
	//  申请主题“开通商户”主题(1.商户开通2.变更开户信息	3.变更终端信息4.变更证照信息）
	public static final String STATUS1="1";
	public static final String STATUS2 ="2";
	public static final String STATUS3 ="3";
	public static final String STATUS4 ="4";
	public static final String STATUS5 ="5";
	public static final String STATUS0="0";

	public static final String 	REPEAL = "3";
	public static final Object 	PAST_STATUS = "4";
	public static final int 	PASTDATE = 2;
	//		
	public static final String TYPE_0="0";
	public static final String TYPE_1="1";
	public static final String TYPE_2="2";
	public static final String TYPE_3="3";
	public static final String TYPE_4="4";
	public static final String TYPE_5="5";
	public static final String TYPE_6="6";
	public static final String TYPE_7="7";

	//用户认证状态 0：未认证 1：个人认证 2：商户认证 3：均认证
	public static final String ATTESTATION_0 = "0";
	public static final String ATTESTATION_1 = "1";
	public static final String ATTESTATION_2 = "2";
	public static final String ATTESTATION_3 = "3";
	//商户版审核状态：6 未审核 7 审核中 8 初审通过 9初审不通过 10复审通过 11复审不通过）
	public static final String CHECK_STATUS_6 = "6";
	public static final String CHECK_STATUS_7 = "7";
	public static final String CHECK_STATUS_8 = "8";
	public static final String CHECK_STATUS_9 = "9";
	public static final String CHECK_STATUS_10 = "10";
	public static final String CHECK_STATUS_11 = "11";

	//商户版主页字典id
	public static final String MERCHANT_HOME_DICTCLSID = "620";
	//商户版
	public static final String MERCHANT_MPOSPAY_DICTCLSID = "520";
	public static final String MERCHANT_QR_DICTCLSID = "720";
	public static final String MERCHANT_KJ_DICTCLSID = "620";

	//商户结算信息查询微信、支付宝默认费率
	public static final String MERCHANT_DEFAULT_WX_FEE = DynamicConfigLoader.getByEnv("merchant_default_wx_fee");
	public static final String MERCHANT_DEFAULT_ZFB_FEE = DynamicConfigLoader.getByEnv("merchant_default_zfb_fee");

	public static final String THEME = DynamicConfigLoader.getByEnv("theme");

    public static final String SMS_SUCCESS_KEY = "sms_success_key";
    
    public static final String SMS_FAILURE_KEY = "sms_failure_key";
    
    /*private static ResourceBundle SMS_PROPS= ResourceBundle.getBundle("smsContent");*/
    
    /*private static ResourceBundle URL= ResourceBundle.getBundle("url");*/
    
     
    
    
  //判断商户编号
	public static final String CON_FIGURE="^[-+]?(([0-9]+)([.]([0-9]+))?|([.]([0-9]+))?)$";
	
	///结算最小金额500
	public static final String MIN_SETTLE_MONEY="50000";
	
		
	/**
	 * add by FK
	 */
	//验证手机号
	public static final String CHECK_MOBILE = "^[1][2,3,4,5,6,7,8,9][0-9]{9}$";
	//验证密码格式  至少6位字母或数字
	public static final String CHECK_PWD = "^[0-9a-zA-Z]{6,}$";
	
	
	/**
	 * end
	 */
	
	
	public static final Map<String, String> bankCardValMsg = new HashMap<String, String>();
	
	public static final Map<String, String> CZ_DATA = new HashMap<String, String>();
	
	public static final Map<String, String> mapReturnMsg = new HashMap<String, String>();
	static{
	    mapReturnMsg.put("0000", MPOSMSG.getString("0000")); 
	    mapReturnMsg.put("0001", MPOSMSG.getString("0001"));
		mapReturnMsg.put("1001", MPOSMSG.getString("1001"));
		mapReturnMsg.put("1000", MPOSMSG.getString("1000"));
		mapReturnMsg.put("2000", MPOSMSG.getString("2000"));
		mapReturnMsg.put("2100", MPOSMSG.getString("2100"));
		mapReturnMsg.put("2211", MPOSMSG.getString("2211"));
		mapReturnMsg.put("2215", MPOSMSG.getString("2215"));
		mapReturnMsg.put("2216", MPOSMSG.getString("2216"));
		mapReturnMsg.put("2217", MPOSMSG.getString("2217"));
		mapReturnMsg.put("2218", MPOSMSG.getString("2218"));
		mapReturnMsg.put("2200", MPOSMSG.getString("2200"));
		mapReturnMsg.put("3000", MPOSMSG.getString("3000"));
		mapReturnMsg.put("3001", MPOSMSG.getString("3001"));
		mapReturnMsg.put("3002", MPOSMSG.getString("3002"));
		mapReturnMsg.put("3005", MPOSMSG.getString("3005"));
		mapReturnMsg.put("3006", MPOSMSG.getString("3006"));
		mapReturnMsg.put("3007", MPOSMSG.getString("3007"));
		mapReturnMsg.put("5001", MPOSMSG.getString("5001"));
		mapReturnMsg.put("6004", MPOSMSG.getString("6004"));
		mapReturnMsg.put("6006", MPOSMSG.getString("6006"));
		mapReturnMsg.put("6011", MPOSMSG.getString("6011"));
		mapReturnMsg.put("7001", MPOSMSG.getString("7001"));
		mapReturnMsg.put("7002", MPOSMSG.getString("7002"));
		mapReturnMsg.put("7003", MPOSMSG.getString("7003"));
		mapReturnMsg.put("7005", MPOSMSG.getString("7005"));
		mapReturnMsg.put("7006", MPOSMSG.getString("7006"));
		mapReturnMsg.put("9001", MPOSMSG.getString("9001"));
		mapReturnMsg.put("9999", MPOSMSG.getString("9999"));
		mapReturnMsg.put("10100000", MPOSMSG.getString("10100000"));
		mapReturnMsg.put("10100001", MPOSMSG.getString("10100001"));
		mapReturnMsg.put("10100002", MPOSMSG.getString("10100002"));
		mapReturnMsg.put("10100003", MPOSMSG.getString("10100003"));
		mapReturnMsg.put("10100004", MPOSMSG.getString("10100004"));
		mapReturnMsg.put("10800000", MPOSMSG.getString("10800000"));
	  	mapReturnMsg.put("11110001", MPOSMSG.getString("11110001"));
		mapReturnMsg.put("11110002", MPOSMSG.getString("11110002"));
		mapReturnMsg.put("11110003", MPOSMSG.getString("11110003"));
		mapReturnMsg.put("11110004", MPOSMSG.getString("11110004"));
		mapReturnMsg.put("11110005", MPOSMSG.getString("11110005"));
		mapReturnMsg.put("11110006", MPOSMSG.getString("11110006"));
		mapReturnMsg.put("11110007", MPOSMSG.getString("11110007"));
		mapReturnMsg.put("11110008", MPOSMSG.getString("11110008"));
		mapReturnMsg.put("11110009", MPOSMSG.getString("11110009"));
		mapReturnMsg.put("11110010", MPOSMSG.getString("11110010"));
		
		mapReturnMsg.put("99999999", MPOSMSG.getString("99999999"));
	
	}
	
	//App版本号
	public static final String VERSION_1_0_0="1.0.0";
	public static final String VERSION_1_0_1="1.0.1";
	public static final String VERSION_2_0_0="2.0.0";
	public static final String VERSION_2_0_1="2.0.1";
	public static final String VERSION_2_1_0="2.1.0";
	public static final String VERSION_2_2_0="2.2.0";
	public static final String VERSION_2_3_0="2.3.0";
	public static final String VERSION_2_4_0="2.4.0";

	public static final String TYPE_P="P";//个人
	public static final String TYPE_C="C";//C企业
	public static final String TYPE_S="S";//商户

	public static final String TYPE_A="A";
	
	public static final String TYPE_I="I";
	
	
	

	public static Map<String, String> convertMap = new HashMap<String, String>();
	static{
	    convertMap.put("0", "未审核");
	    convertMap.put("1", "未确认");
	    convertMap.put("2", "有疑议");
	    convertMap.put("3", "未结算");
	    convertMap.put("4", "已结算");
	    convertMap.put("5", "审核不通过");
	    convertMap.put("6", "疑议已处理");
	}
	public static final int MAX_DOWNLOAD_SIZE = Integer.valueOf(DynamicConfigLoader.getByEnv("max_download_size"));
	

	public static final SimpleDateFormat SF_YYYYMMDD = new SimpleDateFormat("yyyyMMdd");
	
	public static final SimpleDateFormat SF_YYYYMMDDHHMMSS = new SimpleDateFormat("yyyyMMddHHmmss");
	
	public static final Map<String,Date> TIME_LIMIT = new HashMap<String, Date>();
	
	public static final Object AGENTFEE = "0.0078";

	public static final Object TOPMAX = "35";

	public static final Object TOPMIN = "30";
		
	public static final String OPERATION_SUCCEEDED = MSG.getString("00001");
	public static final String OPERATION_FAILED = MSG.getString("00002");

	public static final String ORGTYPE = "1";

	public static final int UPLOAD_SIZE = 5000;
	
	public static String QUERY_SUCCEEDED=MSG.getString("00003");
	
	public static String NO_RETURN_RESULTS=MSG.getString("00004");
	
	public static String LOSE_PARAMETER=MSG.getString("00005");

	public static String NO_RETURN_RESULTS_CODE="00004";
	
	public static String LOSE_PARAMETER_CODE="00005";

	//一级代理商不一致
	public static final String TERM_STATUS1="0001";
	//终端号不存在
	public static final String TERM_STATUS2="0002";
	//代理商不一致
	public static final String TERM_STATUS3="0003";
	//已经绑定商户
	public static final String TERM_STATUS4="0004";
	//终端已经入过库
	public static final String TERM_STATUS5="0005";
	
	public static final String CON_IN="0";//终端入库状态码

	public static final String CON_OUT="2";//终端出库状态码
	
	public static final String OPERATION="1";
	
	public static final String TERM_UNNUM="0006";//非法数字
	public static final int    TERM_SIZE = 16;//终端序列号长度
	public static final String TERM_BIND = "0007";//终端已经绑定商户
	
	//固定编码模块
	public static final String QRCODE_STATUS1="4051";
	public static final String QRCODE_STATUS2="4061";
	public static final String QRCODE_UN="4062";//编码未入库
	public static final String QRCODE_Y="4063";//编码已经出过库
	public static final String QRCODE_UNNUM="4064";//非法数字
	public static final String QRCODE_IN="0";//入库
	public static final String QRCODE_B="1";//绑定商户
	public static final int    QRCODE_SIZE = 8;//固码长度
	public static final String QRCODE_NO = "NO.";//固码编号

	public static final String WX_FLAG = "WX_FLAG";
	public static final String ZFB_FLAG = "ZFB_FLAG";
	public static final String YL_FLAG = "YL_FLAG";

	public static final Object T0_FEE = "0.0007";

	public static final Object T0_FIXED_AMOUNT = "2.00";

	public static final String ORGANIZATION = CONF.getString("hsm_shoper_id");

	public static final String FIX_NAME = "商户消费 ";

	public static final String BIND_TYPE_PLAIN = "plain"; //绑定普通商户固码
	public static final String BIND_TYPE_INVITE = "invite"; //根据邀请码绑定商户固码
	public static final String BIND_TYPE_DIRECT = "direct"; //绑定直营码

	//OCR实名报件进度
	
	public static final String OCR_REG_DONE = "0";//注册完成
	public static final String OCR_IDCARD_INFO_DONE = "1";//上传身份证完成
	public static final String OCR_DEBITCARD_INFO_DONE = "2";//上传结算卡信息完成
	public static final String OCR_CREDITCARD_INFO_DONE = "3";//上传贷记卡信息完成
	public static final String OCR_LIVING_INFO_DONE = "4";//上传活体信息完成
	public static final String OCR_HANDHELD_IDCARDINFO_DONE = "5";//上传手持身份证照片完成
	public static final String OCR_SIGN_DONE = "6";//上传签名和费率确认信息完成
	public static final String SUCCESS_CODE_0000 = "0000"; //查询sys_config成功

	//默认行业
	public static final String DEFAULT_INDUSTRY = "160";//默认行业字典
	
	//注册弘付和海科flag
	public static final String REAL_NAME_FAIL = "6012";//实名认证失败
	public static final String REG_YSB_FAIL = "6013";//注册银生宝失败
	public static final String LOGON_SUCCESS = "1014";//注册成功请登录
	public static final String HK_REG_FAILED = "6015";//海科注册失败
	public static final String HF_REG_FAILED = "6016";//弘付注册失败
	public static  int HK_SERVERPORT = 8088;
	public static  String HK_SUCCESS_CODE = "00";
	public static final String HK_REPEAT_CODE_H2 = "H2";
	public static  String UPDATE_RS_PMSG = "修改成功";
	public static final String D0_FEE = "0.0007";
	
	public static final int INT_0 = 0;
	public static final int INT_1 = 1;
	public static final int INT_2 = 2;
	public static final int INT_3 = 3;
	public static final int INT_4 = 4;
	public static final int INT_5 = 5;
	public static final int INT_6 = 6;
	public static final int INT_7 = 7;
	public static final int INT_8 = 8;
	public static final int INT_9 = 9;
	public static final int INT_10 = 10;
	
	public static final String NOT_PASS_STEP_ID_CARD = "1,0,0,0,0,0";//错误步骤（上传了身份证）
	
	public static final String CONTENT_TYPE_UTF8 = "UTF-8";
	
	public static final String RETURN_CODE_2222 = "2222";
	
	public static final String CONS_STR_NULL = "null";
	
	public static final String APP_LOGIN_FAILED = "1111";//APP登陆用户名或密码错误
	
	public static final String RSP_CODE = "rspCode";//rspCode

	public static final String RSP_MSG = "rspMsg";//rspMsg

	public static final String HK_10A = "10A";
	public static final String HK_10B = "10B";

	public static final String FEE_TYPE_DEBIT = "0";//即时借记储蓄卡
	public static final String FEE_TYPE_CREDIT = "1"; //即时贷记储蓄卡

	public static final String S0_CHANNEL_TYPE = "1001";
	public static final String D0_CHANNEL_TYPE = "2001";
	public static final String T1_CHANNEL_TYPE = "2002";

	public static final String RSP_WX_FEE = "wxFee";
	public static final String RSP_ZFB_FEE = "zfbFee";
	public static final String FEE_TYPE_WX = "2"; //微信费率类型
	public static final String FEE_TYPE_ZFB = "3"; //支付宝费率类型

	public static final String NOT_AGENT_CODE = "1111"; //没有找到代理商

}
