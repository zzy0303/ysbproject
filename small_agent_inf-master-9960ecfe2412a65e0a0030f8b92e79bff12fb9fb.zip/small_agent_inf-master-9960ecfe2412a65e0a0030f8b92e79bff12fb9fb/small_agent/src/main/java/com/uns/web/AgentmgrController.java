package com.uns.web;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.model.Agent;
import com.uns.model.Area;
import com.uns.model.B2cDict;
import com.uns.model.Users;
import com.uns.service.AgentService;
import com.uns.service.ShopPerbiService;
import com.uns.util.HttpClientUtils;
import com.uns.util.Md5Encrypt;
import com.uns.util.StringUtils;
import com.uns.web.form.AgentForm;
import net.sf.json.JSONObject;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

@Controller
@RequestMapping(value = "/agentmgr.htm")
public class AgentmgrController extends BaseController {
	@Autowired
	private AgentService agentservice;

	@Autowired
	private ShopPerbiService shopPerbiService;
	

	@RequestMapping(params = "method=toAddAgent")
	@FormToken(save = true)
	public String toAddAgent(HttpServletRequest request, ModelMap modelMap)
			throws Exception {
		try {
			List<Area> Provincial = shopPerbiService.searchProvince();
			request.setAttribute("Provincial", Provincial);
			// 获取市
			List<Area> list = shopPerbiService.searchArea();
			request.setAttribute("area", list);
			// 获取银行
			List<B2cDict> dicbank = shopPerbiService.searchBank();
			request.setAttribute("bank", dicbank);
			Users sessionUser = (Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			Agent sessionAgent = agentservice.searchAgentByShopperId(sessionUser.getMerchantid().toString());
			request.setAttribute("agent", sessionAgent);
			request.setAttribute("Users", sessionUser);

		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.代理商注册获取列表失败);
		}
		return "agent/toaddagent";
	}

	@RequestMapping(params = "method=saveagent")
	@FormToken(remove = true)
	public String saveagent(HttpServletRequest request, ModelMap modelMap,
			Agent agent, Users users, @ModelAttribute("mb") AgentForm mbForm)
			throws Exception {
		try {
			String shopperid = getPosShopperId(agent.getCity(), Constants.CON_MCC);
			agent.setShopperid(Long.parseLong(shopperid));
			agent.setCreated(new Date());
			agent.setBattalion(Long.parseLong("0"));
			agent.setIfattend(new Short("0"));
			agent.setIfagent(Long.parseLong("1"));
			Users sessionUser = (Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			agent.setShopperidP(sessionUser.getMerchantid());
			String transactid = agent.getTransactid().toString();
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("createDate", new Date());
			param.put("updateUser", agent.getShopperidP());
			param.put("shopperid", agent.getShopperid());
			param.put("updateScompany", agent.getScompany());
			
/*			param.put("skFeetypeFee", agent.getSkFeetypeFee());
			param.put("skToptypeFee", agent.getSkToptypeFee());
			param.put("skToptypeTop", agent.getSkToptypeTop());
			param.put("feetypeD0Fee", agent.getFeetypeD0Fee());
			param.put("toptypeD0Fee", agent.getToptypeD0Fee());*/
			
			param.put("skDebitFee", agent.getSkDebitFee());
			param.put("skCreditFee", agent.getSkCreditFee());
			param.put("d0Fee", agent.getD0Fee());
			param.put("smWechatT1Fee", agent.getSmWechatT1Fee());
			param.put("smWechatD0Fee", agent.getSmWechatD0Fee());
			param.put("smAlipayT1Fee", agent.getSmAlipayT1Fee());
			param.put("smAlipayD0Fee", agent.getSmAlipayD0Fee());
			
			if (Constants.STATUS0.equals(transactid)) {
				agent.setTransactsub("未开通");
			} else if (Constants.STATUS1.equals(transactid)) {
				agent.setTransactsub("已开通");
			} else if (Constants.STATUS2.equals(transactid)) {
				agent.setTransactsub("已冻结");
			}

			if (agent.getProvince() != null) {
				List searchProvincialList = shopPerbiService.searchProvincial(agent.getProvince());
				if (searchProvincialList != null&& searchProvincialList.size() > 0) {
					Area spro = (Area) searchProvincialList.get(0);
					if (spro != null) {
						String sprov = spro.getProvincialname();
						agent.setSprovince(sprov);
					}
				}
			}
			if (agent.getCity() != null) {
				List cityList = shopPerbiService.searchCity(agent.getCity());
				if (cityList != null && cityList.size() > 0) {
					Area area = (Area) cityList.get(0);
					if (area != null) {
						String cityName = (String) area.getCityname();
						agent.setScity(cityName);
					}
				}
			}
			// 在users表中插入密码用户名等数据
			Users user = newuser(request, shopperid,sessionUser.getDemo());
			// 调用接口
			String rspCode=requestlimitAdd(shopperid, agent);
			if (Constants.SUCCESS_CODE.equals(rspCode)) {
				shopPerbiService.saveagent(agent,param,user);
				request.setAttribute(Constants.MESSAGE_KEY, "注册成功!");
				request.setAttribute("url", "agentmgr.htm?method=toAddAgent");
			} else {
				request.setAttribute(Constants.MESSAGE_KEY, "注册失败!");
				request.setAttribute("url", "agentmgr.htm?method=toAddAgent");
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.代理商注册失败);
		}
		return "/returnPage";

	}

	/**
	 * 生成编码
	 * 
	 * @param area
	 * @param mcc
	 * @return
	 * @throws Exception
	 */
	public String getPosShopperId(String area, String mcc) throws Exception {
		String organization = "800";
		String areacold = "";
		if (area.length() > 4) {
			areacold = area.substring(0, 4);
		} else {
			areacold = area;
		}
		String mcccold = "";
		if (mcc.length() == 1) {
			mcccold = "000" + mcc;
		} else {
			mcccold = "00" + mcc;
		}
		String merchantRadom = RandomStringUtils.randomNumeric(4);
		String posMerchantId = organization + areacold + mcccold+ merchantRadom;
		Agent b2cShopperbi = agentservice.searchAgentByShopperId(posMerchantId);
		if (b2cShopperbi != null) {
			return getPosShopperId(area, mcc);
		}
		return posMerchantId;
	}

	/**
	 * 是否有重复的电话号码存在
	 * 
	 * @param request
	 * @param response
	 * @throws
	 * @throws IOException
	 */
	@RequestMapping(params = "method=ajaxCheckTel")
	public void ajaxCheckTel(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		try {
			String stel = request.getParameter("stel");

			Agent list = null;
			if (StringUtils.isTrimNotEmpty(stel)) {
				stel = stel.trim();

				list = agentservice.findbytel(stel);
			}
			PrintWriter out = response.getWriter();
			try {
				if ((list != null)) {
					out.write("{\"x\":\"1\"}");
				} else {
					out.write("{\"x\":\"2\"}");
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (out != null) {
					out.flush();
					out.close();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * 是否有重复的代理商企业名称是否存在
	 * 
	 * @param request
	 * @param response
	 * @throws
	 * @throws IOException
	 */
	@RequestMapping(params = "method=ajaxCheckScompany")
	public void ajaxCheckScompany(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		try {
			String scompany = request.getParameter("scompany");

			Agent list = null;
			if (StringUtils.isTrimNotEmpty(scompany)) {
				scompany = scompany.trim();
				list = agentservice.searchAgentByName(scompany);
			}
			PrintWriter out = response.getWriter();
			try {
				if ((list != null)) {
					out.write("{\"x\":\"1\"}");
				} else {
					out.write("{\"x\":\"2\"}");
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (out != null) {
					out.flush();
					out.close();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * 商户查询
	 * 
	 * @param request
	 * @param b2cShopperbiTmp
	 * @param b2cShopperbargainTmp
	 * @param modelMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=selectAgentList")
	public String selectAgentList(HttpServletRequest request, ModelMap modelMap,
			@ModelAttribute("mb") AgentForm mbForm) throws Exception {
		try {

			List<Agent> agentlist = null;
			// 判断商户编号是否为数字
			String shopperIdq = mbForm.getAgentid();
			String shopperid_p=request.getParameter("shopperid_p");
			if (!StringUtils.isEmpty(shopperIdq)) {
				boolean b = shopperIdq.matches("^[-+]?(([0-9]+)([.]([0-9]+))?|([.]([0-9]+))?)$");
				if (!b) {
					mbForm.setAgentid("");
				}
			}
			
			
			
			
			if (mbForm.getSprovince() != null) {
				List searchProvincialList = shopPerbiService.searchProvincial(mbForm.getSprovince());
				if (searchProvincialList != null&& searchProvincialList.size() > 0) {
					Area spro = (Area) searchProvincialList.get(0);
					if (spro != null) {
						String sprov = spro.getProvincialname();
						mbForm.setSprovince(sprov);
					}
				}
			}
			if (mbForm.getCity() != null) {
				List cityList = shopPerbiService.searchCity(mbForm.getCity());
				if (cityList != null && cityList.size() > 0) {
					Area area = (Area) cityList.get(0);
					if (area != null) {
						String cityName = (String) area.getCityname();
						mbForm.setCity(cityName);
					}
				}
			}
			Users sessionUser = (Users) request.getSession().getAttribute(
					Constants.SESSION_KEY_USER);
			if (sessionUser == null|| StringUtils.isEmpty(Long.toString(sessionUser.getMerchantid()))) {
				throw new BusinessException(ExceptionDefine.代理商查询失败);
			}
			String shopperid = Long.toString(sessionUser.getMerchantid());
			mbForm.setCurrentid(Long.parseLong(shopperid));
			
			
			if(org.apache.commons.lang3.StringUtils.isNotEmpty(shopperid_p)){
				mbForm.setCurrentid(Long.parseLong(shopperid_p));
			}
			
			request.getSession().setAttribute("shopperid", shopperid);
			agentlist = agentservice.selectAgentList(mbForm);
			modelMap.put("agentlist", agentlist);
			// 获取省
			List<Area> Provincial = shopPerbiService.searchProvince();
			request.setAttribute("Provincial", Provincial);
			// 获取市
			List<Area> list = shopPerbiService.searchArea();
			request.setAttribute("area", list);
			request.setAttribute("belongsAgent", mbForm.getBelongsAgent());
		} catch (BusinessException e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.代理商查询失败);
		}
		return "agent/selectagent";
	}

	/**
	 * 查看代理商详情
	 * 
	 * @param request
	 * @param agent
	 * @param modelMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=queryAgentDetails")
	@FormToken(save = true)
	public String queryAgentDetails(HttpServletRequest request,
			ModelMap modelMap, Agent agent,
			@ModelAttribute("mb") AgentForm mbForm) throws Exception {
		try {
			String shopperid = request.getParameter("shopperid");
			if (StringUtils.isEmpty(shopperid)) {
				request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
				mbForm.setBelongsAgent(null);
				request.setAttribute("url", "agentmgr.htm?method=selectAgentList");
			} else {
				Agent agent1 = agentservice.searchAgentByShopperId(shopperid);
				request.setAttribute("agent1", agent1);
			}
			Users users = shopPerbiService.selectUsersByAgentNo(shopperid);
			request.setAttribute("users", users);
			// 获取省
			List<Area> Provincial = shopPerbiService.searchProvince();
			request.setAttribute("Provincial", Provincial);
			// 获取市
			List<Area> list = shopPerbiService.searchArea();
			request.setAttribute("area", list);

		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取代理商信息失败);
		}

		return "agent/selectOneAgent";
	}

	/**
	 * 修改代理商信息变更
	 * 
	 * @param request
	 * @param agent
	 * @param modelMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=queryAgentupdate")
	@FormToken(save = true)
	public String queryAgentupdate(HttpServletRequest request,
			ModelMap modelMap, Agent agent,
			@ModelAttribute("mb") AgentForm mbForm) throws Exception {
		try {
			String shopperid = request.getParameter("shopperid");
			if (StringUtils.isEmpty(shopperid)) {
				request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
				mbForm.setBelongsAgent(null);
				request.setAttribute("url", "agentmgr.htm?method=selectAgentList");
			} else {
				agent = this.agentservice.searchAgentByShopperId(shopperid);
			}
			Users users = shopPerbiService.selectUsersByAgentNo(shopperid);
			request.setAttribute("users", users);
			// 获取省
			List<Area> Provincial = shopPerbiService.searchProvince();
			request.setAttribute("Provincial", Provincial);
			// 获取市
			List<Area> list = shopPerbiService.searchArea();
			request.setAttribute("area", list);

			modelMap.put("agent", agent);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取代理商信息失败);
		}

		return "agent/updateagent";
	}

	/**
	 * 保存代理商修改后的信息
	 * 
	 * @param request
	 * @param response
	 * @param modelMap
	 * @param mbForm
	 * @return
	 * @throws IOException
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=saveAgentUpdate")
	@FormToken(remove = true)
	public String saveAgentUpdate(HttpServletRequest request,
			HttpServletResponse response, ModelMap modelMap, Agent agent,
			@ModelAttribute("mb") AgentForm mbForm) throws Exception,
			BusinessException {
		try {
			String shopperid = request.getParameter("shopperid");
			String password = request.getParameter("agentpassword").trim();
			String stel = request.getParameter("stel").trim();
			String telc = request.getParameter("tel").trim();
			/*String loginname = request.getParameter("loginname").trim();*/
			if (StringUtils.isEmpty(shopperid)) {
				request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
				mbForm.setBelongsAgent(null);
				request.setAttribute("url", "agentmgr.htm?method=selectAgentList");
			} else {
				if (agent.getProvince() != null) {
					List searchProvincialList = shopPerbiService.searchProvincial(agent.getProvince());
					if (searchProvincialList != null && searchProvincialList.size() > 0) {
						Area spro = (Area) searchProvincialList.get(0);
						if (spro != null) {
							String sprov = spro.getProvincialname();
							agent.setSprovince(sprov);
						}
					}
				}
				if (agent.getCity() != null) {
					List cityList = shopPerbiService.searchCity(agent.getCity());
					if (cityList != null && cityList.size() > 0) {
						Area area = (Area) cityList.get(0);
						if (area != null) {
							String cityName = (String) area.getCityname();
							agent.setScity(cityName);
						}
					}
				}
				Users sessionUser=(Users) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
				Users users = shopPerbiService.selectUsersByAgentNo(shopperid);
				if (org.apache.commons.lang.StringUtils.isNotEmpty(password)) {
					String Md5pwd = Md5Encrypt.md5(password);
					users.setPassword(Md5pwd);
				}
				users.setUserName(stel);
				if (telc.equals(stel)) {
					agentservice.updateuseragent(users, agent ,sessionUser);
					request.setAttribute(Constants.MESSAGE_KEY, "修改成功!");
				} else {
					Agent atel = agentservice.findbytel(stel);
					if (atel != null) {
						request.setAttribute(Constants.MESSAGE_KEY, "该手机号码已存在!");
						request.setAttribute("url",	"agentmgr.htm?method=selectAgentList");
					} else {
						
					   String rspCode = requestlimitEdit(agent.getShopperid().toString(),	agent);
					   if (Constants.UPADTELIMIT_CODE.equals(rspCode)) {
						   agent.setStel(stel);
						   users.setTel(stel);
						   agentservice.updateuseragent(users, agent, sessionUser);
						   request.setAttribute(Constants.MESSAGE_KEY, "修改成功!");
					   }else {
						   request.setAttribute(Constants.MESSAGE_KEY, "修改失败!");
					   }
						
						
					}
				}
				
			}
			
			request.setAttribute("url", "agentmgr.htm?method=selectAgentList");

		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.修改失败);
		}

		return "/returnPage";

	}

	public Users newuser(HttpServletRequest request, String shopperid,String demo) {

		String mpassword = request.getParameter("agentpassword");
		String Md5pwd = Md5Encrypt.md5(mpassword);
		/*String loginname = request.getParameter("loginname").trim();*/
		String tel = request.getParameter("stel");
		Users user = new Users();
		user.setIsAgent(new Short("1"));
		user.setMerchantid(Long.parseLong(shopperid));
		user.setUserName(tel);                                                                                                                                                         
		user.setPassword(Md5pwd);
		user.setEnabled(new Short("1"));
		user.setTel(tel);
		user.setCreatedate(new Date());
		user.setDemo(demo);
		return user;
	}
	
	public String requestlimitAdd(String shopperid,Agent agent){
		   String rspCode="";
		   String rspMsg="";
		   String phone = agent.getStel();//代理商电话号
		   Long srcid_p=agent.getShopperidP();//上级代理商编号
		   String scompany = agent.getScompany();//代理商名称
		   
		   List list=new ArrayList();
		   Map debitMap=new HashMap();
		   debitMap.put("d0Fee", agent.getD0Fee());
		   debitMap.put("feeType", Constants.STATUS0);
		   debitMap.put("t1Fee", agent.getSkDebitFee());
		   list.add(debitMap);
		   
		   Map creditMap=new HashMap();
		   creditMap.put("d0Fee", agent.getD0Fee());
		   creditMap.put("feeType", Constants.STATUS1);
		   creditMap.put("t1Fee", agent.getSkCreditFee());
		   list.add(creditMap);
		   
		   Map wechatMap=new HashMap();
		   wechatMap.put("d0Fee", agent.getSmWechatD0Fee());
		   wechatMap.put("feeType", Constants.STATUS2);
		   wechatMap.put("t1Fee", agent.getSmWechatT1Fee());
		   list.add(wechatMap);
		   
		   Map alipayMap=new HashMap();
		   alipayMap.put("d0Fee", agent.getSmAlipayD0Fee());
		   alipayMap.put("feeType", Constants.STATUS3);
		   alipayMap.put("t1Fee", agent.getSmAlipayT1Fee());
		   list.add(alipayMap);
		   
		   Map parmsMap=new HashMap();
			parmsMap.put("orgId", shopperid);
			parmsMap.put("orgaExts", list);
			parmsMap.put("orgType", Constants.ORGTYPE);
			parmsMap.put("limit", agent.getLimit());
			parmsMap.put("phone", phone);
			parmsMap.put("srcid_p", srcid_p);
			parmsMap.put("scompany", scompany);
			
		try {
			
			String mposAgentCode=regMposAgent(parmsMap);
			
			if(!Constants.SUCCESS_CODE.equals(mposAgentCode)){
		    	rspCode= Constants.ERROR_MESSAGE;
		    }else{
		    	String qrAgentCode=regQrAgent(parmsMap);
				if(!Constants.SUCCESS_CODE.equals(qrAgentCode)){
					rspCode= Constants.ERROR_MESSAGE;
				}else {
					rspCode= Constants.SUCCESS_CODE;
				}
				
		    }
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rspCode;
		
	}
	
	public String requestlimitEdit(String shopperid,Agent agent){
		   String rspCode="";
		   String rspMsg="";
		   String phone = agent.getStel();//代理商电话号
		   Long srcid_p=agent.getShopperidP();//上级代理商编号
		   String scompany = agent.getScompany();//代理商名称
		   
		   List list=new ArrayList();
		   Map debitMap=new HashMap();
		   debitMap.put("d0Fee", agent.getD0Fee());
		   debitMap.put("feeType", Constants.STATUS0);
		   debitMap.put("t1Fee", agent.getSkDebitFee());
		   list.add(debitMap);
		   
		   Map creditMap=new HashMap();
		   creditMap.put("d0Fee", agent.getD0Fee());
		   creditMap.put("feeType", Constants.STATUS1);
		   creditMap.put("t1Fee", agent.getSkCreditFee());
		   list.add(creditMap);
		   
		   Map wechatMap=new HashMap();
		   wechatMap.put("d0Fee", agent.getSmWechatD0Fee());
		   wechatMap.put("feeType", Constants.STATUS2);
		   wechatMap.put("t1Fee", agent.getSmWechatT1Fee());
		   list.add(wechatMap);
		   
		   Map alipayMap=new HashMap();
		   alipayMap.put("d0Fee", agent.getSmAlipayD0Fee());
		   alipayMap.put("feeType", Constants.STATUS3);
		   alipayMap.put("t1Fee", agent.getSmAlipayT1Fee());
		   list.add(alipayMap);
		   
		   Map parmsMap=new HashMap();
			parmsMap.put("orgId", shopperid);
			parmsMap.put("orgaExts", list);
			parmsMap.put("orgType", Constants.ORGTYPE);
			parmsMap.put("limit", agent.getLimit());
			parmsMap.put("phone", phone);
			parmsMap.put("srcid_p", srcid_p);
			parmsMap.put("scompany", scompany);
			
		try {
			String mposAgentCode=regMposAgent(parmsMap);
			if(!Constants.SUCCESS_CODE.equals(mposAgentCode)){
		    	rspCode= Constants.ERROR_MESSAGE;
		    }else{
		    	String qrAgentCode=regQrAgent(parmsMap);
				if(!Constants.UPADTELIMIT_CODE.equals(qrAgentCode)){
					rspCode= Constants.ERROR_MESSAGE;
				}else {
					rspCode= Constants.UPADTELIMIT_CODE;
				}
		    }
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rspCode;
		
	}
	
	private String regQrAgent(Map parmsMap) throws BusinessException {
		JSONObject obs = JSONObject.fromObject(parmsMap);
		String rspCode ="";
		//扫码支付 添加代理商
		log.info("扫码支付 添加代理商参数：" + ConstantsEnv.QRPAY_ADDLIMITURL+ obs.toString());
		String result = HttpClientUtils.REpostRequestStrJson(ConstantsEnv.QRPAY_ADDLIMITURL, obs.toString());
		JSONObject ob2 = JSONObject.fromObject(result);
	    rspCode = (String) ob2.get("rspCode");
	    log.info("扫码支付 添加代理商返回码：" + result);
		return rspCode;
		
	}
	/**注册代理商
	 * @param shopperid
	 * @param limit
	 * @return
	 * @throws Exception 
	 */
	private String regMposAgent(Map parmsMap) throws Exception {
		String result="";
		
		JSONObject obs = JSONObject.fromObject(parmsMap);
		
		log.info("添加代理商接口参数：" + ConstantsEnv.LIMITURL+ obs.toString());
		result = HttpClientUtils.REpostRequestStrNormal(ConstantsEnv.LIMITURL, obs.toString());
		Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(result);
		log.info("添加代理商返回码：" + resultMap.toString());
		JSONObject ob = JSONObject.fromObject(result);
		String rspCode = (String) ob.get("rspCode");
		String rspMsg = (String) ob.get("rspMsg");
		return rspCode;
	}

	/**
	 * 查询费率修改记录日志
	 */
	@RequestMapping(params = "method=selectLogList")
	public String selectLogList(HttpServletRequest request,String shopperid){
		List<Map<String,Object>> list = agentservice.selectUpdateAgentfeeAlogList(shopperid);
		request.setAttribute("list", list);
		return "agent/updateAgentFeeLogList";
	}
}
