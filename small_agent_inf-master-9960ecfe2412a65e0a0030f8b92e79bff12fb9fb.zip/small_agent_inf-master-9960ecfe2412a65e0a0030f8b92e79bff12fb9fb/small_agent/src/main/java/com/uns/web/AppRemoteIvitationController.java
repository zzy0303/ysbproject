package com.uns.web;

import com.uns.common.Constants;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.MposRemoteFee;
import com.uns.model.MposRemoteInvitation;
import com.uns.service.MposRemoteFeeService;
import com.uns.service.MposRemoteInvitationService;
import com.uns.service.ShopPerbiService;
import com.uns.util.ToolsUtils;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping(value = "/appRemoteIvitationController.htm")
public class AppRemoteIvitationController extends BaseController {

	@Autowired
	private ShopPerbiService merchantregservice;

	@Autowired
	private MposRemoteInvitationService mposRemoteInvitationService;

	@Autowired
	private MposRemoteFeeService remotefeeservice;

	@RequestMapping(params = "method=remoteinvitation")
	public void remoteinvitation(HttpServletRequest request,HttpServletResponse response) throws IOException {
		String version  = request.getParameter("version") == null ? "" : request.getParameter("version");
	    if((Constants.VERSION_2_0_1).equals(version)){
	    	remoteinvitation201(request,response);
	    }else{
	    	remoteinvitation001(request,response);
	    }
	}
	
	/**远程邀请2.0.1
	 * @param request
	 * @param response
	 * @throws IOException 
	 */
	private void remoteinvitation201(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		Map hashMap = new HashMap();
		try{
			String tel = request.getParameter("tel") == null ? "" : request	.getParameter("tel");
			String debitT1fee = request.getParameter("debitfee") == null ? "" : request.getParameter("debitfee");//借记卡 费率
			String creditT1Fee = request.getParameter("creditfee") == null ? "" : request	.getParameter("creditfee");//贷记卡 费率
			String weChatT1fee=request.getParameter("weChatfee") == null ? "" : request	.getParameter("weChatfee");//微信 T1 费率
			String aliPayT1Fee=request.getParameter("aliPayfee") == null ? "" : request	.getParameter("aliPayfee");//支付宝 T1 费率
			String agentId=request.getParameter("agentId") == null ? "": request.getParameter("agentId");

			String openToFlag=request.getParameter("openToFlag") == null ? "" : request.getParameter("openToFlag");
			String t0Fee = request.getParameter("t0Fee")==null?"0": request.getParameter("t0Fee");//d0提现手续费
			String t0fixedamount = request.getParameter("t0fixedamount")==null?"0":request.getParameter("t0fixedamount");// 固定金额
			String shopperLimit=request.getParameter("shopperLimit") == null ? "" : request.getParameter("shopperLimit");//单日提现限额
			String t0minamount = request.getParameter("t0minamount");// 单笔范围最小金额
			String t0maxamount = request.getParameter("t0maxamount");// 单笔范围最大金额
			
			String weChatD0fee = request.getParameter("weChatD0fee")==null?"0": request.getParameter("weChatD0fee");//微信 D0手续费 费率
			String aliPayD0Fee = request.getParameter("aliPayD0Fee")==null?"0": request.getParameter("aliPayD0Fee");//支付宝 D0手续费 费率
			
			//判断该手机号是否注册过
			B2cShopperbiTemp shoppertel = merchantregservice.findbytel(tel);
			MposRemoteInvitation Rtel = mposRemoteInvitationService.findbytel(tel);
			
			if(shoppertel!=null){
				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "改手机号已被注册，请更换手机号！");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("邀请失败:" + json.toString());
				response.getWriter().write(json.toString());
				return;
			}
			
			MposRemoteInvitation mposRemoteInvitation = new MposRemoteInvitation();
			
			mposRemoteInvitation.setTel(tel);
			mposRemoteInvitation.setAgentId(agentId);
			mposRemoteInvitation.setOpenToFlag(openToFlag);
			if(Constants.CON_NO.equals(openToFlag)){
				mposRemoteInvitation.setT0Fee(ToolsUtils.div(Double.parseDouble(t0Fee), 1, 4));
				mposRemoteInvitation.setT0fixedamount(Double.parseDouble(t0fixedamount));
				mposRemoteInvitation.setShopperLimit(shopperLimit);
				mposRemoteInvitation.setT0minamount(Double.parseDouble(ToolsUtils.div(Double.parseDouble(t0minamount), 1, 4)));
				mposRemoteInvitation.setT0maxamount(Double.parseDouble(ToolsUtils.div(Double.parseDouble(t0maxamount), 1, 4)));
			}
			
			if(Rtel!=null){
				if(Rtel.getStatus().equals(Constants.STATUS3)){
					remotefeeservice.delfee(tel);
					mposRemoteInvitationService.insertRemoteInvitationfee(mposRemoteInvitation,debitT1fee,creditT1Fee,weChatT1fee,aliPayT1Fee,weChatD0fee,aliPayD0Fee,request);
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "邀请成功");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("邀请结果3:" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}else if(Constants.STATUS4.equals(Rtel.getStatus())){
					// 当状态为4的时候邀请将状态改为3 并且将费率表中的数据删除
					Rtel.setStatus(Constants.STATUS3);
					mposRemoteInvitationService.update(Rtel);
					remotefeeservice.delfee(tel);
					mposRemoteInvitationService.insertRemoteInvitationfee(mposRemoteInvitation,debitT1fee,creditT1Fee,weChatT1fee,aliPayT1Fee,weChatD0fee,aliPayD0Fee,request);
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "邀请成功");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("邀请结果3:" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}else{
					hashMap.put("rspCode", "1112");
					hashMap.put("rspMsg", "该手机号已被邀请！");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("邀请结果3:" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				
			}
			if(Rtel==null){
				//未被远程邀请
				remotefeeservice.delfee(tel);
				mposRemoteInvitationService.insertRemoteInvitationfee(mposRemoteInvitation,debitT1fee,creditT1Fee,weChatT1fee,aliPayT1Fee,weChatD0fee,aliPayD0Fee,request);
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "邀请成功");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("邀请结果:" + json.toString());
				response.getWriter().write(json.toString());
				return;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "系统错误，请联系管理员！");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("邀请失败:" + json.toString());
			response.getWriter().write(json.toString());
		}
		
	}

	/**
	 * 代理商远程邀请
	 * 
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	public void remoteinvitation001(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		Map hashMap = new HashMap();
		String stel = "";
		try {
			String tel = request.getParameter("tel") == null ? "" : request	.getParameter("tel");
			String fee = request.getParameter("fee") == null ? "" : request	.getParameter("fee");
			String t0Fee = request.getParameter("t0Fee");
			String t0type = request.getParameter("t0type");// 0-费率机，1-封顶机
			String t1type = request.getParameter("t1type"); // 0 费率 1封顶
			String t0fixedamount = request.getParameter("t0fixedamount");// 固定金额
			String t0additionfee = request.getParameter("t0additionfee");// 附加费率
			String t0topamount = request.getParameter("t0topamount");// 封顶
			String t0minamount = request.getParameter("t0minamount");// 单笔范围最小金额
			String t0maxamount = request.getParameter("t0maxamount");// 单笔范围最大金额
			String t1fee = request.getParameter("t1fee");
			String t1topamount = request.getParameter("t1topamount");
//			String cardType = request.getParameter("cardType");

			B2cShopperbiTemp shoppertel = merchantregservice.findbytel(tel);
			MposRemoteInvitation Rtel = mposRemoteInvitationService.findbytel(tel);

			MposRemoteInvitation mposRemoteInvitation = new MposRemoteInvitation();
			mposRemoteInvitation.setT1type(t1type);
			
			mposRemoteInvitation.setCardType(Constants.CON_NO);
			
			/**判断是否允许封顶商户注册：cardtype 0 费率 1 封顶*/
			/*if(!(Constants.CON_NO.equals(cardType))){
				hashMap.put("returnCode", "2222");
				hashMap.put("msg", "交易类型请选择费率");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("交易类型" + json.toString());
				response.getWriter().write(json.toString());
				return;
			}*/
			
			// 费率机
			if (t1type.equals("0")) {
				mposRemoteInvitation.setT1fee(Double.parseDouble(t1fee));
			}
			// 封顶机
			if (t1type.equals("1")) {
				mposRemoteInvitation.setT1fee(Double.parseDouble(t1fee));
				mposRemoteInvitation.setT1topamount(Double.parseDouble(t1topamount));
			}

			
			mposRemoteInvitation.setTel(request.getParameter("tel") == null ? "" : request.getParameter("tel"));
			mposRemoteInvitation.setOpenToFlag(request.getParameter("openToFlag") == null ? "" : request.getParameter("openToFlag"));
			mposRemoteInvitation.setAgentId(request.getParameter("agentId") == null ? "": request.getParameter("agentId"));
			if (request.getParameter("openToFlag").equals("0")) {
				mposRemoteInvitation.setT0minamount(Double.parseDouble(t0minamount));
				mposRemoteInvitation.setT0maxamount(Double.parseDouble(t0maxamount));
				mposRemoteInvitation.setIcCardFlag(request.getParameter("icCardFlag") == null ? "" : request.getParameter("icCardFlag"));
				mposRemoteInvitation.setShopperLimit(request.getParameter("shopperLimit") == null ? "" : request.getParameter("shopperLimit"));
				mposRemoteInvitation.setT0type(t0type);
				// 费率机
				if (t0type.equals("0")) {
					mposRemoteInvitation.setT0Fee(t0Fee);
					mposRemoteInvitation.setT0fixedamount(Double.parseDouble(t0fixedamount));
				}
				// 封顶机
				if (t0type.equals("1")) {
					mposRemoteInvitation.setT0Fee(t0Fee);
					mposRemoteInvitation.setT0fixedamount(Double.parseDouble(t0fixedamount));
					mposRemoteInvitation.setT0additionfee(Double.parseDouble(t0additionfee));
					mposRemoteInvitation.setT0topamount(Double.parseDouble(t0topamount));
				}
			}

			if ((shoppertel != null)) {
				stel = shoppertel.getStel();
				if (tel.equals(stel)) {
					// 该手机号码已存在
					hashMap.put("returnCode", "1111");
					hashMap.put("msg", "电话号码已存在");
				}
			} else if (Rtel != null) {
				// 状态为3
				if (Rtel != null&& (Rtel.getStatus().equals(Constants.STATUS3))) {
					/*MposRemoteFee remotefee = new MposRemoteFee();
					if (org.apache.commons.lang.StringUtils.isNotEmpty(fee)) {
						String[] str = fee.split("\\|");
						for (int i = 0; i < str.length; i++) {
							String a = str[i];
							String fee1 = a.substring(0, a.indexOf(','));
							String top = a.substring(a.indexOf(',') + 1,a.length());
							remotefee.setFee(fee1);
							remotefee.setTopAmount(top);
							remotefee.setStatus(Constants.TYPE_1);
							remotefee.setCreateDate(new Date());
							remotefee.setTel(tel);
							remotefeeservice.insertfee(remotefee);
						}

					}*/
					//String fees=insertfee(cardType,fee,tel);
//					insertfee(cardType,fee,tel);
					remotefeeservice.insert4RemoteFee(tel);
					mposRemoteInvitation.setFee(ToolsUtils.div(Double.parseDouble("0.0065"), 1, 4)+"");
					mposRemoteInvitationService.saveInitiateinvitationapp(mposRemoteInvitation, request);
					hashMap.put("returnCode", "0000");
					hashMap.put("msg", "邀请成功");
				} else if (Rtel != null	&& (Rtel.getStatus().equals(Constants.STATUS4))) {
					// 当状态为4的时候邀请将状态改为3 并且将费率表中的数据删除
					Rtel.setStatus(Constants.STATUS3);
					mposRemoteInvitationService.update(Rtel);
					/*MposRemoteFee remotefee = new MposRemoteFee();
					if (org.apache.commons.lang.StringUtils.isNotEmpty(fee)) {
						String[] str = fee.split("\\|");
						for (int i = 0; i < str.length; i++) {
							String a = str[i];
							String fee1 = a.substring(0, a.indexOf(','));
							String top = a.substring(a.indexOf(',') + 1,a.length());
							remotefee.setFee(fee1);
							remotefee.setTopAmount(top);
							remotefee.setStatus(Constants.TYPE_1);
							remotefee.setCreateDate(new Date());
							remotefee.setTel(tel);
							remotefeeservice.insertfee(remotefee);
						}

					}
*/
					//String fees=insertfee(cardType,fee,tel);
//					insertfee(cardType,fee,tel);
					remotefeeservice.insert4RemoteFee(tel);
					mposRemoteInvitation.setFee(ToolsUtils.div(Double.parseDouble("0.0065"), 1, 4)+"");
					mposRemoteInvitationService.saveInitiateinvitationapp(mposRemoteInvitation, request);
					hashMap.put("returnCode", "0000");
					hashMap.put("msg", "邀请成功");
				} else {
					// 状态为1和2
					hashMap.put("returnCode", "1111");
					hashMap.put("msg", "电话号码已存在");

				}

			} else {
				// 数据中没有的电话号码
				/*MposRemoteFee remotefee = new MposRemoteFee();
				if (org.apache.commons.lang.StringUtils.isNotEmpty(fee)) {
					String[] str = fee.split("\\|");
					for (int i = 0; i < str.length; i++) {
						String a = str[i];
						String fee1 = a.substring(0, a.indexOf(','));
						String top = a.substring(a.indexOf(',') + 1, a.length());
						remotefee.setFee(fee1);
						remotefee.setTopAmount(top);
						remotefee.setStatus(Constants.TYPE_1);
						remotefee.setCreateDate(new Date());
						remotefee.setTel(tel);
						remotefeeservice.insertfee(remotefee);
					}

				}*/
//				String fees=insertfee(cardType,fee,tel);
				remotefeeservice.insert4RemoteFee(tel);
				mposRemoteInvitation.setFee(ToolsUtils.div(Double.parseDouble("0.0065"), 1, 4)+"");
				mposRemoteInvitationService.saveInitiateinvitationapp(mposRemoteInvitation, request);
				hashMap.put("returnCode", "0000");
				hashMap.put("msg", "邀请成功");
			}

			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("邀请结果:" + json.toString());
			response.getWriter().write(json.toString());
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("returnCode", "2222");
			hashMap.put("msg", "邀请失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("邀请失败:" + json.toString());
			response.getWriter().write(json.toString());
		}

	}

	public String insertfee(String cardType, String fee,String tel) {
		MposRemoteFee remotefee = new MposRemoteFee();
		String fee1 = null;
		String top = null;
		String t0fee=null;
		if (org.apache.commons.lang.StringUtils.isNotEmpty(fee)) {
				if(Constants.CON_YES.equals(cardType)){
					if(org.apache.commons.lang.StringUtils.isNotEmpty(fee)){
						String[] fees=fee.split(",");
						fee1=fees[0].toString();
						top=fees[1].substring(0,fees[1].length()-1);
					}
				}else{
					String[] fees=fee.split(",");
					fee1=fees[0].toString();
				}
				double   d   =   Double.parseDouble(fee1);
				t0fee= ToolsUtils.div(d, 1, 4);
				System.out.println("t0fee:"+t0fee);
				remotefee.setFee(t0fee);
				remotefee.setTopAmount(top);
				remotefee.setStatus(Constants.TYPE_1);
				remotefee.setCreateDate(new Date());
				remotefee.setTel(tel);
				remotefeeservice.insertfee(remotefee);
		}
		return t0fee;
	}

	/**
	 * 邀请跟踪
	 * 
	 * @param response
	 * @param request
	 * @throws IOException
	 */
	@RequestMapping(params = "method=agenttrack")
	public void agenttrack(HttpServletResponse response,
			HttpServletRequest request) throws IOException {
		Map hashMap = new HashMap();
		try {
			String agentid = request.getParameter("agentid") == null ? "": request.getParameter("agentid");
			if (org.apache.commons.lang.StringUtils.isNotEmpty(agentid)) {
				String page = request.getParameter("page");
				Map curTranMap = mposRemoteInvitationService.findHisTranList(agentid, page, request);
				hashMap.put("agenttrack", curTranMap.get("list"));
				hashMap.put("page", curTranMap.get("page"));
				hashMap.put("pages", curTranMap.get("pages"));
				hashMap.put("count", curTranMap.get("count"));
				hashMap.put("returnCode", "0000");
				hashMap.put("msg", "邀请跟踪成功");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("邀请跟踪成功:" + json.toString());
				response.getWriter().write(json.toString());
			} else {

				hashMap.put("returnCode", "1111");
				hashMap.put("msg", "代理商编号不存在");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("代理商编号不存在:" + json.toString());
				response.getWriter().write(json.toString());

			}

		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("returnCode", "2222");
			hashMap.put("msg", "邀请跟踪失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("邀请跟踪失败:" + json.toString());
			response.getWriter().write(json.toString());
		}

	}

	/**
	 * 邀请详情
	 * 
	 * @param response
	 * @param request
	 * @throws IOException
	 */
	
	@RequestMapping(params = "method=agentdetails")
	public void agentdetails(HttpServletResponse response,
			HttpServletRequest request) throws IOException {
		String version  = request.getParameter("version") == null ? "" : request.getParameter("version");
	    if((Constants.VERSION_2_0_1).equals(version)){
	    	agentdetails201(request,response);
	    }else{
	    	agentdetails001(request,response);
	    }
	}
	
	private void agentdetails201(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		Map hashMap = new HashMap();
		try {
			String ids=request.getParameter("id") == null ? "" : request.getParameter("id");
			String id = URLDecoder.decode(ids, "UTF-8");
			MposRemoteInvitation invitation = mposRemoteInvitationService.selectByPrimaryKey(Long.valueOf(id));
			String tel = invitation.getTel();
		
			if (invitation == null) {
				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "手机号码不存在:");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("手机号码不存在:" + json.toString());
				response.getWriter().write(json.toString());
			} else {
				Map invitationMap = new HashMap();
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String dateString = formatter.format(invitation	.getRemoteInvitation() == null ? "" : invitation.getRemoteInvitation());
				invitationMap.put("remoteInvitation", dateString);
				invitationMap.put("tel", invitation.getTel() == null ? "": invitation.getTel());
				invitationMap.put("openToFlag", invitation.getOpenToFlag());
//				invitationMap.put("icCardFlag",	invitation.getIcCardFlag() == null ? "" : invitation.getIcCardFlag());
				invitationMap.put("t0Fee", invitation.getT0Fee());
//				invitationMap.put("t0Type", invitation.getT0type());
//				invitationMap.put("t1Type", invitation.getT1type());
				invitationMap.put("t0fixedamount",invitation.getT0fixedamount());
//				invitationMap.put("t0additionfee",invitation.getT0additionfee());
				invitationMap.put("t0maxamount", invitation.getT0maxamount());
				invitationMap.put("t0minamount", invitation.getT0minamount());
//				invitationMap.put("t0topamount", invitation.getT0topamount());
//				invitationMap.put("t1fee", invitation.getT1fee());
//				invitationMap.put("t1topamount", invitation.getT1topamount());

				invitationMap.put("shopperLimit",invitation.getShopperLimit() == null ? "" : invitation	.getShopperLimit());
				invitationMap.put("status", invitation.getStatus() == null ? "": invitation.getStatus());
				
				List list = remotefeeservice.remotefeeList(tel);
				invitationMap.put("feelist", list);
				
				hashMap.put("agentdetails", invitationMap);
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "邀请详情成功");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("邀请详情成功:" + json.toString());
				response.getWriter().write(json.toString());
			}

		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "邀请详情失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("邀请详情失败:" + json.toString());
			response.getWriter().write(json.toString());
		}
		
	}

	public void agentdetails001(HttpServletRequest request,HttpServletResponse response) throws IOException {
		Map hashMap = new HashMap();
		try {
			String id = URLDecoder.decode(request.getParameter("id") == null ? "" : request	.getParameter("id"), "UTF-8");
			MposRemoteInvitation invitation = mposRemoteInvitationService.selectByPrimaryKey(Long.valueOf(id));
			String tel = invitation.getTel();
			MposRemoteFee remotefee = remotefeeservice.findbytel(tel);
			if (invitation == null) {
				hashMap.put("returnCode", "1111");
				hashMap.put("msg", "手机号码不存在:");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("手机号码不存在:" + json.toString());
				response.getWriter().write(json.toString());
			} else {
				Map invitationMap = new HashMap();
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String dateString = formatter.format(invitation	.getRemoteInvitation() == null ? "" : invitation.getRemoteInvitation());
				invitationMap.put("remoteInvitation", dateString);
				invitationMap.put("tel", invitation.getTel() == null ? "": invitation.getTel());
				invitationMap.put("openToFlag", invitation.getOpenToFlag());
				invitationMap.put("icCardFlag",	invitation.getIcCardFlag() == null ? "" : invitation.getIcCardFlag());
				invitationMap.put("t0Fee", invitation.getT0Fee());
				invitationMap.put("t0Type", invitation.getT0type());
				invitationMap.put("t1Type", invitation.getT1type());
				invitationMap.put("t0fixedamount",invitation.getT0fixedamount());
				invitationMap.put("t0additionfee",invitation.getT0additionfee());
				invitationMap.put("t0maxamount", invitation.getT0maxamount());
				invitationMap.put("t0minamount", invitation.getT0minamount());
				invitationMap.put("t0topamount", invitation.getT0topamount());
				invitationMap.put("t1fee", invitation.getT1fee());
				invitationMap.put("t1topamount", invitation.getT1topamount());
				invitationMap.put("cardType", invitation.getCardType());

				invitationMap.put("shopperLimit",invitation.getShopperLimit() == null ? "" : invitation	.getShopperLimit());
				invitationMap.put("status", invitation.getStatus() == null ? "": invitation.getStatus());
				if (remotefee != null) {
					List list = remotefeeservice.findbytel1(tel);
					invitationMap.put("feelist", list);
				}
				hashMap.put("agentdetails", invitationMap);
				hashMap.put("returnCode", "0000");
				hashMap.put("msg", "邀请详情成功");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("邀请详情成功:" + json.toString());
				response.getWriter().write(json.toString());
			}

		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("returnCode", "2222");
			hashMap.put("msg", "邀请详情失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("邀请详情失败:" + json.toString());
			response.getWriter().write(json.toString());
		}

	}

	/**
	 * 重发
	 * 
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(params = "method=agentresend")
	public void agentresend(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		Map hashMap = new HashMap();
		try {
			String id = URLDecoder.decode(request.getParameter("id") == null ? "" : request	.getParameter("id"), "UTF-8");
			MposRemoteInvitation mposRemoteInvitation = mposRemoteInvitationService.selectByPrimaryKey(Long.valueOf(id));
			String status = mposRemoteInvitation.getStatus();
			// 过期的重发状态改为1
			if (mposRemoteInvitation != null&& (status.equals(Constants.STATUS4))) {
				mposRemoteInvitation.setStatus(Constants.STATUS1);
				mposRemoteInvitationService.resendapp(mposRemoteInvitation,	request);
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String dateString = formatter.format(mposRemoteInvitation.getRemoteInvitation() == null ? "": mposRemoteInvitation.getRemoteInvitation());
				hashMap.put("date", dateString);
				hashMap.put("returnCode", "0000");
				hashMap.put("msg", "重发成功");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("重发成功:" + json.toString());
				response.getWriter().write(json.toString());
			} else if (mposRemoteInvitation != null	&& (status.equals(Constants.STATUS1))) {
				mposRemoteInvitationService.resendapp(mposRemoteInvitation,	request);
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String dateString = formatter.format(mposRemoteInvitation.getRemoteInvitation() == null ? "": mposRemoteInvitation.getRemoteInvitation());
				hashMap.put("date", dateString);
				hashMap.put("returnCode", "0000");
				hashMap.put("msg", "重发成功");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("重发成功:" + json.toString());
				response.getWriter().write(json.toString());
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("returnCode", "2222");
			hashMap.put("msg", "重发失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("重发失败:" + json.toString());
			response.getWriter().write(json.toString());
		}
	}

	/**
	 * 撤回
	 * 
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(params = "method=agentrecall")
	public void agentrecall(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		Map hashMap = new HashMap();
		try {
			String id = request.getParameter("id") == null ? "" : request.getParameter("id");
			MposRemoteInvitation mposRemoteInvitation1 = mposRemoteInvitationService.selectByPrimaryKey(Long.valueOf(id));
			String tel = mposRemoteInvitation1.getTel();
			if (mposRemoteInvitation1 != null) {
				if (mposRemoteInvitation1.getStatus().equals("1")|| mposRemoteInvitation1.getStatus().equals("4")) {
					mposRemoteInvitationService.recallapp(mposRemoteInvitation1, tel);
					hashMap.put("returnCode", "0000");
					hashMap.put("msg", "撤回成功");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("撤回成功:" + json.toString());
					response.getWriter().write(json.toString());
				} else {
					hashMap.put("returnCode", "2222");
					hashMap.put("msg", "撤回失败");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("撤回失败:" + json.toString());
					response.getWriter().write(json.toString());
				}

			}
		} catch (Exception e) {

			e.printStackTrace();
			hashMap.put("returnCode", "2222");
			hashMap.put("msg", "撤回失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("撤回失败:" + json.toString());
			response.getWriter().write(json.toString());
		}
	}

}
