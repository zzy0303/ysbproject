package com.uns.util;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.model.B2cDict;
import com.uns.model.B2cShopperbiTemp;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jpos.iso.BaseChannel;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOUtil;
import org.jpos.iso.channel.PostChannel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.UnsupportedEncodingException;
import java.util.*;

@Component
public class HkMerchantUtils {
	protected Log log = LogFactory.getLog(this.getClass());
	
	public ISO8583Packager pack = new ISO8583Packager();

	@Autowired
	private AcmsMapUtils acmsMapUtils;
	
	/**修改商户信息
	 * @param b2cShopperbi
	 * @return
	 * @throws Exception 
	 */
	public String updateHkMerchantPort(B2cShopperbiTemp b2cShopperbi,String bankName) throws Exception {
		Map<String, Object> parameter = new HashMap<String, Object>();
		ISOMsg reqMsg = new ISOMsg();
		BaseChannel channel = new PostChannel(ConstantsEnv.HK_ERVERIP, ConstantsEnv.HK_SERVERPORT, pack);
		channel.setTimeout(60000);
		channel.setHeader(ConstantsEnv.HK_HEADER);
	
		ISOMsg resMsg = send(buildMsgUpdate(reqMsg, b2cShopperbi,parameter,bankName),channel);
		if(null == resMsg)
			log.info("修改海科小商户失败：updateHkMerchantPort");
			
		
		resMsg.setPackager(pack);
		String code = resMsg.getString(39);
		log.info("海科修改商户查询响应码:" + code);
		Map map=setResult(resMsg);
		String rspMsg=new String((byte[])resMsg.getValue(61),"UTF-8");
		log.info("rspMsg##############:"+rspMsg);
		if("00".equals(code)){
			String resMac = resMsg.getString(64);
			if(null != resMac){
				HkUtils.macCalc(resMsg, ConstantsEnv.HK_MERKEY);
				String localMac = resMsg.getString(64);
				if(!resMac.equals(localMac)){
					log.info("修改商户结算信息，秘钥验证出错！");
					
				}else{
					if(ConstantsEnv.UPDATE_RS_PMSG.equals(rspMsg)){
						return ConstantsEnv.RESPONSE_CODE;//成功
					}else{
						log.info("修改商户结算信息失败："+rspMsg);
					}
				}
			}else{
				log.info("修改商户结算信息失败："+rspMsg);
			}
		}else{
			log.info("修改商户结算信息失败："+rspMsg);
			
		}
		return rspMsg;
	}
	
	/**修改小商户信息
	 * @param reqMsg
	 * @param b2cShopperbi
	 * @param parameter
	 * @return
	 * @throws BusinessException 
	 */
	private ISOMsg buildMsgUpdate(ISOMsg reqMsg, B2cShopperbiTemp b2cShopperbi,
			Map<String, Object> parameter,String bankName) throws BusinessException {
		reqMsg.setDirection(ISOMsg.OUTGOING);//位元表
		reqMsg.setPackager(pack);
		try {
			reqMsg.set(0, "0700");
			reqMsg.set(2,  b2cShopperbi.getAccountbankno()+ "");//提现卡号（与报备小商户号结算账号校验） BCD
			reqMsg.set(38, b2cShopperbi.getAccountbankclientname().getBytes("UTF-8"));//银行开户名 BCD
			
			reqMsg.set(44, ConstantsEnv.HK_CHANNELID);//附加响应数据  渠道ID
			reqMsg.set(48, b2cShopperbi.getShopperid()+"");//小商户号 BCD
			
			reqMsg.set(54,bankName.getBytes("UTF-8"));//开户银行 
			reqMsg.set(57,b2cShopperbi.getAccountbankprov().getBytes("UTF-8"));//开户行省份
			reqMsg.set(58,b2cShopperbi.getAccountBankCity().getBytes("UTF-8"));//开户行城市
			reqMsg.set(59,b2cShopperbi.getAccountBankCity().getBytes("UTF-8"));//开户行县区
			reqMsg.set(61,(bankName+b2cShopperbi.getAccountBankCity()+b2cShopperbi.getAccountbankname()).getBytes("UTF-8"));//开户行网点
			reqMsg.set(63,"10B");//清算银行账户类型
			
			HkUtils.macCalc(reqMsg, ConstantsEnv.HK_MERKEY);//MAC
			log.info("修改小商户信息组装    2:"+b2cShopperbi.getAccountbankno()+"	38:"+b2cShopperbi.getAccountbankclientname()+
					"	44:"+ ConstantsEnv.HK_CHANNELID+"	48:"+b2cShopperbi.getShopperid()+"	54:"+bankName+"	57:"+b2cShopperbi.getAccountbankprov()
					+"	58:"+b2cShopperbi.getAccountBankCity()+"	59:"+b2cShopperbi.getAccountBankCity()+
					"	61:"+(bankName+b2cShopperbi.getAccountBankCity()+b2cShopperbi.getAccountbankname())
					+"	63:"+"10B");
			reqMsg.set(63,"10B");//清算银行账户类型
			
			HkUtils.macCalc(reqMsg, ConstantsEnv.HK_MERKEY);//MAC
		} catch (Exception e) {
			e.printStackTrace();
			log.info("修改商户结算信息失败buildMsgUpdate：");
		}
		return reqMsg;
	}
	
	/**新增小商户到海科
	 * @param b2cShopperbi
	 * @return
	 * @throws Exception
	 */
	public String addHkMerchantPort(B2cShopperbiTemp b2cShopperbi,String bankName) throws Exception {
		ISOMsg reqMsg = new ISOMsg();
		BaseChannel channel = new PostChannel(ConstantsEnv.HK_ERVERIP, ConstantsEnv.HK_SERVERPORT, pack);
		channel.setTimeout(60000);
		channel.setHeader(ConstantsEnv.HK_HEADER);
	
		ISOMsg resMsg = send(buildMsgAdd(reqMsg, b2cShopperbi,bankName),channel);
		if(null == resMsg)
			log.info("海科增加小商户失败：addHkMerchantPort");
		
		resMsg.setPackager(pack);
		String code = resMsg.getString(39);
		log.info("海科新增小商户查询响应码:" + code);
		Map map=setResult(resMsg);
		String rspMsg=new String((byte[])resMsg.getValue(61),"UTF-8");
		return code;
	}

	public String updateHkMerchantPort(B2cShopperbiTemp b2cShopperbiTemp, B2cDict b2cDict) throws Exception {
		Map<String, String> param = initUpdateParam(b2cShopperbiTemp, b2cDict);
		String mac = HkUtils.macCalc(FastJson.toJson(param), ConstantsEnv.HK_MERKEY);
		param.put("mac", mac);
		HashMap<String, String> reqParam = new HashMap<>();
		reqParam.put("data", FastJson.toJson(param));
		log.info("海科报备修改请求参数：" + FastJson.toJson(reqParam));
		Map resMap = HttpClientUtils.postRequestMap(ConstantsEnv.HK_REPORT_URL, reqParam, Map.class);
		log.info("海科报备修改返回参数：" + FastJson.toJson(resMap));
		return resMap.get("resCode").toString();
	}

	public String addHkMerchantPort(B2cShopperbiTemp b2cShopperbiTemp, B2cDict b2cDict) throws Exception {
		Map<String, String> param = initAddParam(b2cShopperbiTemp, b2cDict);
		String mac = HkUtils.macCalc(FastJson.toJson(param), ConstantsEnv.HK_MERKEY);
		param.put("mac", mac);
		HashMap<String, String> reqParam = new HashMap<>();
		reqParam.put("data", FastJson.toJson(param));
		log.info("海科报备新增请求参数：" + FastJson.toJson(reqParam));
		Map resMap = HttpClientUtils.postRequestMap(ConstantsEnv.HK_REPORT_URL, reqParam, Map.class);
		log.info("海科报备新增返回参数：" + FastJson.toJson(resMap));

		if (ConstantsEnv.HK_SUCCESS_CODE.equals(resMap.get("resCode").toString()) || ConstantsEnv.HK_SUCCESS_CODE_01.equals(resMap.get("resCode").toString())) {
			return ConstantsEnv.HK_SUCCESS_CODE;
		}
		return resMap.get("resCode").toString();
	}

	public String addHkTerminalPort(String shopperid, String terminalNo,
									String mianKey) throws Exception {
		HashMap<String, String> param = new LinkedHashMap<>();
		param.put("agentNo", ConstantsEnv.HK_CHANNELID);
		param.put("subMerchantNo", shopperid);
		param.put("tradeTerminalNo", terminalNo);
		param.put("tradeTerminalMainKey", mianKey);
		String mac = HkUtils.macCalc(FastJson.toJson(param), ConstantsEnv.HK_MERKEY);
		HashMap<String, String> reqParam = new HashMap<>();
		reqParam.put("sdata", FastJson.toJson(param));
		reqParam.put("mac", mac);
		log.info("海科终端绑定请求参数:" + FastJson.toJson(reqParam));
		String res = HttpClientUtils.postRequestMap1(ConstantsEnv.HK_ADD_TERMINAL, reqParam);
		log.info("海科终端绑定返回参数:" + res);
		if (res.indexOf(Constants.HK_SUCCESS_CODE) > 0) {
			return Constants.HK_SUCCESS_CODE;
		}
		return res;
	}

	public String queryJq(String merchantNo) throws Exception {
		Map<String, String> param = new LinkedHashMap<>();
		param.put("merchantNo", merchantNo);
		param.put("agentNo", ConstantsEnv.HK_CHANNELID);

		String mac = HkUtils.macCalc(FastJson.toJson(param), ConstantsEnv.HK_MERKEY);
		HashMap<String, String> reqParam = new HashMap<>();
		reqParam.put("sdata", FastJson.toJson(param));
		reqParam.put("mac", mac);
		log.info("鉴权请求参数：" + FastJson.toJson(reqParam));
		String res = HttpClientUtils.postRequestMap1(ConstantsEnv.HK_AUTH_QUERY_URL, reqParam);
		return res;
	}

	protected HashMap<String, String> initUpdateParam(B2cShopperbiTemp b2cShopperbiTemp, B2cDict b2cDict) {
		HashMap<String, String> param = new LinkedHashMap<>();
		param.put("tradeType", Constants.TYPE_7);
		param.put("bankAccount", b2cShopperbiTemp.getAccountbankno());
		param.put("bankAccountName", b2cDict.getDict());
		param.put("credentialCode", b2cShopperbiTemp.getIDNo());
		param.put("agentNo", ConstantsEnv.HK_CHANNELID);
		param.put("subMerchantNo", String.valueOf(b2cShopperbiTemp.getShopperid()));
		param.put("bankHeadOffice", b2cDict.getDictcls());
		param.put("bankProvince", b2cShopperbiTemp.getAccountbankprov());
		param.put("bankDistrict", b2cShopperbiTemp.getAccountBankCity());
		param.put("bankCityId", b2cShopperbiTemp.getAccountBankCity());
		param.put("bankDetail", b2cShopperbiTemp.getAccountbankname());
		param.put("clearingBankAccountType", b2cShopperbiTemp.getMerchantType().equals(Constants.TYPE_0) ? Constants.HK_10B : Constants.HK_10A);
		param.put("phone", b2cShopperbiTemp.getStel());
		param.put("chargeFee", acmsMapUtils.getAcmsMap().get("hk_charge_fee"));
		param.put("chargeMoney", acmsMapUtils.getAcmsMap().get("hk_charge_money"));
		param.put("jCardFeeRuleCode", acmsMapUtils.getAcmsMap().get("hk_jcard_fee"));
		param.put("dCardFeeRuleCode", acmsMapUtils.getAcmsMap().get("hk_dcard_fee"));
		return param;
	}

	protected HashMap<String, String> initAddParam(B2cShopperbiTemp b2cShopperbiTemp, B2cDict b2cDict) {
		HashMap<String, String> param = new LinkedHashMap<>();
		param.put("tradeType", Constants.TYPE_6);
		param.put("bankAccount", b2cShopperbiTemp.getAccountbankno());
		param.put("bankAccountName", b2cDict.getDict());
		param.put("credentialCode", b2cShopperbiTemp.getIDNo());
		param.put("agentNo", ConstantsEnv.HK_CHANNELID);
		param.put("subMerchantNo", String.valueOf(b2cShopperbiTemp.getShopperid()));
		param.put("bankHeadOffice", b2cDict.getDictcls());
		param.put("bankProvince", b2cShopperbiTemp.getAccountbankprov());
		param.put("bankDistrict", b2cShopperbiTemp.getAccountBankCity());
		param.put("bankCityId", b2cShopperbiTemp.getAccountBankCity());
		param.put("bankDetail", b2cShopperbiTemp.getAccountbankname());
		param.put("clearingBankAccountType", b2cShopperbiTemp.getMerchantType().equals(Constants.TYPE_0) ? Constants.HK_10B : Constants.HK_10A);
		param.put("province", b2cShopperbiTemp.getSprovince());
		param.put("district", b2cShopperbiTemp.getScity());
		param.put("cityId", b2cShopperbiTemp.getScity());
		param.put("phone", b2cShopperbiTemp.getStel());
		param.put("addrDetail", b2cShopperbiTemp.getSaddress());
		param.put("corporate", b2cShopperbiTemp.getAccountbankclientname());
		param.put("businessLicenseNo", b2cShopperbiTemp.getSynum());
		param.put("corporatePhone", b2cShopperbiTemp.getIDNo());
		param.put("merchantName", b2cShopperbiTemp.getScompany());
		param.put("linkPerson", b2cShopperbiTemp.getName());
		param.put("chargeFee", acmsMapUtils.getAcmsMap().get("hk_charge_fee"));
		param.put("chargeMoney", acmsMapUtils.getAcmsMap().get("hk_charge_money"));
		param.put("jCardFeeRuleCode", acmsMapUtils.getAcmsMap().get("hk_jcard_fee"));
		param.put("dCardFeeRuleCode", acmsMapUtils.getAcmsMap().get("hk_dcard_fee"));
		return param;
	}

	/**新增商户信息解析
	 * @param reqMsg
	 * @param b2cShopperbi
	 * @return
	 * @throws BusinessException
	 */
	private ISOMsg buildMsgAdd(ISOMsg reqMsg,B2cShopperbiTemp b2cShopperbi,String bankName) throws BusinessException {
		reqMsg.setDirection(ISOMsg.OUTGOING);//位元表
		reqMsg.setPackager(pack);
		try {
			reqMsg.set(0, "0600");
			reqMsg.set(2,  b2cShopperbi.getAccountbankno()+ "");//提现卡号（与报备小商户号结算账号校验） BCD
			reqMsg.set(38, b2cShopperbi.getAccountbankclientname().getBytes("UTF-8"));//银行开户名 BCD

			reqMsg.set(44, ConstantsEnv.HK_CHANNELID);//附加响应数据  渠道ID
			reqMsg.set(48, b2cShopperbi.getShopperid()+"");//小商户号 BCD


			reqMsg.set(54,bankName.getBytes("UTF-8"));//开户银行
			reqMsg.set(57,b2cShopperbi.getAccountbankprov().getBytes("UTF-8"));//开户行省份
			reqMsg.set(58,b2cShopperbi.getAccountBankCity().getBytes("UTF-8"));//开户行城市
			reqMsg.set(59,b2cShopperbi.getAccountBankCity().getBytes("UTF-8"));//开户行县区
			reqMsg.set(61,(bankName+b2cShopperbi.getAccountBankCity()+b2cShopperbi.getAccountbankname()).getBytes("UTF-8"));//开户行网点
			reqMsg.set(63,"10B");//清算银行账户类型

			HkUtils.macCalc(reqMsg, ConstantsEnv.HK_MERKEY);//MAC
			log.info("新增小商户信息组装    2:"+b2cShopperbi.getAccountbankno()+"	38:"+b2cShopperbi.getAccountbankclientname()+
					"	44:"+ ConstantsEnv.HK_CHANNELID+"	48:"+b2cShopperbi.getShopperid()+"	54:"+bankName+"	57:"+b2cShopperbi.getAccountbankprov()
					+"	58:"+b2cShopperbi.getAccountBankCity()+"	59:"+b2cShopperbi.getAccountBankCity()+
					"	61:"+(bankName+b2cShopperbi.getAccountBankCity()+b2cShopperbi.getAccountbankname())
					+"	63:"+"10B");
		} catch (Exception e) {
			e.printStackTrace();
			log.info("海科增加小商户失败：buildMsgAdd");

		}
		return reqMsg;
	}


	
	/**海科报备终端主密钥
	 * @param shopperid
	 * @param terminalNo
	 * @param mianKey
	 * @return
	 * @throws ISOException 
	 * @throws UnsupportedEncodingException 
	 */
	/*public String addHkTerminalPort(String shopperid, String terminalNo,
			String mianKey) throws Exception {
		ISOMsg reqMsg = new ISOMsg();
		BaseChannel channel = new PostChannel(ConstantsEnv.HK_ERVERIP, ConstantsEnv.HK_SERVERPORT, pack);
		channel.setTimeout(60000);
		channel.setHeader(ConstantsEnv.HK_HEADER);
	
		ISOMsg resMsg = send(buildMsgAddTerminal(reqMsg,shopperid,terminalNo,mianKey),channel);
		if(null == resMsg)
			throw new BusinessException(ExceptionDefine.海科增加终端设备失败,new String[]{"海科增加终端设备失败!"});
		
		resMsg.setPackager(pack);
		String code = resMsg.getString(39);
		log.info("海科增加终端设备响应码:" + code);
		Map map=setResult(resMsg);
		String rspMsg=new String((byte[])resMsg.getValue(61),"UTF-8");
		return code;
	}*/
	
	/**添加终端信息
	 * @param reqMsg
	 * @param shopperid
	 * @param terminalNo
	 * @param mianKey
	 * @return
	 * @throws Exception
	 */
	public ISOMsg buildMsgAddTerminal(ISOMsg reqMsg, String shopperid,
			String terminalNo, String mianKey) throws Exception {
		reqMsg.setDirection(ISOMsg.OUTGOING);//位元表
		reqMsg.setPackager(pack);
		try {
			reqMsg.set(0, "0900");
			
			reqMsg.set(44, ConstantsEnv.HK_CHANNELID);//附加响应数据  渠道ID
			reqMsg.set(48, shopperid+"");//小商户号 BCD
			
			reqMsg.set(57,terminalNo.getBytes("UTF-8"));//终端号
			reqMsg.set(58,mianKey.getBytes("UTF-8"));//主密钥
			
			HkUtils.macCalc(reqMsg, ConstantsEnv.HK_MERKEY);//MAC
			log.info("报备商户主密钥信息组装  ："+
					"	44:"+ ConstantsEnv.HK_CHANNELID+"	48:"+shopperid+"	57:"+terminalNo+
					"	58:"+mianKey
				);
			
			HkUtils.macCalc(reqMsg, ConstantsEnv.HK_MERKEY);//MAC
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.海科增加终端设备失败,new String[]{"组装修改商户结算信息失败！"});
		}
		return reqMsg;
	}
	/**发送信息到海科
	 * @param reqMsg
	 * @param channel
	 * @return
	 * @throws Exception
	 */
	public ISOMsg send(ISOMsg reqMsg,BaseChannel channel) throws Exception {
		try {
			channel.connect();
			log.info("查询请求报文：" + ISOUtil.hexString(reqMsg.pack()));
			channel.send(reqMsg);
			ISOMsg retMsg = channel.receive();
			log.info("海科增加终端设备响应报文：" + ISOUtil.hexString(retMsg.pack()));
			channel.disconnect();
			return retMsg;
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.海科增加终端设备失败,new String[]{"海科增加终端设备失败，数据转换异常！"});
		}
	}
	
	/**一机一密结果解析
	 * @param resMsg
	 * @return
	 * @throws Exception
	 */
	public Map setResult(ISOMsg resMsg) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("2:", resMsg.getString(2));
		map.put("39:", resMsg.getString(39));
		map.put("44:", resMsg.getString(44));
		map.put("48:", resMsg.getString(48));
		map.put("57:", new String((byte[])resMsg.getValue(57),"UTF-8"));
		map.put("58:", new String((byte[])resMsg.getValue(58),"UTF-8"));
		map.put("61:", new String((byte[])resMsg.getValue(61),"UTF-8"));
		map.put("63:", resMsg.getString(63));
		log.info("海科增加终端设备响应报文解析:" + map);
		return map;
	}


}
