package com.uns.web.form;

import com.uns.model.B2cSettleDetail;

public class AccountForm extends B2cSettleDetail{
	private String merchantNo;
	private String taskId;
	private String mstart;
	private String mend;
	private String createdStart;
	private String createdEnd;
	private String agentNo;
	private String trantStart;
	private String trantEnd;
	private String istrant;//是否结算
	
	public String getTrantStart() {
		return trantStart;
	}
	public void setTrantStart(String trantStart) {
		this.trantStart = trantStart;
	}
	public String getTrantEnd() {
		return trantEnd;
	}
	public void setTrantEnd(String trantEnd) {
		this.trantEnd = trantEnd;
	}
	public String getIstrant() {
		return istrant;
	}
	public void setIstrant(String istrant) {
		this.istrant = istrant;
	}
	public String getAgentNo() {
		return agentNo;
	}
	public void setAgentNo(String agentNo) {
		this.agentNo = agentNo;
	}
	public String getMerchantNo() {
		return merchantNo;
	}
	public void setMerchantNo(String merchantNo) {
		this.merchantNo = merchantNo;
	}
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	
	
	public String getMstart() {
		return mstart;
	}
	public void setMstart(String mstart) {
		this.mstart = mstart;
	}
	public String getMend() {
		return mend;
	}
	public void setMend(String mend) {
		this.mend = mend;
	}
	public String getCreatedStart() {
		return createdStart;
	}
	public void setCreatedStart(String createdStart) {
		this.createdStart = createdStart;
	}
	public String getCreatedEnd() {
		return createdEnd;
	}
	public void setCreatedEnd(String createdEnd) {
		this.createdEnd = createdEnd;
	}
	
	

	
}
