package com.uns.web.form;

public class AppAuthorizationForm {
	
	private String mobile;
	private String pasword;
	private String uuid;
	private String enterpriseUUid;
	private String idCard;
	private String name;
	private String mac;

	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getPasword() {
		return pasword;
	}

	public void setPasword(String pasword) {
		this.pasword = pasword;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getEnterpriseUUid() {
		return enterpriseUUid;
	}

	public void setEnterpriseUUid(String enterpriseUUid) {
		this.enterpriseUUid = enterpriseUUid;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getIdCard() {
		return idCard;
	}

	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}

	public String getMac() {
		return mac;
	}

	public void setMac(String mac) {
		this.mac = mac;
	}

	
	
	
	

}
