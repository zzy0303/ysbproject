package com.uns.dao;

import com.uns.model.Merchant;
import com.uns.model.Users;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Repository
public interface UsersMapper {
	
	//添加商户
	public void addUsers(Map params);
	
	public  List<Users> selectByUsesrName(String userName);
	
	public Users selectByNameId(String shopperid, String userName);
	
	public Users selectByUserId(String shopperid);
	
	public Users selectByPrimaryId(String id);
	
	public void updateByUsresId(Users users);
   
    int deleteByPrimaryKey(BigDecimal id);
    
    void insert(Users users);
   
    int insertSelective(Merchant record);
 
    Users selectByPrimaryKey(BigDecimal id);

    int updateByPrimaryKeySelective(Users record);
   
    int updateByPrimaryKey(Users record);
    
	public List findmposAgent(Long merchantid);
	
	public Users selectBymid(String merchantid);
	
	public Users findbytel(String tel);
	
	public Users findbytelm(String tel);

	public Users selectUsersByAgentNo(String merchantid);
}