package com.uns.service;

import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.dao.TAppGrantAuthorizationMapper;
import com.uns.model.TAppGrantAuthorization;
import com.uns.web.form.AppAuthorizationForm;
@Service
public class AppAuthorizationService  {

	
	@Autowired
	private TAppGrantAuthorizationMapper tAppGrantAuthorizationMapper;

	public TAppGrantAuthorization findTAppGrantAuthorization(String merchantid, String tel) {
		Map map=new HashMap();
		map.put("merchantid", merchantid);
		map.put("tel", tel);
		return tAppGrantAuthorizationMapper.findTAppGrantAuthorization(map);
	}

	public void insertAppAuthorization(AppAuthorizationForm appAuthorizationForm) throws Exception {
		TAppGrantAuthorization tAppGrantAuthorization=new TAppGrantAuthorization();
		tAppGrantAuthorization.setAuthorizationTime(new Date());
		tAppGrantAuthorization.setCreateTime(new Date());
		tAppGrantAuthorization.setCreateUser(appAuthorizationForm.getUuid());
		tAppGrantAuthorization.setUuid(appAuthorizationForm.getUuid());
		tAppGrantAuthorization.setEnterpriseuuid(appAuthorizationForm.getEnterpriseUUid());
		tAppGrantAuthorization.setIdcard(appAuthorizationForm.getIdCard());
		tAppGrantAuthorization.setName(appAuthorizationForm.getName());
		tAppGrantAuthorization.setMobile(appAuthorizationForm.getMobile());
		tAppGrantAuthorization.setStatus(Constants.CON_YES);
		tAppGrantAuthorizationMapper.insertSelective(tAppGrantAuthorization);
		
	}

	public void updateAuthorization(String uuid, String enterpriseUUid) {
		TAppGrantAuthorization tAppGrantAuthorization=new TAppGrantAuthorization();
		tAppGrantAuthorization.setUuid(uuid);
		tAppGrantAuthorization.setEnterpriseuuid(enterpriseUUid);
		tAppGrantAuthorization.setModifyTime(new Date());
		tAppGrantAuthorization.setStatus(Constants.STATUS2);
		tAppGrantAuthorization.setDeleteTime(new Date());
		tAppGrantAuthorizationMapper.updateAuthorization(tAppGrantAuthorization);
		
	}

	public TAppGrantAuthorization findTAppGrantAuthorizationUuid(String uuid, String mobile) {
		Map map=new HashMap();
		map.put("uuid", uuid);
		map.put("tel", mobile);
		return tAppGrantAuthorizationMapper.findTAppGrantAuthorizationUuid(map);
	}
	
	
}
