package com.uns.model;

import java.math.BigDecimal;
import java.util.Date;

public class B2cShopperbiShare {
    private BigDecimal id;

    private String operType;

    private Date operDate;

    private String operChannel;

    private String operContent;

    private String operTel;

    private String operRegTel;

    public String getOperRegTel() {
        return operRegTel;
    }

    public void setOperRegTel(String operRegTel) {
        this.operRegTel = operRegTel;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getOperType() {
        return operType;
    }

    public void setOperType(String operType) {
        this.operType = operType == null ? null : operType.trim();
    }

    public Date getOperDate() {
        return operDate;
    }

    public void setOperDate(Date operDate) {
        this.operDate = operDate;
    }

    public String getOperChannel() {
        return operChannel;
    }

    public void setOperChannel(String operChannel) {
        this.operChannel = operChannel == null ? null : operChannel.trim();
    }

    public String getOperContent() {
        return operContent;
    }

    public void setOperContent(String operContent) {
        this.operContent = operContent == null ? null : operContent.trim();
    }

    public String getOperTel() {
        return operTel;
    }

    public void setOperTel(String operTel) {
        this.operTel = operTel == null ? null : operTel.trim();
    }
}