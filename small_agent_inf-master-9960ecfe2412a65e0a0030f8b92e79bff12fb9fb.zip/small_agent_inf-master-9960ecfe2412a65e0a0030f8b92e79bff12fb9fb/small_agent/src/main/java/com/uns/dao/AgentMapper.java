package com.uns.dao;

import com.uns.model.Agent;
import com.uns.web.form.AgentForm;
import com.uns.web.form.AgentRatioForm;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface AgentMapper {
	/**
	 * 查询代理商
	 * 
	 * @param agent
	 * @return
	 */
	public List<Agent> searchAgentList(AgentForm agentForm);
	
	public List<Agent> selectAgentList(AgentForm agentForm);
	
	/**
	 * 查询代理商树
	 */
	public List<Agent> searchAgentTree(AgentForm agentForm);

	public Agent searchAgentById(String id);
	
	public Agent searchAgentByShopperid(String shopperId);
	
	public Agent searchAgentByName(String scompany);
	
	public List<Agent>findAgentByMerchantId(String shopperId);
	
	public Long searchUserByNameAndShopperid(Map params);
	
	public void updateAgent(Agent agent);

	public List findAgentByMerchantIdMap(String merchantId);

	public List updateAgentByMerchantId(Map map);
	//查出所有代理商
	public List<AgentRatioForm> findB2cAgentList(Long shopperid);
	
	public Map agentInfo(String agentid);

	public List<AgentRatioForm> findB2cAgentFormList(String agentId);
	
	public Agent findbyshopperidp(String shopperidp);
	
	
	public void addAgent(Agent agent);
	
	public List findbytel(String tel);
	
	public Map agentInfotel(String stel);
	
	public void insertUpdateAgentfeeAlog(Map<String, Object> param);
	
	public List<Map<String,Object>> selectUpdateAgentfeeAlogList(String shopperid);


	public List findAgentTopFee();

	public List findAgentByScompay(Map map);

	public String findFisrtAgentByNo(String shopperid);

	public List findAgentTopFeeList();

	public List findAgentTopFeeByType(String type);
	/**
	 *  根据代理商编号递归查询一级代理商 
	 * @param shopperId
	 * @return
	 */
	public List<Agent> findAgentByRecursionShopperId(String shopperId);
	/**
	 * 库存管理终端出库用到的树结构 
	 * @param shopperId
	 * @return
	 */
	public List<Agent>findAgentForTermOutTree(String shopperId);
}