package com.uns.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.SweepCodeProduct;
@Repository
public interface SweepCodeProductMapper {

    int insert(SweepCodeProduct record);

    int insertSelective(SweepCodeProduct record);

	List<SweepCodeProduct> findCodeProductSm();

	List<SweepCodeProduct> findCodeProductMpos();
	
	List<SweepCodeProduct> findAllSweepCodeProduct();
}