package com.uns.dao;

import com.uns.model.B2cFootfreq;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface B2cFootfreqMapper {

	/**结算周期
	 * @return
	 */
	List<B2cFootfreq> searchFootFreqList();


	B2cFootfreq searchFootFreqById(Long footfreqId);
    
}