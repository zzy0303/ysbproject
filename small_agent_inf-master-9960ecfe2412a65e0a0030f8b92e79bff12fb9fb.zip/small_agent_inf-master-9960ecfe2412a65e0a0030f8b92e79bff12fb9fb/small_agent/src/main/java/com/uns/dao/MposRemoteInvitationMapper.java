package com.uns.dao;

import com.uns.model.MposRemoteInvitation;
import com.uns.web.form.MposRemoteInvitationForm;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public interface MposRemoteInvitationMapper {

    int deleteByPrimaryKey(Long remoteInvitationId);

    int insert(MposRemoteInvitation record);

    int insertSelective(MposRemoteInvitation record);

    MposRemoteInvitation selectByPrimaryKey(Long remoteInvitationId);

    int updateByPrimaryKeySelective(MposRemoteInvitation record);

    int updateByPrimaryKey(MposRemoteInvitation record);

	List findMposRemoteInvitationList(MposRemoteInvitationForm mbform);

	List findMposRemoteInvitationByTel(HashMap map);

	void updateData(HashMap map);
	
	List findbytel(String tel);
	
	List findbyagentList(String agentid);
	
	 List findbytelstauts(String tel);
	 void updateByTel(Map map);
	 
}