package com.uns.service;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.exception.BusinessException;
import com.uns.common.myenum.MessageEnum;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.dao.*;
import com.uns.model.*;
import com.uns.util.AesEncrypt;
import com.uns.util.FastJson;
import com.uns.util.Md5Encrypt;
import com.uns.util.ToolsUtils;
import com.uns.web.form.ShopPerbiForm;
import net.sf.json.JSONObject;
import oracle.jdbc.driver.Const;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.*;


@Service
public class ShopPerbiService {
	
	@Autowired
	private UsersMapper usersMapper;
	@Autowired
	private OperatorMapper operatorMapper;
	@Autowired
	private B2cDictMapper b2cDictMapper;
	
	@Autowired
	private MposMerchantFeeMapper mposMerchantFeeMapper;
	
	@Autowired
	private MposPhotoTmpMapper mposphototmpmapper;
	
	@Autowired
	private B2cFootfreqMapper b2cFootfreqMapper;
	
	@Autowired
	private AreaMapper areaMapper;
	
	@Autowired
	private B2cAgentBinderMapper b2cAgentBinderMapper;
	
	@Autowired
	private B2cUserMapper b2cUserMapper;
	
	@Autowired
	private AgentMapper agentMapper;
	
	@Autowired
	private B2cShopperbiMapper b2cShopperbiMapper;
	
	@Autowired
	private B2cShopperbiTempMapper b2cShopperbiTempMapper;
	
	

	@Autowired
	private B2cTermBinderMapper b2cTermBinderMapper;
	
	@Autowired
	private B2cTerminalMapper b2cTerminalMapper;
	
	@Autowired
	private B2cTempTermBinderMapper b2cTempTermBinderMapper;
	

	
	@Autowired
	private MposApplicationProgressMapper progressmapper;
	
	
	@Autowired
	private B2cDictMapper b2cdictmapper;
	
	
	@Autowired
	private B2cShopperbargainTempMapper bartemp;
	
	@Autowired
	private MposRemoteInvitationMapper remotemapper;

	@Autowired
	private BackupsShopperInformationMapper bkshoppermapper;
	
	@Autowired
	private AgentTopFeeMapper agenttopfeemapper;
	
	@Autowired
	private B2cShopperbiTempHistoryMapper b2cShopperbiTempHistoryMapper;
	
	
	@Autowired
	private MposRemoteInvitationMapper mposRemoteInvitationMapper;
	

	@Autowired
	private FixAmaountMapper fixamountMapper;
	
	@Autowired
	private MposRemoteFeeMapper mposRemoteFeeMapper;

	@Autowired
	private AppOpenRegService appOpenRegService;

	@Autowired
	private AppOpenRegOCRService appOpenRegOCRService;

	@Autowired
	private MposPhotoMapper mposPhotoMapper;

	@Autowired
	private MposPhotoTmpMapper mposPhotoTmpMapper;

	@Autowired
	private B2cShopperValMapper b2cShopperValMapper;

    Logger log = LoggerFactory.getLogger(this.getClass());

	public List<HashMap> selectAgentNum(String agentNo){
		List<HashMap> list=b2cAgentBinderMapper.selectBinderNum(agentNo);
		return list;
	}
	/**
	 * 
	 * 查询中间表终端信息
	 * @return 
	 */
	public B2cTempTermBinder selectTempTermNo(String terminalid) {
		return b2cTempTermBinderMapper.selectByTempBinder(terminalid);
	}
	/**
	 * 
	 * 添加绑定的中间表
	 */
	public void addTempBinder(B2cTempTermBinder b2cTempTermBinder) {
		b2cTempTermBinderMapper.insert(b2cTempTermBinder);
	}
	
	/**
	 * 
	 * 商户审核，添加数据到正式表中
	 */
	public void updateShoppbi(B2cShopperbiTemp b2cShopperbi){
		b2cShopperbiMapper.updateShoppbiTemp(b2cShopperbi);
	}
	
	/**
	 * 
	 * 查原有商户绑定的终端
	 */
	public List<HashMap> selectOldTerminal(String shopperid) {
		List<HashMap> Terlist=b2cTerminalMapper.selectOldTerminal(shopperid);
		return Terlist;
	}
	/**
	 * 
	 * 根据terNUM查询代理商编号
	 */
	public B2cAgentBinder selectByTermNo(String termNum){
		B2cAgentBinder agentbinder=b2cAgentBinderMapper.selectAgentnoByTermNo(termNum);
		return agentbinder;
	};
	/**
	 * 
	 * 查商户新绑定的终端
	 */
	public List<HashMap> selectNewBinder(String shopperid) {
		List<HashMap> newTer=b2cTempTermBinderMapper.selectNewBinder(shopperid);
		return newTer;
	}
	/**
	 * 
	 * 查询出中间绑定的中间表
	 */
	public List<HashMap> selectTempBinderList(String  shopperId) {
		List<HashMap> Binderlist=b2cTempTermBinderMapper.selectTempBinderList(shopperId);
		return Binderlist;
	}
	/**
	 * 
	 * 添加User
	 */
	public void addUser(Map params) {
		usersMapper.addUsers(params);
	}
	/**
	 * 
	 * 查询出终端信息
	 * @return 
	 */
	public B2cTerminal findtermainal(String terminalid) {
		return b2cTerminalMapper.selectByPrimaryKey(terminalid);
	}
	/**
	 * 
	 * 查询出终端号是否绑定了商户
	 * @return 
	 */
	public String selectBindtermainal(String terminalid) {
		return b2cTerminalMapper.selectTerminalbind(terminalid);
	}
	
	/** 查询省
	 * @return
	 */
	public List<Area> searchProvince()throws Exception {
		List<Area> list=areaMapper.searchProvince();
		return list;
	}
	public List<Area> searchArea()throws Exception {
		List<Area> list=areaMapper.searchArea();
		return list;
	}
	/** 查询银行
	 * @return
	 */
	public List<B2cDict> searchBank()throws Exception {
		List<B2cDict> list=b2cDictMapper.searchDictBank();
		return list;
	}
	
	/** 查询银行名字
	 * @return
	 */
	public B2cDict findBankName(String b2cDictId)throws Exception {
		B2cDict b2cdict=b2cDictMapper.findDictBankName(b2cDictId);
		return b2cdict;
	}
	/**�̻���Ӧ��ҵ
	 * @param dictclsid
	 * @return
	 */
	public List searchDictCls (String dictclsid)throws BusinessException {
		List<B2cDict> list=b2cDictMapper.searchDictCls(dictclsid);
		return list;
	}

	/**��������
	 * @return
	 */
	public List searchFootFreqList()throws Exception {
		return b2cFootfreqMapper.searchFootFreqList();
	}
	/**
	 * 查询商户信息未审核的个数
	 * @return
	 */
	public String selectCheckCount(ShopPerbiForm shopPerbiForm){
		String ckCount = b2cShopperbiTempMapper.selectCheckCount(shopPerbiForm);
		return ckCount!=null&&!"".equals(ckCount)?ckCount:"0";
	}	
	/**
	 * 查询商户开户银行的信息未审核的个数
	 * @return
	 */
	public String selectCheckBkCount(ShopPerbiForm shopPerbiForm){
		String bankCount = b2cShopperbiTempMapper.selectCheckBkCount(shopPerbiForm);
		return bankCount!=null&&!"".equals(bankCount)?bankCount:"0";
	}
	
	/**
	 * 查询商户终端未审核的个数
	 * @return
	 */
	public String selectTerminalCount(ShopPerbiForm shopPerbiForm){
		String TerCount = b2cShopperbiTempMapper.selectTerminalCount(shopPerbiForm);
		return TerCount!=null&&!"".equals(TerCount)?TerCount:"0";
	}
	
	
	
	//根据merchantid 查询单个的username
	public Users selectByUserId(String shopperid) throws Exception {
		Users user = usersMapper.selectByUserId(shopperid);
		return user;
	}
	
	//根据shopperid 查询单个的fomalshopper
	public B2cShopperbi selectFormalShopperId(String shopperid) throws Exception {
		B2cShopperbi forshopperbi = b2cShopperbiMapper.selectFormalshoppId(shopperid);
		return forshopperbi;
	}
	
	/**查询代理商
	 * @param agentId
	 * @return
	 */
	public Agent searchAgent(Long agentId)throws Exception {
		return agentMapper.searchAgentByShopperid(agentId.toString());
	}
	
	/**查询代理商
	 * @param agentId
	 * @return
	 */
	public Agent selectAgent(Long agentId)throws Exception {
		return agentMapper.searchAgentById(agentId.toString());
	}

	/**省
	 * @param province
	 * @return
	 */
	public List searchProvincial(String province)throws Exception {
		Area area=new Area();
		area.setProvincial(province);
		return areaMapper.searchProvincial(area);
	}
	
	/**查询单个ip
	 * @param provincial
	 * @return
	 */
	public Area searchBankProvincial(String provincial)throws Exception {
		Area pro=areaMapper.searchBankProvince(provincial);
		return pro;
	}
	/**查询单个代理商信息
	 * @param id
	 * @return
	 */
	public Agent searchAgentById(String id) {
		return agentMapper.searchAgentById(id);
	}
	/**城市
	 * @param city
	 * @return
	 */
	public List searchCity(String city)throws Exception {
		Area area=new Area();
		area.setCity(city);
		return areaMapper.searchCity(area);
	}

	/**
	 * @param conDictclsCalling
	 * @param dictid
	 * @return
	 * @throws BusinessException
	 */
	public List searchDictName(String conDictclsCalling, String dictid) throws BusinessException {
		Map<String, String> map=new HashMap<String, String>();
		map.put("dictclsid", conDictclsCalling);
		map.put("dictid", dictid);
		List list= b2cDictMapper.searchDictName(map);
		return list;
	}
	/**查询结算周期
	 * @param footfreqId
	 * @return
	 */
	public B2cFootfreq searchFootFreqById(Long footfreqId)throws Exception {
		return b2cFootfreqMapper.searchFootFreqById(footfreqId);
	}

	public B2cUser selectB2cUserById(Long writeoperid)throws Exception {
		return b2cUserMapper.selectB2cUserById(writeoperid);
	}
	/**查询商户信息
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	public List<HashMap> queryShopPerbiManageList(ShopPerbiForm mbForm) throws BusinessException {
		PageContext.initPageSize(20);
		return b2cShopperbiTempMapper.ShopPerbiManageList(mbForm);
	}
	
	/**查询正式商户信息
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	public List<HashMap> queryFormalManageList(ShopPerbiForm mbForm) throws BusinessException {
		PageContext.initPageSize(20);
		List<HashMap> list = b2cShopperbiMapper.ShopFormalManageList(mbForm);
		return list;
	}
	
	/**查询正式商户信息
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	public List<HashMap> excelFormalManageList(ShopPerbiForm mbForm) throws BusinessException {
		PageContext.initPageSize(Constants.excel_size);
		List<HashMap> list = b2cShopperbiMapper.ShopFormalManageList(mbForm);
		return list;
	}
	
	/**查询出待审核商户的列表信息
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	public List<HashMap> ShopPerbiCheckList(ShopPerbiForm mbForm) throws BusinessException {
		PageContext.initPageSize(20);
		return b2cShopperbiTempMapper.ShopPerbiCheckList(mbForm);
	}
	
	
	/**
	 * @param mbForm
	 * @return    zt
	 * @throws BusinessException
	 */
	public List<HashMap> shopPerbiTerminalList(ShopPerbiForm mbForm) throws BusinessException {
		PageContext.initPageSize(20);
		return b2cShopperbiTempMapper.shopPerbiTerminalList(mbForm);
	}
	/**添加商户表
	 * @param b2cShopperbi
	 */
	public void insertB2cShopperbi(B2cShopperbiTemp b2cShopperbi) {
		b2cShopperbiTempMapper.insert(b2cShopperbi);
	}
	
	/**商户审核通过以后加入到正式表中
	 * @param b2cShopperbi
	 */
	public void insertFormalB2cShopperbi(B2cShopperbiTemp b2cShopperbi) {
		b2cShopperbiMapper.insert(b2cShopperbi);
	}

	/**查询商户信息
	 * @param b2cShopperbiId
	 * @return
	 */
	public B2cShopperbiTemp queryShopPerbi(String b2cShopperbiId)throws Exception {
		return b2cShopperbiTempMapper.selectByshopperId(Long.valueOf(b2cShopperbiId));
	}
	/**查询正式商户信息
	 * @param b2cShopperbiId
	 * @return
	 */
	public B2cShopperbi queryFormalShopPerbi(String b2cShopperbiId)throws Exception {
		return b2cShopperbiMapper.selectFormalshoppId(b2cShopperbiId);
	}

	/**判断是否有同样的公司名
	 * @param scompany
	 * @return
	 */
	public B2cShopperbiTemp findB2cShopperbiScompany(String scompany) {
		return b2cShopperbiTempMapper.selectByScompany(scompany);
	}
	/**修改小商户的资料
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @throws Exception
	 */
	public void updateByShopperId(B2cShopperbiTemp b2cShopperbi,B2cShopperbargainTemp b2cShopperbargain)throws Exception {
		b2cShopperbiTempMapper.updateByShopperId(b2cShopperbi);
		/*B2cShopperbargainTemp b2cShopperbargains=b2cShopperbargainTempMapper.selectByShopperbiId(Long.valueOf(b2cShopperbargain.getShopperid()));
		if(b2cShopperbargains!=null){
			b2cShopperbargainTempMapper.updateByShopperId(b2cShopperbargain);
		}else{
			insertB2cShopperbargain(b2cShopperbargain);
		}*/
//		usersMapper.updateByUsresId(users);
		saveOrUpdateProgress(b2cShopperbi, Constants.TYPE_2);
	}
	/**修改小商户开户银行的资料
	 * @param b2cShopperbi
	 * @param bkshopper
	 * @throws Exception
	 */
	public void updateBankInfo(B2cShopperbiTemp b2cShopperbi,BackupsShopperInformation bkshopper){
		b2cShopperbiTempMapper.updateBankInfo(b2cShopperbi);
		//申请进度
		saveOrUpdateProgress(b2cShopperbi, Constants.TYPE_3);
		BackupsShopperInformation bk=findbkshopper(new BigDecimal(b2cShopperbi.getShopperid()));
		if(bk==null){
			this.bkshoppermapper.insert(bkshopper);
		}
	}
	
	/**审核成功时候，修改正式表中小商户开户银行的资料
	 * @param b2cShopperbi
	 * @throws Exception
	 */
	public void updateFormalBank(B2cShopperbiTemp b2cShopperbi){
		b2cShopperbiMapper.updateFormalBankInfo(b2cShopperbi);
	}
	
	/**
	 * @param b2cShopperbi
	 * @param remark 
	 * @param type
	 * @throws Exception
	 */
	public void updateCheckShopper(B2cShopperbiTemp b2cShopperbi, String type,String status, String remark)throws Exception {
		b2cShopperbiTempMapper.updateBankInfo(b2cShopperbi);
		//b2cShopperbiTempMapper.updateByShopperId(b2cShopperbi);
		updateProgress(b2cShopperbi.getShopperid().toString(),type,status,remark);
	}
	
	public void updateCheckShopper1(B2cShopperbiTemp b2cShopperbi, String type,String status, String remark)throws Exception {
		//b2cShopperbiTempMapper.updateBankInfo(b2cShopperbi);
		b2cShopperbiTempMapper.updateByShopperId(b2cShopperbi);
		updateProgress(b2cShopperbi.getShopperid().toString(),type,status,remark);
	}
	
	public void updatephotoShopper(B2cShopperbiTemp b2cShopperbi, String type,String status, String remark)throws Exception {
		//b2cShopperbiTempMapper.updateBankInfo(b2cShopperbi);
		b2cShopperbiTempMapper.updateByShopperId(b2cShopperbi);
		updateProgress(b2cShopperbi.getShopperid().toString(),type,status,remark);
	}


	/**审核绑定终端
	 * @param b2cShopperbi
	 * @param Shopperid
	 * @throws Exception
	 */
	public void updateTermianl(B2cShopperbiTemp b2cShopperbi,String Shopperid,String status)throws Exception {
		B2cTermBinder Termbinder=new B2cTermBinder();
		b2cShopperbiTempMapper.updateByShopperId(b2cShopperbi);
		if(status.equals("1")){
			//先删除原来取消绑定的的终端
			b2cTermBinderMapper.deleteBinderId(Shopperid);
			List<HashMap> oldTerminl=b2cTempTermBinderMapper.selectNewBinder(Shopperid);
			if(oldTerminl!=null){
				for (int i = 0; i < oldTerminl.size(); i++) {
					Termbinder.setStatus("1");
					Termbinder.setCreateDate(new Date());
					Termbinder.setMerchantNo(Shopperid);
					Termbinder.setMerchantNo(Shopperid);
					Termbinder.setTermNo(oldTerminl.get(i).get("TERMINALID").toString());
					b2cTermBinderMapper.insert(Termbinder);
				}
			}
			b2cTempTermBinderMapper.deleteByMerchantNo(Shopperid);
			B2cShopperbiTemp shopper2=new B2cShopperbiTemp();
			shopper2.setShopperid(Long.valueOf(Shopperid));
			shopper2.setTermianlstatus("1");
			b2cShopperbiTempMapper.updateByShopperId(shopper2);
		}else{
			B2cTermBinder b2c=new B2cTermBinder();
			b2c.setMerchantNo(Shopperid);
			b2c.setStatus("0");
			b2cTermBinderMapper.updateBackBinder(b2c);
			B2cShopperbiTemp shopper=new B2cShopperbiTemp();
			shopper.setShopperid(Long.valueOf(Shopperid));
			shopper.setTermianlstatus("2");
			b2cShopperbiTempMapper.updateByShopperId(shopper);
		}
		
	}
	

	/**
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param shopperId
	 */
	public void updateByB2cShopperId(B2cShopperbiTemp b2cShopperbi,B2cShopperbargainTemp b2cShopperbargain, String shopperId)throws Exception {
		b2cTermBinderMapper.deleteByShopperId(shopperId);
		b2cShopperbiTempMapper.updateByShopperId(b2cShopperbi);
		/*B2cShopperbargainTemp b2cShopperbargains=b2cShopperbargainTempMapper.selectByShopperbiId(Long.valueOf(b2cShopperbargain.getShopperid()));
		if(b2cShopperbargains!=null){
			b2cShopperbargainTempMapper.updateByShopperId(b2cShopperbargain);
		}else{
			insertB2cShopperbargain(b2cShopperbargain);
		}*/
		saveOrUpdateProgress(b2cShopperbi, Constants.TYPE_2);
	}
	/**
	 * @param shopperId
	 * @param agentId
	 * @return
	 */
	public List<B2cTermBinder> selectByB2cTermBinder(String shopperId,String agentId) {
		Map map=new HashMap();
		map.put("shopperId", shopperId);
		map.put("agentId", agentId);
		return b2cTerminalMapper.selectB2cb2cTerminal(map);
	}
	/**查询商户绑定好的终端
	 * @param shopperId
	 * @return
	 */
	public List<HashMap> shopperB2cTermBinder(String shopperId) {
		return b2cTerminalMapper.selectExistTerminal(shopperId);
	}
	
	/**查询商户绑定好的终端
	 * @param shopperId
	 * @return
	 */
	public List<HashMap> selectBinderNum(String shopperId) {
		return b2cTerminalMapper.selectBinderNum(shopperId);
	}
	
	/**查询即将商户绑定好的终端
	 * @param shopperId
	 * @return
	 */
	public List<HashMap> shopperAjaxBinder(String shopperId) {
		return b2cTerminalMapper.selectAjaxTerminal(shopperId);
	}
	
	/**查询商户绑定的终端数量
	 * @param shopperId
	 * @return
	 */
	public String selectTerminalCount(String shopperId) {
		String tercount=b2cTerminalMapper.selectTerminalCount(shopperId);
		return  tercount!=null&&!"".equals(tercount)?tercount:"0";
	}
	
	/**添加终端
	 * @param shopperid
	 * @param bindTerminal
	 * @throws Exception
	 */

	/**查询中间表的终端信息
	 * @param terNo
	 * @throws Exception
	 */
	public B2cTempTermBinder selectByTempBinder(String terNo){
		return b2cTempTermBinderMapper.selectByTempBinder(terNo);
	}
	/**修改绑定终端中间表的
	 * @param b2cTempTermBinder
	 * @throws Exception
	 */
	public void updateTermBinder(B2cTempTermBinder b2cTempTermBinder){
		
		b2cTempTermBinderMapper.updateTermBinder(b2cTempTermBinder);
	}
	
	/**
	 * 将A集合与B集合进行比较，返回A集合中不包含B集合的元素集合
	 * @param arg0
	 * @param arg1
	 * @return
	 */
	public List<String> compareList(String[] arg0, String[] arg1) {
		List<String> startList = transformList(arg0);
		List<String> endList = transformList(arg1);
		for (int i = 0; i < startList.size(); i++) {
			String start = (String) startList.get(i);
			for (int k = 0; k < endList.size(); k++) {
				String end = (String) endList.get(k);
				if ((start).equals(end)) {
					startList.remove(i);
					i = i - 1;
				}
			}
		}
		return startList;
	}
	
	/**
	 * 将数组转换成集合
	 * @param arg0 
	 * @return
	 */
	public List<String> transformList(String[] arg0){
		List<String> transList = new ArrayList<String>();
		for (int i = 0; i < arg0.length; i++) {
			transList.add(i, arg0[i]);
		}
		return transList;
	}
	public void updateBindTerminal( String bindTerminal,String hiddNum)throws Exception {
		 String[] hiddenNum=hiddNum.split(",");
		if(bindTerminal==null || StringUtils.isEmpty(bindTerminal)){
		    for (int i = 0; i < hiddenNum.length; i++) {
			    B2cTempTermBinder termBinder=b2cTempTermBinderMapper.selectByTempBinder(hiddenNum[i]);
				if(termBinder!=null){
					b2cTempTermBinderMapper.deleteByTermno(termBinder.getTermNo());
				}else{
				    B2cTermBinder b2cTermBinder=b2cTermBinderMapper.selectOneBinder(hiddenNum[i]);
				    if(b2cTermBinder!=null && b2cTermBinder.getStatus().equals("0")){
					    b2cTermBinder.setStatus("1");
					    b2cTermBinderMapper.updateIsBinder(b2cTermBinder);
				    }else{
				    	System.out.println("dd");
				    }
				}
		    }
			}else{
		    String[] bindTerminals=bindTerminal.split(",");
			List<String> bindter=compareList(hiddenNum,bindTerminals);
			if(bindter.size()>0){
				for(int j=0;j<bindter.size();j++){
				    B2cTermBinder b2cTermBinder=b2cTermBinderMapper.selectOneBinder(bindter.get(j));
				    if(b2cTermBinder!=null && b2cTermBinder.getStatus().equals("0")){
					    b2cTermBinder.setStatus("1");
					    b2cTermBinderMapper.updateIsBinder(b2cTermBinder);
				    }
				    else{
				        B2cTempTermBinder termBinder=b2cTempTermBinderMapper.selectByTempBinder(bindter.get(j));
				        if(termBinder!=null){
				            b2cTempTermBinderMapper.deleteByTermno(termBinder.getTermNo());
				        }
				    }
				}
			}
			if(bindTerminals.length>0){
				for(int i=0;i<bindTerminals.length;i++){
					B2cTempTermBinder termBinder=b2cTempTermBinderMapper.selectByTempBinder(bindTerminals[i]);
					if(termBinder!=null){
						termBinder.setStatus("1");
						b2cTempTermBinderMapper.updateTermBinder(termBinder);
					}else{
					    B2cTermBinder b2cTermBinder=b2cTermBinderMapper.selectOneBinder(bindTerminals[i]);
					    if(b2cTermBinder!=null && b2cTermBinder.getStatus().equals("1")){
						    b2cTermBinder.setStatus("0");
						    b2cTermBinderMapper.updateIsBinder(b2cTermBinder);
					    }else{
					    	System.out.println("dd");
					    }
					}
				}
			}
	    }
	  
	}
	/**添加终端
	 * @param shopperId
	 * @param bindTerminal
	 * @throws Exception
	 */
	public void insertBindTerminal(String shopperId, String bindTerminal)throws Exception {
		b2cTermBinderMapper.deleteByShopperId(shopperId);
		String[] bindTerminals=bindTerminal.split(",");
		if(bindTerminals.length>0){
			for(int i=0;i<bindTerminals.length;i++){
				B2cTermBinder b2cTermBinder=new B2cTermBinder();
				b2cTermBinder.setMerchantNo(shopperId);
				b2cTermBinder.setTermNo(bindTerminals[i]);
				b2cTermBinder.setCreateDate(new Date());
				b2cTermBinderMapper.insert(b2cTermBinder);
			}
		}
	}
	/**
	 * @param shopperId
	 * @return
	 */
	public List<B2cTermBinder> selectByB2cTermBinderList(String shopperId) {
		return b2cTermBinderMapper.selectByB2cTermBinderList(shopperId);
	}
	/**注册
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @throws Exception
	 */
	public void saveReg( B2cShopperbiTemp b2cShopperbi,B2cShopperbargainTemp b2cShopperbargain,
			MposPhotoTmp photo1,MposApplicationProgress pro,String[] fees,String[] topamounts) throws Exception {
	/*	mposphototmpmapper.insertSelective(photo1);*/
		b2cShopperbi.setPhotoid(photo1.getPhotoId().longValue());
		insertB2cShopperbi(b2cShopperbi);
	//	insertB2cShopperbargain(b2cShopperbargain);
		progressmapper.insertSelective(pro);
		
		if(fees.length>0&&fees!=null){
			for(int i=0;i<fees.length;i++){
				String fee1=fees[i];
				double   d   =   Double.parseDouble(fee1);
				String fee= ToolsUtils.div(d, 100, 4);
				if(com.uns.util.StringUtils.isTrimNotEmpty(fee)){
					MposMerchantFee mposMerchantFee=new MposMerchantFee();
					mposMerchantFee.setShopperid(b2cShopperbi.getShopperid());
					mposMerchantFee.setFee(fee);
					mposMerchantFee.setTopAmount(topamounts[i]);
					mposMerchantFee.setStatus(Constants.CON_YES);
					mposMerchantFee.setCreateDate(new Date());
					mposMerchantFeeMapper.insertSelective(mposMerchantFee);
				}
			}
		}
	}
	public void deleteTempTermianl(String termNo) {
		b2cTempTermBinderMapper.deleteByTermno(termNo);
		
	}
	public List selectByMuserid(String userName) {
		return b2cShopperbiTempMapper.selectByMuserid(userName);
	}
	
	
	public B2cShopperbiTemp findtelbyscompany(String scompany){
		List list=b2cShopperbiTempMapper.findtelbyscompany(scompany);
		B2cShopperbiTemp shopper=null;
		if(list!=null&&list.size()>0){
			shopper=(B2cShopperbiTemp)list.get(0);
		}
		return shopper;  
	}
	 
	 
	
	 
	 
	 
	

		
		/** 查询行业
		 * @return
		 *//*
		public List<B2cDict> searchBank()throws Exception {
			List<B2cDict> list=b2cdictmapper.searchDictBank();
			return list;
		}*/
		//通过行业名查行业
	public B2cDict findbyB2Cname(String bank)throws Exception{
		List list=b2cdictmapper.findbyB2Cname(bank);
		B2cDict industry=null;
		if(list!=null&&list.size()>0){
			industry=(B2cDict)list.get(0);
		}
		return industry; 
	}
	
	public B2cDict findbyhCname(String industryType)throws Exception{
		List list=b2cdictmapper.findbyhCname(industryType);
		B2cDict industry=null;
		if(list!=null&&list.size()>0){
			industry=(B2cDict)list.get(0);
		}
		return industry; 
	}
	//ajax tel
	public B2cShopperbiTemp findtelajax(String tel,String shopperName,String identityId) {
	    Map map=new HashMap();       
	    map.put("tel", tel);
	    map.put("shopperName", shopperName);
	    map.put("identityId", identityId);
	    return b2cShopperbiTempMapper.findtelajax(map);
	}
	 //添加
	public void insertmerchant(B2cShopperbiTemp shopper) {
		b2cShopperbiTempMapper.insertSelective(shopper);
			
	}
	 //通过ID查询
	 
	public B2cShopperbiTemp findmerchantbyNo(String b2cShopperbiId) {
		List list=b2cShopperbiTempMapper.findmerchantbyNo(b2cShopperbiId);
		B2cShopperbiTemp shopper=null;
		if(list!=null&&list.size()>0){
			shopper=(B2cShopperbiTemp)list.get(0);
		}
		return shopper;
	}
	public void savemerchant( B2cShopperbiTemp shopper)  throws BusinessException {
		try{
			shopper.setUpdated(new Date());
			b2cShopperbiTempMapper.updateByPrimaryKeySelective(shopper);  
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	 
	public Area findcityname (String provinceCode,String cityCode){
		Map map=new HashMap();       
	    map.put("provinceCode", provinceCode);
	    map.put("cityCode", cityCode);
	    List list=(List) areaMapper.findcityname(map);
	    Area are=null;
	    if(list!=null&&list.size()>0){
			are=(Area)list.get(0);
	    }
		return are;
	}
	
	 //是否已经注册
	public B2cShopperbi findregajax(String tel,String shopperName,String identityId) {
		Map map=new HashMap();       
		map.put("tel", tel);
		map.put("shopperName", shopperName);
		map.put("identityId", identityId);
		return b2cShopperbiMapper.findregajax(map);
	}
	 
	 /**
	  * 根据商户号查询注册商户信息
	  * @param shopperbiId 商户号
	  * @return
	  */
	public B2cShopperbiTemp findShopperbiTempByShopperid(String shopperbiId) {
		return b2cShopperbiTempMapper.findShopperbiTempByShopperid(shopperbiId);
	}
	 
	public B2cShopperbi findtelbytel(String tel){
		List list=b2cShopperbiMapper.findtelbytel(tel);
		B2cShopperbi shopper=null;
		if(list!=null&&list.size()>0){
			shopper=(B2cShopperbi)list.get(0);
		}
		return shopper;  
	}
	 
	
	 
	public Area findcity (String cityname){
		 
		List list=areaMapper.findcity(cityname);
		Area area=null;
		if(list!=null&&list.size()>0){
			area=(Area)list.get(0);
		}
		return area; 
	}
	 

	public B2cShopperbi findbyid(String identityId){
		List list=b2cShopperbiMapper.findbyid(identityId);
		B2cShopperbi shopper=null;
		if(list!=null&&list.size()>0){
			shopper=(B2cShopperbi)list.get(0);
		}
		return shopper;  
	}
  	
  	public Area findbyname(String provincialname,String cityname){
  		Map map=new HashMap();       
        map.put("provincialname", provincialname);
        map.put("cityname", cityname);
        List list=(List) areaMapper.findbyname(map);
        Area are=null;
        if(list!=null&&list.size()>0){
			are=(Area)list.get(0);
		}
		return are;
       	      
   	}
  
  
  	public Area findbyareaid(String provincial,String city){
  		Map map=new HashMap();       
        map.put("provincial", provincial);
        map.put("city", city);
        List list=(List) areaMapper.findbyareaid(map);
        Area are=null;
        if(list!=null&&list.size()>0){
			are=(Area)list.get(0);
		}
		return are;
       	      
  	}
  	public void saveorinsertprogress(B2cShopperbiTemp shopper,MposApplicationProgress progress) {
		shopper.setUpdated(new Date());
		b2cShopperbiTempMapper.updateByPrimaryKeySelective(shopper);
		progressmapper.insertSelective(progress);
	}
  	/*public void insershopperorprogress(MposPhotoTmp photo,B2cShopperbiTemp shopper,MposApplicationProgress progress,B2cShopperbargainTemp bar,MposRemoteInvitation remote1,String fee) {
  		mposphototmpmapper.insertSelective(photo);
		shopper.setPhotoid(Long.valueOf(photo.getPhotoId()));
  		b2cShopperbiTempMapper.insert(shopper);
  		MposMerchantFee merchantfee = new MposMerchantFee();
		String[] str = fee.split("\\|");
		for (int i = 0; i < str.length; i++) {
			String a = str[i];
			String fee1 = a.substring(0, a.indexOf(','));
			String top = a.substring(a.indexOf(',') + 1, a.length());
			merchantfee.setFee(fee1);
			merchantfee.setTopAmount(top);
			merchantfee.setStatus(Constants.TYPE_1);
			merchantfee.setCreateDate(new Date());
			merchantfee.setShopperid(shopper.getShopperid());
			feemapper.insertSelective(merchantfee);
		}
  		
  		progress.setPhotoId(photo.getPhotoId());
		progressmapper.insertSelective(progress);
		remotemapper.updateByPrimaryKeySelective(remote1);
		bartemp.insert(bar);
	}
  	*/
  	
  	
	public void insershopperorprogress1(B2cShopperbiTemp shopper,MposApplicationProgress progress,B2cShopperbargainTemp bar,MposRemoteInvitation remote1,String fee) {
  		
  		b2cShopperbiTempMapper.insert(shopper);
  		MposMerchantFee merchantfee = new MposMerchantFee();
		String[] str = fee.split("\\|");
		for (int i = 0; i < str.length; i++) {
			String a = str[i];
			String fee1 = a.substring(0, a.indexOf(','));
			String top = a.substring(a.indexOf(',') + 1, a.length());
			merchantfee.setFee(fee1);
			merchantfee.setTopAmount(top);
			merchantfee.setStatus(Constants.TYPE_1);
			merchantfee.setCreateDate(new Date());
			merchantfee.setShopperid(shopper.getShopperid());
			mposMerchantFeeMapper.insertSelective(merchantfee);
		}
  		 	
		progressmapper.insertSelective(progress);
		remotemapper.updateByPrimaryKeySelective(remote1);
		//bartemp.insert(bar);
	}
	
	

	/**
	 * @param shopper
	 * @param progress
	 * @param remote1  注册商户2.0.0版 zt
	 */
	public void saveshopper(B2cShopperbiTemp shopper,MposApplicationProgress progress,MposRemoteInvitation remote1) {
		shopper.setIsformal(new Short(Constants.STATUS1));
		Users user=new Users();
		Users usres=saveUsers(user,shopper);
		usersMapper.insert(usres);
		b2cShopperbiTempMapper.insert(shopper);
  		b2cShopperbiMapper.insert(shopper);
		progressmapper.insertSelective(progress);
		remotemapper.updateByPrimaryKeySelective(remote1);
		
	}
  	
  	/*public void insertsbar(MposPhotoTmp photo,B2cShopperbiTemp shopper,B2cShopperbargainTemp bar,MposApplicationProgress progress,String fee) {
  		mposphototmpmapper.insertSelective(photo);
		shopper.setPhotoid(Long.valueOf(photo.getPhotoId()));
  		b2cShopperbiTempMapper.insert(shopper);
  		MposMerchantFee merchantfee = new MposMerchantFee();
		String[] str = fee.split("\\|");
		for (int i = 0; i < str.length; i++) {
			String a = str[i];
			String fee1 = a.substring(0, a.indexOf(','));
			String top = a.substring(a.indexOf(',') + 1, a.length());
			merchantfee.setFee(fee1);
			merchantfee.setTopAmount(top);
			merchantfee.setStatus(Constants.TYPE_1);
			merchantfee.setCreateDate(new Date());
			merchantfee.setShopperid(shopper.getShopperid());
			feemapper.insertSelective(merchantfee);
		}
  		
  		progress.setPhotoId(photo.getPhotoId());
		progressmapper.insertSelective(progress);
		bartemp.insert(bar);
	}*/
  	
	public void insertsbar1(B2cShopperbiTemp shopper,MposApplicationProgress progress,String fee) {

  	/*	MposMerchantFee mposmerchantfeetemp = new MposMerchantFee();
		String[] str = fee.split("\\|");
		for (int i = 0; i < str.length; i++) {
			String a = str[i];
			String fee1 = a.substring(0, a.indexOf(','));
			String top = a.substring(a.indexOf(',') + 1, a.length());
			double   d   =   Double.parseDouble(fee1);
			String fees=ToolsUtils.div( d, 1, 4);
			mposmerchantfeetemp.setFee(fees);
			mposmerchantfeetemp.setTopAmount(top);
			mposmerchantfeetemp.setStatus(Constants.TYPE_1);
			mposmerchantfeetemp.setCreateDate(new Date());
			mposmerchantfeetemp.setShopperid(shopper.getShopperid());
			mposMerchantFeeMapper.insertSelective(mposmerchantfeetemp);
		}*/
  		b2cShopperbiTempMapper.insert(shopper);
  		insertMerchantFeeList(shopper.getShopperid());
		progressmapper.insertSelective(progress);
	}
  	
	public void insertMerchantFeeList(Long shopperid) {
		mposMerchantFeeMapper.deleteByshopperid(shopperid);
		
		
		MposMerchantFee mposDebitfee=new MposMerchantFee();
		mposDebitfee.setShopperid(Long.valueOf(shopperid));
		mposDebitfee.setFeetype(Constants.CON_NO);//借记卡
		mposDebitfee.setFee(ToolsUtils.div(Double.parseDouble("0.0065"), 1, 4)+"");
		mposDebitfee.setCreateDate(new Date());
		mposDebitfee.setStatus(Constants.CON_YES);
		mposDebitfee.setD0fee(ToolsUtils.div(Double.parseDouble("0.0007"), 1, 4)+"");

		MposMerchantFee mposCreditFee=new MposMerchantFee();
		mposCreditFee.setShopperid(Long.valueOf(shopperid));
		mposCreditFee.setFeetype(Constants.CON_YES);//借记卡
		mposCreditFee.setFee(ToolsUtils.div(Double.parseDouble("0.0065"), 1, 4)+"");
		mposCreditFee.setCreateDate(new Date());
		mposCreditFee.setStatus(Constants.CON_YES);
		mposCreditFee.setD0fee(ToolsUtils.div(Double.parseDouble("0.0007"), 1, 4)+"");
		
		MposMerchantFee mweChatfee=new MposMerchantFee();
		mweChatfee.setShopperid(Long.valueOf(shopperid));
		mweChatfee.setFeetype(Constants.STATUS2);//
		mweChatfee.setFee(ToolsUtils.div(Double.parseDouble("0.0047"), 1, 4)+"");
		mweChatfee.setCreateDate(new Date());
		mweChatfee.setStatus(Constants.CON_YES);
		mweChatfee.setD0fee(ToolsUtils.div(Double.parseDouble("0.0049"), 1, 4)+"");
		
		MposMerchantFee mposAliPayFee=new MposMerchantFee();
		mposAliPayFee.setShopperid(Long.valueOf(shopperid));
		mposAliPayFee.setFeetype(Constants.STATUS3);//借记卡
		mposAliPayFee.setFee(ToolsUtils.div(Double.parseDouble("0.0047"), 1, 4)+"");
		mposAliPayFee.setCreateDate(new Date());
		mposAliPayFee.setStatus(Constants.CON_YES);
		mposAliPayFee.setD0fee(ToolsUtils.div(Double.parseDouble("0.0049"), 1, 4)+"");
		
		mposMerchantFeeMapper.insertSelective(mposDebitfee);
		
		mposCreditFee.setId(mposDebitfee.getId());
		mposMerchantFeeMapper.insert(mposCreditFee);
		
		mweChatfee.setId(mposDebitfee.getId());
		mposMerchantFeeMapper.insert(mweChatfee);
		
		mposAliPayFee.setId(mposDebitfee.getId());
		mposMerchantFeeMapper.insert(mposAliPayFee);
		
	}
  	
  	
  	public void insertsbarb(B2cShopperbiTemp shopper,B2cShopperbargainTemp bar,MposApplicationProgress progress){
  		b2cShopperbiTempMapper.insert(shopper);
		progressmapper.insertSelective(progress);
		bartemp.insert(bar);
  	}
  
  	public B2cShopperbiTemp findbytel(String tel){
  		List list=b2cShopperbiTempMapper.findbytel(tel);
  		B2cShopperbiTemp shopper=null;
		if(list!=null&&list.size()>0){
			shopper=(B2cShopperbiTemp)list.get(0);
		}
		return shopper;  
	}

    /**
     * 查询商户表有无商户认证信息
     * 根据（商户类型+手机号）
     * @param tel
     * @return
     */
	public String findByStel(String tel,String shopperType){
	    String flag = null;
	    Map param = new HashMap();
	    param.put("tel",tel);
	    param.put("merchantType",shopperType);
        flag = b2cShopperbiTempMapper.findCheckStatus(param);
	    return flag;
    }

    /**
     * 查询商户表有无商户认证信息
     * 根据（商户类型+身份证号）
     * @param sid
     * @return
     */
    public Integer findBySidNo(String sid){
        return null;
    }

    /**
     * 聚合支付版-商户认证
     * 查询代理商是否存在
     * @param shopperidp
     * @throws Exception
     */
    public Map querySAgent(String shopperidp) throws Exception {
        Map hashMap = new HashMap();
        //代理商编号不为空
        if(!shopperidp.equals("")){
            Long id = Long.parseLong(shopperidp);
            Agent agent= searchAgent(id);
            if(agent != null){
                hashMap.put("wxFee",agent.getMerchantWxT1Fee());
                hashMap.put("zfbFee",agent.getMerchantZfbT1Fee());
                hashMap.put("rspCode", Constants.SUCCESS_CODE_0000);
                hashMap.put("rspMsg", "查询代理商成功");
                log.info("查询成功:" + FastJson.toJson(hashMap));
            } else {
                //没有找到代理商
                hashMap.put("rspCode", Constants.NOT_AGENT_CODE);
                hashMap.put("rspMsg", "没有查到代理商");
                log.info("查询有误:" + FastJson.toJson(hashMap));
            }
        } else{
            hashMap.put("rspCode", Constants.RETURN_CODE_2222);
            hashMap.put("rspMsg", "代理商编号为空");
            log.info("查询失败:" + FastJson.toJson(hashMap));
        }
        return hashMap;
    }

    /**
     * 聚合支付版-商户登录
     * 根据手机号查询商户预约信息
     * @param tel
     * @return
     */
    public B2cShopperbiTemp findByAggteltemp(String tel){
        return b2cShopperbiTempMapper.findByAggteltemp(tel);
    }

    /**
     * 聚合支付版-商户登录
     * 根据手机号查询商户正式信息
     * @param tel
     * @return
     */
    public B2cShopperbi findByAggtel(String tel){
        return b2cShopperbiMapper.findByAggtel(tel);
    }
	  /**查找进度
		 * @param shopperid
		 * @param type1
		 * @return
		 */
	public MposApplicationProgress findMposApplicationProgress(
			String shopperid, String type1) {
		Map map=new HashMap();
		map.put("shopperid",shopperid);
		map.put("applicationType", type1);
		return progressmapper.findMposApplicationProgress(map);
	}
		
		
		/**修改进度
		 * @param alp
		 */
	public void updateMposApplicationProgress(MposApplicationProgress alp) {
		progressmapper.updateSelective(alp);
	}
		/**保存或修改进度表
		 * @param b2cShopperbi
		 * @param applicationType
		 */
	public void  saveOrUpdateProgress(B2cShopperbiTemp b2cShopperbi,String applicationType){
		//在进度表中插入数据
		MposApplicationProgress alp=findMposApplicationProgress(b2cShopperbi.getShopperid().toString(),applicationType);
		if(alp!=null){
			alp.setApplicationStatus(Constants.TYPE_1);
			alp.setApplicationRemark(b2cShopperbi.getRemark());
			alp.setUpdateDate(new Date());
			updateMposApplicationProgress(alp);
		}else{
			alp=new MposApplicationProgress();
			Agent ag=agentMapper.searchAgentByShopperid(b2cShopperbi.getShopperidP().toString());
			alp.setShopperid(b2cShopperbi.getShopperid().toString());
			alp.setScompany(b2cShopperbi.getScompany());
			alp.setShopperidP(b2cShopperbi.getShopperidP().toString());
			alp.setAgentName(ag.getScompany());
			String theme=getThemeByType(applicationType);
			alp.setApplicationTheme(theme);
			alp.setApplicationType(applicationType);
			alp.setApplicationStatus(Constants.TYPE_1);
			alp.setApplicationRemark(b2cShopperbi.getRemark());
			alp.setCreateDate(new Date());
			progressmapper.insertSelective(alp);
		}
		
	}
		
		/**根据状态获取主题
		 * @param applicationType
		 * @return
		 */
	private String getThemeByType(String applicationType) {
		String theme="";
		if(applicationType.equals(Constants.TYPE_1)){
			theme="商户开通";
		}else if(applicationType.equals(Constants.TYPE_2)){
			theme="变更商户信息";
		}else if(applicationType.equals(Constants.TYPE_3)){
			theme="变更开户信息";
		}else if(applicationType.equals(Constants.TYPE_4)){
			theme="变更终端信息";
		}else if(applicationType.equals(Constants.TYPE_5)){
			theme="变更证照";
		}
		return theme;
	}
		/**修改进度状态
		 * @param shopperid
		 * @param type
		 */
	public void updateProgress(String shopperid, String type,String status,String remark) {
		MposApplicationProgress alp=findMposApplicationProgress(shopperid,type);
		if(alp!=null){
			alp.setApplicationStatus(status);
			alp.setApplicationRemark(remark);
			updateMposApplicationProgress(alp);
		}
	}
	/**修改终端
	 * @param bindTerminal
	 * @param hiddNum
	 * @param shopperbi
	 * @throws Exception
	 */
	public void updateTerminal(String bindTerminal, String hiddNum,
			B2cShopperbiTemp shopperbi) throws Exception {
		updateBindTerminal(bindTerminal,hiddNum);
		b2cShopperbiTempMapper.updateByShopperId(shopperbi);
		//修改申请进度
		saveOrUpdateProgress(shopperbi, Constants.TYPE_4);
		
	}
	
	public MposPhotoTmp selectPhotoTmpById(Long id){
		return mposphototmpmapper.selectByPrimaryKey(new BigDecimal(id));
	}
	
	/**变更证照信息
	 * @param photo1
	 * @throws Exception
	 */
	public void updatePhoto(MposPhotoTmp photo1,MposApplicationProgress pro) throws Exception {
		mposphototmpmapper.updatePhotoTmpById(photo1);
		progressmapper.insertSelective(pro);
	}
	
	public void updatePhoto1(Map maphoto, MposApplicationProgress pro,String photoid,B2cShopperbiTemp b2cShopperbi)
			throws Exception {
		MposPhotoTmp photo =mposphototmpmapper.findbyphotoid(photoid) ;
		String s1 = (String) maphoto.get("signaturePhotoph");
		String s2 = (String) maphoto.get("handIdentityph");
		String s3 = (String) maphoto.get("frontIdentityph");
		String s4 = (String) maphoto.get("reverseIdentityph");
		String s5 = (String) maphoto.get("storePhotoph");
		String s7 = (String) maphoto.get("licensePhotoph");
		String s8 = (String) maphoto.get("instorePhotoph");
		String s9 = (String) maphoto.get("creditCardPhotop");
		String s10 = (String) maphoto.get("settlementCardPhotop");

		if (s1 != null) {
			photo.setSignaturePhoto(s1);
		}
		if (s2 != null) {
			photo.setHandIdentityCardPhoto(s2);
		}
		if (s3 != null) {
			photo.setFrontIdentityCardPhoto(s3);
		}
		if (s4 != null) {
			photo.setReverseIdentityCardPhoto(s4);
		}
		if (s5 != null) {
			photo.setStorePhoto(s5);
		}
		if (s7 != null) {
			photo.setLicensePhoto(s7);
		}
		if (s8 != null) {
			photo.setInstorePhoto(s8);
		}
		if (s9 != null) {
			photo.setCreditCardPhoto(s9);
		}
		if (s10 != null) {
			photo.setSettlementCardPhoto(s10);
		}

		mposphototmpmapper.updatePhotoTmpById(photo);
		
		b2cShopperbi.setPhotoCheckFlag("0");
		this.b2cShopperbiTempMapper.updateByShopperId(b2cShopperbi);
		 MposApplicationProgress ap=this.findMposApplicationProgress(b2cShopperbi.getShopperid().toString(),"5");
		if(ap==null){
			progressmapper.insertSelective(pro);
		}
		
	}
	
	public String selectevicenumCount(ShopPerbiForm shopPerbiForm){
		String ckCount = b2cShopperbiTempMapper.selectevicenumCount(shopPerbiForm);
		return ckCount!=null&&!"".equals(ckCount)?ckCount:"0";
	}

	
	/**
	 * 根据商户号查询费率
	 * @param shopperid
	 * @return
	 */
	public List<HashMap> selectFeeByShopperid(Long shopperid){
		return mposMerchantFeeMapper.selectByMerchantId(shopperid);
	}
	
	public List<HashMap> selectFeeByShopperid1(Long shopperid){
		return mposMerchantFeeMapper.selectByMerchantId1(shopperid);
	}
	
	public int insertbinder(B2cTempTermBinder binder){
		return b2cTempTermBinderMapper.insert(binder);
	}
	
	public Map findHisTranList(String merchantNo, String tPage, HttpServletRequest request) throws IllegalAccessException, InvocationTargetException {
		if (StringUtils.isEmpty(tPage) || !StringUtils.isNumeric(tPage)){
			tPage = "1";
		}
		int currentPage = Integer.valueOf(tPage);
		Page page  = new Page();

		PageContext context = PageContext.getContext();
		page.setCurrentPage(currentPage);
		BeanUtils.copyProperties(context, page);
		context.setPageSize(Constants.page_size);
		context.setPagination(true);
		
		
		List list=b2cTermBinderMapper.findbinderList(merchantNo);
		
		Map map=new HashMap();
		map.put("list", list);
		map.put("page", context.getCurrentPage());
		map.put("pages",context.getTotalPages());
		map.put("count",context.getTotalRows());
		return map;
	}
	
	public B2cTempTermBinder findbyterm(String deviceNum){
		B2cTempTermBinder binder=b2cTempTermBinderMapper.selectByTempBinder(deviceNum);
  		
		return binder;  
	}
	
	public B2cShopperbiTemp findbysid(String identityId){
		List list=b2cShopperbiTempMapper.findbysid(identityId);
		B2cShopperbiTemp shopper=null;
		if(list!=null&&list.size()>0){
			shopper=(B2cShopperbiTemp)list.get(0);
		}
		return shopper;  
	}
	
	
	

	public B2cShopperbiTemp findbyshopperid(String shopperid){
		List list=b2cShopperbiTempMapper.findbyshopperid(shopperid);
		B2cShopperbiTemp shopper=null;
		if(list!=null&&list.size()>0){
			shopper=(B2cShopperbiTemp)list.get(0);
		}
		return shopper;  
	}
	
	public List<B2cShopperbi> judgeShopper(Map<String,Object> map){
		return b2cShopperbiMapper.judgeShopper(map);
	}
	
	public void updateB2cShopperbiTemp(B2cShopperbiTemp b2cShopperbi) {
		b2cShopperbiTempMapper.updateByPrimaryKeySelective(b2cShopperbi);
		
	}
	
	/**
	 * 查询备份表
	 * @param shopperid
	 * @return
	 */
	public BackupsShopperInformation findbkshopper(BigDecimal shopperid){
		return this.bkshoppermapper.findByshopperid(shopperid);
	}
	
	/**查询交易手续费
	 * @return
	 */
	public MposMerchantFee querymerchantfee(String shopperid)throws Exception{
		List list=mposMerchantFeeMapper.findfee(Long.valueOf(shopperid));
		
		MposMerchantFee merchantfee=null;
		if(list!=null&&list.size()>0){
			merchantfee=(MposMerchantFee)list.get(0);
		}
		return merchantfee; 
		
	}
	
	public AgentTopFee findTopFee()throws Exception{
		return this.agenttopfeemapper.findbyid();
	}
	
	
	public void saveagent(Agent agent,Map param,Users user) throws Exception{
		this.agentMapper.addAgent(agent);
		this.agentMapper.insertUpdateAgentfeeAlog(param);
		this.usersMapper.insert(user);
	}
	
	
	/**
	 * 1.现在历史表中插入删除记录
	 * 2.修改远程邀请表(已提交的改为已撤回)
	 * 3.删除记录
	 */
	public void deleteShopperbi(B2cShopperbiTemp b2cShopperbiTemp) {
		b2cShopperbiTempMapper.updateByShopperId(b2cShopperbiTemp);
		b2cShopperbiTempHistoryMapper.insert(b2cShopperbiTemp);
		Map map=new HashMap();
		map.put("status", Constants.STATUS3);
		map.put("tel", b2cShopperbiTemp.getStel());
		map.put("statusq", Constants.STATUS2);
		mposRemoteInvitationMapper.updateByTel(map);
		
		mposMerchantFeeMapper.deleteByshopperid(b2cShopperbiTemp.getShopperid());
		b2cShopperbiTempMapper.deleteByPrimaryKey(new BigDecimal(b2cShopperbiTemp.getB2cShopperbiId()));
		progressmapper.deleteByPrimaryKey(b2cShopperbiTemp.getShopperid().toString());
	}
	
	public Users selectUsersByAgentNo(String merchantid){
		Users user = usersMapper.selectUsersByAgentNo(merchantid);
		return user;
	}
	
	
	public List<HashMap>  findbyshopper(String shopperid){
		return b2cShopperbiTempMapper.findbyshopper(shopperid);
		
	}

    /**
     * 聚合支付版查询商户信息
     * @param shopperid
     * @return
     */
	public List<HashMap> findByAggShopper(String shopperid){

	    return b2cShopperbiTempMapper.findAggShopper(shopperid);
    }
	
	public void savefee(MposMerchantFee merchantfee ){
		mposMerchantFeeMapper.insertSelective(merchantfee);
	}

	
	
	/**绑定终端
	 * @param b2cTempTermBinder
	 * @param b2cTermBinder
	 */
	public void insertTermBinder(B2cTempTermBinder b2cTempTermBinder,
		B2cTermBinder b2cTermBinder) {
		b2cTempTermBinderMapper.insert(b2cTempTermBinder);
		b2cTermBinderMapper.insertSelective(b2cTermBinder);
		
	}
	public List findMposMerchantFee(String shopperid) {
		return mposMerchantFeeMapper.findMposMerchantFee(shopperid);
	}
	public List findDiveceNo(String merchantNo) {
		
		return b2cTermBinderMapper.findDiveceNo(merchantNo);
	}
	
	
	public FixAmaount searchFixAmaount()throws Exception {
		List<FixAmaount> list=fixamountMapper.searchFixAmaount();
		
		FixAmaount fixamount=null;
		if(list!=null&&list.size()>0){
			fixamount=(FixAmaount)list.get(0);
		}
		return fixamount;
	}
	
	
	/**保存用户名密码
	 * @param b2cShopperbi
	 * @return
	 */
	private Users saveUsers(Users users, B2cShopperbiTemp b2cShopperbi) {
		Users user = new Users();
		user.setMerchantid(b2cShopperbi.getShopperid());
		user.setUserName(b2cShopperbi.getMuserid());
		user.setPassword(b2cShopperbi.getMpassword());
		user.setTel(b2cShopperbi.getStel());
		user.setEnabled(Short.valueOf(Constants.CON_YES));
		user.setCreatedate(new Date());
		user.setLocked(Long.valueOf(b2cShopperbi.getSifpactid()==null? Constants.CON_NO:b2cShopperbi.getSifpactid().toString()));
		user.setIsAgent(Short.valueOf(Constants.CON_NO));
		return user;
	}
	public void updateB2cShopperbiTempSmsCode(B2cShopperbiTemp b2cShopperbi) {
		b2cShopperbiTempMapper.updateB2cShopperbiTempSmsCode(b2cShopperbi);
		
	}

	public String findFisrtAgentByNo(String shopperid) {
		return agentMapper.findFisrtAgentByNo(shopperid);
	}
	
	/**代理商面签 保存费率
	 * @param shopper
	 * @param progress
	 * @param debitfee
	 * @param creditfee
	 * @param weChatT1fee
	 * @param aliPayT1Fee
	 * @param weChatD0fee
	 * @param aliPayD0Fee
	 */
	public void insertMerchant(B2cShopperbiTemp shopper,
			MposApplicationProgress progress, String debitfee, String creditfee,
			String weChatT1fee, String aliPayT1Fee, String weChatD0fee, String aliPayD0Fee) {
		
		//删除已存在的之前注册的数据
		mposMerchantFeeMapper.deleteByshopperid(shopper.getShopperid());
		
		MposMerchantFee mposDebitfee=new MposMerchantFee();
		mposDebitfee.setShopperid(shopper.getShopperid());
		mposDebitfee.setFeetype(Constants.CON_NO);//借记卡
		mposDebitfee.setFee(debitfee);
		mposDebitfee.setCreateDate(new Date());
		mposDebitfee.setStatus(Constants.CON_YES);
		mposDebitfee.setD0fee(ToolsUtils.div(Double.parseDouble(shopper.getT0fee() == null ? "0" : shopper.getT0fee().toString()), 1, 4)+"");
		
		MposMerchantFee mposCreditFee=new MposMerchantFee();
		mposCreditFee.setShopperid(shopper.getShopperid());
		mposCreditFee.setFeetype(Constants.CON_YES);//贷记卡
		mposCreditFee.setFee(creditfee);
		mposCreditFee.setCreateDate(new Date());
		mposCreditFee.setStatus(Constants.CON_YES);
		mposCreditFee.setD0fee(ToolsUtils.div(Double.parseDouble(shopper.getT0fee() == null ? "0" : shopper.getT0fee().toString()), 1, 4)+"");
		
	
		MposMerchantFee mweChatfee=new MposMerchantFee();
		mweChatfee.setShopperid(shopper.getShopperid());
		mweChatfee.setFeetype(Constants.STATUS2);//
		mweChatfee.setFee(weChatT1fee);
		mweChatfee.setCreateDate(new Date());
		mweChatfee.setStatus(Constants.CON_YES);
		mweChatfee.setD0fee(weChatD0fee);
		
		MposMerchantFee mposAliPayFee=new MposMerchantFee();
		mposAliPayFee.setShopperid(shopper.getShopperid());
		mposAliPayFee.setFeetype(Constants.STATUS3);//借记卡
		mposAliPayFee.setFee(aliPayT1Fee);
		mposAliPayFee.setCreateDate(new Date());
		mposAliPayFee.setStatus(Constants.CON_YES);
		mposAliPayFee.setD0fee(aliPayD0Fee);
		
		mposMerchantFeeMapper.insertSelective(mposDebitfee);
		
		mposCreditFee.setId(mposDebitfee.getId());
		mposMerchantFeeMapper.insert(mposCreditFee);
		
		mweChatfee.setId(mposDebitfee.getId());
		mposMerchantFeeMapper.insert(mweChatfee);
		
		mposAliPayFee.setId(mposDebitfee.getId());
		mposMerchantFeeMapper.insert(mposAliPayFee);
		
		b2cShopperbiTempMapper.insert(shopper);
		progressmapper.insertSelective(progress);
		
	}
	/**
	 * 远程邀请保存费率
	 */
	public void saveMerchantFee(B2cShopperbiTemp shopper) {
		Map debitfeeMap =new HashMap();
		debitfeeMap.put("tel", shopper.getStel());
		debitfeeMap.put("feetype", Constants.CON_NO);
		MposRemoteFee debitfee=mposRemoteFeeMapper.findMposRemoteFee(debitfeeMap);
		
		MposMerchantFee mposDebitfee=new MposMerchantFee();
		mposDebitfee.setShopperid(shopper.getShopperid());
		mposDebitfee.setFeetype(Constants.CON_NO);//借记卡
		mposDebitfee.setFee(debitfee.getFee());
		mposDebitfee.setCreateDate(new Date());
		mposDebitfee.setStatus(Constants.CON_YES);
		mposDebitfee.setD0fee(ToolsUtils.div(Double.parseDouble(debitfee == null ? "0" : debitfee.getD0fee() == null ? "0" : debitfee.getD0fee().toString()), 1, 4)+"");
		
		Map creditfeeMap =new HashMap();
		creditfeeMap.put("tel", shopper.getStel());
		creditfeeMap.put("feetype", Constants.CON_YES);
		
		MposRemoteFee creditfee=mposRemoteFeeMapper.findMposRemoteFee(creditfeeMap);
		MposMerchantFee mposCreditFee=new MposMerchantFee();
		mposCreditFee.setShopperid(shopper.getShopperid());
		mposCreditFee.setFeetype(Constants.CON_YES);//借记卡
		mposCreditFee.setFee(creditfee.getFee());
		mposCreditFee.setCreateDate(new Date());
		mposCreditFee.setStatus(Constants.CON_YES);
		mposCreditFee.setD0fee(ToolsUtils.div(Double.parseDouble(creditfee == null ? "0" : creditfee.getD0fee() == null ? "0" : creditfee.getD0fee().toString()), 1, 4)+"");
		
		
		Map weChatfeeMap =new HashMap();
		weChatfeeMap.put("tel", shopper.getStel());
		weChatfeeMap.put("feetype", Constants.STATUS2);
		
		MposRemoteFee weChatfee=mposRemoteFeeMapper.findMposRemoteFee(weChatfeeMap);
		MposMerchantFee mweChatfee=new MposMerchantFee();
		mweChatfee.setShopperid(shopper.getShopperid());
		mweChatfee.setFeetype(Constants.STATUS2);//
		mweChatfee.setFee(weChatfee.getFee());
		mweChatfee.setCreateDate(new Date());
		mweChatfee.setStatus(Constants.CON_YES);
		mweChatfee.setD0fee(weChatfee.getD0fee());
		
		Map aliPayFeeMap =new HashMap();
		aliPayFeeMap.put("tel", shopper.getStel());
		aliPayFeeMap.put("feetype", Constants.STATUS3);
		
		MposRemoteFee aliPayFee=mposRemoteFeeMapper.findMposRemoteFee(aliPayFeeMap);
		MposMerchantFee mposAliPayFee=new MposMerchantFee();
		mposAliPayFee.setShopperid(shopper.getShopperid());
		mposAliPayFee.setFeetype(Constants.STATUS3);//借记卡
		mposAliPayFee.setFee(aliPayFee.getFee());
		mposAliPayFee.setCreateDate(new Date());
		mposAliPayFee.setStatus(Constants.CON_YES);
		mposAliPayFee.setD0fee(aliPayFee.getD0fee());
		
		mposMerchantFeeMapper.insertSelective(mposDebitfee);
		
		mposCreditFee.setId(mposDebitfee.getId());
		mposMerchantFeeMapper.insert(mposCreditFee);
		
		mweChatfee.setId(mposDebitfee.getId());
		mposMerchantFeeMapper.insert(mweChatfee);
		
		mposAliPayFee.setId(mposDebitfee.getId());
		mposMerchantFeeMapper.insert(mposAliPayFee);
		
	}
	

	public String findB2cDictQrPAY() {
		return b2cDictMapper.findB2cDictQrPAY();
	}
	
	public List<Map<String, Object>> findGatheringMethod() {
		return b2cDictMapper.findGatheringMethod();
	}
	public List findMposMerchantFeezhifu(String shopperid) {
		return mposMerchantFeeMapper.findMposMerchantFeezhifu(shopperid);
	}
	
	
	public void updateQrCode(String fixedQrCodeUrl,String merchantNo) {
		Map map=new HashMap();
		map.put("fixedQrCodeUrl", fixedQrCodeUrl);
		map.put("fixedQrCodeFlag", Constants.CON_YES);
		map.put("merchantNo", merchantNo);
		b2cShopperbiMapper.updateQrCode(map);
		b2cShopperbiTempMapper.updateQrCode(map);
	}
	
	public void updateb2cShopperbi(B2cShopperbiTemp b2cShopperbi) {
		Map map=new HashMap();
		map.put("qrPayNo", b2cShopperbi.getQrPayNo());
		map.put("qrpayMerchantkey", b2cShopperbi.getQrpayMerchantkey());
		map.put("merchantNo", b2cShopperbi.getShopperid());
		
		b2cShopperbiMapper.updateQrPayCode(map);
		b2cShopperbiTempMapper.updateQrPayCode(map);
	}
	public List<Map<String, Object>> findB2cDictMposPayType() {
		return b2cDictMapper.findB2cDictMposPayType();
	}

	public List<Map<String, Object>> findB2cDictHomeType() {
		
		return b2cDictMapper.findB2cDictHomeType();
	}
	public List<Map<String, Object>> findQrCollectionType() {
		
		return b2cDictMapper.findQrCollectionType();
	}
	public List<Map<String, Object>> findQrSettlementType() {
		
		return b2cDictMapper.findQrSettlementType();
	}
	public List<Map<String, Object>> findMposPayType() {
		return b2cDictMapper.findMposPayType();
	}

	public List<Map<String, Object>> findKjCollectionType() {
		return b2cDictMapper.findKjCollectionType();
	}
	
	public List<Map<String, Object>> findKjCollectionType220(){
		return b2cDictMapper.findKjCollectionType220();
	}

	public List<Map<String, Object>> findB2cDictMerchantType(String dictclsid) {
		return b2cDictMapper.findB2cDictMerHomeType(dictclsid);
	}

	public List<Map<String, Object>> findMerCollectionType(){
        return b2cdictmapper.findMerCollectionType();
    }
	public List<Map<String, Object>> findQrType() {

		return b2cDictMapper.findQrType();
	}
	/**
	 * 设置商户图片id
	 */
	public void setShopperPhotoId(String identityid, Long photoid){
		B2cShopperbiTemp b2cShopperbiTemp = b2cShopperbiTempMapper.findBySid(identityid);
		b2cShopperbiTemp.setPhotoid(photoid);
		b2cShopperbiTempMapper.updateByShopperId(b2cShopperbiTemp);
	}

	/**
     * 聚合支付版
	 * 查询商户认证信息
	 * @param tel
	 * @return
	 */
	public Map findAttestationInfo(String tel){
        Map hashMap = new HashMap();
        Map param = new HashMap();
        String attestation = null;
        String sattestation = null;
        try {

            param.put("tel",tel);
            //OCR实名认证状态
            param.put("merchantType", Constants.TYPE_0);
            String checkStatus = b2cShopperbiTempMapper.findCheckStatus(param);
            //商户预约表里无记录或审核状态为未申请认证
            if(checkStatus == null || checkStatus.equals(Constants.STATUS0)){
                //未认证
                attestation = Constants.ATTESTATION_0;
            } else if(checkStatus != null && !checkStatus.equals(Constants.STATUS0)){
                //已个人认证
                attestation = Constants.ATTESTATION_1;
            }
            hashMap.put("attestation",attestation);
            //商户认证状态
            param.put("merchantType", Constants.TYPE_2);
            checkStatus = b2cShopperbiTempMapper.findCheckStatus(param);
            if(checkStatus == null){
                //未商户认证
                sattestation = Constants.ATTESTATION_0;
            } else{
                //已商户认证
                sattestation = Constants.ATTESTATION_2;
            }
            hashMap.put("sattestation",sattestation);
            hashMap.put("rspCode",Constants.SUCCESS_CODE_0000);
            hashMap.put("rspMsg","查询用户认证状态成功");

        } catch (Exception e){
            e.printStackTrace();
            hashMap.put("rspCode",Constants.SUCCESS_CODE_0000);
            hashMap.put("rspMsg","查询认证状态异常");
            log.info("查询认证状态异常:" + FastJson.toJson(hashMap));
        }
        return hashMap;
	}

    /**
     * 聚合支付版
     * 商户认证 APP接口
     * 添加基本信息
     * @param request
     * @param response
     * @throws Exception
     */
    public Map merchantAttA(HttpServletRequest request,HttpServletResponse response) throws Exception {
        Map hashMap = new HashMap();
        HashMap areaMap = null;
        B2cShopperbiTemp shopperbiTemp = new B2cShopperbiTemp();
        //String shopperType = request.getParameter("merchantType")==null?"":request.getParameter("merchantType").trim();//商户类型0:个人 1:企业 2:商户
        //商户认证
        //组装所需参数
        assembleMerchantParam(request,shopperbiTemp);
        String idNo = shopperbiTemp.getIDNo();

        log.info("请求参数" + request.getQueryString());
        Integer oldShopperbiCount = b2cShopperbiMapper.findSIdNo(idNo);//根据身份证号查询到正式商户信息
        if (oldShopperbiCount > Constants.INT_0) {//正式表中有信息不允许注册
            hashMap.put(Constants.RSP_CODE, MessageEnum.身份证号已被注册.getCode());
            hashMap.put(Constants.RSP_MSG, MessageEnum.身份证号已被注册.getText());
            return hashMap;
        } else {//正式表中没有信息，删除预约信息
            B2cShopperbiTemp oldShopperbiTemp = b2cShopperbiTempMapper.findBySidNo(idNo);
            if (null != oldShopperbiTemp) {
                b2cShopperbiTempMapper.deleteByAggIdCard(idNo);
                b2cShopperbiTempMapper.deleteByAggStel(shopperbiTemp.getStel());//根据手机号删除商户
                mposMerchantFeeMapper.deleteByshopperid(oldShopperbiTemp.getShopperid());//根据商户号删除商户费率
                mposMerchantFeeMapper.deleteTempByshopperid(oldShopperbiTemp.getShopperid());//删除预约费率
                Long photoid = oldShopperbiTemp.getPhotoid();
                if (null != photoid) {
                    mposPhotoMapper.deleteByPrimaryKey(BigDecimal.valueOf(photoid));
                    mposPhotoTmpMapper.deleteByAggMerTmp(idNo);
                }
            }
        }
        //B2cShopperbiTemp oldB2cShopperbiTemp = b2cShopperbiTempMapper.findBySid(idNo);//根据身份证查询到商户信息

        //截取身份证前六位用于查询地区
        String idCardTopSix = idNo.substring(0, 6);
        areaMap = appOpenRegOCRService.getAreaByIdCardTopSix(idCardTopSix);
        // merchantKey值
        String merchantKey = com.uns.util.StringUtils.getCharAndNumr(8);
        shopperbiTemp.setMerchantKey(merchantKey);

        Long shopperid = Long.valueOf(appOpenRegService.getPosShopperId((String) areaMap.get("city"), Constants.CON_MCC));//生成小商户号
        shopperbiTemp.setShopperid(shopperid);
        shopperbiTemp.setCreated(new Date());//创建时间
        b2cShopperbiTempMapper.insertSelective(shopperbiTemp);
        //返回微信、支付宝默认费率
        hashMap.put(Constants.RSP_WX_FEE,Constants.MERCHANT_DEFAULT_WX_FEE);
        hashMap.put(Constants.RSP_ZFB_FEE,Constants.MERCHANT_DEFAULT_ZFB_FEE);
        hashMap.put(Constants.RSP_CODE,Constants.SUCCESS_CODE_0000);
        hashMap.put(Constants.RSP_MSG,"认证商户基本信息成功!");
        return hashMap;
    }

	/**
	 * 聚合支付版商户保存认证信息
	 *
	 * @throws Exception
	 */
	public HashMap saveMerAttestationInfo(HttpServletRequest request) throws Exception {
		HashMap hashMap = new HashMap();
		//获取商户手机号
		String stel = request.getParameter("stel") == null ? "" : request.getParameter("stel");
		//根据手机号查询到商户
		B2cShopperbiTemp b2cShopperbiTemp = b2cShopperbiTempMapper.findByAggteltemp(stel);
		/*//删除费率（中断注册）
		mposMerchantFeeMapper.deleteByshopperid(b2cShopperbiTemp.getShopperid());
		mposMerchantFeeMapper.deleteTempByshopperid(b2cShopperbiTemp.getShopperid());
*/
		//商户其他信息添加
		saveMerOtherInfo(hashMap, b2cShopperbiTemp);

		//新建用户、预约信息更新和正式信息表的插入
		hashMap = saveshopper(b2cShopperbiTemp,hashMap);

		if (Constants.SUCCESS_CODE.equals(hashMap.get(Constants.RSP_CODE))) {
			hashMap.put(Constants.RSP_CODE, MessageEnum.成功.getCode());
			hashMap.put(Constants.RSP_MSG, MessageEnum.已注册成功请登录.getText());
			log.info("商户认证信息保存成功：" + FastJson.toJson(hashMap));
		} else if (MessageEnum.商户认证失败.getCode().equals(hashMap.get(Constants.RSP_CODE))) {
			hashMap.put(Constants.RSP_CODE, MessageEnum.商户认证失败.getCode());
			hashMap.put(Constants.RSP_MSG, MessageEnum.商户认证失败.getText());
		} else {
			hashMap.put(Constants.RSP_CODE, MessageEnum.出错.getCode());
			hashMap.put(Constants.RSP_MSG, MessageEnum.出错.getText());
		}
		return hashMap;
	}

	/**
	 * 保存商户认证其它信息
	 * @param b2cShopperbiTemp
	 */
	private void saveMerOtherInfo(HashMap hashMap,B2cShopperbiTemp b2cShopperbiTemp) throws Exception{
		b2cShopperbiTemp.setReportResource(Constants.TYPE_4);// 设置报件来源为开放注册
		b2cShopperbiTemp.setCreated(new Date());//设置创建时间
		b2cShopperbiTemp.setMerchantType(Constants.CON_SH);//商户
		b2cShopperbiTemp.setIsSupportT0(Constants.STATUS1);//支持T+0 0支持1不支持

		b2cShopperbiTemp.setFixqrcodecustomername(Constants.FIX_NAME + b2cShopperbiTemp.getSmanager().substring(0, 1) + "**");

		b2cShopperbiTemp.setIsexternalrevenue(Constants.CON_NO);

		// 所在城市票据
		b2cShopperbiTemp.setBillCity(b2cShopperbiTemp.getScity());
		b2cShopperbiTemp.setBillCityCode(b2cShopperbiTemp.getCity());
		b2cShopperbiTemp.setBillProvince(b2cShopperbiTemp.getSprovince());
		b2cShopperbiTemp.setBillProvinceCode(b2cShopperbiTemp.getProvince());

		// 票据地址
		b2cShopperbiTemp.setBillAddress(b2cShopperbiTemp.getSaddress());

		// 默认添加字段
		b2cShopperbiTemp.setIfvalid(Short.valueOf(Constants.STATUS0));
		b2cShopperbiTemp.setOpencheckstatus(Short.valueOf(Constants.STATUS0));
		b2cShopperbiTemp.setIsformal(Short.valueOf(Constants.STATUS0));
		b2cShopperbiTemp.setIsupdateshopper(Short.valueOf(Constants.STATUS0));
		b2cShopperbiTemp.setSifpactid(Long.valueOf(Constants.STATUS0));
		b2cShopperbiTemp.setRecheckmerchantflag(Constants.STATUS0);
		b2cShopperbiTemp.setPhotoCheckFlag(Constants.STATUS0);
		b2cShopperbiTemp.setPhotoRecheckFlag(Constants.STATUS0);
		b2cShopperbiTemp.setTransact(Constants.STATUS1);//设置未审核

		b2cShopperbiTemp.setT0topamount(Double.parseDouble(Constants.MONEY_0));
		b2cShopperbiTemp.setT1type(Constants.STATUS0);
		b2cShopperbiTemp.setT0type(Constants.STATUS0);
		b2cShopperbiTemp.setCardType(Constants.STATUS0);
		b2cShopperbiTemp.setT0additionfee(Double.parseDouble(Constants.MONEY_0));
		b2cShopperbiTemp.setT1topamount(Double.parseDouble(Constants.MONEY_0));
		b2cShopperbiTemp.setIsIcApplyT0(Constants.STATUS0);
		b2cShopperbiTemp.setT0minamount(Double.parseDouble(Constants.MONEY_197));
		b2cShopperbiTemp.setT0maxamount(Double.parseDouble(Constants.MIN_SETTLE_MONEY));
		b2cShopperbiTemp.setT0SingleDayLimit(Double.parseDouble(Constants.MIN_SETTLE_MONEY));
		b2cShopperbiTemp.setSettleType(Constants.CON_YES);//1是普通
		b2cShopperbiTemp.setCreditLines(Double.parseDouble(Constants.MIN_SETTLE_MONEY));//扫码授信额度5W

		//添加分润方案
		b2cShopperbiTemp.setAgentProfitRatio(ConstantsEnv.AGENT_PROFIT_RATIO);
		b2cShopperbiTemp.setProfitOwner(ConstantsEnv.PROFIT_OWNER);
		b2cShopperbiTemp.setMerchProfitRatio1(ConstantsEnv.MERCH_PROFIT_RATIO1);
		b2cShopperbiTemp.setMerchProfitRatio2(ConstantsEnv.MERCH_PROFIT_RATIO2);
		b2cShopperbiTemp.setMerchProfitRatio3(ConstantsEnv.MERCH_PROFIT_RATIO3);

		//设置商户状态为未审核
		b2cShopperbiTemp.setCheckstatus(Constants.CHECK_STATUS_6);//审核状态设置为6（未审核）
		b2cShopperbiTemp.setToManualauditDate(new Date());
		b2cShopperbiTemp.setVisualCheckStatus(Constants.TYPE_0);//设置人工检查状态为0

		//添加merchantKey值
		String merchantKey = com.uns.util.StringUtils.getCharAndNumr(8);
		b2cShopperbiTemp.setMerchantKey(merchantKey);


		//添加商户的muser和mpassword（从商户验证码表中）
		B2cShopperVal b2cShopperVal = new B2cShopperVal();
		b2cShopperVal.setTel(b2cShopperbiTemp.getStel());
		List<B2cShopperVal> b2cShopperValList = b2cShopperValMapper.queryByParam(b2cShopperVal);
		if (null != b2cShopperValList) {
			b2cShopperVal = b2cShopperValList.get(0);
		}
		//设置商户登陆用户名和密码
		b2cShopperbiTemp.setMuserid(b2cShopperVal.getTel());
		b2cShopperbiTemp.setMpassword(Md5Encrypt.md5(b2cShopperVal.getPassword()));
		if(null != b2cShopperVal.getInviteCodeP()){
			b2cShopperbiTemp.setInviteCodeP(b2cShopperVal.getInviteCodeP());
		}
		b2cShopperbiTemp.setShopperidP(b2cShopperbiTemp.getShopperidP() == null ? null : b2cShopperbiTemp.getShopperidP());
		b2cShopperbiTemp.setSagentid(b2cShopperbiTemp.getShopperidP() == null ? null : b2cShopperbiTemp.getShopperidP());
		//设置商户图片id
		if (StringUtils.isNotEmpty(b2cShopperbiTemp.getIDNo())) {
			MposPhotoTmp mposPhotoTmp = mposPhotoTmpMapper.selectByMerIdNo(b2cShopperbiTemp.getIDNo());
			b2cShopperbiTemp.setPhotoid(mposPhotoTmp.getPhotoId());
		}
	}

	/**
     * 聚合支付版 商户认证
	 * 添加用户、更新商户预约、添加正式表
	 * @param shopperbiTemp
	 */
	public HashMap saveshopper(B2cShopperbiTemp shopperbiTemp,HashMap hashMap) {
		B2cShopperbi b2cShopperbi = b2cShopperbiMapper.findByAggtel(shopperbiTemp.getStel());
		if (b2cShopperbi == null) {
			Users user = usersMapper.findbytelm(shopperbiTemp.getStel());
			//如用户不存在
			if(user == null){
				Users usres = saveUsers(user, shopperbiTemp);
				//添加用户
				usersMapper.insert(usres);
			}
			//更新预约信息
			b2cShopperbiTempMapper.updateByPrimaryKeySelective(shopperbiTemp);
			//插入正式表
			b2cShopperbiMapper.insert(shopperbiTemp);
			hashMap.put(Constants.RSP_CODE, MessageEnum.成功.getCode());
			hashMap.put(Constants.RSP_MSG, MessageEnum.成功.getText());
		} else {
			hashMap.put(Constants.RSP_CODE,MessageEnum.商户认证失败.getCode());
			hashMap.put(Constants.RSP_MSG,MessageEnum.商户认证失败.getText());
		}

		return hashMap;
	}

    /**
     *  聚合支付版-商户补件
     *  修改商户
     * @param request
     * @param response
     * @throws IOException
     *
     */
    public HashMap updateAggShopperA(HttpServletRequest request,
                                  HttpServletResponse response) throws Exception {
        HashMap hashMap = new HashMap();
        String shopperid = request.getParameter("shopperid");
        // 根据商户号得到shopper对象
        B2cShopperbiTemp shopper = findbyshopperid(shopperid);
        if (shopper == null) {
            hashMap.put("rspCode", "1111");
            hashMap.put("rspMsg", "商户信息修改失败");
            log.info("商户信息修改失败:" + FastJson.toJson(hashMap));
        } else {
            //组装商户参数
            assembleMerchantParam(request,shopper);

            //注册(补进商户)为"5"
            shopper.setReportResource(Constants.TYPE_5);
            shopper.setIfvalid(Short.valueOf(Constants.STATUS0));
            shopper.setRecheckaccountflag(Constants.STATUS0);
            shopper.setRecheckmerchantflag(Constants.STATUS0);
            shopper.setOpencheckstatus(new Short(Constants.STATUS0));

            //更改审核状态
            shopper.setCheckstatus(Constants.CHECK_STATUS_6);//未审核
            //修改商户预约表
            updateB2cShopperbiTemp(shopper);
            hashMap.put("rspCode", "0000");
            hashMap.put("rspMsg", "商户信息修改成功");
            log.info("商户信息修改成功" + FastJson.toJson(hashMap));
        }
        return hashMap;
    }

    /**
     * 聚合支付版商户补件
     * 修改结算信息
     * @param request
     * @param response
     * @throws IOException
     */
    public void updateAggBankInfo(HttpServletRequest request,HttpServletResponse response) throws IOException {
        HashMap hashMap = new HashMap();
        try {
            String shopperid = request.getParameter("shopperid");
            String bankCard = request.getParameter("bankCard") == null ? "" :
                    AesEncrypt.decryptAES(request.getParameter("bankCard").trim(), ConstantsEnv.APP_AES_KEY).toUpperCase();// 结算卡号
            String bankName = request.getParameter("bankName");// 开户银行
            String branchBankName = URLDecoder.decode(request.getParameter("branchBankName"), "UTF-8");// 支行名称
            String name = request.getParameter("name"); // 姓名
            String accountLineNumber = request.getParameter("accountLineNumber"); //开户行联行号
            String zfbFee = request.getParameter("zfbFee") == null ? "" : request.getParameter("zfbFee").trim(); // 支付宝费率
            String wxFee = request.getParameter("wxFee") == null ? "" : request.getParameter("wxFee").trim(); // 微信费率
            // 根据商户号得到shopper对象
            B2cShopperbiTemp shopper = findbyshopperid(shopperid);
            if (shopper == null) {
                hashMap.put("rspCode", "2222");
                hashMap.put("rspMsg", "结算银行卡信息修改失败");
                response.setContentType("UTF-8");
                JSONObject json = JSONObject.fromObject(hashMap);
                log.info("结算银行卡信息修改失败:" + json.toString());
                response.getWriter().write(json.toString());
            } else {
				//获取银行编码
				String bankCode = b2cShopperbiTempMapper.findBankCode(bankName);
				shopper.setAccountbankdictval(bankCode); //开户银行名称，数据字典

                shopper.setAccountbankother(bankName); //开户银行
                shopper.setAccountbankclientname(name); //开户人
                shopper.setAccountbankname(branchBankName);
                shopper.setAccountbankno(bankCard);
                shopper.setRecheckaccountflag(Constants.STATUS0);
                shopper.setOpencheckstatus(new Short(Constants.STATUS0));
                shopper.setAccountBankLineNumber(accountLineNumber);
                shopper.setName(name);
                updateB2cShopperbiTemp(shopper);
                //修改商户费率
                updateMerchantFee(zfbFee,wxFee,shopperid);
                hashMap.put("rspCode", "0000");
                hashMap.put("rspMsg", "结算信息修改成功");
                response.setContentType("UTF-8");
                JSONObject json = JSONObject.fromObject(hashMap);
                log.info("结算信息修改成功:" + json.toString());
                response.getWriter().write(json.toString());

            }

        } catch (Exception e) {
            e.printStackTrace();
            hashMap.put("rspCode", "2222");
            hashMap.put("rspMsg", "结算信息修改失败");
            response.setContentType("UTF-8");
            JSONObject json = JSONObject.fromObject(hashMap);
            log.info("结算信息修改失败:" + json.toString());
            response.getWriter().write(json.toString());
        }
    }

    /**
     * 聚合支付版
     * 修改费率
     * @param zfbFee
     * @param wxFee
     * @param shopperid
     */
    private void updateMerchantFee(String zfbFee,String wxFee,String shopperid){
        MposMerchantFee mposMerchantFeeMpos = null;
        //初始费率表id设置为0
        Long id = new Long(Constants.INT_0);

        mposMerchantFeeMpos = new MposMerchantFee();
        mposMerchantFeeMpos.setId(id);
        mposMerchantFeeMpos.setShopperid(Long.valueOf(shopperid));
        mposMerchantFeeMpos.setChannelType(Constants.T1_CHANNEL_TYPE); //渠道类型 T1 2002
        mposMerchantFeeMpos.setProType(Constants.TYPE_1); //1 mpos 2 sm
        mposMerchantFeeMpos.setUpdateDate(new Date());

        //微信费率
        mposMerchantFeeMpos.setFeetype(Constants.FEE_TYPE_WX);
        mposMerchantFeeMpos.setFee(wxFee);
        mposMerchantFeeMapper.updateMerchantFee(mposMerchantFeeMpos);
        mposMerchantFeeMapper.updateMerchantFeeTemp(mposMerchantFeeMpos);
        //支付宝费率
        mposMerchantFeeMpos.setFeetype(Constants.FEE_TYPE_ZFB);
        mposMerchantFeeMpos.setFee(zfbFee);
        mposMerchantFeeMapper.updateMerchantFee(mposMerchantFeeMpos);
        mposMerchantFeeMapper.updateMerchantFeeTemp(mposMerchantFeeMpos);
    }

    /**
     * 组装商户认证所需参数
     */
    public void assembleMerchantParam(HttpServletRequest request,B2cShopperbiTemp shopper) throws Exception {
        String smanager = URLDecoder.decode(request.getParameter("smanager")==null?"":request.getParameter("smanager").trim(),"UTF-8"); //法人姓名
        String sid = request.getParameter("identityId").toUpperCase()==null?"":request.getParameter("identityId").toUpperCase().trim(); //法人身份证号
        String srelation = request.getParameter("srelation").toUpperCase()==null?"":request.getParameter("srelation").toUpperCase().trim(); //联系人姓名
        String stel = request.getParameter("stel")==null?"":request.getParameter("stel").trim(); //手机号
        String shandset = request.getParameter("shandset")==null?"":request.getParameter("shandset").trim(); //联系人手机号
        String semail = request.getParameter("semail")==null?"":request.getParameter("semail").trim(); //邮箱
        String scompany = URLDecoder.decode(request.getParameter("scompany") == null ? "" : request.getParameter("scompany").trim(), "UTF-8");// 店铺名称
        String shortname = request.getParameter("shortname")==null?"":request.getParameter("shortname").trim(); //店铺简称
        String industryType = request.getParameter("industryType")==null?"":request.getParameter("industryType").trim(); //行业类别
        String City = request.getParameter("City")==null?"":request.getParameter("City").trim();// 经营城市
        String Province = request.getParameter("Province")==null?"":request.getParameter("Province").trim();// 经营省份

        String saddress = request.getParameter("saddress")==null?"":request.getParameter("saddress").trim(); //店铺地址

        String licenseNo=request.getParameter("licenseNo")== null ? ""	: request.getParameter("licenseNo"); //营业执照编号
        String licenseName = request.getParameter("licenseName")==null?"":request.getParameter("licenseName").trim(); //营业执照名称
        String licenseAddress = request.getParameter("licenseAddress")==null?"":request.getParameter("licenseAddress").trim(); //营业执照地址
        String currentLocation = request.getParameter("currentLocation");// 当前位置
		//如果没有代理商ID 则绑定默认公有代理商
        String shopperidP = request.getParameter("shopperidp") == null ? ConstantsEnv.MPOS_DEFAULT_AGENT :request.getParameter("shopperidp");// 代理商ID

        shopper.setIndustry(industryType);
        // 所在城市票据
        Area area = findbyareaid(Province, City);
        if(area != null){
            shopper.setBillCity(area.getCityname());
            shopper.setScity(area.getCityname());
            shopper.setBillCityCode(area.getCity());
            shopper.setBillProvince(area.getProvincialname());
            shopper.setSprovince(area.getProvincialname());
            shopper.setBillProvinceCode(area.getProvincial());
        }


        shopper.setSmanager(smanager);
        shopper.setSaddress(saddress);
        shopper.setLicenseName(licenseName);
        shopper.setSemail(semail);
        shopper.setScompany(scompany);
        shopper.setLicenseNo(licenseNo);
        shopper.setSynum(licenseNo);
        shopper.setSrelation(srelation);
        shopper.setMuserid(stel);
        shopper.setStel(stel);
        shopper.setShandset(shandset);
        shopper.setShortname(shortname);
        shopper.setCity(City);
        shopper.setProvince(Province);
        shopper.setLicenseAddress(licenseAddress);
        shopper.setIDNo(sid);
        shopper.setCurrentLocation(currentLocation);
        shopper.setMerchantType(Constants.TYPE_2);
        shopper.setShopperidP(Long.valueOf(shopperidP));
    }

}
