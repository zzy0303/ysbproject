package com.uns.model;

import java.util.Date;

public class B2cTermBinder {
    
    private String 	merchantNo;
    private String 	termNo;
    private Date 	createDate;
    private String 	status;
    
    private Long 	id;
    private String 	create_user;
    private Date 	update_date;
    private String 	update_user;
    private String 	batch_no;
    private String 	terminal_type_no;
    private String 	factory_no;
    private String 	agent_no;
    private String 	parent_agent_no;
    private String 	inventory_status;
    private String 	user_status;
    private Date 	binder_date;
    private String 	binder_user;
    private String  upper_level_agent_no;//上级代理商编号
    private String operation;//操作标识
    
    public Date getBinder_date() {
		return binder_date;
	}
	public void setBinder_date(Date binder_date) {
		this.binder_date = binder_date;
	}
	public String getBinder_user() {
		return binder_user;
	}
	public void setBinder_user(String binder_user) {
		this.binder_user = binder_user;
	}
	public Long getId() {
		return id; 
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCreate_user() {
		return create_user;
	}
	public void setCreate_user(String create_user) {
		this.create_user = create_user;
	}
	public Date getUpdate_date() {
		return update_date;
	}
	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}
	public String getUpdate_user() {
		return update_user;
	}
	public void setUpdate_user(String update_user) {
		this.update_user = update_user;
	}
	public String getBatch_no() {
		return batch_no;
	}
	public void setBatch_no(String batch_no) {
		this.batch_no = batch_no;
	}
	public String getTerminal_type_no() {
		return terminal_type_no;
	}
	public void setTerminal_type_no(String terminal_type_no) {
		this.terminal_type_no = terminal_type_no;
	}
	public String getFactory_no() {
		return factory_no;
	}
	public void setFactory_no(String factory_no) {
		this.factory_no = factory_no;
	}
	public String getAgent_no() {
		return agent_no;
	}
	public void setAgent_no(String agent_no) {
		this.agent_no = agent_no;
	}
	public String getParent_agent_no() {
		return parent_agent_no;
	}
	public void setParent_agent_no(String parent_agent_no) {
		this.parent_agent_no = parent_agent_no;
	}
	public String getInventory_status() {
		return inventory_status;
	}
	public void setInventory_status(String inventory_status) {
		this.inventory_status = inventory_status;
	}
	public String getUser_status() {
		return user_status;
	}
	public void setUser_status(String user_status) {
		this.user_status = user_status;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMerchantNo() {
        return merchantNo;
    }
    public void setMerchantNo(String merchantNo) {
        this.merchantNo = merchantNo == null ? null : merchantNo.trim();
    }
    public String getTermNo() {
        return termNo;
    }
    public void setTermNo(String termNo) {
        this.termNo = termNo == null ? null : termNo.trim();
    }
    public Date getCreateDate() {
        return createDate;
    }
   
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
	public String getUpper_level_agent_no() {
		return upper_level_agent_no;
	}
	public void setUpper_level_agent_no(String upper_level_agent_no) {
		this.upper_level_agent_no = upper_level_agent_no;
	}
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	
	
    
    
    

}