package com.uns.model;

import java.math.BigDecimal;

public class BankBranch {
    private BigDecimal id;

    private String bankBranchName;

    private String uniteNumber;

    private String bankName;

    private String bankCity;

    private String bankProvince;

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getBankBranchName() {
        return bankBranchName;
    }

    public void setBankBranchName(String bankBranchName) {
        this.bankBranchName = bankBranchName == null ? null : bankBranchName.trim();
    }

    public String getUniteNumber() {
        return uniteNumber;
    }

    public void setUniteNumber(String uniteNumber) {
        this.uniteNumber = uniteNumber == null ? null : uniteNumber.trim();
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName == null ? null : bankName.trim();
    }

    public String getBankCity() {
        return bankCity;
    }

    public void setBankCity(String bankCity) {
        this.bankCity = bankCity == null ? null : bankCity.trim();
    }

    public String getBankProvince() {
        return bankProvince;
    }

    public void setBankProvince(String bankProvince) {
        this.bankProvince = bankProvince == null ? null : bankProvince.trim();
    }
}