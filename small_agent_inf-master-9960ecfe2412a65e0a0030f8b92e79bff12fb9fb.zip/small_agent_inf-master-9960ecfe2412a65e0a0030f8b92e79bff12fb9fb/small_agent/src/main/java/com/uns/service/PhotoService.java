package com.uns.service;

import com.uns.common.Constants;
import com.uns.dao.B2cShopperbiTempMapper;
import com.uns.dao.MposApplicationProgressMapper;
import com.uns.dao.MposPhotoTmpMapper;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.MposApplicationProgress;
import com.uns.model.MposPhotoTmp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class PhotoService {
	
	
	@Autowired
	private MposPhotoTmpMapper mposphototmpmapper;
	
	@Autowired
	private B2cShopperbiTempMapper b2cShopperbiTempMapper;
	
	@Autowired
	private ImageInterfaceService imageInterfaceService;

	@Autowired
	private MposApplicationProgressMapper progressmapper;
	 //添加
	 public void insertphoto(MposPhotoTmp photo) {
		 mposphototmpmapper.deleteByPrimaryKey(photo.getIdentityid());
		 mposphototmpmapper.insertSelective(photo);
	}
	 
	 public void inserOrUpdatetphoto(MposPhotoTmp photo,String oldphotoid) {
         mposphototmpmapper.insertSelective(photo);
         Map map=new HashMap();
         map.put("newphotoid", photo.getPhotoId());
         map.put("oldphotoid", oldphotoid);
         if(photo.getMerchantType().equals(Constants.TYPE_2)){
             map.put("merchantType",Constants.TYPE_2);
         } else {
             map.put("merchantType",Constants.TYPE_0);
         }
		 b2cShopperbiTempMapper.updateByphoto(map);
	}


	public void insertphotoAndshopper(MposPhotoTmp photo1,	B2cShopperbiTemp shopper,MposApplicationProgress progress) {
		mposphototmpmapper.insertSelective(photo1);
		shopper.setPhotoid(Long.valueOf(photo1.getPhotoId()));
		b2cShopperbiTempMapper.updateByPrimaryKeySelective(shopper);
		progress.setPhotoId(photo1.getPhotoId());
		progressmapper.updateByPrimaryKeySelective(progress);
		
	}
	
	public MposPhotoTmp findbsid(String sid){
	
		List list= mposphototmpmapper.findbysid(sid);
		MposPhotoTmp photo=null;
		if(list!=null&&list.size()>0){
			photo=(MposPhotoTmp)list.get(0);
		}
		return photo;
	}

	/**
	 * 商户版查找有无图片记录
	 * 根据身份证+商户类型
	 * @param sid
	 * @return
	 */
	public MposPhotoTmp findAggsid(String sid){

		List list= mposphototmpmapper.findByAggsid(sid);
		MposPhotoTmp photo=null;
		if(list!=null&&list.size()>0){
			photo=(MposPhotoTmp)list.get(0);
		}
		return photo;
	}

	public MposPhotoTmp findbyphotoid(String photoid){
		return mposphototmpmapper.findbyphotoid(photoid);
	}
	
	 //更新
	 public void updatephoto(MposPhotoTmp photo) {
		 mposphototmpmapper.updatePhotoTmpByIdNo(photo); 
	 } 
		
}
