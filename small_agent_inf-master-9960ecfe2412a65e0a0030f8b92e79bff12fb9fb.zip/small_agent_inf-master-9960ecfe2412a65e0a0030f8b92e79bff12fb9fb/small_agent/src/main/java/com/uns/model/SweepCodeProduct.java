package com.uns.model;

import java.math.BigDecimal;

public class SweepCodeProduct {
    private Long id;

    private String proName;

    private String proT1Fee;

    private String proD0Fee;

    private String proFeeType;

    private String proStatus;

    private String proSort;

    private String channelType;

    private String proType;

    private BigDecimal eachamount;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProName() {
        return proName;
    }

    public void setProName(String proName) {
        this.proName = proName == null ? null : proName.trim();
    }

    public String getProT1Fee() {
        return proT1Fee;
    }

    public void setProT1Fee(String proT1Fee) {
        this.proT1Fee = proT1Fee == null ? null : proT1Fee.trim();
    }

    public String getProD0Fee() {
        return proD0Fee;
    }

    public void setProD0Fee(String proD0Fee) {
        this.proD0Fee = proD0Fee == null ? null : proD0Fee.trim();
    }

    public String getProFeeType() {
        return proFeeType;
    }

    public void setProFeeType(String proFeeType) {
        this.proFeeType = proFeeType == null ? null : proFeeType.trim();
    }

    public String getProStatus() {
        return proStatus;
    }

    public void setProStatus(String proStatus) {
        this.proStatus = proStatus == null ? null : proStatus.trim();
    }

    public String getProSort() {
        return proSort;
    }

    public void setProSort(String proSort) {
        this.proSort = proSort == null ? null : proSort.trim();
    }

    public String getChannelType() {
        return channelType;
    }

    public void setChannelType(String channelType) {
        this.channelType = channelType == null ? null : channelType.trim();
    }

    public String getProType() {
        return proType;
    }

    public void setProType(String proType) {
        this.proType = proType == null ? null : proType.trim();
    }

    public BigDecimal getEachamount() {
        return eachamount;
    }

    public void setEachamount(BigDecimal eachamount) {
        this.eachamount = eachamount;
    }
}