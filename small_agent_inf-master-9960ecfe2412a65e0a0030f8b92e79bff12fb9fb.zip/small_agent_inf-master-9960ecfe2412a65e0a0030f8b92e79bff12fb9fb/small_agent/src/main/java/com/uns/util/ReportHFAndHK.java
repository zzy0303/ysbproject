package com.uns.util;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.myenum.MessageEnum;
import com.uns.dao.B2cDictMapper;
import com.uns.dao.MposPhotoTmpMapper;
import com.uns.model.B2cDict;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.MposPhotoTmp;
import com.uns.service.AppOpenRegService;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

/**
 * 注册弘付和海科
 * created by lak
 */
@Component
public class ReportHFAndHK {
    
    private Logger Log = LoggerFactory.getLogger(ReportHFAndHK.class);

    @Autowired
    private AcmsMapUtils acmsMapUtils;

    @Autowired
    private B2cDictMapper dictMapper;

    @Autowired
    private HkMerchantUtils hkMerchantUtils;

    @Autowired
    MposPhotoTmpMapper mposPhotoTmpMapper;

    /**
     * 报备弘付
     * @param b2cShopperbiTemp
     * @return
     */
    public HashMap reportHF(B2cShopperbiTemp b2cShopperbiTemp) throws Exception {
        HashMap hashMap = new HashMap();
        MposPhotoTmp mposPhotoTmp =mposPhotoTmpMapper.findbyphotoid(String.valueOf(b2cShopperbiTemp.getPhotoid()));
        //验证图片是否上传成功
        if(null == mposPhotoTmp){
            Log.info("图片上传未成功，不能进行弘付报备！");
            hashMap.put(Constants.RSP_CODE, MessageEnum.报备弘付失败.getCode());
            hashMap.put(Constants.RSP_MSG, MessageEnum.报备弘付失败.getText());
            return hashMap;
        }
        //弘付商户信息图片报备
        HfImageRegUtil.hfImagesReg(mposPhotoTmp, String.valueOf(b2cShopperbiTemp.getShopperid()));
        String hfRspCode = null;//弘付返回码
        String hf_psam_d0 = null;//调用接口返回弘付D0终端号
        net.sf.json.JSONObject jsonObject = null;//接收报备结果
        jsonObject = addHfMerchantPortD0(b2cShopperbiTemp);//调用弘付报备接口
        hfRspCode = (String) jsonObject.get("respCode");//接收弘付返回码
        hf_psam_d0 = (String) jsonObject.get("hf_psam");//接收弘付D0终端号
        //如果是返回码不是弘付申请成功，抛出异常
        if (!ConstantsEnv.HF_CODE_ADD.equals(hfRspCode)) {
            Log.info("弘付报备申请失败:{}", jsonObject.toString());
            hashMap.put(Constants.RSP_CODE, MessageEnum.报备弘付失败.getCode());
            hashMap.put(Constants.RSP_MSG, MessageEnum.报备弘付失败.getText());
        } else {
            Log.info("弘付报备成功:{}", jsonObject.toString());
            hashMap.put(Constants.RSP_CODE, MessageEnum.成功.getCode());
            hashMap.put(Constants.RSP_MSG, MessageEnum.成功.getText());
            //设置商户的弘付报备状态和弘付D0终端号
            b2cShopperbiTemp.setHfflg(Constants.CON_YES);
            b2cShopperbiTemp.setHfpsamd0(hashMap.get("hf_psam_d0").toString());
        }
        return hashMap;
    }

    /**
     * 报备海科
     * @param b2cShopperbiTemp
     * @return
     */
    public HashMap reportHK(B2cShopperbiTemp b2cShopperbiTemp) throws Exception {
        HashMap hashMap = new HashMap();
        //弘付成功之后调用海科注册
        B2cDict b2cDict = dictMapper.findDictBankName(b2cShopperbiTemp.getAccountbankdictval());
        //注册海科
        String hkRspCode = hkMerchantUtils.addHkMerchantPort(b2cShopperbiTemp, b2cDict);
        if (ConstantsEnv.HK_SUCCESS_CODE.equals(hkRspCode)) {
            Log.info("海科报备成功:" + hkRspCode);
            b2cShopperbiTemp.setHkflg(Constants.CON_YES);
            hashMap.put(Constants.RSP_CODE, MessageEnum.成功.getCode());
            hashMap.put(Constants.RSP_MSG, MessageEnum.成功.getText());
        } else if (ConstantsEnv.HK_REPEAT_CODE_H2.equals(hkRspCode)) {
            String updateHkCOde = hkMerchantUtils.updateHkMerchantPort(b2cShopperbiTemp, b2cDict);
            if (!(ConstantsEnv.RESPONSE_CODE.equals(updateHkCOde))) {
                Log.info("海科注册修改失败:" + hkRspCode);
                hashMap.put(Constants.RSP_CODE, MessageEnum.修改报备海科失败.getCode());
                hashMap.put(Constants.RSP_MSG, MessageEnum.修改报备海科失败.getText());
            }
        } else {
            Log.info("海科注册新增失败:" + hkRspCode);
            hashMap.put(Constants.RSP_CODE, MessageEnum.报备海科失败.getCode());
            hashMap.put(Constants.RSP_MSG, MessageEnum.报备海科失败.getText());
        }
        return hashMap;
    }

    /**
     * =申请弘付D0
     * 费率规则：例  封顶35千78费率，费率代号为（FD35Q78）。终端分
     * 为借记卡费率与贷记卡费率填写格式  借记卡费率|贷记卡费率 例（FD20Q5|Q5）
     * 修改费率时需要将借记卡费率与贷记卡费率一起上送
     * @param b2cShopperbi
     * @return
     * @throws Exception
     */
    public net.sf.json.JSONObject addHfMerchantPortD0(B2cShopperbiTemp b2cShopperbi) throws BusinessException {
        String respCode = null;
        try {
            String key = ConstantsEnv.HF_KEY;//加密key
            String URL = ConstantsEnv.HF_MERCHANT_URL;//请求地址

            Map<String, String> reqMap = new HashMap<String, String>();
            reqMap.put("orgMerno", b2cShopperbi.getShopperid()==null?"":b2cShopperbi.getShopperid().toString());		//机构商户唯一标识
            reqMap.put("bankName", b2cShopperbi.getAccountbankname());													//开户行名称
            reqMap.put("licenseEndDate", "2050-01-01");																	//营业执照到期时间   yyyy-MM-dd，无数据给默认日期
            reqMap.put("linkMan", b2cShopperbi.getName());																//联系人
            reqMap.put("areaCode", b2cShopperbi.getCity());																//受理区域代码
            reqMap.put("linkPhone", b2cShopperbi.getStel());															//联系电话
            reqMap.put("idCard", b2cShopperbi.getIDNo());																//法人身份证号
            reqMap.put("businessLicense", b2cShopperbi.getLicenseno()==null?"":b2cShopperbi.getLicenseno());			//营业执照号
            reqMap.put("accountNo", b2cShopperbi.getAccountbankno());													//账号
            reqMap.put("legalPerson", b2cShopperbi.getName());															//法人
            reqMap.put("shortName", b2cShopperbi.getName());															//商户简称
            reqMap.put("businessAddress", b2cShopperbi.getSaddress());													//营业地址
            reqMap.put("accountName", b2cShopperbi.getAccountbankclientname());														//账户名
            reqMap.put("regionCode", b2cShopperbi.getCity());															//行政地区码
            reqMap.put("bankNo", dictMapper.findB2cDictBank(b2cShopperbi.getAccountbankdictval()));																				//开户行行号,无数据给0000
            reqMap.put("merName", b2cShopperbi.getScompany());															//商户名称
            reqMap.put("registeredAddress", b2cShopperbi.getSaddress());												//注册地址


            reqMap.put("txnType", Constants.CON_NO);																		//交易类型 0申请 1变更
            reqMap.put("posType", Constants.CON_YES);																		//pos类型,给默认值1
            reqMap.put("groupNo", Constants.STATUS2);																//费率类型（0标准类 1优惠类2综合类）

            reqMap.put("args", Constants.CON_YES);																			//机构自定义，给默认值1
            reqMap.put("userSign", ConstantsEnv.HF_USERSIGN);																//机构标识，由上游提供，请联系技术
            reqMap.put("requestUrl", "");																				//异步密钥通知地址  接收到返回请返回 success字符串 意味着成功接收到异步通知 则停止通知
            //，若未响应则会连续推三次，三次之后则不会继续推送

            reqMap.put("isthirdpos", ConstantsEnv.ISTHIRDPOS);								//秘钥类型   0机构秘钥 1 终端秘钥	(不填写,默认 1终端秘钥)								
            reqMap.put("merchant_mode", ConstantsEnv.MERCHANT_MODE); 							//商户模式 0 一户一码 1 大商户	(不填写 默认 1 大商户)

            reqMap.put("arMark", acmsMapUtils.getAcmsMap().get("hf_arMark"));			// CAP2100R610|R620&CAP2100R610|R620(D1费率（借|贷）& S0费率（借|贷））)   
            reqMap.put("sRate", acmsMapUtils.getAcmsMap().get("hf_sRate"));				//S0附加手续费填写代号，例：例(FJ200)代表加收2块（FJ250）代表加收2块5
            reqMap.put("posDealType", Constants.CON_YES);								//必填 终端交易类型 0 D1 1 S0  445347692


            NameValuePair[] data = {
                    new NameValuePair("orgNo", ConstantsEnv.HF_ORGNO),		//机构编号，由上游提供，请联系技术
                    new NameValuePair("data",new EncryptionDES(key).encrypt(URLEncoder.encode(net.sf.json.JSONObject.fromObject(reqMap).toString(),"UTF-8")))
            };
            Log.info("请求弘付D0参数111："+net.sf.json.JSONObject.fromObject(reqMap).toString());
            String responseStr = null;
            HttpClient httpClient = new HttpClient();
            httpClient.getParams().setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, "UTF-8");
            PostMethod postMethod = new PostMethod(URL);
            postMethod.setRequestBody(data);
            httpClient.getHttpConnectionManager().getParams()
                    .setConnectionTimeout(10000);
            httpClient.getHttpConnectionManager().getParams().setSoTimeout(10000);
            httpClient.executeMethod(postMethod);

            responseStr = postMethod.getResponseBodyAsString();
            postMethod.releaseConnection();
            net.sf.json.JSONObject jsonObject = net.sf.json.JSONObject.fromObject(URLDecoder.decode(responseStr,"UTF-8"));
            System.out.println("弘付D0返回参数："+URLDecoder.decode(responseStr,"UTF-8"));
            return jsonObject;
//			respCode = (String) jsonObject.get("respCode");
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.复核商户,new String[]{"弘付报备D0添加失败"});
        }
    }
}
