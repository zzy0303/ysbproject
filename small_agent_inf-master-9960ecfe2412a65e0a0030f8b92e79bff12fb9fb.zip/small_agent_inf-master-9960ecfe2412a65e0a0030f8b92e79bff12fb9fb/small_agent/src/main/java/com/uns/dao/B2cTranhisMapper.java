package com.uns.dao;

import com.uns.model.B2cTranhis;
import com.uns.web.form.TradeForm;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;

@Repository
public interface B2cTranhisMapper {
	
	List findTradeById(String tranid);
	//根据商户编号，获取终端编号
	List<String> getTerminalSb(String shopperid) throws Exception;
	//代理商交易流水列表
	List findTradeAgentList(TradeForm tradeForm) throws Exception;
	//交易流水汇总（笔数）
	HashMap getb2cTranhisAgent(TradeForm tradeForm);
	//根据代理商编号查询商户的交易详情
	List<B2cTranhis> findTradeSbListByAgentIdList(Long agengId);
	//根据终端id查询交易记录
	List<B2cTranhis> getTradeList(String terId);
	//金额
	HashMap getb2cTranhisAmount(TradeForm tradeForm);
	//app根据商户号查询历史交易
	List findHisTranList(TradeForm tradeForm);

	
}