package com.uns.dao;

import com.uns.model.MposSystemInformation;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface MposSystemInformationMapper {

    int insert(MposSystemInformation record);

    int insertSelective(MposSystemInformation record);

	String findinformationCount(Long shopperid);

	List findAppInformationThemeList(Map param);


	Map findAppInformationDetails(Map map);

	String finInformationTheme();


}