package com.uns.web.form;

import com.uns.model.AgentRatio;

import java.util.ArrayList;
import java.util.List;

public class AgentMccForm {
	
	private Long amid;
	private Long agentid;
	private Long mccid;
	private Double basecost; // 通道底价
	private Double maxFee;
	private List<AgentRatio> agentRatios = new ArrayList<AgentRatio>();

	public Double getMaxFee() {
		return maxFee;
	}
	public void setMaxFee(Double maxFee) {
		this.maxFee = maxFee;
	}
	
	public Long getAmid() {
		return amid;
	}
	public void setAmid(Long amid) {
		this.amid = amid;
	}
	public Long getAgentid() {
		return agentid;
	}
	public void setAgentid(Long agentid) {
		this.agentid = agentid;
	}
	public Long getMccid() {
		return mccid;
	}
	public void setMccid(Long mccid) {
		this.mccid = mccid;
	}
	public Double getBasecost() {
		return basecost;
	}
	public void setBasecost(Double basecost) {
		this.basecost = basecost;
	}
	public List<AgentRatio> getAgentRatios() {
		return agentRatios;
	}
	public void setAgentRatios(List<AgentRatio> agentRatios) {
		this.agentRatios = agentRatios;
	}
}
