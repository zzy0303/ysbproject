package com.uns.bean;
/**
 * OCR上传贷记卡信息实体类
 * @author Administrator
 *
 */
public class OCRCreditCardInfoBean {
	private String creditBankClientIdNo;//贷记卡开卡人身份证号
	private String creditBankClientName;//贷记卡开卡人姓名
	private String creditBankName;//贷记卡银行名称（用于查询出贷记卡银行编码）
	private String creditBankDictval;//贷记卡银行编码（需查询）
	private String creditBankNo;//贷记卡卡号
	private String creditBankClientTel;//贷记卡手机号
	public String getCreditBankClientIdNo() {
		return creditBankClientIdNo;
	}
	public void setCreditBankClientIdNo(String creditBankClientIdNo) {
		this.creditBankClientIdNo = creditBankClientIdNo;
	}
	public String getCreditBankClientName() {
		return creditBankClientName;
	}
	public void setCreditBankClientName(String creditBankClientName) {
		this.creditBankClientName = creditBankClientName;
	}
	public String getCreditBankName() {
		return creditBankName;
	}
	public void setCreditBankName(String creditBankName) {
		this.creditBankName = creditBankName;
	}
	public String getCreditBankDictval() {
		return creditBankDictval;
	}
	public void setCreditBankDictval(String creditBankDictval) {
		this.creditBankDictval = creditBankDictval;
	}
	public String getCreditBankNo() {
		return creditBankNo;
	}
	public void setCreditBankNo(String creditBankNo) {
		this.creditBankNo = creditBankNo;
	}
	public String getCreditBankClientTel() {
		return creditBankClientTel;
	}
	public void setCreditBankClientTel(String creditBankClientTel) {
		this.creditBankClientTel = creditBankClientTel;
	}
}
