package com.uns.bean;

/**
 * OCR上传结算卡信息实体类
 * @author Administrator
 *
 */
public class OCRDebitCardInfoBean {
	private String IDNo;//身份证ID
	private String accountbankclientname;//身份证姓名（银行卡姓名）
	private String accountBankClientTel;//结算借记卡持卡人手机号
	private String accountbankno;//结算借记卡号
	private String headOfficeName;//总行名称（用于查询出总行编码）
	private String accountbankdictval;//总行编码（需查询出来）
	private String accountbankname;//支行名称
	private String accountbankprov;//支行省名称
    private String accountBankProvCode;//支行省编码（需要查询）
    private String accountBankCity;//支行市名称
    private String accountBankCityCode;//支行市编码（需要查询）
	public String getAccountBankClientTel() {
		return accountBankClientTel;
	}
	public void setAccountBankClientTel(String accountBankClientTel) {
		this.accountBankClientTel = accountBankClientTel;
	}
	public String getIDNo() {
		return IDNo;
	}
	public void setIDNo(String iDNo) {
		IDNo = iDNo;
	}
	public String getAccountbankclientname() {
		return accountbankclientname;
	}
	public void setAccountbankclientname(String accountbankclientname) {
		this.accountbankclientname = accountbankclientname;
	}
	public String getAccountbankno() {
		return accountbankno;
	}
	public void setAccountbankno(String accountbankno) {
		this.accountbankno = accountbankno;
	}
	public String getHeadOfficeName() {
		return headOfficeName;
	}
	public void setHeadOfficeName(String headOfficeName) {
		this.headOfficeName = headOfficeName;
	}
	public String getAccountbankdictval() {
		return accountbankdictval;
	}
	public void setAccountbankdictval(String accountbankdictval) {
		this.accountbankdictval = accountbankdictval;
	}
	public String getAccountbankname() {
		return accountbankname;
	}
	public void setAccountbankname(String accountbankname) {
		this.accountbankname = accountbankname;
	}
	public String getAccountbankprov() {
		return accountbankprov;
	}
	public void setAccountbankprov(String accountbankprov) {
		this.accountbankprov = accountbankprov;
	}
	public String getAccountBankProvCode() {
		return accountBankProvCode;
	}
	public void setAccountBankProvCode(String accountBankProvCode) {
		this.accountBankProvCode = accountBankProvCode;
	}
	public String getAccountBankCity() {
		return accountBankCity;
	}
	public void setAccountBankCity(String accountBankCity) {
		this.accountBankCity = accountBankCity;
	}
	public String getAccountBankCityCode() {
		return accountBankCityCode;
	}
	public void setAccountBankCityCode(String accountBankCityCode) {
		this.accountBankCityCode = accountBankCityCode;
	}
    
    
}
