package com.uns.dao;

import com.uns.model.B2cShopperbi;
import com.uns.model.B2cShopperbiTemp;
import com.uns.web.form.ShopPerbiForm;
import org.apache.shiro.crypto.hash.Hash;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public interface B2cShopperbiTempMapper{

    int deleteByPrimaryKey(BigDecimal b2cShopperbiId);

    int insert(B2cShopperbiTemp record);

    int insertSelective(B2cShopperbiTemp record);

    B2cShopperbiTemp selectByPrimaryKey(BigDecimal b2cShopperbiId);

    int updateByPrimaryKeySelective(B2cShopperbiTemp record);

    int updateByPrimaryKey(B2cShopperbiTemp record);

	List<HashMap> ShopPerbiManageList(ShopPerbiForm mbForm);

	B2cShopperbiTemp selectByshopperId(Long b2cShopperbiId);

	void updateByShopperId(B2cShopperbiTemp b2cShopperbi);
	
	void updateBankInfo(B2cShopperbiTemp b2cShopperbi);

	B2cShopperbiTemp selectByScompany(String scompany);
	
	B2cShopperbiTemp selectByshopperName(String muserId);
	
	List<HashMap> ShopPerbiCheckList(ShopPerbiForm mbForm);
	//未审核商户的数量
	String selectCheckCount(ShopPerbiForm shopPerbiForm);
	//未审核商户开户银行的数量
	String selectCheckBkCount(ShopPerbiForm shopPerbiForm);
	//未审核商户终端的数量
	String selectTerminalCount(ShopPerbiForm shopPerbiForm);

	List selectByMuserid(String userName);
	
	
	List findtelbyscompany(String scompany);
	
	
    B2cShopperbiTemp findtelajax(Map map);
    
    List findmerchantbyNo(String b2cShopperbiId);
    
    B2cShopperbiTemp findShopperbiTempByShopperid(String shopperid);
    List findbytel(String tel);
    
    B2cShopperbiTemp findShopperbiTempByShopperidp(String shopperid);
    
    List<HashMap> shopPerbiTerminalList(ShopPerbiForm mbForm);
    
    
    String selectevicenumCount(ShopPerbiForm shopPerbiForm);
    
    List findbysid(String identityId);
    
    List findbyshopperid(String shopperid);
    
    List<HashMap> findbyshopper(String shopperid);

	void updateByphoto(Map map);

	void updateB2cShopperbiTempSmsCode(B2cShopperbiTemp b2cShopperbi);

	void updateQrCode(Map map);

	void updateQrPayCode(Map map);


    List findApplicationProList(Map<String, String> map);
    List findApplicationProOCRList(Map<String, String> map);

    B2cShopperbiTemp findShopperByInviteCode(String inviteCode);

    void updateInviteCode(Map<String, Object> param);

    void updateConfigByShopperid(B2cShopperbi b2cShopperbi);
    
    //OCR身份证信息更新
    void updateOCRIdCardInfo(B2cShopperbiTemp b2cShopperbiTemp);
    
    //OCR结算卡信息更新
    void updateOCRDebitCardInfo(B2cShopperbiTemp b2cShopperbiTemp);
    
    //OCR贷记卡信息更新
    void updateOCRCreditCardInfo(B2cShopperbiTemp b2cShopperbiTemp);
    //根据商户身份证号直接删除
    void deleteByIdCard(String idNo);
    
    //根据手机号查询到一个商户
    B2cShopperbiTemp findByTel(String stel);
    
    //根据手机号查询到shopperid
    String findShopperidByTel(String stel);
    
    //根据身份证号查询到一个商户
    B2cShopperbiTemp findBySid(String identityId);
    
    void updateNotPassStep(Map hashMap);
    
    void deleteByStel(String stel);
    
    void updateShopperActive(B2cShopperbiTemp b2cShopperbiTemp);

    String findCheckStatus(Map param);

    B2cShopperbiTemp findBySidNo(String idNo);

    B2cShopperbiTemp findByAggteltemp(String stel);

    B2cShopperbi findByAggtel(String stel);

    List<HashMap> findAggShopper(String shopperid);

    void deleteByAggStel(String stel);

    void deleteByAggIdCard(String stel);

    Long findAggSid(String sid);

    String findBankCode(String bankName);
}