package com.uns.web;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.dao.B2cShopperbiTempMapper;
import com.uns.model.Image;
import com.uns.model.MposPhotoTmp;
import com.uns.service.AppOpenRegOCRService;
import com.uns.service.PhotoService;

import com.uns.service.ShopPerbiService;
import com.uns.util.AesEncrypt;
import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping(value = "/insertimagecontroller.htm")
public class InsertImageController extends BaseController {

	@Autowired
	ShopPerbiService shopPerbiService;
	
	@Autowired
	private com.uns.dao.ImageMapper ImageMapper;

	@Autowired
	private PhotoService photoservice;

	@Autowired
	private AppOpenRegOCRService appOpenRegOCRService;
	
	@RequestMapping(params = "method=insertimage")
	public void insertimage(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Map hashMap = new HashMap();
		try {
            String merchantType = request.getParameter("merchantType") == null ? "" :request.getParameter("merchantType").toString(); //商户类型
            //商户版上传图片
            if(Constants.TYPE_2.equals(merchantType)){
                log.info("执行商户版上传图片");
                updateImageAgg(request,response);
            } else {
                String identityId = (String) request.getParameter("identityId");
                identityId=identityId.toUpperCase();
                System.out.println("identityId:"+identityId);
                String handIdentity = request.getParameter("handIdentity");
                String frontIdentity = request.getParameter("frontIdentity");
                String reverseIdentity = request.getParameter("reverseIdentity");
                String storePhoto = request.getParameter("storePhoto");
                String licensePhoto = request.getParameter("licensePhoto");
                String instorePhoto = request.getParameter("instorePhoto");
                String checkstandPhoto = request.getParameter("checkstandPhoto");
                String signaturePhoto = request.getParameter("signaturePhoto");
                String creditCardPhoto = request.getParameter("creditCardPhoto");
                String settlementCardPhoto = request.getParameter("settlementCardPhoto");
                String fixPhoto = request.getParameter("fixPhoto");

                Map handIdentity1 = com.uns.util.JsonUtil.jsonStrToMap(handIdentity);
                Map frontIdentity1 = com.uns.util.JsonUtil.jsonStrToMap(frontIdentity);
                Map reverseIdentity1 = com.uns.util.JsonUtil.jsonStrToMap(reverseIdentity);
                Map storePhoto1 = com.uns.util.JsonUtil.jsonStrToMap(storePhoto);
                Map licensePhoto1 = com.uns.util.JsonUtil.jsonStrToMap(licensePhoto);
                Map instorePhoto1 = com.uns.util.JsonUtil.jsonStrToMap(instorePhoto);
                Map checkstandPhoto1 = com.uns.util.JsonUtil.jsonStrToMap(checkstandPhoto);
                Map signaturePhoto1 = com.uns.util.JsonUtil.jsonStrToMap(signaturePhoto);
                Map creditCardPhoto1 = com.uns.util.JsonUtil.jsonStrToMap(creditCardPhoto);
                Map settlementCardPhoto1 = com.uns.util.JsonUtil.jsonStrToMap(settlementCardPhoto);
                Map fixphoto1 = com.uns.util.JsonUtil.jsonStrToMap(fixPhoto);


                MposPhotoTmp photo = new MposPhotoTmp();
                // 签名 1
                if (signaturePhoto1 != null) {
                    String signaturePhotoph = insertphototemp(signaturePhoto1);
                    photo.setSignaturePhoto(signaturePhotoph);
                }

                // 手持 2
                if (handIdentity1 != null) {
                    String handIdentityph = insertphototemp(handIdentity1);
                    photo.setHandIdentityCardPhoto(handIdentityph);
                }
                // 正面 3
                if (frontIdentity1 != null) {
                    String frontIdentityph = insertphototemp(frontIdentity1);
                    photo.setFrontIdentityCardPhoto(frontIdentityph);
                }
                // 反面 4
                if (reverseIdentity1 != null) {
                    String reverseIdentityph = insertphototemp(reverseIdentity1);
                    photo.setReverseIdentityCardPhoto(reverseIdentityph);
                }

                // 门面 5
                if (storePhoto1 != null) {
                    String storePhotoph = insertphototemp(storePhoto1);
                    photo.setStorePhoto(storePhotoph);
                }

                // 收银台照片 6
                if (checkstandPhoto1 != null) {
                    String checkstandPhotoph = insertphototemp(checkstandPhoto1);
                    photo.setCheckstandPhoto(checkstandPhotoph);
                }
                // 执照 7
                if (licensePhoto1 != null) {
                    String licensePhotoph = insertphototemp(licensePhoto1);
                    photo.setLicensePhoto(licensePhotoph);
                }
                // 门店内 8
                if (instorePhoto1 != null) {
                    String instorePhotoph = insertphototemp(instorePhoto1);
                    photo.setInstorePhoto(instorePhotoph);
                }
                // 信用卡 9
                if (creditCardPhoto1 != null) {
                    String creditCardPhotop = insertphototemp(creditCardPhoto1);// 信用卡照片
                    photo.setCreditCardPhoto(creditCardPhotop);
                }
                // 结算银行卡 10
                if (settlementCardPhoto1 != null) {
                    String settlementCardPhotop = insertphototemp(settlementCardPhoto1);// 信用卡照片
                    photo.setSettlementCardPhoto(settlementCardPhotop);
                }

                if (fixphoto1 != null) {
                    String fixphototop = insertphototemp(fixphoto1);// 信用卡照片
                    photo.setFixphoto(fixphototop);
                }

                photo.setCheckFlag(Constants.STATUS0);
                photo.setIdentityid(identityId);
				photo.setMerchantType(Constants.TYPE_0);
                photoservice.insertphoto(photo);

                hashMap.put("returnCode", "0000");
                hashMap.put("msg", "照片上传成功");
                response.setContentType("UTF-8");
                JSONObject json = JSONObject.fromObject(hashMap);
                log.info("照片上传成功:" + json.toString());
                response.getWriter().write(json.toString());
            }
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("returnCode", "2222");
			hashMap.put("msg", "照片上传失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("照片上传:" + json.toString());
			response.getWriter().write(json.toString());
		}
	}



	@RequestMapping(params = "method=updateimage")
	public void updateimage(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String version = request.getParameter("version");
		if(Constants.VERSION_2_3_0.equals(version) || Constants.VERSION_2_4_0.equals(version)){
			updateImageOCR(request, response);
		}else{
			updateImageOld(request, response);
		}
	}


    /**
     * 聚合支付版本商户更新图片
     * @param request
     * @param response
     */
    public void updateImageAgg(HttpServletRequest request, HttpServletResponse response) throws Exception {
        Map hashMap = null;
        MposPhotoTmp photo1 = null;//老图片
        MposPhotoTmp photo = null;//图片更新实体
        try {
            //String identityId = AesEncrypt.decryptAES(request.getParameter("identityId"), ConstantsEnv.APP_AES_KEY);
            String identityId = request.getParameter("identityId");
            log.info("商户identityId:"+identityId);

            String handIdentity = request.getParameter("handIdentity");
            String frontIdentity = request.getParameter("frontIdentity");
            String reverseIdentity = request.getParameter("reverseIdentity");
            String storePhoto = request.getParameter("storePhoto");
            String licensePhoto = request.getParameter("licensePhoto");
            String instorePhoto = request.getParameter("instorePhoto");
            String checkstandPhoto = request.getParameter("checkstandPhoto");
            String settlementCardPhoto = request.getParameter("settlementCardPhoto");
            String fixPhoto = request.getParameter("fixPhoto");
            //新加商户认证照片：
            String lobbyPhoto = request.getParameter("lobbyPhoto"); // 大堂照片
            String openLicensePhoto = request.getParameter("openLicensePhoto"); //开户许可证

            Map handIdentity1 = com.uns.util.JsonUtil.jsonStrToMap(handIdentity);
            Map frontIdentity1 = com.uns.util.JsonUtil.jsonStrToMap(frontIdentity);
            Map reverseIdentity1 = com.uns.util.JsonUtil.jsonStrToMap(reverseIdentity);
            Map storePhoto1 = com.uns.util.JsonUtil.jsonStrToMap(storePhoto);
            Map licensePhoto1 = com.uns.util.JsonUtil.jsonStrToMap(licensePhoto);
            Map instorePhoto1 = com.uns.util.JsonUtil.jsonStrToMap(instorePhoto);
            Map checkstandPhoto1 = com.uns.util.JsonUtil.jsonStrToMap(checkstandPhoto);
            Map settlementCardPhoto1 = com.uns.util.JsonUtil.jsonStrToMap(settlementCardPhoto);
            Map fixphoto1 = com.uns.util.JsonUtil.jsonStrToMap(fixPhoto);

            Map lobbyPhoto1 = com.uns.util.JsonUtil.jsonStrToMap(lobbyPhoto);
            Map openLicensePhoto1 = com.uns.util.JsonUtil.jsonStrToMap(openLicensePhoto);


            photo1 = photoservice.findAggsid(identityId);
            photo = new MposPhotoTmp();

            photo.setIdentityid(identityId);
            //商户类型
            photo.setMerchantType(Constants.TYPE_2);

            // 手持 2
            if (!Constants.CONS_STR_NULL.equals(handIdentity)) {
                String handIdentityph = insertphototemp(handIdentity1);
                photo.setHandIdentityCardPhoto(handIdentityph);
            }
            // 正面 3
            if (!Constants.CONS_STR_NULL.equals(frontIdentity)) {
                String frontIdentityph = insertphototemp(frontIdentity1);
                photo.setFrontIdentityCardPhoto(frontIdentityph);
            }
            // 反面 4
            if (!Constants.CONS_STR_NULL.equals(reverseIdentity)) {
                String reverseIdentityph = insertphototemp(reverseIdentity1);
                photo.setReverseIdentityCardPhoto(reverseIdentityph);
            }

            // 门面 5
            if (!Constants.CONS_STR_NULL.equals(storePhoto)) {
                String storePhotoph = insertphototemp(storePhoto1);
                photo.setStorePhoto(storePhotoph);
            }
            // 收银台照片 6
            if (checkstandPhoto1 != null) {
                String checkstandPhotoph = insertphototemp(checkstandPhoto1);
                photo.setCheckstandPhoto(checkstandPhotoph);
            }
            // 执照 7
            if (licensePhoto1 != null) {
                String licensePhotoph = insertphototemp(licensePhoto1);
                photo.setLicensePhoto(licensePhotoph);
            }
            // 门店内 8
            if (!Constants.CONS_STR_NULL.equals(instorePhoto)) {
                String instorePhotoph = insertphototemp(instorePhoto1);
                photo.setInstorePhoto(instorePhotoph);
            }
            // 结算银行卡 10
            if (settlementCardPhoto1 != null) {
                String settlementCardPhotop = insertphototemp(settlementCardPhoto1);
                photo.setSettlementCardPhoto(settlementCardPhotop);
            }

            // 固码图片 11
            if (!Constants.CONS_STR_NULL.equals(fixPhoto)) {
                String fixphototop = insertphototemp(fixphoto1);
                photo.setFixphoto(fixphototop);
            }
            // 商户认证-大堂照片 12
            if(lobbyPhoto1 != null){
                String lobbyPhotop = insertphototemp(lobbyPhoto1); //大堂照片
                photo.setLobbyPhoto(lobbyPhotop);
            }
            if(openLicensePhoto1 != null){
                String openLicensePhotop = insertphototemp(openLicensePhoto1); //开户许可证
                photo.setOpenLicensePhoto(openLicensePhotop);
            }

            //更新图片
            if(null != photo1){//更新
                photoservice.updatephoto(photo);
            }else{//插入
                photoservice.inserOrUpdatetphoto(photo,identityId);
            }


            hashMap = new HashMap();
            hashMap.put("returnCode", Constants.SUCCESS_CODE);
            hashMap.put("maphoto", photo);//photo中存储的是Image表中图片的uuid
            hashMap.put("msg", "商户照片上传成功");
            response.setContentType(Constants.CONTENT_TYPE_UTF8);
            JSONObject json = JSONObject.fromObject(hashMap);
            log.info("商户照片上传成功:" + json.toString());
            response.getWriter().write(json.toString());
        } catch (Exception e) {
            e.printStackTrace();
            hashMap.put("returnCode", Constants.RETURN_CODE_2222);
            hashMap.put("msg", "商户照片上传失败");
            response.setContentType(Constants.CONTENT_TYPE_UTF8);
            JSONObject json = JSONObject.fromObject(hashMap);
            log.info("商户照片上传失败:" + json.toString());
            response.getWriter().write(json.toString());
        }
    }

	/**
	 * OCR版本更新图片
	 * @param request
	 * @param response
	 */
	public void updateImageOCR(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Map hashMap = null;
		MposPhotoTmp photo1 = null;//老图片
		MposPhotoTmp photo = null;//图片更新实体
		try {
			String identityId = AesEncrypt.decryptAES(request.getParameter("identityId"), ConstantsEnv.APP_AES_KEY);
			identityId=identityId.toUpperCase();
			log.info("identityId:"+identityId);

			String handIdentity = request.getParameter("handIdentity");
			String frontIdentity = request.getParameter("frontIdentity");
			String reverseIdentity = request.getParameter("reverseIdentity");
			String storePhoto = request.getParameter("storePhoto");
			String licensePhoto = request.getParameter("licensePhoto");
			String instorePhoto = request.getParameter("instorePhoto");
			String checkstandPhoto = request.getParameter("checkstandPhoto");
			String signaturePhoto = request.getParameter("signaturePhoto");
			String creditCardPhoto = request.getParameter("creditCardPhoto");
			String settlementCardPhoto = request.getParameter("settlementCardPhoto");
			String fixPhoto = request.getParameter("fixPhoto");

			String livingBodyFacePhoto = request.getParameter("livingBodyFacePhoto");//活体人脸正面
			String livingBodyLeftPhoto = request.getParameter("livingBodyLeftPhoto");//活体人脸左转
			String livingBodyReturnPhoto = request.getParameter("livingBodyReturnPhoto");//活体人脸回正
			String livingBodyRightPhoto = request.getParameter("livingBodyRightPhoto");//活体人脸右转
			String idCardHeadPhoto = request.getParameter("idCardHeadPhoto");//身份证头像照

			Map handIdentity1 = com.uns.util.JsonUtil.jsonStrToMap(handIdentity);
			Map frontIdentity1 = com.uns.util.JsonUtil.jsonStrToMap(frontIdentity);
			Map reverseIdentity1 = com.uns.util.JsonUtil.jsonStrToMap(reverseIdentity);
			Map storePhoto1 = com.uns.util.JsonUtil.jsonStrToMap(storePhoto);
			Map licensePhoto1 = com.uns.util.JsonUtil.jsonStrToMap(licensePhoto);
			Map instorePhoto1 = com.uns.util.JsonUtil.jsonStrToMap(instorePhoto);
			Map checkstandPhoto1 = com.uns.util.JsonUtil.jsonStrToMap(checkstandPhoto);
			Map signaturePhoto1 = com.uns.util.JsonUtil.jsonStrToMap(signaturePhoto);
			Map creditCardPhoto1 = com.uns.util.JsonUtil.jsonStrToMap(creditCardPhoto);
			Map settlementCardPhoto1 = com.uns.util.JsonUtil.jsonStrToMap(settlementCardPhoto);
			Map fixphoto1 = com.uns.util.JsonUtil.jsonStrToMap(fixPhoto);
			Map livingBodyFacePhoto1 = com.uns.util.JsonUtil.jsonStrToMap(livingBodyFacePhoto);
			Map livingBodyLeftPhoto1 = com.uns.util.JsonUtil.jsonStrToMap(livingBodyLeftPhoto);
			Map livingBodyReturnPhoto1 = com.uns.util.JsonUtil.jsonStrToMap(livingBodyReturnPhoto);
			Map livingBodyRightPhoto1 = com.uns.util.JsonUtil.jsonStrToMap(livingBodyRightPhoto);
			Map idCardHeadPhoto1 = com.uns.util.JsonUtil.jsonStrToMap(idCardHeadPhoto);


			photo1 = photoservice.findbsid(identityId);
			photo = new MposPhotoTmp();

			photo.setIdentityid(identityId);
            photo.setMerchantType(Constants.TYPE_0); //个人用户
			// 签名 1
			if (!Constants.CONS_STR_NULL.equals(signaturePhoto)) {
				String signaturePhotoph = insertphototemp(signaturePhoto1);//读取图片内容并返回uuid
				photo.setSignaturePhoto(signaturePhotoph);
			}

			// 手持 2
			if (!Constants.CONS_STR_NULL.equals(handIdentity)) {
				String handIdentityph = updatephototemp(handIdentity1);
				photo.setHandIdentityCardPhoto(handIdentityph);
			}
			// 正面 3
			if (!Constants.CONS_STR_NULL.equals(frontIdentity)) {
				String frontIdentityph = updatephototemp(frontIdentity1);
				photo.setFrontIdentityCardPhoto(frontIdentityph);
			}
			// 反面 4
			if (!Constants.CONS_STR_NULL.equals(reverseIdentity)) {
				String reverseIdentityph = updatephototemp(reverseIdentity1);
				photo.setReverseIdentityCardPhoto(reverseIdentityph);
			}

			// 门面 5
			if (!Constants.CONS_STR_NULL.equals(storePhoto)) {
				String storePhotoph = updatephototemp(storePhoto1);
				photo.setStorePhoto(storePhotoph);
			}

			/*// 收银台照片 6
			if (check= null) {
				String checkstandPhotoph = insertphototemp(checkstandPhoto1);
				//photo.setCheckstandPhoto(checkstandPhotoph);

				maphoto.put("checkstandPhotoph", checkstandPhotoph);
			}*/
			// 执照 7
			if (!Constants.CONS_STR_NULL.equals(licensePhoto)) {
				String licensePhotoph = updatephototemp(licensePhoto1);
				photo.setLicensePhoto(licensePhotoph);
			}
			// 门店内 8
			if (!Constants.CONS_STR_NULL.equals(instorePhoto)) {
				String instorePhotoph = updatephototemp(instorePhoto1);
				photo.setInstorePhoto(instorePhotoph);
			}
			// 信用卡 9
			if (!Constants.CONS_STR_NULL.equals(creditCardPhoto)) {
				String creditCardPhotop = updatephototemp(creditCardPhoto1);// 信用卡照片
				photo.setCreditCardPhoto(creditCardPhotop);
			}
			// 结算银行卡 10
			if (!Constants.CONS_STR_NULL.equals(settlementCardPhoto)) {
				String settlementCardPhotop = insertphototemp(settlementCardPhoto1);// 信用卡照片
				photo.setSettlementCardPhoto(settlementCardPhotop);
			}

			// 固码图片 11
			if (!Constants.CONS_STR_NULL.equals(fixPhoto)) {
				String fixphototop = insertphototemp(fixphoto1);
				photo.setFixphoto(fixphototop);
			}

			// 活体人脸正面
			if (!Constants.CONS_STR_NULL.equals(livingBodyFacePhoto)) {
				String livingBodyFacePhotoTop = insertphototemp(livingBodyFacePhoto1);
				photo.setLivingBodyFacePhoto(livingBodyFacePhotoTop);
			}

			// 活体人脸左转
			if (!Constants.CONS_STR_NULL.equals(livingBodyLeftPhoto)) {
				String livingBodyLeftPhotoTop = insertphototemp(livingBodyLeftPhoto1);
				photo.setLivingBodyLeftPhoto(livingBodyLeftPhotoTop);
			}

			// 活体人脸回正
			if (!Constants.CONS_STR_NULL.equals(livingBodyReturnPhoto)) {
				String livingBodyReturnPhotoTop = insertphototemp(livingBodyReturnPhoto1);
				photo.setLivingBodyReturnPhoto(livingBodyReturnPhotoTop);
			}

			// 活体人脸右转
			if (!Constants.CONS_STR_NULL.equals(livingBodyRightPhoto)) {
				String livingBodyRightPhotoTop = insertphototemp(livingBodyRightPhoto1);
				photo.setLivingBodyRightPhoto(livingBodyRightPhotoTop);
			}

			// 身份证头像照
			if (!Constants.CONS_STR_NULL.equals(idCardHeadPhoto)) {
				String idCardHeadPhotoTop = insertphototemp(idCardHeadPhoto1);
				photo.setIdCardHeadPhoto(idCardHeadPhotoTop);
			}

			//更新图片
			if(null != photo1){//插入
				photoservice.updatephoto(photo);
			}else{//更新
				photoservice.inserOrUpdatetphoto(photo,identityId);
			}

			//更新OCR错误步骤
			updateOCRNotPassStep(livingBodyFacePhoto, livingBodyLeftPhoto, livingBodyRightPhoto, livingBodyReturnPhoto, handIdentity, signaturePhoto, identityId);
			

			hashMap = new HashMap();
			hashMap.put("returnCode", Constants.SUCCESS_CODE);
			hashMap.put("maphoto", photo);//photo中存储的是Image表中图片的uuid
			hashMap.put("msg", "照片上传成功");
			response.setContentType(Constants.CONTENT_TYPE_UTF8);
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("照片上传成功:" + json.toString());
			response.getWriter().write(json.toString());
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("returnCode", Constants.RETURN_CODE_2222);
			hashMap.put("msg", "照片上传失败");
			response.setContentType(Constants.CONTENT_TYPE_UTF8);
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("照片上传失败:" + json.toString());
			response.getWriter().write(json.toString());
		}
	}

	/**
	 * 更新OCR错误步骤
	 * @param livingBodyFacePhoto
	 * @param livingBodyLeftPhoto
	 * @param livingBodyRightPhoto
	 * @param livingBodyReturnPhoto
	 * @param handIdentity
	 * @param signaturePhoto
	 * @param identityId
	 */
	private void updateOCRNotPassStep(String livingBodyFacePhoto,String livingBodyLeftPhoto,
								 String livingBodyRightPhoto,String livingBodyReturnPhoto,String handIdentity,String signaturePhoto,String identityId){
		if(!Constants.CONS_STR_NULL.equals(livingBodyFacePhoto) && !Constants.CONS_STR_NULL.equals(livingBodyLeftPhoto) &&
				!Constants.CONS_STR_NULL.equals(livingBodyRightPhoto) && !Constants.CONS_STR_NULL.equals(livingBodyReturnPhoto)){
			appOpenRegOCRService.updateNotPassStep(identityId, Constants.INT_6);
		}
		if(!Constants.CONS_STR_NULL.equals(handIdentity)){
			appOpenRegOCRService.updateNotPassStep(identityId, Constants.INT_8);
		}
		if(!Constants.CONS_STR_NULL.equals(signaturePhoto)){
			appOpenRegOCRService.updateNotPassStep(identityId, Constants.INT_10);
		}
	}
	
	private void updateImageOld(HttpServletRequest request, HttpServletResponse response)throws Exception{
		Map hashMap = new HashMap();
		try {
			String identityId = (String) request.getParameter("identityId");
			identityId=identityId.toUpperCase();
			log.info("identityId:"+identityId);
			
			String handIdentity = request.getParameter("handIdentity");
			String frontIdentity = request.getParameter("frontIdentity");
			String reverseIdentity = request.getParameter("reverseIdentity");
			String storePhoto = request.getParameter("storePhoto");
			String licensePhoto = request.getParameter("licensePhoto");
			String instorePhoto = request.getParameter("instorePhoto");
			String checkstandPhoto = request.getParameter("checkstandPhoto");
			String signaturePhoto = request.getParameter("signaturePhoto");
			String creditCardPhoto = request.getParameter("creditCardPhoto");
			String settlementCardPhoto = request.getParameter("settlementCardPhoto");
			String fixPhoto = request.getParameter("fixPhoto");

			String  hand=request.getParameter("hand");
			String  front=request.getParameter("front");
			String  rever=request.getParameter("rever");
			String  store=request.getParameter("store");
			String  licen=request.getParameter("licen");
			String  instore=request.getParameter("instore");
			String  sign=request.getParameter("sign");
			String  credit=request.getParameter("credit");
			String  settle=request.getParameter("settle");

			String  fix=request.getParameter("fix");


			Map handIdentity1 = com.uns.util.JsonUtil.jsonStrToMap(handIdentity);
			Map frontIdentity1 = com.uns.util.JsonUtil.jsonStrToMap(frontIdentity);
			Map reverseIdentity1 = com.uns.util.JsonUtil.jsonStrToMap(reverseIdentity);
			Map storePhoto1 = com.uns.util.JsonUtil.jsonStrToMap(storePhoto);
			Map licensePhoto1 = com.uns.util.JsonUtil.jsonStrToMap(licensePhoto);
			Map instorePhoto1 = com.uns.util.JsonUtil.jsonStrToMap(instorePhoto);
			Map checkstandPhoto1 = com.uns.util.JsonUtil.jsonStrToMap(checkstandPhoto);
			Map signaturePhoto1 = com.uns.util.JsonUtil.jsonStrToMap(signaturePhoto);
			Map creditCardPhoto1 = com.uns.util.JsonUtil.jsonStrToMap(creditCardPhoto);
			Map settlementCardPhoto1 = com.uns.util.JsonUtil.jsonStrToMap(settlementCardPhoto);
			Map fixphoto1 = com.uns.util.JsonUtil.jsonStrToMap(fixPhoto);


			MposPhotoTmp photo1 = photoservice.findbsid(identityId);
			MposPhotoTmp photo=new MposPhotoTmp();

			photo.setMerchantType(Constants.TYPE_0);
			photo.setIdentityid(identityId);
//			Map maphoto=new HashMap();
			// 签名 1
			if (sign != null&&org.apache.commons.lang3.StringUtils.isNotEmpty(sign)) {
				String signaturePhotoph = insertphototemp(signaturePhoto1);
				photo.setSignaturePhoto(signaturePhotoph);
				//maphoto.put("signaturePhotoph", signaturePhotoph);
			}

			// 手持 2
			if (hand != null&&org.apache.commons.lang3.StringUtils.isNotEmpty(hand)) {
				String handIdentityph = updatephototemp(handIdentity1);
				photo.setHandIdentityCardPhoto(handIdentityph);
				//maphoto.put("handIdentityph", handIdentityph);
			}
			// 正面 3
			if (front != null&&org.apache.commons.lang3.StringUtils.isNotEmpty(front)) {
				String frontIdentityph = updatephototemp(frontIdentity1);
				photo.setFrontIdentityCardPhoto(frontIdentityph);
				//maphoto.put("frontIdentityph", frontIdentityph);
			}
			// 反面 4
			if (rever != null&&org.apache.commons.lang3.StringUtils.isNotEmpty(rever)) {
				String reverseIdentityph = updatephototemp(reverseIdentity1);
				photo.setReverseIdentityCardPhoto(reverseIdentityph);
				//maphoto.put("reverseIdentityph", reverseIdentityph);
			}

			// 门面 5
			if (store!= null&&org.apache.commons.lang3.StringUtils.isNotEmpty(store)) {
				String storePhotoph = updatephototemp(storePhoto1);
				photo.setStorePhoto(storePhotoph);
				//maphoto.put("storePhotoph", storePhotoph);
			}

			/*// 收银台照片 6
			if (check= null) {
				String checkstandPhotoph = insertphototemp(checkstandPhoto1);
				//photo.setCheckstandPhoto(checkstandPhotoph);
				
				maphoto.put("checkstandPhotoph", checkstandPhotoph);
			}*/
			// 执照 7
			if (licen != null&&org.apache.commons.lang3.StringUtils.isNotEmpty(licen)) {
				String licensePhotoph = updatephototemp(licensePhoto1);
				photo.setLicensePhoto(licensePhotoph);
				//maphoto.put("licensePhotoph", licensePhotoph);
			}
			// 门店内 8
			if (instore!= null&&org.apache.commons.lang3.StringUtils.isNotEmpty(instore)) {
				String instorePhotoph = updatephototemp(instorePhoto1);
				photo.setInstorePhoto(instorePhotoph);
				//maphoto.put("instorePhotoph",instorePhotoph);
			}
			// 信用卡 9
			if (credit != null&&org.apache.commons.lang3.StringUtils.isNotEmpty(credit)) {
				String creditCardPhotop = updatephototemp(creditCardPhoto1);// 信用卡照片
				photo.setCreditCardPhoto(creditCardPhotop);
				//maphoto.put("creditCardPhotop", creditCardPhotop);
			}
			// 结算银行卡 10
			if (settle!= null&&org.apache.commons.lang3.StringUtils.isNotEmpty(settle)) {
				String settlementCardPhotop = insertphototemp(settlementCardPhoto1);// 信用卡照片
				photo.setSettlementCardPhoto(settlementCardPhotop);
				//maphoto.put("settlementCardPhotop", settlementCardPhotop);
			}

			// 固码图片 11
			if (fix!= null&&org.apache.commons.lang3.StringUtils.isNotEmpty(fix)) {
				String fixphototop = insertphototemp(fixphoto1);// 信用卡照片
				photo.setFixphoto(fixphototop);
			}

			if(photo1!=null){
				photoservice.updatephoto(photo);
			}else{
				photoservice.inserOrUpdatetphoto(photo,identityId);
			}

			hashMap.put("returnCode", "0000");
			hashMap.put("maphoto", photo);
			hashMap.put("msg", "照片上传成功");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("照片上传成功:" + json.toString());
			response.getWriter().write(json.toString());
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("returnCode", "2222");
			hashMap.put("msg", "照片上传失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("照片上传失败:" + json.toString());
			response.getWriter().write(json.toString());
		}
	}

	public String insertphototemp(Map hasmap) throws Exception {
		String targetFileName = (String) hasmap.get("targetFileName");

		String imagepath = (String) hasmap.get("imagepath");
		String moduleName = (String) hasmap.get("moduleName");
		String imageFrom = (String) hasmap.get("imageFrom");

		Image image = new Image();
		image.setImageName(targetFileName);
		image.setImagePath(imagepath);
		image.setModuleName(moduleName);
		image.setCreateDate(new Date());
		image.setUpdateDate(new Date());
		image.setImageFrom(imageFrom);
		ImageMapper.insertSelective(image);
		Image image1 = ImageMapper.getImageByName(targetFileName);
		String uuid = image1.getUuid().toString();
		return uuid;

	}





	public String updatephototemp(Map hasmap) throws Exception {
		String targetFileName = (String) hasmap.get("targetFileName");

		String imagepath = (String) hasmap.get("imagepath");
		String moduleName = (String) hasmap.get("moduleName");
		String imageFrom = (String) hasmap.get("imageFrom");
		String identityId = (String) hasmap.get("identityId");
		String photoname = (String) hasmap.get("photoname");

		/*MposPhotoTmp photo = this.photoservice.findbsid(identityId);
		if (photo != null) {
			this.photoservice.delphoto(identityId);
		}*/
		Image image = new Image();
		image.setImageName(targetFileName);
		image.setImagePath(imagepath);
		image.setModuleName(moduleName);
		image.setCreateDate(new Date());
		image.setUpdateDate(new Date());
		image.setImageFrom(imageFrom);
		ImageMapper.insertSelective(image);
		Image image1 = ImageMapper.getImageByName(targetFileName);
		String uuid = image1.getUuid().toString();
		return uuid;

	}

}
