package com.uns.service;

import com.uns.common.ConstantsEnv;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.inf.notify.api.Notify;
import com.uns.inf.notify.request.NotifyResult;
import com.uns.inf.notify.request.SmsNotifyRequest;
import com.uns.model.B2cShopperVal;
import com.uns.model.B2cShopperbiTemp;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@Service
public class SendMessageService {
	
	private Logger log = Logger.getLogger(SendMessageService.class);
	
	@Autowired
	private Notify notify;
	
	/**
	 * 发送短信消息
	 * @param mobile 手机号
	 * @param content 发送内容
	 * @return 
	 * @throws BusinessException
	 */
	public NotifyResult sendSmsMessage(String mobile,String content) throws BusinessException{
		try {
			String serialNumber = System.currentTimeMillis()+RandomStringUtils.randomNumeric(4);
			SmsNotifyRequest smsNotifyRequest = new SmsNotifyRequest();
			smsNotifyRequest.addMobile(mobile);//手机号
			smsNotifyRequest.setSerialNumber(serialNumber);
			smsNotifyRequest.setTemplateId(21000021L);//设置一个已存在的模板，但不会读取模板内容 以Content内容为准
			smsNotifyRequest.setAppid("small_agent");
			Map<String, String> data = new HashMap<String,String>();
			data.put("content", content);
			smsNotifyRequest.setData(data);
			NotifyResult notifyResult = notify.sendSms(smsNotifyRequest);
			if (null == notifyResult || !"success".equals(notifyResult.getState() + "")) {
				log.info("调用发送短信接口返回失败！"+ notifyResult.toString());
			}else{
				log.info("短信已发送到：" + notifyResult.toString());
			}
			return notifyResult;
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.发送短信失败);
		}
	}
	

	public  void sendMessage(B2cShopperbiTemp b2cShopperbi,String smsCode,HttpServletRequest request) throws BusinessException {
			String content=getContentapp(ConstantsEnv.SMS_CODE_CONTENT,smsCode);
			String mobile = b2cShopperbi.getStel();
			sendSmsMessage(mobile, content);
	}
	
	/**
	 * 服务商找回密码验证码
	 * @param b2cShopperVal
	 * @param request
	 * @throws BusinessException
	 */
	public void sendCodeMessagePwd(B2cShopperVal b2cShopperVal, HttpServletRequest request) throws BusinessException{
			String content=getContentapp(ConstantsEnv.SMS_CODE_PWD,b2cShopperVal.getSmsCode());
			String mobile = b2cShopperVal.getTel();
		    sendSmsMessage(mobile, content);
	}
	
	/**
	 * 注册发送验证码
	 * @param b2cShopperVal
	 * @param request
	 * @throws BusinessException
	 */
	public void sendCodeMessage(B2cShopperVal b2cShopperVal, HttpServletRequest request) throws BusinessException{
			String content=getContentapp(ConstantsEnv.SMS_CODE_SEND,b2cShopperVal.getSmsCode());
			String mobile = b2cShopperVal.getTel();
			sendSmsMessage(mobile, content);
	}
	
	private String getContentapp(String smsContent ,String smsCode) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("${smsCode}",smsCode);
		return this.replaceValues(smsContent, map);
	}
	
	private String replaceValues(String mailContent, Map<String, String> values) {
		Set<String> set = values.keySet();
		for (String key : set){
			if(key.indexOf("${") != -1)
				mailContent = mailContent.replace(key, values.get(key) + "");
		}
		return mailContent;
	}
}
