package com.uns.dao;

import com.uns.model.MposPhoto;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

@Repository
public interface MposPhotoMapper {


    int deleteByPrimaryKey(BigDecimal photoId);

    int insert(MposPhoto record);

    int insertSelective(MposPhoto record);

    MposPhoto selectByPrimaryKey(BigDecimal photoId);

    int updateByPrimaryKeySelective(MposPhoto record);

    int updateByPrimaryKey(MposPhoto record);
}