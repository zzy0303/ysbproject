package com.uns.dao;

import com.uns.model.MposMerchantFee;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public interface MposMerchantFeeMapper {

    int deleteByPrimaryKey(BigDecimal id);

    int insert(MposMerchantFee record);

    int insertTemp(MposMerchantFee record);
    
    int insertSelective(MposMerchantFee record);
    
    int insertTempSelective(MposMerchantFee record);

    MposMerchantFee selectByPrimaryKey(BigDecimal id);

    int updateByPrimaryKeySelective(MposMerchantFee record);

    int updateByPrimaryKey(MposMerchantFee record);
    
    List<HashMap> selectByMerchantId(Long shopperid);
    
     List findbyshopperid(String shopperid);
    
    List queryfee(String shopperid);
    
    List<HashMap> selectByMerchantId1(Long shopperid);
    
    List findfee(Long shopperid);
    
    int deleteByshopperid(Long shopperid);

    int deleteTempByshopperid(Long shopperid);

	List<MposMerchantFee> queryfee1(Map map);


	List findMposMerchantFee(String shopperid);

	List merchantfeelist(String shopperid);

	List findmerchantFeeList(String shopperid);

    List findmerchantFeeList2(String shopperid);

	List findQrPayMerchantFeeList(String shopperid);
	
    List findQrPayMerchantFeeList2(String shopperid);

	List findMposMerchantFeezhifu(String shopperid);

	String findQrPayMerchantFee(String shopperid);

	List mposmerchantfeelist(String shopperid);

	List findsmMerchantFeelist(String shopperid);

	List merchantfeelist201(String shopperid);

    List findMerchantFeeByMpos(Long shopperid);

    MposMerchantFee findFeeChannelType(Long shopperid, String feeType, String channelType);

    int updateMerchantFee(MposMerchantFee mposMerchantFee);

    int updateMerchantFeeTemp(MposMerchantFee mposMerchantFee);

    List aggMerchantFeeList(String shopperid);
}