package com.uns.web;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.myenum.MessageEnum;
import com.uns.model.*;
import com.uns.service.*;
import com.uns.util.*;
import net.sf.json.JSONObject;
import oracle.jdbc.driver.Const;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author ting.zeng
 *
 */
@Controller
@RequestMapping(value = "/appmerchantController.htm")
public class AppMerchantController extends BaseController {

	@Autowired
	private ShopPerbiService merchantregservice;

	@Autowired
	private AgentService agentservice;

	@Autowired
	private MposRemoteInvitationService remotesrevice;

	@Autowired
	private PhotoService photoservice;

	@Autowired
	private MposRemoteFeeService remotefeeservice;
	
	@Autowired
	private ShopPerbiService shopPerbiService;
	
	@Autowired
	private AppOpenRegService appOpenRegService;

	@Autowired
	private HkMerchantUtils hkMerchantUtils;
	
	
	

	/**
	 * app商户申请表 1.获取注册信息
	 * 商户app注册
	 * 
	 * @throws IOException
	 */
	@RequestMapping(params = "method=merchantreg")
	public void merchantreg(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String version = request.getParameter("version") == null ? "" : request
				.getParameter("version");
		merchantreg201(request, response);
	}


	/**2.0.1商户APP注册
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	private void merchantreg201(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String type = request.getParameter("type") == null ? "" : request.getParameter("type");
		if ((Constants.TYPE_A).equals(type)) {
			merchantreg201A(request, response);
		} else if ((Constants.TYPE_I).equals(type)) {
			merchantreg201I(request, response);
		}
		
	}

	public void merchantreg201I(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		Map hashMap = new HashMap();
		try {
            B2cShopperbiTemp shopper = new B2cShopperbiTemp();
		    String merchantType = request.getParameter("merchantType")==null?"":request.getParameter("merchantType").trim();//商户类型0:个人 1:企业 2:商户

			String tel = request.getParameter("tel")==null?"":request.getParameter("tel").trim();
			String City = request.getParameter("City")==null?"":request.getParameter("City").trim();// 经营城市
			String Province = request.getParameter("Province")==null?"":request.getParameter("Province").trim();// 经营省份
			String cardCity = request.getParameter("cardCity")==null?"":request.getParameter("cardCity").trim();// 银行城市
			String cardProvince = request.getParameter("cardProvince")==null?"":request.getParameter("cardProvince").trim();// 银行省份
			String industryType = request.getParameter("industryType")==null?"":request.getParameter("industryType").trim();
			String shopperType = request.getParameter("shopperType")==null?"":request.getParameter("shopperType").trim();
			String sid = request.getParameter("identityId").toUpperCase()==null?"":request.getParameter("identityId").toUpperCase().trim();
			String Name = URLDecoder.decode(request.getParameter("Name")==null?"":request.getParameter("Name").trim(),"UTF-8");// 商户姓名
			String address = URLDecoder.decode(request.getParameter("address")==null?"":request.getParameter("address").trim(),	"UTF-8");// 经营地址
			String scompany = URLDecoder.decode(request.getParameter("scompany") == null ? "" : request.getParameter("scompany").trim(), "UTF-8");// 商户名称
			String bankCard = URLDecoder.decode(request.getParameter("bankCard")==null?"":request.getParameter("bankCard").trim(), "UTF-8");// 银行卡号
			String bankName = URLDecoder.decode(request.getParameter("bankName")==null?"":request.getParameter("bankName").trim(), "UTF-8");// 银行名
			String branchBankName = URLDecoder.decode(request.getParameter("branchBankName")==null?"":request.getParameter("branchBankName").trim(), "UTF-8");// 支行名称
			String shopperidp = request.getParameter("shopperidp");// 代理商号
			String longitude = request.getParameter("longitude");// 经度
			String latitude = request.getParameter("latitude");// 纬度
			String currentLocation = request.getParameter("currentLocation");// 当前位置
			String licenseNo=request.getParameter("licenseNo")== null ? ""	: request.getParameter("licenseNo"); //营业执照编号
			
			// 在商户表中判断手机号码和身份证信息是否存在，
			B2cShopperbiTemp temptel = merchantregservice.findbytel(tel);
			B2cShopperbiTemp shoppersid = merchantregservice.findbysid(sid);
			
			// 商户号递归得到
			Area area2 = merchantregservice.findbyareaid(cardProvince,	cardCity);
			String shopperid = getPosShopperId(area2.getCity(),	Constants.CON_MCC);
			
		
			// 调用小虎接口判断手机和身份证是否存在（sid+tel）
			 String flag=checkTelSid(tel,sid);
			
			 //查询远程邀请表
			 findRemoteFee(tel);
			
			if (temptel == null && (Constants.SUCCESS_CODE.equals(flag))) {
				if (shoppersid != null) {
					hashMap.put("rspCode", "1002");
					hashMap.put("rspMsg", "身份证号码已存在");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("注册信息8888身份证号码已存在ios" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				MposPhotoTmp photo = this.photoservice.findbsid(sid);
				if (photo == null) {
					hashMap.put("rspCode", "2001");
					hashMap.put("rspMsg", "照片上传失败");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("照片上传失败ios" + json.toString());
					response.getWriter().write(json.toString());
					return;
				} 
				
				shopper.setMuserid(tel);
				shopper.setMerchantType(shopperType);
				shopper.setStel(tel);
				shopper.setShopperid(Long.valueOf(shopperid));	
				shopper.setShopperidP(Long.valueOf(shopperidp));// 代理商号
				shopper.setIDNo(sid);
				shopper.setPhotoid(photo.getPhotoId());
				
				// 行业
				B2cDict industry = merchantregservice.findbyhCname(industryType);
				if (industry != null) {
					shopper.setIndustry(industry.getB2cDictId().toString());
				}
				// 所在城市票据
				Area area = merchantregservice.findbyareaid(Province, City);
				if (area != null) {
					shopper.setBillCity(area.getCityname());
					shopper.setScity(area.getCityname());
					shopper.setBillCityCode(area.getCity());
					shopper.setCity(area.getCity());
					shopper.setBillProvince(area.getProvincialname());
					shopper.setSprovince(area.getProvincialname());
					shopper.setBillProvinceCode(area.getProvincial());
					shopper.setProvince(area.getProvincial());
				}
				// 票据地址
				shopper.setBillAddress(address);
				// 票据名称
				shopper.setSaddress(address);
				// 0：个人 1企业 2 商户
				if (shopperType.equals("1")) {
					shopper.setScompany(scompany);
					shopper.setLicenseNo(licenseNo);
				} else {
					shopper.setScompany(Name);
				}
                shopper.setName(Name);// 姓名
                shopper.setAccountbankclientname(Name);// 开户人姓名
				shopper.setAccountbankno(bankCard);// 卡号
				shopper.setAccountbankdictval(bankName);// 开户行名称数据字典
				shopper.setAccountbankname(branchBankName);// 支行名称
				Area area1 = merchantregservice.findbyareaid(cardProvince,cardCity);
				if (area1 != null) {
					shopper.setAccountBankCity(area1.getCityname());
					shopper.setAccountBankCityCode(area1.getCity());
					shopper.setAccountbankprov(area1.getProvincialname());
					shopper.setAccountBankProvCode(area1.getProvincial());
				}
				shopper.setReportResource(Constants.TYPE_1);// 商户报件
				shopper.setCreated(new Date());
				// 设置密码
				MposRemoteInvitation remote = remotesrevice.findbytelstauts(tel);
				if (remote != null) {
					String password = Md5Encrypt.md5(remote.getPassword().trim());
					shopper.setMuserid(tel);
					shopper.setMpassword(password);
				}
				// 默认添加字段
				shopper.setIfvalid(Short.valueOf(Constants.STATUS0));
				shopper.setOpencheckstatus(Short.valueOf(Constants.STATUS0));
				shopper.setIsformal(Short.valueOf(Constants.STATUS0));
				shopper.setIsupdateshopper(Short.valueOf(Constants.STATUS0));
				shopper.setSifpactid(Long.valueOf(Constants.STATUS0));
				shopper.setRecheckmerchantflag(Constants.STATUS0);
				shopper.setPhotoCheckFlag(Constants.STATUS0);
				shopper.setPhotoRecheckFlag(Constants.STATUS0);
				shopper.setTransact(Constants.STATUS1);
				shopper.setIsSupportT0(remote.getOpenToFlag());
				shopper.setLatitude(latitude);
				shopper.setLongitude(longitude);
				shopper.setCurrentLocation(currentLocation);
				// 0:代表开通
				if (Constants.STATUS0.equals(remote.getOpenToFlag())) {
					shopper.setT0fee(Double.parseDouble(remote.getT0Fee()));
					shopper.setT0fixedamount(remote.getT0fixedamount());
					shopper.setT0minamount(remote.getT0minamount());
					shopper.setT0maxamount(remote.getT0maxamount());
					shopper.setT0SingleDayLimit(Double.parseDouble(remote.getShopperLimit()));// 商户额度
					
				}

				MposApplicationProgress progress = new MposApplicationProgress();
				progress.setShopperid(shopper.getShopperid().toString());
				if (Constants.STATUS1.equals(shopperType)) {
					progress.setScompany(scompany);
				} else {
					progress.setScompany(Name);
				}
				progress.setApplicationTheme(Constants.THEME);
				progress.setApplicationType(Constants.STATUS1);
				progress.setCreateDate(new Date());
				progress.setShopperidP(shopperidp);
				Agent agent = agentservice.findbyshopperidp(shopperidp);
				progress.setAgentName(agent.getScompany());
				progress.setApplicationStatus(Constants.STATUS1);
				progress.setApplicationRemark("待审核");
				progress.setPhotoId(photo.getPhotoId());
				
				MposRemoteInvitation mposRemoteInvitation = remotesrevice.findbytelstauts(tel);
				mposRemoteInvitation.setStatus(Constants.STATUS2);
				
				// merchantKey值
				String merchantKey = com.uns.util.StringUtils.getCharAndNumr(8);
				shopper.setMerchantKey(merchantKey);
				// 调用小虎注册接口
				String userType = getType(shopper.getMerchantType());
				this.merchantregservice.saveMerchantFee(shopper);
				
				//增加判读是否启用弘付注册 1启用 0 不起用
				if(ConstantsEnv.HF_OPEN_FLG.equals(Constants.CON_YES)){
					//海科成功后调弘付,判断是否申请过,0未申请，1已申请去修改
					String respCede;
					String hf_psam;
					JSONObject jsonObject = appOpenRegService.addHfMerchantPort(shopper);
					respCede = (String) jsonObject.get("respCode");
					hf_psam = (String) jsonObject.get("hf_psam");
					if(!ConstantsEnv.HF_CODE_ADD.equals(respCede)){
						throw new BusinessException(ExceptionDefine.复核商户,new String[]{"弘付报备申请失败"});
					}else{
						shopper.setHfflg(Constants.CON_YES);
						shopper.setHfpsam(hf_psam);
					}

				}

				String flage="";
				B2cDict b2cDict=shopPerbiService.findBankName(bankName);
				String hkCOde = hkMerchantUtils.addHkMerchantPort(shopper, b2cDict.getDictcls());

				if(ConstantsEnv.HK_SUCCESS_CODE.equals(hkCOde)){
					flage=appOpenRegService.saveCreate(request, response,userType, shopper, progress, mposRemoteInvitation);
				}else if (ConstantsEnv.HK_REPEAT_CODE_H2.equals(hkCOde)){
					String updateHkCOde=hkMerchantUtils.updateHkMerchantPort(shopper,b2cDict.getDictcls());
					if(!(ConstantsEnv.RESPONSE_CODE.equals(updateHkCOde))){
						hashMap.put("rspCode","6015");
						hashMap.put("rspMsg","注册失败");
						response.setContentType("UTF-8");
						JSONObject json = JSONObject.fromObject(hashMap);
						log.info("海科注册修改失败ios" + json.toString());
						response.getWriter().write(json.toString());
						return;
					}else{
						flage=appOpenRegService.saveCreate(request, response,userType, shopper, progress, mposRemoteInvitation);
					}
				}else{
					hashMap.put("rspCode","6015");
					hashMap.put("rspMsg","注册失败");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("海科注册新增失败ios" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}

				if(Constants.SUCCESS_CODE.equals(flage)){

					Map qrcodeMap=appOpenRegService.saveQrCode(request, response,userType, shopper);
					if(Constants.SUCCESS_CODE.equals(qrcodeMap.get("flag"))){
						hashMap.put("rspCode", "0000");
						hashMap.put("rspMsg", "注册成功");
						hashMap.put("shopperid", shopperid);
						hashMap.put("scompany", shopper.getScompany());
						hashMap.put("merchantKey", merchantKey);
						hashMap.put("qrpayMerchantkey", qrcodeMap.get("qrpayMerchantkey"));
						response.setContentType("UTF-8");
						JSONObject json = JSONObject.fromObject(hashMap);
						log.info("注册信息0000为成功ios" + json.toString());
						response.getWriter().write(json.toString());
						return;
					}else{
						hashMap.put("rspCode", "0000");
						hashMap.put("rspMsg", "二维码注册失败，请咨询管理员！");
						hashMap.put("shopperid", shopperid);
						hashMap.put("scompany", shopper.getScompany());
						hashMap.put("merchantKey", merchantKey);
						hashMap.put("qrpayMerchantkey", "");
						response.setContentType("UTF-8");
						JSONObject json = JSONObject.fromObject(hashMap);
						log.info("注册信息0000为成功ios" + json.toString());
						response.getWriter().write(json.toString());
						return;
					}

				}else if("6012".equals(flage)){
					hashMap.put("rspCode", "6012");
					hashMap.put("rspMsg", "实名认证失败");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("注册出错ios:" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}else if("6013".equals(flage)){
					hashMap.put("rspCode", "6013");
					hashMap.put("rspMsg", "注册银生宝失败");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("注册出错ios:" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}else{
					hashMap.put("rspCode", "6014");
					hashMap.put("rspMsg", "扫码支付注册失败");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("注册出错ios:" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}


			} else {

				// 该手机号码已存在
				hashMap.put("rspCode", "1001");
				hashMap.put("rspMsg", "电话号码已存在");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("注册信息1001电话号码已存在ios" + json.toString());
				response.getWriter().write(json.toString());
				return;

			}

		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "注册出错");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("注册出错ios:" + json.toString());
			response.getWriter().write(json.toString());
		}

	}



	public void merchantreg201A(HttpServletRequest request,
			HttpServletResponse response) throws Exception {



		Map hashMap = new HashMap();
		try {
            B2cShopperbiTemp shopper = new B2cShopperbiTemp();
            String shopperType = request.getParameter("shopperType")==null?"":request.getParameter("shopperType").trim();//商户类型0:个人 1:企业 2:商户

			String tel = request.getParameter("tel")==null?"":request.getParameter("tel").trim();
			String City = request.getParameter("City")==null?"":request.getParameter("City").trim();// 经营城市
			String Province = request.getParameter("Province")==null?"":request.getParameter("Province").trim();// 经营省份
			String cardCity = request.getParameter("cardCity")==null?"":request.getParameter("cardCity").trim();// 银行城市
			String cardProvince = request.getParameter("cardProvince")==null?"":request.getParameter("cardProvince").trim();// 银行省份
			String industryType = request.getParameter("industryType")==null?"":request.getParameter("industryType").trim();
			//String shopperType = request.getParameter("shopperType")==null?"":request.getParameter("shopperType").trim();
			String sid = request.getParameter("identityId").toUpperCase()==null?"":request.getParameter("identityId").toUpperCase().trim();
			String Name = URLDecoder.decode(request.getParameter("Name")==null?"":request.getParameter("Name").trim(),"UTF-8");// 商户姓名
			String address = URLDecoder.decode(request.getParameter("address")==null?"":request.getParameter("address").trim(),	"UTF-8");// 经营地址
			String scompany = URLDecoder.decode(request.getParameter("scompany") == null ? "" : request.getParameter("scompany").trim(), "UTF-8");// 商户名称
			String bankCard = URLDecoder.decode(request.getParameter("bankCard")==null?"":request.getParameter("bankCard").trim(), "UTF-8");// 银行卡号
			String bankName = URLDecoder.decode(request.getParameter("bankName")==null?"":request.getParameter("bankName").trim(), "UTF-8");// 银行名
			String branchBankName = URLDecoder.decode(request.getParameter("branchBankName")==null?"":request.getParameter("branchBankName").trim(), "UTF-8");// 支行名称
			String shopperidp = request.getParameter("shopperidp");// 代理商号
			String longitude = request.getParameter("longitude");// 经度
			String latitude = request.getParameter("latitude");// 纬度
			String currentLocation = request.getParameter("currentLocation");// 当前位置
			String licenseNo=request.getParameter("licenseNo")== null ? ""	: request.getParameter("licenseNo");

			// 在商户表中判断手机号码和身份证信息是否存在，
			B2cShopperbiTemp temptel = merchantregservice.findbytel(tel);
			B2cShopperbiTemp shoppersid = merchantregservice.findbysid(sid);

			// 商户号递归得到
			Area area2 = merchantregservice.findbyareaid(cardProvince,	cardCity);
			String shopperid = getPosShopperId(area2.getCity(),	Constants.CON_MCC);


			// 调用小虎接口判断手机和身份证是否存在（sid+tel）
			 String flag=checkTelSid(tel,sid);

			 //查询远程邀请表
			 findRemoteFee(tel);

			if (temptel == null && (Constants.SUCCESS_CODE.equals(flag))) {
				if (shoppersid != null) {
					hashMap.put("rspCode", "1002");
					hashMap.put("rspMsg", "身份证号码已存在");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("注册信息8888身份证号码已存在ios" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				MposPhotoTmp photo = this.photoservice.findbsid(sid);
				if (photo == null) {
					hashMap.put("rspCode", "2001");
					hashMap.put("rspMsg", "照片上传失败");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("照片上传失败ios" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}

				shopper.setMuserid(tel);
				shopper.setMerchantType(shopperType);
				shopper.setStel(tel);
				shopper.setShopperid(Long.valueOf(shopperid));
				shopper.setShopperidP(Long.valueOf(shopperidp));// 代理商号
				shopper.setIDNo(sid);
				shopper.setPhotoid(photo.getPhotoId());

				// 行业
				B2cDict industry = merchantregservice.findbyhCname(industryType);
				if (industry != null) {
					shopper.setIndustry(industry.getB2cDictId().toString());
				}
				// 所在城市票据
				Area area = merchantregservice.findbyareaid(Province, City);
				if (area != null) {
					shopper.setBillCity(area.getCityname());
					shopper.setScity(area.getCityname());
					shopper.setBillCityCode(area.getCity());
					shopper.setCity(area.getCity());
					shopper.setBillProvince(area.getProvincialname());
					shopper.setSprovince(area.getProvincialname());
					shopper.setBillProvinceCode(area.getProvincial());
					shopper.setProvince(area.getProvincial());
				}
				// 票据地址
				shopper.setBillAddress(address);
				// 票据名称
				shopper.setSaddress(address);
				// 0：个人 1企业
				if (shopperType.equals("1")) {
					shopper.setScompany(scompany);
					shopper.setName(Name);// 姓名
					shopper.setLicenseNo(licenseNo);
				} else {
					shopper.setScompany(Name);
					shopper.setName(Name);
				}
				shopper.setAccountbankclientname(Name);// 开户人姓名
				shopper.setAccountbankno(bankCard);// 卡号
				shopper.setAccountbankdictval(bankName);// 开户行名称数据字典
				shopper.setAccountbankname(branchBankName);// 支行名称
				Area area1 = merchantregservice.findbyareaid(cardProvince,cardCity);
				if (area1 != null) {
					shopper.setAccountBankCity(area1.getCityname());
					shopper.setAccountBankCityCode(area1.getCity());
					shopper.setAccountbankprov(area1.getProvincialname());
					shopper.setAccountBankProvCode(area1.getProvincial());
				}
				shopper.setReportResource(Constants.TYPE_1);// 商户报件
				shopper.setCreated(new Date());
				// 设置密码
				MposRemoteInvitation remote = remotesrevice.findbytelstauts(tel);
				if (remote != null) {
					String password = Md5Encrypt.md5(remote.getPassword().trim());
					shopper.setMuserid(tel);
					shopper.setMpassword(password);
				}
				// 默认添加字段
				shopper.setIfvalid(Short.valueOf(Constants.STATUS0));
				shopper.setOpencheckstatus(Short.valueOf(Constants.STATUS0));
				shopper.setIsformal(Short.valueOf(Constants.STATUS0));
				shopper.setIsupdateshopper(Short.valueOf(Constants.STATUS0));
				shopper.setSifpactid(Long.valueOf(Constants.STATUS0));
				shopper.setRecheckmerchantflag(Constants.STATUS0);
				shopper.setPhotoCheckFlag(Constants.STATUS0);
				shopper.setPhotoRecheckFlag(Constants.STATUS0);
				shopper.setTransact(Constants.STATUS1);
				shopper.setIsSupportT0(remote.getOpenToFlag());
				shopper.setLatitude(latitude);
				shopper.setLongitude(longitude);
				shopper.setCurrentLocation(currentLocation);
				// 0:代表开通
				if (Constants.STATUS0.equals(remote.getOpenToFlag())) {
					shopper.setT0fee(Double.parseDouble(remote.getT0Fee()));
					shopper.setT0fixedamount(remote.getT0fixedamount());
					shopper.setT0minamount(remote.getT0minamount());
					shopper.setT0maxamount(remote.getT0maxamount());
					shopper.setT0SingleDayLimit(Double.parseDouble(remote.getShopperLimit()));// 商户额度

				}

				MposApplicationProgress progress = new MposApplicationProgress();
				progress.setShopperid(shopper.getShopperid().toString());
				if (Constants.STATUS1.equals(shopperType)) {
					progress.setScompany(scompany);
				} else {
					progress.setScompany(Name);
				}
				progress.setApplicationTheme(Constants.THEME);
				progress.setApplicationType(Constants.STATUS1);
				progress.setCreateDate(new Date());
				progress.setShopperidP(shopperidp);
				Agent agent = agentservice.findbyshopperidp(shopperidp);
				progress.setAgentName(agent.getScompany());
				progress.setApplicationStatus(Constants.STATUS1);
				progress.setApplicationRemark("待审核");
				progress.setPhotoId(photo.getPhotoId());

				MposRemoteInvitation mposRemoteInvitation = remotesrevice.findbytelstauts(tel);


				// merchantKey值
				String merchantKey = com.uns.util.StringUtils.getCharAndNumr(8);
				shopper.setMerchantKey(merchantKey);
				// 调用小虎注册接口
				String userType = getType(shopper.getMerchantType());
				this.merchantregservice.saveMerchantFee(shopper);

				//增加判读是否启用弘付注册 1启用 0 不起用
				if(ConstantsEnv.HF_OPEN_FLG.equals(Constants.CON_YES)){
					//海科成功后调弘付,判断是否申请过,0未申请，1已申请去修改
					String respCede="";
					String hf_psam="";
					JSONObject jsonObject = appOpenRegService.addHfMerchantPort(shopper);
					respCede = (String) jsonObject.get("respCode");
					hf_psam = (String) jsonObject.get("hf_psam");
					if(!ConstantsEnv.HF_CODE_ADD.equals(respCede)){
						throw new BusinessException(ExceptionDefine.复核商户,new String[]{"弘付报备申请失败"});
					}else{
						shopper.setHfflg(Constants.CON_YES);
						shopper.setHfpsam(hf_psam);
					}
					
				}
				
				mposRemoteInvitation.setStatus(Constants.STATUS2);

				String flage="";
				B2cDict b2cDict=shopPerbiService.findBankName(bankName);
				String hkCOde=hkMerchantUtils.addHkMerchantPort(shopper,b2cDict.getDictcls());
				if(ConstantsEnv.HK_SUCCESS_CODE.equals(hkCOde)){
					flage=appOpenRegService.saveCreate(request, response,userType, shopper, progress, mposRemoteInvitation);
				}else if (ConstantsEnv.HK_REPEAT_CODE_H2.equals(hkCOde)){
					String updateHkCOde=hkMerchantUtils.updateHkMerchantPort(shopper,b2cDict.getDictcls());
					if(ConstantsEnv.RESPONSE_CODE.equals(updateHkCOde)){
						flage=appOpenRegService.saveCreate(request, response,userType, shopper, progress, mposRemoteInvitation);
					}else{
						hashMap.put("rspCode","6015");
						hashMap.put("rspMsg","注册失败");
						response.setContentType("UTF-8");
						JSONObject json = JSONObject.fromObject(hashMap);
						log.info("海科注册修改失败A" + json.toString());
						response.getWriter().write(json.toString());
						return;
					}
				}else{
					hashMap.put("rspCode","6015");
					hashMap.put("rspMsg","注册失败");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("海科注册新增失败A" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				
				if(Constants.SUCCESS_CODE.equals(flage)){

					Map qrcodeMap=appOpenRegService.saveQrCode(request, response,userType, shopper);
					
					if(Constants.SUCCESS_CODE.equals(qrcodeMap.get("flag"))){
						hashMap.put("rspCode", "0000");
						hashMap.put("rspMsg", "注册成功");
						hashMap.put("shopperid", shopperid);
						hashMap.put("scompany", shopper.getScompany());
						hashMap.put("merchantKey", merchantKey);
						hashMap.put("qrpayMerchantkey", qrcodeMap.get("qrpayMerchantkey"));
						response.setContentType("UTF-8");
						JSONObject json = JSONObject.fromObject(hashMap);
						log.info("注册信息0000为成功ios" + json.toString());
						response.getWriter().write(json.toString());
						return;
					}else{
						hashMap.put("rspCode", "0000");
						hashMap.put("rspMsg", "二维码注册失败，请咨询管理员！");
						hashMap.put("shopperid", shopperid);
						hashMap.put("scompany", shopper.getScompany());
						hashMap.put("merchantKey", merchantKey);
						hashMap.put("qrpayMerchantkey", "");
						response.setContentType("UTF-8");
						JSONObject json = JSONObject.fromObject(hashMap);
						log.info("注册信息0000为成功ios" + json.toString());
						response.getWriter().write(json.toString());
						return;
					}
					
				}else if("6012".equals(flage)){
					hashMap.put("rspCode", "6012");
					hashMap.put("rspMsg", "实名认证失败");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("注册出错ios:" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}else if("6013".equals(flage)){
					hashMap.put("rspCode", "6013");
					hashMap.put("rspMsg", "注册银生宝失败");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("注册出错ios:" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}else{
					hashMap.put("rspCode", "6014");
					hashMap.put("rspMsg", "扫码支付注册失败");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("注册出错ios:" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				

			} else {
				
				// 该手机号码已存在
				hashMap.put("rspCode", "1001");
				hashMap.put("rspMsg", "电话号码已存在");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("注册信息1001电话号码已存在ios" + json.toString());
				response.getWriter().write(json.toString());
				return;
				
			}

		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "注册出错");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("注册出错ios:" + json.toString());
			response.getWriter().write(json.toString());
		}

	
		
	}


	

	/** 商户信息查询
	 * @param request
	 * @param response
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=queryshopper")
	public void queryshopper(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String version = request.getParameter("version") == null ? "" : request
				.getParameter("version");
			queryshopper220(request, response);
	}

	
	private void queryshopper220(HttpServletRequest request,
								 HttpServletResponse response) throws Exception {
		String type = request.getParameter("type") == null ? "" : request.getParameter("type");
		if ((Constants.TYPE_A).equals(type)) {
			queryshopper220A(request, response);
		} else if ((Constants.TYPE_I).equals(type)) {
			queryshopper220I(request, response);
		}
	}

	
	private void queryshopper220I(HttpServletRequest request,
								  HttpServletResponse response) throws Exception {

		HashMap hashMap = new HashMap();
		try {
			String shopperid = request.getParameter("shopperid") == null ? "": request.getParameter("shopperid");
			String tel = request.getParameter("tel") == null ? "" : request.getParameter("tel");
			List<HashMap> list = merchantregservice.findbyshopper(shopperid);
			if (list != null && list.size() > 0) {
				HashMap hashMap1 = list.get(0);
				hashMap1.put("ACCOUNT_BANK_NO", AesEncrypt.encryptAES(hashMap1.get("ACCOUNT_BANK_NO").toString(),ConstantsEnv.APP_AES_KEY));
				hashMap1.put("ID_NO",AesEncrypt.encryptAES(hashMap1.get("ID_NO").toString(),ConstantsEnv.APP_AES_KEY));
				list = new ArrayList<>();
				list.add(hashMap1);
				hashMap.put("shopper", list);
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "商户信息查询成功");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("商户信息查询成功android" + json.toString());
				response.getWriter().write(json.toString());
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "查询失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("查询失败android:" + json.toString());
			response.getWriter().write(json.toString());
		}



	}
	private void queryshopper220A(HttpServletRequest request,
								  HttpServletResponse response) throws Exception {

		HashMap hashMap = new HashMap();
		try {
			String shopperid = request.getParameter("shopperid") == null ? "": request.getParameter("shopperid");
			String tel = request.getParameter("tel") == null ? "" : request.getParameter("tel");
			List<HashMap> list = merchantregservice.findbyshopper(shopperid);
			if (list != null && list.size() > 0) {
				HashMap hashMap1 = list.get(0);
				hashMap1.put("ACCOUNT_BANK_NO", AesEncrypt.encryptAES(hashMap1.get("ACCOUNT_BANK_NO").toString(),ConstantsEnv.APP_AES_KEY));
				hashMap1.put("ID_NO",AesEncrypt.encryptAES(hashMap1.get("ID_NO").toString(),ConstantsEnv.APP_AES_KEY));
				list = new ArrayList<>();
				list.add(hashMap1);
				hashMap.put("shopper", list);
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "商户信息查询成功");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("商户信息查询成功android" + json.toString());
				response.getWriter().write(json.toString());
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "查询失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("查询失败android:" + json.toString());
			response.getWriter().write(json.toString());
		}



	}


	/** 审核状态刷新
	 * @param request
	 * @param response
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=querystatus")
	public void querystatus(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String version = request.getParameter("version") == null ? "" : request
				.getParameter("version");
			querystatus220(request, response);
	}

	
	private void querystatus220(HttpServletRequest request,
								HttpServletResponse response) throws Exception {
		String type = request.getParameter("type") == null ? "" : request.getParameter("type");
		if ((Constants.TYPE_A).equals(type)) {
			querystatus220A(request, response);
		} else if ((Constants.TYPE_I).equals(type)) {
			querystatus220I(request, response);
		}

	}
	private void querystatus220I(HttpServletRequest request,
								 HttpServletResponse response) throws IOException {


		HashMap hashMap = new HashMap();
		try {
			String shopperid = request.getParameter("shopperid") == null ? "": request.getParameter("shopperid");
			B2cShopperbiTemp shopper = merchantregservice.findbyshopperid(shopperid);
			if (shopper != null) {
				if (Constants.STATUS0.equals(shopper.getIfvalid().toString())) {
					hashMap.put("name", shopper.getName());
					hashMap.put("scompany", shopper.getScompany());
					hashMap.put("status", "3");
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "商户信息未审核");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息未审核android" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}

				if (Constants.STATUS1.equals(shopper.getIfvalid().toString())&&(Constants.STATUS0.equals(shopper.getRecheckmerchantflag().toString()))) {
					hashMap.put("name", shopper.getName());
					hashMap.put("scompany", shopper.getScompany());
					hashMap.put("status", "3");
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "商户信息未审核");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息未审核android" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}

				if (Constants.STATUS1.equals(shopper.getRecheckmerchantflag().toString())) {
					B2cDict bankname=this.merchantregservice.findBankName(shopper.getAccountbankdictval().toString());
					hashMap.put("status", "0");
					hashMap.put("name", shopper.getName());
					hashMap.put("scompany", shopper.getScompany());
					hashMap.put("bankNo", AesEncrypt.encryptAES(shopper.getAccountbankno(),ConstantsEnv.APP_AES_KEY));
					hashMap.put("idNo", ToolsUtils.getSubStr(shopper.getIDNo()));
					hashMap.put("shopperType", shopper.getMerchantType());
					//新增返回值
					hashMap.put("bankname", bankname==null?"":bankname.getDict());
					hashMap.put("cardprovince", shopper.getAccountbankprov());
					hashMap.put("cardcity", shopper.getAccountBankCity());
					hashMap.put("branchBankName", shopper.getAccountbankname());
					hashMap.put("openT+0", shopper.getIsSupportT0());
					hashMap.put("t0Fee",shopper.getT0fee());
					hashMap.put("t0fixedamount",shopper.getT0fixedamount());
					hashMap.put("t0maxamount",shopper.getT0maxamount());
					hashMap.put("t0minamount",shopper.getT0minamount());

					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "商户信息审核已通过");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息审核已通过" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				if (Constants.STATUS2.equals(shopper.getIfvalid().toString())) {
					hashMap.put("name", shopper.getName());
					hashMap.put("scompany", shopper.getScompany());
					hashMap.put("status", "2");
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg","商户信息审核不通过：" + shopper.getExamineresullt());
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息审核不通过android" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				if (Constants.STATUS2.equals(shopper.getRecheckmerchantflag().toString())) {
					hashMap.put("name", shopper.getName());
					hashMap.put("scompany", shopper.getScompany());
					hashMap.put("status", "2");
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg","商户信息审核不通过：" + shopper.getRecheckmerchantremark());
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息审核不通过android" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}

			} else {

				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "商户为空");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("查询失败android:" + json.toString());
				response.getWriter().write(json.toString());
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "查询失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("查询失败android:" + json.toString());
			response.getWriter().write(json.toString());
		}





	}
	private void querystatus220A(HttpServletRequest request,
								 HttpServletResponse response) throws Exception {

		HashMap hashMap = new HashMap();
		try {
			String shopperid = request.getParameter("shopperid") == null ? "": request.getParameter("shopperid");
			B2cShopperbiTemp shopper = merchantregservice.findbyshopperid(shopperid);
			if (shopper != null) {
				if (Constants.STATUS0.equals(shopper.getIfvalid().toString())) {
					hashMap.put("name", shopper.getName());
					hashMap.put("scompany", shopper.getScompany());
					hashMap.put("status", "3");
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "商户信息未审核");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息未审核android" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}

				if (Constants.STATUS1.equals(shopper.getIfvalid().toString())&&(Constants.STATUS0.equals(shopper.getRecheckmerchantflag().toString()))) {
					hashMap.put("name", shopper.getName());
					hashMap.put("scompany", shopper.getScompany());
					hashMap.put("status", "3");
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "商户信息未审核");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息未审核android" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}

				if (Constants.STATUS1.equals(shopper.getRecheckmerchantflag().toString())) {
					B2cDict bankname=this.merchantregservice.findBankName(shopper.getAccountbankdictval().toString());
					hashMap.put("status", "0");
					hashMap.put("name", shopper.getName());
					hashMap.put("scompany", shopper.getScompany());
					hashMap.put("bankNo", AesEncrypt.encryptAES(shopper.getAccountbankno(),ConstantsEnv.APP_AES_KEY));
					hashMap.put("idNo", ToolsUtils.getSubStr(shopper.getIDNo()));
					hashMap.put("shopperType", shopper.getMerchantType());
					//新增返回值
					hashMap.put("bankname", bankname==null?"":bankname.getDict());
					hashMap.put("cardprovince", shopper.getAccountbankprov());
					hashMap.put("cardcity", shopper.getAccountBankCity());
					hashMap.put("branchBankName", shopper.getAccountbankname());
					hashMap.put("openT+0", shopper.getIsSupportT0());
					hashMap.put("t0Fee",shopper.getT0fee());
					hashMap.put("t0fixedamount",shopper.getT0fixedamount());
					hashMap.put("t0maxamount",shopper.getT0maxamount());
					hashMap.put("t0minamount",shopper.getT0minamount());

					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "商户信息审核已通过");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息审核已通过" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				if (Constants.STATUS2.equals(shopper.getIfvalid().toString())) {
					hashMap.put("name", shopper.getName());
					hashMap.put("scompany", shopper.getScompany());
					hashMap.put("status", "2");
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg","商户信息审核不通过：" + shopper.getExamineresullt());
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息审核不通过android" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				if (Constants.STATUS2.equals(shopper.getRecheckmerchantflag().toString())) {
					hashMap.put("name", shopper.getName());
					hashMap.put("scompany", shopper.getScompany());
					hashMap.put("status", "2");
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg","商户信息审核不通过：" + shopper.getRecheckmerchantremark());
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息审核不通过android" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}

			} else {

				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "商户为空");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("查询失败android:" + json.toString());
				response.getWriter().write(json.toString());
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "查询失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("查询失败android:" + json.toString());
			response.getWriter().write(json.toString());
		}



	}

	
	
	/**
	 * @param request
	 * @param response
	 * @throws IOException
	 *             修改商户
	 * 
	 */
	@RequestMapping(params = "method=updateshopper")
	public void updateshopper(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		String version = request.getParameter("version") == null ? "" : request.getParameter("version");
        updateshopper220(request, response);
	}
	
	

	

	/**
	 * @param request
	 * @param response
	 * @throws IOException
	 *             修改结算银行卡信息
	 * 
	 */
	@RequestMapping(params = "method=updatebank")
	public void updatebank(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String version = request.getParameter("version") == null ? "" : request.getParameter("version");
		String shoppertype = request.getParameter("merchantType") == null ? "" : request.getParameter("merchantType");
		//版本2.4.0  聚合支付版
		if(Constants.VERSION_2_4_0.equals(version) && Constants.TYPE_2.equals(shoppertype)){
            shopPerbiService.updateAggBankInfo(request,response);
        } else {
            updatebank200(request, response);
        }
	}
	
	
	/**
	 * @param request
	 * @param response
	 * @throws IOException
	 *             查询结算银行卡信息
	 * 
	 */
	@RequestMapping(params = "method=querybank")
	public void querybank(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		String version = request.getParameter("version") == null ? "" : request
				.getParameter("version");
			querybank200(request, response);
	}
	
	
	/**
	 * @param request
	 * @param response
	 * @throws IOException
	 *             查询代理商
	 * 
	 */
	@RequestMapping(params = "method=queryagent")
	public void queryagent(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		String version = request.getParameter("version") == null ? "" : request
				.getParameter("version");
			queryagent200(request, response);
	}

	

	



	/**商户信息修改2.2.0版本
	 * @param request
	 * @param response
	 * @throws IOException
	 *
	 */
	public void updateshopper220(HttpServletRequest request,
								 HttpServletResponse response) throws IOException {
		String type = request.getParameter("type") == null ? "" : request.getParameter("type");
		if ((Constants.TYPE_A).equals(type)) {
			updateshopper220A(request, response);
		} else if ((Constants.TYPE_I).equals(type)) {
			updateshopper220I(request, response);
		}
	}
	
	
	/**
	 * @param request
	 * @param response
	 * @throws IOException
	 *             结算银行卡信息修改2.0.0版本
	 */
	public void updatebank200(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		String type = request.getParameter("type") == null ? "" : request.getParameter("type");
		if ((Constants.TYPE_A).equals(type)) {
			updatebankA(request, response);
		} else if ((Constants.TYPE_I).equals(type)) {
			updatebankI(request, response);
		}

	}
	
	
	/**
	 * @param request
	 * @param response
	 * @throws IOException
	 *             结算银行卡信息查询2.0.0版本
	 */
	public void querybank200(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		String type = request.getParameter("type") == null ? "" : request.getParameter("type");
		if ((Constants.TYPE_A).equals(type)) {
			querybankA(request, response);
		} else if ((Constants.TYPE_I).equals(type)) {
			querybankI(request, response);
		}

	}
	
	
	/**
	 * @param request
	 * @param response
	 * @throws IOException
	 *             查询代理商信息2.0.0版本
	 */
	public void queryagent200(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		String type = request.getParameter("type") == null ? "" : request.getParameter("type");
		if ((Constants.TYPE_A).equals(type)) {
			queryagentA(request, response);
		} else if ((Constants.TYPE_I).equals(type)) {
			queryagentI(request, response);
		}

	}
	
	
	
	

	

	

	/**
	 * @param request
	 * @param response
	 * @throws IOException
	 *             修改商户 Android端
	 *
	 */
	public void updateshopper220A(HttpServletRequest request,
							   HttpServletResponse response) throws IOException {
		HashMap hashMap = new HashMap();
		try {
			String shopperid = request.getParameter("shopperid");
			String Name = URLDecoder.decode(request.getParameter("Name"),"UTF-8");// 姓名
			String identityId = AesEncrypt.decryptAES(request.getParameter("identityId"),ConstantsEnv.APP_AES_KEY).toUpperCase();// 身份证
			String bankCard = AesEncrypt.decryptAES(request.getParameter("bankCard"),ConstantsEnv.APP_AES_KEY);// 结算卡号
			String bankName = request.getParameter("bankName");// 开户银行
			String Province = request.getParameter("Province");// 经营省市
			String City = request.getParameter("City");// 经营市
			String address = URLDecoder.decode(request.getParameter("address"),"UTF-8");// 经营地址
			String shopperType = request.getParameter("shopperType");// 商户类型
			String industryType = request.getParameter("industryType");// 行业
			String scompany = URLDecoder.decode(request.getParameter("scompany") == null ? "" : request.getParameter("scompany"), "UTF-8");// 商户名称
			String branchBankName = URLDecoder.decode(request.getParameter("branchBankName"), "UTF-8");// 支行名称
			String cardCity = request.getParameter("cardCity");
			String cardProvince = request.getParameter("cardProvince");
			String longitude = request.getParameter("longitude");// 经度
			String latitude = request.getParameter("latitude");// 纬度
			String currentLocation = request.getParameter("currentLocation");// 当前位置

			// 根据商户号得到shopper对象
			B2cShopperbiTemp shopper = this.merchantregservice.findbyshopperid(shopperid);
			if (shopper == null) {
				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "商户信息修改失败");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("商户信息修改失败android:" + json.toString());
				response.getWriter().write(json.toString());
			} else {
				//注册(补进商户)为"5"
				shopper.setReportResource("5");
				shopper.setName(Name);
				shopper.setIDNo(identityId);
				shopper.setSaddress(address);
				shopper.setBillAddress(address);
				shopper.setMerchantType(shopperType);
				shopper.setLongitude(longitude);
				shopper.setLatitude(latitude);
				shopper.setCurrentLocation(currentLocation);
				shopper.setIfvalid(Short.valueOf(Constants.STATUS0));
				shopper.setRecheckmerchantflag(Constants.STATUS0);
				shopper.setRecheckaccountflag(Constants.STATUS0);
				shopper.setOpencheckstatus(new Short(Constants.STATUS0));
				// 行业
				B2cDict industry = merchantregservice.findbyhCname(industryType);
				if (industry != null) {
					shopper.setIndustry(industry.getB2cDictId().toString());
				}
				Area area = merchantregservice.findbyareaid(Province, City);
				if (area != null) {
					shopper.setBillCity(area.getCityname());
					shopper.setScity(area.getCityname());
					shopper.setBillCityCode(area.getCity());
					shopper.setCity(area.getCity());
					shopper.setBillProvince(area.getProvincialname());
					shopper.setSprovince(area.getProvincialname());
					shopper.setBillProvinceCode(area.getProvincial());
					shopper.setProvince(area.getProvincial());
				}
				Area area1 = merchantregservice.findbyareaid(cardProvince,cardCity);
				if (area1 != null) {
					shopper.setAccountBankCity(area1.getCityname());
					shopper.setAccountBankCityCode(area1.getCity());
					shopper.setAccountbankprov(area1.getProvincialname());
					shopper.setAccountBankProvCode(area1.getProvincial());
				}
				// 如果是0：个人
				if (Constants.STATUS0.equals(shopperType)) {
					shopper.setScompany(Name);
				} else {
					shopper.setScompany(scompany);
				}
				//比较开户信息是否修改过
				Map map=compareBankInfo(bankName,branchBankName,bankCard,shopper);

				shopper.setAccountbankdictval(bankName);
				shopper.setAccountbankname(branchBankName);
				shopper.setAccountbankno(bankCard);
				
				//维护老商户OCR审核状态
				shopper.setCheckstatus(Constants.TYPE_4);//人工审核中


				JSONObject ob= JSONObject.fromObject(map);
				String rspCode=(String)ob.get("rspCode");
				if(Constants.SUCCESS_CODE.equals(rspCode)){
					this.merchantregservice.updateB2cShopperbiTemp(shopper);
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "商户信息修改成功");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息修改成功:android" + json.toString());
					response.getWriter().write(json.toString());
				}else{
					hashMap.put("rspCode", "1001");
					hashMap.put("rspMsg", "更新开户信息失败");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息修改成功:android" + json.toString());
					response.getWriter().write(json.toString());
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "商户信息修改失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("商户信息修改失败android:" + json.toString());
			response.getWriter().write(json.toString());
		}
	}
	/**
	 * @param request
	 * @param response
	 * @throws IOException
	 *             修改商户 Android端
	 * 
	 */
	public void updateshopperA(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		HashMap hashMap = new HashMap();
		try {
			String shopperid = request.getParameter("shopperid");
			String Name = URLDecoder.decode(request.getParameter("Name"),"UTF-8");// 姓名
			String identityId = request.getParameter("identityId").toUpperCase();// 身份证
			String bankCard = request.getParameter("bankCard");// 结算卡号
			String bankName = request.getParameter("bankName");// 开户银行
			String Province = request.getParameter("Province");// 经营省市
			String City = request.getParameter("City");// 经营市
			String address = URLDecoder.decode(request.getParameter("address"),"UTF-8");// 经营地址
			String shopperType = request.getParameter("shopperType");// 商户类型
			String industryType = request.getParameter("industryType");// 行业
			String scompany = URLDecoder.decode(request.getParameter("scompany") == null ? "" : request.getParameter("scompany"), "UTF-8");// 商户名称
			String branchBankName = URLDecoder.decode(request.getParameter("branchBankName"), "UTF-8");// 支行名称
			String cardCity = request.getParameter("cardCity");
			String cardProvince = request.getParameter("cardProvince");
			String longitude = request.getParameter("longitude");// 经度
			String latitude = request.getParameter("latitude");// 纬度
			String currentLocation = request.getParameter("currentLocation");// 当前位置

			// 根据商户号得到shopper对象
			B2cShopperbiTemp shopper = this.merchantregservice.findbyshopperid(shopperid);
			if (shopper == null) {
				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "商户信息修改失败");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("商户信息修改失败android:" + json.toString());
				response.getWriter().write(json.toString());
			} else {
				//补进商户为"5"
				shopper.setReportResource("5");
				shopper.setName(Name);
				shopper.setIDNo(identityId);
				shopper.setSaddress(address);
				shopper.setBillAddress(address);
				shopper.setMerchantType(shopperType);
				shopper.setLongitude(longitude);
				shopper.setLatitude(latitude);
				shopper.setCurrentLocation(currentLocation);
				shopper.setIfvalid(Short.valueOf(Constants.STATUS0));
				shopper.setRecheckmerchantflag(Constants.STATUS0);
				shopper.setRecheckaccountflag(Constants.STATUS0);
                shopper.setOpencheckstatus(new Short(Constants.STATUS0));
				// 行业
				B2cDict industry = merchantregservice.findbyhCname(industryType);
				if (industry != null) {
					shopper.setIndustry(industry.getB2cDictId().toString());
				}
				Area area = merchantregservice.findbyareaid(Province, City);
				if (area != null) {
					shopper.setBillCity(area.getCityname());
					shopper.setScity(area.getCityname());
					shopper.setBillCityCode(area.getCity());
					shopper.setCity(area.getCity());
					shopper.setBillProvince(area.getProvincialname());
					shopper.setSprovince(area.getProvincialname());
					shopper.setBillProvinceCode(area.getProvincial());
					shopper.setProvince(area.getProvincial());
				}
				Area area1 = merchantregservice.findbyareaid(cardProvince,cardCity);
				if (area1 != null) {
					shopper.setAccountBankCity(area1.getCityname());
					shopper.setAccountBankCityCode(area1.getCity());
					shopper.setAccountbankprov(area1.getProvincialname());
					shopper.setAccountBankProvCode(area1.getProvincial());
				}
				// 如果是0：个人
				if (Constants.STATUS0.equals(shopperType)) {
					shopper.setScompany(Name);
				} else {
					shopper.setScompany(scompany);
				}
				//比较开户信息是否修改过
				Map map=compareBankInfo(bankName,branchBankName,bankCard,shopper);
				
				shopper.setAccountbankdictval(bankName);
				shopper.setAccountbankname(branchBankName);
				shopper.setAccountbankno(bankCard);
				
				
				JSONObject ob= JSONObject.fromObject(map);
				String rspCode=(String)ob.get("rspCode");
				if(Constants.SUCCESS_CODE.equals(rspCode)){
					this.merchantregservice.updateB2cShopperbiTemp(shopper);
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "商户信息修改成功");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息修改成功:android" + json.toString());
					response.getWriter().write(json.toString());
				}else{
					hashMap.put("rspCode", "1001");
					hashMap.put("rspMsg", "更新开户信息失败");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息修改成功:android" + json.toString());
					response.getWriter().write(json.toString());
				}
				
			}

		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "商户信息修改失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("商户信息修改失败android:" + json.toString());
			response.getWriter().write(json.toString());
		}
	}

	/**比较是否修改开户信息
	 * @param bankName
	 * @param branchBankName
	 * @param bankCard
	 * @param shopper
	 * @throws Exception 
	 */
	private Map compareBankInfo(String bankName, String branchBankName,
			String bankCard, B2cShopperbiTemp shopper) throws Exception {
		if(bankName.equals(shopper.getAccountbankdictval())
				&&branchBankName.equals(shopper.getAccountbankname())
				&&bankCard.equals(shopper.getAccountbankno())){
			System.out.println("=================开户信息没有修改============");
			Map map=new HashMap();
			map.put("rspCode", "0000");
			map.put("rspMsg", "没有修改开户行信息");
			return map;
		}else{
			shopper.setAccountbankdictval(bankName);
			shopper.setAccountbankname(branchBankName);
			shopper.setAccountbankno(bankCard);
			return updateBankPort(shopper);
		}
		
	}
	private Map updateBankPort(B2cShopperbiTemp b2cShopperbi) throws  Exception {
		
		HashMap params=new HashMap();
		
		Date dates = new Date();
		String mradom = RandomStringUtils.randomNumeric(6);
		String orderId = DateUtil.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbi.getB2cShopperbiId();
		String orderTime = DateUtil.getTypeDate(dates, "yyyyMMddhhmmss");
		
		String idNum=b2cShopperbi.getIDNo();
		String bankCode=this.merchantregservice.findBankName(b2cShopperbi.getAccountbankdictval()) == null ? "" : URLDecoder.decode(
				merchantregservice.findBankName(b2cShopperbi.getAccountbankdictval()).getDictid(),"UTF-8");
		String bankNo=b2cShopperbi.getAccountbankno();
		String bankName=b2cShopperbi.getAccountbankname();
		String prov=b2cShopperbi.getAccountBankProvCode();
	    String city=b2cShopperbi.getAccountBankCityCode();
	    //省市
	    String accountBankCity = b2cShopperbi.getAccountBankCity();
	  	String accountbankprov = b2cShopperbi.getAccountbankprov();
        params.put("openingBankName", b2cShopperbi.getAccountbankdictval());
        params.put("accountBankCity", accountBankCity); 
        params.put("accountbankprov", accountbankprov); 
        params.put("orderId", orderId);
        params.put("orderTime", orderTime);
        params.put("idNum", idNum);
        params.put("bankCode", bankCode);
        params.put("bankNo", bankNo);
        params.put("bankName", bankName);
        params.put("prov", prov);
        params.put("city", city);
        
        log.info("修改银行卡账户信息："+ ConstantsEnv.MODIFY_BANK_CARD_URL+params.toString());
        Map resultMap = HttpClientUtils.postRequestMap(ConstantsEnv.MODIFY_BANK_CARD_URL, params, Map.class);
		log.info("修改银行卡账户信息返回码:"+resultMap);
		return resultMap;
	}

	/**
	 * @param request
	 * @param response
	 * @throws IOException
	 *             修改商户 IOS端
	 *
	 */
	public void updateshopper220I(HttpServletRequest request,
							   HttpServletResponse response) throws IOException {
		HashMap hashMap = new HashMap();
		try {
			String shopperid = request.getParameter("shopperid");
			String Name = URLDecoder.decode(request.getParameter("Name"),"UTF-8");// 姓名
			String identityId = AesEncrypt.decryptAES(request.getParameter("identityId"),ConstantsEnv.APP_AES_KEY).toUpperCase();// 身份证
			String bankCard = AesEncrypt.decryptAES(request.getParameter("bankCard"),ConstantsEnv.APP_AES_KEY);// 结算卡号
			String bankName = request.getParameter("bankName");// 开户银行
			String Province = request.getParameter("Province");// 经营省市
			String City = request.getParameter("City");// 经营市
			String address = URLDecoder.decode(request.getParameter("address"),	"UTF-8");// 经营地址
			String shopperType = request.getParameter("shopperType");// 商户类型
			String industryType = request.getParameter("industryType");// 行业
			String scompany = URLDecoder.decode(request.getParameter("scompany") == null ? "" : request	.getParameter("scompany"), "UTF-8");// 商户名称
			String branchBankName = URLDecoder.decode(request.getParameter("branchBankName"), "UTF-8");// 支行名称
			String cardCity = request.getParameter("cardCity");
			String cardProvince = request.getParameter("cardProvince");
			String longitude = request.getParameter("longitude");// 经度
			String latitude = request.getParameter("latitude");// 纬度
			String currentLocation = request.getParameter("currentLocation");// 当前位置

			// 根据商户号得到shopper对象
			B2cShopperbiTemp shopper = this.merchantregservice.findbyshopperid(shopperid);
			if (shopper == null) {
				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "商户信息修改失败");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("商户信息修改失败ios:" + json.toString());
				response.getWriter().write(json.toString());
			} else {
				//补进商户为"5"
				shopper.setReportResource("5");
				shopper.setName(Name);
				shopper.setIDNo(identityId);
				shopper.setSaddress(address);
				shopper.setBillAddress(address);
				shopper.setMerchantType(shopperType);
				shopper.setLongitude(longitude);
				shopper.setLatitude(latitude);
				shopper.setCurrentLocation(currentLocation);
				shopper.setIfvalid(Short.valueOf(Constants.STATUS0));
				shopper.setRecheckmerchantflag(Constants.STATUS0);
				shopper.setRecheckaccountflag(Constants.STATUS0);
				shopper.setOpencheckstatus(new Short(Constants.STATUS0));
				// 行业
				B2cDict industry = merchantregservice.findbyhCname(industryType);
				if (industry != null) {
					shopper.setIndustry(industry.getB2cDictId().toString());
				}
				Area area = merchantregservice.findbyareaid(Province, City);
				if (area != null) {
					shopper.setBillCity(area.getCityname());
					shopper.setScity(area.getCityname());
					shopper.setBillCityCode(area.getCity());
					shopper.setCity(area.getCity());
					shopper.setBillProvince(area.getProvincialname());
					shopper.setSprovince(area.getProvincialname());
					shopper.setBillProvinceCode(area.getProvincial());
					shopper.setProvince(area.getProvincial());
				}
				Area area1 = merchantregservice.findbyareaid(cardProvince,
						cardCity);
				if (area1 != null) {
					shopper.setAccountBankCity(area1.getCityname());
					shopper.setAccountBankCityCode(area1.getCity());
					shopper.setAccountbankprov(area1.getProvincialname());
					shopper.setAccountBankProvCode(area1.getProvincial());
				}
				// 如果是0：个人
				if (Constants.STATUS0.equals(shopperType)) {
					shopper.setScompany(Name);

				} else {
					shopper.setScompany(scompany);
					shopper.setName(Name);
				}
				Map map=compareBankInfo(bankName,branchBankName,bankCard,shopper);

				shopper.setAccountbankdictval(bankName);
				shopper.setAccountbankname(branchBankName);
				shopper.setAccountbankno(bankCard);
				
				//维护老商户OCR审核状态
				shopper.setCheckstatus(Constants.TYPE_4);//人工审核中

				JSONObject ob= JSONObject.fromObject(map);
				String rspCode=(String)ob.get("rspCode");
				if(Constants.SUCCESS_CODE.equals(rspCode)){
					this.merchantregservice.updateB2cShopperbiTemp(shopper);
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "商户信息修改成功");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息修改成功:android" + json.toString());
					response.getWriter().write(json.toString());
				}else{
					hashMap.put("rspCode", "1001");
					hashMap.put("rspMsg", "更新开户信息失败");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息修改成功:android" + json.toString());
					response.getWriter().write(json.toString());
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "商户信息修改失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("商户信息修改失败ios:" + json.toString());
			response.getWriter().write(json.toString());
		}
	}
	/**
	 * @param request
	 * @param response
	 * @throws IOException
	 *             修改商户 IOS端
	 * 
	 */
	public void updateshopperI(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		HashMap hashMap = new HashMap();
		try {
			String shopperid = request.getParameter("shopperid");
			String Name = URLDecoder.decode(request.getParameter("Name"),"UTF-8");// 姓名
			String identityId = request.getParameter("identityId").toUpperCase();// 身份证
			String bankCard = request.getParameter("bankCard");// 结算卡号
			String bankName = request.getParameter("bankName");// 开户银行
			String Province = request.getParameter("Province");// 经营省市
			String City = request.getParameter("City");// 经营市
			String address = URLDecoder.decode(request.getParameter("address"),	"UTF-8");// 经营地址
			String shopperType = request.getParameter("shopperType");// 商户类型
			String industryType = request.getParameter("industryType");// 行业
			String scompany = URLDecoder.decode(request.getParameter("scompany") == null ? "" : request	.getParameter("scompany"), "UTF-8");// 商户名称
			String branchBankName = URLDecoder.decode(request.getParameter("branchBankName"), "UTF-8");// 支行名称
			String cardCity = request.getParameter("cardCity");
			String cardProvince = request.getParameter("cardProvince");
			String longitude = request.getParameter("longitude");// 经度
			String latitude = request.getParameter("latitude");// 纬度
			String currentLocation = request.getParameter("currentLocation");// 当前位置

			// 根据商户号得到shopper对象
			B2cShopperbiTemp shopper = this.merchantregservice.findbyshopperid(shopperid);
			if (shopper == null) {
				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "商户信息修改失败");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("商户信息修改失败ios:" + json.toString());
				response.getWriter().write(json.toString());
			} else {
				//修改进件类别5
				shopper.setReportResource("5");
				shopper.setName(Name);
				shopper.setIDNo(identityId);
				shopper.setSaddress(address);
				shopper.setBillAddress(address);
				shopper.setMerchantType(shopperType);
				shopper.setLongitude(longitude);
				shopper.setLatitude(latitude);
				shopper.setCurrentLocation(currentLocation);
				shopper.setIfvalid(Short.valueOf(Constants.STATUS0));
				shopper.setRecheckmerchantflag(Constants.STATUS0);
				shopper.setRecheckaccountflag(Constants.STATUS0);
				shopper.setOpencheckstatus(new Short(Constants.STATUS0));
				// 行业
				B2cDict industry = merchantregservice.findbyhCname(industryType);
				if (industry != null) {
					shopper.setIndustry(industry.getB2cDictId().toString());
				}
				Area area = merchantregservice.findbyareaid(Province, City);
				if (area != null) {
					shopper.setBillCity(area.getCityname());
					shopper.setScity(area.getCityname());
					shopper.setBillCityCode(area.getCity());
					shopper.setCity(area.getCity());
					shopper.setBillProvince(area.getProvincialname());
					shopper.setSprovince(area.getProvincialname());
					shopper.setBillProvinceCode(area.getProvincial());
					shopper.setProvince(area.getProvincial());
				}
				Area area1 = merchantregservice.findbyareaid(cardProvince,
						cardCity);
				if (area1 != null) {
					shopper.setAccountBankCity(area1.getCityname());
					shopper.setAccountBankCityCode(area1.getCity());
					shopper.setAccountbankprov(area1.getProvincialname());
					shopper.setAccountBankProvCode(area1.getProvincial());
				}
				// 如果是0：个人
				if (Constants.STATUS0.equals(shopperType)) {
					shopper.setScompany(Name);

				} else {
					shopper.setScompany(scompany);
					shopper.setName(Name);
				}
				Map map=compareBankInfo(bankName,branchBankName,bankCard,shopper);
				
				shopper.setAccountbankdictval(bankName);
				shopper.setAccountbankname(branchBankName);
				shopper.setAccountbankno(bankCard);
				
				
				JSONObject ob= JSONObject.fromObject(map);
				String rspCode=(String)ob.get("rspCode");
				if(Constants.SUCCESS_CODE.equals(rspCode)){
					this.merchantregservice.updateB2cShopperbiTemp(shopper);
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "商户信息修改成功");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息修改成功:android" + json.toString());
					response.getWriter().write(json.toString());
				}else{
					hashMap.put("rspCode", "1001");
					hashMap.put("rspMsg", "更新开户信息失败");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息修改成功:android" + json.toString());
					response.getWriter().write(json.toString());
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "商户信息修改失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("商户信息修改失败ios:" + json.toString());
			response.getWriter().write(json.toString());
		}
	}

	/**
	 * @param request
	 * @param response
	 *            app2.0.0
	 * @throws IOException
	 *             审核状态刷新 安卓端
	 */
	public void querystatusA(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		HashMap hashMap = new HashMap();
		try {
			String shopperid = request.getParameter("shopperid") == null ? "": request.getParameter("shopperid");
			B2cShopperbiTemp shopper = merchantregservice.findbyshopperid(shopperid);
			if (shopper != null) {
				if (Constants.STATUS0.equals(shopper.getIfvalid().toString())) {
					hashMap.put("name", shopper.getName());
					hashMap.put("scompany", shopper.getScompany());
					hashMap.put("status", "3");
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "商户信息未审核");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息未审核android" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				
				if (Constants.STATUS1.equals(shopper.getIfvalid().toString())&&(Constants.STATUS0.equals(shopper.getRecheckmerchantflag().toString()))) {
					hashMap.put("name", shopper.getName());
					hashMap.put("scompany", shopper.getScompany());
					hashMap.put("status", "3");
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "商户信息未审核");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息未审核android" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}

				if (Constants.STATUS1.equals(shopper.getRecheckmerchantflag().toString())) {
					B2cDict bankname=this.merchantregservice.findBankName(shopper.getAccountbankdictval().toString());
					hashMap.put("status", "0");
					hashMap.put("name", shopper.getName());
					hashMap.put("scompany", shopper.getScompany());
					hashMap.put("bankNo", shopper.getAccountbankno());
					hashMap.put("idNo", shopper.getIDNo());
					hashMap.put("shopperType", shopper.getMerchantType());
					//新增返回值
					hashMap.put("bankname", bankname==null?"":bankname.getDict());
					hashMap.put("cardprovince", shopper.getAccountbankprov());
					hashMap.put("cardcity", shopper.getAccountBankCity());
					hashMap.put("branchBankName", shopper.getAccountbankname());
					hashMap.put("openT+0", shopper.getIsSupportT0());
					hashMap.put("t0Fee",shopper.getT0fee());
					hashMap.put("t0fixedamount",shopper.getT0fixedamount());
					hashMap.put("t0maxamount",shopper.getT0maxamount());
					hashMap.put("t0minamount",shopper.getT0minamount());
					
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "商户信息审核已通过");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息审核已通过" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				if (Constants.STATUS2.equals(shopper.getIfvalid().toString())) {
					hashMap.put("name", shopper.getName());
					hashMap.put("scompany", shopper.getScompany());
					hashMap.put("status", "2");
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg","商户信息审核不通过：" + shopper.getExamineresullt());
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息审核不通过android" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				if (Constants.STATUS2.equals(shopper.getRecheckmerchantflag().toString())) {
					hashMap.put("name", shopper.getName());
					hashMap.put("scompany", shopper.getScompany());
					hashMap.put("status", "2");
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg","商户信息审核不通过：" + shopper.getRecheckmerchantremark());
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息审核不通过android" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				
			} else {

				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "商户为空");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("查询失败android:" + json.toString());
				response.getWriter().write(json.toString());
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "查询失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("查询失败android:" + json.toString());
			response.getWriter().write(json.toString());
		}

	}
 
	/**审核状态刷新 ios端
	 * @param request
	 * @param response
	 *            app2.0.0
	 * @throws IOException
	 *             
	 */
	public void querystatusI(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		HashMap hashMap = new HashMap();
		try {
			String shopperid = request.getParameter("shopperid") == null ? "": request.getParameter("shopperid");
			B2cShopperbiTemp shopper = merchantregservice.findbyshopperid(shopperid);
			if (shopper != null) {
				if (Constants.STATUS0.equals(shopper.getIfvalid().toString())) {
					hashMap.put("name", shopper.getName());
					hashMap.put("scompany", shopper.getScompany());
					hashMap.put("status", "3");
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "商户信息未审核");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息未审核ios" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				
				if (Constants.STATUS1.equals(shopper.getIfvalid().toString())&&(Constants.STATUS0.equals(shopper.getRecheckmerchantflag().toString()))) {
                    //只要是复审未通过都属于为审核
					hashMap.put("name", shopper.getName());
					hashMap.put("scompany", shopper.getScompany());
					B2cDict bankname=this.merchantregservice.findBankName(shopper.getAccountbankdictval().toString());
					

					hashMap.put("status", "3");
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "商户信息未审核");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息未审核ios" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}

				if (Constants.STATUS1.equals(shopper.getRecheckmerchantflag().toString())) {

					B2cDict bankname=this.merchantregservice.findBankName(shopper.getAccountbankdictval().toString());
					hashMap.put("status", "0");
					hashMap.put("name", shopper.getName());
					hashMap.put("scompany", shopper.getScompany());
					hashMap.put("bankNo", shopper.getAccountbankno());
					hashMap.put("idNo", shopper.getIDNo());
					hashMap.put("shopperType", shopper.getMerchantType());
					//新增返回值
					hashMap.put("bankname", bankname==null?"":bankname.getDict());
					hashMap.put("cardprovince", shopper.getAccountbankprov());
					hashMap.put("cardcity", shopper.getAccountBankCity());
					hashMap.put("branchBankName", shopper.getAccountbankname());
					hashMap.put("openT+0", shopper.getIsSupportT0());
					hashMap.put("t0Fee",shopper.getT0fee());
					hashMap.put("t0fixedamount",shopper.getT0fixedamount());
					hashMap.put("t0maxamount",shopper.getT0maxamount());
					hashMap.put("t0minamount",shopper.getT0minamount());
					
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "商户信息审核已通过");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息审核已通过" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				if (Constants.STATUS2.equals(shopper.getIfvalid().toString())) {
					hashMap.put("name", shopper.getName());
					hashMap.put("scompany", shopper.getScompany());
					hashMap.put("status", "2");
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg","商户信息审核不通过：" + shopper.getExamineresullt());
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息审核不通过ios" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				if (Constants.STATUS2.equals(shopper.getRecheckmerchantflag().toString())) {
					hashMap.put("name", shopper.getName());
					hashMap.put("scompany", shopper.getScompany());
					hashMap.put("status", "2");
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg","商户信息审核不通过：" + shopper.getRecheckmerchantremark());
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("商户信息审核不通过ios" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}

				
			} else {

				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "商户为空");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("查询失败ios:" + json.toString());
				response.getWriter().write(json.toString());
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "查询失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("查询失败android:" + json.toString());
			response.getWriter().write(json.toString());
		}

	}

	

	/**
	 * 转化商户类型
	 *  2： 商户 S
	 * @param merchantType
	 * @return
	 */
	private String getType(String merchantType) {
		String type = "";
		if (Constants.CON_NO.equals(merchantType)) {
			type = Constants.TYPE_P;
		} else if(Constants.CON_SH.equals(merchantType)){
            type = Constants.TYPE_S;
        } else {
			type = Constants.TYPE_C;
		}
		return type;
	}

	public String getPosShopperId(String area, String mcc) throws Exception {
		String organization = "800";
		String areacold = "";
		if (area.length() > 4) {
			areacold = area.substring(0, 4);
		} else {
			areacold = area;
		}
		String mcccold = "";
		if (mcc.length() == 1) {
			mcccold = "000" + mcc;
		} else {
			mcccold = "00" + mcc;
		}
		String merchantRadom = RandomStringUtils.randomNumeric(4);
		String posMerchantId = organization + areacold + mcccold
				+ merchantRadom;
		B2cShopperbiTemp b2cShopperbi = merchantregservice
				.queryShopPerbi(posMerchantId);
		if (b2cShopperbi != null) {
			return getPosShopperId(area, mcc);
		}
		return posMerchantId;
	}

	
	@RequestMapping(params = "method=ajaxtelid")
	public void ajaxtelid(HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		Map hashMap = new HashMap();
		try {
			String tel =request.getParameter("tel");
			String sid =request.getParameter("sid");
			B2cShopperbiTemp shoppertel = this.merchantregservice.findbytel(tel);
			B2cShopperbiTemp shoppersid = merchantregservice.findbysid(sid);
			 String flag=checkTelSid(tel,sid);
			 if(tel.isEmpty()&&sid.isEmpty()){
				 hashMap.put("rspCode", "2222");
					hashMap.put("rspMsg", "出错");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("出错:" + json.toString());
					response.getWriter().write(json.toString());
					return;
			 }
			 
			 if (shoppertel == null&&shoppersid == null && (Constants.SUCCESS_CODE.equals(flag))) {
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "该手机号码和身份证未注册过可以使用");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("该手机号码和身份证未注册过可以使用:" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}else  if(shoppertel != null){
					hashMap.put("rspCode", "1111");
					hashMap.put("rspMsg", "该手机号码存在");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("该手机号码存在:" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}else if(shoppersid!=null){
					hashMap.put("rspCode", "3333");
					hashMap.put("rspMsg", "身份证存在");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("身份证存在:" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}else{
					hashMap.put("rspCode", "4444");
					hashMap.put("rspMsg", "身份证号码和手机号验证失败");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("身份证号码和手机号验证失败（银生宝）:" + json.toString());
					response.getWriter().write(json.toString());
				}

		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "出错");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("出错:" + json.toString());
			response.getWriter().write(json.toString());
		}

	}
	
	public String checkTelSid(String stel, String sid) throws Exception {
		HashMap hashmap = new HashMap();
		Date dates = new Date();
		String mradom = RandomStringUtils.randomNumeric(15);
		String orderId = DateUtil.getTypeDate(dates, "yyyyMMddhhmmss") + mradom;
		String orderTime = DateUtil.getTypeDate(dates, "yyyyMMddhhmmss");
		hashmap.put("mobile", stel);
		hashmap.put("idNum", sid);
		hashmap.put("orderId", orderId);
		hashmap.put("orderTime", orderTime);
		log.info("验证手机号和身份证是否在银生宝存在：" + ConstantsEnv.CHECKTELSID	+ hashmap.toString());
		Map resultMap = HttpClientUtils.postJsonRequestMap(ConstantsEnv.CHECKTELSID, hashmap, Map.class);
		log.info("验证手机号和身份证是否在银生宝存在返回码:" + resultMap);
		JSONObject ob = JSONObject.fromObject(resultMap);
		String rspCode = (String) ob.get("rspCode");
		return rspCode;
	}

	
	
	
	
	
	/**
	 * @param request
	 * @param response
	 * @throws IOException
	 *            结算银行卡信息修改Android端
	 * 
	 */
	public void updatebankA(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		HashMap hashMap = new HashMap();
		try {
			String shopperid = request.getParameter("shopperid");
			String bankCard = request.getParameter("bankCard");// 结算卡号
			String bankName = request.getParameter("bankName");// 开户银行
			String branchBankName = URLDecoder.decode(request.getParameter("branchBankName"), "UTF-8");// 支行名称
			String cardCity = request.getParameter("cardCity");
			String cardProvince = request.getParameter("cardProvince");

			// 根据商户号得到shopper对象
			B2cShopperbiTemp shopper = this.merchantregservice.findbyshopperid(shopperid);
			if (shopper == null) {
				hashMap.put("rspCode", "2222");
				hashMap.put("rspMsg", "结算银行卡信息修改失败");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("结算银行卡信息修改失败android:" + json.toString());
				response.getWriter().write(json.toString());
			} else {
				shopper.setAccountbankdictval(bankName);
				shopper.setAccountbankname(branchBankName);
				shopper.setAccountbankno(bankCard);
				shopper.setRecheckaccountflag(Constants.STATUS0);
				shopper.setOpencheckstatus(new Short(Constants.STATUS0));
				Area area1 = merchantregservice.findbyareaid(cardProvince,cardCity);
				if (area1 != null) {
					shopper.setAccountBankCity(area1.getCityname());
					shopper.setAccountBankCityCode(area1.getCity());
					shopper.setAccountbankprov(area1.getProvincialname());
					shopper.setAccountBankProvCode(area1.getProvincial());
				}
				this.merchantregservice.updateB2cShopperbiTemp(shopper);
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "结算银行卡信息修改成功");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("结算银行卡信息修改成功:android" + json.toString());
				response.getWriter().write(json.toString());

			}

		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "结算银行卡信息修改失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("结算银行卡信息修改失败android:" + json.toString());
			response.getWriter().write(json.toString());
		}
	}
	
	
	/**
	 * @param request
	 * @param response
	 * @throws IOException
	 *            结算银行卡信息修改IOS端
	 * 
	 */
	public void updatebankI(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		HashMap hashMap = new HashMap();
		try {
			String shopperid = request.getParameter("shopperid");
			String bankCard = request.getParameter("bankCard");// 结算卡号
			String bankName = request.getParameter("bankName");// 开户银行
			String branchBankName = URLDecoder.decode(request.getParameter("branchBankName"), "UTF-8");// 支行名称
			String cardCity = request.getParameter("cardCity");
			String cardProvince = request.getParameter("cardProvince");

			// 根据商户号得到shopper对象
			B2cShopperbiTemp shopper = this.merchantregservice.findbyshopperid(shopperid);
			if (shopper == null) {
				hashMap.put("rspCode", "2222");
				hashMap.put("rspMsg", "结算银行卡信息修改失败");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("结算银行卡信息修改失败IOS:" + json.toString());
				response.getWriter().write(json.toString());
			} else {
				shopper.setAccountbankdictval(bankName);
				shopper.setAccountbankname(branchBankName);
				shopper.setAccountbankno(bankCard);
				shopper.setRecheckaccountflag(Constants.STATUS0);
				shopper.setOpencheckstatus(new Short(Constants.STATUS0));
				Area area1 = merchantregservice.findbyareaid(cardProvince,cardCity);
				if (area1 != null) {
					shopper.setAccountBankCity(area1.getCityname());
					shopper.setAccountBankCityCode(area1.getCity());
					shopper.setAccountbankprov(area1.getProvincialname());
					shopper.setAccountBankProvCode(area1.getProvincial());
				}
				this.merchantregservice.updateB2cShopperbiTemp(shopper);
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "结算银行卡信息修改成功");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("结算银行卡信息修改成功:IOS" + json.toString());
				response.getWriter().write(json.toString());

			}

		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "结算银行卡信息修改失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("结算银行卡信息修改失败IOS:" + json.toString());
			response.getWriter().write(json.toString());
		}
	}
	
	
	
	/**
	 * @param request
	 * @param response
	 * @throws IOException
	 *            结算银行卡信息查询IOS端
	 * 
	 */
	public void querybankI(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		HashMap hashMap = new HashMap();
		try {
			String shopperid = request.getParameter("shopperid");
			// 根据商户号得到shopper对象
			B2cShopperbiTemp shopper = this.merchantregservice.findbyshopperid(shopperid);
			if (shopper == null) {
				hashMap.put("rspCode", "2222");
				hashMap.put("rspMsg", "查询失败");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("查询失败IOS:" + json.toString());
				response.getWriter().write(json.toString());
				return;
			} else {
				String bankstatus=shopper.getOpencheckstatus().toString();
				SimpleDateFormat sf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String date=sf.format(shopper.getBankUpdateDate());
				if(shopper.getBankUpdateDate()!=null&& Constants.STATUS0.equals(bankstatus)){
					
					hashMap.put("updateDate", date);
					hashMap.put("status","0");
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "查询成功:未审核");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("查询成功:IOS" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}else if(shopper.getBankUpdateDate()!=null&& Constants.STATUS0.equals(shopper.getRecheckaccountflag())){
					hashMap.put("updateDate", date);
					hashMap.put("status","0");
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "查询成功：未审核");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("查询成功:IOS" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}else if(shopper.getBankUpdateDate()!=null&& Constants.STATUS2.equals(shopper.getRecheckaccountflag())){
					hashMap.put("updateDate", date);
					hashMap.put("result", shopper.getRecheckaccountremark());
					hashMap.put("status","2");
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "查询成功：审核不通过");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("查询成功:IOS" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}else if(shopper.getBankUpdateDate()==null){
					hashMap.put("rspCode", "0000");
					hashMap.put("status", "3");
					hashMap.put("rspMsg", "查询成功:未修改过");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("查询成功:IOS" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "查询失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("失败IOS:" + json.toString());
			response.getWriter().write(json.toString());
		}
	}

	
	
	/**
	 * @param request
	 * @param response
	 * @throws IOException
	 *            结算银行卡信息查询IOS端
	 * 
	 */
	public void querybankA(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		HashMap hashMap = new HashMap();
		try {
			String shopperid = request.getParameter("shopperid");

			// 根据商户号得到shopper对象
			B2cShopperbiTemp shopper = this.merchantregservice.findbyshopperid(shopperid);
			if (shopper == null) {
				hashMap.put("rspCode", "2222");
				hashMap.put("rspMsg", "查询失败");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("查询失败Android:" + json.toString());
				response.getWriter().write(json.toString());
				return;
			} else {
				String bankstatus=shopper.getOpencheckstatus().toString();
				SimpleDateFormat sf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String date=sf.format(shopper.getBankUpdateDate());
				if(shopper.getBankUpdateDate()!=null&& Constants.STATUS0.equals(bankstatus)){
					
					hashMap.put("updateDate", date);
					hashMap.put("status","0");
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "查询成功:未审核");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("查询成功:Android" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}else if(shopper.getBankUpdateDate()!=null&& Constants.STATUS0.equals(shopper.getRecheckaccountflag())){
					hashMap.put("updateDate", date);
					hashMap.put("status","0");
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "查询成功：未审核");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("查询成功:Android" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}else if(shopper.getBankUpdateDate()!=null&& Constants.STATUS2.equals(shopper.getRecheckaccountflag())){
					hashMap.put("updateDate", date);
					hashMap.put("result", shopper.getRecheckaccountremark());
					hashMap.put("status","2");
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "查询成功：审核不通过");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("查询成功:Android" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}else if(shopper.getBankUpdateDate()==null){
					hashMap.put("rspCode", "0000");
					hashMap.put("status", "3");
					hashMap.put("rspMsg", "查询成功:未修改过");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("查询成功:Android" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "查询失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("失败Android:" + json.toString());
			response.getWriter().write(json.toString());
		}
	}
	
	/**
	 * @param request
	 * @param response
	 * @throws IOException  查询代理商信息安卓端
	 */
	public void queryagentA(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		HashMap hashMap=new HashMap();
		try{
			String shopperid = request.getParameter("shopperid");
			// 根据商户号得到shopper对象
			B2cShopperbiTemp shopper = this.merchantregservice.findbyshopperid(shopperid);
			if (shopper == null) {
				hashMap.put("rspCode", "2222");
				hashMap.put("rspMsg", "查询失败");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("查询失败Android:" + json.toString());
				response.getWriter().write(json.toString());
				return;
			} else {
				long agentid=shopper.getShopperidP();
				Agent agent=this.merchantregservice.searchAgent(agentid);
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "查询成功");
				hashMap.put("scompany",agent.getScompany() );
				hashMap.put("tel", agent.getStel());
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("查询成功Android:" + json.toString());
				response.getWriter().write(json.toString());
				return;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "查询失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("失败Android:" + json.toString());
			response.getWriter().write(json.toString());
		}
	}
	
	
	/**
	 * @param request
	 * @param response
	 * @throws IOException  查询代理商信息ios端
	 */
	public void queryagentI(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		HashMap hashMap=new HashMap();
		try{
			String shopperid = request.getParameter("shopperid");
			// 根据商户号得到shopper对象
			B2cShopperbiTemp shopper = this.merchantregservice.findbyshopperid(shopperid);
			if (shopper == null) {
				hashMap.put("rspCode", "2222");
				hashMap.put("rspMsg", "查询失败");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("查询失败IOS:" + json.toString());
				response.getWriter().write(json.toString());
				return;
			} else {
				long agentid=shopper.getShopperidP();
				Agent agent=this.merchantregservice.searchAgent(agentid);
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "查询成功");
				hashMap.put("scompany",agent.getScompany() );
				hashMap.put("tel", agent.getStel());
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("查询成功IOS:" + json.toString());
				response.getWriter().write(json.toString());
				return;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "查询失败");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("失败IOS	:" + json.toString());
			response.getWriter().write(json.toString());
		}
	}

	
	
	
	private void findRemoteFee(String tel){
		List list = remotefeeservice.queryfee(tel);
		if(list.size()<2){
			remotefeeservice.insert4RemoteFee(tel);
		}
	}

    /**
     * 聚合支付商户认证
     * 0.查询代理商
     * @param request
     * @param response
     */
    @RequestMapping(params = "method=queryAggAgent")
    @ResponseBody
    public Map queryAggAgent(HttpServletRequest request,HttpServletResponse response) throws Exception {
        String version = request.getParameter("version") == null ? "" : request.getParameter("version");
        Map hashMap = new HashMap();
        try {
            if(Constants.VERSION_2_4_0.equals(version)){
                //代理商编号
                String shopperidp = request.getParameter("shopperidp") == null ? "" : request.getParameter("shopperidp");
                hashMap = shopPerbiService.querySAgent(shopperidp);
            } else {
				hashMap.put(Constants.RSP_CODE,"1111");
				hashMap.put(Constants.RSP_MSG,"请升级APP!");
				log.info("登录拦截：" + hashMap);
			}
        } catch (Exception e){
            e.printStackTrace();
            hashMap.put("rspCode", Constants.RETURN_CODE_2222);
            hashMap.put("rspMsg","查询代理商异常");
        }
        return hashMap;
    }

    /**
     * 聚合支付版商户认证
     * 1.商户基本信息
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(params = "method=merchantAttestation")
    @ResponseBody
    public Map merchantAttestation(HttpServletRequest request, HttpServletResponse response) throws Exception{
        Map hashMap = new HashMap();
        String version = request.getParameter("version") == null ? "" : request.getParameter("version");
        String merchantType = request.getParameter("merchantType") == null ? "" : request.getParameter("merchantType");
        try {
            if(Constants.VERSION_2_4_0.equals(version) && Constants.TYPE_2.equals(merchantType)){
                hashMap = shopPerbiService.merchantAttA(request,response);
                log.info("商户认证基本信息:" + hashMap);
            } else {
                hashMap.put(Constants.RSP_CODE,"1111");
                hashMap.put(Constants.RSP_MSG,"请升级APP!");
                log.info("登录拦截：" + hashMap);
            }

        } catch (Exception e){
            e.printStackTrace();
            hashMap.put(Constants.RSP_CODE,Constants.RETURN_CODE_2222);
            hashMap.put(Constants.RSP_MSG,"认证基本信息异常！");
            log.info("注册出错:" + FastJson.toJson(hashMap));
        }
        return hashMap;

    }

	/**
	 * 聚合支付版商户完成认证信息后保存
	 * 商户认证最后步骤
	 * @param request
	 * @param response
	 */
	@Transactional(rollbackFor = Exception.class)
	@RequestMapping(params = "method=commMerchantInfo")
	@ResponseBody
	public Map commMerchantInfo(HttpServletRequest request,HttpServletResponse response) throws Exception{
		HashMap hashMap = new HashMap();
		try {
			hashMap = shopPerbiService.saveMerAttestationInfo(request);
		} catch (Exception e){
			e.printStackTrace();
			hashMap.put(Constants.RSP_CODE,"2222");
			hashMap.put(Constants.RSP_MSG,"保存认证信息异常");
			log.info(MessageEnum.系统异常.getText() + FastJson.toJson(hashMap));
		}
		return hashMap;
	}

    /**
     * 聚合支付版商户补件
     * 修改基本信息
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping(params = "method=updateAggShopper")
    @ResponseBody
    public Map updateAggShopper(HttpServletRequest request, HttpServletResponse response) throws Exception {
        HashMap hashMap = new HashMap();
        String version = request.getParameter("version") == null ? "" : request.getParameter("version");
        String shopperType = request.getParameter("merchantType") == null ? "" : request.getParameter("merchantType");// 商户类型
        try {
            if(Constants.VERSION_2_4_0.equals(version) && Constants.TYPE_2.equals(shopperType)){
                hashMap = shopPerbiService.updateAggShopperA(request,response);
            } else {
                updateshopper220(request, response);
            }
        } catch (Exception e){
            e.printStackTrace();
            hashMap.put("rspCode", "2222");
            hashMap.put("rspMsg", "商户信息修改失败");
            log.info("商户信息修改失败:" + FastJson.toJson(hashMap));
        }
        return hashMap;

    }

    /** 聚合支付商户信息查询
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(params = "method=queryAggShopper")
    @ResponseBody
    public Map queryAggShopper(HttpServletRequest request,HttpServletResponse response) throws Exception {
        HashMap hashMap = new HashMap();
        String version = request.getParameter("version") == null ? "" : request.getParameter("version");
        String shopperType = request.getParameter("merchantType")==null?"":request.getParameter("merchantType").trim();//商户类型0:个人 1:企业 2:商户
        try {
            if(Constants.VERSION_2_4_0.equals(version) && Constants.TYPE_2.equals(shopperType)){
                hashMap = findAggShopper(request,response);
            } else {
                queryshopper220(request, response);
            }
        } catch (Exception e){
            e.printStackTrace();
            hashMap.put("rspCode", "2222");
            hashMap.put("rspMsg", "查询失败");
            log.info("查询失败:" + FastJson.toJson(hashMap));
        }
        return hashMap;
    }

    /**
     * 聚合支付版查询商户基本信息
     * @param request
     * @param response
     * @throws Exception
     */
    public HashMap findAggShopper(HttpServletRequest request,HttpServletResponse response) throws Exception {
        HashMap hashMap = new HashMap();
        String shopperid = request.getParameter("shopperid") == null ? "": request.getParameter("shopperid");
        List<HashMap> list = merchantregservice.findByAggShopper(shopperid);
        if (list != null && list.size() > 0) {
            HashMap hashMap1 = list.get(0);
            /*//银行卡号加密
            hashMap1.put("ACCOUNT_BANK_NO", AesEncrypt.encryptAES(hashMap1.get("ACCOUNT_BANK_NO").toString(),ConstantsEnv.APP_AES_KEY));
            //身份证号加密
            hashMap1.put("ID_NO",AesEncrypt.encryptAES(hashMap1.get("ID_NO").toString(),ConstantsEnv.APP_AES_KEY));*/
            list = new ArrayList<>();
            list.add(hashMap1);
            hashMap.put("shopper", list);
            hashMap.put("rspCode", "0000");
            hashMap.put("rspMsg", "商户信息查询成功");
            log.info("商户信息查询成功" + FastJson.toJson(hashMap));
        }
        return hashMap;
    }


}
