package com.uns.dao;

import com.uns.model.B2cShopperbiShare;
import org.springframework.stereotype.Repository;

import java.util.Map;

@Repository
public interface B2cShopperbiShareMapper {

    int insert(B2cShopperbiShare record);

    int insertSelective(B2cShopperbiShare record);

    Map collectShareOper(String stel);
}