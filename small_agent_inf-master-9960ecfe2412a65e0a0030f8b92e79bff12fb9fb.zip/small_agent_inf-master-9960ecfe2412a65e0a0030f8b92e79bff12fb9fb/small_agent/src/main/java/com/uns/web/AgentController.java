package com.uns.web;

import com.uns.model.Agent;
import com.uns.service.AgentService;
import com.uns.web.form.AgentForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.*;

@Controller
@RequestMapping(value = "/agent.htm")
public class AgentController extends BaseController{
	@Autowired
	private AgentService agentservice;

	/**
	 * @param request
	 * @return
	 */
	@RequestMapping(params="method=selectAgentTree")
	public String selectAgentTree(HttpServletRequest request,AgentForm agentForm){
		Agent agents = (Agent)request.getSession().getAttribute("agent");
		String merchantId=agents.getShopperid()==null?"":agents.getShopperid().toString();
		agentForm.setShopperid(new Long(merchantId));
		List list = agentservice.searchAgentTree(agentForm);
		Map mapReturn = new HashMap();
		//循环遍历所有功能，放入map中，key为parentId_Id (上级功能Id和Id)
		for(Iterator iter = list.iterator(); iter.hasNext();){
			Agent agent = (Agent)iter.next();
			String strParentId="1";
			if(agent.getShopperidP()!=null&&!merchantId.equals(agent.getShopperid().toString())){
				strParentId=agent.getShopperidP().toString();
			}
			String strId = String.valueOf(agent.getShopperid());         //角色编号
			String strKey = strParentId + "_" + strId;
			mapReturn.put(strKey, agent);
		}
		request.setAttribute("mapTree", mapReturn);
		return "agent/agent_tree";
	}
	
	
	
	
	@RequestMapping(params="method=selectAgentTree_t")
	public String selectAgentTree_t(HttpServletRequest request){
		Agent agents = (Agent)request.getSession().getAttribute("agent");
		String merchantId=agents.getShopperid()==null?"":agents.getShopperid().toString();
		Agent agent = new Agent();
	    List list = agentservice.findAgentByMerchantId(merchantId);
	    Map mapReturn = new HashMap();
		//循环遍历所有功能，放入map中，key为parentId_Id (上级功能Id和Id)
		for(int i=0;i<list.size();i++){
			agent = (Agent)list.get(i);
			String strParentId="1";
	
			if(agent.getShopperidP()!=null&&!merchantId.equals(agent.getShopperid().toString())){
				strParentId=agent.getShopperidP().toString();
			}
			String strId = String.valueOf(agent.getShopperid());         //角色编号
			String strKey = strParentId + "_" + strId;
			mapReturn.put(strKey, agent);
		}
		request.setAttribute("mapTree", mapReturn);
	
		return "agent/agent_trees_t";
	}
	
	/**代理商修改时，查询上级代理商为临时表
	 * @param request
	 * @return
	 */
	@RequestMapping(params="method=updateAgentTreeByCode")
	public String updateAgentTreeByCode(HttpServletRequest request){
		Agent agent = (Agent)request.getSession().getAttribute("agent");
		String merchantId=agent.getShopperid()==null?"":agent.getShopperid().toString();
		String shopperId=request.getParameter("shopperId");
		
		List list = agentservice.updateAgentByMerchantId(merchantId,shopperId);
		Map mapReturn = new HashMap();
		//循环遍历所有功能，放入map中，key为parentId_Id (上级功能Id和Id)
		for(int i=0;i<list.size();i++){
			agent = (Agent)list.get(i);
			String strParentId="1";
	
			if(agent.getShopperidP()!=null&&!merchantId.equals(agent.getShopperid().toString())){
				strParentId=agent.getShopperidP().toString();
			}
			String strId = String.valueOf(agent.getShopperid());         //角色编号
			String strKey = strParentId + "_" + strId;
			mapReturn.put(strKey, agent);
		}
		request.setAttribute("mapTree", mapReturn);
		return "agent/agent_tree";
	}
	@RequestMapping(params="method=selectAgentTreeByCode")
	public String selectAgentTreeByCode(HttpServletRequest request){
		Agent agent = (Agent)request.getSession().getAttribute("agent");
		String shopperId=agent.getShopperid()==null?"":agent.getShopperid().toString();
	    List list = agentservice.findAgentByMerchantId(shopperId);
	    Map mapReturn = new HashMap();
		//循环遍历所有功能，放入map中，key为parentId_Id (上级功能Id和Id)
		for(int i=0;i<list.size();i++){
			agent = (Agent)list.get(i);
			String strParentId="1";
	
			if(agent.getShopperidP()!=null&&!shopperId.equals(agent.getShopperid().toString())){
				strParentId=agent.getShopperidP().toString();
			}
			String strId = String.valueOf(agent.getShopperid());         //角色编号
			String strKey = strParentId + "_" + strId;
			mapReturn.put(strKey, agent);
		}
		request.setAttribute("mapTree", mapReturn);
	
		return "agent/agent_trees";
	}
	
	/**
	 *  库存管理终端出库用到的树结构 
	 * @param request
	 * @return
	 */
	@RequestMapping(params="method=findAgentForTermOutTree")
	public String findAgentForTermOutTree(HttpServletRequest request){
		Agent agent = (Agent)request.getSession().getAttribute("agent");
		String shopperId=agent.getShopperid()==null?"":agent.getShopperid().toString();
	    List list = agentservice.findAgentForTermOutTree(shopperId);
	    Map mapReturn = new HashMap();
		//循环遍历所有功能，放入map中，key为parentId_Id (上级功能Id和Id)
		for(int i=0;i<list.size();i++){
			agent = (Agent)list.get(i);
			String strParentId="1";
	
			if(agent.getShopperidP()!=null&&!shopperId.equals(agent.getShopperid().toString())){
				strParentId=agent.getShopperidP().toString();
			}
			String strId = String.valueOf(agent.getShopperid());         //角色编号
			String strKey = strParentId + "_" + strId;
			mapReturn.put(strKey, agent);
		}
		request.setAttribute("mapTree", mapReturn);
		request.setAttribute("agentNo", shopperId);
	
		return "agent/agent_tree_trem";
	}
	
	@RequestMapping(params="method=findAgent")
	public String findAgent(HttpServletRequest request){
		Agent agent = (Agent)request.getSession().getAttribute("agent");
		String scompay=request.getParameter("scompay");
		String shopperId=agent.getShopperid()==null?"":agent.getShopperid().toString();
	    List list = agentservice.findAgentByScompay(shopperId,scompay.trim());
	    Map mapReturn = new HashMap();
		//循环遍历所有功能，放入map中，key为parentId_Id (上级功能Id和Id)
		for(int i=0;i<list.size();i++){
			agent = (Agent)list.get(i);
			String strParentId="1";
	
			if(agent.getShopperidP()!=null&&!shopperId.equals(agent.getShopperid().toString())){
				strParentId=agent.getShopperidP().toString();
			}
			String strId = String.valueOf(agent.getShopperid());         //角色编号
			String strKey = strParentId + "_" + strId;
			mapReturn.put(strKey, agent);
		}
		request.setAttribute("mapTree", mapReturn);
	
		return "agent/agent_trees_check";
	}
	
	
	
	@RequestMapping(params="method=selectAgentTreeByShopperId")
	public String selectAgentTreeByShopperId(HttpServletRequest request){
		Agent agent = new Agent();
		String shopperId=request.getParameter("shopperid");
	    List list = agentservice.findAgentByMerchantId(shopperId);
	    Map mapReturn = new HashMap();
		//循环遍历所有功能，放入map中，key为parentId_Id (上级功能Id和Id)
		for(int i=0;i<list.size();i++){
			agent = (Agent)list.get(i);
			String strParentId="1";
	
			if(agent.getShopperidP()!=null){
				strParentId=agent.getShopperidP().toString();
			}
			String strId = String.valueOf(agent.getShopperid());         //角色编号
			String strKey = strParentId + "_" + strId;
			mapReturn.put(strKey, agent);
		}
		request.setAttribute("mapTree", mapReturn);
	
		return "agent/agent_trees";
	}
	

	 // 获取下月第一天  
    public String getFirstDayOfNextMonth() {  
        String strFirstDay = "";  
        SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyyMMdd");  
          
        Calendar calendar = Calendar.getInstance();  
        calendar.add(Calendar.MONTH, 1);    // 加一个月  
        calendar.set(Calendar.DATE, 1);     // 设置当前月第一天  
          
        strFirstDay = sDateFormat.format(calendar.getTime());  
        return strFirstDay;  
    }  
   
}
