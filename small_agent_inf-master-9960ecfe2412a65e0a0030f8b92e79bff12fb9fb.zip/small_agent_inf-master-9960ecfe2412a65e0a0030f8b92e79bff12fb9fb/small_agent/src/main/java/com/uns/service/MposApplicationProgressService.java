package com.uns.service;

import com.uns.common.Constants;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.dao.MposApplicationProgressMapper;
import com.uns.model.MposApplicationProgress;
import com.uns.web.form.ApplicationProgressForm;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class MposApplicationProgressService {
	@Autowired
	private MposApplicationProgressMapper progressmapper;

	// 插入
	public void insertprogress(MposApplicationProgress progress) {
		progressmapper.insertSelective(progress);

	}

	public List queryall() {
		return progressmapper.queryall();
	}

	
	public MposApplicationProgress findbyid(long applicationProgressId) {
		List list = progressmapper.findbyid(applicationProgressId);
		MposApplicationProgress progress = null;
		if (list != null && list.size() > 0) {
			progress = (MposApplicationProgress) list.get(0);
		}
		return progress;
	}

	// 申请进度信息
	public List<Map<String, String>> searchApplicationProgressList(
			ApplicationProgressForm aform) {
		PageContext.initPageSize(Constants.page_size);
		return progressmapper.searchApplicationProgressList(aform);
	}

	public MposApplicationProgress findbyshopperid(String shopperid) {
		return progressmapper.findbyshopperid(shopperid);
	}

	public Map findHisTranList(String status,String shopperidP,String tPage, HttpServletRequest request) throws IllegalAccessException, InvocationTargetException {
		if (StringUtils.isEmpty(tPage) || !StringUtils.isNumeric(tPage)){
			tPage = "1";
		}
		int currentPage = Integer.valueOf(tPage);
		Page page  = new Page();

		PageContext context = PageContext.getContext();
		page.setCurrentPage(currentPage);
		BeanUtils.copyProperties(context, page);
		context.setPageSize(Constants.page_size);
		context.setPagination(true);
		
		Map<String, String> map1=new HashMap<String, String>();
		map1.put("status", status);
		map1.put("shopperidP", shopperidP);
		
		List list=progressmapper.findbystatusList( map1);
		System.out.println(context.getTotalRows());
		Map map=new HashMap();
		map.put("list", list);
		map.put("page", context.getCurrentPage());
		map.put("pages",context.getTotalPages());
		map.put("count",context.getTotalRows());
		return map;
	}

}
