package com.uns.web;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.model.Agent;
import com.uns.model.B2cTranhis;
import com.uns.service.AgentSplitFeeService;
import com.uns.service.TradeService;
import com.uns.web.form.AgentSplitFeeForm;
import org.apache.commons.beanutils.BeanUtils;
import org.codehaus.plexus.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**分润管理
 * @author peng.du
 *
 */
@Controller
@RequestMapping(value = "/agentSplitFee.htm")
public class AgentSplitFeeController extends BaseController {
	
	@Autowired
	private AgentSplitFeeService agentSplitFeeService;
	
	@Autowired
	private TradeService tradeService;
	
	
	
	
	/**主页面
	 * @param request
	 * @param response
	 * @param splitFeesForm
	 * @return
	 * @throws BusinessException
	 * @throws Exception
	 */
	@RequestMapping(params = "method=toAgentSplitManageList")
	public String toAgentSplitManageList(HttpServletRequest request, HttpServletResponse response, AgentSplitFeeForm form)
		throws BusinessException, Exception{
		
		return "agentSplit/agentSplitindex";
	
	}
	
	/**上半部分
	 * @param request
	 * @param response
	 * @param form
	 * @return
	 * @throws BusinessException
	 * @throws Exception
	 */
	@RequestMapping(params = "method=toAgentSplitsManageList")
	public String toAgentSplitsManageList(HttpServletRequest request, HttpServletResponse response, AgentSplitFeeForm form)
		throws BusinessException, Exception{
		return "agentSplit/agentSplitManage";
	}
	
	/**下半部分
	 * @param request
	 * @param response
	 * @param form
	 * @return
	 * @throws BusinessException
	 * @throws Exception
	 */
	@RequestMapping(params = "method=toAgentSplitsList")
	public String toAgentSplitsList(HttpServletRequest request, HttpServletResponse response, AgentSplitFeeForm form)
		throws BusinessException, Exception{
		
		return "agentSplit/agentSplitList";
	
	}
	/**分润历史统计信息汇总（上半部分）
	 * @param request
	 * @param response
	 * @param splitFeesForm
	 * @return
	 * @throws BusinessException
	 * @throws Exception
	 */

	@RequestMapping(params = "method=toAgentSplitIndexList")
	public String toAgentSplitIndexList(HttpServletRequest request, HttpServletResponse response, AgentSplitFeeForm form)
		throws BusinessException, Exception{
		try {
			Agent agent = (Agent)request.getSession().getAttribute("agent");
			if(agent==null)
				throw new BusinessException(ExceptionDefine.session过期请重新登录);
			
			form.setShopperids(request.getParameter("shopperids"));
			form.setSettdateStart(request.getParameter("settdateStart"));
			form.setSettdateEnd(request.getParameter("settdateEnd"));
			form.setAmountStart(request.getParameter("amountStart"));
			form.setAmountEnd(request.getParameter("amountEnd"));
			form=getForm(form);
			String agentId=agent.getShopperid()==null?"":agent.getShopperid().toString();
			form.setAgentId(agentId);
			List splitFeesList=agentSplitFeeService.getSplitFeesList(form);
			request.setAttribute("splitFeesList", splitFeesList);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.分润历史统计信息汇总);
		}
		return "agentSplit/agentSplitManage";
	
	}
	/**分润历史查询列表（下半部分）
	 * @param request
	 * @param response
	 * @param AgentSplitFeeForm
	 * @return
	 * @throws BusinessException
	 * @throws Exception
	 */
	@RequestMapping(params = "method=toAgentSplitList")
	public String toAgentSplitList(HttpServletRequest request, HttpServletResponse response, AgentSplitFeeForm form)
		throws BusinessException, Exception{
		try {
			Agent agent = (Agent)request.getSession().getAttribute("agent");
			if(agent==null)
				throw new BusinessException(ExceptionDefine.session过期请重新登录);
			String agentId=agent.getShopperid()==null?"":agent.getShopperid().toString();
			form.setShopperids(request.getParameter("shopperids"));
			form.setSettdateStart(request.getParameter("settdateStart"));
			form.setSettdateEnd(request.getParameter("settdateEnd"));
			form.setAmountStart(request.getParameter("amountStart"));
			form.setAmountEnd(request.getParameter("amountEnd"));
			AgentSplitFeeForm forms=getForm(form);
			forms.setAgentId(agentId);
			List agentSplitFeeList=agentSplitFeeService.getAgentSplitFeeList(forms);
			request.setAttribute("agentSplitFeeList", agentSplitFeeList);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.分润查询出错);
		}
		return "agentSplit/agentSplitList";
	
	}
	/**获取分页
	 * @param request
	 * @param response
	 * @param splitFeesForm
	 * @return
	 * @throws BusinessException
	 * @throws Exception
	 */
	@RequestMapping(params = "method=getExcelSbPage")
	public String getExcelSbPage(HttpServletRequest request, HttpServletResponse response, AgentSplitFeeForm form)
		throws BusinessException, Exception{
		try {
			Agent agent = (Agent)request.getSession().getAttribute("agent");
			if(agent==null)
				throw new BusinessException(ExceptionDefine.session过期请重新登录);
			String agentId=agent.getShopperid()==null?"":agent.getShopperid().toString();
			form.setAgentId(agentId);
			Page page  = new Page();
			page.setPageSize(Constants.excel_size);
			PageContext context = PageContext.getContext();
			BeanUtils.copyProperties(context, page);
			context.setPagination(true);
			agentSplitFeeService.findExcelList(form);
			BeanUtils.copyProperties(page, context);
			request.setAttribute("splitFee",form);
			request.setAttribute("page",page);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return "agentSplit/excel_sb_page";
	}
	
	/**导出分润数据
	 * @param request
	 * @param response
	 * @param splitFeesForm
	 * @return
	 * @throws BusinessException
	 * @throws Exception
	 */
	@RequestMapping(params = "method=outExcle")
	public String outExcle(HttpServletRequest request, HttpServletResponse response, AgentSplitFeeForm form)
		throws BusinessException, Exception{
		try{
			Agent agent = (Agent)request.getSession().getAttribute("agent");
			if(agent==null)
				throw new BusinessException(ExceptionDefine.session过期请重新登录);
			String agentId=agent.getShopperid()==null?"":agent.getShopperid().toString();
			form.setAgentId(agentId);
			String tPage = request.getParameter("page");
			if (StringUtils.isEmpty(tPage) || !StringUtils.isNumeric(tPage)){
				tPage = "1";
			}
			int currentPage = Integer.valueOf(tPage);
			Page page  = new Page();
			page.setPageSize(Constants.excel_size);
			PageContext context = PageContext.getContext();
			BeanUtils.copyProperties(context, page);
			context.setPagination(true);
			context.setCurrentPage(currentPage);
			
			List splitFee = agentSplitFeeService.findExcelList(form);
			BeanUtils.copyProperties(page, context);
			request.setAttribute("page",page);
			
			response.setContentType("application/vnd.ms-excel");
			response.setHeader("content-disposition", "attachment;filename=PersonTransDetail.csv");
	        response.setCharacterEncoding("gbk");
	        
	        StringBuffer sb = new StringBuffer();
	        for(int i=0;i<splitFee.size();i++){
	        	HashMap splitFees=(HashMap)splitFee.get(i);
	        	sb.append(splitFees.get("AGENTID")==null?",":splitFees.get("AGENTID").toString()+"\t,");
	        	sb.append(splitFees.get("SCOMPANY")==null?",":splitFees.get("SCOMPANY").toString()+"\t,");
	        	sb.append(splitFees.get("SETTDATE")==null?",":splitFees.get("SETTDATE").toString()+"\t,");
	        	sb.append(splitFees.get("PDG")==null?",":splitFees.get("PDG").toString()+"\t,");
	        	sb.append(splitFees.get("FEE")==null?",":splitFees.get("FEE").toString()+"\t,");
	        	sb.append(splitFees.get("BFEE")==null?",":splitFees.get("BFEE").toString()+"\t,");
	        	sb.append(splitFees.get("SUMFEE")==null?",":splitFees.get("SUMFEE")+"\t,");
				sb.append("\n");
			}
	        response.getWriter().println("代理商编号,代理商名称,分润日期,手续费(元),本期分润金额(元),上期未分润金额(元),本期分润总额  ");
	        response.getWriter().println(sb.toString());
		}catch (Exception e) {
			e.printStackTrace();
		}
        return null;
	}
	
	/**查看代理商交易列表
	 * @param request
	 * @param response
	 * @param form
	 * @return
	 * @throws BusinessException
	 * @throws Exception
	 */
	@RequestMapping(params = "method=getTradeSbViewList")
	public String getTradeSbViewList(HttpServletRequest request, HttpServletResponse response, AgentSplitFeeForm form)
		throws BusinessException, Exception{
		try{
			String agengId=request.getParameter("agentid");
			if(StringUtils.isNotEmpty(agengId)){
				List<B2cTranhis> trades = agentSplitFeeService.findTradeSbList(agengId);
				request.setAttribute("agentid",agengId);
				request.setAttribute("trades", trades);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return "agentSplit/tradelist";
	}
	
	/**
	 * 获取商户交易流水详情
	 * @param request
	 * @param tradeForm
	 * @return
	 * @throws BusinessException
	 * @throws Exception
	 */
	@RequestMapping(params = "method=getTradeSbView")
	public String getTradeSbView(HttpServletRequest request,String tranid) 
		throws BusinessException, Exception{
		
		Map trade = tradeService.getTradeView(tranid);
		request.setAttribute("trade", trade);
		return "agentSplit/trade_sb_view";
	}
	
	/**处理form... 
	 * @param form
	 * @return
	 */
	public AgentSplitFeeForm getForm(AgentSplitFeeForm form){
		AgentSplitFeeForm feeForm=new AgentSplitFeeForm();
		feeForm.setShopperids(getNumber(form.getShopperids()));
		feeForm.setAmountStart(getFormtNumber(getNumber(form.getAmountStart()),100));
		feeForm.setAmountEnd(getFormtNumber(getNumber(form.getAmountEnd()),100));
		feeForm.setSettdateStart(form.getSettdateStart());
		feeForm.setSettdateEnd(form.getSettdateEnd());
		return feeForm;
	}
	//字符串格式化成数字
	public String getNumber(String val){
		String number="";
		if(StringUtils.isNotEmpty(val)){
			boolean b = val.trim().matches("^[-+]?(([0-9]+)([.]([0-9]+))?|([.]([0-9]+))?)$");
			if(b){
				number=val.trim();
			}
		}
		return number;
	}
	//将金额放大到原始
	public String getFormtNumber(String val,int number){
		String numval="";
		if(StringUtils.isNotEmpty(val)){
			numval=Double.valueOf(val)*number+"";
		}
		return numval;
	}
}
