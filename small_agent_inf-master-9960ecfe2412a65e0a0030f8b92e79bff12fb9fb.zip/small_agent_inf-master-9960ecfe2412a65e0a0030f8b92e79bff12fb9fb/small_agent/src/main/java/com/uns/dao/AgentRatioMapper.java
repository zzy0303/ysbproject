package com.uns.dao;

import com.uns.model.AgentRatio;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface AgentRatioMapper {

	List<Map> isRatioTmp(Long shopperid);

	List<Map> isRatio(Long shopperid);

	List<AgentRatio> findAgentRatioTmpByAmid(Map map);

	List<AgentRatio> findAgentRatio(Map map);
	
	
}
