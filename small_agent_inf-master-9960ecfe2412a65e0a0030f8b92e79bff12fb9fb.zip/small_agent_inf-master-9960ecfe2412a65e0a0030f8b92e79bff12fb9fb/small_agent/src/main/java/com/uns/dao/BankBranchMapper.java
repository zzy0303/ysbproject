package com.uns.dao;

import com.uns.model.BankBranch;
import com.uns.model.SupportBankForm;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface BankBranchMapper {

    int insert(BankBranch record);

    int insertSelective(BankBranch record);
    
    List searchBankBranch(Map map);
    
    List<SupportBankForm> querySupportBankList();

}