package com.uns.model;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by Administrator on 2017/2/27.
 */
public class B2cCreditCount implements Serializable {
    private Long id;
    private String shopperId;
    private String phoneType;
    private Date createDate;
    private String cardlifetype;
    private String projectType;

    public String getProjectType() {
        return projectType;
    }

    public void setProjectType(String projectType) {
        this.projectType = projectType;
    }

    public String getCardlifetype() {
		return cardlifetype;
	}

	public void setCardlifetype(String cardlifetype) {
		this.cardlifetype = cardlifetype;
	}

	public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getShopperId() {
        return shopperId;
    }

    public void setShopperId(String shopperId) {
        this.shopperId = shopperId;
    }

    public String getPhoneType() {
        return phoneType;
    }

    public void setPhoneType(String phoneType) {
        this.phoneType = phoneType;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
}
