package com.uns.dao;

import com.uns.model.BackupsShopperInformation;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

@Repository
public interface BackupsShopperInformationMapper extends BaseMapper<Object> {


    int insert(BackupsShopperInformation record);

    int insertSelective(BackupsShopperInformation record);
    
    void updateByShopperId(BackupsShopperInformation shopper);
    
    BackupsShopperInformation findByshopperid(BigDecimal shopperid);
}