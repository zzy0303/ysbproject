package com.uns.common.filter;

import com.uns.common.page.PageContext;
import org.apache.commons.lang3.StringUtils;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;


public class PageFilter implements Filter {

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest hRequest = (HttpServletRequest) request;
		String uri = hRequest.getRequestURL().toString();
		String param=hRequest.getQueryString();
				
		if(uri.toLowerCase().endsWith(".jsp")){
		chain.doFilter(request, response);
		return;
		}
		if(param!=null&&param.toLowerCase().indexOf("list")<0){
			PageContext.removeContext();
			chain.doFilter(request, response);
			return;
		}
		if(!uri.equals(PageContext.getLastUrl())){
			PageContext.removeContext();
		}
		String pagec = hRequest.getParameter("page"); 
		String pageSize = hRequest.getParameter("pageSize");
		String sortField = hRequest.getParameter("sort");
		pageSize = StringUtils.isEmpty(pageSize)?"1":pageSize; 
		PageContext.setLastUrl(uri);
		PageContext page = PageContext.getContext();
		
		if(null == pagec){
			page.setCurrentPage(1);
		}else{
			page.setCurrentPage(Integer.parseInt(pagec));
		}
		page.setPageSize(Integer.parseInt(pageSize));
		page.setPagination(true);
		
		if(sortField != null && !"".equals(sortField))
			PageContext.initSort(sortField);
		
		request.setAttribute("page",page);
		chain.doFilter(request, response);		
	}

	@Override
	public void init(FilterConfig config) throws ServletException {
		// TODO Auto-generated method stub
		
	}

}
