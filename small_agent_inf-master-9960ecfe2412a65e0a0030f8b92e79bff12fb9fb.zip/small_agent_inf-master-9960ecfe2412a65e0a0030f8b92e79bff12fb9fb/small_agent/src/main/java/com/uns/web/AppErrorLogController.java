package com.uns.web;

import com.uns.common.ConstantsEnv;
import com.uns.common.exception.BusinessException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@Controller
@RequestMapping(value = "/appErrorLog.htm")
public class AppErrorLogController extends BaseController {
	SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
	/**
	 * 充值记录查询
	 * 
	 * @throws BusinessException
	 * @throws ParseException
	 */
	@RequestMapping(params = "method=uploadErrorlog")
	public void uploadErrorlog(String data) {
		if(data==null){
			return;
		}
		ByteArrayInputStream is = null;
		FileOutputStream fos =null;
		try {
			is = new ByteArrayInputStream(data.getBytes());
			fos = new FileOutputStream(ConstantsEnv.APP_ERRORLOG_PATH + sf.format(new Date()) + ".log",true);
			int temp = 0;
			while ((temp = is.read()) != (-1)) {
				fos.write(temp);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally{
			try {
				fos.flush();
				is.close();
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
	}
}
