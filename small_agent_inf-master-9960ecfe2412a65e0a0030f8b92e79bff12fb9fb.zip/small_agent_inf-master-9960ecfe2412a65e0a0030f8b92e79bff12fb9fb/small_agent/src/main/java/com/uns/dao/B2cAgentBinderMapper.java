package com.uns.dao;

import com.uns.model.B2cAgentBinder;
import com.uns.web.form.TerminalForm;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public interface B2cAgentBinderMapper {
	List selectAgentBinderList(TerminalForm form);

    int insert(B2cAgentBinder record);

    int insertSelective(B2cAgentBinder record);
    
    int selectAgentBinderCount();
    
    int updateAgentBinder(Map map);
    
    int deleteAgentBinder(Map map);
    
    int delectAgentBinderBytermId(String Terminalid);
    
    B2cAgentBinder selectAgentBinderByid(String terminalid);
    
    int updateAgentBinder(TerminalForm form);
    
    B2cAgentBinder selectAgentnoByTermNo(String termNum);
    //查询代理商下还未绑定的终端
    List<HashMap> selectBinderNum(String agentNo);
}