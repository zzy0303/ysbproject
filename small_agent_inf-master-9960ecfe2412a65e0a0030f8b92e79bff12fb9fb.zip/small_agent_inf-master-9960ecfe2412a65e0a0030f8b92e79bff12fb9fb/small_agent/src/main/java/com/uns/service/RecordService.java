package com.uns.service;

import com.alibaba.dubbo.common.serialize.support.json.JsonObjectInput;
import com.alibaba.fastjson.JSONObject;
import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.exception.BusinessException;
import com.uns.common.myenum.MessageEnum;
import com.uns.common.page.PageContext;
import com.uns.dao.B2cShopperbiMapper;
import com.uns.dao.B2cShopperbiTempMapper;
import com.uns.dao.OrderInfoMapper;
import com.uns.model.B2cShopperbi;
import com.uns.util.FastJson;
import com.uns.util.HttpClientUtils;
import com.uns.web.form.AgentRechargeForm;
import org.apache.shiro.crypto.hash.Hash;
import org.jpos.util.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class RecordService {
	@Autowired
	private B2cShopperbiMapper b2cShopperbiMapper;

	@Autowired
	private B2cShopperbiTempMapper b2cShopperbiTempMapper;
	
	@Autowired
	public OrderInfoMapper orderInfoMapper;

	private Logger log = LoggerFactory.getLogger(RecordService.class);
	/**
	 * 根据商户号查询保理账户ID
	 * @return
	 */
	public B2cShopperbi findFactoringNoByShopperid(String shopperid){
		return b2cShopperbiMapper.findFactoringNoByShopperid(shopperid);
	}
	
	/**
	 * 查询充值记录
	 * @param param
	 * @return
	 */
	public List<Map<String,String>> selectRechargeList(Map<String, Object> param){
		PageContext.initPageSize(20);
		return orderInfoMapper.selectRechargeList(param);
	}
	/**
	 * 刷卡总计
	 * @param param
	 * @return
	 */
	public Map selectRechargeListSum(Map<String, Object> param){
		return orderInfoMapper.selectRechargeListSum(param);
	}
	
	/**
	 * 查询提现记录
	 * @param param
	 * @return
	 */
	public List<Map<String,String>> selectWithdrawList(Map<String, Object> param){
		PageContext.initPageSize(20);
		return orderInfoMapper.selectWithdrawList(param);
	}
	/**
	 * T0提现总计
	 * @param param
	 * @return
	 */
	public Map selectWithdrawListSum(Map<String, Object> param){
		return orderInfoMapper.selectWithdrawListSum(param);
	}
	
	/**
	 * 查询提现记录
	 * @param param
	 * @return
	 */
	public List<Map<String,String>> excelWithdrawList(Map<String, Object> param){
		PageContext.initPageSize(Constants.excel_size);
		return orderInfoMapper.selectWithdrawList(param);
	}
    
	/**
	 * 通过商户号查询银生宝找好
	 * @param shopperidp
	 * @return
	 */
    public List<String> selectYsbno(Long shopperidp){
    	return orderInfoMapper.selectYsbno(shopperidp);
    }  
    
    /**
     * 充值记录信息下载
     * @param arForm
     * @return
     */
    public List findRechargePageList(AgentRechargeForm arForm){
		PageContext.initPageSize(Constants.excel_size);
		List list=orderInfoMapper.findRechargePageList(arForm);
		if(list!=null&&list.size()!=0){
			return list;
		}
    	return new ArrayList();
    }
    
    /**
     * 查询D0提现时间
     * @return
     */
    public List<Map<String,String>> selectD0Time(){
    	return orderInfoMapper.selectD0Time();
    }

	public HashMap queryShopperPayInfo(HttpServletRequest request) throws Exception {
    	HashMap hashMap = new HashMap();
		String shopperid = request.getParameter("shopperid").trim();
		B2cShopperbi b2cShopperbi = b2cShopperbiMapper.queryByShopperid(shopperid);
		if (null == b2cShopperbi){
			hashMap.put("rspCode", MessageEnum.商户不存在.getCode());
			hashMap.put("rspMsg", MessageEnum.商户不存在.getText());
			return hashMap;
		}
		Map param = new HashMap();
		String resultString;
		Map resultMap;
		//剩余刷卡授信额度 调用mposAccount刷卡业务平台查询
		param.put("micromerchantno", b2cShopperbi.getShopperid());
		resultString = HttpClientUtils.REpostRequestStrJson(
				ConstantsEnv.MPOS_ACCOUNT_CREDITLINES, FastJson.toJson(param));
		log.info("查询刷卡授信额度返回参数：{}", resultString);
		resultMap = FastJson.fromJson(resultString);
		if (null == resultMap || !Constants.SUCCESS_CODE.equals(resultMap.get("code"))){
			throw new Exception(MessageEnum.系统异常.getText());
		}
		hashMap.put("cardAmount", resultMap.get("creditLines"));
		hashMap.put("overCardAmount", resultMap.get("remaining"));

		//剩余扫码授信额度 调用mposQrcode扫码业务平台查询
		param = new HashMap();
		param.put("smallMerchNo", b2cShopperbi.getShopperid());
		resultString = HttpClientUtils.REpostRequestStrJson(
				ConstantsEnv.MPOS_QRCODE_CREDITLINES, FastJson.toJson(param));
		log.info("查询扫码授信额度返回参数：{}", resultString);
		resultMap = FastJson.fromJson(resultString);
		if (null == resultMap || !Constants.SUCCESS_CODE.equals(resultMap.get("code"))){
			throw new Exception(MessageEnum.系统异常.getText());
		}

		hashMap.put("codeAmount", resultMap.get("creditLines"));
		hashMap.put("overCodeAmount", resultMap.get("remaining"));

		hashMap.put("rspCode", MessageEnum.成功.getCode());
		hashMap.put("rspMsg", MessageEnum.成功.getText());
		hashMap.put("name", b2cShopperbi.getScompany());
		hashMap.put("tel", b2cShopperbi.getStel());


		hashMap.put("settleType", b2cShopperbi.getSettleType().toString());
		hashMap.put("outRevenue", b2cShopperbi.getIsexternalrevenue() == null ? "0" : b2cShopperbi.getIsexternalrevenue().toString());
		return hashMap;
	}

	public HashMap editShopperPayInfo(HttpServletRequest request) throws Exception {
    	HashMap hashMap = new HashMap();
    	String shopperid = request.getParameter("shopperid").trim();
		String settleType = request.getParameter("settleType");
		String outRevenue = request.getParameter("outRevenue");
		B2cShopperbi b2cShopperbi = b2cShopperbiMapper.queryByShopperid(shopperid);
		if (null == b2cShopperbi){
			hashMap.put("rspCode", MessageEnum.商户不存在.getCode());
			hashMap.put("rspMsg", MessageEnum.商户不存在.getText());
			return hashMap;
		}
		//调用扫码业务平台 修改固码是否快速收款、是否手续费外放
		Map param = new HashMap();
		param.put("userId", b2cShopperbi.getQrPayNo());
		param.put("isExternalRevenue",outRevenue);
		param.put("settleType", settleType);
		String resultString = HttpClientUtils.REpostRequestStrJson(
				ConstantsEnv.UPDATE_MERCHANT, FastJson.toJson(param));
		log.info("修改商户信息返回参数：{}", resultString);
		Map resultMap = FastJson.fromJson(resultString);
		if (null != resultMap && Constants.SUCCESS_CODE.equals(resultMap.get("rspCode"))){
			B2cShopperbi b2cShopperbiNew = new B2cShopperbi();
			b2cShopperbiNew.setSettleType(settleType);
			b2cShopperbiNew.setIsexternalrevenue(outRevenue);
			b2cShopperbiNew.setShopperid(Long.valueOf(shopperid));
			b2cShopperbiMapper.updateConfigByShopperid(b2cShopperbiNew);
			b2cShopperbiTempMapper.updateConfigByShopperid(b2cShopperbiNew);
		} else {
			throw new Exception(MessageEnum.系统异常.getText());
		}
		hashMap.put("rspCode", MessageEnum.成功.getCode());
		hashMap.put("rspMsg", MessageEnum.成功.getText());
		return hashMap;
	}

	public Map findCreditAmountRestoreTime() throws Exception {
    	Map<String, String> param = new HashMap();
		Map<String, String> hashMap = new HashMap();
		//查询动码固码有效期和授信额度恢复时间
		param.put("configKey", "creditAmountRestoreTime");
		log.info("查询mpos_qrcode配置请求参数：{}", FastJson.toJson(param));
		
		Map<String, Object> result = FastJson.fromJson(HttpClientUtils.REpostRequestStrJson(ConstantsEnv.HTTP_PROTOCOL + ConstantsEnv.MPOS_QRCODE_URL + ConstantsEnv.MPOS_QRCODE_QUERY_CONFIG, FastJson.toJson(param)));
		log.info("查询mpos_qrcode配置返回：{}", result.toString());
		if (result != null && Constants.SUCCESS_CODE_0000.equals(result.get("rspCode"))) {
			log.info(result.get("data").toString());
			List sysConfigs = FastJson.jsonToList(result.get("data").toString());
			log.info(sysConfigs.toString());
			JSONObject creditAmountRestoreTimeO = (JSONObject) sysConfigs.get(0);
			String creditAmountRestoreTime = FastJson.fromJson(creditAmountRestoreTimeO.toString()).get("keyValue").toString();
			log.info(creditAmountRestoreTime);
			return hashMap;
		} else {
			throw new Exception(MessageEnum.系统异常.getText());
		}
	}
}
