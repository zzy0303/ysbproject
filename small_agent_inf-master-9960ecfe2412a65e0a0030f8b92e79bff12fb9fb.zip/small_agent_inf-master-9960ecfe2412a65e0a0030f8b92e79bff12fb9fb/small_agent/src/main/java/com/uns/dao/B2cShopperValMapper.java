package com.uns.dao;

import com.uns.model.B2cShopperVal;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.Map;

@Repository
public interface B2cShopperValMapper {

	void saveShopperVal(B2cShopperVal b2cShopperVal);

	List<B2cShopperVal> queryByParam(B2cShopperVal b2cShopperVal);

	void delByParam(@Param("shopperValId") Long b2cShopperValId);

	void editByParam(B2cShopperVal b2cShopperVal);
	
	List findNoOCRVal();
}
