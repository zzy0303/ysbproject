package com.uns.util;

import javax.servlet.http.HttpServletResponse;
import java.io.*;

/**
 * 文件操作类
 * @author yang.liu01
 *
 */
public class FileOperateUtil {

	
	/**
	 * 下载模板
	 * @param fileName
	 * @param response
	 * @return
	 */
	public String download(String fileName,HttpServletResponse response) {
		 File file= null;
		 if (fileName != null) {
	         String filePath = Thread.currentThread().getContextClassLoader()
						.getResource("").getPath()
						+ "download";
//	         String suffix =".xls";
//	         fileName+=suffix;
//	         File file = new File(realPath, fileName);//获取文件夹路径
	        
	         try {
	        	 file = new File(filePath);
		         if(!file.exists()){//判断文件夹是否创建，没有创建则创建新文件夹
		        	 file.mkdirs();
		         }
		        
		         String suffix =".xls";
		         fileName+=suffix;
		         file = new File(filePath, fileName);
		         // 创建文件
		         if (!file.exists()) {
		            file.createNewFile();
		         }
			} catch (Exception e) {
				e.printStackTrace();
			}
	        
	         
	         if (file.exists()) {
	        	 // 清空response   
	             response.reset();   
	             try {
					response.setHeader("Content-Disposition", "attachment; filename=\"" + new String(fileName.getBytes("gbk"),"iso-8859-1") + "\"");
				} catch (UnsupportedEncodingException e1) {
					e1.printStackTrace();
				}    
	             response.addHeader("Content-Length", "" + file.length());    
	             response.setContentType("application/octet-stream;charset=UTF-8");  
	             
	             byte[] buffer = new byte[1024];
	             FileInputStream fis = null;
	             BufferedInputStream bis = null;
	             try {
	                 fis = new FileInputStream(file);
	                 bis = new BufferedInputStream(fis);
	                 OutputStream os = response.getOutputStream();
	                 int i = bis.read(buffer);
	                 while (i != -1) {
	                    os.write(buffer, 0, i);
	                     i = bis.read(buffer);
	                 }
	             } catch (Exception e) {
	                // TODO: handle exception
	                e.printStackTrace();
	             } finally {
	                 if (bis != null) {
	                     try {
	                         bis.close();
	                     } catch (IOException e) {
	                         // TODO Auto-generated catch block
	                     e.printStackTrace();
	                    }
	                 }
	                 if (fis != null) {
	                     try {
	                        fis.close();
	                    } catch (IOException e) {
	                     // TODO Auto-generated catch block
	                        e.printStackTrace();
	                    }
	                 }
	             }
	         }
	     }
	     return null;
	}
}
