package com.uns.service;

import com.uns.common.Constants;
import com.uns.common.page.PageContext;
import com.uns.dao.AgentSplitBatchMapper;
import com.uns.dao.AgentSplitProfitMapper;
import com.uns.model.AgentSplitBatch;
import com.uns.web.form.SplitForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class SplitService {
	@Autowired
	private AgentSplitBatchMapper agentSplitBatchMapper;
	@Autowired
	private AgentSplitProfitMapper agentSplitProfitMapper;
	/**
	 * 查询批次信息 
	 */
	public List<Map<String,Object>> selectBatchList(SplitForm param){
		PageContext.initPageSize(20);
		return agentSplitBatchMapper.selectBatchList(param);
	}
	
	/**
	 * 查询子代理商批次信息 
	 */
	public List<Map<String,Object>> selectSubBatchList(SplitForm param){
		PageContext.initPageSize(20);
		return agentSplitBatchMapper.selectSubBatchList(param);
	}
	
	/**
	 * 查询批次详情 
	 */
	public List<Map<String,Object>> selectSplitList(SplitForm param){
		PageContext.initPageSize(20);
		return agentSplitProfitMapper.selectSplitList(param);
	}
	
	/**
	 * 下载批次信息 
	 */
	public List<Map<String,Object>> downBatchList(SplitForm param){
		PageContext.initPageSize(Constants.MAX_DOWNLOAD_SIZE);
		return agentSplitBatchMapper.selectBatchList(param);
	}
	
	/**
	 * 子代理商下载批次信息 
	 */
	public List<Map<String,Object>> downSubBatchList(SplitForm param){
		PageContext.initPageSize(Constants.MAX_DOWNLOAD_SIZE);
		return agentSplitBatchMapper.selectSubBatchList(param);
	}
	
	/**
	 * 下载批次详情 
	 */
	public List<Map<String,Object>> downSplitList(SplitForm param){
		PageContext.initPageSize(Constants.MAX_DOWNLOAD_SIZE);
		return agentSplitProfitMapper.selectSplitList(param);
	}
	
	/**
	 * 根据批次号更新批次状态 
	 */
	public void updateStatusByBatchNo(SplitForm param) throws Exception{
		agentSplitBatchMapper.updateStatusByBatchNo(param);
	}
	
	/**
	 * 查询疑议信息 
	 */
	public Map<String,Object> selectDoubt(SplitForm param){
		return agentSplitBatchMapper.selectDoubt(param);
	}
	
	/**
	 * 添加疑议并更新批次状态 
	 */
	public void insertDoubt(SplitForm param) throws Exception{
		agentSplitBatchMapper.insertDoubt(param);
		agentSplitBatchMapper.updateStatusByBatchNo(param);
	}
	
	/**
	 * 更新疑议信息 并更新批次状态
	 */
	public void updateDoubt(SplitForm param) throws Exception{
		agentSplitBatchMapper.updateDoubt(param);
		agentSplitBatchMapper.updateStatusByBatchNo(param);
	}
	
	/**
	 * 更新批次分润值
	 */
	public void updateBatch(SplitForm param) throws Exception{
		agentSplitBatchMapper.updateBatch(param);
	}
	
	/**
	 * 根据id查询批次信息 
	 */
	public AgentSplitBatch selectByPrimaryKey(SplitForm param){
		return agentSplitBatchMapper.selectByPrimaryKey(param);
	}
	
	/**
	 * 批量更新批次表状态 
	 */
	public void batchUpdate(Map<String,Object> param) throws Exception{
		agentSplitBatchMapper.batchUpdate(param);
	}

	/**
	 * 查询扫码批次信息 
	 */
	public List<Map<String, Object>> selectSmBatchList(SplitForm sform) {
		PageContext.initPageSize(20);
		return agentSplitBatchMapper.selectSmBatchList(sform);
	}

	/**
	 * 下载扫码批次信息 
	 */
	public List<Map<String,Object>> downSmBatchList(SplitForm param){
		PageContext.initPageSize(Constants.MAX_DOWNLOAD_SIZE);
		return agentSplitBatchMapper.selectSmBatchList(param);
	}
	
	/**
	 * 查询扫码批次详情 
	 */
	public List<Map<String, Object>> selectSmSplitList(SplitForm sform) {
		PageContext.initPageSize(20);
		return agentSplitProfitMapper.selectSmSplitList(sform);
	}
	
	/**
	 * 下载扫码批次详情 
	 */
	public List<Map<String,Object>> downSmSplitList(SplitForm param){
		PageContext.initPageSize(Constants.MAX_DOWNLOAD_SIZE);
		return agentSplitProfitMapper.selectSmSplitList(param);
	}
	
	/**
	 * 查询子代理商扫码批次信息 
	 */
	public List<Map<String,Object>> selectSmSubBatchList(SplitForm param){
		PageContext.initPageSize(20);
		return agentSplitBatchMapper.selectSmSubBatchList(param);
	}
	
	/**
	 * 子代理商下载扫码批次信息 
	 */
	public List<Map<String,Object>> downSmSubBatchList(SplitForm param){
		PageContext.initPageSize(Constants.MAX_DOWNLOAD_SIZE);
		return agentSplitBatchMapper.selectSmSubBatchList(param);
	}
	
	/**
	 * 扫码根据批次号更新批次状态 
	 */
	public void updateSmStatusByBatchNo(SplitForm param) throws Exception{
		agentSplitBatchMapper.updateSmStatusByBatchNo(param);
	}
	
	/**
	 * 更新批次分润值
	 */
	public void updateSmBatch(SplitForm param)throws Exception{
		agentSplitBatchMapper.updateSmBatch(param);
	}
	
	/**
	 * 批量更新批次表状态 
	 */
	public void smBatchUpdate(Map<String,Object> param)throws Exception{
		agentSplitBatchMapper.smBatchUpdate(param);
	}
	
	/**
	 * 添加疑议并更新批次状态 
	 */
	public void smInsertDoubt(SplitForm param) throws Exception{
		agentSplitBatchMapper.insertDoubt(param);
		agentSplitBatchMapper.updateSmStatusByBatchNo(param);
	}
	
	/**
	 * 更新疑议信息 并更新批次状态
	 */
	public void smUpdateDoubt(SplitForm param) throws Exception{
		agentSplitBatchMapper.updateDoubt(param);
		agentSplitBatchMapper.updateSmStatusByBatchNo(param);
	}
}
