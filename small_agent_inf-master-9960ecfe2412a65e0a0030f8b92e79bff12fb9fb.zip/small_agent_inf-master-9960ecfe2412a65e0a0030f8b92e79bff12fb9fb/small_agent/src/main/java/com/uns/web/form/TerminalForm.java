package com.uns.web.form;

import org.springframework.web.multipart.MultipartFile;

import java.util.Date;

public class TerminalForm extends ShopPerbiForm {
	private String terminalid;
	private String merchantid;
	private String num;
	private String name;
	private String time;
	private String type;
	private String flag;
	private String terminallimit;
	private String note;
	private String tertype;
	private String sdate;
	private String edate;
	private String agentscompany;
	private String scompany;
	private char status;
	private String agentid;
	private String newagentid;
	private String merchantno;
	//所属代理商编号
	private String bactchNoq;
	private String termNoBeg;
	private String termNoEnd;
	private String terminalTypeNoq;
	private String inventoryStatusq;
	private String shopperidP;
	private String startDate;
	private String endDate;
	private String upper_level_agent_no;
	
	
	//actionhistory
	private String changetype;
	private String newvest;
	private String oldvest;
	private String checkstatus;
	private String comments;
	private String oldscompany;
	private String newscompany;
	private Date createdate;
	private Date supdatedate;
	private Date eupdatedate;
	private MultipartFile bankfiles;
    private String shopperid;
    private String pnewscompany;
    private String poldscompany;
	    
	    
	public String getPnewscompany() {
		return pnewscompany;
	}
	public void setPnewscompany(String pnewscompany) {
		this.pnewscompany = pnewscompany;
	}
	public String getPoldscompany() {
		return poldscompany;
	}
	public void setPoldscompany(String poldscompany) {
		this.poldscompany = poldscompany;
	}
	public String getShopperid() {
		return shopperid;
	}
	public void setShopperid(String shopperid) {
		this.shopperid = shopperid;
	}

	public String getTerminalid() {
		return terminalid;
	}

	public void setTerminalid(String terminalid) {
		this.terminalid = terminalid;
	}

	public String getMerchantid() {
		return merchantid;
	}

	public void setMerchantid(String merchantid) {
		this.merchantid = merchantid;
	}

	public String getNum() {
		return num;
	}

	public void setNum(String num) {
		this.num = num.trim();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name.trim();
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getTerminallimit() {
		return terminallimit;
	}

	public void setTerminallimit(String terminallimit) {
		this.terminallimit = terminallimit;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getTertype() {
		return tertype;
	}

	public void setTertype(String tertype) {
		this.tertype = tertype;
	}

	public String getSdate() {
		return sdate;
	}

	public void setSdate(String sdate) {
		String temp = sdate.replaceAll("/","");
		if (temp.length() == 8) {
			temp += "000000";
		}
		this.sdate = temp;
	}

	public String getEdate() {
		return edate;
	}

	public void setEdate(String edate) {
		String temp = edate.replaceAll("/","");
		if (temp.length() == 8) {
			temp += "235959";
		}
		this.edate = temp;
	}

	public String getAgentscompany() {
		return agentscompany;
	}

	public void setAgentscompany(String agentscompany) {
		this.agentscompany = agentscompany;
	}

	public String getScompany() {
		return scompany;
	}

	public void setScompany(String scompany) {
		this.scompany = scompany;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

	public String getNewagentid() {
		return newagentid;
	}

	public void setNewagentid(String newagentid) {
		this.newagentid = newagentid;
	}

	public String getAgentid() {
		return agentid;
	}

	public void setAgentid(String agentid) {
		this.agentid = agentid;
	}

	public String getChangetype() {
		return changetype;
	}

	public void setChangetype(String changetype) {
		this.changetype = changetype;
	}

	public String getCheckstatus() {
		return checkstatus;
	}

	public void setCheckstatus(String checkstatus) {
		this.checkstatus = checkstatus;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments.trim();
	}

	public String getNewvest() {
		return newvest;
	}

	public void setNewvest(String newvest) {
		this.newvest = newvest;
	}

	public String getOldvest() {
		return oldvest;
	}

	public void setOldvest(String oldvest) {
		this.oldvest = oldvest;
	}

	public String getMerchantno() {
		return merchantno;
	}

	public void setMerchantno(String merchantno) {
		this.merchantno = merchantno.trim();
	}

	public String getOldscompany() {
		return oldscompany;
	}

	public void setOldscompany(String oldscompany) {
		this.oldscompany = oldscompany;
	}

	public String getNewscompany() {
		return newscompany;
	}

	public void setNewscompany(String newscompany) {
		this.newscompany = newscompany;
	}

	public Date getCreatedate() {
		return createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}

	public MultipartFile getBankfiles() {
		return bankfiles;
	}

	public void setBankfiles(MultipartFile bankfiles) {
		this.bankfiles = bankfiles;
	}

	public Date getSupdatedate() {
		return supdatedate;
	}

	public void setSupdatedate(Date supdatedate) {
		this.supdatedate = supdatedate;
	}

	public Date getEupdatedate() {
		return eupdatedate;
	}

	public void setEupdatedate(Date eupdatedate) {
		this.eupdatedate = eupdatedate;
	}
	public String getBactchNoq() {
		return bactchNoq;
	}
	public void setBactchNoq(String bactchNoq) {
		this.bactchNoq = bactchNoq;
	}
	
	
	
	

	public String getUpper_level_agent_no() {
		return upper_level_agent_no;
	}
	public void setUpper_level_agent_no(String upper_level_agent_no) {
		this.upper_level_agent_no = upper_level_agent_no;
	}
	public String getTermNoBeg() {
		return termNoBeg;
	}
	public void setTermNoBeg(String termNoBeg) {
		this.termNoBeg = termNoBeg;
	}
	public String getTermNoEnd() {
		return termNoEnd;
	}
	public void setTermNoEnd(String termNoEnd) {
		this.termNoEnd = termNoEnd;
	}
	public String getTerminalTypeNoq() {
		return terminalTypeNoq;
	}
	public void setTerminalTypeNoq(String terminalTypeNoq) {
		this.terminalTypeNoq = terminalTypeNoq;
	}
	public String getInventoryStatusq() {
		return inventoryStatusq;
	}
	public void setInventoryStatusq(String inventoryStatusq) {
		this.inventoryStatusq = inventoryStatusq;
	}
	public String getShopperidP() {
		return shopperidP;
	}
	public void setShopperidP(String shopperidP) {
		this.shopperidP = shopperidP;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	
	
	
	
	
	
	

}
