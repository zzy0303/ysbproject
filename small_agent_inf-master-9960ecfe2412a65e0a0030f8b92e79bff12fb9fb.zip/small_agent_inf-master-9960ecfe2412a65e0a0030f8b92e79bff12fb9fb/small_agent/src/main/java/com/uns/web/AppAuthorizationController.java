package com.uns.web;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uns.common.myenum.MessageEnum;
import com.uns.model.*;
import com.uns.service.B2cShopperValService;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.service.AppAuthorizationService;
import com.uns.service.ShopPerbiService;
import com.uns.service.UserService;
import com.uns.util.AesEncrypt;
import com.uns.util.HttpClientUtils;
import com.uns.util.Md5Encrypt;
import com.uns.util.ToolsUtils;
import com.uns.web.form.AppAuthorizationForm;

import net.sf.json.JSONObject;

@Controller
@RequestMapping(value = "/appAuthorization")
public class AppAuthorizationController extends BaseController {
	
	@Autowired
	private ShopPerbiService shopPerbiService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private AppAuthorizationService appAuthorizationService;

	@Autowired
	private B2cShopperValService b2cShopperValService;
	
	
	
	
	/** 商户app 已登录 授权
	 * @param request
	 * @param response
	 * @param appAuthorizationForm
	 * @throws Exception
	 */
	@RequestMapping(value="appAuthorizationLogin.htm",method=RequestMethod.POST)
	public void appAuthorizationLogin(HttpServletRequest request, HttpServletResponse response, AppAuthorizationForm appAuthorizationForm ) throws Exception{
		Map hashMap=new HashMap();
		response.setHeader("Access-Control-Allow-Origin","*");
        response.setHeader("Access-Control-Allow-Methods","GET,POST");
        response.setContentType("application/json;charset=utf-8");
        log.info("appAuthorizationLogin 商户app 已登录 授权");
		try {
			String mac=getAppCutAuthorizationMac(appAuthorizationForm);
			if(!mac.equals(appAuthorizationForm.getMac())){
				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "mac错误");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("mac错误!");
				response.getWriter().write(json.toString());
				return;
			}
			TAppGrantAuthorization tAppGrantAuthorization=appAuthorizationService.findTAppGrantAuthorization(appAuthorizationForm.getEnterpriseUUid(),appAuthorizationForm.getMobile());
			B2cShopperbiTemp b2cShopperbiTemp = shopPerbiService.findbytel(appAuthorizationForm.getMobile());
			if(b2cShopperbiTemp==null){
				hashMap.put("rspCode", "3004");
				hashMap.put("rspMsg", "用户不存在");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("用户不存在 3004");
				response.getWriter().write(json.toString());
				return;
			}
			if(tAppGrantAuthorization==null){
				hashMap.put("rspCode", "1001");
				hashMap.put("rspMsg", "用户未授权");
				hashMap.put("idCard", b2cShopperbiTemp.getIDNo().toUpperCase());
				hashMap.put("bankNo", b2cShopperbiTemp.getAccountbankno());
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("用户未授权!"+hashMap.toString());
				response.getWriter().write(json.toString());
				return;
			}else{
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "用户已授权");
				hashMap.put("uuid", tAppGrantAuthorization.getUuid());
				hashMap.put("name", b2cShopperbiTemp.getName());
				hashMap.put("idCard", b2cShopperbiTemp.getIDNo().toUpperCase());
				hashMap.put("bankNo", b2cShopperbiTemp.getAccountbankno());
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("用户已授权!"+hashMap.toString());
				response.getWriter().write(json.toString());
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "9999");
			hashMap.put("rspMsg", "系统错误");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("APP授权系统错误"+hashMap.toString());
			response.getWriter().write(json.toString());
		}
		
		
		
	}
	
	
	
	


	/** html 绑定
	 * @param request
	 * @param response
	 * @param appAuthorizationForm
	 * @throws Exception
	 */
	@RequestMapping(value="appAuthorization.htm",method=RequestMethod.POST)
	public void appAuthorization(HttpServletRequest request, HttpServletResponse response, AppAuthorizationForm appAuthorizationForm ) throws Exception{
		Map hashMap=new HashMap();
		response.setContentType("application/json;charset=utf-8");
		log.info("appAuthorization html 绑定");
		try {
			String mac=getAppAuthorizationMac(appAuthorizationForm);
			if(!mac.equals(appAuthorizationForm.getMac())){
				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "mac错误");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("mac错误!");
				response.getWriter().write(json.toString());
				return;
			}
			B2cShopperbiTemp b2cShopperbiTemp = shopPerbiService.findbytel(appAuthorizationForm.getMobile());
			if(b2cShopperbiTemp==null){

				//判断商户注册临时表是否有此信息
				//如果有此信息 并且上级商户邀请码不为空 则此商户为裂变商户
				B2cShopperVal b2cShopperVal = new B2cShopperVal();
				b2cShopperVal.setTel(appAuthorizationForm.getMobile());
				List<B2cShopperVal> b2cShopperVals = b2cShopperValService.queryByParam(b2cShopperVal);
				if (null != b2cShopperVals && b2cShopperVals.size() > 0){
					b2cShopperVal = b2cShopperVals.get(0);
					if (StringUtils.isNotEmpty(b2cShopperVal.getInviteCodeP())){
						hashMap.put("rspCode", "3002");
						hashMap.put("rspMsg", "您的信息未完善，请先登录完善信息！");
						hashMap.put("inviteFirstLogin", Constants.STATUS1); //裂变商户首次登陆 1:首次登陆 0:非首次登陆
						hashMap.put("inviteCodeP", b2cShopperVal.getInviteCodeP()); //上级商户邀请码
						JSONObject json = JSONObject.fromObject(hashMap);
						log.info("裂变商户授权：" + json.toString());
						response.getWriter().write(json.toString());
						return;
					}
				}

				hashMap.put("rspCode", "3004");
				hashMap.put("rspMsg", "用户不存在");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("用户不存在 3004");
				response.getWriter().write(json.toString());
				return;
			}
			Boolean flag=checkEmpty(appAuthorizationForm);
			if(!flag){
				hashMap.put("rspCode", "3005");
				hashMap.put("rspMsg", "参数不匹配");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("用户不存在 3004");
				response.getWriter().write(json.toString());
				return;
			}
			Boolean paramflag=checkParam(appAuthorizationForm,b2cShopperbiTemp);
			if(!paramflag){
				hashMap.put("rspCode", "3007");
				hashMap.put("rspMsg", "参数不匹配");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("用户不存在 3005"+json.toString());
				response.getWriter().write(json.toString());
				return;
			}
			TAppGrantAuthorization tAppGrantAuthorization=appAuthorizationService.findTAppGrantAuthorizationUuid(appAuthorizationForm.getUuid(),appAuthorizationForm.getMobile());
			if(tAppGrantAuthorization!=null){
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "已授权");
				hashMap.put("enterpriseUuid", b2cShopperbiTemp.getShopperid());
				hashMap.put("name", b2cShopperbiTemp.getName());
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("APP已授权");
				response.getWriter().write(json.toString());
				return;
			}else{
				//调用 u8授权
				Map authorizationMap=new HashMap();
				authorizationMap.put("uuid", appAuthorizationForm.getUuid());
				authorizationMap.put("enterpriseUuid", b2cShopperbiTemp.getShopperid());
				authorizationMap.put("idCard", appAuthorizationForm.getIdCard());
				authorizationMap.put("name", appAuthorizationForm.getName());
				authorizationMap.put("mobile", appAuthorizationForm.getMobile());
				log.info("授权 u8："+ConstantsEnv.APP_AUTHORIZATION_URL+authorizationMap.toString());
				Map authorizationCodeMap=HttpClientUtils.postRequestMap(ConstantsEnv.APP_AUTHORIZATION_URL, authorizationMap, Map.class);
				Integer authorizationCode=(Integer) authorizationCodeMap.get("isAuthorization");
				log.info("授权 返回码："+authorizationCode);
				if(Constants.CON_YES.equals(authorizationCode==null?null:authorizationCode.toString())){
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "授权成功");
					hashMap.put("enterpriseUuid", b2cShopperbiTemp.getShopperid());
					hashMap.put("name", b2cShopperbiTemp.getName());
					appAuthorizationForm.setEnterpriseUUid(b2cShopperbiTemp.getShopperid().toString());
					appAuthorizationService.insertAppAuthorization(appAuthorizationForm);
				}else{
					hashMap.put("rspCode", "3006");
					hashMap.put("rspMsg", "个人端授权失败");
				}
				
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("APP已完成"+json.toString());
				response.getWriter().write(json.toString());
				return;
				
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "9999");
			hashMap.put("rspMsg", "系统错误");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("APP绑定 系统错误");
			response.getWriter().write(json.toString());
		}
	}
	
	/** 商户app解绑
	 * @param request
	 * @param response
	 * @param appAuthorizationForm
	 * @throws Exception
	 */
	@RequestMapping(value="appRemoveAuthorization.htm",method=RequestMethod.POST)
	public void appRemoveAuthorization(HttpServletRequest request, HttpServletResponse response, AppAuthorizationForm appAuthorizationForm ) throws Exception{
		Map hashMap=new HashMap();
		response.setContentType("application/json;charset=utf-8");
		log.info("appRemoveAuthorization 商户app解绑");
		try {
			String mac=getAppDeleteAuthorizationMac(appAuthorizationForm);
			if(!mac.equals(appAuthorizationForm.getMac())){
				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "mac错误");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("mac错误!");
				response.getWriter().write(json.toString());
				return;
			}
			TAppGrantAuthorization tAppGrantAuthorization=appAuthorizationService.findTAppGrantAuthorization(appAuthorizationForm.getEnterpriseUUid(),appAuthorizationForm.getMobile());
			if(tAppGrantAuthorization==null){
				hashMap.put("rspCode", "3003");
				hashMap.put("rspMsg", "授权不存在");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("APP解绑");
				response.getWriter().write(json.toString());
				return;
			}else{
				Map authorizationMap=new HashMap();
				authorizationMap.put("uuid", appAuthorizationForm.getUuid());
				authorizationMap.put("enterpriseUuid", appAuthorizationForm.getEnterpriseUUid());
				log.info("解除绑定 请求U8:"+ConstantsEnv.REMOVE_AUTHORIZATION_URL+authorizationMap.toString());
				Map authorizationCodeMap=HttpClientUtils.postRequestMap(ConstantsEnv.REMOVE_AUTHORIZATION_URL,authorizationMap,Map.class);
				Integer authorizationCode=(Integer) authorizationCodeMap.get("isRemoveAuthorization");
				log.info("解除绑定 U8返回值:"+authorizationCode);
				if(Constants.CON_YES.equals(authorizationCode==null?null:authorizationCode.toString())){
					appAuthorizationService.updateAuthorization(appAuthorizationForm.getUuid(),appAuthorizationForm.getEnterpriseUUid());
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "解绑成功");
				}else{
					hashMap.put("rspCode", "3007");
					hashMap.put("rspMsg", "解除授权失败");
				}
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("APP解绑"+json.toString());
				response.getWriter().write(json.toString());
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "9999");
			hashMap.put("rspMsg", "系统错误");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("APP绑定 系统错误");
			response.getWriter().write(json.toString());
		}
		
	}

	/**商户 app 切换
	 * @param request
	 * @param response
	 * @param appAuthorizationForm
	 * @throws Exception
	 */
	@RequestMapping(value="appCutAuthorization.htm",method=RequestMethod.POST)
	public void appCutAuthorization(HttpServletRequest request, HttpServletResponse response, AppAuthorizationForm appAuthorizationForm ) throws Exception{
		Map hashMap=new HashMap();
		response.setContentType("application/json;charset=utf-8");
		log.info("appCutAuthorization 商户 app 切换");
		try {
			String mac=getAppCutAuthorizationMac(appAuthorizationForm);
			if(!mac.equals(appAuthorizationForm.getMac())){
				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "mac错误");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("mac错误!");
				response.getWriter().write(json.toString());
				return;
			}
			TAppGrantAuthorization tAppGrantAuthorization=appAuthorizationService.findTAppGrantAuthorization(appAuthorizationForm.getEnterpriseUUid(),appAuthorizationForm.getMobile());
			if(tAppGrantAuthorization==null){
				hashMap.put("rspCode", "3003");
				hashMap.put("rspMsg", "未找到授权信息");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("APP解绑");
				response.getWriter().write(json.toString());
				return;
			}else{
				B2cShopperbiTemp b2cShopperbiTemp = shopPerbiService.findbytel(appAuthorizationForm.getMobile());
				FixAmaount fix=shopPerbiService.searchFixAmaount();
				hashMap.put("T0minamount", b2cShopperbiTemp.getT0minamount());
				hashMap.put("T0maxamount", b2cShopperbiTemp.getT0maxamount());
				hashMap.put("shopperid",b2cShopperbiTemp.getShopperid());
				hashMap.put("merchantKey", b2cShopperbiTemp.getMerchantKey());
				hashMap.put("shoppertype", b2cShopperbiTemp.getMerchantType());//商户类型
				hashMap.put("scompany", b2cShopperbiTemp.getScompany());
				hashMap.put("fixamount", fix.getFixamaount());
				hashMap.put("qrpayMerchantkey", b2cShopperbiTemp.getQrpayMerchantkey());
				hashMap.put("fixedQrCodeUrl", b2cShopperbiTemp.getFixedqrcodeurl());
				hashMap.put("fixedQrCodeFlag", b2cShopperbiTemp.getFixedqrcodeflag()==null? Constants.CON_NO:b2cShopperbiTemp.getFixedqrcodeflag());
				hashMap.put("uuid", tAppGrantAuthorization.getUuid());
				if(b2cShopperbiTemp.getShopperidP() == null){
					hashMap.put("ifHavaAgent", Constants.CON_NO);
				}else{
					hashMap.put("ifHavaAgent", Constants.CON_YES);
				}

				hashMap.put("inviteCode",b2cShopperbiTemp.getInviteCode());
				hashMap.put("inviteCodeP", b2cShopperbiTemp.getInviteCodeP());
				
				hashMap.put("firstLogin","false");
				hashMap.put("rspCode", "0000");
				if(Constants.CON_YES.equalsIgnoreCase(b2cShopperbiTemp.getRecheckmerchantflag())){
					
					hashMap.put("idNo", ToolsUtils.getSubStr(b2cShopperbiTemp.getIDNo()));
					hashMap.put("bankno", AesEncrypt.encryptAES(b2cShopperbiTemp.getAccountbankno(),ConstantsEnv.APP_AES_KEY));
					hashMap.put("name",b2cShopperbiTemp.getName());
					B2cDict bankname=shopPerbiService.findBankName(b2cShopperbiTemp.getAccountbankdictval().toString());
					hashMap.put("bankname", bankname.getDict());
					hashMap.put("cardprovince", b2cShopperbiTemp.getAccountbankprov());
					hashMap.put("cardcity", b2cShopperbiTemp.getAccountBankCity());
					hashMap.put("branchBankName", b2cShopperbiTemp.getAccountbankname());
					hashMap.put("openT+0",b2cShopperbiTemp.getIsSupportT0() == null ? "" : b2cShopperbiTemp.getIsSupportT0());
					hashMap.put("qrpayMerchantkey", b2cShopperbiTemp.getQrpayMerchantkey());
					hashMap.put("fixedQrCodeUrl", b2cShopperbiTemp.getFixedqrcodeurl());
					hashMap.put("fixedQrCodeFlag", b2cShopperbiTemp.getFixedqrcodeflag()==null? Constants.CON_NO:b2cShopperbiTemp.getFixedqrcodeflag());
					hashMap.put("rspMsg", "审核已通过");
					hashMap.put("flag", Constants.CON_NO);
				}else{
					if(Constants.STATUS0.equalsIgnoreCase(b2cShopperbiTemp.getIfvalid()==null?"":b2cShopperbiTemp.getIfvalid().toString().trim())){
						hashMap.put("rspMsg", "信息已经注册过,未审核");
						hashMap.put("flag", Constants.STATUS3);
					}else if(Constants.STATUS2.equalsIgnoreCase(b2cShopperbiTemp.getIfvalid()==null?"":b2cShopperbiTemp.getIfvalid().toString().trim())){
						hashMap.put("rspMsg", "信息已注册，初审不通过："+b2cShopperbiTemp.getExamineresullt());
						hashMap.put("flag", Constants.STATUS2);

					}else if(Constants.STATUS1.equalsIgnoreCase(b2cShopperbiTemp.getIfvalid()==null?"":b2cShopperbiTemp.getIfvalid().toString().trim())){
						if(Constants.STATUS0.equals(b2cShopperbiTemp.getRecheckmerchantflag()==null?"":b2cShopperbiTemp.getRecheckmerchantflag().toString().trim())){
							hashMap.put("rspMsg", "信息已经注册过,未审核");
							hashMap.put("flag", Constants.STATUS3);
						}else if(Constants.STATUS2.equals(b2cShopperbiTemp.getRecheckmerchantflag()==null?"":b2cShopperbiTemp.getRecheckmerchantflag().toString().trim())){
							hashMap.put("rspMsg", "信息已注册，复审不通过："+b2cShopperbiTemp.getRecheckmerchantremark());
							hashMap.put("flag", Constants.STATUS2);

						}
					}
					
				}
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("切换:" + json.toString());
				response.getWriter().write(json.toString());
				shopPerbiService.updateB2cShopperbiTemp(b2cShopperbiTemp);
				return ;
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "9999");
			hashMap.put("rspMsg", "系统错误");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("APP绑定 系统错误");
			response.getWriter().write(json.toString());
		}
	}
	
	/**生成 mac
	 * @param appAuthorizationForm
	 * @return
	 */
	private String getMac(AppAuthorizationForm appAuthorizationForm) {
		StringBuffer sb=new StringBuffer();
		sb.append("mobile="+appAuthorizationForm.getMobile());
		sb.append("&pasword="+appAuthorizationForm.getPasword());
		sb.append("&merchantKey="+ConstantsEnv.MERCHANTKEY);
		log.info("mac 加密前:"+sb.toString());
		log.info("mac:"+Md5Encrypt.md5(sb.toString()));
		return Md5Encrypt.md5(sb.toString());
	}

	
	/**登录授权 mac
	 * @param appAuthorizationForm
	 * @return
	 */
	private String getAppAuthorizationMac(AppAuthorizationForm appAuthorizationForm) {
		StringBuffer sb=new StringBuffer();
		sb.append("mobile="+appAuthorizationForm.getMobile());
		sb.append("&uuid="+appAuthorizationForm.getUuid());
		sb.append("&idCard="+appAuthorizationForm.getIdCard());
		sb.append("&name="+appAuthorizationForm.getName());
		sb.append("&merchantKey="+ConstantsEnv.MERCHANTKEY);
		log.info("授权mac 加密前:"+sb.toString());
		log.info("appAuthorizationMac:"+Md5Encrypt.md5(sb.toString()));
		return Md5Encrypt.md5(sb.toString());
	}
	
	/**根据 uuid 小商户号生成 mac
	 * @param appAuthorizationForm
	 * @return
	 */
	private String getAppCutAuthorizationMac(AppAuthorizationForm appAuthorizationForm) {
		StringBuffer sb=new StringBuffer();
		sb.append("mobile="+appAuthorizationForm.getMobile());
		sb.append("&enterpriseUUid="+appAuthorizationForm.getEnterpriseUUid());
		sb.append("&merchantKey="+ConstantsEnv.MERCHANTKEY);
		log.info("切换 加密前:"+sb.toString());
		log.info("authorizationMac:"+Md5Encrypt.md5(sb.toString()));
		return Md5Encrypt.md5(sb.toString());
	}
	
	

	/** 根据 手机号 ，uuid,小商户号 生成mac
	 * @param appAuthorizationForm
	 * @return
	 */
	private String getAppDeleteAuthorizationMac(AppAuthorizationForm appAuthorizationForm) {
		StringBuffer sb=new StringBuffer();
		sb.append("mobile="+appAuthorizationForm.getMobile());
		sb.append("&uuid="+appAuthorizationForm.getUuid());
		sb.append("&enterpriseUUid="+appAuthorizationForm.getEnterpriseUUid());
		sb.append("&merchantKey="+ConstantsEnv.MERCHANTKEY);
		log.info("解绑 加密前:"+sb.toString());
		log.info("appDeleteAuthorizationMac:"+Md5Encrypt.md5(sb.toString()));
		return Md5Encrypt.md5(sb.toString());
	}
	

	/** 验证参数是否为空
	 * @param appAuthorizationForm
	 * @return
	 */
	private Boolean checkEmpty(AppAuthorizationForm appAuthorizationForm) {
		Boolean flag=StringUtils.isNotEmpty(appAuthorizationForm.getMobile())&&StringUtils.isNotEmpty(appAuthorizationForm.getIdCard())
				&&StringUtils.isNotEmpty(appAuthorizationForm.getName())&&StringUtils.isNotEmpty(appAuthorizationForm.getUuid())
				&&StringUtils.isNotEmpty(appAuthorizationForm.getMac());
		log.info("判断参数是否为空:"+" 电话："+appAuthorizationForm.getMobile()+" 身份证号："+appAuthorizationForm.getIdCard()
		+"姓名:"+appAuthorizationForm.getName()+" uuid:"+appAuthorizationForm.getUuid()+" mac:"+appAuthorizationForm.getMac());		
		return flag;
	}
	
	/**html(u8) 授权
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value="htmlAuthorizationLogin.htm",method=RequestMethod.POST)
	public void htmlAuthorizationLogin(HttpServletRequest request, HttpServletResponse response, AppAuthorizationForm appAuthorizationForm ) throws Exception{
		Map hashMap=new HashMap();
		response.setHeader("Access-Control-Allow-Origin","*");
        response.setHeader("Access-Control-Allow-Methods","GET,POST");
        response.setContentType("application/json;charset=utf-8");
        log.info("htmlAuthorizationLogin html(u8) 授权");
        try {
			String mac=getMac(appAuthorizationForm);
			if(!mac.equals(appAuthorizationForm.getMac())){
				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "mac错误");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("mac错误!");
				response.getWriter().write(json.toString());
				return;
			}
			Users users=userService.findbytelm(appAuthorizationForm.getMobile());
			if(users==null){
				hashMap.put("rspCode", "2222");
				hashMap.put("rspMsg", "用户名或密码错误");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("APP授权登录用户不存在!"+hashMap.toString());
				response.getWriter().write(json.toString());
				return;
			}
			String password = Md5Encrypt.md5(appAuthorizationForm.getPasword());
			if(!password.equals(users.getPassword())){
				hashMap.put("rspCode", "2222");
				hashMap.put("rspMsg", "用户名或密码错误");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("APP授权登录密码错误!");
				response.getWriter().write(json.toString());
				return;
			}
			B2cShopperbiTemp b2cShopperbiTemp = shopPerbiService.findbytel(appAuthorizationForm.getMobile());
			if(b2cShopperbiTemp==null){
				hashMap.put("rspCode", "3004");
				hashMap.put("rspMsg", "用户不存在");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("用户不存在 3004");
				response.getWriter().write(json.toString());
				return;
			}
			
			TAppGrantAuthorization tAppGrantAuthorization=appAuthorizationService.findTAppGrantAuthorization(users.getMerchantid().toString(),appAuthorizationForm.getMobile());
			
			if(tAppGrantAuthorization==null){
				hashMap.put("rspCode", "1001");
				hashMap.put("rspMsg", "用户未授权");
				hashMap.put("mobile", b2cShopperbiTemp.getStel());
				hashMap.put("name", b2cShopperbiTemp.getName());
				hashMap.put("idCard", b2cShopperbiTemp.getIDNo().toUpperCase());
				hashMap.put("enterpriseUUid", b2cShopperbiTemp.getShopperid());
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("用户未授权!"+hashMap.toString());
				response.getWriter().write(json.toString());
				return;
			}else{
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "授权成功");
				hashMap.put("mobile", b2cShopperbiTemp.getStel());
				hashMap.put("uuid", tAppGrantAuthorization.getUuid());
				hashMap.put("enterpriseUUid", b2cShopperbiTemp.getShopperid());
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("用户已授权!"+hashMap.toString());
				response.getWriter().write(json.toString());
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "9999");
			hashMap.put("rspMsg", "系统错误");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("APP授权系统错误"+hashMap.toString());
			response.getWriter().write(json.toString());
		}
	}
	
	/**u8 使用
	 * u8 回调绑定
	 * @param request
	 * @param response
	 * @param appAuthorizationForm
	 * @throws Exception
	 */
	@RequestMapping(value="appBoundAuthorization.htm",method=RequestMethod.POST)
	public void appBoundAuthorization(HttpServletRequest request, HttpServletResponse response, AppAuthorizationForm appAuthorizationForm ) throws Exception{
		Map hashMap=new HashMap();
		response.setHeader("Access-Control-Allow-Origin","*");
        response.setHeader("Access-Control-Allow-Methods","GET,POST");
        response.setContentType("application/json;charset=utf-8");
        log.info("appBoundAuthorization u8 回调绑定");
        try {
        	Boolean flag=checkEmpty(appAuthorizationForm);
			if(!flag){
				hashMap.put("rspCode", "3005");
				hashMap.put("rspMsg", "参数不匹配");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("用户不存在 3005"+json.toString());
				response.getWriter().write(json.toString());
				return;
			}
			String mac=appBoundAuthorizationMac(appAuthorizationForm);
			if(!mac.equals(appAuthorizationForm.getMac())){
				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "mac错误");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("mac错误!");
				response.getWriter().write(json.toString());
				return;
			}
			B2cShopperbiTemp b2cShopperbiTemp = shopPerbiService.findbytel(appAuthorizationForm.getMobile());
			if(b2cShopperbiTemp==null){
				hashMap.put("rspCode", "3004");
				hashMap.put("rspMsg", "用户不存在");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("用户不存在 3004"+json.toString());
				response.getWriter().write(json.toString());
				return;
			}
			
			Boolean paramflag=checkParam(appAuthorizationForm,b2cShopperbiTemp);
			if(!paramflag){
				hashMap.put("rspCode", "3007");
				hashMap.put("rspMsg", "参数不匹配");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("用户不存在 3005"+json.toString());
				response.getWriter().write(json.toString());
				return;
			}
			TAppGrantAuthorization tAppGrantAuthorization=appAuthorizationService.findTAppGrantAuthorizationUuid(appAuthorizationForm.getUuid(),appAuthorizationForm.getMobile());
			if(tAppGrantAuthorization!=null){
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "已授权");
				hashMap.put("enterpriseUUid", b2cShopperbiTemp.getShopperid());
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("APP已授权"+json.toString());
				response.getWriter().write(json.toString());
				return;
			}else{
				appAuthorizationForm.setEnterpriseUUid(b2cShopperbiTemp.getShopperid().toString());
				appAuthorizationService.insertAppAuthorization(appAuthorizationForm);
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "授权成功");
				hashMap.put("enterpriseUuid", b2cShopperbiTemp.getShopperid());
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("APP已授权"+json.toString());
				response.getWriter().write(json.toString());
				return;
			}
				
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "9999");
			hashMap.put("rspMsg", "系统错误");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("APP绑定 系统错误");
			response.getWriter().write(json.toString());
		}
	}
	
	
	

	private Boolean checkParam(AppAuthorizationForm appAuthorizationForm, B2cShopperbiTemp b2cShopperbiTemp) {
		Boolean flag=b2cShopperbiTemp.getIDNo().toUpperCase().equals(appAuthorizationForm.getIdCard())&&b2cShopperbiTemp.getName().equals(appAuthorizationForm.getName());
		log.info("u3_small ID_NO:"+b2cShopperbiTemp.getIDNo().toUpperCase()+" u3_small name:"+b2cShopperbiTemp.getName()+
		"U8 Id_card:"+appAuthorizationForm.getIdCard()+"u8 name:"+appAuthorizationForm.getName());
		return flag;
	}






	/**u8 调用
	 * @param request
	 * @param response
	 * @param appAuthorizationForm
	 * @throws Exception
	 */
	@RequestMapping(value="appDeleteAuthorization.htm",method=RequestMethod.POST)
	public void appDeleteAuthorization(HttpServletRequest request, HttpServletResponse response, AppAuthorizationForm appAuthorizationForm ) throws Exception{
		Map hashMap=new HashMap();
		response.setHeader("Access-Control-Allow-Origin","*");
        response.setHeader("Access-Control-Allow-Methods","GET,POST");
        response.setContentType("application/json;charset=utf-8");
        log.info("appDeleteAuthorization u8 调用");
        try {
			String mac=getAppDeleteAuthorizationMac(appAuthorizationForm);
			if(!mac.equals(appAuthorizationForm.getMac())){
				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "mac错误");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("mac错误!");
				response.getWriter().write(json.toString());
				return;
			}
			TAppGrantAuthorization tAppGrantAuthorization=appAuthorizationService.findTAppGrantAuthorizationUuid(appAuthorizationForm.getUuid(),appAuthorizationForm.getMobile());
			if(tAppGrantAuthorization==null){
				hashMap.put("rspCode", "3003");
				hashMap.put("rspMsg", "未找到有效授权信息");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("APP解绑"+hashMap.toString());
				response.getWriter().write(json.toString());
				return;
			}else{
				appAuthorizationService.updateAuthorization(appAuthorizationForm.getUuid(),appAuthorizationForm.getEnterpriseUUid());
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "解绑成功");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("APP解绑"+hashMap.toString());
				response.getWriter().write(json.toString());
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "9999");
			hashMap.put("rspMsg", "系统错误");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("APP绑定 系统错误");
			response.getWriter().write(json.toString());
		}
		
	}
	
	private String appBoundAuthorizationMac(AppAuthorizationForm appAuthorizationForm) {
		StringBuffer sb=new StringBuffer();
		sb.append("mobile="+appAuthorizationForm.getMobile());
		sb.append("&uuid="+appAuthorizationForm.getUuid());
		sb.append("&idCard="+appAuthorizationForm.getIdCard());
		sb.append("&name="+appAuthorizationForm.getName());
		sb.append("&merchantKey="+ConstantsEnv.MERCHANTKEY);
		log.info("appBoundAuthorizationMac 加密前:"+sb.toString());
		log.info("appBoundAuthorizationMac:"+Md5Encrypt.md5(sb.toString()));
		return Md5Encrypt.md5(sb.toString());
	}

}
