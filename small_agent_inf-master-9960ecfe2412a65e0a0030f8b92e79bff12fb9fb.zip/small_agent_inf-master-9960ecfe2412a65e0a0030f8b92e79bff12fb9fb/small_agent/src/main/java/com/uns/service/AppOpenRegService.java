package com.uns.service;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uns.common.myenum.MessageEnum;
import com.uns.dao.*;
import com.uns.model.*;

import com.uns.util.*;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.uns.bean.BankCardValBean;
import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;

@Service
public class AppOpenRegService {

	@Autowired
	private B2cShopperValMapper shopperValMapper;
	
	@Autowired
	private B2cShopperbiTempMapper shopperbiTempMapper;
	
	@Autowired
	private AreaMapper areaMapper;
	
	@Autowired
	private B2cDictMapper dictMapper;
	
	@Autowired
	private MposPhotoTmpMapper mposPhotoTmpMapper;
	
	@Autowired
	private MposMerchantFeeMapper mposMerchantFeeMapper;
	
	
	@Autowired
	private MposRemoteFeeMapper mposRemoteFeeMapper;
	
	@Autowired
	private UsersMapper usersMapper;
	
	@Autowired
	private B2cShopperbiMapper b2cShopperbiMapper;
	
	@Autowired
	private B2cShopperbiTempMapper b2cShopperbiTempMapper;
	
	@Autowired
	private B2cTermBinderMapper b2cTermBinderMapper;
	
	@Autowired
	private TerminalHistoryMapper terminalHistoryMapper;
	
	@Autowired
	private MposRemoteInvitationMapper mposRemoteInvitationMapper;
	
	@Autowired
	private B2cFixedCodeMapper fixedCodeMapper;
	
	@Autowired
	private MposApplicationProgressMapper progressmapper;
	
	@Autowired
	private MposRemoteInvitationMapper  remotemapper;
	
	@Autowired
	private HkMerchantUtils hkMerchantUtils;

	@Autowired
	private B2cCreditCountMapper creditCountMapper;

	@Autowired
	private AcmsMapUtils acmsMapUtils;
	
	@Autowired
	private SweepCodeProductMapper sweepCodeProductMapper;

	@Autowired
	private B2cShopperbiShareMapper b2cShopperbiShareMapper;

	@Autowired
	private RegMposAndQrcode regMposAndQrcode;

	private Logger Log = LoggerFactory.getLogger(AppOpenRegService.class);



	public HashMap countCreditMin(HttpServletRequest request) {
		HashMap hashMap = new HashMap();
		String merchantNo = request.getParameter("merchantNo") == null ? "" : request.getParameter("merchantNo").trim();
		String cardlifetype = request.getParameter("cardlifetype") == null ? "" : request.getParameter("cardlifetype").trim();
		//项目类型
		String projectType = request.getParameter("projectType") == null ? "" : request.getParameter("projectType").trim();
		String type = request.getParameter("type");
		if("".equals(merchantNo)){
			hashMap.put("rspCode","1001");
			hashMap.put("rspMsg","merchantNo is null");
			return hashMap;
		}
		try {
			B2cCreditCount b2cCreditCount = new B2cCreditCount();
			b2cCreditCount.setShopperId(merchantNo);
			b2cCreditCount.setPhoneType(type);
			b2cCreditCount.setCreateDate(new Date());
			b2cCreditCount.setProjectType(projectType);
			if(StringUtils.isNotEmpty(cardlifetype)){
				b2cCreditCount.setCardlifetype(cardlifetype);
			}else{
				b2cCreditCount.setCardlifetype(Constants.CON_YES);
			}
			int i = creditCountMapper.addCreditCount(b2cCreditCount);
			if(i > 0){
				hashMap.put("rspCode","0000");
				hashMap.put("rspMsg","成功");
				return hashMap;
			}
		}catch (Exception e){
			e.printStackTrace();
			hashMap.put("rspCode","2222");
			hashMap.put("rspMsg","系统出错");
			return hashMap;
		}
		return hashMap;
	}

	/**
	 * 设置默认收款码
	 * @param request
	 * @return
	 */
	public HashMap setDefaultQrCode(HttpServletRequest request) {
		HashMap hashMap = new HashMap();
		String version = request.getParameter("version");
		String type = request.getParameter("type");
		try {
			if(Constants.VERSION_2_1_0.equals(version)){
				if(Constants.TYPE_A.equals(type)){
					hashMap = setDefaultQrCodeAndroid210(request);
				}else{
					hashMap = setDefaultQrCodeIOS210(request);
				}
			} else{
				if(Constants.TYPE_A.equals(type)){
					hashMap = setDefaultQrCodeAndroid210(request);
				}else{
					hashMap = setDefaultQrCodeIOS210(request);
				}
			}
			return hashMap;
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "出错");
			return hashMap;
		}
	}
	
	/**
	 * 设置默认收款码IOS210
	 * @param request
	 * @return
	 */
	private HashMap setDefaultQrCodeIOS210(HttpServletRequest request) {
		HashMap hashMap = new HashMap();
		try {
			System.out.println("设置默认收款码IOS210......................");
			String merchantNo = request.getParameter("merchantNo") == null ? "" : request.getParameter("merchantNo").trim();
			String qrCodeNo = request.getParameter("qrCodeNo") == null ? "" : request.getParameter("qrCodeNo").trim();
			if(merchantNo.isEmpty()){
				hashMap.put("rspCode", "1001");
				hashMap.put("rspMsg", "商户号为空");
				return hashMap;
			}
			if(qrCodeNo.isEmpty()){
				hashMap.put("rspCode", "1002");
				hashMap.put("rspMsg", "二维码编号为空");
				return hashMap;
			}
			
			B2cFixedCode b2cFixedCode = new B2cFixedCode();
			b2cFixedCode.setMerchantid(merchantNo);
			b2cFixedCode.setIfDefault(Constants.STATUS0);
			fixedCodeMapper.updateDefault(b2cFixedCode);
			
			b2cFixedCode = new B2cFixedCode();
			b2cFixedCode.setQrCodeNo(qrCodeNo);
			b2cFixedCode.setIfDefault(Constants.STATUS1);
			fixedCodeMapper.updateDefault(b2cFixedCode);
			
			hashMap.put("rspCode", "0000");
			hashMap.put("rspMsg", "成功");
			return hashMap;
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "出错");
			return hashMap;
		}
	}

	/**
	 * 设置默认收款码Android210
	 * @param request
	 * @return
	 */
	private HashMap setDefaultQrCodeAndroid210(HttpServletRequest request) {
		HashMap hashMap = new HashMap();
		try {
			System.out.println("设置默认收款码Android210......................");
			String merchantNo = request.getParameter("merchantNo") == null ? "" : request.getParameter("merchantNo").trim();
			String qrCodeNo = request.getParameter("qrCodeNo") == null ? "" : request.getParameter("qrCodeNo").trim();
			if(merchantNo.isEmpty()){
				hashMap.put("rspCode", "1001");
				hashMap.put("rspMsg", "商户号为空");
				return hashMap;
			}
			if(qrCodeNo.isEmpty()){
				hashMap.put("rspCode", "1002");
				hashMap.put("rspMsg", "二维码编号为空");
				return hashMap;
			}
			
			B2cFixedCode b2cFixedCode = new B2cFixedCode();
			b2cFixedCode.setMerchantid(merchantNo);
			b2cFixedCode.setIfDefault(Constants.STATUS0);
			fixedCodeMapper.updateDefault(b2cFixedCode);
			
			b2cFixedCode = new B2cFixedCode();
			b2cFixedCode.setQrCodeNo(qrCodeNo);
			b2cFixedCode.setIfDefault(Constants.STATUS1);
			fixedCodeMapper.updateDefault(b2cFixedCode);
			
			hashMap.put("rspCode", "0000");
			hashMap.put("rspMsg", "成功");
			return hashMap;
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "出错");
			return hashMap;
		}
	}


	/**
	 * 查询二维码详情
	 * @param request
	 * @return
	 */
	public HashMap queryQrCodeByNo(HttpServletRequest request) {
		HashMap hashMap = new HashMap();
		String version = request.getParameter("version");
		String type = request.getParameter("type");
		try {
			if(Constants.VERSION_2_1_0.equals(version)){
				if(Constants.TYPE_A.equals(type)){
					hashMap = queryQrCodeByNoAndroid210(request);
				}else{
					hashMap = queryQrCodeByNoIOS210(request);
				}
			}else {
				if(Constants.TYPE_A.equals(type)){
					hashMap = queryQrCodeByNoAndroid210(request);
				}else{
					hashMap = queryQrCodeByNoIOS210(request);
				}
			}
			return hashMap;
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "出错");
			return hashMap;
		}
	}
	
	/**
	 * 查询二维码详情IOS210
	 * @param request
	 * @return
	 */
	private HashMap queryQrCodeByNoIOS210(HttpServletRequest request) {
		HashMap hashMap = new HashMap();
		try {
			System.out.println("查询二维码详情IOS210.................");
			String merchantNo = request.getParameter("merchantNo") == null ? "" : request.getParameter("merchantNo").trim();
			String qrCodeNo = request.getParameter("qrCodeNo") == null ? "" : request.getParameter("qrCodeNo").trim();
			
			if(merchantNo.isEmpty()){
				hashMap.put("rspCode", "1001");
				hashMap.put("rspMsg", "商户号为空");
				return hashMap;
			}
			if(qrCodeNo.isEmpty()){
				hashMap.put("rspCode", "1002");
				hashMap.put("rspMsg", "二维码编号为空");
				return hashMap;
			}
			B2cFixedCode fixedCode = new B2cFixedCode();
			fixedCode.setMerchantid(merchantNo);
			fixedCode.setQrCodeNo(qrCodeNo);
			List<B2cFixedCode> fixedCodes = fixedCodeMapper.findFixedCodesByParam(fixedCode);
			if(fixedCodes != null && fixedCodes.size() > 0){
				fixedCode = fixedCodes.get(0);
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "查询成功");
				hashMap.put("id", fixedCode.getId());
				hashMap.put("qrCodeNO", fixedCode.getQrCodeNo());
				hashMap.put("qrCodeUrl", getQrCodeUrl(fixedCode.getQrCodeNo()));
				hashMap.put("shopperidP", fixedCode.getShopperidP());
				hashMap.put("ifDefault", fixedCode.getIfDefault());
				return hashMap;
			}else {
				hashMap.put("rspCode", "1003");
				hashMap.put("rspMsg", "该二维码未入库，请联系所属服务商或客服！");
				return hashMap;
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "出错");
			return hashMap;
		}
	}

	/**
	 * 查询二维码详情Android210
	 * @param request
	 * @return
	 */
	private HashMap queryQrCodeByNoAndroid210(HttpServletRequest request) {
		HashMap hashMap = new HashMap();
		try {
			System.out.println("查询二维码详情Android210.................");
			String merchantNo = request.getParameter("merchantNo") == null ? "" : request.getParameter("merchantNo").trim();
			String qrCodeNo = request.getParameter("qrCodeNo") == null ? "" : request.getParameter("qrCodeNo").trim();
			
			if(merchantNo.isEmpty()){
				hashMap.put("rspCode", "1001");
				hashMap.put("rspMsg", "商户号为空");
				return hashMap;
			}
			if(qrCodeNo.isEmpty()){
				hashMap.put("rspCode", "1002");
				hashMap.put("rspMsg", "二维码编号为空");
				return hashMap;
			}
			B2cFixedCode fixedCode = new B2cFixedCode();
			fixedCode.setMerchantid(merchantNo);
			fixedCode.setQrCodeNo(qrCodeNo);
			List<B2cFixedCode> fixedCodes = fixedCodeMapper.findFixedCodesByParam(fixedCode);
			if(fixedCodes != null && fixedCodes.size() > 0){
				fixedCode = fixedCodes.get(0);
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "查询成功");
				hashMap.put("id", fixedCode.getId());
				hashMap.put("qrCodeNO", fixedCode.getQrCodeNo());
				hashMap.put("qrCodeUrl", getQrCodeUrl(fixedCode.getQrCodeNo()));
				hashMap.put("shopperidP", fixedCode.getShopperidP());
				hashMap.put("ifDefault", fixedCode.getIfDefault());
				return hashMap;
			}else {
				hashMap.put("rspCode", "1003");
				hashMap.put("rspMsg", "该二维码未入库，请联系所属服务商或客服！");
				return hashMap;
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "出错");
			return hashMap;
		}
	}

	/**
	 * 查询商户已绑定二维码
	 * @param request
	 * @return
	 */
	public HashMap queryQrCodeList(HttpServletRequest request) {
		HashMap hashMap = new HashMap();
		String version = request.getParameter("version");
		String type = request.getParameter("type");
		try {
			if(Constants.VERSION_2_1_0.equals(version)){
				if(Constants.TYPE_A.equals(type)){
					hashMap = queryQrCodeListAndroid210(request);
				}else{
					hashMap = queryQrCodeListIOS210(request);
				}
			}else {
				if(Constants.TYPE_A.equals(type)){
					hashMap = queryQrCodeListAndroid210(request);
				}else{
					hashMap = queryQrCodeListIOS210(request);
				}
			}
			return hashMap;
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "出错");
			return hashMap;
		}
	}

	/**
	 * 查询商户已绑定二维码IOS210
	 * @param request
	 * @return
	 */
	private HashMap queryQrCodeListIOS210(HttpServletRequest request) {
		HashMap hashMap = new HashMap();
		try {
			System.out.println("查询商户已绑定二维码IOS210............");
			String merchantNo = request.getParameter("merchantNo") == null ? "" : request.getParameter("merchantNo").trim();
			if(merchantNo.isEmpty()){
				hashMap.put("rspCode", "1001");
				hashMap.put("rspMsg", "商户号为空");
				return hashMap;
			}
			B2cFixedCode b2cFixedCode = new B2cFixedCode();
			b2cFixedCode.setMerchantid(merchantNo);
			List<B2cFixedCode> fixedCodes = fixedCodeMapper.findFixedCodesByParam(b2cFixedCode);
			if(fixedCodes != null && fixedCodes.size() > 0){
				String smacs = "";
				String qrCodeUrl = "";
				for (B2cFixedCode b2cFixedCode2 : fixedCodes) {
					b2cFixedCode2.setQrCodeUrl(getQrCodeUrl(b2cFixedCode2.getQrCodeNo()));
				}
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg","查询成功");
				hashMap.put("qrCodeList", fixedCodes);
				return hashMap;
			}
			hashMap.put("rspCode", "1002");
			hashMap.put("rspMsg", "商户未绑定二维码");
			return hashMap;
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "出错");
			return hashMap;
		}
	}

	/**
	 * 查询商户已绑定二维码Android210
	 * @param request
	 * @return
	 */
	private HashMap queryQrCodeListAndroid210(HttpServletRequest request) {
		HashMap hashMap = new HashMap();
		try {
			System.out.println("查询商户已绑定二维码Android210............");
			String merchantNo = request.getParameter("merchantNo") == null ? "" : request.getParameter("merchantNo").trim();
			if(merchantNo.isEmpty()){
				hashMap.put("rspCode", "1001");
				hashMap.put("rspMsg", "商户号为空");
				return hashMap;
			}
			B2cFixedCode b2cFixedCode = new B2cFixedCode();
			b2cFixedCode.setMerchantid(merchantNo);
			List<B2cFixedCode> fixedCodes = fixedCodeMapper.findFixedCodesByParam(b2cFixedCode);
			if(fixedCodes != null && fixedCodes.size() > 0){
				for (B2cFixedCode b2cFixedCode2 : fixedCodes) {
					b2cFixedCode2.setQrCodeUrl(getQrCodeUrl(b2cFixedCode2.getQrCodeNo()));
				}
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg","查询成功");
				hashMap.put("qrCodeList", fixedCodes);
				return hashMap;
			}
			hashMap.put("rspCode", "1002");
			hashMap.put("rspMsg", "商户未绑定二维码");
			return hashMap;
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "出错");
			return hashMap;
		}
	}


	/**
	 * 商户二维码绑定
	 * @param request
	 * @return
	 */
	public HashMap qrCodeBind(HttpServletRequest request) {
		HashMap hashMap = new HashMap();
		String version = request.getParameter("version");
		String type = request.getParameter("type");
		try {
			if(Constants.TYPE_A.equals(type)){
				hashMap = qrCodeBindAndroid210(request);
			}else{
				hashMap = qrCodeBindIos210(request);
			}
			return hashMap;
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "绑定出错");
			return hashMap;
		}
	}
	
	/**
	 * 商户二维码绑定IOS210
	 * @param request
	 * @return
	 */
	private HashMap qrCodeBindIos210(HttpServletRequest request) throws Exception {
		HashMap hashMap = new HashMap();
		try {
			Log.info("商户二维码绑定Ios210............");
			String merchantNo = request.getParameter("merchantNo") == null ? "" : request.getParameter("merchantNo").trim();
			String qrCodeNo = request.getParameter("qrCodeNo") == null ? "" : request.getParameter("qrCodeNo").trim();
			
			if(merchantNo.isEmpty()){hashMap.put("rspCode", "1001"); hashMap.put("rspMsg", "商户号为空"); return hashMap;}
			if(qrCodeNo.isEmpty()){hashMap.put("rspCode", "1002"); hashMap.put("rspMsg", "二维码编号为空"); return hashMap;}
			
			Map map = new HashMap();
			map.put("qrCodeNo", qrCodeNo);
			B2cFixedCode b2cFixedCode = fixedCodeMapper.findFixedCodeByParam(map);
			
			if(b2cFixedCode == null){
				hashMap.put("rspCode", "1003");
				hashMap.put("rspMsg", "该二维码未入库，请联系所属服务商或客服！");
				return hashMap;
			}
			
			if(b2cFixedCode.getShopperidP() == null || "".equals(b2cFixedCode.getShopperidP())){
				hashMap.put("rspCode", "1004");
				hashMap.put("rspMsg", "该二维码未出库，请联系所属服务商或客服！");
				return hashMap;
			}
			
			if(b2cFixedCode.getMerchantid() != null && !"".equals(b2cFixedCode.getMerchantid())){
				hashMap.put("rspCode", "1005");
				hashMap.put("rspMsg", "二维码已被绑定");
				return hashMap;
			}
			
			Map params = new HashMap();
			params.put("qrCode", qrCodeNo);
			params.put("smallMerchNo", merchantNo);
			net.sf.json.JSONObject obs = net.sf.json.JSONObject.fromObject(params);
			Log.info("mpos_qrcode商户绑定二维码请求参数:"+obs.toString());
			String resultString = HttpClientUtils.REpostRequestStrJson(
					ConstantsEnv.QRCODE_BIND_URL, obs.toString());
			Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);
			Log.info("商户绑定二维码响应参数:"+ FastJson.fromJson(resultString));
			if(Constants.SUCCESS_CODE.equals(resultMap.get("rspCode"))){
				//查询商户信息
				B2cShopperbi shopperbi = b2cShopperbiMapper.findFactoringNoByShopperid(merchantNo);
				//修改商户服务商
				Map params1 = new HashMap();
				params.put("merchantNo", shopperbi.getShopperid());
				params.put("agentNo", b2cFixedCode.getAgentNo());
				obs = net.sf.json.JSONObject.fromObject(params);
				Log.info("修改代理商请求参数:"+obs.toString());
				resultString = HttpClientUtils.REpostRequestStrJson(
						ConstantsEnv.MPOS_AGENT_UPDATE_URL, obs.toString());
				resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);
				Log.info("MPOS_ACCOUNT修改代理商请求结果："+ FastJson.fromJson(resultString));
				 
				resultString = HttpClientUtils.REpostRequestStrJson(ConstantsEnv.QRCODE_AGENT_UPDATE_URL, obs.toString());
				resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);
				Log.info("QR_CODE修改代理商请求结果："+ FastJson.fromJson(resultString));
				
				if(Constants.SUCCESS_CODE.equals(resultMap.get("rspCode"))){
					//查询商户已绑定二维码
					b2cFixedCode = new B2cFixedCode();
					b2cFixedCode.setMerchantid(merchantNo);
					List<B2cFixedCode> fixedCodes = fixedCodeMapper.findFixedCodesByParam(b2cFixedCode);
					
					//查询二维码信息
					Map map1 = new HashMap();
					map1.put("qrCodeNo", qrCodeNo);
					B2cFixedCode fixedCode = fixedCodeMapper.findFixedCodeByParam(map1);
					fixedCode.setMerchantid(merchantNo);
					fixedCode.setBindingDate(new Date());
					fixedCode.setTel(shopperbi.getStel());
					fixedCode.setScompany(shopperbi.getScompany());
					//判断是否已绑定二维码  如果没有绑定过  则二维码设为默认
					if(fixedCodes == null || fixedCodes.size() == 0){
						//设置二维码为默认
						fixedCode.setIfDefault(Constants.STATUS1);
					}
					//修改二维码信息
					fixedCodeMapper.updateById(fixedCode);
					
					//修改商户信息中二维码信息
					Map map2=new HashMap();
					map2.put("fixedQrCodeUrl", getQrCodeUrl(qrCodeNo));
					map2.put("fixedQrCodeFlag", Constants.CON_YES);
					map2.put("merchantNo", merchantNo);
					map2.put("agentNo", fixedCode.getAgentNo());
					b2cShopperbiMapper.updateQrCode(map2);
					b2cShopperbiTempMapper.updateQrCode(map2);
					
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg","绑定成功");
					hashMap.put("qrCodeUrl", getQrCodeUrl(qrCodeNo));
					return hashMap;
				}else{
					hashMap.put("rspCode", "2222");
					hashMap.put("rspMsg", "绑定出错");
					return hashMap;
				}
			}else{
				hashMap.put("rspCode", resultMap.get("rspCode"));
				hashMap.put("rspMsg",resultMap.get("rspMsg"));
				return hashMap;
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "绑定出错");
			return hashMap;
		}
	}

	/**
	 * 商户二维码绑定Android210
	 * @param request
	 * @return
	 */
	public HashMap qrCodeBindAndroid210(HttpServletRequest request) throws Exception{
		HashMap hashMap = new HashMap();
		try {
			Log.info("商户二维码绑定Android210............");
			String merchantNo = request.getParameter("merchantNo") == null ? "" : request.getParameter("merchantNo").trim();
			String qrCodeNo = request.getParameter("qrCodeNo") == null ? "" : request.getParameter("qrCodeNo").trim();

			if(merchantNo.isEmpty()){hashMap.put("rspCode", "1001"); hashMap.put("rspMsg", "商户号为空"); return hashMap;}
			if(qrCodeNo.isEmpty()){hashMap.put("rspCode", "1002"); hashMap.put("rspMsg", "二维码编号为空"); return hashMap;}

            Map map = new HashMap();
            map.put("qrCodeNo", qrCodeNo);
            B2cFixedCode b2cFixedCode = fixedCodeMapper.findFixedCodeByParam(map);

            if (b2cFixedCode == null) {
                hashMap.put("rspCode", "1003");
                hashMap.put("rspMsg", "该二维码未入库，请联系所属服务商或客服！");
                return hashMap;
            }

            if (b2cFixedCode.getShopperidP() == null || "".equals(b2cFixedCode.getShopperidP())) {
                hashMap.put("rspCode", "1004");
                hashMap.put("rspMsg", "该二维码未出库，请联系所属服务商或客服！");
                return hashMap;
            }

            if (b2cFixedCode.getMerchantid() != null && !"".equals(b2cFixedCode.getMerchantid())) {
                hashMap.put("rspCode", "1005");
                hashMap.put("rspMsg", "二维码已被绑定");
                return hashMap;
            }

            Map params = new HashMap();
            params.put("qrCode", qrCodeNo);
            params.put("smallMerchNo", merchantNo);
            net.sf.json.JSONObject obs = net.sf.json.JSONObject.fromObject(params);
            Log.info("mpos_qrcode商户绑定二维码请求参数:" + obs.toString());
            String resultString = HttpClientUtils.REpostRequestStrJson(
                    ConstantsEnv.QRCODE_BIND_URL, obs.toString());
            Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);
            Log.info("商户绑定二维码响应参数:" + FastJson.fromJson(resultString));
            if (Constants.SUCCESS_CODE.equals(resultMap.get("rspCode"))) {
                //查询商户信息
                B2cShopperbi shopperbi = b2cShopperbiMapper.findFactoringNoByShopperid(merchantNo);
                //修改商户服务商
                Map params1 = new HashMap();
                params.put("merchantNo", shopperbi.getShopperid());
                params.put("agentNo", b2cFixedCode.getAgentNo());
                obs = net.sf.json.JSONObject.fromObject(params);
                Log.info("修改代理商请求参数:" + obs.toString());
                resultString = HttpClientUtils.REpostRequestStrJson(
                        ConstantsEnv.MPOS_AGENT_UPDATE_URL, obs.toString());
                resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);
                Log.info("MPOS_ACCOUNT修改代理商请求结果：" + FastJson.fromJson(resultString));

                resultString = HttpClientUtils.REpostRequestStrJson(ConstantsEnv.QRCODE_AGENT_UPDATE_URL, obs.toString());
                resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);
                Log.info("QR_CODE修改代理商请求结果：" + FastJson.fromJson(resultString));

                if (Constants.SUCCESS_CODE.equals(resultMap.get("rspCode"))) {
                    //查询商户已绑定二维码
                    b2cFixedCode = new B2cFixedCode();
                    b2cFixedCode.setMerchantid(merchantNo);
                    List<B2cFixedCode> fixedCodes = fixedCodeMapper.findFixedCodesByParam(b2cFixedCode);

                    //查询二维码信息
                    Map map1 = new HashMap();
                    map1.put("qrCodeNo", qrCodeNo);
                    B2cFixedCode fixedCode = fixedCodeMapper.findFixedCodeByParam(map1);
                    fixedCode.setMerchantid(merchantNo);
                    fixedCode.setBindingDate(new Date());
                    fixedCode.setTel(shopperbi.getStel());
                    fixedCode.setScompany(shopperbi.getScompany());
                    //判断是否已绑定二维码  如果没有绑定过  则二维码设为默认
                    if (fixedCodes == null || fixedCodes.size() == 0) {
                        //设置二维码为默认
                        fixedCode.setIfDefault(Constants.STATUS1);
                    }
                    //修改二维码信息
                    fixedCodeMapper.updateById(fixedCode);

                    //修改商户信息中二维码信息
                    Map map2 = new HashMap();
                    map2.put("fixedQrCodeUrl", getQrCodeUrl(qrCodeNo));
                    map2.put("fixedQrCodeFlag", Constants.CON_YES);
                    map2.put("merchantNo", merchantNo);
                    map2.put("agentNo", fixedCode.getAgentNo());
                    b2cShopperbiMapper.updateQrCode(map2);
                    b2cShopperbiTempMapper.updateQrCode(map2);

                    hashMap.put("rspCode", "0000");
                    hashMap.put("rspMsg", "绑定成功");
                    hashMap.put("qrCodeUrl", getQrCodeUrl(qrCodeNo));
                    return hashMap;
                } else {
                    hashMap.put("rspCode", "2222");
                    hashMap.put("rspMsg", "绑定出错");
                    return hashMap;
                }
            } else {
                hashMap.put("rspCode", resultMap.get("rspCode"));
                hashMap.put("rspMsg", resultMap.get("rspMsg"));
                return hashMap;
            }
        } catch (Exception e) {
            e.printStackTrace();
            hashMap.put("rspCode", "2222");
            hashMap.put("rspMsg", "绑定出错");
            return hashMap;
        }
    }

    /**
     * 终端绑定
     *
     * @param request
     * @return
     */
    public HashMap appOpenRegService(HttpServletRequest request) {
        HashMap hashMap = new HashMap();
        String version = request.getParameter("version");
        String type = request.getParameter("type");
        String tel = request.getParameter("tel") == null ? "" : request.getParameter("tel");
        B2cShopperbiTemp b2cShopperbiTemp = b2cShopperbiTempMapper.findByTel(tel);
        if (!Constants.TYPE_1.equals(b2cShopperbiTemp.getHfflg()) && !Constants.TYPE_1.equals(b2cShopperbiTemp.getHkflg())) {
        	Log.info("终端绑定：弘付海科都未报备！");
            hashMap.put("rspCode", MessageEnum.上游未报备.getCode());
            hashMap.put("rspMsg", MessageEnum.上游未报备.getText());
            return hashMap;
        }
        try {
            if (Constants.TYPE_A.equals(type)) { //安卓
                hashMap = boundDevienNoAndroid200(request);
            } else { //ios
                hashMap = boundDevienNoISO200(request);
            }
			if(null != hashMap.get("rspCode") && !Constants.SUCCESS_CODE.equals(hashMap.get("rspCode"))){
				return hashMap;
			}
            Map resultMap = regMposAndQrcode.activateMposAndQrcode(b2cShopperbiTemp);//激活
            String rspCode = (String) resultMap.get("rspCode");
            String qrpayRspCode = (String) resultMap.get("qrpayRspCode");
            if (Constants.SUCCESS_CODE.equals(rspCode) && Constants.SUCCESS_CODE.equals(qrpayRspCode)) {
                b2cShopperbiTemp.setIfactivated(Constants.CON_YES);
                b2cShopperbiTemp.setIfactivadate(new Date());
				b2cShopperbiTemp.setTransact(Constants.TYPE_2);//已激活
                updateActiveStatus(b2cShopperbiTemp);
            } else {
                hashMap.put("rspCode", MessageEnum.激活商户失败.getCode());
                hashMap.put("rspMsg", MessageEnum.激活商户失败.getText());
            }
        } catch (Exception e) {
            hashMap.put("rspCode", "2222");
            hashMap.put("rspMsg", "出错");
            return hashMap;
        }
        return hashMap;
    }

	/**
	 * 更新商户激活状态
	 * @param b2cShopperbiTemp
	 */
	private void updateActiveStatus(B2cShopperbiTemp b2cShopperbiTemp){
		b2cShopperbiTempMapper.updateShopperActive(b2cShopperbiTemp);
		b2cShopperbiMapper.updateShopperActive(b2cShopperbiTemp);
	}
	
	/**绑定终端iso
	 * @param request
	 * @throws Exception
	 */
	private HashMap boundDevienNoISO200(HttpServletRequest request) throws Exception {
		HashMap hashMap=new HashMap();
		try {
			String tel=request.getParameter("tel") == null ? "" : request.getParameter("tel");
			String deviceNum=request.getParameter("deviceNum")==null?"":request.getParameter("deviceNum");
			System.out.println("绑定终端："+"tel:	"+tel+"	deviceNum:"+deviceNum);
			B2cTermBinder termno=null;
			if(org.apache.commons.lang.StringUtils.isEmpty(deviceNum)){
				 hashMap.put("rspCode", "1001");
				 hashMap.put("rspMsg", "设备号为空");
				 return hashMap;
			 }else{
				 List<B2cShopperbiTemp> shopperbiTemps =shopperbiTempMapper.findbytel(tel);
				 B2cShopperbiTemp shopper = null;
				 if(shopperbiTemps != null && shopperbiTemps.size() > 0){
					 shopper = shopperbiTemps.get(0);
				 }
				 
				 termno = b2cTermBinderMapper.findB2cTermBinderByTermNo(deviceNum.trim());
				 if(termno == null || (termno.getAgent_no() ==null || "".equals(termno.getAgent_no()))){
					 hashMap.put("rspCode", "1002");
					 hashMap.put("rspMsg", "该终端未入库，请联系所属服务商或客服！");
					 return hashMap;
				 }
				 if(Constants.CON_YES.equals(termno.getInventory_status())){
					 hashMap.put("rspCode", "1003");
					 hashMap.put("rspMsg", "已注销的设备不能进行绑定!");
					 return hashMap;
				 }
				 
				 if(shopper != null){
					 if(termno.getMerchantNo() != null){
						 if(!termno.getMerchantNo().equals(shopper.getShopperid())){
							 hashMap.put("rspCode", "1004");
							 hashMap.put("rspMsg", "该终端已绑定其他设备");
							 return hashMap;
						 }
					 }
					 if(null != shopper.getShopperidP() && !"".equals(String.valueOf(shopper.getShopperidP()))){
						 if(!String.valueOf(shopper.getShopperidP()).equals(termno.getAgent_no())){
							 hashMap.put("rspCode", "1007");
							 hashMap.put("rspMsg", "请绑定所属服务商设备!");
							 return hashMap;
						 }
					 }
					 String shopperid=shopper.getShopperid().toString();
					 Map returnMap=boundTerminalPort200(request, shopperid, deviceNum, shopper);
					 
					 System.out.println("绑定终端ad*************："+ FastJson.toJson(returnMap));
					 String rspCode=returnMap.get("rspCode")==null?"":returnMap.get("rspCode").toString();
					 String returnMesg=returnMap.get("rspMsg")==null?"":returnMap.get("rspMsg").toString();
					 String terminalNo=returnMap.get("terminalNo")==null?"":returnMap.get("terminalNo").toString();
					 String mianKey=returnMap.get("mianKey")==null?"":returnMap.get("mianKey").toString();
					 if(Constants.SUCCESS_CODE.equals(rspCode)){
                         //hk报备开关
                         if(Constants.CON_YES.equals(acmsMapUtils.getAcmsMap().get("hk_open_flg"))) {
                             //调用海科终端主密钥报备
                             String hkCOde=hkMerchantUtils.addHkTerminalPort(shopperid,terminalNo,mianKey);
                             if(!"00".equals(hkCOde)){
								 Log.info("终端绑定：海科报备失败！");
                                 hashMap.put("rspCode", hkCOde);
                                 hashMap.put("rspMsg", "绑定失败" );
                                 return hashMap;
                             }
                         }
                         updateTermBinder(shopper,termno);

                         //调用修改代理商接口
                         Map params = new HashMap();
                         params.put("merchantNo", shopper.getShopperid());
                         params.put("agentNo", termno.getAgent_no());
                         net.sf.json.JSONObject obs = net.sf.json.JSONObject.fromObject(params);
                         System.out.println("修改代理商请求参数:"+obs.toString());
                         String resultString = HttpClientUtils.REpostRequestStrJson(
                                 ConstantsEnv.MPOS_AGENT_UPDATE_URL, obs.toString());
                         Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);
                         System.out.println("MPOS_ACCOUNT修改代理商请求结果："+ FastJson.fromJson(resultString));

                         resultString = HttpClientUtils.REpostRequestStrJson(ConstantsEnv.QRCODE_AGENT_UPDATE_URL, obs.toString());
                         resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);
                         System.out.println("QR_CODE修改代理商请求结果："+ FastJson.fromJson(resultString));

                         if(Constants.SUCCESS_CODE.equals(resultMap.get("rspCode"))){
                             hashMap.put("rspCode", "0000");
                             hashMap.put("rspMsg", "绑定成功");
                             hashMap.put("ifHavaAgent","1");
                             return hashMap;
                         }else{
                             hashMap.put("rspCode", "1006");
                             hashMap.put("rspMsg", "绑定失败");
                             return hashMap;
                         }
					}else{
						 hashMap.put("rspCode", rspCode);
						 hashMap.put("rspMsg", returnMesg);
						 return hashMap;
					}
				 }else{
					 hashMap.put("rspCode", "1005");
					 hashMap.put("rspMsg", "商户不存在");
					 return hashMap;
				 }
			 }
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "出错");
			return hashMap;
		}
	}
	/**绑定终端
	 * @param request
	 * @throws Exception
	 */
	private HashMap boundDevienNoAndroid200(HttpServletRequest request) throws Exception {
		HashMap hashMap=new HashMap();
		try {
			String tel=request.getParameter("tel") == null ? "" : request.getParameter("tel");
			String deviceNum=request.getParameter("deviceNum")==null?"":request.getParameter("deviceNum");
			System.out.println("绑定终端："+"tel:	"+tel+"	deviceNum:"+deviceNum);
			B2cTermBinder termno=null;
			if(org.apache.commons.lang.StringUtils.isEmpty(deviceNum)){
				 hashMap.put("rspCode", "1001");
				 hashMap.put("rspMsg", "设备号为空");
				 return hashMap;
			 }else{
				 List<B2cShopperbiTemp> shopperbiTemps =shopperbiTempMapper.findbytel(tel);
				 B2cShopperbiTemp shopper = null;
				 if(shopperbiTemps != null && shopperbiTemps.size() > 0){
					 shopper = shopperbiTemps.get(0);
				 }
				 
				 termno = b2cTermBinderMapper.findB2cTermBinderByTermNo(deviceNum.trim());
				 if(termno == null || (termno.getAgent_no() ==null || "".equals(termno.getAgent_no()))){
					 hashMap.put("rspCode", "1002");
					 hashMap.put("rspMsg", "该终端未入库，请联系所属服务商或客服！");
					 return hashMap;
				 }
				 if(Constants.CON_YES.equals(termno.getInventory_status())){
					 hashMap.put("rspCode", "1003");
					 hashMap.put("rspMsg", "已注销的设备不能进行绑定!");
					 return hashMap;
				 }
				 
				 if(shopper != null){
					 if(termno.getMerchantNo() != null){
						 if(!termno.getMerchantNo().equals(String.valueOf(shopper.getShopperid()))){
							 hashMap.put("rspCode", "1004");
							 hashMap.put("rspMsg", "该终端已绑定其他设备");
							 return hashMap;
						 }
					 }
					 if(null != shopper.getShopperidP() && !"".equals(String.valueOf(shopper.getShopperidP()))){
						 if(!String.valueOf(shopper.getShopperidP()).equals(termno.getAgent_no())){
							 hashMap.put("rspCode", "1007");
							 hashMap.put("rspMsg", "请绑定所属服务商设备!");
							 return hashMap;
						 }
					 }
					 String shopperid=shopper.getShopperid().toString();
					 Map returnMap=boundTerminalPort200(request, shopperid, deviceNum, shopper);
					 net.sf.json.JSONObject ob= net.sf.json.JSONObject.fromObject(returnMap);
					 System.out.println("绑定终端ad*************："+ob.toString());
					 String rspCode=ob.get("rspCode")==null?"":ob.get("rspCode").toString();
					 String returnMesg=ob.get("rspMsg")==null?"":ob.get("rspMsg").toString();
					 String terminalNo=ob.get("terminalNo")==null?"":ob.get("terminalNo").toString();
					 String mianKey=ob.get("mianKey")==null?"":ob.get("mianKey").toString();
					 if(Constants.SUCCESS_CODE.equals(rspCode)){
					     //hk报备开关
						 if(Constants.CON_YES.equals(acmsMapUtils.getAcmsMap().get("hk_open_flg"))){
                             //调用海科终端主密钥报备
                             String hkCOde=hkMerchantUtils.addHkTerminalPort(shopperid,terminalNo,mianKey);
                             if(!"00".equals(hkCOde)){
                             	 Log.info("终端绑定：海科报备失败！");
                                 hashMap.put("rspCode", hkCOde);
                                 hashMap.put("rspMsg", "绑定失败" );
                                 return hashMap;
                             }
						 }
                         updateTermBinder(shopper,termno);

                         //调用修改代理商接口
                         Map params = new HashMap();
                         params.put("merchantNo", shopper.getShopperid());
                         params.put("agentNo", termno.getAgent_no());
                         net.sf.json.JSONObject obs = net.sf.json.JSONObject.fromObject(params);
                         System.out.println("修改代理商请求参数:"+obs.toString());
                         String resultString = HttpClientUtils.REpostRequestStrJson(
                                 ConstantsEnv.MPOS_AGENT_UPDATE_URL, obs.toString());
                         Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);
                         System.out.println("MPOS_ACCOUNT修改代理商请求结果："+ FastJson.fromJson(resultString));

                         resultString = HttpClientUtils.REpostRequestStrJson(ConstantsEnv.QRCODE_AGENT_UPDATE_URL, obs.toString());
                         resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);
                         System.out.println("QR_CODE修改代理商请求结果："+ FastJson.fromJson(resultString));
                         if(Constants.SUCCESS_CODE.equals(resultMap.get("rspCode"))){
                             hashMap.put("rspCode", "0000");
                             hashMap.put("rspMsg", "绑定成功");
                             hashMap.put("ifHavaAgent","1");
                             return hashMap;
                         }else{
                             hashMap.put("rspCode", "1006");
                             hashMap.put("rspMsg", "绑定失败");
                             return hashMap;
                         }
					}else{
							hashMap.put("rspCode", rspCode);
						 hashMap.put("rspMsg", returnMesg);
						 return hashMap;
					}
				 }else{
					 hashMap.put("rspCode", "1005");
					 hashMap.put("rspMsg", "商户不存在");
					 return hashMap;
				 }
			 }
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "出错");
			return hashMap;
		}
	}
	
	/**
	 * @param shopper
	 * @param termno
	 */
	public void updateTermBinder(B2cShopperbiTemp shopper, B2cTermBinder termno) {
		
		termno.setUpdate_date(new Date());
		termno.setUpdate_user(shopper.getShopperid()==null?"":shopper.getShopperid().toString());
		termno.setMerchantNo(shopper.getShopperid()==null?"":shopper.getShopperid().toString());
		termno.setStatus(Constants.CON_NO);
		/*termno.setAgent_no(shopper.getShopperidP()==null?"":shopper.getShopperidP().toString());*/
		termno.setBinder_date(new Date());
		termno.setBinder_user(shopper.getShopperid() == null ? "" : shopper.getShopperid().toString());
		
		TerminalHistory terminalHistory=new TerminalHistory();
		terminalHistory.setCreateDate(new Date());
		terminalHistory.setCreateUser(shopper.getShopperid() == null ? "" : shopper.getShopperid().toString());
		terminalHistory.setStatus(Constants.STATUS3);
		terminalHistory.setTermNo(termno.getTermNo());
		
		updateOrInsert(termno, terminalHistory);
	}
	private void updateOrInsert(B2cTermBinder termno,
			TerminalHistory terminalHistory) {
		B2cTermBinder b2cTermBinder = b2cTermBinderMapper.findTermBatchByTermNo(termno.getTermNo());
		String agentNo = b2cTermBinder.getAgent_no();
		
		B2cShopperbiTemp b2cShopperbiTemp = new B2cShopperbiTemp();
		b2cShopperbiTemp.setShopperid(Long.valueOf(termno.getMerchantNo()));
		b2cShopperbiTemp.setShopperidP(Long.valueOf(termno.getAgent_no()));
		
		b2cShopperbiMapper.updateShoppbiTemp(b2cShopperbiTemp);
		shopperbiTempMapper.updateByShopperId(b2cShopperbiTemp);
		
		b2cTermBinderMapper.updateBundling(termno);
		terminalHistoryMapper.insertSelective(terminalHistory);
	}

	
	/**
	 * @param merchantNo
	 * @return
	 */
	public B2cTermBinder getDiveceNo(String merchantNo) {
		List list=b2cTermBinderMapper.findDiveceNo(merchantNo);
		B2cTermBinder b2cTermBinder=null;
		if(list!=null&&list.size()>0){
			b2cTermBinder=(B2cTermBinder)list.get(0);
		}
		return b2cTermBinder;
	}
	
	
	/**
	 * 商户认证
	 * @return
	 * @throws Exception 
	 */
	public HashMap merchantCA(HttpServletRequest request) throws Exception {
		HashMap hashMap = new HashMap();
		String tel = request.getParameter("tel") == null ? "" : request.getParameter("tel").trim(); //手机号码
		String city = request.getParameter("city") == null ? "" : request.getParameter("city").trim(); //经营城市
		String province = request.getParameter("province") == null ? "" : request.getParameter("province").trim(); //经营省份
		String industryType = request.getParameter("industryType") == null ? "" : request.getParameter("industryType").trim(); //行业类型
		String merchantType = request.getParameter("merchantType") == null ? "" : request.getParameter("merchantType").trim(); //商户类型(0:个人 1:企业)

		String address = request.getParameter("address") == null ? "" : request.getParameter("address").trim(); //经营地址
		String scompany = request.getParameter("scompany") == null ? "" : request.getParameter("scompany").trim(); //商户名称
		String longitude = request.getParameter("longitude") == null ? "" : request.getParameter("longitude").trim(); //经度
		String latitude = request.getParameter("latitude") == null ? "" : request.getParameter("latitude").trim(); //纬度
		String currentLocation = request.getParameter("currentLocation") == null ? "" : request.getParameter("currentLocation").trim(); //商户当前位置
		String licenseNo=request.getParameter("licenseNo")== null ? ""	: request.getParameter("licenseNo"); //营业执照编号(企业类型才有)
		try {
			if("".equals(tel)){ hashMap.put("rspCode", "1001"); hashMap.put("rspMsg", "手机号码为空"); return hashMap;}
			if("".equals(city)){ hashMap.put("rspCode", "1002"); hashMap.put("rspMsg", "经营城市为空"); return hashMap;}
			if("".equals(province)){ hashMap.put("rspCode", "1003"); hashMap.put("rspMsg", "经营省份为空"); return hashMap;}
			if("".equals(industryType)){ hashMap.put("rspCode", "1004"); hashMap.put("rspMsg", "行业类型为空"); return hashMap;}
			if("".equals(merchantType)){ hashMap.put("rspCode", "1005"); hashMap.put("rspMsg", "商户类型为空"); return hashMap;}
			if("".equals(address)){ hashMap.put("rspCode", "1006"); hashMap.put("rspMsg", "地址为空"); return hashMap;}
			if("".equals(scompany)){ hashMap.put("rspCode", "1007"); hashMap.put("rspMsg", "商户名称为空"); return hashMap;}
			if("".equals(longitude)){ hashMap.put("rspCode", "1008"); hashMap.put("rspMsg", "经度为空"); return hashMap;}
			if("".equals(latitude)){ hashMap.put("rspCode", "1009"); hashMap.put("rspMsg", "纬度为空"); return hashMap;}
			if("".equals(currentLocation)){ hashMap.put("rspCode", "1010"); hashMap.put("rspMsg", "当前位置为空"); return hashMap;}
			if(!"".equals(merchantType) && Constants.STATUS1.equals(merchantType)){
				if("".equals(licenseNo)){ hashMap.put("rspCode", "1011"); hashMap.put("rspMsg", "企业营业执照编号为空"); return hashMap;}	
			}
			
			
			B2cShopperVal shopperVal = new B2cShopperVal();
			shopperVal.setTel(tel);
			List<B2cShopperVal> shopperVals = shopperValMapper.queryByParam(shopperVal);//这是查询商户注册验证表
			if(shopperVals != null && shopperVals.size() > 0){
				shopperVal = shopperVals.get(0);
			}
			//这里验证图片是否上传成功
			List<MposPhotoTmp> mposPhotoTmps = mposPhotoTmpMapper.findbysid(shopperVal==null?null:shopperVal.getIdentityId());
			if(mposPhotoTmps == null || mposPhotoTmps.size() == 0){
				hashMap.put("rspCode", "1012");
				hashMap.put("rspMsg", "照片上传失败");
				return hashMap;
			}
			
			B2cShopperbiTemp shopperbiTemp = new B2cShopperbiTemp();
			shopperbiTemp.setMerchantType(merchantType);
			shopperbiTemp.setIDNo(shopperVal.getIdentityId());
			shopperbiTemp.setStel(shopperVal.getTel());
			shopperbiTemp.setIsSupportT0(Constants.STATUS0);//支持T+0 0支持1不支持
			//获取商户号
			Map map=new HashMap();       
	        map.put("provincial", shopperVal.getCardProvince());
	        map.put("city", shopperVal.getCardCity());
	        List list=(List) areaMapper.findbyareaid(map);
	        Area area=null;
	        if(list!=null&&list.size()>0){
				area=(Area)list.get(0);
				shopperbiTemp.setAccountBankCity(area.getCityname());
				shopperbiTemp.setAccountBankCityCode(area.getCity());
				shopperbiTemp.setAccountbankprov(area.getProvincialname());
				shopperbiTemp.setAccountBankProvCode(area.getProvincial());
			}
			String shopperid = getPosShopperId(area.getCity(), Constants.CON_MCC);
			shopperbiTemp.setShopperid(Long.valueOf(shopperid));
			// 获取行业
			List<B2cDict> b2cDicts = dictMapper.findbyhCname(industryType);
			if(b2cDicts != null && b2cDicts.size() > 0){
				shopperbiTemp.setIndustry(b2cDicts.get(0).getB2cDictId().toString());
			}
			//可以删除的map赋值 上述已经对Map赋值了 不需要第二次赋值
			map.put("provincial", province);
	        map.put("city", city);
			// 所在城市票据
			List list2 = areaMapper.findbyareaid(map);
			if(list2 != null && list2.size() > 0){
				Area area2 = (Area) list2.get(0);
				shopperbiTemp.setBillCity(area2.getCityname());
				shopperbiTemp.setScity(area2.getCityname());
				shopperbiTemp.setBillCityCode(area2.getCity());
				shopperbiTemp.setCity(area2.getCity());
				shopperbiTemp.setBillProvince(area2.getProvincialname());
				shopperbiTemp.setSprovince(area2.getProvincialname());
				shopperbiTemp.setBillProvinceCode(area2.getProvincial());
				shopperbiTemp.setProvince(area2.getProvincial());
			}
			// 票据地址
			shopperbiTemp.setBillAddress(address);
			// 票据名称
			shopperbiTemp.setSaddress(address);
			// 0：个人 1企业
			if (merchantType.equals(Constants.TYPE_1)) {
				shopperbiTemp.setScompany(scompany);
				shopperbiTemp.setName(shopperVal.getName());// 姓名
				shopperbiTemp.setLicenseno(licenseNo);
				shopperbiTemp.setLicenseNo(licenseNo);
				shopperbiTemp.setFixqrcodecustomername(scompany);
			} else {
				shopperbiTemp.setScompany(shopperVal.getName());
				shopperbiTemp.setName(shopperVal.getName());
				shopperbiTemp.setFixqrcodecustomername(Constants.FIX_NAME+shopperVal.getName().substring(0, 1)+"**");
			}
			shopperbiTemp.setIsexternalrevenue(Constants.CON_NO);

			//获取商户邀请码
			String inviteCode = getShopperInviteCode();
			shopperbiTemp.setInviteCode(inviteCode);
			shopperbiTemp.setInviteCodeP(shopperVal.getInviteCodeP()); //上级商户邀请码
			shopperbiTemp.setShopperidP(shopperVal.getShopperidP() == null ? null : shopperVal.getShopperidP());
			shopperbiTemp.setSagentid(shopperVal.getShopperidP() == null ? null : shopperVal.getShopperidP());
			shopperbiTemp.setAccountbankclientname(shopperVal.getName());// 开户人姓名
			shopperbiTemp.setAccountbankno(shopperVal.getBankCard());// 卡号
			shopperbiTemp.setAccountbankdictval(shopperVal.getBankCode());// 开户行名称数据字典
			shopperbiTemp.setAccountbankname(shopperVal.getBranchBankName());// 支行名称
			shopperbiTemp.setReportResource(Constants.TYPE_4);// 开放注册
			shopperbiTemp.setCreated(new Date());
			String password = Md5Encrypt.md5(shopperVal.getPassword().trim());
			shopperbiTemp.setMuserid(tel);
			shopperbiTemp.setMpassword(password);
			// 默认添加字段
			shopperbiTemp.setIfvalid(Short.valueOf(Constants.STATUS0));
			shopperbiTemp.setOpencheckstatus(Short.valueOf(Constants.STATUS0));
			shopperbiTemp.setIsformal(Short.valueOf(Constants.STATUS0));
			shopperbiTemp.setIsupdateshopper(Short.valueOf(Constants.STATUS0));
			shopperbiTemp.setSifpactid(Long.valueOf(Constants.STATUS0));
			shopperbiTemp.setRecheckmerchantflag(Constants.STATUS0);
			shopperbiTemp.setPhotoCheckFlag(Constants.STATUS0);
			shopperbiTemp.setPhotoRecheckFlag(Constants.STATUS0);
			shopperbiTemp.setTransact(Constants.STATUS1);
			shopperbiTemp.setLatitude(latitude);
			shopperbiTemp.setLongitude(longitude);
			shopperbiTemp.setCurrentLocation(currentLocation);
			
			shopperbiTemp.setT0topamount(Double.parseDouble(Constants.MONEY_0));
			shopperbiTemp.setT1type(Constants.STATUS0);
			shopperbiTemp.setT0type(Constants.STATUS0);
			shopperbiTemp.setCardType(Constants.STATUS0);
			shopperbiTemp.setT0additionfee(Double.parseDouble(Constants.MONEY_0));
			shopperbiTemp.setT1topamount(Double.parseDouble(Constants.MONEY_0));
			shopperbiTemp.setIsIcApplyT0(Constants.STATUS0);
			shopperbiTemp.setT0minamount(Double.parseDouble(Constants.MONEY_197));
			shopperbiTemp.setT0maxamount(Double.parseDouble(Constants.MIN_SETTLE_MONEY));
			shopperbiTemp.setT0SingleDayLimit(Double.parseDouble(Constants.MIN_SETTLE_MONEY));
			shopperbiTemp.setSettleType(Constants.CON_YES);//1是普通
			shopperbiTemp.setCreditLines(Double.parseDouble(Constants.MIN_SETTLE_MONEY));//扫码授信额度5W
			//分润方案
			shopperbiTemp.setAgentProfitRatio(ConstantsEnv.AGENT_PROFIT_RATIO);
			shopperbiTemp.setProfitOwner(ConstantsEnv.PROFIT_OWNER);
			shopperbiTemp.setMerchProfitRatio1(ConstantsEnv.MERCH_PROFIT_RATIO1);
			shopperbiTemp.setMerchProfitRatio2(ConstantsEnv.MERCH_PROFIT_RATIO2);
			shopperbiTemp.setMerchProfitRatio3(ConstantsEnv.MERCH_PROFIT_RATIO3);
			if(mposPhotoTmps != null && mposPhotoTmps.size() > 0){
				shopperbiTemp.setPhotoid(mposPhotoTmps.get(0).getPhotoId());
			}
			// merchantKey值
			String merchantKey = com.uns.util.StringUtils.getCharAndNumr(8);
			shopperbiTemp.setMerchantKey(merchantKey);
			
			String userType = getType(shopperbiTemp.getMerchantType());
			
			//弘付 判断是否开通弘付注册接口:
			//增加判读是否启用弘付注册 1启用 0 不起用
			if(acmsMapUtils.getAcmsMap().get("hf_open_flg").equals(Constants.CON_YES)){

				//弘付商户信息图片报备
				HfImageRegUtil.hfImagesReg(mposPhotoTmps.get(0), shopperid);

				//海科成功后调弘付,判断是否申请过,0未申请，1已申请去修改
				String respCede;
				String hf_psam_d0;
				net.sf.json.JSONObject jsonObject1 = addHfMerchantPortD0(shopperbiTemp);
				respCede = (String) jsonObject1.get("respCode");
				hf_psam_d0 = (String) jsonObject1.get("hf_psam");
				if(!ConstantsEnv.HF_CODE_ADD.equals(respCede)){
					Log.info("弘付报备申请失败:{}",jsonObject1.toString());
				}else{
					shopperbiTemp.setHfflg(Constants.CON_YES);
					shopperbiTemp.setHfpsamd0(hf_psam_d0);
				}
			}

			String flage = "0000";

			B2cDict b2cDict=dictMapper.findDictBankName(shopperbiTemp.getAccountbankdictval());
			//注册海科
			String hkCOde=ConstantsEnv.HK_SUCCESS_CODE;
			if(acmsMapUtils.getAcmsMap().get("hk_open_flg").equals(Constants.CON_YES)){
				hkCOde = hkMerchantUtils.addHkMerchantPort(shopperbiTemp,b2cDict.getDictcls());
			}
			if(ConstantsEnv.HK_SUCCESS_CODE.equals(hkCOde)){
				flage = saveCreate(request, null, userType, shopperbiTemp, null, null);
			}else if(ConstantsEnv.HK_REPEAT_CODE_H2.equals(hkCOde)){
				String updateHkCOde=hkMerchantUtils.updateHkMerchantPort(shopperbiTemp, b2cDict.getDictcls());
				if(!(ConstantsEnv.RESPONSE_CODE.equals(updateHkCOde))){
					Log.info("海科注册修改失败:" + hkCOde);
					hashMap.put("rspCode","6015");
					hashMap.put("rspMsg","注册失败");
					return hashMap;
				}else{
					//注册 mpos 
					flage = saveCreate(request, null, userType, shopperbiTemp, null, null);
				}
			}else{
				Log.info("海科注册新增失败:" + hkCOde);
				hashMap.put("rspCode","6015");
				hashMap.put("rspMsg","注册失败");
				return hashMap;
			}
			
			if(Constants.SUCCESS_CODE.equals(flage)){
				//注册扫码
				Map qrcodeMap=saveQrCode(request, null, userType, shopperbiTemp);
				if(Constants.SUCCESS_CODE.equals(qrcodeMap.get("flag"))){
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "注册成功");
					hashMap.put("shopperid", shopperid);
					hashMap.put("scompany", shopperbiTemp.getScompany());
					hashMap.put("merchantKey", merchantKey);
					hashMap.put("qrpayMerchantkey", qrcodeMap.get("qrpayMerchantkey"));
				}else{
					System.out.println("扫码支付注册失败");
					hashMap.put("rspCode", "0000");
					hashMap.put("rspMsg", "注册成功");
					hashMap.put("shopperid", shopperid);
					hashMap.put("scompany", shopperbiTemp.getScompany());
					hashMap.put("merchantKey", merchantKey);
					hashMap.put("qrpayMerchantkey", "");
				}
			}else if("6012".equals(flage)){
				hashMap.put("rspCode", "6012");
				hashMap.put("rspMsg", "实名认证失败");
			}else if("6013".equals(flage)){
				hashMap.put("rspCode", "6013");
				hashMap.put("rspMsg", "注册银生宝失败");
			}else if("1014".equals(flage)){
				hashMap.put("rspCode", "1014");
				hashMap.put("rspMsg", "已注册成功，请登录!");
			}else{
				hashMap.put("rspCode", "6014");
				hashMap.put("rspMsg", "注册银生宝失败!");
			}
			return hashMap;
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "注册出错");
			return hashMap;
		}
	}

	private String getShopperInviteCode() {
		String inviteCode = "";
		List<String> inviteCodes = b2cShopperbiMapper.findAllInviteCode();
		while (1 == 1){
			String inviteCode1 = RandomStringUtils.random(2, "ABCDEFGHJKMNPQRSTUVWXYZ");
			String inviteCode2 = String.valueOf((int)((Math.random()*9+1)*100000));
			inviteCode=inviteCode1+inviteCode2;
			if (!inviteCodes.contains(inviteCode)){
				break;
			}
		}
		return inviteCode;
	}

	

	

	/**
	 * 注册扫码支付
	 * @param response 
	 * @param request 
	 * @param request
	 * @param response
	 * @param userType
	 * @param b2cShopperbi
	 * @return
	 * @throws Exception
	 */
	public Map saveQrCode(HttpServletRequest request, HttpServletResponse response, String userType,
			B2cShopperbiTemp b2cShopperbi) throws Exception {
		Map map=new HashMap();
		//扫码支付
		String flag="";
		Map qrMap=saveQrPay(userType, b2cShopperbi);
		if(Constants.SUCCESS_CODE.equals(qrMap.get("rspCode"))){
				String qrPayNo=qrMap.get("qrPayNo")==null?"":qrMap.get("qrPayNo").toString();
				String qrpayMerchantkey=qrMap.get("qrpayMerchantkey")==null?"":qrMap.get("qrpayMerchantkey").toString();
				b2cShopperbi.setQrPayNo(qrPayNo);//扫码支付的账号
				b2cShopperbi.setQrpayMerchantkey(qrpayMerchantkey);//扫码支付的密钥
				
				Map map1=new HashMap();
				map1.put("qrPayNo", b2cShopperbi.getQrPayNo());
				map1.put("qrpayMerchantkey", b2cShopperbi.getQrpayMerchantkey());
				map1.put("merchantNo", b2cShopperbi.getShopperid());
				map1.put("settleType", b2cShopperbi.getSettleType());//默认扫码1普通
				map1.put("creditLines", b2cShopperbi.getCreditLines());//扫码授信额度
				
				
				
				b2cShopperbiMapper.updateQrPayCode(map1);//修改正式表添加扫码支付的账号和密钥
				shopperbiTempMapper.updateQrPayCode(map1);//修改临时表添加扫码支付的账号和密钥
				
				map.put("flag", "0000");
				map.put("qrPayNo", qrPayNo);
				map.put("qrpayMerchantkey", qrpayMerchantkey);
				flag="0000";
				System.out.println("=======扫码支付注册成功!==============");
		}else{
				map.put("flag", "6015");
		}
		return map;
	}
	
	/**扫码支付
	 * @param userType
	 * @param b2cShopperbi
	 * @return
	 * @throws Exception
	 */
	private Map saveQrPay( String userType,
			B2cShopperbiTemp b2cShopperbi) throws Exception {
		String qrpayMerchantkey=RandomStringUtils.random(32, "0123456789ABCDEF");
		b2cShopperbi.setQrpayMerchantkey(qrpayMerchantkey);
		Map map=new HashMap();
		String flag="";
		net.sf.json.JSONObject ob = null;
		String rspCode = "";
		String qrPayNo="";
		// 区分企业还是个人
		Map ysbMap = null;
		if (Constants.TYPE_P.equals(userType)) {
			ysbMap = regQrPayMerchant(b2cShopperbi, userType);
		}
		if (Constants.TYPE_C.equals(userType)) {
			ysbMap = regQrPayCompany(b2cShopperbi, userType);
		}
		System.out.println("扫码支付注册返回码:" + ysbMap);
		ob = net.sf.json.JSONObject.fromObject(ysbMap);
		rspCode = (String) ob.get("rspCode");
		if (Constants.SUCCESS_CODE.equals("6012")) {
			/****/
			map.put("rspCode", rspCode);
			return map;
		} else {
			System.out.println("扫码支付实名认证成功"+ob.toString());
			qrPayNo = (String) ob.get("userId");
			
			map.put("qrPayNo", qrPayNo);
			map.put("qrpayMerchantkey", qrpayMerchantkey);
			map.put("rspCode", rspCode);
			flag=rspCode;
			return map;
		}
	}
	
	/**
	 * 转化商户类型
	 * 
	 * @param merchantType
	 * @return
	 */
	private String getType(String merchantType) {
		String type = "";
		if (Constants.CON_NO.equals(merchantType)) {
			type = Constants.TYPE_P;
		} else {
			type = Constants.TYPE_C;
		}
		return type;
	}
	
	/**扫码支付企业注册
	 * @param b2cShopperbi
	 * @param userType
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	public Map regQrPayCompany(B2cShopperbiTemp b2cShopperbi, String userType) throws Exception {

		HashMap params = new HashMap();
		Date dates = new Date();
		String mradom = RandomStringUtils.randomNumeric(6);
		String orderId = DateUtil.getTypeDate(dates, "yyyyMMdd") + mradom+ b2cShopperbi.getShopperid();
		String orderTime = DateUtil.getTypeDate(dates, "yyyyMMddhhmmss");

		// 基本信息
		String name = b2cShopperbi.getName();
		String idCard = b2cShopperbi.getIDNo();
		String tel = b2cShopperbi.getStel();
		String merchantNo = b2cShopperbi.getShopperid() == null ? "": b2cShopperbi.getShopperid().toString();
		Long agentNo = b2cShopperbi.getShopperidP();
		String institutionNo = b2cShopperbi.getOrgNo();
		String platformType = "";
		
		if (agentNo != null) {
			platformType = Constants.CON_NO;// 0 自有
		} else {
			platformType = Constants.CON_YES;// 机构
		}
		// 结算信息
		String settlementType = b2cShopperbi.getSettlementType();
		String accountBankDictval = b2cShopperbi.getAccountbankdictval();
		String accountbankname = b2cShopperbi.getAccountbankname();
		String accountbankprovCode = b2cShopperbi.getAccountBankProvCode();
		String accountBankCityCode = b2cShopperbi.getAccountBankCityCode();
		String accountbankclientname = b2cShopperbi.getAccountbankclientname();
		String accountbankno = b2cShopperbi.getAccountbankno();

		String superShopperId = "";
		String ifInvite = "0";
		if (StringUtils.isNotEmpty(b2cShopperbi.getInviteCodeP())){
			B2cShopperbiTemp b2cShopperbiTempNew = b2cShopperbiTempMapper.findShopperByInviteCode(b2cShopperbi.getInviteCodeP());
			if(null != b2cShopperbiTempNew){
				superShopperId = b2cShopperbiTempNew.getShopperid().toString();
				ifInvite = "1";
			}
		}

		//省市
		String accountBankCity = b2cShopperbi.getAccountBankCity();
		String accountbankprov = b2cShopperbi.getAccountbankprov();
		// 刷卡手续费
		List merchantFeeList = mposMerchantFeeMapper.findQrPayMerchantFeeList(b2cShopperbi.getShopperid().toString());
		String qrD0fee=mposMerchantFeeMapper.findQrPayMerchantFee(b2cShopperbi.getShopperid().toString());
		String issupportt0 = b2cShopperbi.getIsSupportT0(); // 0支持
		String isicapplyt0 = "";
		Double t0singledaylimit = 0.00;
		if (Constants.CON_NO.equals(issupportt0)) {
			isicapplyt0 = b2cShopperbi.getIsIcApplyT0();
			t0singledaylimit = b2cShopperbi.getT0SingleDayLimit();
			params.put("t0fee", qrD0fee);
			params.put("t0fixedamount", b2cShopperbi.getT0fixedamount());
			params.put("t0minamount", b2cShopperbi.getT0minamount());
			params.put("t0maxamount", b2cShopperbi.getT0maxamount());
			params.put("creditAmount", t0singledaylimit == null ? "": t0singledaylimit);
			params.put("t0singledaylimit", t0singledaylimit == null ? "": t0singledaylimit);
		} else {
			params.put("t0fee", "0");
			params.put("t0fixedamount", "0");
			params.put("t0minamount", "0");
			params.put("t0maxamount", "0");
			params.put("creditAmount", "0");
			params.put("t0singledaylimit", "0");
		}
		params.put("userType", userType == null ? "" : userType);
		params.put("orderId", orderId == null ? "" : orderId);
		params.put("orderTime", orderTime == null ? "" : orderTime);
		params.put("idNum", idCard == null ? "" : idCard);
		params.put("register_corpTel", tel == null ? "" : tel);
		params.put("register_prinName",URLDecoder.decode(name == null ? "" : name, "UTF-8"));
		params.put("prov", accountbankprovCode == null ? "": accountbankprovCode);
		params.put("city", accountBankCityCode == null ? ""	: accountBankCityCode);
		String bankCode = dictMapper.findDictBankName(b2cShopperbi.getAccountbankdictval()) == null ? "" :
		URLDecoder.decode(dictMapper.findDictBankName(b2cShopperbi.getAccountbankdictval()).getDictid(),"UTF-8");
		params.put("bankCode", bankCode);
		params.put("bankNo", accountbankno == null ? "" : accountbankno);
		params.put("bankName",accountbankname == null ? "" : URLDecoder.decode(accountbankname, "UTF-8"));
		params.put("cityName",accountBankCity);
	    params.put("provinceName",accountbankprov);
	    //开户银行
    	String openingBankName=dictMapper.findDictBankName(b2cShopperbi.getAccountbankdictval())==null?"":dictMapper.findDictBankName(b2cShopperbi.getAccountbankdictval()).getDict();
        params.put("openingBankName",openingBankName);
		params.put("register_corpFinanceName", URLDecoder.decode(name, "UTF-8"));
		params.put("linkman",name == null ? "" : URLDecoder.decode(name, "UTF-8"));
		params.put("register_corpLicenceNo",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi	.getLicenseNo());
		params.put("register_corpName", accountbankclientname == null ? "": URLDecoder.decode(accountbankclientname, "UTF-8"));
		params.put("register_email", b2cShopperbi.getSemail() == null ? "": b2cShopperbi.getSemail());
		params.put("register_corpAccountLicenceNo",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi.getLicenseNo());
		params.put("register_corpOrganizeNo",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi.getLicenseNo());
		params.put("register_corpTaxId",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi	.getLicenseNo());
		params.put("register_corpAddr", b2cShopperbi.getSaddress() == null ? ""	: URLDecoder.decode(b2cShopperbi.getSaddress(), "UTF-8"));
		params.put("register_corpZip", b2cShopperbi.getSzip() == null ? "": b2cShopperbi.getSzip());
		params.put("proxyId", agentNo == null ? "" : agentNo);
		params.put("merchantNo", merchantNo == null ? "" : merchantNo);
		params.put("institutionNo", institutionNo == null ? "" : institutionNo);
		//params.put("settlementType", settlementType == null ? "": settlementType);
		params.put("commissionIds", merchantFeeList);
		params.put("issupportt0", issupportt0 == null ? "" : issupportt0);// 是否支持T0提现

		String qrMerchantKey = b2cShopperbi.getQrpayMerchantkey();
		params.put("qrMerchantKey", null==qrMerchantKey?"":qrMerchantKey);
		params.put("agentNo", agentNo);
		
		params.put("fixQrcodePic", "");
		params.put("fixQrcodeCustomerName", b2cShopperbi.getFixqrcodecustomername());
		params.put("isExternalRevenue", b2cShopperbi.getIsexternalrevenue());
		params.put("settleType", Constants.CON_NO);

		params.put("superShopperId", superShopperId); //上级商户ID(裂变)
		params.put("ifInvite", ifInvite); //是否裂变商户（1：是 0：否）

		params.put("settleType", b2cShopperbi.getSettleType());//1是普通
		params.put("creditLines",b2cShopperbi.getCreditLines().toString());//5万
		
		
		//扫码注册睿付添加四个字段
		String unionBankCode = dictMapper.findUnionBankCode(b2cShopperbi.getAccountbankdictval());
		String cityCode = b2cShopperbi.getCity();
		Area area1 = areaMapper.findPayeeBankProvinceAndCity(cityCode);
		
		params.put("merchAddress", b2cShopperbi.getSaddress());//商户地址
		params.put("payeeBankId", unionBankCode);//银行卡所在联行总行号
		params.put("payeeBankProvince", area1.getShProvincial());//睿付开户行省份编码
		params.put("payeeBankCity", area1.getShCity());//睿付开户行城市编码
		
		
		
		
		params.put("profitOwner", b2cShopperbi.getProfitOwner());//分润给那个代理商
		params.put("agentProfitRatio", b2cShopperbi.getAgentProfitRatio()); //代理商分润百分比
		params.put("merchProfitRatio1", b2cShopperbi.getMerchProfitRatio1());//商户分润方案1
		params.put("merchProfitRatio2", b2cShopperbi.getMerchProfitRatio2()); //商户分润方案2
		params.put("merchProfitRatio3", b2cShopperbi.getMerchProfitRatio3()); //商户分润方案3
		net.sf.json.JSONObject obs = net.sf.json.JSONObject.fromObject(params);
		System.out.println("扫码支付企业注册：" + ConstantsEnv.REG_QR_PAY_COMPANY_URL+ obs.toString());
		String resultString = HttpClientUtils.REpostRequestStr1(ConstantsEnv.REG_QR_PAY_COMPANY_URL, obs.toString());
		Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);

		return resultMap;
	
	}
	
	/**扫码支付
	 * @param b2cShopperbi
	 * @param userType
	 * @return
	 * @throws Exception
	 */
	public Map regQrPayMerchant(B2cShopperbiTemp b2cShopperbi, String userType) throws Exception {

		HashMap params = new HashMap();

		Date dates = new Date();
		String mradom = RandomStringUtils.randomNumeric(6);
		String orderId = DateUtil.getTypeDate(dates, "yyyyMMdd") + mradom+ b2cShopperbi.getShopperid();
		String orderTime = DateUtil.getTypeDate(dates, "yyyyMMddhhmmss");
		// 基本信息
		String linkName = b2cShopperbi.getName();
		String idCard = b2cShopperbi.getIDNo();
		String tel = b2cShopperbi.getStel();
		String merchantNo = b2cShopperbi.getShopperid() == null ? "": b2cShopperbi.getShopperid().toString();
		Long agentNo = b2cShopperbi.getShopperidP();
		String institutionNo = b2cShopperbi.getOrgNo();
		String platformType = "";
		platformType = Constants.CON_NO;
		/*if (agentNo != null) {
			platformType = Constants.CON_NO;// 0 自有
		} else {
			platformType = Constants.CON_YES;// 机构
		}*/
		// 结算信息
		String settlementType = b2cShopperbi.getSettlementType();
		String accountbankname = b2cShopperbi.getAccountbankname();
		String accountbankprovCode = b2cShopperbi.getAccountBankProvCode();
		String accountBankCityCode = b2cShopperbi.getAccountBankCityCode();
		String accountbankclientname = b2cShopperbi.getAccountbankclientname();
		String accountbankno = b2cShopperbi.getAccountbankno();

		String superShopperId = "";
		String ifInvite = "0";
		if (StringUtils.isNotEmpty(b2cShopperbi.getInviteCodeP())){
			B2cShopperbiTemp b2cShopperbiTempNew = b2cShopperbiTempMapper.findShopperByInviteCode(b2cShopperbi.getInviteCodeP());
			if(null != b2cShopperbiTempNew){
				superShopperId = b2cShopperbiTempNew.getShopperid().toString();
				ifInvite = "1";
			}
		}

		//省市
		String accountBankCity = b2cShopperbi.getAccountBankCity();
		String accountbankprov = b2cShopperbi.getAccountbankprov();
		// 扫码支付
		List merchantFeeList = mposMerchantFeeMapper.findQrPayMerchantFeeList(b2cShopperbi.getShopperid().toString());
		
		String qrD0fee=mposMerchantFeeMapper.findQrPayMerchantFee(b2cShopperbi.getShopperid().toString());
		
		
		
		// t+0手续费
		String issupportt0 = b2cShopperbi.getIsSupportT0(); // 0支持
		String isicapplyt0 = "";
		Double t0singledaylimit = 0.00;
		if (Constants.CON_NO.equals(issupportt0)) {
			isicapplyt0 = b2cShopperbi.getIsIcApplyT0();
			t0singledaylimit = b2cShopperbi.getT0SingleDayLimit();
			params.put("t0fee", qrD0fee);
			params.put("t0fixedamount", b2cShopperbi.getT0fixedamount());
			params.put("t0minamount", b2cShopperbi.getT0minamount());
			params.put("t0maxamount", b2cShopperbi.getT0maxamount());
			params.put("creditAmount", t0singledaylimit == null ? "": t0singledaylimit);
		} else {
			params.put("t0fee", "0");
			params.put("t0fixedamount", "0");
			params.put("t0minamount", "0");
			params.put("t0maxamount", "0");
			params.put("creditAmount", "0");
		}
		params.put("userType", userType == null ? "" : userType);
		params.put("orderId", orderId == null ? "" : orderId);
		params.put("orderTime", orderTime == null ? "" : orderTime);
		params.put("name",linkName == null ? "" : URLDecoder.decode(linkName, "UTF-8"));
		params.put("idNum", idCard == null ? "" : idCard);
		params.put("mobilePhoneNum", tel == null ? "" : tel);
		String bankCode = this.dictMapper.findDictBankName(b2cShopperbi	.getAccountbankdictval()) == null ? "" : URLDecoder.decode(
				dictMapper.findDictBankName(b2cShopperbi.getAccountbankdictval()).getDictid(),"UTF-8");
		params.put("bankCode", bankCode == null ? "" : bankCode);
		params.put("bankNo", accountbankno == null ? "" : accountbankno);
		params.put("bankName",accountbankname == null ? "" : URLDecoder.decode(accountbankname, "UTF-8"));
		params.put("prov", accountbankprovCode == null ? "": accountbankprovCode);
		params.put("city", accountBankCityCode == null ? "": accountBankCityCode);
		  //开户银行
    	String openingBankName=dictMapper.findDictBankName(b2cShopperbi.getAccountbankdictval())==null?"":dictMapper.findDictBankName(b2cShopperbi.getAccountbankdictval()).getDict();
        params.put("openingBankName",openingBankName);
		params.put("cityName",accountBankCity);
	    params.put("provinceName",accountbankprov);
		params.put("merchantNo", merchantNo == null ? "" : merchantNo);
		params.put("proxyId", agentNo == null ? "" : agentNo);
		params.put("institutionNo", institutionNo == null ? "" : institutionNo);
		params.put("platformType", platformType == null ? "" : platformType);
		//params.put("settlementType", settlementType == null ? "": settlementType);
		params.put("commissionIds", merchantFeeList);
		params.put("issupportt0", issupportt0 == null ? "" : issupportt0);// 是否支持T0提现
		
		String scompany = b2cShopperbi.getScompany();//商户名称
		String qrMerchantKey = b2cShopperbi.getQrpayMerchantkey();//扫码秘钥
		params.put("scompany", null==scompany?"":scompany);
		params.put("qrMerchantKey", null==qrMerchantKey?"":qrMerchantKey);
		params.put("agentNo", agentNo);
		
		
		params.put("fixQrcodePic", "");
		params.put("fixQrcodeCustomerName", b2cShopperbi.getFixqrcodecustomername());
		params.put("isExternalRevenue", b2cShopperbi.getIsexternalrevenue());

		params.put("superShopperId", superShopperId); //上级商户ID(裂变)
		params.put("ifInvite", ifInvite); //是否裂变商户（1：是 0：否）

		params.put("settleType", b2cShopperbi.getSettleType());//1是普通
		params.put("creditLines",b2cShopperbi.getCreditLines().toString());//5万
		
		params.put("profitOwner", b2cShopperbi.getProfitOwner());//分润给那个代理商
		params.put("agentProfitRatio", b2cShopperbi.getAgentProfitRatio()); //代理商分润百分比
		params.put("merchProfitRatio1", b2cShopperbi.getMerchProfitRatio1());//商户分润方案1
		params.put("merchProfitRatio2", b2cShopperbi.getMerchProfitRatio2()); //商户分润方案2
		params.put("merchProfitRatio3", b2cShopperbi.getMerchProfitRatio3()); //商户分润方案3
		
		
		//扫码注册睿付添加四个字段
		String unionBankCode = dictMapper.findUnionBankCode(b2cShopperbi.getAccountbankdictval());
		String cityCode = b2cShopperbi.getCity();
		Area area1 = areaMapper.findPayeeBankProvinceAndCity(cityCode);
		
		params.put("merchAddress", b2cShopperbi.getSaddress());//商户地址
		params.put("payeeBankId", unionBankCode);//银行卡所在联行总行号
		params.put("payeeBankProvince", area1.getShProvincial());//睿付开户行省份编码
		params.put("payeeBankCity", area1.getShCity());//睿付开户行城市编码
		
		
		net.sf.json.JSONObject obs = net.sf.json.JSONObject.fromObject(params);
		System.out.println("注册扫码支付个人：" + ConstantsEnv.REG_QR_PAY_MERCHANT_URL + obs.toString());
		String resultString = HttpClientUtils.REpostRequestStr1(
				ConstantsEnv.REG_QR_PAY_MERCHANT_URL, obs.toString());
		Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);

		return resultMap;
	
	}
	
	public String saveCreate(HttpServletRequest request, HttpServletResponse response, 
			String userType, B2cShopperbiTemp b2cShopperbi,
			MposApplicationProgress progress,
			MposRemoteInvitation mposRemoteInvitation) throws Exception{
		String flag="";
		net.sf.json.JSONObject ob = null;
		String rspCode = "";
		String ysbNo = "";
		String factoringNo = "";
		insertMerchantFeeList(b2cShopperbi.getShopperid().toString());
		
	
		
		// 区分企业、个人 还是商户
		Map ysbMap = null;
		if (Constants.TYPE_P.equals(userType)) {
			ysbMap = regMerchant(b2cShopperbi, userType);
		} else if(Constants.TYPE_S.equals(userType)){
            ysbMap = regCustomer(b2cShopperbi, userType);
        } else{
			ysbMap = regCompany(b2cShopperbi, userType);
		}
		
		System.out.println("银生宝注册返回码:" + ysbMap);
		ob = net.sf.json.JSONObject.fromObject(ysbMap);
		rspCode = (String) ob.get("rspCode");
		if (Constants.SUCCESS_CODE.equals(rspCode)) {
			ysbNo = (String) ob.get("userId");
			factoringNo = (String) ob.get("factor_userId");
			b2cShopperbi.setYsbNo(ysbNo);
			b2cShopperbi.setFactoringno(factoringNo);
			// 通过后注册
			b2cShopperbi.setOpen_mpos_create_date(new Date());
			flag = saveshopper(b2cShopperbi,progress,mposRemoteInvitation);
			return flag;
		} else {
			if (rspCode.equals("6012")) {
				System.out.println("实名认证失败6012");
				flag="6012";
				return flag;
			} else if(rspCode.equals("6013")){
				System.out.println("实名认证失败6013");
				flag="6013";
				return flag;
				
			}else if(rspCode.equals("6014")){
				System.out.println("实名认证失败6014");
				flag="6014";
				return flag;
			}
		}
		return flag;
	}
	
	public String saveshopper(B2cShopperbiTemp shopperbiTemp,
			MposApplicationProgress progress,
			MposRemoteInvitation remote1){
		
		List b2cShopperbiList = b2cShopperbiMapper.findtelbytel(shopperbiTemp.getStel());
		if(b2cShopperbiList == null || b2cShopperbiList.size() == 0){
			shopperbiTemp.setIsformal(new Short(Constants.STATUS1));
			Users user = new Users();
			Users usres=saveUsers(user,shopperbiTemp);
			
			usersMapper.insert(usres);
			shopperbiTempMapper.insert(shopperbiTemp);
	  		b2cShopperbiMapper.insert(shopperbiTemp);
	  		if(progress!=null){
	  			progressmapper.insertSelective(progress);
	  		}
	  		if(remote1!=null){
	  			remotemapper.updateByPrimaryKeySelective(remote1);
	  		}
			
	  		/*shopperbiTempMapper.updateBankInfo(b2cShopperbi);*/
		}
		return "0000";
	}
	
	/**保存用户名密码
	 * @param user
	 * @param b2cShopperbi
	 * @return
	 */
	private Users saveUsers(Users user, B2cShopperbiTemp b2cShopperbi) {
		user.setMerchantid(b2cShopperbi.getShopperid());
		user.setUserName(b2cShopperbi.getMuserid());
		user.setPassword(b2cShopperbi.getMpassword());
		user.setTel(b2cShopperbi.getStel());
		user.setEnabled(Short.valueOf(Constants.CON_YES));
		user.setCreatedate(new Date());
		user.setLocked(Long.valueOf(b2cShopperbi.getSifpactid()==null? Constants.CON_NO:b2cShopperbi.getSifpactid().toString()));
		user.setIsAgent(Short.valueOf(Constants.CON_NO));
		return user;
	}
	
	/**
	 * 个人商户注册（注册参数）
	 *
	 * @param b2cShopperbi
	 * @return
	 * @throws Exception
	 */
	private Map regCustomer(B2cShopperbiTemp b2cShopperbi, String userType)
			throws Exception {
        HashMap params = new HashMap();
        Date dates = new Date();
        String mradom = RandomStringUtils.randomNumeric(6);
        String orderId = DateUtil.getTypeDate(dates, "yyyyMMdd") + mradom+ b2cShopperbi.getShopperid();
        String orderTime = DateUtil.getTypeDate(dates, "yyyyMMddhhmmss");

        // 基本信息
        String name = b2cShopperbi.getName();
        String idCard = b2cShopperbi.getIDNo();
        String tel = b2cShopperbi.getStel();
        String merchantNo = b2cShopperbi.getShopperid() == null ? "": b2cShopperbi.getShopperid().toString();
        Long agentNo = b2cShopperbi.getShopperidP();
        String institutionNo = b2cShopperbi.getOrgNo();
        String platformType = "";
        if (agentNo != null) {
            platformType = Constants.CON_NO;// 0 自有
        } else {
            platformType = Constants.CON_YES;// 机构
        }
        // 结算信息
        String settlementType = b2cShopperbi.getSettlementType();
        String accountBankDictval = b2cShopperbi.getAccountbankdictval();
        String accountbankname = b2cShopperbi.getAccountbankname();
        String accountbankprovCode = b2cShopperbi.getAccountBankProvCode();
        String accountBankCityCode = b2cShopperbi.getAccountBankCityCode();
        String accountbankclientname = b2cShopperbi.getAccountbankclientname();
        String accountbankno = b2cShopperbi.getAccountbankno();

        String superShopperId = "";
        String ifInvite = "0";
        if (StringUtils.isNotEmpty(b2cShopperbi.getInviteCodeP())){
            B2cShopperbiTemp b2cShopperbiTempNew = b2cShopperbiTempMapper.findShopperByInviteCode(b2cShopperbi.getInviteCodeP());
            if(null != b2cShopperbiTempNew){
                superShopperId = b2cShopperbiTempNew.getShopperid().toString();
                ifInvite = "1";
            }
        }

        // 刷卡手续费
        List merchantFeeList = mposMerchantFeeMapper.findmerchantFeeList(b2cShopperbi.getShopperid().toString());
        // t1type
        params.put("t1Type", b2cShopperbi.getT1type()==null?"0":b2cShopperbi.getT1type());
        params.put("t1topamount", b2cShopperbi.getT1topamount() == null ? "0": b2cShopperbi.getT1topamount());// t+1提现手续费
        // t+0手续费
        String issupportt0 = b2cShopperbi.getIsSupportT0(); // 0支持
        String isicapplyt0 = "";
        Double t0singledaylimit = 0.00;
        if (Constants.CON_NO.equals(issupportt0)) {
            isicapplyt0 = b2cShopperbi.getIsIcApplyT0();
            t0singledaylimit = b2cShopperbi.getT0SingleDayLimit();
            params.put("t0Type", b2cShopperbi.getT0type()==null?"0":b2cShopperbi.getT0type());
            params.put("t0fee", Constants.T0_FEE);
            params.put("t0fixedamount", Constants.T0_FIXED_AMOUNT);
            params.put("t0minamount", b2cShopperbi.getT0minamount());
            params.put("t0maxamount", b2cShopperbi.getT0maxamount());
            params.put("creditAmount", t0singledaylimit == null ? "": t0singledaylimit);
            params.put("t0singledaylimit", t0singledaylimit == null ? "": t0singledaylimit);
        } else {
            params.put("t0Type", "0");
            params.put("t0fee", "0");
            params.put("t0fixedamount", "0");
            params.put("t0minamount", "0");
            params.put("t0maxamount", "0");
            params.put("creditAmount", "0");
            params.put("t0singledaylimit", "0");
        }
        params.put("userType", userType == null ? "" : userType);
        params.put("orderId", orderId == null ? "" : orderId);
        params.put("orderTime", orderTime == null ? "" : orderTime);
        params.put("idNum", idCard == null ? "" : idCard);
        params.put("register_corpTel", tel == null ? "" : tel);
        params.put("register_prinName",URLDecoder.decode(name == null ? "" : name, "UTF-8"));
        params.put("prov", accountbankprovCode == null ? "": accountbankprovCode);
        params.put("city", accountBankCityCode == null ? ""	: accountBankCityCode);
        String bankCode = this.dictMapper.findDictBankName(b2cShopperbi.getAccountbankdictval()) == null ? "" :
                URLDecoder.decode(dictMapper.findDictBankName(b2cShopperbi.getAccountbankdictval()).getDictid(),"UTF-8");
        params.put("bankCode", bankCode);
        params.put("bankNo", accountbankno == null ? "" : accountbankno);
        params.put("bankName",accountbankname == null ? "" : URLDecoder.decode(accountbankname, "UTF-8"));
        params.put("register_corpFinanceName", URLDecoder.decode(name, "UTF-8"));
        params.put("linkman",name == null ? "" : URLDecoder.decode(name, "UTF-8"));
        params.put("register_corpLicenceNo",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi	.getLicenseNo());
        params.put("register_corpName", accountbankclientname == null ? "": URLDecoder.decode(accountbankclientname, "UTF-8"));
        params.put("register_email", b2cShopperbi.getSemail() == null ? "": b2cShopperbi.getSemail());
        params.put("register_corpAccountLicenceNo",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi.getLicenseNo());
        params.put("register_corpOrganizeNo",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi.getLicenseNo());
        params.put("register_corpTaxId",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi	.getLicenseNo());
        params.put("register_corpAddr", b2cShopperbi.getSaddress() == null ? ""	: URLDecoder.decode(b2cShopperbi.getSaddress(), "UTF-8"));
        params.put("register_corpZip", b2cShopperbi.getSzip() == null ? "": b2cShopperbi.getSzip());
        params.put("proxyId", agentNo == null ? "" : agentNo);
        params.put("merchantNo", merchantNo == null ? "" : merchantNo);
        params.put("institutionNo", institutionNo == null ? "" : institutionNo);
        params.put("commissionIds", merchantFeeList);
        params.put("issupportt0", issupportt0 == null ? "" : issupportt0);// 是否支持T0提现
        params.put("scompany", b2cShopperbi.getScompany());
        params.put("agentNo", b2cShopperbi.getShopperidP());
        params.put("terminalNo", b2cShopperbi.getHfpsamd0()); //弘付psam D0
        params.put("pscmNo",b2cShopperbi.getHfpsam()==null?"":b2cShopperbi.getHfpsam()); //弘付psam D1

        params.put("superShopperId", superShopperId); //上级商户ID(裂变)
        params.put("ifInvite", ifInvite); //是否裂变商户（1：是 0：否）

        params.put("profitOwner", b2cShopperbi.getProfitOwner());//分润给那个代理商
        params.put("agentProfitRatio", b2cShopperbi.getAgentProfitRatio()); //代理商分润百分比
        params.put("merchProfitRatio1", b2cShopperbi.getMerchProfitRatio1());//商户分润方案1
        params.put("merchProfitRatio2", b2cShopperbi.getMerchProfitRatio2()); //商户分润方案2
        params.put("merchProfitRatio3", b2cShopperbi.getMerchProfitRatio3()); //商户分润方案3
        net.sf.json.JSONObject obs = net.sf.json.JSONObject.fromObject(params);
        System.out.println("注册银生宝商户：" + ConstantsEnv.SIMPLE_REGISTER_COMPANY_URL+ obs.toString());
        String resultString = HttpClientUtils.REpostRequestStr1(ConstantsEnv.SIMPLE_REGISTER_COMPANY_URL, obs.toString());
        Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);

        return resultMap;
	}
	/**
	 * 注册企业
	 * 
	 * @param b2cShopperbi
	 * @param userType
	 * @return
	 * @throws Exception
	 */
	private Map regCompany(B2cShopperbiTemp b2cShopperbi, String userType)
			throws Exception {
		HashMap params = new HashMap();
		Date dates = new Date();
		String mradom = RandomStringUtils.randomNumeric(6);
		String orderId = DateUtil.getTypeDate(dates, "yyyyMMdd") + mradom+ b2cShopperbi.getShopperid();
		String orderTime = DateUtil.getTypeDate(dates, "yyyyMMddhhmmss");

		// 基本信息
		String name = b2cShopperbi.getName();
		String idCard = b2cShopperbi.getIDNo();
		String tel = b2cShopperbi.getStel();
		String merchantNo = b2cShopperbi.getShopperid() == null ? "": b2cShopperbi.getShopperid().toString();
		Long agentNo = b2cShopperbi.getShopperidP();
		String institutionNo = b2cShopperbi.getOrgNo();
		String platformType = "";
		if (agentNo != null) {
			platformType = Constants.CON_NO;// 0 自有
		} else {
			platformType = Constants.CON_YES;// 机构
		}
		// 结算信息
		String settlementType = b2cShopperbi.getSettlementType();
		String accountBankDictval = b2cShopperbi.getAccountbankdictval();
		String accountbankname = b2cShopperbi.getAccountbankname();
		String accountbankprovCode = b2cShopperbi.getAccountBankProvCode();
		String accountBankCityCode = b2cShopperbi.getAccountBankCityCode();
		String accountbankclientname = b2cShopperbi.getAccountbankclientname();
		String accountbankno = b2cShopperbi.getAccountbankno();

		String superShopperId = "";
		String ifInvite = "0";
		if (StringUtils.isNotEmpty(b2cShopperbi.getInviteCodeP())){
			B2cShopperbiTemp b2cShopperbiTempNew = b2cShopperbiTempMapper.findShopperByInviteCode(b2cShopperbi.getInviteCodeP());
			if(null != b2cShopperbiTempNew){
				superShopperId = b2cShopperbiTempNew.getShopperid().toString();
				ifInvite = "1";
			}
		}

		// 刷卡手续费
		List merchantFeeList = mposMerchantFeeMapper.findmerchantFeeList(b2cShopperbi.getShopperid().toString());
		// t1type
		params.put("t1Type", b2cShopperbi.getT1type()==null?"0":b2cShopperbi.getT1type());
		params.put("t1topamount", b2cShopperbi.getT1topamount() == null ? "0": b2cShopperbi.getT1topamount());// t+1提现手续费
		// t+0手续费
		String issupportt0 = b2cShopperbi.getIsSupportT0(); // 0支持
		String isicapplyt0 = "";
		Double t0singledaylimit = 0.00;
		if (Constants.CON_NO.equals(issupportt0)) {
			isicapplyt0 = b2cShopperbi.getIsIcApplyT0();
			t0singledaylimit = b2cShopperbi.getT0SingleDayLimit();
			params.put("t0Type", b2cShopperbi.getT0type()==null?"0":b2cShopperbi.getT0type());
			params.put("t0fee", Constants.T0_FEE);
			params.put("t0fixedamount", Constants.T0_FIXED_AMOUNT);
			params.put("t0minamount", b2cShopperbi.getT0minamount());
			params.put("t0maxamount", b2cShopperbi.getT0maxamount());
			params.put("creditAmount", t0singledaylimit == null ? "": t0singledaylimit);
			params.put("t0singledaylimit", t0singledaylimit == null ? "": t0singledaylimit);
		} else {
			params.put("t0Type", "0");
			params.put("t0fee", "0");
			params.put("t0fixedamount", "0");
			params.put("t0minamount", "0");
			params.put("t0maxamount", "0");
			params.put("creditAmount", "0");
			params.put("t0singledaylimit", "0");
		}
		params.put("userType", userType == null ? "" : userType);
		params.put("orderId", orderId == null ? "" : orderId);
		params.put("orderTime", orderTime == null ? "" : orderTime);
		params.put("idNum", idCard == null ? "" : idCard);
		params.put("register_corpTel", tel == null ? "" : tel);
		params.put("register_prinName",URLDecoder.decode(name == null ? "" : name, "UTF-8"));
		params.put("prov", accountbankprovCode == null ? "": accountbankprovCode);
		params.put("city", accountBankCityCode == null ? ""	: accountBankCityCode);
		String bankCode = this.dictMapper.findDictBankName(b2cShopperbi.getAccountbankdictval()) == null ? "" :
		URLDecoder.decode(dictMapper.findDictBankName(b2cShopperbi.getAccountbankdictval()).getDictid(),"UTF-8");
		params.put("bankCode", bankCode);
		params.put("bankNo", accountbankno == null ? "" : accountbankno);
		params.put("bankName",accountbankname == null ? "" : URLDecoder.decode(accountbankname, "UTF-8"));
		params.put("register_corpFinanceName", URLDecoder.decode(name, "UTF-8"));
		params.put("linkman",name == null ? "" : URLDecoder.decode(name, "UTF-8"));
		params.put("register_corpLicenceNo",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi	.getLicenseNo());
		params.put("register_corpName", accountbankclientname == null ? "": URLDecoder.decode(accountbankclientname, "UTF-8"));
		params.put("register_email", b2cShopperbi.getSemail() == null ? "": b2cShopperbi.getSemail());
		params.put("register_corpAccountLicenceNo",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi.getLicenseNo());
		params.put("register_corpOrganizeNo",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi.getLicenseNo());
		params.put("register_corpTaxId",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi	.getLicenseNo());
		params.put("register_corpAddr", b2cShopperbi.getSaddress() == null ? ""	: URLDecoder.decode(b2cShopperbi.getSaddress(), "UTF-8"));
		params.put("register_corpZip", b2cShopperbi.getSzip() == null ? "": b2cShopperbi.getSzip());
		params.put("proxyId", agentNo == null ? "" : agentNo);
		params.put("merchantNo", merchantNo == null ? "" : merchantNo);
		params.put("institutionNo", institutionNo == null ? "" : institutionNo);
		params.put("commissionIds", merchantFeeList);
		params.put("issupportt0", issupportt0 == null ? "" : issupportt0);// 是否支持T0提现
		params.put("scompany", b2cShopperbi.getScompany());
		params.put("agentNo", b2cShopperbi.getShopperidP());
		params.put("terminalNo", b2cShopperbi.getHfpsamd0()); //弘付psam D0
		params.put("pscmNo",b2cShopperbi.getHfpsam()==null?"":b2cShopperbi.getHfpsam()); //弘付psam D1

		params.put("superShopperId", superShopperId); //上级商户ID(裂变)
		params.put("ifInvite", ifInvite); //是否裂变商户（1：是 0：否）

		params.put("profitOwner", b2cShopperbi.getProfitOwner());//分润给那个代理商
		params.put("agentProfitRatio", b2cShopperbi.getAgentProfitRatio()); //代理商分润百分比
		params.put("merchProfitRatio1", b2cShopperbi.getMerchProfitRatio1());//商户分润方案1
		params.put("merchProfitRatio2", b2cShopperbi.getMerchProfitRatio2()); //商户分润方案2
		params.put("merchProfitRatio3", b2cShopperbi.getMerchProfitRatio3()); //商户分润方案3
		net.sf.json.JSONObject obs = net.sf.json.JSONObject.fromObject(params);
		System.out.println("注册银生宝企业：" + ConstantsEnv.SIMPLE_REGISTER_COMPANY_URL+ obs.toString());
		String resultString = HttpClientUtils.REpostRequestStr1(ConstantsEnv.SIMPLE_REGISTER_COMPANY_URL, obs.toString());
		Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);

		return resultMap;
	}

    /**
     * 注册商户
     *
     * @param b2cShopperbi
     * @param userType
     * @return
     * @throws Exception
     */
    private Map regMerchant(B2cShopperbiTemp b2cShopperbi, String userType)
            throws Exception {
        HashMap params = new HashMap();
        Date dates = new Date();
        String mradom = RandomStringUtils.randomNumeric(6);
        String orderId = DateUtil.getTypeDate(dates, "yyyyMMdd") + mradom+ b2cShopperbi.getShopperid();
        String orderTime = DateUtil.getTypeDate(dates, "yyyyMMddhhmmss");

        // 基本信息
        String name = b2cShopperbi.getName();
        String idCard = b2cShopperbi.getIDNo();
        String tel = b2cShopperbi.getStel();
        String merchantNo = b2cShopperbi.getShopperid() == null ? "": b2cShopperbi.getShopperid().toString();
        Long agentNo = b2cShopperbi.getShopperidP();
        String institutionNo = b2cShopperbi.getOrgNo();
        String platformType = "";
        if (agentNo != null) {
            platformType = Constants.CON_NO;// 0 自有
        } else {
            platformType = Constants.CON_YES;// 机构
        }
        // 结算信息
        String settlementType = b2cShopperbi.getSettlementType();
        String accountBankDictval = b2cShopperbi.getAccountbankdictval();
        String accountbankname = b2cShopperbi.getAccountbankname();
        String accountbankprovCode = b2cShopperbi.getAccountBankProvCode();
        String accountBankCityCode = b2cShopperbi.getAccountBankCityCode();
        String accountbankclientname = b2cShopperbi.getAccountbankclientname();
        String accountbankno = b2cShopperbi.getAccountbankno();

        String superShopperId = "";
        String ifInvite = "0";
        if (StringUtils.isNotEmpty(b2cShopperbi.getInviteCodeP())){
            B2cShopperbiTemp b2cShopperbiTempNew = b2cShopperbiTempMapper.findShopperByInviteCode(b2cShopperbi.getInviteCodeP());
            if(null != b2cShopperbiTempNew){
                superShopperId = b2cShopperbiTempNew.getShopperid().toString();
                ifInvite = "1";
            }
        }

        // 刷卡手续费
        List merchantFeeList = mposMerchantFeeMapper.findmerchantFeeList(b2cShopperbi.getShopperid().toString());
        // t1type
        params.put("t1Type", b2cShopperbi.getT1type()==null?"0":b2cShopperbi.getT1type());
        params.put("t1topamount", b2cShopperbi.getT1topamount() == null ? "0": b2cShopperbi.getT1topamount());// t+1提现手续费
        // t+0手续费
        String issupportt0 = b2cShopperbi.getIsSupportT0(); // 0支持
        String isicapplyt0 = "";
        Double t0singledaylimit = 0.00;
        if (Constants.CON_NO.equals(issupportt0)) {
            isicapplyt0 = b2cShopperbi.getIsIcApplyT0();
            t0singledaylimit = b2cShopperbi.getT0SingleDayLimit();
            params.put("t0Type", b2cShopperbi.getT0type()==null?"0":b2cShopperbi.getT0type());
            params.put("t0fee", Constants.T0_FEE);
            params.put("t0fixedamount", Constants.T0_FIXED_AMOUNT);
            params.put("t0minamount", b2cShopperbi.getT0minamount());
            params.put("t0maxamount", b2cShopperbi.getT0maxamount());
            params.put("creditAmount", t0singledaylimit == null ? "": t0singledaylimit);
            params.put("t0singledaylimit", t0singledaylimit == null ? "": t0singledaylimit);
        } else {
            params.put("t0Type", "0");
            params.put("t0fee", "0");
            params.put("t0fixedamount", "0");
            params.put("t0minamount", "0");
            params.put("t0maxamount", "0");
            params.put("creditAmount", "0");
            params.put("t0singledaylimit", "0");
        }
        params.put("userType", userType == null ? "" : userType);
        params.put("orderId", orderId == null ? "" : orderId);
        params.put("orderTime", orderTime == null ? "" : orderTime);
        params.put("idNum", idCard == null ? "" : idCard);
        params.put("register_corpTel", tel == null ? "" : tel);
        params.put("register_prinName",URLDecoder.decode(name == null ? "" : name, "UTF-8"));
        params.put("prov", accountbankprovCode == null ? "": accountbankprovCode);
        params.put("city", accountBankCityCode == null ? ""	: accountBankCityCode);
        String bankCode = this.dictMapper.findDictBankName(b2cShopperbi.getAccountbankdictval()) == null ? "" :
                URLDecoder.decode(dictMapper.findDictBankName(b2cShopperbi.getAccountbankdictval()).getDictid(),"UTF-8");
        params.put("bankCode", bankCode);
        params.put("bankNo", accountbankno == null ? "" : accountbankno);
        params.put("bankName",accountbankname == null ? "" : URLDecoder.decode(accountbankname, "UTF-8"));
        params.put("register_corpFinanceName", URLDecoder.decode(name, "UTF-8"));
        params.put("linkman",name == null ? "" : URLDecoder.decode(name, "UTF-8"));
        params.put("register_corpLicenceNo",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi	.getLicenseNo());
        params.put("register_corpName", accountbankclientname == null ? "": URLDecoder.decode(accountbankclientname, "UTF-8"));
        params.put("register_email", b2cShopperbi.getSemail() == null ? "": b2cShopperbi.getSemail());
        params.put("register_corpAccountLicenceNo",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi.getLicenseNo());
        params.put("register_corpOrganizeNo",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi.getLicenseNo());
        params.put("register_corpTaxId",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi	.getLicenseNo());
        params.put("register_corpAddr", b2cShopperbi.getSaddress() == null ? ""	: URLDecoder.decode(b2cShopperbi.getSaddress(), "UTF-8"));
        params.put("register_corpZip", b2cShopperbi.getSzip() == null ? "": b2cShopperbi.getSzip());
        params.put("proxyId", agentNo == null ? "" : agentNo);
        params.put("merchantNo", merchantNo == null ? "" : merchantNo);
        params.put("institutionNo", institutionNo == null ? "" : institutionNo);
        params.put("commissionIds", merchantFeeList);
        params.put("issupportt0", issupportt0 == null ? "" : issupportt0);// 是否支持T0提现
        params.put("scompany", b2cShopperbi.getScompany());
        params.put("agentNo", b2cShopperbi.getShopperidP());
        params.put("terminalNo", b2cShopperbi.getHfpsamd0()); //弘付psam D0
        params.put("pscmNo",b2cShopperbi.getHfpsam()==null?"":b2cShopperbi.getHfpsam()); //弘付psam D1

        params.put("superShopperId", superShopperId); //上级商户ID(裂变)
        params.put("ifInvite", ifInvite); //是否裂变商户（1：是 0：否）

        params.put("profitOwner", b2cShopperbi.getProfitOwner());//分润给那个代理商
        params.put("agentProfitRatio", b2cShopperbi.getAgentProfitRatio()); //代理商分润百分比
        params.put("merchProfitRatio1", b2cShopperbi.getMerchProfitRatio1());//商户分润方案1
        params.put("merchProfitRatio2", b2cShopperbi.getMerchProfitRatio2()); //商户分润方案2
        params.put("merchProfitRatio3", b2cShopperbi.getMerchProfitRatio3()); //商户分润方案3
        net.sf.json.JSONObject obs = net.sf.json.JSONObject.fromObject(params);
        System.out.println("注册银生宝企业：" + ConstantsEnv.SIMPLE_REGISTER_COMPANY_URL+ obs.toString());
        String resultString = HttpClientUtils.REpostRequestStr1(ConstantsEnv.SIMPLE_REGISTER_COMPANY_URL, obs.toString());
        Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);

        return resultMap;
    }


	/**
	 * 保存商户费率信息
	 * @param shopperid
	 *//*
	public void insertMerchantFeeList(String shopperid) {
		List<MposMerchantFee> moFees = mposMerchantFeeMapper.findbyshopperid(shopperid);
		if(moFees != null && moFees.size() > 0){
			mposMerchantFeeMapper.deleteByshopperid(Long.valueOf(shopperid));
		}
		
		MposMerchantFee mposDebitfee=new MposMerchantFee();
		mposDebitfee.setShopperid(Long.valueOf(shopperid));
		mposDebitfee.setFeetype(Constants.CON_NO);//借记卡
		mposDebitfee.setFee(ToolsUtils.div(Double.parseDouble("0.0065"), 1, 4)+"");
		mposDebitfee.setCreateDate(new Date());
		mposDebitfee.setStatus(Constants.CON_YES);
		mposDebitfee.setD0fee(ToolsUtils.div(Double.parseDouble("0.0007"), 1, 4)+"");

		MposMerchantFee mposCreditFee=new MposMerchantFee();
		mposCreditFee.setShopperid(Long.valueOf(shopperid));
		mposCreditFee.setFeetype(Constants.CON_YES);//借记卡
		mposCreditFee.setFee(ToolsUtils.div(Double.parseDouble("0.0065"), 1, 4)+"");
		mposCreditFee.setCreateDate(new Date());
		mposCreditFee.setStatus(Constants.CON_YES);
		mposCreditFee.setD0fee(ToolsUtils.div(Double.parseDouble("0.0007"), 1, 4)+"");
		
		MposMerchantFee mweChatfee=new MposMerchantFee();
		mweChatfee.setShopperid(Long.valueOf(shopperid));
		mweChatfee.setFeetype(Constants.STATUS2);//微信
		mweChatfee.setFee(ToolsUtils.div(Double.parseDouble("0.0047"), 1, 4)+"");
		mweChatfee.setCreateDate(new Date());
		mweChatfee.setStatus(Constants.CON_YES);
		mweChatfee.setD0fee(ToolsUtils.div(Double.parseDouble("0.0049"), 1, 4)+"");
		
		MposMerchantFee mposAliPayFee=new MposMerchantFee();
		mposAliPayFee.setShopperid(Long.valueOf(shopperid));
		mposAliPayFee.setFeetype(Constants.STATUS3);//支付宝
		mposAliPayFee.setFee(ToolsUtils.div(Double.parseDouble("0.0047"), 1, 4)+"");
		mposAliPayFee.setCreateDate(new Date());
		mposAliPayFee.setStatus(Constants.CON_YES);
		mposAliPayFee.setD0fee(ToolsUtils.div(Double.parseDouble("0.0049"), 1, 4)+"");

		//添加银联二维码费率
		MposMerchantFee mposYlsmFee = new MposMerchantFee(); //银联二维码费率
		mposYlsmFee.setShopperid(Long.valueOf(shopperid));
		mposYlsmFee.setFeetype(Constants.STATUS4); //银联二维码
		mposYlsmFee.setFee(ToolsUtils.div(Double.parseDouble(acmsMapUtils.getAcmsMap().get("YL_FEE")), 1, 4)+"");
		mposYlsmFee.setCreateDate(new Date());
		mposYlsmFee.setStatus(Constants.CON_YES);

		mposMerchantFeeMapper.insertSelective(mposDebitfee);
		
		mposCreditFee.setId(mposDebitfee.getId());
		mposMerchantFeeMapper.insert(mposCreditFee);
		
		mweChatfee.setId(mposDebitfee.getId());
		mposMerchantFeeMapper.insert(mweChatfee);
		
		mposAliPayFee.setId(mposDebitfee.getId());
		mposMerchantFeeMapper.insert(mposAliPayFee);

		mposYlsmFee.setId(mposDebitfee.getId());
		mposMerchantFeeMapper.insert(mposYlsmFee);
		
	}*/
	
	/**
	 * 保存商户费率信息
	 * @param shopperid
	 */
	public void insertMerchantFeeList(String shopperid) {
		List<MposMerchantFee> moFees = mposMerchantFeeMapper.findbyshopperid(shopperid);
		if(moFees != null && moFees.size() > 0){
			mposMerchantFeeMapper.deleteByshopperid(Long.valueOf(shopperid));
		}

		//扫码
		List<SweepCodeProduct> sweepCodeProducts = sweepCodeProductMapper.findCodeProductSm();
		MposMerchantFee mposMerchantFee = null;
		MposMerchantFee mposMerchantFeeMpos = null;
		Long id = new Long(0);
		for(SweepCodeProduct sweepCodeProduct : sweepCodeProducts){
			mposMerchantFee = new MposMerchantFee();
			mposMerchantFee.setShopperid(Long.valueOf(shopperid));
			mposMerchantFee.setFeetype(sweepCodeProduct.getProFeeType());//费率类型
			mposMerchantFee.setFee(sweepCodeProduct.getProT1Fee());//t1费率多少
			mposMerchantFee.setD0fee(sweepCodeProduct.getProD0Fee());//DO汇率
			mposMerchantFee.setStatus(Constants.CON_YES);
			mposMerchantFee.setCreateDate(new Date());
			mposMerchantFee.setProType(sweepCodeProduct.getProType());
			if(id != 0){
				mposMerchantFee.setId(id);
				mposMerchantFeeMapper.insert(mposMerchantFee);
			}else{
				mposMerchantFeeMapper.insertSelective(mposMerchantFee);
			}
			id = mposMerchantFee.getId();
		}
		//mpos
		List<SweepCodeProduct> sweepCodeProductsMpos = sweepCodeProductMapper.findCodeProductMpos();
		for(SweepCodeProduct sweepCodeProductsM:sweepCodeProductsMpos){
			mposMerchantFeeMpos = new MposMerchantFee();
			mposMerchantFeeMpos.setId(id);
			mposMerchantFeeMpos.setShopperid(Long.valueOf(shopperid));
			mposMerchantFeeMpos.setFeetype(sweepCodeProductsM.getProFeeType());
			mposMerchantFeeMpos.setFee(sweepCodeProductsM.getProT1Fee());
			mposMerchantFeeMpos.setD0fee(sweepCodeProductsM.getProD0Fee());
			mposMerchantFeeMpos.setStatus(Constants.CON_YES);
			mposMerchantFeeMpos.setCreateDate(new Date());
			mposMerchantFeeMpos.setChannelType(sweepCodeProductsM.getChannelType());
			mposMerchantFeeMpos.setEachamount(sweepCodeProductsM.getEachamount());
			mposMerchantFeeMpos.setProType(sweepCodeProductsM.getProType());
			mposMerchantFeeMapper.insert(mposMerchantFeeMpos);
		}
		
	}
	
	
	/**
	 * 获取商户编号
	 * @param area
	 * @param mcc
	 * @return
	 * @throws Exception
	 */
	public String getPosShopperId(String area, String mcc) throws Exception {
		String organization = Constants.ORGANIZATION;
		String areacold = "";
		if (area.length() > 4) {
			areacold = area.substring(0, 4);
		} else {
			areacold = area;
		}
		String mcccold = "";
		if (mcc.length() == 1) {
			mcccold = "000" + mcc;
		} else {
			mcccold = "00" + mcc;
		}
		String merchantRadom = RandomStringUtils.randomNumeric(4);
		String posMerchantId = organization + areacold + mcccold
				+ merchantRadom;
		B2cShopperbiTemp b2cShopperbi = shopperbiTempMapper
				.selectByshopperId(Long.valueOf(posMerchantId));
		if (b2cShopperbi != null) {
			return getPosShopperId(area, mcc);
		}
		return posMerchantId;
	}
	
	
	/**
	 * 实名认证
	 * @param request
	 * @throws IOException
	 */
	public HashMap checkRelIdentity(HttpServletRequest request) {
		HashMap hashMap = new HashMap();
		String tel = request.getParameter("tel") == null ? "" : request.getParameter("tel").trim(); //手机号码
		String identityId = request.getParameter("identityId").toUpperCase() == null ? "" : request.getParameter("identityId").toUpperCase().trim(); // 身份证号
		String name = request.getParameter("name") == null ? "" : request.getParameter("name").trim(); // 姓名
		String cardCity = request.getParameter("cardCity") == null ? "" : request.getParameter("cardCity").trim(); //发卡城市名称
		String cardProvince = request.getParameter("cardProvince") == null ? "" : request.getParameter("cardProvince").trim(); //发卡省份名称
		String bankCard = request.getParameter("bankCard") == null ? "" : request.getParameter("bankCard").trim(); //银行卡号
		String bankName = request.getParameter("bankName") == null ? "" : request.getParameter("bankName").trim(); //银行名称
		String bankCode = request.getParameter("bankCode") == null ? "" : request.getParameter("bankCode").trim(); //银行Code
		String branchBankName = request.getParameter("branchBankName") == null ? "" : request.getParameter("branchBankName").trim(); //支行名称
		try {
			Log.info("123");
			if("".equals(name)){ hashMap.put("rspCode","1001"); hashMap.put("rspMsg", "姓名为空"); return hashMap;}
			if("".equals(identityId)){ hashMap.put("rspCode","1002"); hashMap.put("rspMsg", "身份证号为空"); return hashMap; }
			if("".equals(bankName)){ hashMap.put("rspCode","1003"); hashMap.put("rspMsg", "银行名称为空"); return hashMap;}
			if("".equals(branchBankName)){ hashMap.put("rspCode","1004"); hashMap.put("rspMsg", "支行名称为空"); return hashMap;}
			if("".equals(cardCity)){ hashMap.put("rspCode","1005"); hashMap.put("rspMsg", "发卡城市为空"); return hashMap;}
			if("".equals(cardProvince)){ hashMap.put("rspCode","1006"); hashMap.put("rspMsg", "发卡省份为空"); return hashMap;}
			if("".equals(bankCard)){ hashMap.put("rspCode","1007"); hashMap.put("rspMsg", "银行卡号为空"); return hashMap;}
			
			List<B2cShopperbiTemp> shopperbiTemps = b2cShopperbiMapper.findbyid(identityId);
			if(shopperbiTemps != null && shopperbiTemps.size() > 0){
				hashMap.put("rspCode", "1008");
				hashMap.put("rspMsg", "身份证号已被注册");
				return hashMap;
			}
			
			//调用商户鉴权接口进行鉴权
			String result = AuthenticAtionUtils.authentication3(bankCard, name, identityId);
			System.out.println("商户鉴权:"+result);
			
			BankCardValBean bankCardValBean = JSONObject.parseObject(result, BankCardValBean.class);
			if("1111".equals(bankCardValBean.getResult_code())){
				hashMap.put("rspCode", "1009");
				hashMap.put("rspMsg", "系统异常");
				return hashMap;
			}else if("2033".equals(bankCardValBean.getResult_code())){
				hashMap.put("rspCode", "1010");
				hashMap.put("rspMsg", "网络繁忙");
				return hashMap;
			}else if("1005".equals(bankCardValBean.getResult_code())){
				hashMap.put("rspCode", "1011");
				hashMap.put("rspMsg", "身份证号格式不正确");
				return hashMap;
			}else if("0000".equals(bankCardValBean.getResult_code()) && "20".equals(bankCardValBean.getStatus())){
				hashMap.put("rspCode", "1012");
				hashMap.put("rspMsg", "信息不匹配,持卡人身份信息输入不正确");
				return hashMap;
			}else if("0000".equals(bankCardValBean.getResult_code()) && "00".equals(bankCardValBean.getStatus())){
				B2cShopperVal shopperVal = new B2cShopperVal();
				shopperVal.setTel(tel);
				List<B2cShopperVal> shopperVals = shopperValMapper.queryByParam(shopperVal);
				if(shopperVals != null && shopperVals.size() > 0){
					shopperVal = new B2cShopperVal();
					shopperVal.setB2cShopperValId(shopperVals.get(0).getB2cShopperValId());
					shopperVal.setName(name);
					shopperVal.setIdentityId(identityId);
					shopperVal.setCardCity(cardCity);
					shopperVal.setCardProvince(cardProvince);
					shopperVal.setBankCard(bankCard);
					shopperVal.setBankName(bankName);
					shopperVal.setBankCode(bankCode);
					shopperVal.setBranchBankName(branchBankName);
					shopperValMapper.editByParam(shopperVal);
				}
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "成功");
				return hashMap;
			}else {
				hashMap.put("rspCode", "1009");
				hashMap.put("rspMsg", "系统异常");
				return hashMap;
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "出错");
			return hashMap;
		}
	}

	/**
	 * 实名认证2.2.0
	 * @param request
	 * @throws IOException
	 */
	public HashMap checkRelIdentity220(HttpServletRequest request) {
		HashMap hashMap = new HashMap();
		String tel = request.getParameter("tel") == null ? "" : request.getParameter("tel").trim(); //手机号码
		String identityId = request.getParameter("identityId").toUpperCase() == null ? "" :
				AesEncrypt.decryptAES(request.getParameter("identityId").trim(), ConstantsEnv.APP_AES_KEY).toUpperCase(); // 身份证号
		String name = request.getParameter("name") == null ? "" : request.getParameter("name").trim(); // 姓名
		String cardCity = request.getParameter("cardCity") == null ? "" : request.getParameter("cardCity").trim(); //发卡城市名称
		String cardProvince = request.getParameter("cardProvince") == null ? "" : request.getParameter("cardProvince").trim(); //发卡省份名称
		String bankCard = request.getParameter("bankCard") == null ? "" :
				AesEncrypt.decryptAES(request.getParameter("bankCard").trim(), ConstantsEnv.APP_AES_KEY); //银行卡号
		String bankName = request.getParameter("bankName") == null ? "" : request.getParameter("bankName").trim(); //银行名称
		String bankCode = request.getParameter("bankCode") == null ? "" : request.getParameter("bankCode").trim(); //银行Code
		String branchBankName = request.getParameter("branchBankName") == null ? "" : request.getParameter("branchBankName").trim(); //支行名称
		String inviteCodeP = request.getParameter("inviteCodeP") == null ? "" : request.getParameter("inviteCodeP").trim().toUpperCase(); //上级商户邀请码

		try {

			if("".equals(name)){ hashMap.put("rspCode",MessageEnum.姓名为空.getCode()); hashMap.put("rspMsg", MessageEnum.姓名为空.getText()); return hashMap;}
			if("".equals(identityId)){ hashMap.put("rspCode",MessageEnum.身份证号为空.getCode()); hashMap.put("rspMsg", MessageEnum.身份证号为空.getText()); return hashMap; }
			if("".equals(bankName)){ hashMap.put("rspCode",MessageEnum.银行名称为空.getCode()); hashMap.put("rspMsg", MessageEnum.银行名称为空.getText()); return hashMap;}
			if("".equals(branchBankName)){ hashMap.put("rspCode",MessageEnum.支行名称为空.getCode()); hashMap.put("rspMsg", MessageEnum.支行名称为空.getText()); return hashMap;}
			if("".equals(cardCity)){ hashMap.put("rspCode",MessageEnum.发卡城市为空.getCode()); hashMap.put("rspMsg", MessageEnum.发卡城市为空.getText()); return hashMap;}
			if("".equals(cardProvince)){ hashMap.put("rspCode",MessageEnum.发卡省份为空.getCode()); hashMap.put("rspMsg", MessageEnum.发卡省份为空.getText()); return hashMap;}
			if("".equals(bankCard)){ hashMap.put("rspCode",MessageEnum.银行卡号为空.getCode()); hashMap.put("rspMsg", MessageEnum.银行卡号为空.getText()); return hashMap;}

			B2cShopperbiTemp b2cShopperbiTemp = b2cShopperbiTempMapper.findShopperByInviteCode(inviteCodeP);
			if (StringUtils.isNotEmpty(inviteCodeP) && null == b2cShopperbiTemp){
				hashMap.put("rspCode", MessageEnum.邀请码不存在请确认后重输.getCode());
				hashMap.put("rspMsg", MessageEnum.邀请码不存在请确认后重输.getText());
				return hashMap;
			}

			List<B2cShopperbiTemp> shopperbiTemps = b2cShopperbiMapper.findbyid(identityId);
			if(shopperbiTemps != null && shopperbiTemps.size() > 0){
				hashMap.put("rspCode", MessageEnum.身份证号已被注册.getCode());
				hashMap.put("rspMsg", MessageEnum.身份证号已被注册.getText());
				return hashMap;
			}

			//调用商户鉴权接口进行鉴权
			String result = AuthenticAtionUtils.authentication3(bankCard, name, identityId);
			Log.info("商户鉴权：{}",result);

			BankCardValBean bankCardValBean = JSONObject.parseObject(result, BankCardValBean.class);
			if("1111".equals(bankCardValBean.getResult_code())){
				hashMap.put("rspCode", MessageEnum.系统异常.getCode());
				hashMap.put("rspMsg", MessageEnum.系统异常.getText());
				return hashMap;
			}else if("2033".equals(bankCardValBean.getResult_code())){
				hashMap.put("rspCode", MessageEnum.网络繁忙.getCode());
				hashMap.put("rspMsg", MessageEnum.网络繁忙.getText());
				return hashMap;
			}else if("1005".equals(bankCardValBean.getResult_code())){
				hashMap.put("rspCode", MessageEnum.身份证号格式不正确.getCode());
				hashMap.put("rspMsg", MessageEnum.身份证号格式不正确.getText());
				return hashMap;
			}else if("0000".equals(bankCardValBean.getResult_code()) && "20".equals(bankCardValBean.getStatus())){
				hashMap.put("rspCode", MessageEnum.信息不匹配持卡人身份信息输入不正确.getCode());
				hashMap.put("rspMsg", MessageEnum.信息不匹配持卡人身份信息输入不正确.getText());
				return hashMap;
			}else if("0000".equals(bankCardValBean.getResult_code()) && "00".equals(bankCardValBean.getStatus())){
				B2cShopperVal shopperVal = new B2cShopperVal();
				shopperVal.setTel(tel);
				List<B2cShopperVal> shopperVals = shopperValMapper.queryByParam(shopperVal);
				if(shopperVals != null && shopperVals.size() > 0){
					shopperVal = new B2cShopperVal();
					shopperVal.setB2cShopperValId(shopperVals.get(0).getB2cShopperValId());
					shopperVal.setName(name);
					shopperVal.setIdentityId(identityId);
					shopperVal.setCardCity(cardCity);
					shopperVal.setCardProvince(cardProvince);
					shopperVal.setBankCard(bankCard);
					shopperVal.setBankName(bankName);
					shopperVal.setBankCode(bankCode);
					shopperVal.setBranchBankName(branchBankName);

					//APP有传inviteCodeP但注册临时表没有 则表明开放注册商户  根据邀请码绑定代理商
					if (StringUtils.isNotEmpty(inviteCodeP)){
						if(StringUtils.isEmpty(shopperVals.get(0).getInviteCodeP())){

							if (null != b2cShopperbiTemp.getShopperidP()){
								shopperVal.setShopperidP(b2cShopperbiTemp.getShopperidP());
							} else{
								//绑定直营服务商
								shopperVal.setShopperidP(Long.valueOf(ConstantsEnv.DIRECT_AGENTNO));
							}
						}
					}

					shopperVal.setInviteCodeP(inviteCodeP);
					shopperValMapper.editByParam(shopperVal);
				}
				hashMap.put("rspCode", MessageEnum.成功.getCode());
				hashMap.put("rspMsg", MessageEnum.成功.getText());
				return hashMap;
			}else {
				hashMap.put("rspCode", MessageEnum.系统异常.getCode());
				hashMap.put("rspMsg", MessageEnum.系统异常.getText());
				return hashMap;
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", MessageEnum.出错.getCode());
			hashMap.put("rspMsg", MessageEnum.出错.getText());
			return hashMap;
		}
	}

    /**
     * 商户认证，结算信息
     * @param request
     * @throws IOException
     */
    public HashMap checkSettleCustomer(HttpServletRequest request) {
        HashMap hashMap = new HashMap();
        String tel = request.getParameter("tel") == null ? "" : request.getParameter("tel").trim(); //手机号码
        String identityId = request.getParameter("identityId").toUpperCase() == null ? "" :
                AesEncrypt.decryptAES(request.getParameter("identityId").trim(), ConstantsEnv.APP_AES_KEY).toUpperCase(); // 身份证号
        String name = request.getParameter("name") == null ? "" : request.getParameter("name").trim(); // 商户版改为开户名称
        String bankCard = request.getParameter("bankCard") == null ? "" :
                AesEncrypt.decryptAES(request.getParameter("bankCard").trim(), ConstantsEnv.APP_AES_KEY); //银行卡号
        String bankName = request.getParameter("bankName") == null ? "" : request.getParameter("bankName").trim(); //银行名称
        String branchBankName = request.getParameter("branchBankName") == null ? "" : request.getParameter("branchBankName").trim(); //支行名称
        String accountLineNumber = request.getParameter("accountLineNumber") == null ? "" : request.getParameter("accountLineNumber").trim(); //开户行联行号
        try {

            if("".equals(name)){ hashMap.put("rspCode",MessageEnum.姓名为空.getCode()); hashMap.put("rspMsg", MessageEnum.姓名为空.getText()); return hashMap;}
            if("".equals(identityId)){ hashMap.put("rspCode",MessageEnum.身份证号为空.getCode()); hashMap.put("rspMsg", MessageEnum.身份证号为空.getText()); return hashMap; }
            if("".equals(bankName)){ hashMap.put("rspCode",MessageEnum.银行名称为空.getCode()); hashMap.put("rspMsg", MessageEnum.银行名称为空.getText()); return hashMap;}
            if("".equals(branchBankName)){ hashMap.put("rspCode",MessageEnum.支行名称为空.getCode()); hashMap.put("rspMsg", MessageEnum.支行名称为空.getText()); return hashMap;}
            if("".equals(bankCard)){ hashMap.put("rspCode",MessageEnum.银行卡号为空.getCode()); hashMap.put("rspMsg", MessageEnum.银行卡号为空.getText()); return hashMap;}
            if("".equals(accountLineNumber)){ hashMap.put("rspCode",MessageEnum.开户行联行号为空.getCode()); hashMap.put("rspMsg", MessageEnum.开户行联行号为空.getText()); return hashMap;}

            /*List<B2cShopperbiTemp> shopperbiTemps = b2cShopperbiMapper.findbyid(identityId);
            if(shopperbiTemps != null && shopperbiTemps.size() > 0){
                hashMap.put("rspCode", MessageEnum.身份证号已被注册.getCode());
                hashMap.put("rspMsg", MessageEnum.身份证号已被注册.getText());
                return hashMap;
            }*/

            //数据更新实体
            B2cShopperbiTemp b2cShopperbiTemp = new B2cShopperbiTemp();


            //查询商户号
            Long shopperid = b2cShopperbiTempMapper.findAggSid(identityId);
            b2cShopperbiTemp.setShopperid(shopperid);

            //获取银行编码
            String bankCode = b2cShopperbiTempMapper.findBankCode(bankName);
            b2cShopperbiTemp.setAccountbankdictval(bankCode); //开户银行名称，数据字典
            //设置结算卡信息
            b2cShopperbiTemp.setAccountbankclientname(name);
            b2cShopperbiTemp.setAccountBankClientTel(tel);
            b2cShopperbiTemp.setAccountbankno(bankCard);
            b2cShopperbiTemp.setAccountbankother(bankName);
            b2cShopperbiTemp.setAccountbankname(branchBankName);
            b2cShopperbiTemp.setAccountBankLineNumber(accountLineNumber);
            b2cShopperbiTemp.setBankUpdateDate(new Date());

            //B2cShopperbiTemp oldB2cShopperbiTemp = b2cShopperbiTempMapper.findByTel(identityId);//根据身份证查询到商户信息

           /* oldNotPassStep = oldB2cShopperbiTemp.getNotPassStep();
            oldNotPassStep = com.uns.util.StringUtils.replaceIndex(Constants.INT_2, oldNotPassStep, Constants.TYPE_1);
            b2cShopperbiTemp.setNotPassStep(oldNotPassStep);*/
            //更新实体
            b2cShopperbiTempMapper.updateOCRDebitCardInfo(b2cShopperbiTemp);

            //添加微信和支付宝费率
            insertMerchantFee(request,String.valueOf(shopperid));
            hashMap.put("rspCode", MessageEnum.认证结算信息成功.getCode());
            hashMap.put("rspMsg", MessageEnum.认证结算信息成功.getText());
            Log.info("认证结算信息成功：" + hashMap);
            return hashMap;
        } catch (Exception e) {
            e.printStackTrace();
            hashMap.put("rspCode", MessageEnum.出错.getCode());
            hashMap.put("rspMsg", MessageEnum.出错.getText());
            return hashMap;
        }
    }

    /**
     * 商户版新加微信和支付宝费率
     * @param shopperid
     */
    private void insertMerchantFee(HttpServletRequest request,String shopperid){
        String zfbFee = request.getParameter("zfbFee") == null ? "" : request.getParameter("zfbFee").trim(); // 支付宝费率
        String wxFee = request.getParameter("wxFee") == null ? "" : request.getParameter("wxFee").trim(); // 微信费率

        MposMerchantFee mposMerchantFeeMpos = null;

        mposMerchantFeeMpos = new MposMerchantFee();
        mposMerchantFeeMpos.setShopperid(Long.valueOf(shopperid));
        //mposMerchantFeeMpos.setD0fee();
        mposMerchantFeeMpos.setStatus(Constants.CON_YES);
        mposMerchantFeeMpos.setChannelType(Constants.T1_CHANNEL_TYPE); //渠道类型 T1 2002
        //mposMerchantFeeMpos.setEachamount();
        mposMerchantFeeMpos.setProType(Constants.TYPE_1); //1 mpos 2 sm
        mposMerchantFeeMpos.setCreateDate(new Date());

        //微信费率
        mposMerchantFeeMpos.setFeetype(Constants.FEE_TYPE_WX);
        mposMerchantFeeMpos.setFee(wxFee);
        mposMerchantFeeMapper.insertSelective(mposMerchantFeeMpos);
        mposMerchantFeeMapper.insertTempSelective(mposMerchantFeeMpos);
        //支付宝费率
        mposMerchantFeeMpos.setFeetype(Constants.FEE_TYPE_ZFB);
        mposMerchantFeeMpos.setFee(zfbFee);
        mposMerchantFeeMapper.insertSelective(mposMerchantFeeMpos);
        mposMerchantFeeMapper.insertTempSelective(mposMerchantFeeMpos);
    }

    /**
     * 四要素鉴权
     */
    public HashMap authentication4(String bankNo, String bankClientName, String idNo, String bankClientTel) {
        HashMap hashMap = new HashMap();
        //四要素鉴权
        String authResult = AuthenticAtionUtils.authentication4(bankNo, bankClientName, idNo, bankClientTel);//银行卡号，姓名，身份证号，手机号
        BankCardValBean bankCardValBean = JSONObject.parseObject(authResult, BankCardValBean.class);
        Log.info("四要素鉴权返回结果:{}", FastJson.toJson(bankCardValBean));
        if ("1111".equals(bankCardValBean.getResult_code())) {
            hashMap.put(Constants.RSP_CODE, "1009");
            hashMap.put(Constants.RSP_MSG, "系统异常");
            return hashMap;
        } else if ("2033".equals(bankCardValBean.getResult_code())) {
            hashMap.put(Constants.RSP_CODE, "1010");
            hashMap.put(Constants.RSP_MSG, "网络繁忙");
            return hashMap;
        } else if ("1005".equals(bankCardValBean.getResult_code())) {
            hashMap.put(Constants.RSP_CODE, "1011");
            hashMap.put(Constants.RSP_MSG, "身份证号格式不正确");
            return hashMap;
        } else if ("0000".equals(bankCardValBean.getResult_code())) {
            if ("20".equals(bankCardValBean.getStatus())) {
                hashMap.put(Constants.RSP_CODE, "1012");
                hashMap.put(Constants.RSP_MSG, "信息不匹配,持卡人身份信息输入不正确");
                return hashMap;
            }
            //鉴权通过
            else if (!"00".equals(bankCardValBean.getStatus())) {
                hashMap.put(Constants.RSP_CODE, MessageEnum.出错.getCode());
                hashMap.put(Constants.RSP_MSG, MessageEnum.出错.getText());
                return hashMap;
            } else {
                hashMap.put(Constants.RSP_CODE, MessageEnum.成功.getCode());
                hashMap.put(Constants.RSP_MSG, MessageEnum.成功.getText());
                return hashMap;
            }
        } else {
            hashMap.put(Constants.RSP_CODE, MessageEnum.出错.getCode());
            hashMap.put(Constants.RSP_MSG, MessageEnum.出错.getText());
            return hashMap;
        }
    }


	/**
	 * 验证注册商户账号是否存在
	 * 如果手机号可以注册发送短信验证码
	 * @param tel
	 * @param smsCode
	 * @return
	 */
	public HashMap checkRegTel(String tel, String smsCode) {
		HashMap hashMap = new HashMap();
		try {
			if ("".equals(tel)) {
				hashMap.put("rspCode", MessageEnum.手机号码为空.getCode());
				hashMap.put("rspMsg", MessageEnum.手机号码为空.getText());
				return hashMap;
			}
			if (!RegularUtils.isMobile(tel)) {
				hashMap.put("rspCode", MessageEnum.手机号码格式不对.getCode());
				hashMap.put("rspMsg", MessageEnum.手机号码格式不对.getText());
				return hashMap;
			}
			
			List list= mposRemoteInvitationMapper.findbytelstauts(tel);
			MposRemoteInvitation remote=null;
			if(list!=null&&list.size()>0){
				remote=(MposRemoteInvitation)list.get(0);
			}
			if(remote != null){
				hashMap.put("rspCode", MessageEnum.手机号已被远程邀请.getCode());
				hashMap.put("rspMsg", MessageEnum.手机号已被远程邀请.getText());
				return hashMap;
			}
			
			List<B2cShopperbiTemp> shopperbiTemps = shopperbiTempMapper.findbytel(tel);
			B2cShopperbiTemp shopperbiTemp = null;
			if(shopperbiTemps != null && shopperbiTemps.size() > 0){
				shopperbiTemp = shopperbiTemps.get(0);
			}
			if (shopperbiTemp != null) {
				hashMap.put("rspCode", MessageEnum.手机号码已被注册.getCode());
				hashMap.put("rspMsg", MessageEnum.手机号码已被注册.getText());
				return hashMap;
			} else {
				B2cShopperVal b2cShopperVal = new B2cShopperVal();
				b2cShopperVal = new B2cShopperVal();
				b2cShopperVal.setTel(tel);
				List<B2cShopperVal> shopperVals = shopperValMapper.queryByParam(b2cShopperVal);
				if (shopperVals != null && shopperVals.size() > 0) {
				    b2cShopperVal = shopperVals.get(0);
				    if (StringUtils.isNotEmpty(b2cShopperVal.getPassword())){
                        hashMap.put("rspCode", MessageEnum.手机号码已被注册.getCode());
                        hashMap.put("rspMsg", MessageEnum.手机号码已被注册.getText());
                        return hashMap;
                    }
					shopperValMapper.delByParam(shopperVals.get(0).getB2cShopperValId());
				}

				b2cShopperVal.setSmsCode(smsCode);
				b2cShopperVal.setSmsCodeDate(new Date());
				shopperValMapper.saveShopperVal(b2cShopperVal);
				hashMap.put("rspCode", MessageEnum.成功.getCode());
				hashMap.put("rspMsg", MessageEnum.成功.getText());
				return hashMap;
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", MessageEnum.出错.getCode());
			hashMap.put("rspMsg", MessageEnum.出错.getText());
			return hashMap;
		}
	}

	/**
	 * 注册验证220
	 * 两次密码输入是否一致
	 * 验证码是否过期
	 * 验证手机号和验证码是否对应
	 * @return
	 */
	public HashMap checkRegInfo220(HttpServletRequest request) {
		String tel = request.getParameter("tel") == null ? "" : request.getParameter("tel").trim(); //手机号
		String smsCode = request.getParameter("smsCode") == null ? "" : request.getParameter("smsCode"); //验证码
		String inviteCodeP = request.getParameter("inviteCodeP") == null ? "" : request.getParameter("inviteCodeP").toUpperCase(); //上级商户邀请码
		String password = request.getParameter("password") == null ? "" :
				AesEncrypt.decryptAES(request.getParameter("password"),ConstantsEnv.APP_AES_KEY); //密码
		String repeatPwd = request.getParameter("repeatPwd") == null ? "" :
				AesEncrypt.decryptAES(request.getParameter("repeatPwd"),ConstantsEnv.APP_AES_KEY); //确认密码

		String operChannel = request.getParameter("operChannel") == null ? "" : request.getParameter("operChannel");//操作渠道(wx:微信    qq:qq    zfb:支付宝)
		String operContent = request.getParameter("operContent") == null ? "" : request.getParameter("operContent");//操作内容(link:链接文案   qrcode:二维码)

		HashMap hashMap = new HashMap();
		try {
			if ("".equals(tel)) {
				hashMap.put("rspCode", MessageEnum.手机号码为空.getCode());
				hashMap.put("rspMsg", MessageEnum.手机号码为空.getText());
				return hashMap;
			}

			if ("".equals(smsCode)) {
				hashMap.put("rspCode", MessageEnum.验证码为空.getCode());
				hashMap.put("rspMsg", MessageEnum.验证码为空.getText());
				return hashMap;
			}
			if ("".equals(password)) {
				hashMap.put("rspCode", MessageEnum.密码为空.getCode());
				hashMap.put("rspMsg", MessageEnum.密码为空.getText());
				return hashMap;
			}
			if ("".equals(repeatPwd)) {
				hashMap.put("rspCode", MessageEnum.确认密码为空.getCode());
				hashMap.put("rspMsg", MessageEnum.确认密码为空.getText());
				return hashMap;
			}
			B2cShopperVal b2cShopperVal = new B2cShopperVal();
			b2cShopperVal.setTel(tel);
			List<B2cShopperVal> shopperVals = shopperValMapper.queryByParam(b2cShopperVal);
			if (shopperVals != null && shopperVals.size() > 0){
				b2cShopperVal = shopperVals.get(0);
				if (StringUtils.isNotEmpty(b2cShopperVal.getPassword())){
					hashMap.put("rspCode", MessageEnum.手机号码已被注册.getCode());
					hashMap.put("rspMsg", MessageEnum.手机号码已被注册.getText());
					return hashMap;
				}
			}
			b2cShopperVal = new B2cShopperVal();
			b2cShopperVal.setTel(tel);
			b2cShopperVal.setSmsCode(smsCode);
			shopperVals = shopperValMapper.queryByParam(b2cShopperVal);
			if (shopperVals != null && shopperVals.size() > 0) {

				Date curDate = new Date();
				Long time = curDate.getTime() - shopperVals.get(0).getSmsCodeDate().getTime();
				if(time > Constants.TIME_TEN){
					hashMap.put("rspCode", MessageEnum.验证码过期.getCode());
					hashMap.put("rspMsg", MessageEnum.验证码过期.getText());
					return hashMap;
				}
				if (!RegularUtils.checkPwd(password)) {
					hashMap.put("rspCode", MessageEnum.密码格式不正确.getCode());
					hashMap.put("rspMsg", MessageEnum.密码格式不正确.getText());
					return hashMap;
				}
				if (!password.equals(repeatPwd)) {
					hashMap.put("rspCode", MessageEnum.两次密码输入不一致.getCode());
					hashMap.put("rspMsg", MessageEnum.两次密码输入不一致.getText());
					return hashMap;
				}

				if(StringUtils.isNotEmpty(inviteCodeP)){
					B2cShopperbiTemp b2cShopperbiTemp = b2cShopperbiTempMapper.findShopperByInviteCode(inviteCodeP);
					if (null == b2cShopperbiTemp){
						hashMap.put("rspCode", MessageEnum.邀请码不存在请确认后重输.getCode());
						hashMap.put("rspMsg", MessageEnum.邀请码不存在请确认后重输.getText());
						return hashMap;
					}
				}

				b2cShopperVal = new B2cShopperVal();
				b2cShopperVal.setB2cShopperValId(shopperVals.get(0).getB2cShopperValId());
				b2cShopperVal.setPassword(password);
				b2cShopperVal.setInviteCodeP(inviteCodeP);

				//裂变商户 添加注册记录
				if (!"".equals(inviteCodeP)){
					B2cShopperbiTemp b2cShopperbiTemp = b2cShopperbiTempMapper.findShopperByInviteCode(inviteCodeP);
					B2cShopperbiShare b2cShopperbiShare = new B2cShopperbiShare();
					b2cShopperbiShare.setOperDate(new Date());
					b2cShopperbiShare.setOperType("reg");
					b2cShopperbiShare.setOperChannel(operChannel);
					b2cShopperbiShare.setOperContent(operContent);
					b2cShopperbiShare.setOperTel(b2cShopperbiTemp.getStel());
					b2cShopperbiShare.setOperRegTel(tel);

					b2cShopperbiShareMapper.insertSelective(b2cShopperbiShare);
					//裂变商户绑定上级商户的所属服务商
					//如果上级商户没有所属服务商 则绑定直营服务商
					if (StringUtils.isNotEmpty(b2cShopperbiTemp.getShopperidP() == null ? null : b2cShopperbiTemp.getShopperidP().toString())){
						b2cShopperVal.setShopperidP(b2cShopperbiTemp.getShopperidP());
					} else{
						b2cShopperVal.setShopperidP(Long.valueOf(ConstantsEnv.DIRECT_AGENTNO));
					}
				}
				shopperValMapper.editByParam(b2cShopperVal);

				hashMap.put("rspCode", MessageEnum.成功.getCode());
				hashMap.put("rspMsg", MessageEnum.成功.getText());
				hashMap.put("tel", tel);
				return hashMap;

			} else {
				hashMap.put("rspCode", MessageEnum.短信验证码错误.getCode());
				hashMap.put("rspMsg", MessageEnum.短信验证码错误.getText());
				return hashMap;
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", MessageEnum.出错.getCode());
			hashMap.put("rspMsg", MessageEnum.出错.getText());
			return hashMap;
		}

	}

	/**
	 * 注册验证
	 * 两次密码输入是否一致
	 * 验证码是否过期
	 * 验证手机号和验证码是否对应
	 * @return
	 */
	public HashMap checkRegInfo(HttpServletRequest request) {
		String tel = request.getParameter("tel") == null ? "" : request.getParameter("tel").trim(); //手机号
		String smsCode = request.getParameter("smsCode") == null ? "" : request.getParameter("smsCode"); //验证码
		String password = request.getParameter("password") == null ? "" : request.getParameter("password"); //密码
		String repeatPwd = request.getParameter("repeatPwd") == null ? "" : request.getParameter("repeatPwd"); //确认密码

		HashMap hashMap = new HashMap();
		try {
			if ("".equals(tel)) {
				hashMap.put("rspCode", MessageEnum.手机号码为空.getCode());
				hashMap.put("rspMsg", MessageEnum.手机号码为空.getText());
				return hashMap;
			}

			if ("".equals(smsCode)) {
				hashMap.put("rspCode", MessageEnum.验证码为空.getCode());
				hashMap.put("rspMsg", MessageEnum.验证码为空.getText());
				return hashMap;
			}
			if ("".equals(password)) {
				hashMap.put("rspCode", MessageEnum.密码为空.getCode());
				hashMap.put("rspMsg", MessageEnum.密码为空.getText());
				return hashMap;
			}
			if ("".equals(repeatPwd)) {
				hashMap.put("rspCode", MessageEnum.确认密码为空.getCode());
				hashMap.put("rspMsg", MessageEnum.确认密码为空.getText());
				return hashMap;
			}
			B2cShopperVal b2cShopperVal = new B2cShopperVal();
			b2cShopperVal.setTel(tel);
			b2cShopperVal.setSmsCode(smsCode);
			List<B2cShopperVal> shopperVals = shopperValMapper.queryByParam(b2cShopperVal);
			if (shopperVals != null && shopperVals.size() > 0) {

				Date curDate = new Date();
				Long time = curDate.getTime() - shopperVals.get(0).getSmsCodeDate().getTime();
				if(time > Constants.TIME_TEN){
					hashMap.put("rspCode", MessageEnum.验证码过期.getCode());
					hashMap.put("rspMsg", MessageEnum.验证码过期.getText());
					return hashMap;
				}
				if (!RegularUtils.checkPwd(password)) {
					hashMap.put("rspCode", MessageEnum.密码格式不正确.getCode());
					hashMap.put("rspMsg", MessageEnum.密码格式不正确.getText());
					return hashMap;
				}
				if (!password.equals(repeatPwd)) {
					hashMap.put("rspCode", MessageEnum.两次密码输入不一致.getCode());
					hashMap.put("rspMsg", MessageEnum.两次密码输入不一致.getText());
					return hashMap;
				}

				b2cShopperVal = new B2cShopperVal();
				b2cShopperVal.setB2cShopperValId(shopperVals.get(0).getB2cShopperValId());
				b2cShopperVal.setPassword(password);

				shopperValMapper.editByParam(b2cShopperVal);

				hashMap.put("rspCode", MessageEnum.成功.getCode());
				hashMap.put("rspMsg", MessageEnum.成功.getText());
				hashMap.put("tel", tel);
				return hashMap;

			} else {
				hashMap.put("rspCode", MessageEnum.短信验证码错误.getCode());
				hashMap.put("rspMsg", MessageEnum.短信验证码错误.getText());
				return hashMap;
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", MessageEnum.出错.getCode());
			hashMap.put("rspMsg", MessageEnum.出错.getText());
			return hashMap;
		}

	}
	
	
	
	/**绑定终端
	 * @param request
	 * @return
	 * @throws Exception 
	 */
	private Map boundTerminalPort200(HttpServletRequest request, String shopperid,String deviceNum, B2cShopperbiTemp shopper) {
		try {
			Map regMap=new HashMap();
			B2cShopperbi b2cShopperbi=b2cShopperbiMapper.selectFormalshoppId(shopperid);
			regMap.put("deviceNumber", deviceNum);
			regMap.put("scompay", URLEncoder.encode(b2cShopperbi.getScompany(), "UTF-8"));
			regMap.put("youngMerchant",shopperid);
			regMap.put("ysbNo", b2cShopperbi.getYsbNo());
			regMap.put("merchantType", Constants.TYPE_2);//机构为1
			regMap.put("version", Constants.VERSION_2_0_1);
			regMap.put("type",  request.getParameter("type")==""?"I":request.getParameter("type"));
			regMap.put("cardType",  Constants.CON_NO); //0 费率 1是封顶
			regMap.put("shopperbiType",  shopper.getMerchantType()); //0 个人 1是企业
			regMap.put("sprovince",  URLEncoder.encode(shopper.getSprovince(), "UTF-8")); //终端所属 地区
			regMap.put("province",  shopper.getProvince()); //终端所属 地区
			regMap.put("hfpsamd0",  shopper.getHfpsamd0()); //弘付D0设置
			
			List list=mposMerchantFeeMapper.findMposMerchantFeezhifu(shopperid);
			regMap.put("fee", list);
			String deviceNo="";
			B2cTermBinder b2cTermBinder=getDiveceNo(shopperid);
			if(b2cTermBinder!=null){
				deviceNo=b2cTermBinder.getTermNo();
			}
			regMap.put("deviceNo", deviceNo);
			
			net.sf.json.JSONObject obs = net.sf.json.JSONObject.fromObject(regMap);
			String url= ConstantsEnv.REG_SHOUDAN_URL+obs.toString()+"";
			System.out.println("绑定终端请求："+url);
			org.apache.http.client.HttpClient httpclient=new DefaultHttpClient();
			url=url.replace("\"", "%22");
			url=url.replace("{", "%7B");
			url=url.replace("}", "%7D");
			HttpPost httpget=new HttpPost(url);
			
			HttpResponse httprespone;
			
			httprespone = httpclient.execute(httpget);
			
			String str = EntityUtils.toString(httprespone.getEntity());
			Map map1 = com.uns.util.JsonUtil.jsonStrToMap(str);
		
			return map1;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	/**
	 * 密钥处理
	 * @param qrCode
	 * @return
	 */
	public String getQrCodeUrl(String qrCode) {
		StringBuffer sBuffer=new StringBuffer();
		sBuffer.append(qrCode);
		sBuffer.append(ConstantsEnv.MERCHANTKEY);
		String smacs=Md5Encrypt.md5(sBuffer.toString());
		
		return ConstantsEnv.Fixed_Qr_Code_Url+"qrCode="+qrCode+"&mac="+smacs;
	}

	/**
	 * =申请弘付D0
	 * 费率规则：例  封顶35千78费率，费率代号为（FD35Q78）。终端分
	 * 为借记卡费率与贷记卡费率填写格式  借记卡费率|贷记卡费率 例（FD20Q5|Q5）
	 * 修改费率时需要将借记卡费率与贷记卡费率一起上送
	 * @param b2cShopperbi
	 * @return
	 * @throws Exception
	 */
	public net.sf.json.JSONObject addHfMerchantPortD0(B2cShopperbiTemp b2cShopperbi) throws BusinessException {
		String respCode = null;
		try {
			String key = ConstantsEnv.HF_KEY;//加密key
			String URL = ConstantsEnv.HF_MERCHANT_URL;//请求地址

			Map<String, String> reqMap = new HashMap<String, String>();
			reqMap.put("orgMerno", b2cShopperbi.getShopperid()==null?"":b2cShopperbi.getShopperid().toString());		//机构商户唯一标识
			reqMap.put("bankName", b2cShopperbi.getAccountbankname());													//开户行名称
			reqMap.put("licenseEndDate", "2050-01-01");																	//营业执照到期时间   yyyy-MM-dd，无数据给默认日期
			reqMap.put("linkMan", b2cShopperbi.getName());																//联系人
			reqMap.put("areaCode", b2cShopperbi.getCity());																//受理区域代码
			reqMap.put("linkPhone", b2cShopperbi.getStel());															//联系电话
			reqMap.put("idCard", b2cShopperbi.getIDNo());																//法人身份证号
			reqMap.put("businessLicense", b2cShopperbi.getLicenseno()==null?"":b2cShopperbi.getLicenseno());			//营业执照号
			reqMap.put("accountNo", b2cShopperbi.getAccountbankno());													//账号
			reqMap.put("legalPerson", b2cShopperbi.getName());															//法人
			reqMap.put("shortName", b2cShopperbi.getName());															//商户简称
			reqMap.put("businessAddress", b2cShopperbi.getSaddress());													//营业地址
			reqMap.put("accountName", b2cShopperbi.getAccountbankclientname());														//账户名
			reqMap.put("regionCode", b2cShopperbi.getCity());															//行政地区码
			reqMap.put("bankNo", dictMapper.findB2cDictBank(b2cShopperbi.getAccountbankdictval()));																				//开户行行号,无数据给0000
			reqMap.put("merName", b2cShopperbi.getScompany());															//商户名称
			reqMap.put("registeredAddress", b2cShopperbi.getSaddress());												//注册地址
			
			
			reqMap.put("txnType", Constants.CON_NO);																		//交易类型 0申请 1变更
			reqMap.put("posType", Constants.CON_YES);																		//pos类型,给默认值1
			reqMap.put("groupNo", Constants.STATUS2);																//费率类型（0标准类 1优惠类2综合类）

			reqMap.put("args", Constants.CON_YES);																			//机构自定义，给默认值1
			reqMap.put("userSign", ConstantsEnv.HF_USERSIGN);																//机构标识，由上游提供，请联系技术
			reqMap.put("requestUrl", "");																				//异步密钥通知地址  接收到返回请返回 success字符串 意味着成功接收到异步通知 则停止通知
			//，若未响应则会连续推三次，三次之后则不会继续推送
			
			reqMap.put("isthirdpos", ConstantsEnv.ISTHIRDPOS);								//秘钥类型   0机构秘钥 1 终端秘钥	(不填写,默认 1终端秘钥)								
	    	reqMap.put("merchant_mode", ConstantsEnv.MERCHANT_MODE); 							//商户模式 0 一户一码 1 大商户	(不填写 默认 1 大商户)
	    	
	    	reqMap.put("arMark", acmsMapUtils.getAcmsMap().get("hf_arMark"));			// CAP2100R610|R620&CAP2100R610|R620(D1费率（借|贷）& S0费率（借|贷））)   
	    	reqMap.put("sRate", acmsMapUtils.getAcmsMap().get("hf_sRate"));				//S0附加手续费填写代号，例：例(FJ200)代表加收2块（FJ250）代表加收2块5
			reqMap.put("posDealType", Constants.CON_YES);								//必填 终端交易类型 0 D1 1 S0  445347692


			NameValuePair[] data = {
					new NameValuePair("orgNo", ConstantsEnv.HF_ORGNO),		//机构编号，由上游提供，请联系技术
					new NameValuePair("data",new EncryptionDES(key).encrypt(URLEncoder.encode(net.sf.json.JSONObject.fromObject(reqMap).toString(),"UTF-8")))
			};
			Log.info("请求弘付D0参数111："+net.sf.json.JSONObject.fromObject(reqMap).toString());
			String responseStr = null;
			HttpClient httpClient = new HttpClient();
			httpClient.getParams().setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, "UTF-8");
			PostMethod postMethod = new PostMethod(URL);
			postMethod.setRequestBody(data);
			httpClient.getHttpConnectionManager().getParams()
					.setConnectionTimeout(10000);
			httpClient.getHttpConnectionManager().getParams().setSoTimeout(10000);
			httpClient.executeMethod(postMethod);

			responseStr = postMethod.getResponseBodyAsString();
			postMethod.releaseConnection();
			net.sf.json.JSONObject jsonObject = net.sf.json.JSONObject.fromObject(URLDecoder.decode(responseStr,"UTF-8"));
			System.out.println("弘付D0返回参数："+URLDecoder.decode(responseStr,"UTF-8"));
			return jsonObject;
//			respCode = (String) jsonObject.get("respCode");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.复核商户,new String[]{"弘付报备D0添加失败"});
		}
	}

	/**
	 * =申请弘付T0
	 * 费率规则：例  封顶35千78费率，费率代号为（FD35Q78）。终端分
	 * 为借记卡费率与贷记卡费率填写格式  借记卡费率|贷记卡费率 例（FD20Q5|Q5）
	 * 修改费率时需要将借记卡费率与贷记卡费率一起上送
	 * @param b2cShopperbi
	 * @return
	 * @throws Exception 
	 */
	public net.sf.json.JSONObject addHfMerchantPort(B2cShopperbiTemp b2cShopperbi) throws Exception {
		String respCode = null;
		try {
			String key = ConstantsEnv.HF_KEY;//加密key
			String URL = ConstantsEnv.HF_MERCHANT_URL;//请求地址
			
			Map<String, String> reqMap = new HashMap<String, String>();
			reqMap.put("orgMerno", b2cShopperbi.getShopperid()==null?"":b2cShopperbi.getShopperid().toString());		//机构商户唯一标识
			reqMap.put("bankName", b2cShopperbi.getAccountbankname());													//开户行名称
			reqMap.put("licenseEndDate", "2050-01-01");																	//营业执照到期时间   yyyy-MM-dd，无数据给默认日期
			reqMap.put("linkMan", b2cShopperbi.getName());																//联系人
			reqMap.put("areaCode", b2cShopperbi.getCity());																//受理区域代码
			reqMap.put("linkPhone", b2cShopperbi.getStel());															//联系电话
			reqMap.put("idCard", b2cShopperbi.getIDNo());																//法人身份证号
			reqMap.put("businessLicense", b2cShopperbi.getLicenseno()==null?"":b2cShopperbi.getLicenseno());			//营业执照号
			reqMap.put("accountNo", b2cShopperbi.getAccountbankno());													//账号
			reqMap.put("legalPerson", b2cShopperbi.getName());															//法人
			reqMap.put("shortName", b2cShopperbi.getName());															//商户简称
			reqMap.put("businessAddress", b2cShopperbi.getSaddress());													//营业地址
			reqMap.put("accountName", b2cShopperbi.getAccountbankname());												//账户名
			reqMap.put("regionCode", b2cShopperbi.getCity());															//行政地区码
			reqMap.put("bankNo", "0000");																				//开户行行号,无数据给0000
			reqMap.put("merName", b2cShopperbi.getScompany());															//商户名称
			reqMap.put("registeredAddress", b2cShopperbi.getSaddress());												//注册地址
			reqMap.put("arMark", "");																					// 终端交易费率代号(注：商户直清时需上送，机构自清时无需上送)
			reqMap.put("txnType", Constants.CON_NO);																		//交易类型 0申请 1变更
			reqMap.put("posType", Constants.CON_YES);																		//pos类型,给默认值1
			reqMap.put("groupNo", Constants.STATUS2);																//费率类型（0标准类 1优惠类2综合类）

			reqMap.put("args", Constants.CON_YES);																			//机构自定义，给默认值1
			reqMap.put("userSign", ConstantsEnv.HF_USERSIGN);																//机构标识，由上游提供，请联系技术
			reqMap.put("requestUrl", "");																				//异步密钥通知地址  接收到返回请返回 success字符串 意味着成功接收到异步通知 则停止通知
																														//，若未响应则会连续推三次，三次之后则不会继续推送 
			NameValuePair[] data = {
				 	new NameValuePair("orgNo", ConstantsEnv.HF_ORGNO),		//机构编号，由上游提供，请联系技术
					new NameValuePair("data",new EncryptionDES(key).encrypt(URLEncoder.encode(net.sf.json.JSONObject.fromObject(reqMap).toString(),"UTF-8")))
			};
			System.out.println("请求弘付T0参数："+net.sf.json.JSONObject.fromObject(reqMap).toString());
			String responseStr = null;
			HttpClient httpClient = new HttpClient();
			httpClient.getParams().setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, "UTF-8");
			PostMethod postMethod = new PostMethod(URL);
			postMethod.setRequestBody(data);
			httpClient.getHttpConnectionManager().getParams()
					.setConnectionTimeout(10000);
			httpClient.getHttpConnectionManager().getParams().setSoTimeout(10000);
			httpClient.executeMethod(postMethod);

			responseStr = postMethod.getResponseBodyAsString();
			postMethod.releaseConnection();
			net.sf.json.JSONObject jsonObject = net.sf.json.JSONObject.fromObject(URLDecoder.decode(responseStr,"UTF-8"));
			System.out.println("弘付T0返回参数："+URLDecoder.decode(responseStr,"UTF-8"));
			return jsonObject;
//			respCode = (String) jsonObject.get("respCode");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.复核商户,new String[]{"弘付报备修改失败"});
		}
	}
	/**
	 * =修改弘付
	 * @param b2cShopperbi
	 * @return
	 * @throws Exception 
	 */
	public net.sf.json.JSONObject updateHfMerchantPort(B2cShopperbiTemp b2cShopperbi) throws Exception{
		String respCode = null;
		try {
			    String key = ConstantsEnv.HF_KEY;                                                                              //加密key
			    String URL = ConstantsEnv.HF_MERCHANT_URL;                                                                     //请求地址
				Map<String, String> reqMap = new HashMap<String, String>();
				reqMap.put("orgMerno", b2cShopperbi.getShopperid()==null?"":b2cShopperbi.getShopperid().toString());		//机构商户唯一标识
				reqMap.put("bankName", b2cShopperbi.getAccountbankname());	                                                //开户行名称
				reqMap.put("licenseEndDate", "2050-01-01");					                                                //营业执照到期时间   yyyy-MM-dd，无数据给默认日期
				reqMap.put("linkMan", b2cShopperbi.getName());								                                //联系人
				reqMap.put("areaCode", b2cShopperbi.getCity());								                                //受理区域代码
				reqMap.put("linkPhone", b2cShopperbi.getStel());						                                    //联系电话
				reqMap.put("idCard", b2cShopperbi.getIDNo());					                                            //法人身份证号
				reqMap.put("businessLicense", b2cShopperbi.getLicenseno()==null?"":b2cShopperbi.getLicenseno());			//营业执照号
				reqMap.put("accountNo", b2cShopperbi.getAccountbankno());				                                    //账号
				reqMap.put("legalPerson", b2cShopperbi.getName());							                                //法人
				reqMap.put("shortName", b2cShopperbi.getName());							                                //商户简称
				reqMap.put("businessAddress", b2cShopperbi.getSaddress());				                                    //营业地址
				reqMap.put("accountName", b2cShopperbi.getAccountbankname());							                    //账户名
				reqMap.put("regionCode", b2cShopperbi.getCity());							                                //行政地区码
				reqMap.put("bankNo", "0000");						                                                        //开户行行号,无数据给0000
				reqMap.put("merName", b2cShopperbi.getScompany());								                            //商户名称
				reqMap.put("registeredAddress", b2cShopperbi.getSaddress());				                                //注册地址
				reqMap.put("arMark", "");									                                                // 终端交易费率代号(注：商户直清时需上送，机构自清时无需上送)
				
				reqMap.put("txnType", Constants.CON_YES);									                                    //交易类型 0申请 1变更
				reqMap.put("posType", Constants.CON_YES);									                                    //pos类型,默认值
				reqMap.put("groupNo", Constants.STATUS2);									                            //费率类型（0标准类 1优惠类2综合类）
				reqMap.put("args", Constants.CON_YES);									                                        //机构自定义
				reqMap.put("userSign", ConstantsEnv.HF_USERSIGN);								                                //机构标识，由上游提供，请联系技术
				reqMap.put("requestUrl", "");								                                                //异步密钥通知地址  接收到返回请返回 success字符串 意味着成功接收到异步通知 则停止通知
																			                                                //，若未响应则会连续推三次，三次之后则不会继续推送 
				NameValuePair[] data = {
					 	new NameValuePair("orgNo", ConstantsEnv.HF_ORGNO),				                                        //机构编号，由上游提供，请联系技术
						new NameValuePair("data",new EncryptionDES(key).encrypt(URLEncoder.encode(net.sf.json.JSONObject.fromObject(reqMap).toString(),"UTF-8")))
				};
				System.out.println("请求弘付参数"+net.sf.json.JSONObject.fromObject(reqMap).toString());
			 	String responseStr = null;
				HttpClient httpClient = new HttpClient();
				httpClient.getParams().setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, "UTF-8");
				PostMethod postMethod = new PostMethod(URL);
				postMethod.setRequestBody(data);
				httpClient.getHttpConnectionManager().getParams()
						.setConnectionTimeout(10000);
				httpClient.getHttpConnectionManager().getParams().setSoTimeout(10000);
				httpClient.executeMethod(postMethod);

				responseStr = postMethod.getResponseBodyAsString();
				postMethod.releaseConnection();
				net.sf.json.JSONObject jsonObject = net.sf.json.JSONObject.fromObject(URLDecoder.decode(responseStr,"UTF-8"));
				System.out.println("弘付返回参数"+URLDecoder.decode(responseStr,"UTF-8"));
//				respCode = (String) jsonObject.get("respCode");
				return jsonObject;
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.复核商户,new String[]{"弘付报备修改失败"});
		}
	}
}
