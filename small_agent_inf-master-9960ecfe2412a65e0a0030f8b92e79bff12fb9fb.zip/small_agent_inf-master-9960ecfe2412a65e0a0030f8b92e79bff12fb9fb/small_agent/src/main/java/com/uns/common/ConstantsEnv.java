package com.uns.common;

import com.uns.inf.acms.client.DynamicConfigLoader;

public class ConstantsEnv {

	
    /**
     * 短信模板
     */
    public static String SMS_CONTENT=DynamicConfigLoader.getByEnv("sms.content.url");

	public static String SMS_CODE_CONTENT=DynamicConfigLoader.getByEnv("sms.code.content.url");
	
	public static String SMS_CODE_SEND = DynamicConfigLoader.getByEnv("sms_code_send.url");

	public static String SMS_CODE_PWD = DynamicConfigLoader.getByEnv("sms_code_pwd.url");

	public static String SMS_APP_CONTENT_TRAN=DynamicConfigLoader.getByEnv("sms_app_content_tran.url");


	//个人 信用卡  ：￥1万    月交易：￥8万
	public static final String PERSONAL_CREDIT=DynamicConfigLoader.getByEnv("personal_credit");
	
	public static final String PERSONAL_MONTH=DynamicConfigLoader.getByEnv("personal_month");

	//鉴权商户编号
	public static final String AUTHENTICATION_MERNUM = DynamicConfigLoader.getByEnv("authentication_mernum");
	//鉴权秘钥
	public static final String AUTHENTICATION_KEY = DynamicConfigLoader.getByEnv("authentication_key");

	//商户信用卡  ：￥5万    月交易：￥40万
	
    public static final String SHOPPER_CREDIT=DynamicConfigLoader.getByEnv("shopper_credit");
	
	public static final String SHOPPER_MONTH=DynamicConfigLoader.getByEnv("shopper_month");
	//小商户功能账户秘钥
	public static final String GNZH_KEY = DynamicConfigLoader.getByEnv("gnzh_key");
	//保理平台秘钥
	public static final String BLZH_KEY = DynamicConfigLoader.getByEnv("blzh_key");
	
	public static final String ACTIVE_LIMIT = DynamicConfigLoader.getByEnv("active_limit");
	
	public static final String APP_ERRORLOG_PATH = DynamicConfigLoader.getByEnv("app_errorlog_path");


	public static final String VI_PRIVATEKEY = DynamicConfigLoader.getByEnv("vi_privatekey");

	public static final String VI_MERCHANTID = DynamicConfigLoader.getByEnv("vi_merchantid");

	public static  String HK_ERVERIP = DynamicConfigLoader.getByEnv("hk_erverip");

	public static  int HK_SERVERPORT = 8088;
	
	public static  String HK_HEADER =DynamicConfigLoader.getByEnv("hk_header");
	
	public static  String HK_MERKEY = DynamicConfigLoader.getByEnv("hk_merkey");

	public static String HK_CHANNELID=DynamicConfigLoader.getByEnv("hk_channelid");
	
	public static final String MERCHANTKEY=DynamicConfigLoader.getByEnv("merchantkey");
	
	public static final String REG_URL = DynamicConfigLoader.getByEnv("app_reg_form.url");
	
	public static final String BIND_URL = DynamicConfigLoader.getByEnv("bind.url");
	
	public static final String IMAGE_URL = DynamicConfigLoader.getByEnv("get_image.url");
	
	public static final String IMAGE_GET_URL = DynamicConfigLoader.getByEnv("imageget.url");
	
	public static final String IMMEDIATELY_MONEY_URL  = DynamicConfigLoader.getByEnv("immediately_money.url");
	
	public static final String TODAY_TRADE_RECORD_URL = DynamicConfigLoader.getByEnv("today_trade_record.url");
	
	public static final String HISTORY_TRADE_RECORD_URL = DynamicConfigLoader.getByEnv("history_traderecord.url");
	
	public static final String T0WITHDRAW_RECORD_URL = DynamicConfigLoader.getByEnv("t0withdraw_record.url");
	
	public static final String BALANCE_URL = DynamicConfigLoader.getByEnv("balance.url");
	
	public static final String T0WITHDRAW_URL = DynamicConfigLoader.getByEnv("t0withdraw.url");
	
	public static final String PHOTO_URL = DynamicConfigLoader.getByEnv("photo.url");
	
	public static final String UPDATE_PHOTO=DynamicConfigLoader.getByEnv("update.photo");
	
	public static final String LIMITURL     = DynamicConfigLoader.getByEnv("addlimit.url");
	
	public static final String REG_SHOUDAN_URL = DynamicConfigLoader.getByEnv("reg_shoudan_url");
	
	public static final String CHECKTELSID  = DynamicConfigLoader.getByEnv("checktel.url");
	
	public static final String SIMPLE_REGISTER_URL = DynamicConfigLoader.getByEnv("simple_register_url");
	
	public static final String SIMPLE_REGISTER_COMPANY_URL = DynamicConfigLoader.getByEnv("simple_register_company_url");
	
	public static final String TRANS_VALIDATE_SMS = DynamicConfigLoader.getByEnv("trans_validate_sms_url");
	
	public static final String MODIFY_BANK_CARD_URL=DynamicConfigLoader.getByEnv("modify_bank_card_url");
	
	public static final String VALIDATION_IDENTITYID_URL = DynamicConfigLoader.getByEnv("validation_identityid_url");
	
	public static final String D0COMMISSION_URL = DynamicConfigLoader.getByEnv("d0commission_url");
	
	public static final String T1_TRAN_LIST_URL = DynamicConfigLoader.getByEnv("t1_tran_list.url");
	
	public static final String REG_QR_PAY_MERCHANT_URL=DynamicConfigLoader.getByEnv("reg_qr_pay_merchant_url");
	
	public static final String REG_QR_PAY_COMPANY_URL=DynamicConfigLoader.getByEnv("reg_qr_pay_company_url");
	
	public static final String Fixed_Qr_Code_Url = DynamicConfigLoader.getByEnv("fixed_qr_code.url");

	public static final String MER_FIXED_QR_CODE_URL = DynamicConfigLoader.getByEnv("mer_fixed_qr_code.url");

	public static final String MPOS_AGENT_UPDATE_URL = DynamicConfigLoader.getByEnv("mpos_agent_update_url");
	
	public static final String QRCODE_AGENT_UPDATE_URL = DynamicConfigLoader.getByEnv("qrcode_agent_update_url");
	
	public static final String AUTHENTICATION_URL = DynamicConfigLoader.getByEnv("authentication_url");
	/**
	 * 二维码绑定URL
	 */
	public static final String QRCODE_BIND_URL = DynamicConfigLoader.getByEnv("qrcode_bind_url");
	
	public static final String QRPAY_ADDLIMITURL = DynamicConfigLoader.getByEnv("qrpay_addlimit.url");

	public static final String UPDATE_RS_PMSG = DynamicConfigLoader.getByEnv("update_rs_pmsg");

	public static final String RESPONSE_CODE = DynamicConfigLoader.getByEnv("response_code");

	public static final String HK_SUCCESS_CODE = DynamicConfigLoader.getByEnv("hk_success_code");

	public static final String HK_SUCCESS_CODE_01 = DynamicConfigLoader.getByEnv("hk_success_code_01");

	public static final String HK_REPEAT_CODE_H2 = DynamicConfigLoader.getByEnv("hk_repeat_code_h2");

	public static final String HF_OPEN_FLG = DynamicConfigLoader.getByEnv("hf_open_flg");

	public static final String HF_KEY = DynamicConfigLoader.getByEnv("hf_key");

	public static final String HF_MERCHANT_URL = DynamicConfigLoader.getByEnv("hf_merchant_url");

	public static final String HF_USERSIGN = DynamicConfigLoader.getByEnv("hf_usersign");

	public static final String HF_ORGNO = DynamicConfigLoader.getByEnv("hf_orgno");

	public static final String HF_CODE_ADD = DynamicConfigLoader.getByEnv("hf_code_add");

	public static final String HF_CODE_UPDATE = DynamicConfigLoader.getByEnv("hf_code_update");

	/**
	 * 弘付图片报备socket IP 端口
	 */
	public static final String HF_IMAGE_REG_SOCKET_IP = DynamicConfigLoader.getByEnv("hf_image_reg_socket_ip");
	public static final int HF_IMAGE_REG_SOCKET_PORT = Integer.valueOf(DynamicConfigLoader.getByEnv("hf_image_reg_socket_port"));
	public static final String GET_HF_IMAGE_URL = DynamicConfigLoader.getByEnv("get_hf_image_url");

	//App数据传输敏感信息加密解密key
	public static final String APP_AES_KEY = DynamicConfigLoader.getByEnv("app_aes_key");

	public static final String ISTHIRDPOS = DynamicConfigLoader.getByEnv("hf_isthirdpos");
	
	public static final String MERCHANT_MODE = DynamicConfigLoader.getByEnv("hf_merchant_mode");

	public static final String DIRECT_AGENTNO = DynamicConfigLoader.getByEnv("direct_agentno"); //直营商户编号

    public static final String APP_AUTHORIZATION_URL= DynamicConfigLoader.getByEnv("app_authorization_url");
    public static final String REMOVE_AUTHORIZATION_URL = DynamicConfigLoader.getByEnv("remove_authorization_url");
	//分润方案
	public static final String AGENT_PROFIT_RATIO = DynamicConfigLoader.getByEnv("agent_profit_ratio_agent");
	public static final String PROFIT_OWNER = DynamicConfigLoader.getByEnv("profit_owner_agent");
	public static final String MERCH_PROFIT_RATIO1 = DynamicConfigLoader.getByEnv("merch_profit1_agent");
	public static final String MERCH_PROFIT_RATIO2 = DynamicConfigLoader.getByEnv("merch_profit2_agent");
	public static final String MERCH_PROFIT_RATIO3 = DynamicConfigLoader.getByEnv("merch_profit3_agent");

	public static final String MPOS_ACCOUNT_CREDITLINES = DynamicConfigLoader.getByEnv("MPOS_ACCOUNT_CREDITLINES");
	public static final String MPOS_QRCODE_CREDITLINES = DynamicConfigLoader.getByEnv("MPOS_QRCODE_CREDITLINES");
	public static final String QRCODE_FGR_SYSCONFIG = DynamicConfigLoader.getByEnv("QRCODE_FGR_SYSCONFIG");
	public static final String UPDATE_MERCHANT = DynamicConfigLoader.getByEnv("UPDATE_MERCHANT");

	public static final String HTTP_PROTOCOL = "http://";

	public static final String MPOS_QRCODE_URL = DynamicConfigLoader.getByEnv("MPOS_QRCODE_URL");
	public static final String MPOS_QRCODE_QUERY_CONFIG = DynamicConfigLoader.getByEnv("MPOS_QRCODE_QUERY_CONFIG");

	public static final String HK_REPORT_URL = DynamicConfigLoader.getByEnv("hk_report_url");
	public static final String HK_AUTH_QUERY_URL = DynamicConfigLoader.getByEnv("hk_auth_query_url");
	public static final String HK_ADD_TERMINAL = DynamicConfigLoader.getByEnv("hk_add_terminal");

	//查询默认代理商编号
	public static final String MPOS_DEFAULT_AGENT = DynamicConfigLoader.getByEnv("mpos_default_agent");
}
