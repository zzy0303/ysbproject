package com.uns.web;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.model.B2cShopperbi;
import com.uns.service.RecordService;
import com.uns.util.HttpClientUtils;
import com.uns.util.Md5Encrypt;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;

@Controller
@RequestMapping(value="/appCommissionCotroller.htm")
public class AppCommissionCotroller extends BaseController{
	@Autowired
	private RecordService recordService;
	
	/**
	 * 查询T+0提现手续费
	 * @param merchantId 商户号
	 * @param amount 提现金额
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(params = "method=d0Commission")
	public void d0Commission(HttpServletRequest request,HttpServletResponse response) throws IOException{
		response.setContentType("UTF-8");
		String merchantId = request.getParameter("merchantId");
		String amount = request.getParameter("amount");
		//判断参数是否为空
		if(val(merchantId) || val(amount)){
			response.getWriter().write(errorMsg("11110001"));
			return;
		}else{
			//根据商户号查询
			B2cShopperbi b2cShopperbi = recordService.findFactoringNoByShopperid(merchantId.trim());
			//如果根据商户号查不到商户信息
			if(b2cShopperbi==null){
				response.getWriter().write(errorMsg("11110005"));
				return;
			}
			//如果查到的商户没有银生宝账号
			String userId = b2cShopperbi.getYsbNo();
			if(val(userId)){
				response.getWriter().write(errorMsg("11110010"));
				return;
			}
			//发送请求并接收
			String record = null;
			try {
				String str = "&amount=" +amount;
				String requestStr = macBLZH(userId, str);
				log.info("请求："+ ConstantsEnv.D0COMMISSION_URL+"   "+requestStr);
				record = HttpClientUtils.REpostRequestStr(ConstantsEnv.D0COMMISSION_URL ,requestStr);
				log.info("响应："+record);
				JSONObject  json = JSONObject.fromObject(record);
				if(Constants.mapReturnMsg.containsKey(json.get("rspCode"))){
					json.put("rspMsg", Constants.mapReturnMsg.get(json.get("rspCode")));
				}
				record = json.toString();
			} catch (Exception e) {
				response.getWriter().write(errorMsg("11110002"));
				e.printStackTrace();
				return;
			}
			response.getWriter().write(record);
			return;
		}
		
	}

	/**
	 * 验证非空
	 */
	public boolean val(String param){
		if(param == null || param == ""){
			return true;
		}
		return false;
	}
	
	/**
	 *  根据返回码，生成返回值
	 */
	public String errorMsg(String code){
		HashMap<String,String> hashMap = new HashMap<String, String>();
		hashMap.put("rspCode", code);
		hashMap.put("rspMsg", Constants.mapReturnMsg.get(code));
		String mac = Md5Encrypt.md5("rspCode=" + code + "&rspMsg=" + Constants.mapReturnMsg.get(code));
	    hashMap.put("mac", mac);
		return JSONObject.fromObject(hashMap).toString();
	}
	
	/**
	 * 算mac,GNZH
	 */
	public String macBLZH(String userId,String str){
		return "userId=" + userId + str + "&mac=" + Md5Encrypt.md5("userId=" + userId + str + "&merchantKey=" + ConstantsEnv.BLZH_KEY).toLowerCase();
	}
}
