package com.uns.util;

import com.uns.inf.acms.client.core.ChangeHandler;
import com.uns.inf.acms.client.core.ChangedConfig;
import com.uns.inf.acms.client.core.ConfigOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import java.util.List;

public class AcmsHandler implements ChangeHandler,ApplicationContextAware{
	
	private static Logger log = LoggerFactory.getLogger(AcmsHandler.class);
	
	private String TEST_KEY;

	@Override
	public void handle(List<ChangedConfig> configs) {
		for (ChangedConfig config : configs) {
			String key = config.getConfigKey();
			String value = config.getConfigValue();
			ConfigOperation op = config.getOp();
			log.info("acms enent="+op.name()+",key="+key+",value="+value);
			String urlKey = key.substring(TEST_KEY.length()+1);
			log.info("Send urlKey["+urlKey+"] has changed");
			if(urlKey.indexOf(".") < 0){
				log.info("参数"+key+"值由"+config.getOldConfigValue()+"变为"+value);
				if(ConfigOperation.Add.equals(op) || ConfigOperation.Update.equals(op)){
					try {
					} catch (Exception e) {
						log.error("Failed to set " + urlKey
								+"Sender property. key = " + key + ",value = "+
								value,e);
					}
				}else if(ConfigOperation.Delete.equals(op)) {
					try {
					} catch (Exception e) {
						log.error("Failed to set " + urlKey
								+"Sender property. key = " + key + ",value = "+
								value,e);
					}
				}
			}
		}
	}
	
	@Override
	public void setApplicationContext(ApplicationContext arg0) throws BeansException {
		
	}
	
	public String getTEST_KEY() {
		return TEST_KEY;
	}

	public void setTEST_KEY(String tEST_KEY) {
		TEST_KEY = tEST_KEY;
	}
	
}
