package com.uns.model;

import java.util.Date;

public class MposRemoteInvitation {
    private Long remoteInvitationId;

    private Long salesman;

    private String tel;

    private String fee;

    private String openToFlag;

    private String icCardFlag;

    private String t0Fee;

    private String shopperLimit;

    private String agentId;

    private Date createDate;

    private Date remoteInvitation;

    private Date pastDate;

    private String status;

    private String verificationCode;

    private Date updateDate;
    
    private String password;
    
    private String t0type;
    
    private String t1type; 
    private Double t0fixedamount; 
    private Double t0topamount; 
    private Double t0additionfee; 
    private Double t0minamount; 
    private Double t0maxamount; 
    private Double t1fee;
    private Double t1topamount;
    private String  cardType;
    private String  firstLogin;

	public String getFirstLogin() {
		return firstLogin;
	}

	public void setFirstLogin(String firstLogin) {
		this.firstLogin = firstLogin;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public String getT1type() {
		return t1type;
	}

	public void setT1type(String t1type) {
		this.t1type = t1type;
	}

	public Double getT0fixedamount() {
		return t0fixedamount;
	}

	public void setT0fixedamount(Double t0fixedamount) {
		this.t0fixedamount = t0fixedamount;
	}

	public Double getT0topamount() {
		return t0topamount;
	}

	public void setT0topamount(Double t0topamount) {
		this.t0topamount = t0topamount;
	}

	public Double getT0additionfee() {
		return t0additionfee;
	}

	public void setT0additionfee(Double t0additionfee) {
		this.t0additionfee = t0additionfee;
	}

	public Double getT0minamount() {
		return t0minamount;
	}

	public void setT0minamount(Double t0minamount) {
		this.t0minamount = t0minamount;
	}

	public Double getT0maxamount() {
		return t0maxamount;
	}

	public void setT0maxamount(Double t0maxamount) {
		this.t0maxamount = t0maxamount;
	}

	public Double getT1fee() {
		return t1fee;
	}

	public void setT1fee(Double t1fee) {
		this.t1fee = t1fee;
	}

	public Double getT1topamount() {
		return t1topamount;
	}

	public void setT1topamount(Double t1topamount) {
		this.t1topamount = t1topamount;
	}

	public String getT0type() {
		return t0type;
	}

	public void setT0type(String t0type) {
		this.t0type = t0type;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public Long getRemoteInvitationId() {
        return remoteInvitationId;
    }

    public void setRemoteInvitationId(Long remoteInvitationId) {
        this.remoteInvitationId = remoteInvitationId;
    }

    public Long getSalesman() {
        return salesman;
    }

    public void setSalesman(Long salesman) {
        this.salesman = salesman;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel == null ? null : tel.trim();
    }

    public String getFee() {
        return fee;
    }

    public void setFee(String fee) {
        this.fee = fee == null ? null : fee.trim();
    }

    public String getOpenToFlag() {
        return openToFlag;
    }

    public void setOpenToFlag(String openToFlag) {
        this.openToFlag = openToFlag == null ? null : openToFlag.trim();
    }

    public String getIcCardFlag() {
        return icCardFlag;
    }

    public void setIcCardFlag(String icCardFlag) {
        this.icCardFlag = icCardFlag == null ? null : icCardFlag.trim();
    }

    public String getT0Fee() {
        return t0Fee;
    }

    public void setT0Fee(String t0Fee) {
        this.t0Fee = t0Fee == null ? null : t0Fee.trim();
    }

    public String getShopperLimit() {
        return shopperLimit;
    }

    public void setShopperLimit(String shopperLimit) {
        this.shopperLimit = shopperLimit == null ? null : shopperLimit.trim();
    }

    public String getAgentId() {
        return agentId;
    }

    public void setAgentId(String agentId) {
        this.agentId = agentId == null ? null : agentId.trim();
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getRemoteInvitation() {
        return remoteInvitation;
    }

    public void setRemoteInvitation(Date remoteInvitation) {
        this.remoteInvitation = remoteInvitation;
    }

    public Date getPastDate() {
        return pastDate;
    }

    public void setPastDate(Date pastDate) {
        this.pastDate = pastDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    public String getVerificationCode() {
        return verificationCode;
    }

    public void setVerificationCode(String verificationCode) {
        this.verificationCode = verificationCode == null ? null : verificationCode.trim();
    }
}