package com.uns.dao;

import com.uns.model.B2cCreditCount;
import org.springframework.stereotype.Repository;

/**
 * Created by Administrator on 2017/2/27.
 */
@Repository
public interface B2cCreditCountMapper {
    int addCreditCount(B2cCreditCount b2cCreditCount);
}
