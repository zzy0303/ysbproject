package com.uns.model;

import java.math.BigDecimal;

public class B2cFootfreq {
   
    private BigDecimal b2cFootfreqId;
    private String footfreq;
    private String gbid;
    private BigDecimal intervalunitid;
    private String intervalunit;
    private BigDecimal frenqece;
    private String freqexec;
    private BigDecimal gradeid;
    private BigDecimal interminute;
    
	public BigDecimal getB2cFootfreqId() {
		return b2cFootfreqId;
	}
	public void setB2cFootfreqId(BigDecimal b2cFootfreqId) {
		this.b2cFootfreqId = b2cFootfreqId;
	}
	public String getFootfreq() {
		return footfreq;
	}
	public void setFootfreq(String footfreq) {
		this.footfreq = footfreq;
	}
	public String getGbid() {
		return gbid;
	}
	public void setGbid(String gbid) {
		this.gbid = gbid;
	}
	public BigDecimal getIntervalunitid() {
		return intervalunitid;
	}
	public void setIntervalunitid(BigDecimal intervalunitid) {
		this.intervalunitid = intervalunitid;
	}
	public String getIntervalunit() {
		return intervalunit;
	}
	public void setIntervalunit(String intervalunit) {
		this.intervalunit = intervalunit;
	}
	public BigDecimal getFrenqece() {
		return frenqece;
	}
	public void setFrenqece(BigDecimal frenqece) {
		this.frenqece = frenqece;
	}
	public String getFreqexec() {
		return freqexec;
	}
	public void setFreqexec(String freqexec) {
		this.freqexec = freqexec;
	}
	public BigDecimal getGradeid() {
		return gradeid;
	}
	public void setGradeid(BigDecimal gradeid) {
		this.gradeid = gradeid;
	}
	public BigDecimal getInterminute() {
		return interminute;
	}
	public void setInterminute(BigDecimal interminute) {
		this.interminute = interminute;
	}
	public B2cFootfreq() {
		super();
	}
    
   
}