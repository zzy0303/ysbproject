package com.uns.web;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.model.*;
import com.uns.service.AgentService;
import com.uns.service.PhotoService;
import com.uns.service.SendMessageService;
import com.uns.service.ShopPerbiService;
import com.uns.util.DateUtil;
import com.uns.util.HttpClientUtils;
import com.uns.util.ToolsUtils;
import net.sf.json.JSONObject;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLDecoder;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping(value = "/appagentController.htm")
public class AppAgentController extends BaseController {

	@Autowired
	private ShopPerbiService merchantregservice;

	@Autowired
	private AgentService agentservice;
    
	
	@Autowired
	private PhotoService photoservice;

	@Autowired
	private SendMessageService sendMessageService;

	/**
	 * 查询服务商下商户申请进度详情
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(params = "method=applicationProInfo")
	public void applicationProInfo(HttpServletRequest request, HttpServletResponse response) throws IOException {
		response.setContentType("UTF-8");
		HashMap hashMap = new HashMap();
		String requestQuery = request.getQueryString();
		try {
			hashMap = agentservice.applicationProInfo(request);
			if(Constants.TYPE_A.equals(request.getParameter("type"))){
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("查询申请进度详情{}:{}",requestQuery,json.toString());
				response.getWriter().write(json.toString());
			}else{
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("查询申请进度详情{}:{}",requestQuery,json.toString());
				response.getWriter().write(json.toString());
			}

		}catch (Exception e){
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "出错");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("查询申请进度详情{}:{}",requestQuery,json.toString());
			response.getWriter().write(json.toString());
		}
	}

	/**
	 * 查询代理商下商户申请进度
	 * status 0:未审核 1:初审通过 2:初审未通过 3:复审通过 4:复审未通过
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(params = "method=applicationPro")
	public void applicationPro(HttpServletRequest request, HttpServletResponse response) throws IOException {
		response.setContentType("UTF-8");
		HashMap hashMap = new HashMap();
		String requestQuery = request.getQueryString();
		try {
			hashMap = agentservice.applicationProList(request);
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("查询申请进度{}:{}",requestQuery,json.toString());
			response.getWriter().write(json.toString());
		}catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "出错");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("查询申请进度{}:{}",requestQuery,json.toString());
			response.getWriter().write(json.toString());
		}
	}




	/**
	 * 代理商忘记密码 密码修改
	 * @param request
	 * @param response
	 */
	@RequestMapping(params = "method=agentUpdatePwd")
	public void agentUpdatePwd(HttpServletRequest request, HttpServletResponse response) throws IOException {
		response.setContentType("UTF-8");
		HashMap hashMap = new HashMap();
		String requestQuery = request.getQueryString();
		try {
			hashMap = agentservice.agentUpdatePwd(request);
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("服务商密码修改{}:{}",requestQuery,json.toString());
			response.getWriter().write(json.toString());
		}catch (Exception e){
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "出错");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("服务商密码修改{}:{}",requestQuery,json.toString());
			response.getWriter().write(json.toString());
		}
	}

	/**
	 * 代理商忘记密码 验证验证码是否正确 过期
	 * @param request
	 * @param response
	 */
	@RequestMapping(params = "method=agentCheckCode")
	public void agentCheckCode(HttpServletRequest request, HttpServletResponse response) throws IOException {
		response.setContentType("UTF-8");
		HashMap hashMap = new HashMap();
		String requestQuery = request.getQueryString();
		try {
			hashMap = agentservice.agentCheckCode(request);
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("服务商验证验证码{}:{}",requestQuery,json.toString());
			response.getWriter().write(json.toString());
		}catch (Exception e){
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "出错");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("服务商验证验证码{}:{}",requestQuery,json.toString());
			response.getWriter().write(json.toString());
		}
	}

	/**
	 * 代理商忘记密码 验证手机号是否已注册
	 * 已注册 发送验证码
	 * 未注册 提示手机号未注册
	 * @param request
	 * @param response
	 */
	@RequestMapping(params = "method=agentSendCode")
	public void agentSendCode(HttpServletRequest request, HttpServletResponse response) throws IOException {
		response.setContentType("UTF-8");
		String tel = request.getParameter("tel") == null ? "" : request.getParameter("tel").trim();
		HashMap hashMap = new HashMap();
		String requestQuery = request.getQueryString();
		try {

			String smsCode = org.apache.commons.lang.RandomStringUtils.randomNumeric(6);
			hashMap = agentservice.checkTel(tel,smsCode);
			if("0000".equals(hashMap.get("rspCode"))){
				// 发送短信验证码
				B2cShopperVal b2cShopperVal = new B2cShopperVal();
				b2cShopperVal.setTel(tel);
				b2cShopperVal.setSmsCode(smsCode);
				sendMessageService.sendCodeMessagePwd(b2cShopperVal,request);
				hashMap.put("rspMsg","验证码已发送");
			}
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("服务商验证手机号{}:{}",requestQuery,json.toString());
			response.getWriter().write(json.toString());
		}catch (Exception e){
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "出错");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("服务商验证手机号{}:{}",requestQuery,json.toString());
			response.getWriter().write(json.toString());
		}
	}
	
	/**代理商面签注册
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(params = "method=agentreg")
	public void agentreg(HttpServletRequest request,HttpServletResponse response) throws Exception {
		String version  = request.getParameter("version") == null ? "" : request.getParameter("version");
	    if((Constants.VERSION_2_0_1).equals(version)){
	    	agentreg201(request,response);
	    }else{
	    	agentreg001(request,response);
	    }
	}
	
	/**代理商注册 2.0.1
	 * @param request
	 * @param response
	 * @throws Exception 
	 */
	private void agentreg201(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Map hashMap = new HashMap();
		try {
			
			String tel = request.getParameter("tel")==null?"":request.getParameter("tel").trim();
			String shopperType=request.getParameter("shopperType")==null?"":request.getParameter("shopperType").trim();//商户类型
			String debitfee = request.getParameter("debitfee") == null ? "" : request.getParameter("debitfee");//借记卡 费率
			String creditFee = request.getParameter("creditfee") == null ? "" : request	.getParameter("creditfee");//贷记卡 费率
			
			String weChatT1fee=request.getParameter("weChatfee") == null ? "" : request	.getParameter("weChatfee");//微信 T1 费率
			String aliPayT1Fee=request.getParameter("aliPayfee") == null ? "" : request	.getParameter("aliPayfee");//支付宝 T1 费率
			
			String OpenT0Flag=request.getParameter("OpenT0Flag");
//			String icCardFlag=request.getParameter("icCardFlag");
			String t0Fee=request.getParameter("t0Fee");//d0费率
			String t0fixedamount=request.getParameter("t0fixedamount");//固定金额
			String shopperLimit=request.getParameter("shopperLimit");//当日提现限额
	        String t0minamount=request.getParameter("t0minamount");//单笔范围最小金额
	        String t0maxamount=request.getParameter("t0maxamount");//单笔范围最大金额
			
			String billCity = request.getParameter("billCity") == null ? "": request.getParameter("billCity").trim();// 票据城市编码
			String billProvince = request.getParameter("billProvince") == null ? "": request.getParameter("billProvince").trim();// 票据省份编码
			String cardCity = request.getParameter("cardCity")==null?"":request.getParameter("cardCity").trim();
			String cardProvince =request.getParameter("cardProvince")==null?"":request.getParameter("cardProvince").trim();
			String industryType = request.getParameter("industryType")==null?"":request.getParameter("industryType").trim();
			String address=URLDecoder.decode(request.getParameter("address") , "UTF-8");
			String billName=URLDecoder.decode(request.getParameter("billName") , "UTF-8");
			
			String Name=request.getParameter("Name");//名字
			String identityId=request.getParameter("identityId").toUpperCase();//身份证
			String scompany=request.getParameter("scompany")==null?"":request.getParameter("scompany");
			String licenseNo=request.getParameter("licenseNo")==null?"":request.getParameter("licenseNo");
			String clientName=request.getParameter("clientName")==null?"":request.getParameter("clientName");
			String bankCard=request.getParameter("bankCard");
			String shopperidp=request.getParameter("shopperidp");
			String branchBankName=request.getParameter("branchBankName");
			
			String weChatD0fee = request.getParameter("weChatD0fee")==null?"0": request.getParameter("weChatD0fee");//微信 D0手续费 费率
			String aliPayD0Fee = request.getParameter("aliPayD0fee")==null?"0": request.getParameter("aliPayD0fee");//支付宝 D0手续费 费率


			B2cShopperbiTemp temptel = merchantregservice.findbytel(tel);//验证手机号是否存在
			String flag=checkTelSid(tel,identityId);//验证手机号，身份证是否在银生宝注册
			B2cShopperbiTemp shoppersid=merchantregservice.findbysid(identityId);//验证身份证是否已注册
			if(temptel!=null){
				// 该手机号码已存在
				hashMap.put("rspCode", "1001");
				hashMap.put("rspMsg", "电话号码已注册");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("电话号码已注册" + json.toString());
				response.getWriter().write(json.toString());
				return;
			}
			if(shoppersid!=null){
				// 该手机号码已存在
				hashMap.put("rspCode", "1002");
				hashMap.put("rspMsg", "该商户已注册");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("电话号码已注册" + json.toString());
				response.getWriter().write(json.toString());
				return;
			}
			if(!(Constants.SUCCESS_CODE.equals(flag))){
				hashMap.put("rspCode", "6020");
				hashMap.put("rspMsg", "电话号码已注册");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("电话号码已在银生宝注册，与商户名称不一致：" + json.toString());
				response.getWriter().write(json.toString());
				return;
			}
			
		
			
			B2cDict industry = merchantregservice.findbyhCname(industryType);
			B2cShopperbiTemp shopper = new B2cShopperbiTemp();
			shopper.setMerchantType(shopperType);
			shopper.setStel(tel);
			shopper.setName(URLDecoder.decode(Name, "UTF-8"));
			shopper.setIDNo(identityId);
			
			if (industry != null) {
				log.info(tel + "获取行业类型成功");
				shopper.setIndustry(industry.getB2cDictId().toString());
			}
			
			Area area = merchantregservice.findbyareaid(billProvince,billCity);
			if (area != null) {
				log.info(tel + "获取票据的省市成功");
				shopper.setBillCity(area.getCityname());
				shopper.setScity(area.getCityname());
				shopper.setBillCityCode(area.getCity());
				shopper.setCity(area.getCity());
				shopper.setBillProvince(area.getProvincialname());
				shopper.setSprovince(area.getProvincialname());
				shopper.setBillProvinceCode(area.getProvincial());
				shopper.setProvince(area.getProvincial());
			}
			shopper.setBillAddress(URLDecoder.decode(address , "UTF-8"));
			shopper.setSaddress(URLDecoder.decode(address , "UTF-8"));
			shopper.setBillName(URLDecoder.decode(billName , "UTF-8"));
			shopper.setIsSupportT0(OpenT0Flag);
			//0:支持
		    if((OpenT0Flag.trim()).equals("0")){
		    	log.info(tel + "支持T+0");
		    	String t0fee=ToolsUtils.div(Double.parseDouble(t0Fee), 1, 4);
//		    	shopper.setIsIcApplyT0(icCardFlag);
				shopper.setT0SingleDayLimit(Double.parseDouble(shopperLimit)) ;
				shopper.setT0fee(Double.parseDouble(t0fee));
	        	shopper.setT0fixedamount(Double.parseDouble(t0fixedamount));
				//新增功能费率  t0					
				shopper.setT0minamount(Double.parseDouble(t0minamount));
				shopper.setT0maxamount(Double.parseDouble(t0maxamount));
		    }
		    if(shopperType.equals("1")){
		    	log.info(tel + "商户类型为企业");
		    	shopper.setScompany(URLDecoder.decode(scompany, "UTF-8"));
		    	shopper.setLicenseNo(licenseNo);
		    }else{
		    	shopper.setScompany(Name);
		    }
			
			shopper.setAccountbankclientname(Name);
			shopper.setAccountbankno(bankCard );
			// 开户行名称数据字典
			shopper.setAccountbankdictval(URLDecoder.decode(clientName, "UTF-8"));
			// 发卡
			Area area1 = merchantregservice.findbyareaid(cardProvince,cardCity);
			if (area1 != null) {
				log.info(tel + "获取开户行省份成功");
				shopper.setAccountBankCity(area1.getCityname());
				shopper.setAccountBankCityCode(area1.getCity());
				shopper.setAccountbankprov(area1.getProvincialname());
				shopper.setAccountBankProvCode(area1.getProvincial());
			}
			// 支行名称
			shopper.setAccountbankname(URLDecoder.decode(branchBankName,"UTF-8"));
			shopper.setReportResource(Constants.STATUS0);// 代理报件
			shopper.setCreated(new Date());
			// 生成商户编号
			Area area2 = merchantregservice.findbyareaid(cardProvince,cardCity);
			String shopperid = getPosShopperId(area2.getCity(),	Constants.CON_MCC);
			shopper.setShopperid(Long.valueOf(shopperid));
			shopper.setShopperidP(Long.valueOf(shopperidp));
			// 默认添加字段
			shopper.setIfvalid(Short.valueOf(Constants.STATUS0));
			shopper.setOpencheckstatus(Short.valueOf(Constants.STATUS0));
			shopper.setIsformal(Short.valueOf(Constants.STATUS0));
			shopper.setIsupdateshopper(Short.valueOf(Constants.STATUS0));
			shopper.setRecheckmerchantflag(Constants.STATUS0);
			shopper.setSifpactid(Long.valueOf(Constants.STATUS0));
			shopper.setMuserid(tel);
			shopper.setPhotoCheckFlag(Constants.STATUS0);
			shopper.setPhotoRecheckFlag(Constants.STATUS0);
			// MIN_SETTLE_MONEY最小结算金额
			shopper.setMinsettlemoney(Double.valueOf(Constants.MIN_SETTLE_MONEY));

			//申请进度表
			MposApplicationProgress progress = new MposApplicationProgress();
			progress.setShopperid(shopper.getShopperid().toString());
			
			if(shopperType.equals("1")){
				progress.setScompany(scompany);
		    }else{
		    	progress.setScompany(Name);
		    }
			progress.setApplicationTheme(Constants.THEME);
			progress.setApplicationType(Constants.STATUS1);
			progress.setApplicationStatus(Constants.STATUS1);
			progress.setApplicationRemark("待审核");
			progress.setCreateDate(new Date());
			progress.setShopperidP(shopperidp);
			Agent agent = agentservice.findbyshopperidp(request.getParameter("shopperidp") );
			progress.setAgentName(agent.getScompany());
            
			MposPhotoTmp photo =this.photoservice.findbsid(identityId);
			if(photo==null){
				hashMap.put("rspCode", "2222");
				hashMap.put("rspMsg", "照片上传失败");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info(tel + "照片上传失败" + json.toString());
				response.getWriter().write(json.toString());
				return;
			}else{
				log.info(tel + "照片上传成功");
				shopper.setPhotoid(photo.getPhotoId());
				progress.setPhotoId(photo.getPhotoId());
			}

			this.merchantregservice.insertMerchant(shopper,progress,debitfee,creditFee,weChatT1fee,aliPayT1Fee,weChatD0fee,aliPayD0Fee);
			hashMap.put("rspCode", "0000");
			hashMap.put("rspMsg", "注册成功");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("代理商面签成功" + json.toString());
			response.getWriter().write(json.toString());
			return;
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "注册出错");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("注册出错:" + json.toString());
			response.getWriter().write(json.toString());
		}
		
	}

	/**
	 * app代理商申请表 1.获取注册信息
	 * 
	 * @throws IOException
	 */
	public void agentreg001(HttpServletRequest request,HttpServletResponse response) throws IOException {
		Map hashMap = new HashMap();
		try {
			String stel = "";
			// 验证商户名称是否重复
			String billCity = request.getParameter("billCity") == null ? "": request.getParameter("billCity").trim();// 票据城市编码
			String billProvince = request.getParameter("billProvince") == null ? "": request.getParameter("billProvince").trim();// 票据省份编码
			String settlementtype = request.getParameter("settlementtype").trim();// 结算方式
			String tel = request.getParameter("tel")==null?"":request.getParameter("tel").trim();
			String cardCity = request.getParameter("cardCity")==null?"":request.getParameter("cardCity").trim();
			String cardProvince =request.getParameter("cardProvince")==null?"":request.getParameter("cardProvince").trim();
			String industryType = request.getParameter("industryType")==null?"":request.getParameter("industryType").trim();
			String shopperType=request.getParameter("shopperType")==null?"":request.getParameter("shopperType").trim();
			String fee = URLDecoder.decode(request.getParameter("fee") , "UTF-8");
			String t0Fee=request.getParameter("t0Fee");
			String t0type=request.getParameter("t0type");//t0type 0-费率机，1-封顶机
            String t1type=request.getParameter("t1type"); //0 费率  1封顶    
            String t0fixedamount=request.getParameter("t0fixedamount");//固定金额
            String t0additionfee=request.getParameter("t0additionfee");//附加费率
            String t0topamount=request.getParameter("t0topamount");//封顶
            String t0minamount=request.getParameter("t0minamount");//单笔范围最小金额
            String t0maxamount=request.getParameter("t0maxamount");//单笔范围最大金额
        	String t1fee=request.getParameter("t1fee");
			String t1topamount=request.getParameter("t1topamount");
//			String cardType=request.getParameter("cardType");
	
			
			B2cShopperbiTemp temptel = merchantregservice.findbytel(tel);
			String sid=request.getParameter("identityId").toUpperCase();
			
			String flag=checkTelSid(tel,sid);
			if (temptel != null) {	
			
				// 该手机号码已存在
				hashMap.put("returnCode", "1001");
				hashMap.put("msg", "电话号码已存在");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("注册信息1001电话号码已存在" + json.toString());
				response.getWriter().write(json.toString());
				return;
				
			} else {
				B2cShopperbiTemp shopper = new B2cShopperbiTemp();
				shopper.setMerchantType(shopperType);
				shopper.setStel(request.getParameter("tel"));
				shopper.setName(URLDecoder.decode(request.getParameter("Name") , "UTF-8"));
				
				
				B2cShopperbiTemp shoppersid=merchantregservice.findbysid(sid);
				if(shoppersid==null&&sid!=null){
					shopper.setIDNo(sid);
					if(!(Constants.SUCCESS_CODE.equals(flag))){
						hashMap.put("returnCode", "6020");
						hashMap.put("msg", "手机号已存在");
						response.setContentType("UTF-8");
						JSONObject json = JSONObject.fromObject(hashMap);
						log.info("手机号在银生宝已存在，与商户信息不匹配" + json.toString());
						response.getWriter().write(json.toString());
						return;
					}
				}else{
					hashMap.put("returnCode", "8888");
					hashMap.put("msg", "身份证号码已存在");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("注册信息8888身份证号码已存在" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}
				/**判断是否允许封顶商户注册：cardtype 0 费率 1 封顶*//*
				if(!(Constants.CON_NO.equals(cardType))){
					hashMap.put("returnCode", "2222");
					hashMap.put("msg", "交易类型请选择费率");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info("交易类型" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}*/
				
				B2cDict industry = merchantregservice.findbyhCname(industryType);
				if (industry != null) {
					log.info(tel + "获取行业类型成功");
					shopper.setIndustry(industry.getB2cDictId().toString());
				}
				Area area = merchantregservice.findbyareaid(billProvince,billCity);
				if (area != null) {
					log.info(tel + "获取票据的省市成功");
					shopper.setBillCity(area.getCityname());
					shopper.setScity(area.getCityname());
					shopper.setBillCityCode(area.getCity());
					shopper.setCity(area.getCity());
					shopper.setBillProvince(area.getProvincialname());
					shopper.setSprovince(area.getProvincialname());
					shopper.setBillProvinceCode(area.getProvincial());
					shopper.setProvince(area.getProvincial());
				}
				shopper.setBillAddress(URLDecoder.decode(request.getParameter("address") , "UTF-8"));
				shopper.setSaddress(URLDecoder.decode(request.getParameter("address") , "UTF-8"));
				shopper.setBillName(URLDecoder.decode(request.getParameter("billName") , "UTF-8"));
				shopper.setIsSupportT0(request.getParameter("OpenT0Flag"));
				//0:支持
			    if((request.getParameter("OpenT0Flag").trim()).equals("0")){
			    	log.info(tel + "支持T+0");
			    	shopper.setIsIcApplyT0(request.getParameter("icCardFlag"));
					shopper.setT0SingleDayLimit(Double.parseDouble(request.getParameter("shopperLimit"))) ;
					//新增功能费率  t0				
					shopper.setT0type(t0type);			
					shopper.setT0minamount(Double.parseDouble(t0minamount));
					shopper.setT0maxamount(Double.parseDouble(t0maxamount));
					double   d   =   Double.parseDouble(t0Fee);
					String t0fee=ToolsUtils.div( d, 1, 4);
					//费率机
//					 if(t0type.equals("0")){
						 log.info(tel + "是费率机");
			        	  shopper.setT0fee(Double.parseDouble(t0fee));
			        	  shopper.setT0fixedamount(Double.parseDouble(t0fixedamount==""?"2":t0fixedamount));
//			          }				 
					 //封顶机
					/*if(t0type.equals("1")){
						log.info(tel + "是封顶机");
						shopper.setT0fee(Double.parseDouble(t0fee));
			        	shopper.setT0fixedamount(Double.parseDouble(t0fixedamount));
			        	
					}*/
					shopper.setT0additionfee(Double.parseDouble("0"));
		        	shopper.setT0topamount(Double.parseDouble("0"));
			    }
			    //1商户
			    if(shopperType.equals("1")){
			    	log.info(tel + "商户类型为企业");
			    	shopper.setScompany(URLDecoder.decode(request.getParameter("scompany") , "UTF-8"));
			    	shopper.setLicenseNo(request.getParameter("licenseNo") );
			    }else{
			    	log.info(tel + "商户类型为个人");
			    	shopper.setScompany(URLDecoder.decode(request.getParameter("Name") , "UTF-8"));
			    }
				
				shopper.setAccountbankclientname(URLDecoder.decode(request.getParameter("Name") , "UTF-8"));
				shopper.setSettlementType(settlementtype);
				shopper.setAccountbankno(request.getParameter("bankCard") );
				// 开户行名称数据字典
				shopper.setAccountbankdictval(URLDecoder.decode(request.getParameter("clientName") , "UTF-8"));
				// 发卡
				Area area1 = merchantregservice.findbyareaid(cardProvince,cardCity);
				if (area1 != null) {
					log.info(tel + "获取开户行省份成功");
					shopper.setAccountBankCity(area1.getCityname());
					shopper.setAccountBankCityCode(area1.getCity());
					shopper.setAccountbankprov(area1.getProvincialname());
					shopper.setAccountBankProvCode(area1.getProvincial());
				}
				// 支行名称
				shopper.setAccountbankname(URLDecoder.decode(request.getParameter("branchBankName"),"UTF-8"));
				shopper.setReportResource(Constants.STATUS0);// 代理报件
				shopper.setCreated(new Date());
				// 生成商户编号
				Area area2 = merchantregservice.findbyareaid(cardProvince,cardCity);
				String shopperid = getPosShopperId(area2.getCity(),	Constants.CON_MCC);
				shopper.setShopperid(Long.valueOf(shopperid));
				shopper.setShopperidP(Long.valueOf(request.getParameter("shopperidp") ));
				// 默认添加字段
				shopper.setIfvalid(Short.valueOf(Constants.STATUS0));
				shopper.setOpencheckstatus(Short.valueOf(Constants.STATUS0));
				shopper.setIsformal(Short.valueOf(Constants.STATUS0));
				shopper.setIsupdateshopper(Short.valueOf(Constants.STATUS0));
				shopper.setRecheckmerchantflag(Constants.STATUS0);
				shopper.setSifpactid(Long.valueOf(Constants.STATUS0));
				shopper.setMuserid(tel);
				shopper.setPhotoCheckFlag(Constants.STATUS0);
				shopper.setPhotoRecheckFlag(Constants.STATUS0);
				
//                shopper.setCardType(cardType);
				// MIN_SETTLE_MONEY最小结算金额
				shopper.setMinsettlemoney(Double.valueOf(Constants.MIN_SETTLE_MONEY));
				// 进度表
				
				
				/*shopper.setT1type(t1type);
				//费率机 T1
				 if(t1type.equals("0")){
					 log.info(tel + "是费率机");
		        	  shopper.setT1fee(Double.parseDouble(t1fee));
		        	 
		          }				 
				 //封顶机 T1
				if(t1type.equals("1")){
					log.info(tel + "是封顶机");
					shopper.setT1fee(Double.parseDouble(t1fee));
		        	shopper.setT1topamount(Double.parseDouble(t1topamount));
				}
				shopper.setT1topamount(Double.parseDouble("0"));*/
				
				MposApplicationProgress progress = new MposApplicationProgress();
				progress.setShopperid(shopper.getShopperid().toString());
				
				  if(shopperType.equals("1")){
						progress.setScompany(URLDecoder.decode(request.getParameter("scompany") , "UTF-8"));
				    	
				    }else{
				    	progress.setScompany(URLDecoder.decode(request.getParameter("Name") , "UTF-8"));
				    	
				    }
			
				progress.setApplicationTheme(Constants.THEME);
				progress.setApplicationType(Constants.STATUS1);
				progress.setApplicationStatus(Constants.STATUS1);
				progress.setApplicationRemark("待审核");
				progress.setCreateDate(new Date());
				progress.setShopperidP(request.getParameter("shopperidp") );
				Agent agent = agentservice.findbyshopperidp(request.getParameter("shopperidp") );
				progress.setAgentName(agent.getScompany());
			
				// 多费率
                
				MposPhotoTmp photo =this.photoservice.findbsid(sid);
				if(photo==null){
					hashMap.put("returnCode", "2222");
					hashMap.put("msg", "照片上传失败");
					response.setContentType("UTF-8");
					JSONObject json = JSONObject.fromObject(hashMap);
					log.info(tel + "照片上传失败" + json.toString());
					response.getWriter().write(json.toString());
					return;
				}else{
					log.info(tel + "照片上传成功");
					shopper.setPhotoid(photo.getPhotoId());
					progress.setPhotoId(photo.getPhotoId());
				}
				
				this.merchantregservice.insertsbar1(shopper,progress,fee);
				hashMap.put("returnCode", "0000");
				hashMap.put("msg", "注册成功");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("注册信息0000为成功" + json.toString());
				response.getWriter().write(json.toString());
				return;
			}
			

		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("returnCode", "2222");
			hashMap.put("msg", "注册出错");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("注册出错:" + json.toString());
			response.getWriter().write(json.toString());
		}

	}

	public String getPosShopperId(String area, String mcc) throws Exception {
		String organization = "800";
		String areacold = "";
		if (area.length() > 4) {
			areacold = area.substring(0, 4);
		} else {
			areacold = area;
		}
		String mcccold = "";
		if (mcc.length() == 1) {
			mcccold = "000" + mcc;
		} else {
			mcccold = "00" + mcc;
		}
		String merchantRadom = RandomStringUtils.randomNumeric(4);
		String posMerchantId = organization + areacold + mcccold + merchantRadom;
		B2cShopperbiTemp b2cShopperbi = merchantregservice.queryShopPerbi(posMerchantId);
		if (b2cShopperbi != null) {
			return getPosShopperId(area, mcc);
		}
		return posMerchantId;
	}
	
	
	@RequestMapping(params = "method=ajaxtel")
	public void ajaxtel(HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		Map hashMap = new HashMap();
		try {
			String tel =request.getParameter("tel");
			B2cShopperbiTemp shopper = this.merchantregservice.findbytel(tel);
			
			if (shopper != null) {
				hashMap.put("returnCode", "1111");
				hashMap.put("msg", "该手机号码已注册过");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("该手机号码已注册过:" + json.toString());
				response.getWriter().write(json.toString());
			} else if(!tel.equals("")){
				hashMap.put("returnCode", "0000");
				hashMap.put("msg", "该手机号码未注册过可以使用");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("该手机号码未注册过可以使用:" + json.toString());
				response.getWriter().write(json.toString());
			}

		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("returnCode", "2222");
			hashMap.put("msg", "出错");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("出错:" + json.toString());
			response.getWriter().write(json.toString());
		}

	}

	
	public String checkTelSid(String stel, String sid) throws Exception {
		HashMap hashmap = new HashMap();
		Date dates = new Date();
		String mradom = RandomStringUtils.randomNumeric(15);
		String orderId = DateUtil.getTypeDate(dates, "yyyyMMddhhmmss") + mradom;
		String orderTime = DateUtil.getTypeDate(dates, "yyyyMMddhhmmss");
		hashmap.put("mobile", stel);
		hashmap.put("idNum", sid);
		hashmap.put("orderId", orderId);
		hashmap.put("orderTime", orderTime);
		log.info("验证手机号和身份证是否在银生宝存在：" + ConstantsEnv.CHECKTELSID	+ hashmap.toString());
		Map resultMap =HttpClientUtils.postJsonRequestMap(ConstantsEnv.CHECKTELSID,hashmap,Map.class);
		log.info("验证手机号和身份证是否在银生宝存在返回码:" + resultMap);
		JSONObject ob = JSONObject.fromObject(resultMap);
		String rspCode = (String) ob.get("rspCode");
		return rspCode;
	}

}
