package com.uns.util;

import com.uns.common.Constants;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularUtils {

	/**
	 * 验证手机号格式
	 * 
	 * @param str
	 * @return
	 */
	public static boolean isMobile(String str) {
		Pattern p = null;
		Matcher m = null;
		boolean b = false;
		p = Pattern.compile(Constants.CHECK_MOBILE); // 验证手机号
		m = p.matcher(str);
		b = m.matches();
		return b;
	}
	
	/**
	 * 验证密码格式
	 * 至少6位字母或数字
	 * @param str
	 * @return
	 */
	public static boolean checkPwd(String str){
		Pattern p = null;
		Matcher m = null;
		boolean b = false;
		p = Pattern.compile(Constants.CHECK_PWD);
		m = p.matcher(str);
		b = m.matches();
		return b;
	}
	
}
