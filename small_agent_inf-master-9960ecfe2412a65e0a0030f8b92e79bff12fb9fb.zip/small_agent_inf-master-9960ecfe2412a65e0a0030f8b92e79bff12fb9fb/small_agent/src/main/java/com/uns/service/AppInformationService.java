package com.uns.service;

import com.uns.common.Constants;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.dao.MposSystemInformationMapper;
import com.uns.dao.SInfomationMerchantRelationMapper;
import com.uns.model.MposSystemInformation;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AppInformationService {

	@Autowired
	private MposSystemInformationMapper mposSystemInformationMapper;
	
	@Autowired
	private SInfomationMerchantRelationMapper sInfomationMerchantRelationMapper;
	
	public String findinformationCount(Long shopperid) {
		return mposSystemInformationMapper.findinformationCount(shopperid);
	}

	public Map findAppInformationTheme(HttpServletRequest request, String tPage) throws Exception{
		if (StringUtils.isEmpty(tPage) || !StringUtils.isNumeric(tPage)){
			tPage = "1";
		}
		int currentPage = Integer.valueOf(tPage);
		Page page  = new Page();

		PageContext context = PageContext.getContext();
		page.setCurrentPage(currentPage);
		BeanUtils.copyProperties(context, page);
		context.setPageSize(Constants.page_size);
		context.setPagination(true);
		
		String merchantNo=request.getParameter("merchantNo");
		String ifAgent = request.getParameter("ifAgent");
		Map param = new HashMap(2);
		param.put("merchantNo", merchantNo);
		param.put("ifAgent", ifAgent);
		List list=mposSystemInformationMapper.findAppInformationThemeList(param);

		Map map=new HashMap(4);
		map.put("list", list);
		map.put("page", context.getCurrentPage());
		map.put("pages",context.getTotalPages());
		map.put("count",context.getTotalRows());
		
		return map;
	}

	public Map findAppInformationDetails(HttpServletRequest request) {
		String informationId=request.getParameter("informationId");
		String merchantNo=request.getParameter("merchantNo");
		Map map=new HashMap();
		map.put("informationId", informationId);
		map.put("merchantNo", merchantNo);
		Map list=mposSystemInformationMapper.findAppInformationDetails(map);
		if(Constants.STATUS1.equals(list==null?"":list.get("FLAG").toString())){
			sInfomationMerchantRelationMapper.updateInfomationMerchant(map);
		}
		
		return list;
	}

	public String finInformationTheme() {
		return mposSystemInformationMapper.finInformationTheme();
	}

}
