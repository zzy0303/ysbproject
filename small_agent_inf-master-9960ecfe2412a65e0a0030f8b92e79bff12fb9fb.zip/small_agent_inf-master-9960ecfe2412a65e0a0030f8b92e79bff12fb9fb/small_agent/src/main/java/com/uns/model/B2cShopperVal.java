package com.uns.model;

import java.io.Serializable;
import java.util.Date;

public class B2cShopperVal implements Serializable {
	private Long b2cShopperValId; 
	private String tel;				//手机号码
	private String smsCode;			//短信验证码
	private Date smsCodeDate;		//验证码发送时间
	private String password;		//登录密码
	private String name;			//姓名
	private String identityId;		//身份证号
	private String bankName;		//开户银行名称
	private String bankCode; 		//银行code
	private String cardCity; 		//发卡城市名称
	private String cardProvince;	//发卡省份名称
	private String bankCard;		//银行卡号
	private String branchBankName;	//支行名称
	private String inviteCodeP;		//上级商户邀请码
	private String inviteCode; 		//商户邀请码
	private Long shopperidP;		//上级代理商

	public String getInviteCode() {
		return inviteCode;
	}

	public void setInviteCode(String inviteCode) {
		this.inviteCode = inviteCode;
	}

	public Long getShopperidP() {
		return shopperidP;
	}

	public void setShopperidP(Long shopperidP) {
		this.shopperidP = shopperidP;
	}

	public String getInviteCodeP() {
		return inviteCodeP;
	}

	public void setInviteCodeP(String inviteCodeP) {
		this.inviteCodeP = inviteCodeP;
	}

	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public Long getB2cShopperValId() {
		return b2cShopperValId;
	}
	public void setB2cShopperValId(Long b2cShopperValId) {
		this.b2cShopperValId = b2cShopperValId;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getSmsCode() {
		return smsCode;
	}
	public void setSmsCode(String smsCode) {
		this.smsCode = smsCode;
	}
	public Date getSmsCodeDate() {
		return smsCodeDate;
	}
	public void setSmsCodeDate(Date smsCodeDate) {
		this.smsCodeDate = smsCodeDate;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIdentityId() {
		return identityId;
	}
	public void setIdentityId(String identityId) {
		this.identityId = identityId;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getCardCity() {
		return cardCity;
	}
	public void setCardCity(String cardCity) {
		this.cardCity = cardCity;
	}
	public String getCardProvince() {
		return cardProvince;
	}
	public void setCardProvince(String cardProvince) {
		this.cardProvince = cardProvince;
	}
	public String getBankCard() {
		return bankCard;
	}
	public void setBankCard(String bankCard) {
		this.bankCard = bankCard;
	}
	public String getBranchBankName() {
		return branchBankName;
	}
	public void setBranchBankName(String branchBankName) {
		this.branchBankName = branchBankName;
	}
	
}
