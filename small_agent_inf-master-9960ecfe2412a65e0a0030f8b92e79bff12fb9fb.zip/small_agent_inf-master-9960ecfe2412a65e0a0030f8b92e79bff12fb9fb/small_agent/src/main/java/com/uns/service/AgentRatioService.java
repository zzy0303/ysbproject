package com.uns.service;

import com.uns.dao.AgentRatioMapper;
import com.uns.model.AgentRatio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AgentRatioService {
	@Autowired
	private AgentRatioMapper agentRatioMapper;

	public Boolean isRatioTmp(Long shopperid) {
		List<Map> list = agentRatioMapper.isRatioTmp(shopperid);
		if(list!=null && list.size()>0)
			return true;
		else 
			return false;
	}

	public Boolean isRatio(Long shopperid) {
		List<Map> list = agentRatioMapper.isRatio(shopperid);
		if(list!=null && list.size()>0)
			return true;
		else 
			return false;
	}

	public List<AgentRatio> findAgentRatioTmpByAmid(Long shopperid, Long amid) {
		Map map=new HashMap();
		map.put("shopperid", shopperid);
		map.put("amid", amid);
		return agentRatioMapper.findAgentRatioTmpByAmid(map);
	}

	public List<AgentRatio> findAgentRatio(Long shopperid, Long amid) {
		Map map=new HashMap();
		map.put("shopperid", shopperid);
		map.put("amid", amid);
		return agentRatioMapper.findAgentRatio(map);
	}
	
	
}
