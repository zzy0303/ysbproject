package com.uns.model;

import java.util.Date;

public class B2cShopperbi {
	
	
	private Long b2cShopperbiId;
	private String scompany;
	private String gateway;
	private String sqcode;
	private String synum;
	private String sicp;
	private String saddress;
	private String szip;
	private String smanager;
	private String srelation;
	private String semail;
	private String stel;
	private String sfax;
	private String shandset;
	private String sqq;
	private String smsn;
	private Long sshopertypeid;
	private String sshopertype;
	private String sdomain;
	private Long sshoppertypeid;
	private String sshoppertype;
	private String scity;
	private String city;
	private String sprovince;
	private String province;
	private Long transactid;
	private String transactsub;
	private String transact;
	private String operid;
	private String oper;
	private Long sifpactid;
	private String sifpact;
	private String spactoperid;
	private String spactoper;
	private Long sisnew;
	private String shoppercallingid;
	private String shoppercalling;
	private Date created;
	private Long shopperid;
	private Long sagentid;
	private Long battalion;
	private Long persentid;
	private Short ifattend;
	private Long ifagent;
	private Short shoppertypeid;
	private String srelationcredno;
	private String legalentity;
	private String srelationcrededate;
	private String legalecredno;
	private String legalecrededate;
	private String synumedate;
	private String licenseno;
	private String taxregisterno;
	private String remark;
	private String upoperid;
	private String upoper;
	private Date updated;
	private String grade;
	private String division;
	private Long shopperidP;
	private String shortname;
	private String levels;
	private Short ifvalid;
	private String accountbankdictval;
	private String accountbankname;
	private String accountbankclientname;
	private String accountbankno;
	private String  accountbankprov;
	private String accountbankother;
	private String istopmerchant;
	private Double topfee;
	private Double minsettlemoney;
	private String settlefrequency;
	private String settlementType;
	private String ysbNo;
	private String ysbScompany;
    private Long  photoid;
    private String merchantType;
    private String name;
    private String IDNo;
    private String licenseNo;
    private String industry;
    private String billProvince;
    private String billProvinceCode;
    private String billCity;
    private String billCityCode;
    private String billAddress;
    private String billName;
    private String isSupportT0;
    private String isIcApplyT0;
    private Double T0fee;
    private Long T0SingleDayLimit;
    private String accountBankProvCode;
    private String accountBankCity;
    private String accountBankCityCode;
    private String reportResource;
    private String shopperlimit;
    private String evicenumber;
    private String fee;
    private String merchantKey;  
    private String cardType;
    private String currentLocation;
    private String longitude;
    private String latitude;
    private String aiflag;
    private String ifactivated;   
    private String factoringno;
    private Date open_mpos_create_date;
	private Double  t0fixedamount;
	private Double  t0minamount;
	private Double  t0maxamount;
    private String qrPayNo;
    private String qrpayMerchantkey;

    private String fixedqrcodeurl;
    private String fixedqrcodeflag;
    
    private String fixqrcodecustomername;
    private String isexternalrevenue;
    private String settleType;
    private String inviteCode;
	private String inviteCodeP;
	
	private String blackFlag;
	
	private String birthday;//生日
	private String sex;//性别
	
	
	private String nation;//民族
	private String signUnit;//身份证签发机关
	private String usefulLife;//身份证有效期限

	private String accountBankClientTel;//结算卡手机号
	//添加贷记字段
	private String creditBankDictval;//贷记卡银行编码
	private String creditBankNo;//贷记卡卡号
	private String creditBankUsefullife;//贷记卡有效期
	private String  creditBankClientTel;//贷记卡手机号
	private String creditBankClientIdNo;//贷记卡开卡人身份证号
	private String creditBankClientName;//贷记卡开卡人姓名
	
	private String checkstatus;//审核进度（OCR）

	//新加商户认证字段
	private String licenseName; //营业执照名称
	private String accountBankLineNumber; //开户行联行号
	private String licenseAddress; //营业执照地址

	public String getLicenseName() {
		return licenseName;
	}

	public void setLicenseName(String licenseName) {
		this.licenseName = licenseName;
	}

	public String getAccountBankLineNumber() {
		return accountBankLineNumber;
	}

	public void setAccountBankLineNumber(String accountBankLineNumber) {
		this.accountBankLineNumber = accountBankLineNumber;
	}

	public String getLicenseAddress() {
		return licenseAddress;
	}

	public void setLicenseAddress(String licenseAddress) {
		this.licenseAddress = licenseAddress;
	}

	public String getAccountBankClientTel() {
		return accountBankClientTel;
	}

	public void setAccountBankClientTel(String accountBankClientTel) {
		this.accountBankClientTel = accountBankClientTel;
	}

	public String getBlackFlag() {
		return blackFlag;
	}

	public void setBlackFlag(String blackFlag) {
		this.blackFlag = blackFlag;
	}

	public String getNation() {
		return nation;
	}

	public void setNation(String nation) {
		this.nation = nation;
	}

	public String getSignUnit() {
		return signUnit;
	}

	public void setSignUnit(String signUnit) {
		this.signUnit = signUnit;
	}

	public String getUsefulLife() {
		return usefulLife;
	}

	public void setUsefulLife(String usefulLife) {
		this.usefulLife = usefulLife;
	}

	public String getCreditBankDictval() {
		return creditBankDictval;
	}

	public void setCreditBankDictval(String creditBankDictval) {
		this.creditBankDictval = creditBankDictval;
	}

	public String getCreditBankNo() {
		return creditBankNo;
	}

	public void setCreditBankNo(String creditBankNo) {
		this.creditBankNo = creditBankNo;
	}

	public String getCreditBankUsefullife() {
		return creditBankUsefullife;
	}

	public void setCreditBankUsefullife(String creditBankUsefullife) {
		this.creditBankUsefullife = creditBankUsefullife;
	}

	public String getCreditBankClientTel() {
		return creditBankClientTel;
	}

	public void setCreditBankClientTel(String creditBankClientTel) {
		this.creditBankClientTel = creditBankClientTel;
	}

	public String getCreditBankClientIdNo() {
		return creditBankClientIdNo;
	}

	public void setCreditBankClientIdNo(String creditBankClientIdNo) {
		this.creditBankClientIdNo = creditBankClientIdNo;
	}

	public String getCreditBankClientName() {
		return creditBankClientName;
	}

	public void setCreditBankClientName(String creditBankClientName) {
		this.creditBankClientName = creditBankClientName;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getInviteCode() {
		return inviteCode;
	}

	public void setInviteCode(String inviteCode) {
		this.inviteCode = inviteCode;
	}

	public String getInviteCodeP() {
		return inviteCodeP;
	}

	public void setInviteCodeP(String inviteCodeP) {
		this.inviteCodeP = inviteCodeP;
	}

    private Double creditLines;//授信额度
    private String profitOwner;//分论给谁
    private String agentProfitRatio;//服务商分润
    private String merchProfitRatio1;//商户分润1
    private String merchProfitRatio2;//商户分润2
    private String merchProfitRatio3;//商户分润3



	public String getProfitOwner() {
		return profitOwner;
	}
	public void setProfitOwner(String profitOwner) {
		this.profitOwner = profitOwner;
	}
	public String getAgentProfitRatio() {
		return agentProfitRatio;
	}
	public void setAgentProfitRatio(String agentProfitRatio) {
		this.agentProfitRatio = agentProfitRatio;
	}
	public String getMerchProfitRatio1() {
		return merchProfitRatio1;
	}
	public void setMerchProfitRatio1(String merchProfitRatio1) {
		this.merchProfitRatio1 = merchProfitRatio1;
	}
	public String getMerchProfitRatio2() {
		return merchProfitRatio2;
	}
	public void setMerchProfitRatio2(String merchProfitRatio2) {
		this.merchProfitRatio2 = merchProfitRatio2;
	}
	public String getMerchProfitRatio3() {
		return merchProfitRatio3;
	}
	public void setMerchProfitRatio3(String merchProfitRatio3) {
		this.merchProfitRatio3 = merchProfitRatio3;
	}
	public Double getCreditLines() {
		return creditLines;
	}
	public void setCreditLines(Double creditLines) {
		this.creditLines = creditLines;
	}
	public String getSettleType() {
		return settleType;
	}
	public void setSettleType(String settleType) {
		this.settleType = settleType;
	}
	public String getFixqrcodecustomername() {
		return fixqrcodecustomername;
	}
	public void setFixqrcodecustomername(String fixqrcodecustomername) {
		this.fixqrcodecustomername = fixqrcodecustomername;
	}
	public String getIsexternalrevenue() {
		return isexternalrevenue;
	}
	public void setIsexternalrevenue(String isexternalrevenue) {
		this.isexternalrevenue = isexternalrevenue;
	}
	public String getFixedqrcodeurl() {
		return fixedqrcodeurl;
	}
	public void setFixedqrcodeurl(String fixedqrcodeurl) {
		this.fixedqrcodeurl = fixedqrcodeurl;
	}
	public String getFixedqrcodeflag() {
		return fixedqrcodeflag;
	}
	public void setFixedqrcodeflag(String fixedqrcodeflag) {
		this.fixedqrcodeflag = fixedqrcodeflag;
	}
	public String getQrPayNo() {
		return qrPayNo;
	}
	public void setQrPayNo(String qrPayNo) {
		this.qrPayNo = qrPayNo;
	}
	public String getQrpayMerchantkey() {
		return qrpayMerchantkey;
	}
	public void setQrpayMerchantkey(String qrpayMerchantkey) {
		this.qrpayMerchantkey = qrpayMerchantkey;
	}
	public Double getT0fixedamount() {
		return t0fixedamount;
	}
	public void setT0fixedamount(Double t0fixedamount) {
		this.t0fixedamount = t0fixedamount;
	}
	public Double getT0minamount() {
		return t0minamount;
	}
	public void setT0minamount(Double t0minamount) {
		this.t0minamount = t0minamount;
	}
	public Double getT0maxamount() {
		return t0maxamount;
	}
	public void setT0maxamount(Double t0maxamount) {
		this.t0maxamount = t0maxamount;
	}
	public Date getOpen_mpos_create_date() {
		return open_mpos_create_date;
	}
	public void setOpen_mpos_create_date(Date open_mpos_create_date) {
		this.open_mpos_create_date = open_mpos_create_date;
	}
	public String getFactoringno() {
		return factoringno;
	}
	public void setFactoringno(String factoringno) {
		this.factoringno = factoringno;
	}
	public String getCurrentLocation() {
		return currentLocation;
	}
	public void setCurrentLocation(String currentLocation) {
		this.currentLocation = currentLocation;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getAiflag() {
		return aiflag;
	}
	public void setAiflag(String aiflag) {
		this.aiflag = aiflag;
	}
	
    public String getIfactivated() {
		return ifactivated;
	}
	public void setIfactivated(String ifactivated) {
		this.ifactivated = ifactivated;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public String getMerchantKey() {
		return merchantKey;
	}
	public void setMerchantKey(String merchantKey) {
		this.merchantKey = merchantKey;
	}
	public String getFee() {
		return fee;
	}
	public void setFee(String fee) {
		this.fee = fee;
	}
	public String getBillProvinceCode() {
		return billProvinceCode;
	}
	public void setBillProvinceCode(String billProvinceCode) {
		this.billProvinceCode = billProvinceCode;
	}
	public Long getPhotoid() {
		return photoid;
	}
	public void setPhotoid(Long photoid) {
		this.photoid = photoid;
	}
	public String getMerchantType() {
		return merchantType;
	}
	public void setMerchantType(String merchantType) {
		this.merchantType = merchantType;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIDNo() {
		return IDNo;
	}
	public void setIDNo(String iDNo) {
		IDNo = iDNo;
	}
	public String getLicenseNo() {
		return licenseNo;
	}
	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getBillProvince() {
		return billProvince;
	}
	public void setBillProvince(String billProvince) {
		this.billProvince = billProvince;
	}
	public String getBillCity() {
		return billCity;
	}
	public void setBillCity(String billCity) {
		this.billCity = billCity;
	}
	public String getBillCityCode() {
		return billCityCode;
	}
	public void setBillCityCode(String billCityCode) {
		this.billCityCode = billCityCode;
	}
	public String getBillAddress() {
		return billAddress;
	}
	public void setBillAddress(String billAddress) {
		this.billAddress = billAddress;
	}
	public String getBillName() {
		return billName;
	}
	public void setBillName(String billName) {
		this.billName = billName;
	}
	public String getIsSupportT0() {
		return isSupportT0;
	}
	public void setIsSupportT0(String isSupportT0) {
		this.isSupportT0 = isSupportT0;
	}
	public String getIsIcApplyT0() {
		return isIcApplyT0;
	}
	public void setIsIcApplyT0(String isIcApplyT0) {
		this.isIcApplyT0 = isIcApplyT0;
	}
	
	public Double getT0fee() {
		return T0fee;
	}
	public void setT0fee(Double t0fee) {
		T0fee = t0fee;
	}
	public Long getT0SingleDayLimit() {
		return T0SingleDayLimit;
	}
	public void setT0SingleDayLimit(Long t0SingleDayLimit) {
		T0SingleDayLimit = t0SingleDayLimit;
	}
	public String getAccountBankProvCode() {
		return accountBankProvCode;
	}
	public void setAccountBankProvCode(String accountBankProvCode) {
		this.accountBankProvCode = accountBankProvCode;
	}
	public String getAccountBankCity() {
		return accountBankCity;
	}
	public void setAccountBankCity(String accountBankCity) {
		this.accountBankCity = accountBankCity;
	}
	public String getAccountBankCityCode() {
		return accountBankCityCode;
	}
	public void setAccountBankCityCode(String accountBankCityCode) {
		this.accountBankCityCode = accountBankCityCode;
	}
	public String getReportResource() {
		return reportResource;
	}
	public void setReportResource(String reportResource) {
		this.reportResource = reportResource;
	}
	public String getShopperlimit() {
		return shopperlimit;
	}
	public void setShopperlimit(String shopperlimit) {
		this.shopperlimit = shopperlimit;
	}
	public String getEvicenumber() {
		return evicenumber;
	}
	public void setEvicenumber(String evicenumber) {
		this.evicenumber = evicenumber;
	}
	public Double getTopfee() {
		return topfee;
	}
	public void setTopfee(Double topfee) {
		this.topfee = topfee;
	}
	public Double getMinsettlemoney() {
		return minsettlemoney;
	}
	public void setMinsettlemoney(Double minsettlemoney) {
		this.minsettlemoney = minsettlemoney;
	}
	
	public String getSettlefrequency() {
		return settlefrequency;
	}
	public void setSettlefrequency(String settlefrequency) {
		this.settlefrequency = settlefrequency;
	}
	public String getIstopmerchant() {
		return istopmerchant;
	}
	public void setIstopmerchant(String istopmerchant) {
		this.istopmerchant = istopmerchant;
	}

	public String getAccountbankother() {
		return accountbankother;
	}
	public void setAccountbankother(String accountbankother) {
		this.accountbankother = accountbankother;
	}
	public String getAccountbankdictval() {
		return accountbankdictval;
	}
	public void setAccountbankdictval(String accountbankdictval) {
		this.accountbankdictval = accountbankdictval;
	}
	public String getAccountbankname() {
		return accountbankname;
	}
	public void setAccountbankname(String accountbankname) {
		this.accountbankname = accountbankname;
	}
	public String getAccountbankclientname() {
		return accountbankclientname;
	}
	public void setAccountbankclientname(String accountbankclientname) {
		this.accountbankclientname = accountbankclientname;
	}
	public String getAccountbankno() {
		return accountbankno;
	}
	public void setAccountbankno(String accountbankno) {
		this.accountbankno = accountbankno;
	}
	public String getAccountbankprov() {
		return accountbankprov;
	}
	public void setAccountbankprov(String accountbankprov) {
		this.accountbankprov = accountbankprov;
	}
	public Long getB2cShopperbiId() {
		return b2cShopperbiId;
	}
	public void setB2cShopperbiId(Long b2cShopperbiId) {
		this.b2cShopperbiId = b2cShopperbiId;
	}
	public String getScompany() {
		return scompany;
	}
	public void setScompany(String scompany) {
		this.scompany = scompany;
	}
	public String getGateway() {
		return gateway;
	}
	public void setGateway(String gateway) {
		this.gateway = gateway;
	}
	public String getSqcode() {
		return sqcode;
	}
	public void setSqcode(String sqcode) {
		this.sqcode = sqcode;
	}
	public String getSynum() {
		return synum;
	}
	public void setSynum(String synum) {
		this.synum = synum;
	}
	public String getSicp() {
		return sicp;
	}
	public void setSicp(String sicp) {
		this.sicp = sicp;
	}
	public String getSaddress() {
		return saddress;
	}
	public void setSaddress(String saddress) {
		this.saddress = saddress;
	}
	public String getSzip() {
		return szip;
	}
	public void setSzip(String szip) {
		this.szip = szip;
	}
	public String getSmanager() {
		return smanager;
	}
	public void setSmanager(String smanager) {
		this.smanager = smanager;
	}
	public String getSrelation() {
		return srelation;
	}
	public void setSrelation(String srelation) {
		this.srelation = srelation;
	}
	public String getSemail() {
		return semail;
	}
	public void setSemail(String semail) {
		this.semail = semail;
	}
	public String getStel() {
		return stel;
	}
	public void setStel(String stel) {
		this.stel = stel;
	}
	public String getSfax() {
		return sfax;
	}
	public void setSfax(String sfax) {
		this.sfax = sfax;
	}
	public String getShandset() {
		return shandset;
	}
	public void setShandset(String shandset) {
		this.shandset = shandset;
	}
	public String getSqq() {
		return sqq;
	}
	public void setSqq(String sqq) {
		this.sqq = sqq;
	}
	public String getSmsn() {
		return smsn;
	}
	public void setSmsn(String smsn) {
		this.smsn = smsn;
	}
	public Long getSshopertypeid() {
		return sshopertypeid;
	}
	public void setSshopertypeid(Long sshopertypeid) {
		this.sshopertypeid = sshopertypeid;
	}
	public String getSshopertype() {
		return sshopertype;
	}
	public void setSshopertype(String sshopertype) {
		this.sshopertype = sshopertype;
	}
	public String getSdomain() {
		return sdomain;
	}
	public void setSdomain(String sdomain) {
		this.sdomain = sdomain;
	}
	public Long getSshoppertypeid() {
		return sshoppertypeid;
	}
	public void setSshoppertypeid(Long sshoppertypeid) {
		this.sshoppertypeid = sshoppertypeid;
	}
	public String getSshoppertype() {
		return sshoppertype;
	}
	public void setSshoppertype(String sshoppertype) {
		this.sshoppertype = sshoppertype;
	}
	public String getScity() {
		return scity;
	}
	public void setScity(String scity) {
		this.scity = scity;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getSprovince() {
		return sprovince;
	}
	public void setSprovince(String sprovince) {
		this.sprovince = sprovince;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public Long getTransactid() {
		return transactid;
	}
	public void setTransactid(Long transactid) {
		this.transactid = transactid;
	}
	public String getTransactsub() {
		return transactsub;
	}
	public void setTransactsub(String transactsub) {
		this.transactsub = transactsub;
	}
	public String getTransact() {
		return transact;
	}
	public void setTransact(String transact) {
		this.transact = transact;
	}
	public String getOperid() {
		return operid;
	}
	public void setOperid(String operid) {
		this.operid = operid;
	}
	public String getOper() {
		return oper;
	}
	public void setOper(String oper) {
		this.oper = oper;
	}
	public Long getSifpactid() {
		return sifpactid;
	}
	public void setSifpactid(Long sifpactid) {
		this.sifpactid = sifpactid;
	}
	public String getSifpact() {
		return sifpact;
	}
	public void setSifpact(String sifpact) {
		this.sifpact = sifpact;
	}
	public String getSpactoperid() {
		return spactoperid;
	}
	public void setSpactoperid(String spactoperid) {
		this.spactoperid = spactoperid;
	}
	public String getSpactoper() {
		return spactoper;
	}
	public void setSpactoper(String spactoper) {
		this.spactoper = spactoper;
	}
	public Long getSisnew() {
		return sisnew;
	}
	public void setSisnew(Long sisnew) {
		this.sisnew = sisnew;
	}
	public String getShoppercallingid() {
		return shoppercallingid;
	}
	public void setShoppercallingid(String shoppercallingid) {
		this.shoppercallingid = shoppercallingid;
	}
	public String getShoppercalling() {
		return shoppercalling;
	}
	public void setShoppercalling(String shoppercalling) {
		this.shoppercalling = shoppercalling;
	}
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	public Long getShopperid() {
		return shopperid;
	}
	public void setShopperid(Long shopperid) {
		this.shopperid = shopperid;
	}
	public Long getSagentid() {
		return sagentid;
	}
	public void setSagentid(Long sagentid) {
		this.sagentid = sagentid;
	}
	public Long getBattalion() {
		return battalion;
	}
	public void setBattalion(Long battalion) {
		this.battalion = battalion;
	}
	public Long getPersentid() {
		return persentid;
	}
	public void setPersentid(Long persentid) {
		this.persentid = persentid;
	}
	public Short getIfattend() {
		return ifattend;
	}
	public void setIfattend(Short ifattend) {
		this.ifattend = ifattend;
	}
	public Long getIfagent() {
		return ifagent;
	}
	public void setIfagent(Long ifagent) {
		this.ifagent = ifagent;
	}
	public Short getShoppertypeid() {
		return shoppertypeid;
	}
	public void setShoppertypeid(Short shoppertypeid) {
		this.shoppertypeid = shoppertypeid;
	}
	public String getSrelationcredno() {
		return srelationcredno;
	}
	public void setSrelationcredno(String srelationcredno) {
		this.srelationcredno = srelationcredno;
	}
	public String getLegalentity() {
		return legalentity;
	}
	public void setLegalentity(String legalentity) {
		this.legalentity = legalentity;
	}
	public String getSrelationcrededate() {
		return srelationcrededate;
	}
	public void setSrelationcrededate(String srelationcrededate) {
		this.srelationcrededate = srelationcrededate;
	}
	public String getLegalecredno() {
		return legalecredno;
	}
	public void setLegalecredno(String legalecredno) {
		this.legalecredno = legalecredno;
	}
	public String getLegalecrededate() {
		return legalecrededate;
	}
	public void setLegalecrededate(String legalecrededate) {
		this.legalecrededate = legalecrededate;
	}
	public String getSynumedate() {
		return synumedate;
	}
	public void setSynumedate(String synumedate) {
		this.synumedate = synumedate;
	}
	public String getLicenseno() {
		return licenseno;
	}
	public void setLicenseno(String licenseno) {
		this.licenseno = licenseno;
	}
	public String getTaxregisterno() {
		return taxregisterno;
	}
	public void setTaxregisterno(String taxregisterno) {
		this.taxregisterno = taxregisterno;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getUpoperid() {
		return upoperid;
	}
	public void setUpoperid(String upoperid) {
		this.upoperid = upoperid;
	}
	public String getUpoper() {
		return upoper;
	}
	public void setUpoper(String upoper) {
		this.upoper = upoper;
	}
	public Date getUpdated() {
		return updated;
	}
	public void setUpdated(Date updated) {
		this.updated = updated;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public Long getShopperidP() {
		return shopperidP;
	}
	public void setShopperidP(Long shopperidP) {
		this.shopperidP = shopperidP;
	}
	public String getShortname() {
		return shortname;
	}
	public void setShortname(String shortname) {
		this.shortname = shortname;
	}
	public String getLevels() {
		return levels;
	}
	public void setLevels(String levels) {
		this.levels = levels;
	}
	public Short getIfvalid() {
		return ifvalid;
	}
	public void setIfvalid(Short ifvalid) {
		this.ifvalid = ifvalid;
	}
	public String getSettlementType() {
		return settlementType;
	}
	public void setSettlementType(String settlementType) {
		this.settlementType = settlementType;
	}
	public String getYsbNo() {
		return ysbNo;
	}
	public void setYsbNo(String ysbNo) {
		this.ysbNo = ysbNo;
	}
	public String getYsbScompany() {
		return ysbScompany;
	}
	public void setYsbScompany(String ysbScompany) {
		this.ysbScompany = ysbScompany;
	}

}