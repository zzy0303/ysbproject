package com.uns.model;



public class Mcc{
	 
	private Long mccId;
	private String firmName; // 行业名称
	private Double mccFee; // 标准手续费
	
	public Long getMccId() {
		return mccId;
	}
	public void setMccId(Long mccId) {
		this.mccId = mccId;
	}
	public String getFirmName() {
		return firmName;
	}
	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}
	public Double getMccFee() {
		return mccFee;
	}
	public void setMccFee(Double mccFee) {
		this.mccFee = mccFee;
	}
	
}