package com.uns.service;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.dao.AgentMapper;
import com.uns.dao.MposRemoteFeeMapper;
import com.uns.dao.MposRemoteInvitationMapper;
import com.uns.dao.UsersMapper;
import com.uns.model.Agent;
import com.uns.model.MposRemoteFee;
import com.uns.model.MposRemoteInvitation;
import com.uns.model.Users;
import com.uns.util.DateUtil;
import com.uns.util.ToolsUtils;
import com.uns.web.form.MposRemoteInvitationForm;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Service("mposRemoteInvitationService")
public class MposRemoteInvitationService {

	@Autowired
	private MposRemoteInvitationMapper  mposRemoteInvitationMapper;
	@Autowired
	private AgentMapper  agentMapper;
	
	@Autowired
	private UsersMapper usersMapper;
	
	@Autowired
	private MposRemoteFeeMapper  mposRemoteFeeMapper;
	
	@Autowired
	private SendMessageService  sendMessageService;
	
	
	
	/**
	 * 将已邀请单未提交注册申请的记录，按照过期时间设置成已过期
	 */
	public void updateData() throws Exception{
		SimpleDateFormat sf = new SimpleDateFormat(Constants.DEFAULT_DATE_FORMAT);
		
		HashMap map=new HashMap();
		map.put("status", Constants.CON_YES);
		map.put("statuss", Constants.PAST_STATUS);
		map.put("updateDate", new Date());
		map.put("pastDate", sf.format(new Date()));
		mposRemoteInvitationMapper.updateData(map);
	}
	
	
	
	/**查询当前记录
	 * @param mbform
	 * @return
	 */
	public List findMposRemoteInvitationList(MposRemoteInvitationForm mbform) {
		PageContext.initPageSize(Constants.page_size);
		return mposRemoteInvitationMapper.findMposRemoteInvitationList(mbform);
	}
	/**
	 * 保存信息，并发送短息
	 * 1.保存信息
	 * 2.发送短息
	 * @param request 
	 * @throws BusinessException 
	 * @throws ParseException 
	 */
	public void saveInitiateinvitation000(MposRemoteInvitation mposRemoteInvitation, HttpServletRequest request) throws BusinessException, ParseException {
		//保存邀请信息
		mposRemoteFeeMapper.delfee(mposRemoteInvitation.getTel());
		Users user=usersMapper.selectByPrimaryId(mposRemoteInvitation.getSalesman()==null?"":mposRemoteInvitation.getSalesman().toString());
		mposRemoteInvitation.setCreateDate(new Date());
		mposRemoteInvitation.setRemoteInvitation(new Date());
		mposRemoteInvitation.setStatus(Constants.CON_YES);
		mposRemoteInvitation.setCardType(Constants.CON_NO);//默认值 代表是费率（贷记卡）
		mposRemoteInvitation.setSalesman(user.getId());
		Users user1=(Users) request.getSession().getAttribute("sessionUser");
		mposRemoteInvitation.setAgentId(user1.getMerchantid().toString());
		
		String t0Fee=request.getParameter("t0Fee");
		if(StringUtils.isEmpty(t0Fee)||t0Fee==null){
			mposRemoteInvitation.setT0Fee("0");
		}else{
			double   d   =   Double.parseDouble(t0Fee);
			String t0fee= ToolsUtils.div(d, 100, 4);
			mposRemoteInvitation.setT0Fee(t0fee);
		}
		
		Date pasDate=DateUtil.calculateDate(new Date(), Constants.PASTDATE);
		mposRemoteInvitation.setPastDate(pasDate);
		String passw=RandomStringUtils.random(6, "0123456789");
		mposRemoteInvitation.setPassword(passw);
		insertMposRemoteFee(mposRemoteInvitation,request);
		mposRemoteInvitationMapper.insertSelective(mposRemoteInvitation);
		//发送短信
		sendSms(mposRemoteInvitation,request);
	}
	
	
	private void insertMposRemoteFee(MposRemoteInvitation mposRemoteInvitation,
			HttpServletRequest request) {
		String debitfeeT1=request.getParameter("debitfeeT1");
		String creditfeeT1=request.getParameter("creditfeeT1");
		
		String weChatfeeT1=request.getParameter("weChatfeeT1");
		String weChatfeeD0=request.getParameter("weChatfeeD0");
		String aliPayfeeT1=request.getParameter("aliPayfeeT1");
		String aliPayfeeD0=request.getParameter("aliPayfeeD0");
		
		
		MposRemoteFee mposDebitfee=new MposRemoteFee();
		mposDebitfee.setTel(mposRemoteInvitation.getTel());
		mposDebitfee.setFeetype(Constants.CON_NO);//借记卡
		mposDebitfee.setFee(debitfeeT1);
		mposDebitfee.setCreateDate(new Date());
		mposDebitfee.setStatus(Constants.CON_YES);
		mposDebitfee.setD0fee(ToolsUtils.div(Double.parseDouble(mposRemoteInvitation.getT0Fee()), 1, 4)+"");

		MposRemoteFee mposCreditFee=new MposRemoteFee();
		mposCreditFee.setTel(mposRemoteInvitation.getTel());
		mposCreditFee.setFeetype(Constants.CON_YES);//贷记卡
		mposCreditFee.setFee(creditfeeT1);
		mposCreditFee.setCreateDate(new Date());
		mposCreditFee.setStatus(Constants.CON_YES);
		mposCreditFee.setD0fee(ToolsUtils.div(Double.parseDouble(mposRemoteInvitation.getT0Fee()), 1, 4)+"");
		
		MposRemoteFee mweChatfee=new MposRemoteFee();
		mweChatfee.setTel(mposRemoteInvitation.getTel());
		mweChatfee.setFeetype(Constants.STATUS2);//
		mweChatfee.setFee(weChatfeeT1);
		mweChatfee.setCreateDate(new Date());
		mweChatfee.setStatus(Constants.CON_YES);
		mweChatfee.setD0fee(ToolsUtils.div(Double.parseDouble(weChatfeeD0), 1, 4)+"");
			
		MposRemoteFee mposAliPayFee=new MposRemoteFee();
		mposAliPayFee.setTel(mposRemoteInvitation.getTel());
		mposAliPayFee.setFeetype(Constants.STATUS3);//借记卡
		mposAliPayFee.setFee(aliPayfeeT1);
		mposAliPayFee.setCreateDate(new Date());
		mposAliPayFee.setStatus(Constants.CON_YES);
		mposAliPayFee.setD0fee(ToolsUtils.div(Double.parseDouble(aliPayfeeD0), 1, 4)+"");
		
		mposRemoteFeeMapper.insertSelective(mposDebitfee);
		
		mposCreditFee.setId(mposDebitfee.getId());
		mposRemoteFeeMapper.insert(mposCreditFee);
		
		mweChatfee.setId(mposDebitfee.getId());
		mposRemoteFeeMapper.insert(mweChatfee);
		
		mposAliPayFee.setId(mposDebitfee.getId());
		mposRemoteFeeMapper.insert(mposAliPayFee);
		
	}



	public void saveInitiateinvitationapp(MposRemoteInvitation mposRemoteInvitation, HttpServletRequest request) throws BusinessException, ParseException {
		//保存邀请信息
		Users user=usersMapper.selectUsersByAgentNo(mposRemoteInvitation.getAgentId()==null?"":mposRemoteInvitation.getAgentId().toString());
		mposRemoteInvitation.setCreateDate(new Date());
		mposRemoteInvitation.setRemoteInvitation(new Date());
		mposRemoteInvitation.setStatus(Constants.CON_YES);
		mposRemoteInvitation.setSalesman(user.getId());
		Date pasDate=DateUtil.calculateDate(new Date(), Constants.PASTDATE);
		mposRemoteInvitation.setPastDate(pasDate);
		
		String passw=RandomStringUtils.random(6, "0123456789");;
		mposRemoteInvitation.setPassword(passw);
		
		mposRemoteInvitationMapper.insertSelective(mposRemoteInvitation);
		//发送短信
		sendSmsapp(mposRemoteInvitation,request);
	}

	/**
	 * 发送短信
	 * @throws BusinessException 
	 */
	public void sendSms(MposRemoteInvitation mposRemote,HttpServletRequest request) throws BusinessException {
		try {
			Map<String,String> params = new HashMap<String,String>();
			String content=getContent(ConstantsEnv.SMS_CONTENT,params,mposRemote);
			String tel = mposRemote.getTel();
			sendMessageService.sendSmsMessage(tel, content);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.发送短信失败);
		}
		
	}
	
	public void sendSmsapp(MposRemoteInvitation mposRemote,HttpServletRequest request) throws BusinessException {
		try {
			Map<String,String> params = new HashMap<String,String>();
			String content=getContentapp(ConstantsEnv.SMS_CONTENT,params,mposRemote);
			String tel = mposRemote.getTel();
			sendMessageService.sendSmsMessage(tel, content);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.发送短信失败);
		}
		
	}
	
	/**
	 * @param smsContent
	 * @param params
	 * @param mposRemote
	 * @return
	 */
	private String getContent(String smsContent, Map<String, String> params, MposRemoteInvitation mposRemote) {
		Map map=getMposRemoteInvitationValues(mposRemote);
		return this.replaceValues(smsContent, map);
	}

	private String getContentapp(String smsContent, Map<String, String> params, MposRemoteInvitation mposRemote) {
		Map map=getMposRemoteInvitationValuesapp(mposRemote);
		return this.replaceValues(smsContent, map);
	}
	/**
	 * @param mposremote
	 * @return
	 */
	private Map<String, String> getMposRemoteInvitationValues(MposRemoteInvitation mposremote) {

		Map<String, String> map = new HashMap<String, String>();
		Users user=usersMapper.selectByPrimaryId(mposremote.getSalesman()==null?"":mposremote.getSalesman().toString());
		map.put("${salesman}", user.getUserName() + "");
		map.put("${pastDate}", DateUtil.date2String(mposremote.getPastDate() , "yyyy-MM-dd HH:mm:ss")+ "");
		map.put("${agenttel}",user.getTel()+ "");
		map.put("${password}",mposremote.getPassword());
		return map;
	}

	
	private Map<String, String> getMposRemoteInvitationValuesapp(MposRemoteInvitation mposremote) {

		Map<String, String> map = new HashMap<String, String>();
		Users user=usersMapper.selectUsersByAgentNo(mposremote.getAgentId()==null?"":mposremote.getAgentId().toString());
		map.put("${salesman}", user.getUserName() + "");
		map.put("${pastDate}", DateUtil.date2String(mposremote.getPastDate() , "yyyy-MM-dd HH:mm:ss")+ "");
		map.put("${agenttel}",user.getTel()+ "");
		map.put("${password}",mposremote.getPassword());
		return map;
	}
	
	private String replaceValues(String mailContent, Map<String, String> values) {
		Set<String> set = values.keySet();
		for (String key : set){
			if(key.indexOf("${") != -1)
				mailContent = mailContent.replace(key, values.get(key) + "");
		}
		return mailContent;
	}
	public MposRemoteInvitation findMposRemoteInvitationById(Long remoteInvitationId) {
		return mposRemoteInvitationMapper.selectByPrimaryKey(remoteInvitationId);
	}
	/**根据tel获取记录
	 * @param tel
	 * @return
	 */
	public List findMposRemoteInvitationByTel(String tel) {
		HashMap map=new HashMap();
		map.put("tel", tel);
		map.put("status", Constants.CON_YES);
		return mposRemoteInvitationMapper.findMposRemoteInvitationByTel(map);
	}
	/**
	 * 重新发送短信
	 * @param request 
	 * @throws BusinessException 
	 * @throws ParseException 
	 */
	public void resend(MposRemoteInvitation mposRemoteInvitation, HttpServletRequest request) throws BusinessException, ParseException {
		sendSms(mposRemoteInvitation,request);
		mposRemoteInvitation.setStatus(Constants.CON_YES);
		mposRemoteInvitation.setRemoteInvitation(new Date());
		Date pasDate=DateUtil.calculateDate(new Date(), Constants.PASTDATE);
		mposRemoteInvitation.setPastDate(pasDate);
		mposRemoteInvitation.setUpdateDate(new Date());
		update(mposRemoteInvitation);
		
	}
	
	
	
	/**APP端重发短信
	 * @param mposRemoteInvitation
	 * @param request
	 * @throws BusinessException
	 * @throws ParseException
	 */
	public void resendapp(MposRemoteInvitation mposRemoteInvitation, HttpServletRequest request) throws BusinessException, ParseException {
		sendSmsapp(mposRemoteInvitation,request);
		mposRemoteInvitation.setStatus(Constants.CON_YES);
		mposRemoteInvitation.setRemoteInvitation(new Date());
		Date pasDate=DateUtil.calculateDate(new Date(), Constants.PASTDATE);
		mposRemoteInvitation.setPastDate(pasDate);
		mposRemoteInvitation.setUpdateDate(new Date());
		update(mposRemoteInvitation);
		
	}
	/**
	 * 修改MposRemoteInvitation 
	 */
	public void update(MposRemoteInvitation mposRemoteInvitation) {
		mposRemoteInvitationMapper.updateByPrimaryKeySelective(mposRemoteInvitation);
	}
	
	
	/**
	 * 撤回
	 */
	public void recall(MposRemoteInvitation mposRemoteInvitation) {
		mposRemoteInvitation.setUpdateDate(new Date());
		mposRemoteInvitation.setStatus(Constants.REPEAL);
		mposRemoteFeeMapper.delfee(mposRemoteInvitation.getTel());
		update(mposRemoteInvitation);
	}
	public void recallapp(MposRemoteInvitation mposRemoteInvitation,String tel) {
		mposRemoteInvitation.setUpdateDate(new Date());
		mposRemoteInvitation.setStatus(Constants.REPEAL);
		mposRemoteFeeMapper.delfee(tel);
		update(mposRemoteInvitation);
	}
	
	public MposRemoteInvitation findbytel(String tel){
		List list=mposRemoteInvitationMapper.findbytel(tel);
		MposRemoteInvitation remote=null;
		if(list!=null&&list.size()>0){
			remote=(MposRemoteInvitation)list.get(0);
		}
		return remote;  
		
	}
	
	public MposRemoteInvitation findbytelstauts(String tel){
		List list= mposRemoteInvitationMapper.findbytelstauts(tel);
		MposRemoteInvitation remote=null;
		if(list!=null&&list.size()>0){
			remote=(MposRemoteInvitation)list.get(0);
		}
		return remote;
	}
	
	public Agent findbyagent(String agentid){
		Agent agent=agentMapper.searchAgentByShopperid(agentid);
		return agent;  
		
	}



	public List findmposAgent(Long merchantid) {
		return usersMapper.findmposAgent(merchantid);
	}
	

	
	public Map findHisTranList(String agentid, String tPage, HttpServletRequest request) throws IllegalAccessException, InvocationTargetException {
		if (StringUtils.isEmpty(tPage) || !StringUtils.isNumeric(tPage)){
			tPage = "1";
		}
		int currentPage = Integer.valueOf(tPage);
		Page page  = new Page();

		PageContext context = PageContext.getContext();
		page.setCurrentPage(currentPage);
		BeanUtils.copyProperties(context, page);
		context.setPageSize(Constants.page_size);
		context.setPagination(true);
		
		
		List list=mposRemoteInvitationMapper.findbyagentList(agentid);
		
		Map map=new HashMap();
		map.put("list", list);
		map.put("page", context.getCurrentPage());
		map.put("pages",context.getTotalPages());
		map.put("count",context.getTotalRows());
		return map;
	}
    
	
	public MposRemoteInvitation selectByPrimaryKey(Long id) {
		return mposRemoteInvitationMapper.selectByPrimaryKey(id);
	}



	public void insertRemoteInvitationfee(
			MposRemoteInvitation mposRemoteInvitation, String debitfee,
			String creditfee, String weChatT1fee, String aliPayT1Fee, 
			String weChatD0fee, String aliPayD0Fee, HttpServletRequest request) throws Exception {
		//借记卡
		MposRemoteFee mposDebitfee=new MposRemoteFee();
		mposDebitfee.setTel(mposRemoteInvitation.getTel());
		mposDebitfee.setFeetype(Constants.CON_NO);//借记卡
		mposDebitfee.setFee(debitfee);
		mposDebitfee.setCreateDate(new Date());
		mposDebitfee.setStatus(Constants.CON_YES);
		mposDebitfee.setD0fee(mposRemoteInvitation.getT0Fee());
		//贷记卡
		MposRemoteFee mposCreditFee=new MposRemoteFee();
		mposCreditFee.setTel(mposRemoteInvitation.getTel());
		mposCreditFee.setFeetype(Constants.CON_YES);//贷记卡
		mposCreditFee.setFee(creditfee);
		mposCreditFee.setCreateDate(new Date());
		mposCreditFee.setD0fee(mposRemoteInvitation.getT0Fee());
		mposCreditFee.setStatus(Constants.CON_YES);
		
		//微信
		MposRemoteFee weChatfee=new MposRemoteFee();
		weChatfee.setTel(mposRemoteInvitation.getTel());
		weChatfee.setFeetype(Constants.STATUS2);//微信
		weChatfee.setFee(weChatT1fee);
		weChatfee.setCreateDate(new Date());
		weChatfee.setD0fee(weChatD0fee);
		weChatfee.setStatus(Constants.CON_YES);
		//支付宝
		MposRemoteFee aliPayFee=new MposRemoteFee();
		aliPayFee.setTel(mposRemoteInvitation.getTel());
		aliPayFee.setFeetype(Constants.STATUS3);//支付宝
		aliPayFee.setFee(aliPayT1Fee);
		aliPayFee.setCreateDate(new Date());
		aliPayFee.setD0fee(aliPayD0Fee);
		aliPayFee.setStatus(Constants.CON_YES);//正常
		
		
		
		mposRemoteFeeMapper.insertSelective(mposDebitfee);
		mposCreditFee.setId(mposDebitfee.getId());
		mposRemoteFeeMapper.insert(mposCreditFee);
		//微信
		weChatfee.setId(mposDebitfee.getId());
		mposRemoteFeeMapper.insert(weChatfee);
		//支付宝
		aliPayFee.setId(mposDebitfee.getId());
		mposRemoteFeeMapper.insert(aliPayFee);
		
		saveInitiateinvitationapp(mposRemoteInvitation,request);
	}

}
