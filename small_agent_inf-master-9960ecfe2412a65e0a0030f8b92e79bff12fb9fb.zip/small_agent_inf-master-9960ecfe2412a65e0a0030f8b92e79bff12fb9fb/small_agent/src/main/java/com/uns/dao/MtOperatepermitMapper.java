package com.uns.dao;

import com.uns.model.MtOperatepermit;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MtOperatepermitMapper {

    List<MtOperatepermit> selectAllPermitTypeList();
}