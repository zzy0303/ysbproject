package com.uns.util;

import org.apache.commons.lang3.RandomStringUtils;

public class CodeCreater {
	public static String getPosShopperId(String area, String mcc) {
		String organization="800"; 
		String areacold="";
		if (area.length()>4) {
			areacold=area.substring(0,4);
		}else {
			areacold=area;
		} 	
		String mcccold="";	
		if (mcc.length()==1) {
			mcccold="000"+mcc;
		}else {
			mcccold="00"+mcc;
		}
		String merchantRadom=RandomStringUtils.randomNumeric(4);
		String posMerchantId=organization+areacold+mcccold+merchantRadom;
		return posMerchantId;
	}
}
