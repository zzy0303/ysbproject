package com.uns.dao;

import com.uns.model.Mcc;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface MccMapper {

	List<Mcc> searchMcc();

	List<Mcc> searchMccById(Map map);
}
