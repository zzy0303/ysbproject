package com.uns.web;

import com.uns.common.Constants;
import com.uns.dao.B2cShopperbiTempMapper;
import com.uns.model.MposPhotoTmp;
import com.uns.service.*;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping(value = "/appphotoController.htm")
public class AppphotoController extends BaseController {

	@Autowired
	private ShopPerbiService merchantregservice;

	@Autowired
	private ImageInterfaceService imageInterfaceService;

	@Autowired
	private PhotoService photoservice;
    
	@Autowired
	private MposApplicationProgressService progressService;

	/**
	 * @param request
	 * @param response
	 * @throws Exception
	 *             APP证件照上传
	 */
	@RequestMapping(params = "method=uploadphoto")
	public void uploadphoto(HttpServletRequest request,	HttpServletResponse response) throws Exception {
		Map hashMap = new HashMap();
		try {
			String identityId = request.getParameter("identityId").toUpperCase() ;
			String shopperType= request.getParameter("shopperType");
		
			String p1 = request.getParameter("handIdentityCardPhoto") == null ? "": request.getParameter("handIdentityCardPhoto");
			String p2 = request.getParameter("frontIdentityCardPhoto") == null ? "": request.getParameter("frontIdentityCardPhoto");
			String p3 = request.getParameter("reverseIdentityCardPhoto") == null ? "": request.getParameter("reverseIdentityCardPhoto");
			String p4 = request.getParameter("storePhoto") == null ? "": request.getParameter("storePhoto");
			String p5 = request.getParameter("licensePhoto") == null ? "": request.getParameter("licensePhoto");
			String p6 = request.getParameter("instorePhoto") == null ? "": request.getParameter("instorePhoto");
			String p7 = request.getParameter("checkstandPhoto") == null ? "": request.getParameter("checkstandPhoto");
			String p8 = request.getParameter("signaturePhoto") == null ? "": request.getParameter("signaturePhoto");
			//11月3号添加
			String p9 = request.getParameter("creditCardPhoto") == null ? "": request.getParameter("creditCardPhoto");//信用卡
			String p10 = request.getParameter("settlementCardPhoto") == null ? "": request.getParameter("settlementCardPhoto");//结算卡
			String p11 = request.getParameter("fixPhoto") == null ? "": request.getParameter("fixPhoto");
			String p12 = request.getParameter("livingBodyFacePhoto") == null ? "": request.getParameter("livingBodyFacePhoto");
			String p13 = request.getParameter("livingBodyLeftPhoto") == null ? "": request.getParameter("livingBodyLeftPhoto");
			String p14 = request.getParameter("livingBodyReturnPhoto") == null ? "": request.getParameter("livingBodyReturnPhoto");
			String p15 = request.getParameter("livingBodyRightPhoto") == null ? "": request.getParameter("livingBodyRightPhoto");
			String p16 = request.getParameter("idCardHeadPhoto") == null ? "": request.getParameter("idCardHeadPhoto");
			//判断照片是否存在
			MposPhotoTmp photo =this.photoservice.findbsid(identityId);
			/*	if(photo!=null){
				this.photoservice.delphoto(identityId);
			}*/
			if (shopperType != null) {
				// 个人
				if (shopperType.equals(Constants.PERSONAL)) {
					String uuId1 = imageInterfaceService.saveAppImage("small_agent", "small", p1);
					String uuId2 = imageInterfaceService.saveAppImage("small_agent", "small", p2);
					String uuId3 = imageInterfaceService.saveAppImage("small_agent", "small", p3);
					String uuId4 = imageInterfaceService.saveAppImage("small_agent", "small", p4);
					String uuId6 = imageInterfaceService.saveAppImage("small_agent", "small", p6);
					String uuId7 = imageInterfaceService.saveAppImage("small_agent", "small", p7);
					String uuId8 = imageInterfaceService.saveAppImage("small_agent", "small", p8);
					//11月3号添加
					String uuId9 = imageInterfaceService.saveAppImage("small_agent", "small", p9);
					String uuId10 = imageInterfaceService.saveAppImage("small_agent", "small", p10);
					String uuId11 = imageInterfaceService.saveAppImage("small_agent", "small", p11);
					String uuId12 = imageInterfaceService.saveAppImage("small_agent", "livingBody", p12);
					String uuId13 = imageInterfaceService.saveAppImage("small_agent", "livingBody", p13);
					String uuId14 = imageInterfaceService.saveAppImage("small_agent", "livingBody", p14);
					String uuId15 = imageInterfaceService.saveAppImage("small_agent", "livingBody", p15);
					String uuId16 = imageInterfaceService.saveAppImage("small_agent", "livingBody", p16);
					
					MposPhotoTmp photo1 = new MposPhotoTmp();
					photo1.setHandIdentityCardPhoto(uuId1);
					photo1.setFrontIdentityCardPhoto(uuId2);
					photo1.setReverseIdentityCardPhoto(uuId3);
					photo1.setStorePhoto(uuId4);
					photo1.setInstorePhoto(uuId6);
					photo1.setCheckstandPhoto(uuId7);
					photo1.setSignaturePhoto(uuId8);
					//11月3号添加
					photo1.setCreditCardPhoto(uuId9);
					photo1.setSettlementCardPhoto(uuId10);
					photo1.setFixphoto(uuId11);

					photo1.setLivingBodyFacePhoto(uuId12);//活体正面
					photo1.setLivingBodyLeftPhoto(uuId13);//活体左转
					photo1.setLivingBodyReturnPhoto(uuId14);//活体回正
					photo1.setLivingBodyRightPhoto(uuId15);//活体右转
					
					photo1.setIdCardHeadPhoto(uuId16);//身份证大头贴
					
					photo1.setCheckFlag(Constants.STATUS0);
					photo1.setIdentityid(identityId);
					
					
				} else {
					// 商户
					String uuId1 = imageInterfaceService.saveAppImage("small_agent", "small", p1);
					String uuId2 = imageInterfaceService.saveAppImage("small_agent", "small", p2);
					String uuId3 = imageInterfaceService.saveAppImage("small_agent", "small", p3);
					String uuId4 = imageInterfaceService.saveAppImage("small_agent", "small", p4);
					String uuId5 = imageInterfaceService.saveAppImage("small_agent", "small", p5);
					String uuId6 = imageInterfaceService.saveAppImage("small_agent", "small", p6);
					String uuId7 = imageInterfaceService.saveAppImage("small_agent", "small", p7);
					String uuId8 = imageInterfaceService.saveAppImage("small_agent", "small", p8);
					MposPhotoTmp photo1 = new MposPhotoTmp();
					photo1.setHandIdentityCardPhoto(uuId1);
					photo1.setFrontIdentityCardPhoto(uuId2);
					photo1.setReverseIdentityCardPhoto(uuId3);
					photo1.setStorePhoto(uuId4);
					photo1.setLicensePhoto(uuId5);
					photo1.setInstorePhoto(uuId6);
					photo1.setCheckstandPhoto(uuId7);
					photo1.setSignaturePhoto(uuId8);
					photo1.setCheckFlag(Constants.STATUS0);
					photo1.setIdentityid(identityId);
					if(photo!=null){
						photo1.setPhotoId(photo.getPhotoId());
						photoservice.updatephoto(photo1);
					}else{
						photoservice.insertphoto(photo1);
					}
				}
	
				hashMap.put("returnCode", "0000");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("照片上传成功:" + json.toString());
				response.getWriter().write(json.toString());
			}else{
				hashMap.put("returnCode", "2222");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				log.info("照片上传失败:" + json.toString());
				response.getWriter().write(json.toString());
			}
		} catch (Exception e) {
			e.printStackTrace();
			hashMap.put("returnCode", "2222");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("照片上传失败:" + json.toString());
			response.getWriter().write(json.toString());
		}
	}

	
}
