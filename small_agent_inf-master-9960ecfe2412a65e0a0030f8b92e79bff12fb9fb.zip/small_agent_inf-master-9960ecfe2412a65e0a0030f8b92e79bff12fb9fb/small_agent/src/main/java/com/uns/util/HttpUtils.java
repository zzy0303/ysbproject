package com.uns.util;

import javax.servlet.http.HttpServletResponse;

public class HttpUtils {

	public static void  writeToClient(HttpServletResponse response,String contentType,String src) throws Exception{
		response.setCharacterEncoding("UTF-8");
		response.setContentType(contentType);
		response.setContentLength(src.length());
		response.getWriter().write(src);
		response.getWriter().flush();
		response.getWriter().close();
	}
}
