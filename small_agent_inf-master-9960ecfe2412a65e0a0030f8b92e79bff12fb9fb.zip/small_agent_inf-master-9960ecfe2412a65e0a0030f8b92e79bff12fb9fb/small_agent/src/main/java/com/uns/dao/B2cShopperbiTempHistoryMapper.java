package com.uns.dao;

import com.uns.model.B2cShopperbiTemp;
import com.uns.model.B2cShopperbiTempHistory;
import com.uns.web.form.ShopPerbiForm;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;

@Repository
public interface B2cShopperbiTempHistoryMapper {

    int deleteByPrimaryKey(BigDecimal b2cShopperbiId);

    int insert(B2cShopperbiTemp b2cShopperbiTemp);

    int insertSelective(B2cShopperbiTempHistory record);

    B2cShopperbiTempHistory selectByPrimaryKey(BigDecimal b2cShopperbiId);

    int updateByPrimaryKeySelective(B2cShopperbiTempHistory record);

    int updateByPrimaryKey(B2cShopperbiTempHistory record);
    
    List<HashMap> querydelshopperList(ShopPerbiForm mbForm);
    
    B2cShopperbiTempHistory selectByshopperId(Long b2cShopperbiId);
}