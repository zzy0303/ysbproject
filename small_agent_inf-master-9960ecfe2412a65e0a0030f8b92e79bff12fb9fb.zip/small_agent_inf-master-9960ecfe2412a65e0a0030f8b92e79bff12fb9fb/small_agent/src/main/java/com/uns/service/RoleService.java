package com.uns.service;

import com.uns.common.Constants;
import com.uns.common.page.PageContext;
import com.uns.dao.*;
import com.uns.model.*;
import com.uns.web.form.RoleForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class RoleService {
	
	@Autowired
	private RoleFunctionMapper roleFunctionMapper;//角色
	
	@Autowired
	private RoleInfoMapper roleInfoMapper;//权限--角色表
	
	@Autowired
	private FunctionInfoMapper functionInfoMapper;//权限
	
	@Autowired
	private FunctionMerInfoMapper functionMerInfoMapper;//权限
	
	@Autowired
	private AgentOperatorMapper users;
	
	/**列表查询
	 * @param mbForm
	 * @return
	 */
	public List selectRoleList(RoleForm mbForm)throws Exception {
		PageContext.initPageSize(20);
		return roleInfoMapper.selectRoleList(mbForm);
	}
	//查询功能树
	public Map findAllFunction() throws NumberFormatException, Exception {
		List<FunctionInfo> list=functionInfoMapper.selectByStatus(Long.valueOf(Constants.CON_YES));//状态为有效
		Map mapReturn = new HashMap();
		
		//循环遍历所有功能，放入map中，key为parentId_Id (上级功能Id和Id)
		for(Iterator iter = list.iterator(); iter.hasNext();){
			FunctionInfo func = (FunctionInfo) iter.next();
			String strId = String.valueOf(func.getId());         //角色编号
			
			String strParentId = "1";          //初始值设为1
			if(func.getFunctionId()!= null){
				strParentId = String.valueOf(func.getFunctionId());
			}
			String strKey = strParentId + "_" + strId;
			mapReturn.put(strKey, func);
		}
		return mapReturn;
	}

	/**根据角色名称验证角色名字是否重复
	 * @param roleName
	 * @param operatorId 
	 * @return
	 * @throws Exception 
	 */
	public List<RoleInfo> getRoleInfoByName(String roleName, String operatorId) throws Exception {
		Map map=new HashMap();
		map.put("roleName", roleName.trim());
		map.put("createUser", Long.valueOf(operatorId));
		return roleInfoMapper.selectByMap(map);
	}

	/**插入角色和角色权限表
	 * @param roleInfo
	 * @param ids
	 * @throws Exception 
	 */
	public void insert(RoleInfo roleInfo, Long[] ids) throws Exception {
		roleInfoMapper.insert(roleInfo);
		RoleFunction roleFunction=null;
		//保存角色权限表
		for(int i=0;i<ids.length;i++){
			if(ids[i]!=null){
				roleFunction=new RoleFunction();
				roleFunction.setFunctionId(ids[i]);
				roleFunction.setRoleId(roleInfo.getId());
				roleFunctionMapper.insert(roleFunction);
			}
		}
		
	}
	/**根据主键查询角色
	 * @param id
	 * @return
	 * @throws Exception 
	 * @throws NumberFormatException 
	 */
	public RoleInfo selectByRoleId(String id) throws NumberFormatException, Exception {
		// TODO Auto-generated method stub
		return roleInfoMapper.selectByPrimaryKey(Long.valueOf(id));
	}
	/**
	 * @param id
	 * @return
	 */
	public Users selectByUsersId(String id) {
		// TODO Auto-generated method stub
		//return users.selectById(id);
		return null;
	}
	/**根据角色值返回权限
	 * @param id
	 * @return
	 * @throws Exception 
	 * @throws NumberFormatException 
	 */
	public List selectById(String id) throws NumberFormatException, Exception {
		List<FunctionInfo> functionInfoList=functionInfoMapper.selectByPrimaryKey(Long.valueOf(id));
		return functionInfoList;
	}
	/**修改角色的权限
	 * 1.修改角色的内容。
	 * 2.删除以前的角色权限关系。
	 * 3.插入新的角色权限关系
	 * @param roleInfo
	 * @param ids
	 * @throws Exception 
	 */
	public void update(RoleInfo roleInfo, Long[] ids) throws Exception {
		roleInfoMapper.updateByPrimaryKey(roleInfo);
		roleFunctionMapper.deleteByRoleId(roleInfo.getId());
		RoleFunction roleFunction=null;
		//保存角色权限表
		for(int i=0;i<ids.length;i++){
			if(ids[i]!=null){
				roleFunction=new RoleFunction();
				roleFunction.setFunctionId(ids[i]);
				roleFunction.setRoleId(roleInfo.getId());
				roleFunctionMapper.insert(roleFunction);
			}
		}
	}
	/**
	 * 查询正常的角色
	 * @param status 
	 * @throws Exception 
	 * @throws NumberFormatException 
	 */
	public List<RoleInfo> selectRoleInfo(String status) throws NumberFormatException, Exception {
		return roleInfoMapper.selectRoleInfo(Long.valueOf(status));
	}
	/**判断登录权限
	 * 1.知道角色id,可以通过关系表找到对应的权限
	 * @param usercode
	 * @return
	 * @throws Exception 
	 */
	public Map findFunction(String usercode) throws Exception {
		
		List<FunctionInfo> list=functionInfoMapper.selectFunctionByUsercode(usercode);
		Map mapReturn = new HashMap();
		
		//循环遍历所有功能，放入map中，key为parentId_Id (上级功能Id和Id)
		for(Iterator iter = list.iterator(); iter.hasNext();){
			FunctionInfo func = (FunctionInfo) iter.next();
			String strId = String.valueOf(func.getId());         //角色编号
			
			String strParentId = "1";          //初始值设为1
			if(func.getFunctionId()!= null){
				strParentId = String.valueOf(func.getFunctionId());
			}
			String strKey = strParentId + "_" + strId;
			mapReturn.put(strKey, func);
		}
		return mapReturn;
	}
	/**代理商权限管理
	 * @param usercode
	 * @return
	 */
	public Map findFunction1(String usercode) {
		List<FunctionMerInfo> list=functionMerInfoMapper.selectFunctionByUsercode1(usercode);
		Map<Long,FunctionMerInfo>  allMap = new HashMap<Long,FunctionMerInfo>();
		Map mapReturn = new HashMap();
		
		/***第一次遍历,取根列表***/
		Long curId = null; 
		Long parId = null;
		Map<FunctionMerInfo,List<FunctionMerInfo> > dataMap = new LinkedHashMap<FunctionMerInfo,List<FunctionMerInfo>>();
		List<FunctionMerInfo> subList = null;
		
		for(Iterator iter = list.iterator(); iter.hasNext();){
			FunctionMerInfo func = (FunctionMerInfo) iter.next();
			curId = func.getId();
			allMap.put(curId, func);
			parId = func.getFunctionId();
			if(parId == null){
				dataMap.put(func, new ArrayList<FunctionMerInfo>());
			}
		}
		
		for(Iterator iter = list.iterator(); iter.hasNext();){
			FunctionMerInfo func = (FunctionMerInfo) iter.next();
			curId = func.getId();
			parId = func.getFunctionId();
			if(parId != null){
				subList = dataMap.get(allMap.get(parId));
				if(subList == null)
					subList = new ArrayList<FunctionMerInfo>();
				subList.add(func);
				dataMap.put(allMap.get(parId), subList);
			}
		}
		
		return dataMap;
	}
}
