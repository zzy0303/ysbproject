package com.uns.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class AgentSplitProfit implements Serializable {
	private static final long serialVersionUID = 1L;

	private BigDecimal id;

    private Date setDate;

    private String transType;

    private String feeType;

    private String outtradeno;
    
    private String outtradetime;

    private BigDecimal amount;

    private BigDecimal commission;

    private String shopperid;
    
    private BigDecimal skFee;
    
    private BigDecimal skTop;
    
    private BigDecimal d0fee;

    private String shopperidP;

    private String agentp;

    private BigDecimal profit;

    private Date createDate;

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public Date getSetDate() {
        return setDate;
    }

    public void setSetDate(Date setDate) {
        this.setDate = setDate;
    }

    public String getTransType() {
        return transType;
    }

    public void setTransType(String transType) {
        this.transType = transType;
    }

    public String getFeeType() {
        return feeType;
    }

    public void setFeeType(String feeType) {
        this.feeType = feeType;
    }

    public String getOuttradeno() {
        return outtradeno;
    }

    public void setOuttradeno(String outtradeno) {
        this.outtradeno = outtradeno;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getCommission() {
        return commission;
    }

    public void setCommission(BigDecimal commission) {
        this.commission = commission;
    }

    public String getShopperid() {
        return shopperid;
    }

    public void setShopperid(String shopperid) {
        this.shopperid = shopperid;
    }

    public String getShopperidP() {
        return shopperidP;
    }

    public void setShopperidP(String shopperidP) {
        this.shopperidP = shopperidP;
    }

    public String getAgentp() {
        return agentp;
    }

    public void setAgentp(String agentp) {
        this.agentp = agentp;
    }

    public BigDecimal getProfit() {
        return profit;
    }

    public void setProfit(BigDecimal profit) {
        this.profit = profit;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

	public String getOuttradetime() {
		return outtradetime;
	}

	public void setOuttradetime(String outtradetime) {
		this.outtradetime = outtradetime;
	}

	public BigDecimal getSkFee() {
		return skFee;
	}

	public void setSkFee(BigDecimal skFee) {
		this.skFee = skFee;
	}

	public BigDecimal getSkTop() {
		return skTop;
	}

	public void setSkTop(BigDecimal skTop) {
		this.skTop = skTop;
	}

	public BigDecimal getD0fee() {
		return d0fee;
	}

	public void setD0fee(BigDecimal d0fee) {
		this.d0fee = d0fee;
	}
}