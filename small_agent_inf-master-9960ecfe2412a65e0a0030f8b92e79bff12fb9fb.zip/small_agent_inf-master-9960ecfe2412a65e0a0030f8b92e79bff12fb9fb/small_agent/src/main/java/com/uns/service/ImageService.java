package com.uns.service;

import com.uns.dao.ImageMapper;
import com.uns.model.Image;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ImageService {

	
	@Autowired
	private ImageMapper ImageMapper;

	public void insertSelective(Image image) {
		ImageMapper.insertSelective(image);
	}

	public Image getImageByName(String targetFileName) {
		return ImageMapper.getImageByName(targetFileName);
	}
	
	
}
