package com.uns.inf;


import java.util.Map;

/**
 * 智能路由接口
 * The interface Smart rout inf.
 */
public interface SmartRoutInf {

    /**
     * Search shoppper string.
     * 查询商户
     * @param map the map
     * @return the string
     */
    public String searchShoppper(Map map);

}
