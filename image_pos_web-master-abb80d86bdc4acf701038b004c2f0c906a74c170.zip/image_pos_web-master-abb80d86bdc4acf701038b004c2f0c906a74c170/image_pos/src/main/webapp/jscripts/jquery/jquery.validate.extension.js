jQuery.extend(jQuery.validator.classRuleSettings, {
    compareNowDate: {compareNowDate: true},
    compareDate: {compareDate:true},
    mobile: {mobile:true},
   password: {password:true},
   volume: {volume:true},
   englishBrand:{englishBrand:true},
   chineseBrand:{chineseBrand:true},
   betweenDate:{betweenDate:true},
   numAndLetter:{numAndLetter:true},
   telephoneTest:{telephoneTest:true},
   accountTest:{accountTest:true},
   compareNowAddOneDate: {compareNowAddOneDate : true},
   decimalRrangeOne:{decimalRrangeOne:true},
   decimalRrangeTwo:{decimalRrangeTwo:true},
   requiredZero:{requiredZero : true},
   organizationCodeTest:{organizationCodeTest:true},
   idCard:{idCard:true}
});
jQuery.extend(jQuery.validator.methods, {
    compareNowDate: function(value, element) {
        var vTimeDate = new Date(value.replace("-", "/").replace("-", "/"));
        var vNowDate = new Date(new Date().getFullYear() + "/" + (new Date().getMonth() + 1) + "/" + new Date().getDate());
        return vTimeDate.getTime() >= vNowDate.getTime();
    },

    compareDate: function(value, element, param) {
        var startDate = jQuery(param)[0].value;
        var vStartDate = new Date(startDate.replace("-", "/").replace("-", "/"));
        var vEndTimeDate = new Date(value.replace("-", "/").replace("-", "/"));
        return vEndTimeDate.getTime() >= vStartDate.getTime();
    },
    //a value less than or equal
    numberCompareLeTo:function(value, element, param) {
        var paramValue = jQuery(param).val()
        var currentValue = value;
        return parseInt(paramValue) >= parseInt(currentValue);
    },
    promotionDateCompare: function(value, element, param) {
        var startDate = jQuery(param)[0].value;
        var vStartDate = new Date(startDate.replace("-", "/").replace("-", "/"));
        var vEndTimeDate = new Date(value.replace("-", "/").replace("-", "/"));
        var vOverTimeDate = new Date(jQuery("#lasteseOffLineTime").html().replace("-", "/").replace("-", "/"));
        return ((vEndTimeDate.getTime() > vStartDate.getTime()) && (vEndTimeDate.getTime() <= vOverTimeDate));
    },
    promotionNumberCompare: function(value, element, param) {
        var paramValue = jQuery(param).val()
        var currentValue = value;
        return parseInt(currentValue) > parseInt(paramValue);
    },
  
    selected: function(value,element,param) {
        //��Ҫ���������б�  param: #id option
        return jQuery(param).length > 0;
    },
    mobile: function(value, element){
      return this.optional(element) || /^(13[0-9]|15[0-9]|18[0-9])\d{8}/.test(value);
    },
    password: function(value, element){
      return this.optional(element) || /^[a-zA-Z0-9]{8,15}$/.test(value);
    },
    volume: function(value, element){
      return this.optional(element) || /^(300|[1-2][0-9][0-9]|[1-9][0-9]{0,1})\*(300|[1-2][0-9][0-9]|[1-9][0-9]{0,1})\*(300|[1-2][0-9][0-9]|[1-9][0-9]{0,1})$/.test(value);
    },
    englishBrand: function(value, element){
      return this.optional(element) || /^[A-Za-z\s]+$/.test(value);
    },
     chineseBrand: function(value, element){
      return this.optional(element) || /^[\u4e00-\u9fa5\s]+$/.test(value);
    },
	betweenDate: function(value, element){
		var el = element.parentNode.getElementsByTagName("input");
		var beginDate = new Date(el[0].value.replace(/-/g,"\/"));
		var endDate = new Date(el[1].value.replace(/-/g,"\/"));
		return(beginDate < endDate);			
	},
	numAndLetter: function(value, element){
	  return this.optional(element) || /^[a-zA-Z0-9]+$/.test(value);
	},
	telephoneTest: function(value, element){
	  return this.optional(element) || /(^(\d{2,4}[-]?)?\d{3,8}([-]?\d{3,8})?([-]?\d{1,7})?$)|(^0?1[35]\d{9}$)/.test(value);
	},
	accountTest:function(value, element){
	  return this.optional(element) || /^[a-z0-9_\u4e00-\u9fa5]{4,16}$/.test(value);
	},
    compareNowAddOneDate: function(value, element) {
        var vTimeDate = new Date(value.replace("-", "/").replace("-", "/"));
        var vNowDate = new Date(new Date().getFullYear() + "/" + (new Date().getMonth() + 1) + "/" + new Date().getDate());
        return vTimeDate.getTime() > vNowDate.getTime();
    },
    decimalRrangeOne: function(value,element) {
        return this.optional(element) || /^[0-9]+(.[0-9]){0,1}$/.test(value);
    },
    decimalRrangeTwo: function(value,element) {
        return this.optional(element) || /^[0-9]+(.[0-9]{0,2}){0,1}$/.test(value);
    },
    requiredZero: function(value,element) {
        return value.substring(0,1).indexOf("0") != -1 || value.substring(0,1).indexOf("1") != -1;
    },
    organizationCodeTest: function(value, element){
       return this.optional(element) || /^[a-zA-Z0-9-]+$/.test(value);
    },
    idCard: function(value, element) {
		return this.optional(element) || /^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{4}$/.test(value);
	}
});