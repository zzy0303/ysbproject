function jspOpen( jspName, Param )
{
     document.location = jspName + ".jsp?param0=" + Param;
}


function seeComment( formNO )
{
	thisForm = document.forms[formNO];
	
	thisForm.myFlag.value = "1";
	thisForm.submit( );
	return;
}


function Complete( formNO, myStat )
{
	thisForm = document.forms[formNO];

	if ( myStat == "???" )
		return true;

	thisForm.myFlag.value = "2";

	thisForm.submit( );
	return true;
}


function del1( formNO )
{
	thisForm = document.forms[formNO];
	
	thisForm.myFlag.value = "0";
	window.confirm( '?????????????' );
	thisForm.submit( );
	return true;
}


function retList( )
{
     document.location = "tomerch.jsp";
}