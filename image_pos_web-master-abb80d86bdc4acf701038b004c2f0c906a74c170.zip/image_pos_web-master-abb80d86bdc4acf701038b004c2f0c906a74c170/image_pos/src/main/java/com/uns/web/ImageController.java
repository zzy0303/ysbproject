package com.uns.web;

import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.service.ImageService;



@Controller
public class ImageController extends BaseController implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Autowired
	private ImageService imageService; 
	
	/**交易签名保存图片
	 * @param request
	 * @param response
	 * @param params
	 * @param input
	 * @return
	 * @throws Exception
	 */
	
	@RequestMapping({"/saveImage"})
	public String saveTranImage(HttpServletRequest request,HttpServletResponse response,String params) throws Exception{
		log.info("开始上传图片：...");
		
		String version =request.getParameter("version");
		String type =request.getParameter("type");
		log.info("交易签名开始上传图片：...version:"+version+"type:"+type);
		
		log.info("交易签名开始上传图片：...batch_number:"+request.getParameter("batch_number")+"pos_traceno:"+request.getParameter("pos_traceno")
				+"merchant_no:"+request.getParameter("merchant_no"));
		
	/*	if(Constants.VERSION_1_0_0.equals(version)){
			saveTranImage100(request,response);
		}else if(Constants.VERSION_2_0_0.equals(version)){
		*/	if(Constants.TYPE_A.equals(type)){
				//android2.0.0
				saveTranImageAndroid200(request,response);
			}else{
				//iso2.0.0
				saveTranImageIso200(request,response);
			}
			
//		}else{
//			saveTranImage001(request,response);
//		}
		
		return null;
	}
	
	
	/**上传卡照片
	 * @param request
	 * @param response
	 * @param params
	 * @return
	 * @throws Exception
	 */
	@RequestMapping({"/saveTranCardImage"})
	public String saveTranCardImage(HttpServletRequest request,HttpServletResponse response,String params) throws Exception{
		
		
		String version =request.getParameter("version");
		String type =request.getParameter("type");
		log.info("交易银行卡开始上传图片：...version:"+version+"type:"+type);
		
		log.info("交易银行卡开始上传图片：...batch_number:"+request.getParameter("batch_number")+"pos_traceno:"+request.getParameter("pos_traceno")
				+"merchant_no:"+request.getParameter("merchant_no"));
		
//		if(Constants.VERSION_2_0_0.equals(version)){
			if(Constants.TYPE_A.equals(type)){
				//android2.0.0  
				log.info("saveTranCardImageAndroid200");
				saveTranCardImageAndroid200(request,response);
			}else{
				//iso2.0.0
				saveTranCardImageIso200(request,response);
			}
			
//		}
		
		return null;
	}
	

	/**
	 * @param request
	 * @param response
	 * @throws IOException 
	 */
	private void saveTranCardImageIso200(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Map<String, Object> hashMap=new HashMap<String, Object>();
		try {
			Map returnMap=imageService.saveTranCardImageIso200(request);
			JSONObject ob= JSONObject.fromObject(returnMap);
			String rspCode=(String)ob.get("rspCode");
			String rspMsg=(String)ob.get("rspMsg");
			if(Constants.RSP_CODE.equals(rspCode)){
				log.info("上传卡照片成功iso2.0.0：...");
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "上传图片成功");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				System.out.println("json:"+json.toString());
				response.getWriter().write(json.toString());
			}else{
				log.info("上传卡照片失败iso2.0.0：...");
				hashMap.put("rspCode", rspCode);
				hashMap.put("rspMsg", rspMsg);
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				System.out.println("json:"+json.toString());
				response.getWriter().write(json.toString());
			}
		} catch (Exception e) {
			log.info("上传卡照片出错iso2.0.0：...");
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "系统异常");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			System.out.println("json:"+json.toString());
			response.getWriter().write(json.toString());
			e.printStackTrace();
		}
		
	}


	private void saveTranCardImageAndroid200(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Map<String, Object> hashMap=new HashMap<String, Object>();
		try {
			log.info("+++++++++++++++++++++++++++++:");
			Map returnMap=imageService.saveTranCardImageAndroid200(request);
			JSONObject ob= JSONObject.fromObject(returnMap);
			String rspCode=(String)ob.get("rspCode");
			String rspMsg=(String)ob.get("rspMsg");
			if(Constants.RSP_CODE.equals(rspCode)){
				log.info("上传卡照片成功Android2.0.0：...");
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "上传图片成功");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				System.out.println("json:"+json.toString());
				response.getWriter().write(json.toString());
			}else{
				log.info("上传卡照片失败Android2.0.0：...");
				hashMap.put("rspCode", rspCode);
				hashMap.put("rspMsg", rspMsg);
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				System.out.println("json:"+json.toString());
				response.getWriter().write(json.toString());
			}
		} catch (Exception e) {
			log.info("上传卡照片出错Android2.0.0：...");
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "系统异常");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			System.out.println("json:"+json.toString());
			response.getWriter().write(json.toString());
			e.printStackTrace();
		}
		
	}


	/**iso2.0.0上传交易签名图片
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	private void saveTranImageIso200(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		Map<String, Object> hashMap=new HashMap<String, Object>();
		try {
			Map returnMap=imageService.saveTranImageIso200(request);
			JSONObject ob= JSONObject.fromObject(returnMap);
			String rspCode=(String)ob.get("rspCode");
			String rspMsg=(String)ob.get("rspMsg");
			if(Constants.RSP_CODE.equals(rspCode)){
				log.info("上传成功iso2.0.0：...");
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "上传交易签名成功");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				System.out.println("json:"+json.toString());
				response.getWriter().write(json.toString());
			}else{
				log.info("上传失败iso2.0.0：...");
				hashMap.put("rspCode", rspCode);
				hashMap.put("rspMsg", rspMsg);
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				System.out.println("json:"+json.toString());
				response.getWriter().write(json.toString());
			}
		} catch (Exception e) {
			log.info("上传出错iso2.0.0：...");
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "交易签名出错");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			System.out.println("json:"+json.toString());
			response.getWriter().write(json.toString());
			e.printStackTrace();
		}
		
	}

	/**android2.0.0上传交易签名图片
	 * @param request
	 * @param response
	 * @throws IOException 
	 */
	private void saveTranImageAndroid200(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		Map<String, Object> hashMap=new HashMap<String, Object>();
		try {
			Map returnMap=imageService.saveTranImageAndroid200(request);
			JSONObject ob= JSONObject.fromObject(returnMap);
			String rspCode=(String)ob.get("rspCode");
			String rspMsg=(String)ob.get("rspMsg");
			if(Constants.RSP_CODE.equals(rspCode)){
				log.info("上传成功android2.0.0：...");
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "上传图片成功");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				System.out.println("json:"+json.toString());
				response.getWriter().write(json.toString());
			}else{
				log.info("上传失败android2.0.0：...");
				hashMap.put("rspCode", rspCode);
				hashMap.put("rspMsg", rspMsg);
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				System.out.println("json:"+json.toString());
				response.getWriter().write(json.toString());
			}
		} catch (Exception e) {
			log.info("上传出错android2.0.0：...");
			hashMap.put("rspCode", "2222");
			hashMap.put("rspMsg", "系统异常");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			System.out.println("json:"+json.toString());
			response.getWriter().write(json.toString());
			e.printStackTrace();
		}
		
	}

	private void saveTranImage001(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Map<String, Object> hashMap=new HashMap<String, Object>();
		try {
			String uuid=imageService.saveTranImage(request);
			if(StringUtils.isNotEmpty(uuid)){
				log.info("上传成功：...");
				hashMap.put("returnCode", "0000");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				System.out.println("json:"+json.toString());
				response.getWriter().write(json.toString());
			}else{
				log.info("上传失败：...");
				hashMap.put("returnCode", "1111");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				System.out.println("json:"+json.toString());
				response.getWriter().write(json.toString());
			}
		} catch (Exception e) {
			log.info("上传出错：...");
			hashMap.put("returnCode", "2222");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			System.out.println("json:"+json.toString());
			response.getWriter().write(json.toString());
			e.printStackTrace();
		}
		
	}

	private void saveTranImage100(HttpServletRequest request,HttpServletResponse response) throws Exception {
		Map<String, Object> hashMap=new HashMap<String, Object>();	
		try {
			String uuid=imageService.saveTranImage(request);
			if(StringUtils.isNotEmpty(uuid)){
				log.info("上传成功：...");
				hashMap.put("rspCode", "0000");
				hashMap.put("rspMsg", "上传成功");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				System.out.println("json:"+json.toString());
				response.getWriter().write(json.toString());
			}else{
				log.info("上传失败：...");
				hashMap.put("rspCode", "1111");
				hashMap.put("rspMsg", "上传失败");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				System.out.println("json:"+json.toString());
				response.getWriter().write(json.toString());
			}
			} catch (Exception e) {
				log.info("上传出错：...");
				hashMap.put("rspCode", "2222");
				hashMap.put("rspMsg", "上传出错");
				response.setContentType("UTF-8");
				JSONObject json = JSONObject.fromObject(hashMap);
				System.out.println("json:"+json.toString());
				response.getWriter().write(json.toString());
				e.printStackTrace();
			}
			
	}

	
	
}
