package com.uns.model;

import java.io.Serializable;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/2/28
 * @Modifyed By:
 */
public class InsImageModel implements Serializable {
    private String faceIdCard;
    private String backIdCard;
    private String handIdCard;
    private String debitCard;
    private String businessLicence;
    private String accountOpenPermit;
    private String idCard;

    public String getFaceIdCard() {
        return faceIdCard;
    }

    public void setFaceIdCard(String faceIdCard) {
        this.faceIdCard = faceIdCard;
    }

    public String getBackIdCard() {
        return backIdCard;
    }

    public void setBackIdCard(String backIdCard) {
        this.backIdCard = backIdCard;
    }

    public String getHandIdCard() {
        return handIdCard;
    }

    public void setHandIdCard(String handIdCard) {
        this.handIdCard = handIdCard;
    }

    public String getDebitCard() {
        return debitCard;
    }

    public void setDebitCard(String debitCard) {
        this.debitCard = debitCard;
    }

    public String getBusinessLicence() {
        return businessLicence;
    }

    public void setBusinessLicence(String businessLicence) {
        this.businessLicence = businessLicence;
    }

    public String getAccountOpenPermit() {
        return accountOpenPermit;
    }

    public void setAccountOpenPermit(String accountOpenPermit) {
        this.accountOpenPermit = accountOpenPermit;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }
}
