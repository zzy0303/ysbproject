package com.uns.web;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;
import net.sf.json.JSONObject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import sun.swing.StringUIClientPropertyKey;

import com.uns.common.Constants;
import com.uns.service.ImageInterfaceService;
import com.uns.util.AesEncrypt;
import com.uns.util.HttpClientUtils;

@Controller

public class AppphotoController extends BaseController {

    @Autowired
    private ImageInterfaceService imageInterfaceService;

    /**
     * @param request
     * @param response
     * @throws Exception APP证件照上传
     */
    @RequestMapping({"/uploadphoto"})
    public void uploadphoto(HttpServletRequest request, HttpServletResponse response) throws Exception {
        Map hashMap = new HashMap();
        String identityId = "";
        String version = request.getParameter("version");
        if (Constants.VERSION_2_1_0.equals(version)) {
            identityId = request.getParameter("identityId");
        } else {
            identityId = AesEncrypt.decryptAES(request.getParameter("identityId"), "9513624781236547");
        }

        String p1 = request.getParameter("handIdentityCardPhoto") == null ? null : request.getParameter("handIdentityCardPhoto");
        String p2 = request.getParameter("frontIdentityCardPhoto") == null ? null : request.getParameter("frontIdentityCardPhoto");
        String p3 = request.getParameter("reverseIdentityCardPhoto") == null ? null : request.getParameter("reverseIdentityCardPhoto");
        String p4 = request.getParameter("storePhoto") == null ? null : request.getParameter("storePhoto");
        String p5 = request.getParameter("licensePhoto") == null ? null : request.getParameter("licensePhoto");//企业执照
        String p6 = request.getParameter("instorePhoto") == null ? null : request.getParameter("instorePhoto");
        String p7 = request.getParameter("checkstandPhoto") == null ? null : request.getParameter("checkstandPhoto");
        String p8 = request.getParameter("signaturePhoto") == null ? null : request.getParameter("signaturePhoto");
        String p9 = request.getParameter("creditCardPhoto") == null ? null : request.getParameter("creditCardPhoto");
        String p10 = request.getParameter("settlementCardPhoto") == null ? null : request.getParameter("settlementCardPhoto");
        String p11 = request.getParameter("fixPhoto") == null ? null : request.getParameter("fixPhoto");
        //新加商户认证：
        String merchantType = request.getParameter("merchantType") == null ? "" :request.getParameter("merchantType"); //商户类型
        String p12 = request.getParameter("lobbyPhoto") == null ? null : request.getParameter("lobbyPhoto");//大堂照片
        String p13 = request.getParameter("openLicensePhoto") == null ? null : request.getParameter("openLicensePhoto");//开户许可证
        log.info("identityId:" + identityId + "version:" + version + "手持：" + p1 + "正面：" + p2 + "反面：" + p3 + "门店：" + p4 + "执照：" + p5 + "门店内：" + p6 + "收银台：" + p7 + "签名：" + p8
                + "信用卡：" + p9 + "结算卡：" + p10 + "固码照片" + p11 + "大堂照片" + p12 + "开户许可证" + p13);

        if (identityId != null) {
            // 商户
            Map hashmap = new HashMap();
            Map handIdentity = p1 == null ? null : imageInterfaceService.saveAppImage("small_agent", "small", p1, "handIdentityCardPhoto", identityId);
            Map frontIdentity = p2 == null ? null : imageInterfaceService.saveAppImage("small_agent", "small", p2, "frontIdentityCardPhoto", identityId);
            Map reverseIdentity = p3 == null ? null : imageInterfaceService.saveAppImage("small_agent", "small", p3, "reverseIdentityCardPhoto", identityId);
            Map storePhoto = p4 == null ? null : imageInterfaceService.saveAppImage("small_agent", "small", p4, "storePhoto", identityId);
            Map licensePhoto = p5 == null ? null : imageInterfaceService.saveAppImage("small_agent", "small", p5, "licensePhoto", identityId);
            Map instorePhoto = p6 == null ? null : imageInterfaceService.saveAppImage("small_agent", "small", p6, "instorePhoto", identityId);
            Map checkstandPhoto = p7 == null ? null : imageInterfaceService.saveAppImage("small_agent", "small", p7,"checkstandPhoto",identityId);
            Map signaturePhoto = p8 == null ? null : imageInterfaceService.saveAppImage("small_agent", "small", p8, "signaturePhoto", identityId);
            Map creditCardPhoto = p9 == null ? null : imageInterfaceService.saveAppImage("small_agent", "small", p9, "creditCardPhoto", identityId);
            Map settlementCardPhoto = p10 == null ? null : imageInterfaceService.saveAppImage("small_agent", "small", p10, "settlementCardPhoto", identityId);
            Map fixPhoto = null;
            if (StringUtils.isNotEmpty(p11)) {
                fixPhoto = p11 == null ? null : imageInterfaceService.saveAppImage("small_agent", "small", p11, "fixPhoto", identityId);
            }
            Map lobbyPhoto = p12 == null ? null : imageInterfaceService.saveAppImage("small_agent", "small", p12, "lobbyPhoto", identityId);
            Map openLicensePhoto = p13 == null ? null : imageInterfaceService.saveAppImage("small_agent", "small", p13, "openLicensePhoto", identityId);

            hashmap.put("handIdentity", JSONObject.fromObject(handIdentity));
            hashmap.put("frontIdentity", JSONObject.fromObject(frontIdentity));
            hashmap.put("reverseIdentity", JSONObject.fromObject(reverseIdentity));
            hashmap.put("storePhoto", JSONObject.fromObject(storePhoto));
            hashmap.put("licensePhoto", JSONObject.fromObject(licensePhoto));
            hashmap.put("instorePhoto", JSONObject.fromObject(instorePhoto));
            hashmap.put("checkstandPhoto", JSONObject.fromObject(checkstandPhoto));
            hashmap.put("signaturePhoto", JSONObject.fromObject(signaturePhoto));
            hashmap.put("creditCardPhoto", JSONObject.fromObject(creditCardPhoto));
            hashmap.put("settlementCardPhoto", JSONObject.fromObject(settlementCardPhoto));
            hashmap.put("fixPhoto", JSONObject.fromObject(fixPhoto));
            //新加商户认证
            hashmap.put("lobbyPhoto", JSONObject.fromObject(lobbyPhoto));// 大堂照片
            hashmap.put("openLicensePhoto", JSONObject.fromObject(openLicensePhoto));//开户许可证
            hashmap.put("identityId", identityId);
            hashmap.put("merchantType",merchantType); //商户类型

            Map resultMap = HttpClientUtils.postRequestMap(Constants.IMAGEURL, hashmap, Map.class);
            response.setContentType("UTF-8");
            JSONObject json = JSONObject.fromObject(resultMap);
            log.info("照片上传结果:" + json.toString());
            response.getWriter().write(json.toString());
        } else {
            hashMap.put("returnCode", "2222");
            hashMap.put("msg", "身份证号为空!");
            response.setContentType("UTF-8");
            JSONObject json = JSONObject.fromObject(hashMap);
            log.info("结果:" + json.toString());
            response.getWriter().write(json.toString());
        }
    }

    /**
     * App图片更新
     *
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/updateAppPhoto", method = RequestMethod.POST)
    public void updateAppPhoto(HttpServletRequest request,
                               HttpServletResponse response) throws Exception {
        String version = request.getParameter("version") == null ? "" : request.getParameter("version").trim();
        if (Constants.VERSION_2_3_0.equals(version) || Constants.VERSION_2_4_0.equals(version)) {
            updateAppPhotoOCR(version, request, response);
        } else {
            updateAppPhotoOld(version, request, response);
        }

    }

    /**
     * OCR版本更新图片
     */
    private void updateAppPhotoOCR(String version, HttpServletRequest request, HttpServletResponse response) throws Exception {
        Map hashMap = new HashMap();
        Map hashmap = new HashMap();
//		String photoid = request.getParameter("photoid");

        String identityId = AesEncrypt.decryptAES(request.getParameter("identityId"), Constants.APP_AES_KEY);

        String p1 = request.getParameter("handIdentityCardPhoto") == null ? null : request.getParameter("handIdentityCardPhoto");
        String p2 = request.getParameter("frontIdentityCardPhoto") == null ? null : request.getParameter("frontIdentityCardPhoto");
        String p3 = request.getParameter("reverseIdentityCardPhoto") == null ? null : request.getParameter("reverseIdentityCardPhoto");
        String p4 = request.getParameter("storePhoto") == null ? null : request.getParameter("storePhoto");
        String p5 = request.getParameter("licensePhoto") == null ? null : request.getParameter("licensePhoto");// 企业执照
        String p6 = request.getParameter("instorePhoto") == null ? null : request.getParameter("instorePhoto");
        //String p7 = request.getParameter("checkstandPhoto") == null ? null: request.getParameter("checkstandPhoto");
        String p8 = request.getParameter("signaturePhoto") == null ? null : request.getParameter("signaturePhoto");
        String p9 = request.getParameter("creditCardPhoto") == null ? null : request.getParameter("creditCardPhoto");
        String p10 = request.getParameter("settlementCardPhoto") == null ? null : request.getParameter("settlementCardPhoto");

        String p11 = request.getParameter("fixPhoto") == null ? null : request.getParameter("fixPhoto");

        String p12 = request.getParameter("livingBodyFacePhoto") == null ? null : request.getParameter("livingBodyFacePhoto");//活体人脸正面
        String p13 = request.getParameter("livingBodyLeftPhoto") == null ? null : request.getParameter("livingBodyLeftPhoto");//活体人脸左转
        String p14 = request.getParameter("livingBodyReturnPhoto") == null ? null : request.getParameter("livingBodyReturnPhoto");//活体人脸回正
        String p15 = request.getParameter("livingBodyRightPhoto") == null ? null : request.getParameter("livingBodyRightPhoto");//活体人脸右转
        String p16 = request.getParameter("idCardHeadPhoto") == null ? null : request.getParameter("idCardHeadPhoto");//身份证头像照
        version= request.getParameter("version");
        if (StringUtils.isNotEmpty(identityId)) {

            Map handIdentity = p1 == null ? null : imageInterfaceService.updateImage("small_agent", "small", p1, "handIdentityCardPhoto", identityId);
            Map frontIdentity = p2 == null ? null : imageInterfaceService.updateImage("small_agent", "small", p2, "frontIdentityCardPhoto", identityId);
            Map reverseIdentity = p3 == null ? null : imageInterfaceService.updateImage("small_agent", "small", p3, "reverseIdentityCardPhoto", identityId);
            Map storePhoto = p4 == null ? null : imageInterfaceService.updateImage("small_agent", "small", p4, "storePhoto", identityId);
            Map licensePhoto = p5 == null ? null : imageInterfaceService.updateImage("small_agent", "small", p5, "licensePhoto", identityId);
            Map instorePhoto = p6 == null ? null : imageInterfaceService.updateImage("small_agent", "small", p6, "instorePhoto", identityId);
//    			Map checkstandPhoto = imageInterfaceService.updateImage("small_agent", "small", p7, "checkstandPhoto", photoid);
            Map signaturePhoto = p8 == null ? null : imageInterfaceService.updateImage("small_agent", "small", p8, "signaturePhoto", identityId);
            Map creditCardPhoto = p9 == null ? null : imageInterfaceService.updateImage("small_agent", "small", p9, "creditCardPhoto", identityId);
            Map settlementCardPhoto = p10 == null ? null : imageInterfaceService.updateImage("small_agent", "small", p10, "settlementCardPhoto", identityId);
            Map fixPhoto = p11 == null ? null : imageInterfaceService.updateImage("small_agent", "small", p11, "fixPhoto", identityId);
            Map livingBodyFacePhoto = p12 == null ? null : imageInterfaceService.saveAppImage("small_agent", "livingBody", p12, "livingBodyFacePhoto", identityId);//活体人脸正面
            Map livingBodyLeftPhoto = p13 == null ? null : imageInterfaceService.saveAppImage("small_agent", "livingBody", p13, "livingBodyLeftPhoto", identityId);//活体人脸左转
            Map livingBodyReturnPhoto = p14 == null ? null : imageInterfaceService.saveAppImage("small_agent", "livingBody", p14, "livingBodyReturnPhoto", identityId);//活体人脸回正
            Map livingBodyRightPhoto = p15 == null ? null : imageInterfaceService.saveAppImage("small_agent", "livingBody", p15, "livingBodyRightPhoto", identityId);//活体人脸右转
            Map idCardHeadPhoto = p16 == null ? null : imageInterfaceService.saveAppImage("small_agent", "small", p16, "idCardHeadPhoto", identityId);//身份证大头贴

            hashmap.put("handIdentity", JSONObject.fromObject(handIdentity));
            hashmap.put("frontIdentity", JSONObject.fromObject(frontIdentity));
            hashmap.put("reverseIdentity", JSONObject.fromObject(reverseIdentity));
            hashmap.put("storePhoto", JSONObject.fromObject(storePhoto));
            hashmap.put("creditCardPhoto", JSONObject.fromObject(creditCardPhoto));// 信用卡
            //hashmap.put("checkstandPhoto",JSONObject.fromObject(checkstandPhoto));
            hashmap.put("settlementCardPhoto", JSONObject.fromObject(settlementCardPhoto));// 结算银行卡
            hashmap.put("signaturePhoto", JSONObject.fromObject(signaturePhoto));
            hashmap.put("licensePhoto", JSONObject.fromObject(licensePhoto));
            hashmap.put("instorePhoto", JSONObject.fromObject(instorePhoto));
            hashmap.put("fixPhoto", JSONObject.fromObject(fixPhoto));

            hashmap.put("livingBodyFacePhoto", JSONObject.fromObject(livingBodyFacePhoto));   //活体人脸正面
            hashmap.put("livingBodyLeftPhoto", JSONObject.fromObject(livingBodyLeftPhoto));   //活体人脸左转
            hashmap.put("livingBodyReturnPhoto", JSONObject.fromObject(livingBodyReturnPhoto));   //活体人脸回正
            hashmap.put("livingBodyRightPhoto", JSONObject.fromObject(livingBodyRightPhoto));   //活体人脸右转
            hashmap.put("idCardHeadPhoto", JSONObject.fromObject(idCardHeadPhoto));   //身份证头像照
            hashmap.put("identityId", AesEncrypt.encryptAES(identityId, Constants.APP_AES_KEY));
            hashmap.put("version", version);
            //调用small_agent的接口进行照片更新
            Map resultMap = HttpClientUtils.postRequestMap(Constants.UPDATEIMAGE, hashmap, Map.class);
            response.setContentType("UTF-8");
            JSONObject json = JSONObject.fromObject(resultMap);
            log.info("照片上传结果:" + json.toString());
            response.getWriter().write(json.toString());
        } else {
            hashMap.put("returnCode", "2222");
            hashMap.put("msg", "图片id为空");
            response.setContentType("UTF-8");
            JSONObject json = JSONObject.fromObject(hashMap);
            log.info("结果:" + json.toString());
            response.getWriter().write(json.toString());
        }
    }

    /**
     * OCR版本之前的图片更新
     *
     * @param request
     * @param response
     * @throws Exception
     */
    private void updateAppPhotoOld(String version, HttpServletRequest request, HttpServletResponse response) throws Exception {
        Map hashMap = new HashMap();
        Map hashmap = new HashMap();
//		String photoid = request.getParameter("photoid");

        String identityId = AesEncrypt.decryptAES(request.getParameter("identityId"), "9513624781236547");

        String p1 = request.getParameter("handIdentityCardPhoto") == null ? null : request.getParameter("handIdentityCardPhoto");
        String p2 = request.getParameter("frontIdentityCardPhoto") == null ? null : request.getParameter("frontIdentityCardPhoto");
        String p3 = request.getParameter("reverseIdentityCardPhoto") == null ? null : request.getParameter("reverseIdentityCardPhoto");
        String p4 = request.getParameter("storePhoto") == null ? null : request.getParameter("storePhoto");
        String p5 = request.getParameter("licensePhoto") == null ? null : request.getParameter("licensePhoto");// 企业执照
        String p6 = request.getParameter("instorePhoto") == null ? null : request.getParameter("instorePhoto");
        //String p7 = request.getParameter("checkstandPhoto") == null ? null: request.getParameter("checkstandPhoto");
        String p8 = request.getParameter("signaturePhoto") == null ? null : request.getParameter("signaturePhoto");
        String p9 = request.getParameter("creditCardPhoto") == null ? null : request.getParameter("creditCardPhoto");
        String p10 = request.getParameter("settlementCardPhoto") == null ? null : request.getParameter("settlementCardPhoto");

        String p11 = request.getParameter("fixPhoto") == null ? null : request.getParameter("fixPhoto");
        log.info("修改图片 photoid:" + identityId + "手持：" + p1 + "正面：" + p2
                + "反面：" + p3 + "门店：" + p4 + "执照：" + p5 + "门店内：" + p6 + "签名：" + p8 + "信用卡：" + p9 + "结算卡：" + p10
                + "固码照片：" + p11);
        if (StringUtils.isNotEmpty(identityId)) {

            Map handIdentity = p1 == null ? null : imageInterfaceService.updateImage("small_agent", "small", p1, "handIdentityCardPhoto", identityId);
            Map frontIdentity = p2 == null ? null : imageInterfaceService.updateImage("small_agent", "small", p2, "frontIdentityCardPhoto", identityId);
            Map reverseIdentity = p3 == null ? null : imageInterfaceService.updateImage("small_agent", "small", p3, "reverseIdentityCardPhoto", identityId);
            Map storePhoto = p4 == null ? null : imageInterfaceService.updateImage("small_agent", "small", p4, "storePhoto", identityId);
            Map licensePhoto = p5 == null ? null : imageInterfaceService.updateImage("small_agent", "small", p5, "licensePhoto", identityId);
            Map instorePhoto = p6 == null ? null : imageInterfaceService.updateImage("small_agent", "small", p6, "instorePhoto", identityId);
//    			Map checkstandPhoto = imageInterfaceService.updateImage("small_agent", "small", p7, "checkstandPhoto", photoid);
            Map signaturePhoto = p8 == null ? null : imageInterfaceService.updateImage("small_agent", "small", p8, "signaturePhoto", identityId);
            Map creditCardPhoto = p9 == null ? null : imageInterfaceService.updateImage("small_agent", "small", p9, "creditCardPhoto", identityId);
            Map settlementCardPhoto = p10 == null ? null : imageInterfaceService.updateImage("small_agent", "small", p10, "settlementCardPhoto", identityId);
            Map fixPhoto = p11 == null ? null : imageInterfaceService.updateImage("small_agent", "small", p11, "fixPhoto", identityId);

            hashmap.put("handIdentity", JSONObject.fromObject(handIdentity));
            hashmap.put("frontIdentity", JSONObject.fromObject(frontIdentity));
            hashmap.put("reverseIdentity", JSONObject.fromObject(reverseIdentity));
            hashmap.put("storePhoto", JSONObject.fromObject(storePhoto));
            hashmap.put("creditCardPhoto", JSONObject.fromObject(creditCardPhoto));// 信用卡
            //hashmap.put("checkstandPhoto",JSONObject.fromObject(checkstandPhoto));
            hashmap.put("settlementCardPhoto", JSONObject.fromObject(settlementCardPhoto));// 结算银行卡
            hashmap.put("signaturePhoto", JSONObject.fromObject(signaturePhoto));
            hashmap.put("licensePhoto", JSONObject.fromObject(licensePhoto));
            hashmap.put("instorePhoto", JSONObject.fromObject(instorePhoto));
            hashmap.put("fixPhoto", JSONObject.fromObject(fixPhoto));

            hashmap.put("hand", request.getParameter("handIdentityCardPhoto") == null ? "" : "1");
            hashmap.put("front", request.getParameter("frontIdentityCardPhoto") == null ? "" : "1");
            hashmap.put("rever", request.getParameter("reverseIdentityCardPhoto") == null ? "" : "1");
            hashmap.put("store", request.getParameter("storePhoto") == null ? "" : "1");
            hashmap.put("licen", request.getParameter("licensePhoto") == null ? "" : "1");
            hashmap.put("instore", request.getParameter("instorePhoto") == null ? "" : "1");
            hashmap.put("sign", request.getParameter("signaturePhoto") == null ? "" : "1");
            hashmap.put("credit", request.getParameter("creditCardPhoto") == null ? "" : "1");
            hashmap.put("settle", request.getParameter("settlementCardPhoto") == null ? "" : "1");
            hashmap.put("fix", request.getParameter("fixPhoto") == null ? "" : "1");
            hashmap.put("identityId", identityId);
            hashmap.put("version", version);

            Map resultMap = HttpClientUtils.postRequestMap(Constants.UPDATEIMAGE, hashmap, Map.class);
            response.setContentType("UTF-8");
            JSONObject json = JSONObject.fromObject(resultMap);
            log.info("照片上传结果:" + json.toString());
            response.getWriter().write(json.toString());
        } else {
            hashMap.put("returnCode", "2222");
            hashMap.put("msg", "图片id为空");
            response.setContentType("UTF-8");
            JSONObject json = JSONObject.fromObject(hashMap);
            log.info("结果:" + json.toString());
            response.getWriter().write(json.toString());
        }
    }
}
