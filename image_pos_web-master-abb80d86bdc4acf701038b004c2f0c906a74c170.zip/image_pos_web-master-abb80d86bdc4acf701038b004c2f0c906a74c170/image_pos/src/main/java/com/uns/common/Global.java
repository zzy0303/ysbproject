package com.uns.common;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;


/**
 * 常用工具方法
 * @author Administrator
 *
 */
public class Global {

	private static ApplicationContext springContext = null;

	public static String md5(String password) {
		StringBuffer retval = new StringBuffer();

		try {
			final byte[] passBytes = password.getBytes();
			final byte[] encodeBytes;

			encodeBytes = MessageDigest.getInstance("MD5").digest(passBytes);
			String stmp = "";
			for (int i = 0; i < encodeBytes.length; i++) {
				stmp = Integer.toHexString(((int) encodeBytes[i]) & 0xFF);

				if (stmp.length() == 1)
					stmp = "0" + stmp;

				retval.append(stmp);
			}
		} catch (NoSuchAlgorithmException e) {
			retval = new StringBuffer("");
		}

		return retval.toString();
	}
	
	/**
	 * 将日期字符串转化为日期格类型
	 * @param timeStr
	 * @param pattern
	 * @return
	 */
	public static Date String2Date(String timeStr,String pattern){
		Date tmp = null;
		try {
			tmp = new SimpleDateFormat(pattern).parse(timeStr);
		} catch (ParseException e) {
			return null;
		}
		return tmp;
	}
	
	/**base64解密
	 * @param key
	 * @return
	 * @throws Exception
	 */
	public static byte[] decryptBASE64(String key) throws Exception {
		return (new BASE64Decoder()).decodeBuffer(key);
	}

	/**base64加密
	 * @param key
	 * @return
	 * @throws Exception
	 */
	public static String encryptBASE64(byte[] key) throws Exception {
		return (new BASE64Encoder()).encodeBuffer(key);
	}
	
	public static ApplicationContext getSpringContext(){
		return new ClassPathXmlApplicationContext(new String[]{"applicationContext.xml"});
	}

	
}
