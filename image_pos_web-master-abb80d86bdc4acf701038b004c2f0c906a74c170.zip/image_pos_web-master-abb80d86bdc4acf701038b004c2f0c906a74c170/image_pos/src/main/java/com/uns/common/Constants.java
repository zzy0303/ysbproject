package com.uns.common;

import java.util.ResourceBundle;

import com.uns.inf.acms.client.DynamicConfigLoader;

public class Constants {
	
	/**
	 * 统一错误消息KEY
	 */
	public static final String MESSAGE_KEY="message";
	
	public static final String SESSION_VERIFY_CODE="sessionVerifycode";
	
	public static final String SESSION_KEY_USER="sessionUser";

	public static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd";
	
	public static final String DEFAULT_DATETIME_FORMAT = "yyyy-MM-dd hh:mm:ss";

	public static final String ERROR_MESSAGE = "errMsg";

	public static final String INS_IMAGE_PATH = DynamicConfigLoader.getByEnv("ins_imagepath.url");
	
	public static final String PATH = DynamicConfigLoader.getByEnv("imagepath.url");
	
	public static final String CARD_PATH = DynamicConfigLoader.getByEnv("card_path.url");
	
	public static final String PERSON_PATH = DynamicConfigLoader.getByEnv("personpath.url");

	public static final String CFM_CHARGE =  DynamicConfigLoader.getByEnv("cfm_charge.url");
	
	public static final String IMAGEURL= DynamicConfigLoader.getByEnv("imageurl");
	
	public static final String UPDATEIMAGE=DynamicConfigLoader.getByEnv("updateimage");

	public static final String VERSION_1_0_0 = "1.0.0";

	public static final String VERSION_2_0_0 = "2.0.0";
	
	
	public static final String TYPE_A="A";
	
	public static final String TYPE_I="I";
	
	public static final String RSP_CODE="0000";
	
	public static final String CARD_IMAGE_URL = DynamicConfigLoader.getByEnv("card_image_url");

	public static final String VERSION_2_1_0 = "2.1.0";
	
	public static final String VERSION_2_3_0 = "2.3.0";

	public static final String VERSION_2_4_0 = "2.4.0";

	public static final String APP_AES_KEY = DynamicConfigLoader.getByEnv("app_aes_key");

}
