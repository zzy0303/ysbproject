package com.uns.service;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import net.sf.json.JSONObject;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import sun.misc.BASE64Decoder;

import com.uns.common.Base64;
import com.uns.common.Constants;

import com.uns.dao.ImageMapper;
import com.uns.model.Image;
import com.uns.util.HttpClientUtils;

@Component
public class ImageServiceImpl implements ImageInterfaceService {

	private Logger logger = Logger.getLogger(ImageServiceImpl.class);

	@Autowired
	private ImageMapper imageMapper;

	/*
	 * web保存接口
	 */
	@Override
	public String saveImage(String moduleName, String fileName,
			String imageFrom, InputStream input) throws Exception {

		String targetDirectory = "";
		String targetFileName = "";
		String fullPath = "";
		// 保存文件
		String sep = File.separator;
		int index = fileName.lastIndexOf(".");
		targetFileName = System.currentTimeMillis()
				+ RandomStringUtils.randomNumeric(6)
				+ fileName.substring(index);
		System.out.println("**:" + targetFileName);
		targetDirectory = sep + moduleName + sep
				+ new SimpleDateFormat("yyyyMMdd").format(new Date()) + sep;
		File uploadFile = new File(Constants.PATH + targetDirectory);
		if (!uploadFile.exists()) {
			logger.info("crate dir:" + uploadFile);
			uploadFile.mkdirs();
		}

		OutputStream os = null;
		try {
			fullPath = Constants.PATH + targetDirectory + sep + targetFileName;
			logger.info("file path:" + fullPath);
			os = new FileOutputStream(new File(fullPath));

			ByteArrayOutputStream baos = new ByteArrayOutputStream();

			byte[] b = new byte[1024];
			int len = 0;
			System.out.println("图片的大小" + b.length);
			while ((len = input.read(b)) >= 0) {
				baos.write(b, 0, len);
			}
			System.out.println("加密后的密文:"
					+ Base64.encode(baos.toByteArray()).toString());
			os.write(baos.toByteArray());
			os.flush();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			os.close();
		}

		String imagepath = Constants.PATH + targetDirectory;
		Map hashMap = new HashMap();
		hashMap.put("imagename", targetFileName);
		hashMap.put("imagepath", imagepath);
		hashMap.put("moduleName", moduleName);
		hashMap.put("imageFrom", imageFrom);
		Map resultMap = HttpClientUtils.postRequestMap(Constants.IMAGEURL,
				hashMap, Map.class);
		/*
		 * //图片相关信息数据库保存 com.uns.model.Image image = new Image();
		 * image.setImageName(targetFileName); image.setImagePath(Constants.PATH
		 * + targetDirectory); image.setModuleName(moduleName);
		 * image.setCreateDate(new Date()); image.setUpdateDate(new Date());
		 * image.setImageFrom(imageFrom); ImageMapper.insertSelective(image);
		 * 
		 * Image image1 = ImageMapper.getImageByName(targetFileName); String a =
		 * image1.getUuid().toString(); System.out.println(a); return
		 * image1.getUuid().toString();
		 */

		System.out.println("json:" + resultMap);
		JSONObject ob = JSONObject.fromObject(resultMap);
		String uuid = (String) ob.get("uuid");

		return uuid;
	}

	/*
	 * 
	 */
	@Override
	public Map saveAppImage(String moduleName, String imageFrom,
			String StringStream, String photoname, String sid) throws Exception {

		String targetDirectory = "";
		String targetFileName = "";
		String fullPath = "";
		// 文件路径的分隔符

		String sep = File.separator;
		// 保存交易图片
		targetFileName = System.currentTimeMillis()
				+ RandomStringUtils.randomNumeric(6) + ".jpg";
		targetDirectory = sep + moduleName + sep
				+ new SimpleDateFormat("yyyyMMdd").format(new Date()) + sep;
		File uploadFile = new File(Constants.PATH + targetDirectory);
		if (!uploadFile.exists()) {
			uploadFile.mkdirs();
		}

		OutputStream os = null;

		fullPath = Constants.PATH + targetDirectory + sep + targetFileName;

		os = new FileOutputStream(new File(fullPath));
		byte[] buffer = new BASE64Decoder().decodeBuffer(StringStream);
		os.write(buffer);
		os.flush();
		os.close();
		String imagepath = Constants.PATH + targetDirectory;
		Map hashMap = new HashMap();
		hashMap.put("targetFileName", targetFileName);
		hashMap.put("imagepath", imagepath);
		hashMap.put("moduleName", moduleName);
		hashMap.put("imageFrom", imageFrom);
		hashMap.put("identityId", sid);
		hashMap.put("photoname", photoname);
		return hashMap;
	}

	/*
	 * 
	 */
	@Override
	public Map updateImage(String moduleName, String imageFrom,
			String StringStream, String photoname, String sid) throws Exception {

		String targetDirectory = "";
		String targetFileName = "";
		String fullPath = "";
		// 文件路径的分隔符

		String sep = File.separator;
		// 保存交易图片
		targetFileName = System.currentTimeMillis()
				+ RandomStringUtils.randomNumeric(6) + ".jpg";
		targetDirectory = sep + moduleName + sep
				+ new SimpleDateFormat("yyyyMMdd").format(new Date()) + sep;
		File uploadFile = new File(Constants.PATH + targetDirectory);
		if (!uploadFile.exists()) {
			uploadFile.mkdirs();
		}

		OutputStream os = null;

		fullPath = Constants.PATH + targetDirectory + sep + targetFileName;

		os = new FileOutputStream(new File(fullPath));
		byte[] buffer = new BASE64Decoder().decodeBuffer(StringStream);
		os.write(buffer);
		os.flush();
		os.close();
		String imagepath = Constants.PATH + targetDirectory;
		Map hashMap = new HashMap();
		hashMap.put("targetFileName", targetFileName);
		hashMap.put("imagepath", imagepath);
		hashMap.put("moduleName", moduleName);
		hashMap.put("imageFrom", imageFrom);
		hashMap.put("identityId", sid);
		hashMap.put("photoname", photoname);
		return hashMap;

	}
	@Override
	public void updateImageIns(String moduleName, String imageFrom,
						   String StringStream, String photoname, String sid, String UUID) throws Exception {

		String targetDirectory = "";
		String targetFileName = "";
		String fullPath = "";
		// 文件路径的分隔符

		String sep = File.separator;
		// 保存交易图片
		targetFileName = System.currentTimeMillis()
				+ RandomStringUtils.randomNumeric(6) + ".jpg";
		targetDirectory = sep + moduleName + sep
				+ new SimpleDateFormat("yyyyMMdd").format(new Date()) + sep;
		File uploadFile = new File(Constants.INS_IMAGE_PATH + targetDirectory);
		if (!uploadFile.exists()) {
			uploadFile.mkdirs();
		}

		OutputStream os = null;

		fullPath = Constants.INS_IMAGE_PATH + targetDirectory + sep + targetFileName;

		os = new FileOutputStream(new File(fullPath));
		byte[] buffer = new BASE64Decoder().decodeBuffer(StringStream);
		os.write(buffer);
		os.flush();
		os.close();
		String imagepath = Constants.INS_IMAGE_PATH + targetDirectory;

		Image image = new Image();
		image.setUuid(UUID);
		image.setImageName(targetFileName);
		image.setImagePath(imagepath);
		image.setModuleName(moduleName);
		image.setCreateDate(new Date());
		image.setUpdateDate(new Date());
		image.setImageFrom(imageFrom);
		imageMapper.insertInsSelective(image);
	}
}
