package com.uns.dao;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.MtImagePos;
@Repository
public interface MtImagePosMapper extends BaseMapper<MtImagePos>{

    int deleteByPrimaryKey(BigDecimal id);


    int insert(MtImagePos record);


    int insertSelective(MtImagePos record);


    MtImagePos selectByPrimaryKey(BigDecimal id);


    int updateByPrimaryKeySelective(MtImagePos record);

 
    int updateByPrimaryKey(MtImagePos record);


	List getImageByTranId(String tranId);
}