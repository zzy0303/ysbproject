package com.uns.common.exception;

import org.springframework.context.MessageSource;

/**
 * 业务异常类
 * @author Administrator
 *
 */
public class BusinessException extends Exception {

	private static final long serialVersionUID = -2361064565644612496L;

	private String errCode;

	public String getErrCode() {
		return errCode;
	}

	private String errMessage;
	
	private String[] params;
	

	public BusinessException(String message) {
		super(message);
	}

	/**
	 * 以枚举的name作为错误码者
	 * @param enumCode
	 */
	public BusinessException(Enum enumCode) {
		this.errCode = enumCode.name();
	}
	
	/**
	 * 以枚举的参数作为错误码者
	 * @param errEnum
	 */
	public BusinessException(ExceptionDefine errEnum){
		this.errCode = errEnum.getErrorCode();
	}
	
	public BusinessException(ExceptionDefine errEnum,String ... ps){
		this.errCode = errEnum.getErrorCode();
		this.params = ps;
	}
	public BusinessException(String code, String message) {
		this.errCode = code;
		this.errMessage = message;
	}

	/**
	 * 业务异常类不直接操作资源文件
	 * @param messageSource
	 * @return
	 */
	public String getErrMessage(MessageSource messageSource){
		return messageSource.getMessage(this.errCode, this.params, null);
	}

}

