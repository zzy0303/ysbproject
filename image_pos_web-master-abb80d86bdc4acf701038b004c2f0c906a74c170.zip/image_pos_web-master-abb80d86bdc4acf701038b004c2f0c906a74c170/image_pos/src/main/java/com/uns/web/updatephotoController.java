package com.uns.web;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uns.util.AesEncrypt;
import net.sf.json.JSONObject;

import oracle.jdbc.driver.Const;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.service.ImageInterfaceService;
import com.uns.util.HttpClientUtils;

@Controller
public class updatephotoController extends BaseController {

	@Autowired
	private ImageInterfaceService imageInterfaceService;

	/**
	 * @param request
	 * @param response
	 * @throws Exception
	 *             APP证件照上传 修改保存照片
	 */
	@RequestMapping({ "/updatephoto" })
	public void updatephoto(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Map hashMap = new HashMap();
		Map hashmap = new HashMap();
		String identityId = AesEncrypt.decryptAES(request.getParameter("identityId"), Constants.APP_AES_KEY);

		String p1 = request.getParameter("handIdentityCardPhoto") == null ? null	: request.getParameter("handIdentityCardPhoto");
		String p2 = request.getParameter("frontIdentityCardPhoto") == null ? null	: request.getParameter("frontIdentityCardPhoto");
		String p3 = request.getParameter("reverseIdentityCardPhoto") == null ? null: request.getParameter("reverseIdentityCardPhoto");
		String p4 = request.getParameter("storePhoto") == null ? null : request.getParameter("storePhoto");
		String p5 = request.getParameter("licensePhoto") == null ? null : request.getParameter("licensePhoto");// 企业执照
		String p6 = request.getParameter("instorePhoto") == null ? null : request.getParameter("instorePhoto");
		//String p7 = request.getParameter("checkstandPhoto") == null ? "": request.getParameter("checkstandPhoto");
		String p8 = request.getParameter("signaturePhoto") == null ? null: request.getParameter("signaturePhoto");
		String p9 = request.getParameter("creditCardPhoto") == null ? null: request.getParameter("creditCardPhoto");
		String p10 = request.getParameter("settlementCardPhoto") == null ? null: request.getParameter("settlementCardPhoto");
		
		String p11 = request.getParameter("fixPhoto") == null ? null: request.getParameter("fixPhoto");
		String p12=request.getParameter("livingbodyFacePhoto")== null ? null: request.getParameter("livingbodyFacePhoto");//活体人脸正面
		String p13=request.getParameter("livingbodyLeftPhoto")== null ? null: request.getParameter("livingbodyLeftPhoto");//活体人脸左转
		String p14=request.getParameter("livingbodyReturnPhoto")== null ? null: request.getParameter("livingbodyReturnPhoto");//活体人脸回正
		String p15=request.getParameter("livingbodyRightPhoto")== null ? null: request.getParameter("livingbodyRightPhoto");//活体人脸右转
		String p16=request.getParameter("idCardHeadPhoto")== null ? null: request.getParameter("idCardHeadPhoto");//身份证头像照
		log.info("修改图片 photoid:"  + "手持：" + p1 + "正面：" + p2
				+ "反面：" + p3 + "门店：" + p4 + "执照：" + p5 + "门店内：" + p6 +  "签名：" + p8 + "信用卡：" + p9 + "结算卡：" + p10
				+"固码照片："+p11+"活体人脸正面"+p12+"活体人脸左转"+p13+"活体人脸回正"+p14+"活体人脸右转"+p15+"身份证头像照"+p16);
		if (identityId != null) {
           
            	Map handIdentity = p1 == null ? null : imageInterfaceService.updateImage("small_agent",	"small", p1, "handIdentityCardPhoto", identityId);
    			Map frontIdentity = p2 == null ? null : imageInterfaceService.updateImage("small_agent", "small", p2, "frontIdentityCardPhoto",	identityId);
    			Map reverseIdentity = p3 == null ? null : imageInterfaceService.updateImage("small_agent", "small", p3, "reverseIdentityCardPhoto",identityId);
    			Map storePhoto = p4 == null ? null : imageInterfaceService.updateImage("small_agent","small", p4, "storePhoto", identityId);
    			Map instorePhoto = p6 == null ? null : imageInterfaceService.updateImage("small_agent","small", p6, "instorePhoto", identityId);
    			//Map checkstandPhoto = imageInterfaceService.updateImage("small_agent", "small", p7, "checkstandPhoto", photoid);
    			Map licensePhoto = p5 == null ? null : imageInterfaceService.updateImage("small_agent","small", p5, "licensePhoto", identityId);
    			Map signaturePhoto = p8 == null ? null : imageInterfaceService.updateImage("small_agent", "small", p8, "signaturePhoto", identityId);
    			Map creditCardPhoto = p9 == null ? null : imageInterfaceService.updateImage("small_agent", "small", p9, "creditCardPhoto", identityId);
    			Map settlementCardPhoto = p10 == null ? null : imageInterfaceService.updateImage("small_agent", "small", p10,"settlementCardPhoto", identityId);
    			Map fixPhoto = p11 == null ? null : imageInterfaceService.updateImage("small_agent", "small", p11,"fixPhoto", identityId);
    			
    			//saveAppImage方法上传图片到服务器并返回图片的信息(targetFileName、imagepath、moduleName、imageFrom、sid、photoname)
    			Map livingbodyFacePhoto = p12==null?null:imageInterfaceService.saveAppImage("small_agent", "livingBody", p12,"livingbodyFacePhoto",identityId);//活体人脸正面
				Map livingbodyLeftPhoto = p13==null?null:imageInterfaceService.saveAppImage("small_agent", "livingBody", p13,"livingbodyLeftPhoto",identityId);//活体人脸左转
				Map livingbodyReturnPhoto = p14==null?null:imageInterfaceService.saveAppImage("small_agent", "livingBody", p14,"livingbodyReturnPhoto",identityId);//活体人脸回正
				Map livingbodyRightPhoto = p15==null?null:imageInterfaceService.saveAppImage("small_agent", "livingBody", p15,"livingbodyRightPhoto",identityId);//活体人脸右转
				Map idCardHeadPhoto = p16==null?null:imageInterfaceService.saveAppImage("small_agent", "small", p16,"idCardHeadPhoto",identityId);//身份证大头贴
				
    			hashmap.put("handIdentity", JSONObject.fromObject(handIdentity));
    			hashmap.put("frontIdentity", JSONObject.fromObject(frontIdentity));
    			hashmap.put("reverseIdentity",JSONObject.fromObject(reverseIdentity));
    			hashmap.put("storePhoto", JSONObject.fromObject(storePhoto));
    			hashmap.put("creditCardPhoto",JSONObject.fromObject(creditCardPhoto));// 信用卡
    			//hashmap.put("checkstandPhoto",JSONObject.fromObject(checkstandPhoto));
    			hashmap.put("settlementCardPhoto",JSONObject.fromObject(settlementCardPhoto));// 结算银行卡
    			hashmap.put("signaturePhoto", JSONObject.fromObject(signaturePhoto));
    			hashmap.put("licensePhoto", JSONObject.fromObject(licensePhoto));
    			hashmap.put("instorePhoto", JSONObject.fromObject(instorePhoto));
    			hashmap.put("fixPhoto", JSONObject.fromObject(fixPhoto));
    			
    			hashmap.put("livingBodyFacePhoto", JSONObject.fromObject(livingbodyFacePhoto));   //活体人脸正面
				hashmap.put("livingBodyLeftPhoto", JSONObject.fromObject(livingbodyLeftPhoto));   //活体人脸左转
				hashmap.put("livingBodyReturnPhoto", JSONObject.fromObject(livingbodyReturnPhoto));   //活体人脸回正
				hashmap.put("livingBodyRightPhoto", JSONObject.fromObject(livingbodyRightPhoto));   //活体人脸右转
				hashmap.put("idCardHeadPhoto", JSONObject.fromObject(idCardHeadPhoto));   //身份证头像照
    			
    			hashmap.put("identityId",AesEncrypt.encryptAES(identityId, Constants.APP_AES_KEY));
				hashmap.put("version", Constants.VERSION_2_3_0);

    			Map resultMap = HttpClientUtils.postRequestMap(Constants.UPDATEIMAGE, hashmap, Map.class);
    			response.setContentType("UTF-8");
    			JSONObject json = JSONObject.fromObject(resultMap);
    			log.info("照片上传结果:" + json.toString());
    			response.getWriter().write(json.toString());

		} else {
			hashMap.put("returnCode", "2222");
			hashMap.put("msg", "商户类型为空");
			response.setContentType("UTF-8");
			JSONObject json = JSONObject.fromObject(hashMap);
			log.info("结果:" + json.toString());
			response.getWriter().write(json.toString());
		}
	}

}
