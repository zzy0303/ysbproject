package com.uns.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

public class AesEncrypt {

	private static String hexStr = "0123456789ABCDEF";

	private static final Logger log = LoggerFactory.getLogger(AesEncrypt.class);

	private static final String IV_STRING = "0000000000000000";

	/**
	 * 同步IOS加密算法
	 * @param content
	 * @param key
	 * @return
	 * @throws InvalidKeyException
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchPaddingException
	 * @throws UnsupportedEncodingException
	 * @throws InvalidAlgorithmParameterException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 */
	public static String encryptAES(String content, String key) {
		try {
			byte[] byteContent = content.getBytes("UTF-8");
			// 注意，为了能与 iOS 统一
			// 这里的 key 不可以使用 KeyGenerator、SecureRandom、SecretKey 生成
			byte[] enCodeFormat = key.getBytes();
			SecretKeySpec secretKeySpec = new SecretKeySpec(enCodeFormat, "AES");
			byte[] initParam = IV_STRING.getBytes();
			IvParameterSpec ivParameterSpec = new IvParameterSpec(initParam);
			// 指定加密的算法、工作模式和填充方式
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, ivParameterSpec);
			byte[] encryptedBytes = cipher.doFinal(byteContent);
			// 同样对加密后数据进行 base64 编码
			return BinaryToHexString(encryptedBytes);
		} catch (Exception e){
			e.printStackTrace();
			log.info("解密失败");
		}
		return null;
	}

	/**
	 * 同步IOS解密算法
	 * @param content
	 * @param key
	 * @return
	 * @throws InvalidKeyException
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchPaddingException
	 * @throws InvalidAlgorithmParameterException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 * @throws UnsupportedEncodingException
	 */
	public static String decryptAES(String content, String key) {
		try {
			// base64 解码
			byte[] encryptedBytes = HexStringToBinary(content);
			byte[] enCodeFormat = key.getBytes();
			SecretKeySpec secretKey = new SecretKeySpec(enCodeFormat, "AES");
			byte[] initParam = IV_STRING.getBytes();
			IvParameterSpec ivParameterSpec = new IvParameterSpec(initParam);
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE, secretKey, ivParameterSpec);
			byte[] result = cipher.doFinal(encryptedBytes);
			return new String(result, "UTF-8");
		}catch (Exception e){
			e.printStackTrace();
			log.info("解密失败");
		}
		return null;
	}

	/**
	 * 加密
	 *
	 * @param content
	 *            需要加密的内容
	 * @return
	 */
	public static String encrypt(String content, String privateKey) {
		try {
			KeyGenerator kgen = KeyGenerator.getInstance("AES");
			SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
			secureRandom.setSeed(privateKey.getBytes());

			kgen.init(128, secureRandom);
			SecretKey secretKey = kgen.generateKey();
			byte[] enCodeFormat = secretKey.getEncoded();
			SecretKeySpec key = new SecretKeySpec(enCodeFormat, "AES");
			Cipher cipher = Cipher.getInstance("AES");// 创建密码器
			byte[] byteContent = content.getBytes("utf-8");
			cipher.init(Cipher.ENCRYPT_MODE, key);// 初始化
			byte[] result = cipher.doFinal(byteContent);
			String strResult = BinaryToHexString(result);
			return strResult; // 加密
		} catch (NoSuchAlgorithmException e) {
			log.error("Invalid Algorith.");
			// e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			log.error(e.getMessage(), e);
		} catch (InvalidKeyException e) {
			log.error(e.getMessage(), e);
		} catch (UnsupportedEncodingException e) {
			log.error(e.getMessage(), e);
		} catch (IllegalBlockSizeException e) {
			log.error(e.getMessage(), e);
		} catch (BadPaddingException e) {
			log.error(e.getMessage(), e);
		}
		return null;
	}

	/**
	 * 解密
	 * 
	 * @param content
	 *            待解密内容
	 * @return
	 */
	public static String decrypt(String content, String privateKey) {
		try {
			KeyGenerator kgen = KeyGenerator.getInstance("AES");
			SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
			secureRandom.setSeed(privateKey.getBytes());
			kgen.init(128, secureRandom);
			SecretKey secretKey = kgen.generateKey();
			byte[] enCodeFormat = secretKey.getEncoded();
			SecretKeySpec key = new SecretKeySpec(enCodeFormat, "AES");
			Cipher cipher = Cipher.getInstance("AES");// 创建密码器
			cipher.init(Cipher.DECRYPT_MODE, key);// 初始化
			byte[] byteContent = HexStringToBinary(content);

			byte[] result = cipher.doFinal(byteContent);
			return new String(result); // 加密
		} catch (NoSuchAlgorithmException e) {
			log.error("Invalid Algorith.");
			// e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			log.error("Invalid Padding.");
		} catch (InvalidKeyException e) {
			log.error("Invalid key.");
		} catch (IllegalBlockSizeException e) {
			log.error("Illegal Block Size.");
		} catch (BadPaddingException e) {
			e.printStackTrace();
			log.error("bad  Paddin.");
		}
		return null;
	}

	/**
	 * 
	 * @param bytes
	 * @return 将二进制转换为十六进制字符输出
	 */
	public static String BinaryToHexString(byte[] bytes) {

		StringBuilder result = new StringBuilder();
		StringBuilder hex = new StringBuilder();
		for (int i = 0; i < bytes.length; i++) {
			hex.delete(0, hex.length());
			// 字节高4位
			hex.append(String.valueOf(hexStr.charAt((bytes[i] & 0xF0) >> 4)));
			// 字节低4位
			hex.append(String.valueOf(hexStr.charAt(bytes[i] & 0x0F)));
			result.append(hex);

		}
		return result.toString();
	}

	/**
	 * 
	 * @param hexString
	 * @return 将十六进制转换为字节数组
	 */
	public static byte[] HexStringToBinary(String hexString) {
		// hexString的长度对2取整，作为bytes的长度
		int len = hexString.length() / 2;
		byte[] bytes = new byte[len];
		byte high = 0;// 字节高四位
		byte low = 0;// 字节低四位

		for (int i = 0; i < len; i++) {
			// 右移四位得到高位
			high = (byte) ((hexStr.indexOf(hexString.charAt(2 * i))) << 4);
			low = (byte) hexStr.indexOf(hexString.charAt(2 * i + 1));
			bytes[i] = (byte) (high | low);// 高地位做或运算
		}
		return bytes;
	}

	public static void main(String[] args){

//		System.out.println(decryptAES("AF7861A4884EBC51DC80073EEE0F664E","9513624781236547"));
		System.out.println(encryptAES("320722197910180016","9513624781236547"));
	}
	
}
