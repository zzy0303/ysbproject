package com.uns.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;
import org.eclipse.jetty.util.log.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sun.misc.BASE64Decoder;
import sun.util.logging.resources.logging;

import com.uns.common.Base64;
import com.uns.common.Constants;
import com.uns.dao.MtImagePosMapper;
import com.uns.model.MtImagePos;
import com.uns.util.HttpClientUtils;
import common.Logger;

@Service 
public class ImageService {

	@Autowired
	private MtImagePosMapper mtImagePosMapper;
	
	
	/**
	 * 1.上传交易图片
	 * 2.保存交易数据，经纬度
	 * @param request
	 * @param input
	 * @throws IOException 
	 */
	public String saveTranImage(HttpServletRequest request) throws Exception {
		
		String targetDirectory = "";
		String targetFileName = "";
		String fullPath = "";
		//文件路径的分隔符
		
		String sep = File.separator;
		//保存交易图片
		targetFileName = System.currentTimeMillis()+RandomStringUtils.randomNumeric(6)+".jpg";
//		targetDirectory="D:"+sep+"image"+sep+new SimpleDateFormat("yyyyMMdd").format(new Date());
		targetDirectory=Constants.PATH+sep+new SimpleDateFormat("yyyyMMdd").format(new Date());
		File uploadFile = new File(targetDirectory);
		if (!uploadFile.exists()) {
			uploadFile.mkdirs();
		}
		
		OutputStream os = null;
		
		fullPath = targetDirectory + sep + targetFileName;
		
		os = new FileOutputStream(new File(fullPath));
		String tranStream=request.getParameter("tranStream");
		byte[] buffer =Base64.decode(tranStream);
		os.write(buffer);
		os.flush();
		os.close();
		
		Map paramsMap=new HashMap();
		paramsMap.put("tran_id", request.getParameter("tran_id"));
		
		paramsMap.put("tran_num",request.getParameter("tran_num"));
		paramsMap.put("tran_date",request.getParameter("tran_date"));
		paramsMap.put("tran_time",request.getParameter("tran_time"));
		paramsMap.put("tran_type",request.getParameter("tran_type"));
		paramsMap.put("tran_flag",request.getParameter("tran_flag"));
		paramsMap.put("merchant_no",request.getParameter("merchant_no"));
		paramsMap.put("termianl_no",request.getParameter("termianl_no"));
		paramsMap.put("image_name",targetFileName);
		paramsMap.put("image_url",targetDirectory+sep);
		paramsMap.put("batchNumber",request.getParameter("batchNumber"));
		paramsMap.put("posTraceNo",request.getParameter("posTraceNo"));
		
		//添加经纬度坐标
		paramsMap.put("longitude",request.getParameter("longitude"));
		paramsMap.put("latitude",request.getParameter("latitude"));
		paramsMap.put("version", request.getParameter("version"));
		
		
		System.out.println("image充值接口"+new Date()+"-->:"+Constants.CFM_CHARGE+paramsMap.toString());
		Map resultMap=HttpClientUtils.postRequestMap(Constants.CFM_CHARGE,paramsMap,Map.class);
		System.out.println("image返回结果"+new Date()+"-->:"+resultMap);
		
		//图片相关信息数据库保存
	/*	MtImagePos image = new MtImagePos();
		
		image.setTranId(request.getParameter("tran_id"));
		image.setTranNo(request.getParameter("tran_num"));
		image.setTranDate(request.getParameter("tran_date"));
		image.setTranTime(request.getParameter("tran_time"));
		image.setTranType(request.getParameter("tran_type"));
		image.setTranFlag(request.getParameter("tran_flag"));
		image.setMerchantNo(request.getParameter("merchant_no"));
		image.setTerminalNo(request.getParameter("termianl_no"));
		image.setCreateDate(new Date());
		image.setUpdateDate(new Date());
		image.setImageName(targetFileName);
		image.setImageUrl(targetDirectory+sep);
		//添加经纬度坐标
		image.setLongitude(request.getParameter("longitude"));
		image.setLatitude(request.getParameter("latitude"));
		//保存消费者图片
		savePersonImage(request,targetDirectory);
		
		mtImagePosMapper.insertSelective(image);
		
		MtImagePos images=this.getImageByTranId(request.getParameter("tran_id"));
		if(images!=null){
			return images.getTranId();
		}*/
		return resultMap.toString();
	}
	

	/**保存消费者图片
	 * @param request
	 * @param targetDirectory
	 * @throws Exception
	 */
	private void savePersonImage(HttpServletRequest request, String targetDirectory) throws Exception {
		String sep = File.separator;
		String personImageStream=request.getParameter("personImageStream");
		if(StringUtils.isNotEmpty(personImageStream)){
			//保存交易人图像
			String fileName="";
			String basePath="";
			String path="";
			
			fileName=System.currentTimeMillis()+RandomStringUtils.randomNumeric(6)+".jpg";
			targetDirectory=Constants.PATH+sep+new SimpleDateFormat("yyyyMMdd").format(new Date())+sep+Constants.PERSON_PATH;
			path=basePath+sep+fileName;
			
			File uploadFile2 = new File(basePath);
			if (!uploadFile2.exists()) {
				uploadFile2.mkdirs();
			}
			
			OutputStream os2 = null;
			
			os2 = new FileOutputStream(new File(path));
			byte[] buffer1 =Base64.decode(personImageStream);
			os2.write(buffer1);
			os2.flush();
			os2.close();
			MtImagePos images=this.getImageByTranId(request.getParameter("tran_id"));
			if(images!=null){
				//保存交易人的图像
				images.setpImageName(fileName);
				images.setpImageUrl(basePath);
				mtImagePosMapper.updateByPrimaryKeySelective(images);
			}
			
		}
		
		
	}


	/**根据交易id查询
	 * @param tranId
	 * @return
	 */
	private MtImagePos getImageByTranId(String tranId) {
		List list=mtImagePosMapper.getImageByTranId(tranId);
		MtImagePos mtImagePos=null;
		if(list!=null){
			mtImagePos=(MtImagePos)list.get(0);
		}
		return mtImagePos;
	}


	/**
	 * @param request
	 * @return
	 * @throws Exception
	 */
	public Map saveTranImageIso200(HttpServletRequest request) throws Exception {
		String targetDirectory = "";
		String targetFileName = "";
		String fullPath = "";
		//文件路径的分隔符
		
		String sep = File.separator;
		//保存交易图片
		targetFileName = System.currentTimeMillis()+RandomStringUtils.randomNumeric(6)+".jpg";
//		targetDirectory="D:"+sep+"image"+sep+new SimpleDateFormat("yyyyMMdd").format(new Date());
		targetDirectory=Constants.PATH+sep+new SimpleDateFormat("yyyyMMdd").format(new Date());
		File uploadFile = new File(targetDirectory);
		if (!uploadFile.exists()) {
			uploadFile.mkdirs();
		}
		
		OutputStream os = null;
		
		fullPath = targetDirectory + sep + targetFileName;
		
		os = new FileOutputStream(new File(fullPath));
		String tranStream=request.getParameter("tranStream");
//		byte[] buffer =Base64.decode(tranStream);
		byte[] buffer = new BASE64Decoder().decodeBuffer(tranStream);
		os.write(buffer);
		os.flush();
		os.close();
		
		Map paramsMap=new HashMap();
		paramsMap.put("batch_number", request.getParameter("batch_number"));//批次号
		paramsMap.put("pos_traceno", request.getParameter("pos_traceno"));//pos流水号
		paramsMap.put("merchant_no",request.getParameter("merchant_no"));//大商户号
		paramsMap.put("termianl_no",request.getParameter("termianl_no"));//终端号
		paramsMap.put("tran_date",request.getParameter("tran_date"));//交易日期
		paramsMap.put("tran_time",request.getParameter("tran_time"));//交易时间
		paramsMap.put("image_name",targetFileName);//图片名称
		paramsMap.put("image_url",targetDirectory+sep);//图片路径
		paramsMap.put("version", request.getParameter("version"));//版本号
		paramsMap.put("type", request.getParameter("type"));//版本类型
		paramsMap.put("currentLocation", URLEncoder.encode(request.getParameter("currentLocation"),"UTF-8"));//当前位置
		
		System.out.println("imageISO上传图片"+new Date()+"-->:"+Constants.CFM_CHARGE+paramsMap.toString());
		Map resultMap=HttpClientUtils.postRequestMap(Constants.CFM_CHARGE,paramsMap,Map.class);
		System.out.println("image返回结果"+new Date()+"-->:"+resultMap);
		return resultMap;
	}


	/**
	 * @param request
	 * @return
	 * @throws Exception
	 */
	public Map saveTranImageAndroid200(HttpServletRequest request) throws Exception {
		String targetDirectory = "";
		String targetFileName = "";
		String fullPath = "";
		//文件路径的分隔符
		
		String sep = File.separator;
		//保存交易图片
		targetFileName = System.currentTimeMillis()+RandomStringUtils.randomNumeric(6)+".jpg";
//		targetDirectory="D:"+sep+"image"+sep+new SimpleDateFormat("yyyyMMdd").format(new Date());
		targetDirectory=Constants.PATH+sep+new SimpleDateFormat("yyyyMMdd").format(new Date());
		File uploadFile = new File(targetDirectory);
		if (!uploadFile.exists()) {
			uploadFile.mkdirs();
		}
		
		OutputStream os = null;
		
		fullPath = targetDirectory + sep + targetFileName;
		
		os = new FileOutputStream(new File(fullPath));
		String tranStream=request.getParameter("tranStream");
		byte[] buffer = new BASE64Decoder().decodeBuffer(tranStream);
//		byte[] buffer =Base64.decode(tranStream);
		os.write(buffer);
		os.flush();
		os.close();
		
		Map paramsMap=new HashMap();
		//paramsMap.put("merchant_name", request.getParameter("merchant_name"));//商户名
		//paramsMap.put("shopperbiid", request.getParameter("shopperbiid"));//商户号
		//paramsMap.put("device_number", request.getParameter("device_number"));//设备号
		
		
		paramsMap.put("batch_number", request.getParameter("batch_number"));//批次号
		paramsMap.put("pos_traceno", request.getParameter("pos_traceno"));//pos流水号
		paramsMap.put("merchant_no",request.getParameter("merchant_no"));//大商户号
		paramsMap.put("termianl_no",request.getParameter("termianl_no"));//终端号
		paramsMap.put("tran_date",request.getParameter("tran_date"));//交易日期
		paramsMap.put("tran_time",request.getParameter("tran_time"));//交易时间
		paramsMap.put("version", request.getParameter("version"));//版本号
		paramsMap.put("type", request.getParameter("type"));//版本类型
		paramsMap.put("currentLocation", URLEncoder.encode(request.getParameter("currentLocation"),"UTF-8"));//当前位置
		
		paramsMap.put("image_name",targetFileName);//图片名称
		paramsMap.put("image_url",targetDirectory+sep);//图片路径
		
		
		System.out.println("imageAndroid上传图片"+new Date()+"-->:"+Constants.CFM_CHARGE+paramsMap.toString());
		Map resultMap=HttpClientUtils.postRequestMap(Constants.CFM_CHARGE,paramsMap,Map.class);
		System.out.println("image返回结果"+new Date()+"-->:"+resultMap);
		
		return resultMap;
	}


	/**
	 * @param request
	 * @return
	 * @throws Exception
	 */
	public Map saveTranCardImageAndroid200(HttpServletRequest request) throws Exception {
		String targetDirectory = "";
		String targetFileName = "";
		String fullPath = "";
		//文件路径的分隔符
		
		String sep = File.separator;
		//保存交易图片
		targetFileName = System.currentTimeMillis()+RandomStringUtils.randomNumeric(6)+".jpg";
//		targetDirectory="D:"+sep+"image"+sep+new SimpleDateFormat("yyyyMMdd").format(new Date());
		targetDirectory=Constants.CARD_PATH+sep+new SimpleDateFormat("yyyyMMdd").format(new Date());
		File uploadFile = new File(targetDirectory);
		if (!uploadFile.exists()) {
			uploadFile.mkdirs();
		}
		
		OutputStream os = null;
		
		fullPath = targetDirectory + sep + targetFileName;
		
		os = new FileOutputStream(new File(fullPath));
		String tranCardStream=request.getParameter("tranCardStream");
		
//		byte[] buffer =Base64.decode(tranCardStream);
		byte[] buffer = new BASE64Decoder().decodeBuffer(tranCardStream);
		os.write(buffer);
		os.flush();
		os.close();

		
		Map paramsMap=new HashMap();
		
		paramsMap.put("batch_number", request.getParameter("batch_number"));//批次号
		paramsMap.put("pos_traceno", request.getParameter("pos_traceno"));//pos流水号
		paramsMap.put("merchant_no",request.getParameter("merchant_no"));//大商户号
		paramsMap.put("termianl_no",request.getParameter("termianl_no"));//终端号
		paramsMap.put("version", request.getParameter("version"));//版本号
		paramsMap.put("type", request.getParameter("type"));//版本类型
		
		paramsMap.put("imagecardname",targetFileName);//图片名称
		paramsMap.put("imagecardurl",targetDirectory+sep);//图片路径
		
		
		System.out.println("imageAndroid上传图片"+new Date()+"-->:"+Constants.CARD_IMAGE_URL+paramsMap.toString());
		Map resultMap=HttpClientUtils.postRequestMap(Constants.CARD_IMAGE_URL,paramsMap,Map.class);
		System.out.println("image返回结果"+new Date()+"-->:"+resultMap);
		
		return resultMap;
	}


	/**
	 * @param request
	 * @return
	 * @throws Exception 
	 */
	public Map saveTranCardImageIso200(HttpServletRequest request) throws Exception {
		String targetDirectory = "";
		String targetFileName = "";
		String fullPath = "";
		//文件路径的分隔符
		
		String sep = File.separator;
		//保存交易图片
		targetFileName = System.currentTimeMillis()+RandomStringUtils.randomNumeric(6)+".jpg";
//		targetDirectory="D:"+sep+"image"+sep+new SimpleDateFormat("yyyyMMdd").format(new Date());
		targetDirectory=Constants.CARD_PATH+sep+new SimpleDateFormat("yyyyMMdd").format(new Date());
		File uploadFile = new File(targetDirectory);
		if (!uploadFile.exists()) {
			uploadFile.mkdirs();
		}
		
		OutputStream os = null;
		
		fullPath = targetDirectory + sep + targetFileName;
		
		os = new FileOutputStream(new File(fullPath));
		String tranCardStream=request.getParameter("tranCardStream");
		byte[] buffer = new BASE64Decoder().decodeBuffer(tranCardStream);
//		byte[] buffer =Base64.decode(tranCardStream);
		os.write(buffer);
		os.flush();
		os.close();
		
		Map paramsMap=new HashMap();
		
		paramsMap.put("batch_number", request.getParameter("batch_number"));//批次号
		paramsMap.put("pos_traceno", request.getParameter("pos_traceno"));//pos流水号
		paramsMap.put("merchant_no",request.getParameter("merchant_no"));//大商户号
		paramsMap.put("termianl_no",request.getParameter("termianl_no"));//终端号
		paramsMap.put("version", request.getParameter("version"));//版本号
		paramsMap.put("type", request.getParameter("type"));//版本类型
		
		paramsMap.put("imagecardname",targetFileName);//图片名称
		paramsMap.put("imagecardurl",targetDirectory+sep);//图片路径
		
		
		System.out.println("imageIso上传图片"+new Date()+"-->:"+Constants.CARD_IMAGE_URL+paramsMap.toString());
		Map resultMap=HttpClientUtils.postRequestMap(Constants.CARD_IMAGE_URL,paramsMap,Map.class);
		System.out.println("image返回结果"+new Date()+"-->:"+resultMap);
		
		return resultMap;
	}

}
