package com.uns.web;

import com.uns.model.InsImageModel;
import com.uns.service.ImageInterfaceService;
import com.uns.util.HttpClientUtils;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import sun.misc.BASE64Encoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author: KaiFeng
 * @Description: 机构图片接口
 * @Date: 2018/2/28
 * @Modifyed By:
 */
@Controller
public class InsPhotoController extends BaseController {

    private Logger log = LoggerFactory.getLogger(InsPhotoController.class);

    @Autowired
    private ImageInterfaceService imageInterfaceService;

    /**
     * 机构图片上传接口
     * @param request
     * @param response
     */
    @RequestMapping({ "/insPhotoUpload" })
    public void insPhotoUpload(HttpServletRequest request, HttpServletResponse response) throws Exception {
        response.setContentType("UTF-8");
        Map result = new HashMap();
        String faceIdCard = request.getParameter("faceIdCard");
        String backIdCard = request.getParameter("backIdCard");
        String handIdCard = request.getParameter("handIdCard");
        String debitCard = request.getParameter("debitCard");
        String businessLicence = request.getParameter("businessLicence");
        String accountOpenPermit = request.getParameter("accountOpenPermit");
        String faceIdCardUUID = request.getParameter("faceIdCardUUID");
        String backIdCardUUID = request.getParameter("backIdCardUUID");
        String handIdCardUUID = request.getParameter("handIdCardUUID");
        String debitCardUUID = request.getParameter("debitCardUUID");
        String businessLicenceUUID = request.getParameter("businessLicenceUUID");
        String accountOpenPermitUUID = request.getParameter("accountOpenPermitUUID");
        String idCard = request.getParameter("idCard");
        String moduleName = "organization_services_web";
        String imageFrom = "organization_services_web";
        try {
            if (StringUtils.isNotEmpty(faceIdCard)){
                imageInterfaceService.updateImageIns(moduleName, imageFrom, faceIdCard, "faceIdCard", idCard, faceIdCardUUID);
            }
            if (StringUtils.isNotEmpty(backIdCard)){
                imageInterfaceService.updateImageIns(moduleName, imageFrom, backIdCard, "backIdCard", idCard, backIdCardUUID);
            }
            if (StringUtils.isNotEmpty(handIdCard)){
                imageInterfaceService.updateImageIns(moduleName, imageFrom, handIdCard, "handIdCard", idCard, handIdCardUUID);
            }
            if (StringUtils.isNotEmpty(debitCard)){
                imageInterfaceService.updateImageIns(moduleName, imageFrom, debitCard, "debitCard", idCard, debitCardUUID);
            }
            if (StringUtils.isNotEmpty(businessLicence)){
                imageInterfaceService.updateImageIns(moduleName, imageFrom, businessLicence, "businessLicence", idCard, businessLicenceUUID);
            }
            if (StringUtils.isNotEmpty(accountOpenPermit)){
                imageInterfaceService.updateImageIns(moduleName, imageFrom, accountOpenPermit, "accountOpenPermit", idCard, accountOpenPermitUUID);
            }
            result.put("rspCode", "0000");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("rspCode", "9999");
            result.put("rspMsg", "系统错误");
        }
        log.info("机构上传图片返回信息：{}", com.alibaba.fastjson.JSONObject.toJSON(result));
        JSONObject json = JSONObject.fromObject(result);
        response.getWriter().write(json.toString());
    }

    protected String encodeBase64(InputStream inputStream) throws Exception {
        try {
            byte[] data = new byte[inputStream.available()];
            inputStream.read(data);
            inputStream.close();
            String encodeBase64String = new BASE64Encoder().encode(data);
            return encodeBase64String;
        } finally {
            if (null != inputStream){
                inputStream.close();
            }
        }
    }
}
