package com.uns.dao;

import org.springframework.stereotype.Repository;

import com.uns.model.Image;
@Repository
public interface ImageMapper {


    int deleteByPrimaryKey(byte[] uuid);

    int insert(Image record);

    int insertSelective(Image record);

    Image selectByPrimaryKey(byte[] uuid);


    int updateByPrimaryKeySelective(Image record);

    int updateByPrimaryKey(Image record);

	Image getImageByName(String targetFileName);

    void insertInsSelective(Image image);
}