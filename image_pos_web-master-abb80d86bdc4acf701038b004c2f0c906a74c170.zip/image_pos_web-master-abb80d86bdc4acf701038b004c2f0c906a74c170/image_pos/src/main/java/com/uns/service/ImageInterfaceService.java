package com.uns.service;

import java.io.InputStream;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Component;

@Component
public interface ImageInterfaceService {

	public String saveImage(String moduleName,String path,String imageFrom,InputStream input) throws Exception;

	
	public Map saveAppImage(String moduleName,String imageFrom,String StringStream,String photoname,String sid) throws Exception;
	public Map updateImage(String moduleName,String imageFrom,String StringStream,String photoname,String sid) throws Exception;
	public void updateImageIns(String moduleName,String imageFrom,String StringStream,String photoname,String sid, String UUID) throws Exception;
}
		