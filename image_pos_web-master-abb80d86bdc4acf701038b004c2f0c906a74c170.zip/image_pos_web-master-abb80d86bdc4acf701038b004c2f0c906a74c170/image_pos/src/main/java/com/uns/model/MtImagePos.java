package com.uns.model;

import java.util.Date;

public class MtImagePos {

    private Long id;
    private String tranId;
    private String tranNo;
    private String tranType;
    private String tranFlag;
    private String tranDate;
    private String tranTime;
    private String merchantNo;
    private String terminalNo;
    private Date createDate;
    private Date updateDate;
    private String imageUrl;
    private String imageName;
    private String imageUuid;
    private String pImageUrl;
    private String pImageName;
    private String pImageUuid;
    private String longitude;
    private String latitude;
    
    

    public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public Long getId() {
		return id;
	}
    
	public void setId(Long id) {
		this.id = id;
	}
	
    public String getTranId() {
        return tranId;
    }

    public void setTranId(String tranId) {
        this.tranId = tranId == null ? null : tranId.trim();
    }

    
    public String getTranNo() {
        return tranNo;
    }

   
    public void setTranNo(String tranNo) {
        this.tranNo = tranNo == null ? null : tranNo.trim();
    }

    
    public String getTranType() {
        return tranType;
    }

    
    public void setTranType(String tranType) {
        this.tranType = tranType == null ? null : tranType.trim();
    }

   
    public String getTranFlag() {
        return tranFlag;
    }

    
    public void setTranFlag(String tranFlag) {
        this.tranFlag = tranFlag == null ? null : tranFlag.trim();
    }

    
    public String getTranDate() {
        return tranDate;
    }

    
    public void setTranDate(String tranDate) {
        this.tranDate = tranDate == null ? null : tranDate.trim();
    }

    
    public String getTranTime() {
        return tranTime;
    }

    
    public void setTranTime(String tranTime) {
        this.tranTime = tranTime == null ? null : tranTime.trim();
    }

   
    public String getMerchantNo() {
        return merchantNo;
    }

   
    public void setMerchantNo(String merchantNo) {
        this.merchantNo = merchantNo == null ? null : merchantNo.trim();
    }

    
    public String getTerminalNo() {
        return terminalNo;
    }

   
    public void setTerminalNo(String terminalNo) {
        this.terminalNo = terminalNo == null ? null : terminalNo.trim();
    }
    
    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
    
    public Date getUpdateDate() {
        return updateDate;
    }
    
    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
    
    public String getImageUrl() {
        return imageUrl;
    }
   
    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl == null ? null : imageUrl.trim();
    }
   
    public String getImageName() {
        return imageName;
    }
   
    public void setImageName(String imageName) {
        this.imageName = imageName == null ? null : imageName.trim();
    }

	public String getImageUuid() {
		return imageUuid;
	}

	public void setImageUuid(String imageUuid) {
		this.imageUuid = imageUuid;
	}

	public String getpImageUrl() {
		return pImageUrl;
	}

	public void setpImageUrl(String pImageUrl) {
		this.pImageUrl = pImageUrl;
	}

	public String getpImageName() {
		return pImageName;
	}

	public void setpImageName(String pImageName) {
		this.pImageName = pImageName;
	}

	public String getpImageUuid() {
		return pImageUuid;
	}

	public void setpImageUuid(String pImageUuid) {
		this.pImageUuid = pImageUuid;
	}
    
	
	
}