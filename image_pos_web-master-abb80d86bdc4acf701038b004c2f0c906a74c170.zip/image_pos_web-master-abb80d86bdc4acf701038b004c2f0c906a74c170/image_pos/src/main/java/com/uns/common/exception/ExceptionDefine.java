package com.uns.common.exception;

/**
 * 错误定义可以用中文来定义
 * @author Administrator
 *
 */
public enum ExceptionDefine {

	
	
	;
	
	
	private String errorCode;
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	ExceptionDefine(String errorCode){
		this.errorCode = errorCode;
	}
	
	public String getErrorCode(){
		return this.errorCode;
	}
}
