package com.uns.dao;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.uns.model.B2cShopperbi;
import com.uns.model.B2cShopperbiTemp;
import com.uns.web.form.ShopPerbiForm;
@Repository
public interface B2cShopperbiTempMapper extends BaseMapper<Object>{

    int deleteByPrimaryKey(BigDecimal b2cShopperbiId);

    int insert(B2cShopperbiTemp record);

    int insertSelective(B2cShopperbiTemp record);

    B2cShopperbiTemp selectByPrimaryKey(BigDecimal b2cShopperbiId);

    int updateByPrimaryKey(B2cShopperbiTemp record);

	List<HashMap> ShopPerbiManageList(ShopPerbiForm mbForm);

	B2cShopperbiTemp selectByshopperId(Long b2cShopperbiId);

	void updateByShopperId(B2cShopperbiTemp b2cShopperbi);
	
	void updateBankInfo(B2cShopperbiTemp b2cShopperbi);

	List selectByScompany(String scompany);
	
	List<HashMap> ShopPerbiCheckList(ShopPerbiForm mbForm);
	
	List<HashMap> ShopPerbiPhotoList(ShopPerbiForm mbForm);
	//未审核商户的数量
	String selectCheckCount();
	//未审核商户开户银行的数量
	String selectCheckBkCount();
	//未审核商户终端的数量
	String selectTerminalCount();
	//商户复核,开户,终端信息查询
	List getReCheckList(ShopPerbiForm mbForm);
	//未复核商户信息
	String getReCheckMerchantCount();
	//开户信息带复核数量
	String getBankCount();
	//终端信息复核
	String getTerminalCount();

	List selectByMuserid(String userName);
	
	
	List findbytel(String stel);
	//开户信息
	List<HashMap> shopPerbiBankList(ShopPerbiForm mbForm);
	//终端信息
	List<HashMap> shopPerbiTerminalList(ShopPerbiForm mbForm);
    
	String selectmerchantCount();
	
	//照片复审
     List getReCheck1List(ShopPerbiForm mbForm);
  
     List findbysid(String id);

     void deleteByShopperbiId(B2cShopperbiTemp b2cShopperbiTemp); 
     
     //手续费信息
   
 	List<HashMap> shopPerbiFeeList(ShopPerbiForm mbForm);
 	//未审核商户开户银行的数量
 	String selectCheckFeeCount();
 	
 	//未复审数量
 	String getfeecount();
 	//查看复审信息
 	List<HashMap> reCheckFeeList(ShopPerbiForm mbForm);
    //旧商户二维码信息补全
	void updateOldB2cShopperbiTemp(B2cShopperbi b2cShopperbi);

	void updateQrPayCode(Map map);

	//OCR商户预约信息查询
	List<HashMap> findShopperTempList(ShopPerbiForm form);

	Map findShopperTempDetails(@Param("shopperid")Long shopperid);
	
	Map<String, String> findCheckstatusCount();
	
	List<HashMap> findShopperTempCheckList(ShopPerbiForm mbForm);

	//聚合支付商户用户预约信息
	List<HashMap> findShopperAggTempList(ShopPerbiForm form);

	Map findAggShopperDetails(@Param("shopperid")Long shopperid);

	//聚合支付商户用户状态信息
	List<HashMap> findShopperAggStatusList(ShopPerbiForm form);

	//聚合支付商户更新预约审核状态
	void updateShopperAggTempCheckStatus(B2cShopperbiTemp form);
	//聚合支付商户更新正式审核状态
	void updateShopperAggCheckStatus(B2cShopperbiTemp form);
    //商户修改状态
	void updateShopperAggStatus(Map param);
}