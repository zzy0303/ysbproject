package com.uns.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.model.FunctionInfo;
import com.uns.model.Operator;
import com.uns.model.RoleInfo;
import com.uns.service.RoleService;
import com.uns.util.StringUtils;
import com.uns.web.form.RoleForm;

@Controller("RoleController")
@RequestMapping("/role.htm")
public class RoleController extends BaseController {
	
	
	@Autowired
	private RoleService roleService;
	
	/**去权限列表页面
	 * @param request
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=toRoleManageList")
	public String toRoleManageList(HttpServletRequest request,@ModelAttribute("mb") RoleForm mbForm, ModelMap modelMap) throws BusinessException{
		try {
			List roleManagerList=roleService.selectRoleList(mbForm);
			modelMap.put("rolePageList",roleManagerList );
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.权限列表页面出错);
		}
		return "role/roleList";
	}
	
	/**添加页面
	 * @param request
	 * @param modelMap
	 * @param mbForm
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=roleAdd")
	@FormToken(save=true)
	public String roleAdd(HttpServletRequest request, ModelMap modelMap) throws BusinessException {
		try {
			Operator operator = (Operator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			List listFuncSelect = new ArrayList();
			request.setAttribute("funcSelect", listFuncSelect);
			// 查询返回功能树
			Map map = roleService.findAllFunction();
			request.setAttribute("functionTree", map);
			modelMap.put("operator", operator);
		} catch (NumberFormatException e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.数字格式化错误);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.角色添加页面出错);
		}
		return "role/roleAdd";
	}
	
	/**保存角色权限
	 * @param request
	 * @param modelMap
	 * @param mbForm
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=saveRole")
	@FormToken(remove=true)
	public String saveRole(HttpServletRequest request, ModelMap modelMap,@ModelAttribute("mb") RoleForm mbForm) throws BusinessException {
	    try {
		    RoleInfo roleInfo = new RoleInfo();
			Long operatorId = mbForm.getOperatorId();
			String roleName = mbForm.getRoleName();
			String remark = mbForm.getRemark();
			roleInfo.setRoleName(roleName);
			roleInfo.setRemark(remark);
			roleInfo.setCreateUser(operatorId);
			roleInfo.setCreateDate(new Date());
			roleInfo.setStatus(Long.valueOf(Constants.CON_YES));
			Long[] ids = mbForm.getIds();

			roleService.insert(roleInfo, ids);
			request.setAttribute(Constants.MESSAGE_KEY, "角色添加成功!");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.角色保存方法出错);
		}
		return toRoleManageList(request,null,modelMap);
	}
	/**修改
	 * @param request
	 * @param modelMap
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=updateRole")
	@FormToken(save=true)
	public String updateRole(HttpServletRequest request, ModelMap modelMap,@ModelAttribute("mb") RoleForm mbForm) throws BusinessException {
		try {
			String id = request.getParameter("roleId");
			Operator operator = null;
			RoleInfo roleInfo = null;
			List listFuncSelect = new ArrayList();
			if (org.apache.commons.lang.StringUtils.isNotEmpty(id)) {
				operator = (Operator) request.getSession().getAttribute(
						Constants.SESSION_KEY_USER);
				roleInfo = roleService.selectByRoleId(id);
				List listFunction = new ArrayList(roleService.selectById(id));
				for (Iterator iter = listFunction.iterator(); iter.hasNext();) {
					FunctionInfo func = (FunctionInfo) iter.next();
					listFuncSelect.add(func.getId());
				}
			}
			request.setAttribute("funcSelect", listFuncSelect);

			// 查询返回功能树
			Map map = roleService.findAllFunction();
			request.setAttribute("functionTree", map);
			modelMap.put("operator", operator);
			modelMap.put("roleInfo", roleInfo);
		} catch (NumberFormatException e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.数字格式化错误);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.角色修改页面);
		}
		return "role/roleUpdate";
	}
	
	/**保存修改信息
	 * @param request
	 * @param modelMap
	 * @param mbForm
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=saveUpdateRole")
	@FormToken(remove=true)
	public String saveUpdateRole(HttpServletRequest request, ModelMap modelMap,@ModelAttribute("mb") RoleForm mbForm) throws BusinessException {
		try {
			RoleInfo roleInfo=new RoleInfo();
			Long operatorId=mbForm.getOperatorId();
			Long roleId = mbForm.getRoleId();
			String roleName=mbForm.getRoleName();
			String remark=mbForm.getRemark();
			roleInfo.setId(roleId);
			roleInfo.setRoleName(roleName);
			roleInfo.setRemark(remark);
			roleInfo.setUpdateUser(operatorId);
			roleInfo.setUpdateDate(new Date());
			roleInfo.setStatus(Long.valueOf(Constants.CON_YES));
			Long[] ids=mbForm.getIds();
			roleService.update(roleInfo,ids);
			request.setAttribute(Constants.MESSAGE_KEY,"修改成功!");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.角色修改);
		}
		request.setAttribute("url", "role.htm?method=toRoleManageList");
		return "/returnPage";
	}
	
	/**利用Ajax判断角色名是否已存在
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=ajaxRoleName")
	public String ajaxRoleName(HttpServletRequest request,HttpServletResponse response) throws Exception{
		PrintWriter out = null;
		try {
			String operatorId=request.getParameter("operatorId");
			String roleName = request.getParameter("roleName").trim();
			List<RoleInfo> roleInfoList=null;
			if(!StringUtils.isEmpty(roleName)){
				roleInfoList = roleService.getRoleInfoByName(roleName,
						operatorId);
			}
			boolean isExist = false;
			if(roleInfoList!=null&&roleInfoList.size()>0){
				isExist = true;
			}
			out = response.getWriter();
			out.println("{isExist:"+isExist+"}");
		} catch (IOException e) {
			e.printStackTrace();
			if(out !=null ){
				out.flush();
				out.close();
			}
			throw new BusinessException(ExceptionDefine.验证用户名);
		}finally{
			if(out !=null){
				out.flush();
				out.close();
			}
		}
		return null;
	}
}
