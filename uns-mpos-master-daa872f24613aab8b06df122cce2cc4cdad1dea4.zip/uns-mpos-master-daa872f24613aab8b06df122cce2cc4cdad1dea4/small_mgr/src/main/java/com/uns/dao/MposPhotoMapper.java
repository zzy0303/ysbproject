package com.uns.dao;

import java.math.BigDecimal;

import org.springframework.stereotype.Repository;

import com.uns.model.MposPhoto;
@Repository
public interface MposPhotoMapper {

    int deleteByPrimaryKey(Long photoId);

    int insert(MposPhoto record);

    int insertSelective(MposPhoto record);

    MposPhoto selectByPrimaryKey(Long photoId);

    int updateByPrimaryKeySelective(MposPhoto record);

    int updateByPrimaryKey(MposPhoto record);
}