package com.uns.web.form;

import org.springframework.web.multipart.MultipartFile;

import java.util.Date;

public class SupportBankForm {

    private MultipartFile supportBankFile; //支持银行列表文件

    private String debitCardSupport; //借记卡支持银行

    private String clearingBankNo; //人行清算行号

    private String debitSingleQuota; //借记卡单笔限额（万元）

    private String debitDayQuota; //借记卡单日限额（万元）

    private String creditCardSupport; //贷记卡支持银行

    private String creditClearingBankNo; //贷记卡人行清算行号

    private String creditSingleQuota; //贷记卡单笔限额（万元）

    private String creditDayQuota; //贷记卡单日限额（万元）

    private Date uploadDate; //上传时间

    private String uploadPerson; //上传者

    private String showStatus;  //显示状态

    public String getUploadPerson() {
        return uploadPerson;
    }

    public void setUploadPerson(String uploadPerson) {
        this.uploadPerson = uploadPerson;
    }

    public String getShowStatus() {
        return showStatus;
    }

    public void setShowStatus(String showStatus) {
        this.showStatus = showStatus;
    }

    public MultipartFile getSupportBankFile() {
        return supportBankFile;
    }

    public void setSupportBankFile(MultipartFile supportBankFile) {
        this.supportBankFile = supportBankFile;
    }

    public Date getUploadDate() {
        return uploadDate;
    }

    public void setUploadDate(Date uploadDate) {
        this.uploadDate = uploadDate;
    }

    public String getDebitCardSupport() {
        return debitCardSupport;
    }

    public void setDebitCardSupport(String debitCardSupport) {
        this.debitCardSupport = debitCardSupport;
    }

    public String getClearingBankNo() {
        return clearingBankNo;
    }

    public void setClearingBankNo(String clearingBankNo) {
        this.clearingBankNo = clearingBankNo;
    }

    public String getDebitSingleQuota() {
        return debitSingleQuota;
    }

    public void setDebitSingleQuota(String debitSingleQuota) {
        this.debitSingleQuota = debitSingleQuota;
    }

    public String getDebitDayQuota() {
        return debitDayQuota;
    }

    public void setDebitDayQuota(String debitDayQuota) {
        this.debitDayQuota = debitDayQuota;
    }

    public String getCreditCardSupport() {
        return creditCardSupport;
    }

    public void setCreditCardSupport(String creditCardSupport) {
        this.creditCardSupport = creditCardSupport;
    }

    public String getCreditClearingBankNo() {
        return creditClearingBankNo;
    }

    public void setCreditClearingBankNo(String creditClearingBankNo) {
        this.creditClearingBankNo = creditClearingBankNo;
    }

    public String getCreditSingleQuota() {
        return creditSingleQuota;
    }

    public void setCreditSingleQuota(String creditSingleQuota) {
        this.creditSingleQuota = creditSingleQuota;
    }

    public String getCreditDayQuota() {
        return creditDayQuota;
    }

    public void setCreditDayQuota(String creditDayQuota) {
        this.creditDayQuota = creditDayQuota;
    }
}
