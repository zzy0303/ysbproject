package com.uns.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 固码管理实体
 * @author yang.liu01
 *
 */
public class B2cFixedCode implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long id;
	private String merchantid;//小商户号
	private String qrCodeNo;//二维码编号
	private String tel;//联系电话
	private String scompany;//商户姓名
	private String shopperidP;//所属服务商
	private String parentAgentNo;//一级代理商
	private Date bindingDate;//绑定时间
	private Date storageDate;//入库时间
	private Date createDate;//创建时间
	private Date updateDate; //修改时间
	private String storageUser;//入库人
	private String createUser;//创建人
	private String updateUser;//修改人
	private String status; //状态
	private String agentNo; //代理商编号
	
	private String belongsAgent;
	
	
	//处理时间参数
	private String startDate;
	private String endDate;
	private String startBinDate;
	private String endBinDate;
	private String stringQrcedes;
	private String qrCodeNoBeg;
	private String qrCodeNoEnd;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getMerchantid() {
		return merchantid;
	}
	public void setMerchantid(String merchantid) {
		this.merchantid = merchantid;
	}
	public String getQrCodeNo() {
		return qrCodeNo;
	}
	public void setQrCodeNo(String qrCodeNo) {
		this.qrCodeNo = qrCodeNo;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getScompany() {
		return scompany;
	}
	public void setScompany(String scompany) {
		this.scompany = scompany;
	}
	public String getShopperidP() {
		return shopperidP;
	}
	public void setShopperidP(String shopperidP) {
		this.shopperidP = shopperidP;
	}
	public String getParentAgentNo() {
		return parentAgentNo;
	}
	public void setParentAgentNo(String parentAgentNo) {
		this.parentAgentNo = parentAgentNo;
	}
	public Date getBindingDate() {
		return bindingDate;
	}
	public void setBindingDate(Date bindingDate) {
		this.bindingDate = bindingDate;
	}
	public Date getStorageDate() {
		return storageDate;
	}
	public void setStorageDate(Date storageDate) {
		this.storageDate = storageDate;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public String getStorageUser() {
		return storageUser;
	}
	public void setStorageUser(String storageUser) {
		this.storageUser = storageUser;
	}
	public String getCreateUser() {
		return createUser;
	}
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	public String getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getAgentNo() {
		return agentNo;
	}
	public void setAgentNo(String agentNo) {
		this.agentNo = agentNo;
	}
	
	public String getStringQrcedes() {
		return stringQrcedes;
	}
	public void setStringQrcedes(String stringQrcedes) {
		this.stringQrcedes = stringQrcedes;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getStartBinDate() {
		return startBinDate;
	}
	public void setStartBinDate(String startBinDate) {
		this.startBinDate = startBinDate;
	}
	public String getEndBinDate() {
		return endBinDate;
	}
	public void setEndBinDate(String endBinDate) {
		this.endBinDate = endBinDate;
	}
	public String getBelongsAgent() {
		return belongsAgent;
	}
	public void setBelongsAgent(String belongsAgent) {
		this.belongsAgent = belongsAgent;
	}
	public String getQrCodeNoBeg() {
		return qrCodeNoBeg;
	}
	public void setQrCodeNoBeg(String qrCodeNoBeg) {
		this.qrCodeNoBeg = qrCodeNoBeg;
	}
	public String getQrCodeNoEnd() {
		return qrCodeNoEnd;
	}
	public void setQrCodeNoEnd(String qrCodeNoEnd) {
		this.qrCodeNoEnd = qrCodeNoEnd;
	}
	
	
	
	
	
	
	
}
