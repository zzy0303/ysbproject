package com.uns.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.AgentRatio;
@Repository
public interface AgentRatioMapper extends BaseMapper<Object>{

	List<Map> isRatioTmp(Long shopperid);

	List<Map> isRatio(Long shopperid);

	List<AgentRatio> findAgentRatioTmpByAmid(Map map);

	List<AgentRatio> findAgentRatio(Map map);
	
	
}
