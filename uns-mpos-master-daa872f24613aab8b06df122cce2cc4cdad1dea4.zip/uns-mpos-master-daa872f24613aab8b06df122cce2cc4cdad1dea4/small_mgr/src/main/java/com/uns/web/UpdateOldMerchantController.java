package com.uns.web;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.Global;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.model.B2cShopperbi;
import com.uns.service.ShopPerbiService;
import com.uns.util.DateUtils;
import com.uns.util.HttpClientUtils;

import net.sf.json.JSONObject;

@Controller("UpdateOldMerchant")
@RequestMapping("/UpdateOldMerchant.htm")
public class UpdateOldMerchantController extends BaseController{
	
	@Autowired
	private ShopPerbiService shopPerbiService;
	
/**
 * 旧商户信息更新，扫码
 * @throws Exception 
 */
	
	public static void run(String[] args) throws Exception {
		System.out.println("#####################请求扫码支付注册#######################");
		UpdateOldMerchantController updateOldMerchantController = new UpdateOldMerchantController();
		updateOldMerchantController.shopperbiQR();
		System.out.println("#####################批量请求扫码支付注册完成#######################");
	}
	public static void run2(String[] args) throws Exception {
		System.out.println("#####################补充费率开始#######################");
		UpdateOldMerchantController updateOldMerchantController = new UpdateOldMerchantController();
		updateOldMerchantController.updateFee();
		System.out.println("#####################补充费率结束#######################");
	}
	public void shopperbiQR() throws Exception {
		 
		 //查询b2c_shopperbi的旧商户信息
		 log.info("旧商户更新定时任务");
		 ShopPerbiService shopPerbiService = (ShopPerbiService) Global.getSpringContext().getBean("shopPerbiService");
		 //查询旧商户总数
		 int oldMerchantCount = shopPerbiService.findOldMerchantCount();
		 for (int i = 0; i < oldMerchantCount ; i+=5000) {
			 int startRow = i;
			 int endRow = i+4999; 
			//查询旧商户信息,5000一次
			 List<B2cShopperbi> list = shopPerbiService.findOldMerchant(startRow,endRow);
			 for (B2cShopperbi b2cShopperbi : list) {
				//注册扫码支付
				 String userType;
				 if(Constants.TYPE_0.equals(b2cShopperbi.getMerchantType())){
					 userType = Constants.TYPE_P;
				 }else{
					 userType = Constants.TYPE_C; 
				 }
				 Map map = saveQrPay(b2cShopperbi ,userType ,shopPerbiService);
				 log.info("扫码支付注册返回码"+map.toString());
				 if(Constants.RESPONSE_CODE.equals(map.get("rspCode"))){
					 //注册成功后，获取QRPAYNO和QRPAY_MERCHANT_KEY
					 b2cShopperbi.setQrpayMerchantkey((String) map.get("qrpayMerchantkey"));
					 b2cShopperbi.setQrPayNo((String) map.get("qrPayNo"));
					 //扫码支付激活
					 Map map2 = activateQrPayMerchantPort(b2cShopperbi);
					 if(Constants.RESPONSE_CODE.equals(map2.get("rspCode"))){
						 //更新B2cShopperbi
						 shopPerbiService.updateOldB2cShopperbi(b2cShopperbi);
						 log.info("更新商户信息"+b2cShopperbi.getShopperid());
					 }else{
						 log.info("扫码支付激活失败"+b2cShopperbi.getShopperid());
					 }
				 }else{
					 log.info("扫码支付注册失败"+b2cShopperbi.getShopperid());
				 }
			}
		}
	   }
	 
	 public void updateFee() throws Exception{
		 log.info("旧商户费率定时任务");
		 ShopPerbiService shopPerbiService = (ShopPerbiService) Global.getSpringContext().getBean("shopPerbiService");
		 shopPerbiService.updateFeeProcedure();
	 }
	 
	 /**扫码支付
		 * @param request
		 * @param b2cShopperbi
		 * @param userType
		 * @return 
		 * @throws Exception 
		 */
		private static Map saveQrPay(B2cShopperbi b2cShopperbi, String userType,ShopPerbiService shopPerbiService) throws Exception {
			Map map=new HashMap();
			String flag="";
			JSONObject ob = null;
			String rspCode = "";
			String qrPayNo="";
			// 区分企业还是个人
			Map ysbMap = null;
			if (Constants.TYPE_P.equals(userType)) {
				ysbMap = regQrPayMerchant(b2cShopperbi, userType,shopPerbiService);
			}
			if (Constants.TYPE_C.equals(userType)) {
				ysbMap = regQrPayCompany(b2cShopperbi, userType,shopPerbiService);
			}
			ob = JSONObject.fromObject(ysbMap);
			rspCode = (String) ob.get("rspCode");
			if (Constants.RESPONSE_CODE.equals(rspCode)) {
				qrPayNo = (String) ob.get("userId");
				String qrpayMerchantkey=RandomStringUtils.random(32, "0123456789ABCDEF");
				map.put("qrPayNo", qrPayNo);
				map.put("qrpayMerchantkey", qrpayMerchantkey);
				map.put("rspCode", rspCode);
				return map;
			} else {
				map.put("rspCode", rspCode);
				return map;
			}
			
		}
		
		private static  Map regQrPayMerchant(B2cShopperbi b2cShopperbi, String userType,ShopPerbiService shopPerbiService) throws Exception {

			HashMap params = new HashMap();

			Date dates = new Date();
			String mradom = RandomStringUtils.randomNumeric(6);
			String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom+ b2cShopperbi.getShopperid();
			String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");
			// 基本信息
			String linkName = b2cShopperbi.getName();
			String idCard = b2cShopperbi.getIDNo();
			String tel = b2cShopperbi.getStel();
			String merchantNo = b2cShopperbi.getShopperid() == null ? "": b2cShopperbi.getShopperid().toString();
			Long agentNo = b2cShopperbi.getShopperidP();
			String institutionNo = b2cShopperbi.getOrgNo();
			String platformType = "";
			if (agentNo != null) {
				platformType = Constants.CON_NO;// 0 自有
			} else {
				platformType = Constants.CON_YES;// 机构
			}
			// 结算信息
			String settlementType = b2cShopperbi.getSettlementType();
			String accountbankname = b2cShopperbi.getAccountbankname();
			String accountbankprovCode = b2cShopperbi.getAccountBankProvCode();
			String accountBankCityCode = b2cShopperbi.getAccountBankCityCode();
			String accountbankclientname = b2cShopperbi.getAccountbankclientname();
			String accountbankno = b2cShopperbi.getAccountbankno();

			// 扫码支付
			List merchantFeeList = shopPerbiService.findQrPayMerchantFeeList(b2cShopperbi.getShopperid().toString());
			

			String issupportt0 = b2cShopperbi.getIsSupportT0(); // 0支持
			String isicapplyt0 = "";
			Double t0singledaylimit = 0.00;
			if (Constants.CON_NO.equals(issupportt0)) {
				isicapplyt0 = b2cShopperbi.getIsIcApplyT0();
				t0singledaylimit = b2cShopperbi.getT0SingleDayLimit();
				params.put("t0fee", "0.0049");
				params.put("t0fixedamount", b2cShopperbi.getT0fixedamount());
				params.put("t0minamount", b2cShopperbi.getT0minamount());
				params.put("t0maxamount", b2cShopperbi.getT0maxamount());
				params.put("creditAmount", t0singledaylimit == null ? "": t0singledaylimit);
			} else {
				params.put("t0fee", "0");
				params.put("t0fixedamount", "0");
				params.put("t0minamount", "0");
				params.put("t0maxamount", "0");
				params.put("creditAmount", "0");
			}
			params.put("userType", userType == null ? "" : userType);
			params.put("orderId", orderId == null ? "" : orderId);
			params.put("orderTime", orderTime == null ? "" : orderTime);
			params.put("name",linkName == null ? "" : URLDecoder.decode(linkName, "UTF-8"));
			params.put("idNum", idCard == null ? "" : idCard);
			params.put("mobilePhoneNum", tel == null ? "" : tel);
			String bankCode=shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval())==null?"":URLDecoder.decode(shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval()).getDictid(),"UTF-8");
			params.put("bankCode", bankCode == null ? "" : bankCode);
			params.put("bankNo", accountbankno == null ? "" : accountbankno);
			params.put("bankName",accountbankname == null ? "" : URLDecoder.decode(accountbankname, "UTF-8"));
			params.put("prov", accountbankprovCode == null ? "": accountbankprovCode);
			params.put("city", accountBankCityCode == null ? "": accountBankCityCode);

			params.put("merchantNo", merchantNo == null ? "" : merchantNo);
			params.put("proxyId", agentNo == null ? "" : agentNo);
			params.put("institutionNo", institutionNo == null ? "" : institutionNo);
			params.put("platformType", platformType == null ? "" : platformType);

			params.put("commissionIds", merchantFeeList);
			params.put("issupportt0", issupportt0 == null ? "" : issupportt0);// 是否支持T0提现

			JSONObject obs = JSONObject.fromObject(params);
			System.out.println("扫码支付个人注册："+DynamicConfigLoader.getByEnv("reg_qr_pay_merchant_url")+obs.toString()+"代理商编号"+agentNo);
			String resultString = HttpClientUtils.REpostRequestStr(
					DynamicConfigLoader.getByEnv("reg_qr_pay_merchant_url"), obs.toString());
			Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);

			return resultMap;
		
		}
		
		/**扫码支付企业注册
		 * @param b2cShopperbi
		 * @param userType
		 * @return
		 * @throws UnsupportedEncodingException 
		 */
		private static Map regQrPayCompany(B2cShopperbi b2cShopperbi, String userType,ShopPerbiService shopPerbiService) throws Exception {

			HashMap params = new HashMap();
			Date dates = new Date();
			String mradom = RandomStringUtils.randomNumeric(6);
			String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom+ b2cShopperbi.getShopperid();
			String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");

			// 基本信息
			String name = b2cShopperbi.getName();
			String idCard = b2cShopperbi.getIDNo();
			String tel = b2cShopperbi.getStel();
			String merchantNo = b2cShopperbi.getShopperid() == null ? "": b2cShopperbi.getShopperid().toString();
			Long agentNo = b2cShopperbi.getShopperidP();
			String institutionNo = b2cShopperbi.getOrgNo();
			String platformType = "";
			if (agentNo != null) {
				platformType = Constants.CON_NO;// 0 自有
			} else {
				platformType = Constants.CON_YES;// 机构
			}
			// 结算信息
			String settlementType = b2cShopperbi.getSettlementType();
			String accountBankDictval = b2cShopperbi.getAccountbankdictval();
			String accountbankname = b2cShopperbi.getAccountbankname();
			String accountbankprovCode = b2cShopperbi.getAccountBankProvCode();
			String accountBankCityCode = b2cShopperbi.getAccountBankCityCode();
			String accountbankclientname = b2cShopperbi.getAccountbankclientname();
			String accountbankno = b2cShopperbi.getAccountbankno();
			// 刷卡手续费
			List merchantFeeList = shopPerbiService.findQrPayMerchantFeeList(b2cShopperbi.getShopperid().toString());
			// t+0手续费
			String issupportt0 = b2cShopperbi.getIsSupportT0(); // 0支持
			String isicapplyt0 = "";
			Double t0singledaylimit = 0.00;
			if (Constants.CON_NO.equals(issupportt0)) {
				isicapplyt0 = b2cShopperbi.getIsIcApplyT0();
				t0singledaylimit = b2cShopperbi.getT0SingleDayLimit();
				params.put("t0fee", "0.0049");
				params.put("t0fixedamount", b2cShopperbi.getT0fixedamount());
				params.put("t0minamount", b2cShopperbi.getT0minamount());
				params.put("t0maxamount", b2cShopperbi.getT0maxamount());
				params.put("creditAmount", t0singledaylimit == null ? "": t0singledaylimit);
				params.put("t0singledaylimit", t0singledaylimit == null ? "": t0singledaylimit);
			} else {
				params.put("t0fee", "0");
				params.put("t0fixedamount", "0");
				params.put("t0minamount", "0");
				params.put("t0maxamount", "0");
				params.put("creditAmount", "0");
				params.put("t0singledaylimit", "0");
			}
			params.put("userType", userType == null ? "" : userType);
			params.put("orderId", orderId == null ? "" : orderId);
			params.put("orderTime", orderTime == null ? "" : orderTime);
			params.put("idNum", idCard == null ? "" : idCard);
			params.put("register_corpTel", tel == null ? "" : tel);
			params.put("register_prinName",URLDecoder.decode(name == null ? "" : name, "UTF-8"));
			params.put("prov", accountbankprovCode == null ? "": accountbankprovCode);
			params.put("city", accountBankCityCode == null ? ""	: accountBankCityCode);
			String bankCode=shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval())==null?"":URLDecoder.decode(shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval()).getDictid(),"UTF-8");
			params.put("bankCode", bankCode);
			params.put("bankNo", accountbankno == null ? "" : accountbankno);
			params.put("bankName",accountbankname == null ? "" : URLDecoder.decode(accountbankname, "UTF-8"));
			params.put("register_corpFinanceName", URLDecoder.decode(name == null ? "" : name, "UTF-8"));
			params.put("linkman",name == null ? "" : URLDecoder.decode(name == null ? "" : name, "UTF-8"));
			params.put("register_corpLicenceNo",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi	.getLicenseNo());
			params.put("register_corpName", accountbankclientname == null ? "": URLDecoder.decode(accountbankclientname, "UTF-8"));
			params.put("register_email", b2cShopperbi.getSemail() == null ? "": b2cShopperbi.getSemail());
			params.put("register_corpAccountLicenceNo",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi.getLicenseNo());
			params.put("register_corpOrganizeNo",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi.getLicenseNo());
			params.put("register_corpTaxId",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi	.getLicenseNo());
			params.put("register_corpAddr", b2cShopperbi.getSaddress() == null ? ""	: URLDecoder.decode(b2cShopperbi.getSaddress(), "UTF-8"));
			params.put("register_corpZip", b2cShopperbi.getSzip() == null ? "": b2cShopperbi.getSzip());
			params.put("proxyId", agentNo == null ? "" : agentNo);
			params.put("merchantNo", merchantNo == null ? "" : merchantNo);
			params.put("institutionNo", institutionNo == null ? "" : institutionNo);
			//params.put("settlementType", settlementType == null ? "": settlementType);
			params.put("commissionIds", merchantFeeList);
			params.put("issupportt0", issupportt0 == null ? "" : issupportt0);// 是否支持T0提现
			JSONObject obs = JSONObject.fromObject(params);
			System.out.println("扫码支付企业注册："+DynamicConfigLoader.getByEnv("reg_qr_pay_company_url")+obs.toString());
			String resultString = HttpClientUtils.REpostRequestStr(DynamicConfigLoader.getByEnv("reg_qr_pay_company_url"), obs.toString()+"代理商编号"+agentNo);
			Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);
			return resultMap;
		
		}
		
		/**扫码支付激活
		 * @param b2cShopperbi
		 * @return
		 * @throws Exception 
		 */
		private static Map activateQrPayMerchantPort(B2cShopperbi b2cShopperbi) throws Exception {

			HashMap params=new HashMap();
			
			Date dates = new Date();
			String mradom = RandomStringUtils.randomNumeric(6);
			String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbi.getB2cShopperbiId();
			String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");
			
		    params.put("orderId", orderId);	    
	        params.put("userId", b2cShopperbi.getQrPayNo());
	        params.put("activeStatus", Constants.TYPE_2);//已激活
	        
	        JSONObject obs = JSONObject.fromObject(params);
	        String request = "activeStatus=" + Constants.TYPE_2 + "&orderId="+orderId+"&userId="+ b2cShopperbi.getQrPayNo();
		    String result = HttpClientUtils.REpostRequestStrNormal(DynamicConfigLoader.getByEnv("update_qrpay_user_status_url"), request);
		   
			Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(result);
	        
	        return resultMap;
		}
}
