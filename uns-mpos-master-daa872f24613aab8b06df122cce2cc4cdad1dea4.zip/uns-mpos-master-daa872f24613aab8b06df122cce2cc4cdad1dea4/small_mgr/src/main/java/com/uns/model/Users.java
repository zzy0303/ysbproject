package com.uns.model;

import java.util.Date;

public class Users {
	private Long id;
	private Long merchantid;
	private String userName;
	private String password;
	private Short enabled;
	private Date createdate;
	private Date lastlogindate;
	private Short results;
	private Short attempttimes;
	private Short locked;
	private String permits;
	private String roledesc;
	private String demo;
	private String usercode;
	private Long subsidiarid;
	private String isAgent;
	private String loginname;
	private String tel;

	public String getLoginname() {
		return loginname;
	}

	public void setLoginname(String loginname) {
		this.loginname = loginname;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getLoginName() {
		return loginname;
	}

	public void setLoginName(String loginName) {
		this.loginname = loginName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password == null ? null : password.trim();
	}

	public Short getEnabled() {
		return enabled;
	}

	public void setEnabled(Short enabled) {
		this.enabled = enabled;
	}

	public Date getCreatedate() {
		return createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}

	public Date getLastlogindate() {
		return lastlogindate;
	}

	public void setLastlogindate(Date lastlogindate) {
		this.lastlogindate = lastlogindate;
	}

	public Short getResults() {
		return results;
	}

	public void setResults(Short results) {
		this.results = results;
	}

	public Short getAttempttimes() {
		return attempttimes;
	}

	public void setAttempttimes(Short attempttimes) {
		this.attempttimes = attempttimes;
	}

	public Short getLocked() {
		return locked;
	}

	public void setLocked(Short locked) {
		this.locked = locked;
	}

	public String getPermits() {
		return permits;
	}

	public void setPermits(String permits) {
		this.permits = permits == null ? null : permits.trim();
	}

	public String getRoledesc() {
		return roledesc;
	}

	public void setRoledesc(String roledesc) {
		this.roledesc = roledesc == null ? null : roledesc.trim();
	}

	public String getDemo() {
		return demo;
	}

	public void setDemo(String demo) {
		this.demo = demo == null ? null : demo.trim();
	}

	public String getUsercode() {
		return usercode;
	}

	public void setUsercode(String usercode) {
		this.usercode = usercode == null ? null : usercode.trim();
	}

	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getMerchantid() {
		return merchantid;
	}

	public void setMerchantid(Long merchantid) {
		this.merchantid = merchantid;
	}

	public Long getSubsidiarid() {
		return subsidiarid;
	}

	public void setSubsidiarid(Long subsidiarid) {
		this.subsidiarid = subsidiarid;
	}

	public String getIsAgent() {
		return isAgent;
	}

	public void setIsAgent(String isAgent) {
		this.isAgent = isAgent == null ? null : isAgent.trim();
	}
}