package com.uns.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.annotation.FormToken;
import com.uns.model.B2cShopperbiTemp;
import com.uns.service.ShopPerbiService;
import com.uns.web.form.BatchForm;

@Controller("batchRegController")
@RequestMapping("/batchreg.htm")
public class BatchRegController extends BaseController {
	@Autowired
	private ShopPerbiService shopperService;

	@RequestMapping(params = "method=tobatchregList")
	public String tobatchregList(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		return "shopPerbi/batchreg";
	}

	/**
	 * @param request
	 * @param response
	 * @param form
	 * @return
	 * @throws Exception
	 *             保存注册
	 */
	@RequestMapping(params = "method=savebatchreg")
	public String savebatchreg(HttpServletRequest request,
			HttpServletResponse response, BatchForm form) throws Exception {
		/*String msg = null;
		String count = null;
		try {

			InputStream ins1 = form.getBatchfile().getInputStream();
			Workbook wb = WorkbookFactory.create(ins1);
			ins1.close();
			Sheet sheet = wb.getSheetAt(0);

			if (sheet == null) {
				msg = "上传的文档中没有内容！";
				request.setAttribute("msg", msg);
			} else {
				int lastRow = sheet.getLastRowNum();
				if (lastRow > 5000) {
					msg = "文档记录超过了5000条，请拆分文档，拆分时请保证同一订单号的订单在一个文件里";
					request.setAttribute("msg", msg);
				}
				for (int i = 1; i <= lastRow; i++) {
					count = i + "";
					B2cShopperbiTemp shopper = new B2cShopperbiTemp();
					String scompany = sheet.getRow(i).getCell(1).toString()
							.trim();
					B2cShopperbiTemp b2cShopperbi = this.shopperService
							.findB2cShopperbiScompany(scompany);
					if (b2cShopperbi != null) {
						msg = "第" + i + "行数据的商户名已存在！";
						request.setAttribute("msg", msg);
						return "shopPerbi/batchreg";

					} else {
						shopper.setScompany(scompany);
					}
					// 票据
					String Province = sheet.getRow(i).getCell(2).toString()
							.trim();
					String City = sheet.getRow(i).getCell(3).toString().trim();
					Area area = shopperService.findbyareaname(Province, City);
					if (area != null) {
						shopper.setScity(area.getCityname());
						shopper.setCity(area.getCity());
						shopper.setSprovince(area.getProvincialname());
						shopper.setProvince(area.getProvincial());
					} else {
						msg = "第" + count + "行数据报错省份或城市不正确请重新填写！";
						request.setAttribute("msg", msg);
						return "shopPerbi/batchreg";
					}

					String address = sheet.getRow(i).getCell(4).toString()
							.trim();
					if (address != null && address != "") {
						shopper.setSaddress(address);
					} else {
						msg = "第" + i + "行数据的商户地址不能为空！";
						request.setAttribute("msg", msg);
						return "shopPerbi/batchreg";
					}
                    //验证电话号码格式以及判断电话号码是否存在
					String tel = sheet.getRow(i).getCell(5).toString().trim();
					String regtel = "^//d{11}$";
					Pattern pattern5 = Pattern.compile(regtel);
					Matcher matcher5 = pattern5.matcher(tel);
					boolean rstel = matcher5.matches();
					if (rstel == true) {
						List list = shopperService.findbytel(tel);
						if (list.size() > 0 && (list != null)) {
							msg = "第" + i + "行数据的电话号码已存在！";
							request.setAttribute("msg", msg);
							return "shopPerbi/batchreg";
						} else {
							shopper.setStel(tel);
						}
					} else {
						msg = "第" + i + "行数据的手机号码输入不正确！";
						request.setAttribute("msg", msg);
						return "shopPerbi/batchreg";
					}

					// 商户状态
					String sifpactid = sheet.getRow(i).getCell(6).toString()
							.trim();
					if (sifpactid.equals("开通")) {
						shopper.setSifpactid(Long.parseLong("0"));
					} else if (sifpactid.equals("冻结")) {
						shopper.setSifpactid(Long.parseLong("1"));
					} else {
						msg = "第" + i + "行数据的商户状态输入不正确！";
						request.setAttribute("msg", msg);
						return "shopPerbi/batchreg";
					}

					String settlementType = sheet.getRow(i).getCell(7)
							.toString().trim();
					if (settlementType.equals("结算至银行")) {
						shopper.setSettlementType("0");
					} else if (settlementType.equals("结算至银生宝")) {
						shopper.setSettlementType("1");
					} else {
						msg = "第" + i + "行数据的结算方式输入不正确！";
						request.setAttribute("msg", msg);
						return "shopPerbi/batchreg";
					}

					String bankname = sheet.getRow(i).getCell(11).toString()
							.trim();
					String bankclientname = sheet.getRow(i).getCell(12)
							.toString().trim();
					String name = sheet.getRow(i).getCell(20).toString().trim();
					if (bankname != null && bankname != "") {
						shopper.setAccountbankname(bankname);
					} else {
						msg = "第" + i + "行数据的开户行名称不能为空！";
						request.setAttribute("msg", msg);
						return "shopPerbi/batchreg";
					}

					if (bankclientname != null && bankclientname != "") {
						shopper.setAccountbankclientname(bankclientname);
					} else {
						msg = "第" + i + "行数据的开户姓名不能为空！";
						request.setAttribute("msg", msg);
						return "shopPerbi/batchreg";
					}

					if (name != null && name != "") {
						shopper.setName(name);
					} else {
						msg = "第" + i + "行数据的商户联系人姓名不能为空！";
						request.setAttribute("msg", msg);
						return "shopPerbi/batchreg";
					}

					String bankno = sheet.getRow(i).getCell(13).toString()
							.trim();
					String regbankno = "^//d{16}|//d{19}$";
					Pattern pattern1 = Pattern.compile(regbankno);
					Matcher matcher1 = pattern1.matcher(bankno);
					boolean rs1 = matcher1.matches();

					if (rs1 == true) {
						shopper.setAccountbankno(bankno);
					} else {
						msg = "第" + i + "行数据的银行卡号输入不正确！";
						request.setAttribute("msg", msg);
						return "shopPerbi/batchreg";
					}

					shopper.setMuserid(tel);
					
					// 商户类型
					String merchantType = sheet.getRow(i).getCell(18)
							.toString().trim();
					if (merchantType.equals("企业")) {
						shopper.setMerchantType("1");
						shopper.setLicenseNo(sheet.getRow(i).getCell(19)
								.toString().trim());
					} else if (merchantType.equals("个人")) {
						shopper.setMerchantType("0");
					} else {
						msg = "第" + i + "行数据的商户类型不正确！";
						request.setAttribute("msg", msg);
						return "shopPerbi/batchreg";
					}

					shopper.setName(sheet.getRow(i).getCell(20).toString()
							.trim());
					// 身份证号码
					String id = sheet.getRow(i).getCell(21).toString().trim();
					List list = shopperService.findbysid(id);
					B2cShopperbiTemp b2cShopperbi1 = null;
					if (list != null && list.size() > 0) {
						b2cShopperbi1 = (B2cShopperbiTemp) list.get(0);
					}
					String regid = "^//d{15}|//d{18}$";
					Pattern pattern = Pattern.compile(regid);
					Matcher matcher = pattern.matcher(id);
					boolean rs = matcher.matches();
					if (b2cShopperbi1 == null) {
						if (rs == true) {
							shopper.setIDNo(id);
						} else {
							msg = "第" + i + "行数据的身份证号码输入不正确！";
							request.setAttribute("msg", msg);
							return "shopPerbi/batchreg";
						}
					} else {
						msg = "第" + i + "行数据的身份证号码已存在！";
						request.setAttribute("msg", msg);
						return "shopPerbi/batchreg";
					}

					String billaddress = sheet.getRow(i).getCell(24).toString()
							.trim();
					String billname = sheet.getRow(i).getCell(25).toString()
							.trim();
					String orgno = sheet.getRow(i).getCell(26).toString()
							.trim();
					if (billaddress != null && billaddress != "") {
						shopper.setBillAddress(billaddress);
					} else {
						msg = "第" + i + "行数据的票据地址不能为空！";
						request.setAttribute("msg", msg);
						return "shopPerbi/batchreg";
					}

					if (billname != null && billname != "") {
						shopper.setBillName(billname);
					} else {
						msg = "第" + i + "行数据的票据名称不能为空！";
						request.setAttribute("msg", msg);
						return "shopPerbi/batchreg";
					}

					String regorgno = "^//d{8,11}$";
					Pattern pattern2 = Pattern.compile(regorgno);
					Matcher matcher2 = pattern2.matcher(orgno);
					boolean rs2 = matcher2.matches();

					if (rs2 == true) {
						shopper.setOrgNo(orgno);
					} else {
						msg = "第" + i + "行数据的机构编码不能为空！";
						request.setAttribute("msg", msg);
						return "shopPerbi/batchreg";
					}

					String supportT0 = sheet.getRow(i).getCell(27).toString()
							.trim();
					if (supportT0.equals("是")) {
						shopper.setIsSupportT0("0");
						if (sheet.getRow(i).getCell(28).toString().trim()
								.equals("是")) {
							shopper.setIsIcApplyT0("0");
						} else if (sheet.getRow(i).getCell(28).toString()
								.trim().equals("否")) {
							shopper.setIsIcApplyT0("1");
						} else {
							msg = "第" + i + "行数据的是否可以IC卡交易申请T+0输入错误！";
							request.setAttribute("msg", msg);
							return "shopPerbi/batchreg";
						}
						shopper.setT0fee(Double.parseDouble(sheet.getRow(i)
								.getCell(29).toString().trim()));
						shopper.setT0SingleDayLimit(Double.parseDouble(sheet
								.getRow(i).getCell(30).toString().trim()));
					} else if (supportT0.equals("否")) {
						shopper.setIsSupportT0("1");
					} else {
						msg = "第" + i + "行数据的是否支持T+0输入错误！";
						request.setAttribute("msg", msg);
						return "shopPerbi/batchreg";
					}

					B2cDict industry = shopperService.findbyhCname(sheet
							.getRow(i).getCell(31).toString().trim());
					if (industry != null) {
						shopper.setIndustry(industry.getB2cDictId().toString()
								.trim());
					} else {
						msg = "第" + count + "行数据报错票据行业类型不正确请重新填写！";
						request.setAttribute("msg", msg);
						return "shopPerbi/batchreg";
					}

					// 票据
					String billProvince = sheet.getRow(i).getCell(22)
							.toString().trim();
					String billCity = sheet.getRow(i).getCell(23).toString()
							.trim();
					Area area3 = shopperService.findbyareaname(billProvince,
							billCity);
					if (area3 != null) {
						shopper.setBillCity(area3.getCityname());
						shopper.setBillCityCode(area3.getCity());
						shopper.setBillProvince(area3.getProvincialname());
						shopper.setBillProvinceCode(area3.getProvincial());
					} else {
						msg = "第" + count + "行数据报错票据省份或城市不正确请重新填写！";
						request.setAttribute("msg", msg);
						return "shopPerbi/batchreg";
					}

					// 开户行名称数据字典
					String bankid = sheet.getRow(i).getCell(8).toString()
							.trim();
					B2cDict bank = shopperService.findbankName(bankid);
					if (bank == null) {
						msg = "第" + count + "行数据报错开户银行不正确请重新填写！";
						request.setAttribute("msg", msg);
						return "shopPerbi/batchreg";
					} else {
						shopper.setAccountbankdictval(bank.getB2cDictId()
								.toString());
					}

					// 银行地址
					String cardProvince = sheet.getRow(i).getCell(9).toString()
							.trim();
					String cardCity = sheet.getRow(i).getCell(10).toString()
							.trim();
					Area area1 = shopperService.findbyareaname(cardProvince,
							cardCity);
					Area area2 = new Area();
					if (area1 != null) {
						shopper.setAccountBankCity(area1.getCityname());
						shopper.setAccountBankCityCode(area1.getCity());
						shopper.setAccountbankprov(area1.getProvincialname());
						shopper.setAccountBankProvCode(area1.getProvincial());
						// 生成商户编号
						area2 = shopperService.findbyareaname(cardProvince,
								cardCity);
					} else {
						msg = "第" + count + "行数据报错开户银行省份或城市不正确请重新填写！";
						request.setAttribute("msg", msg);
						return "shopPerbi/batchreg";
					}

					// 支行名称

					shopper.setReportResource(Constants.STATUS3);// 批量注册
					shopper.setCreated(new Date());
					// 生成商户号
					String shopperid = getPosShopperId(area2.getCity(),
							Constants.CON_MCC);
					shopper.setShopperid(Long.valueOf(shopperid));

					String fee = sheet.getRow(i).getCell(16).toString();
					String top = sheet.getRow(i).getCell(17).toString();

					String Minsettlemoney = sheet.getRow(i).getCell(15)
							.toString().trim();
					String regmoney = "^//d$";
					Pattern pattern3 = Pattern.compile(regmoney);
					Matcher matcher3 = pattern3.matcher(Minsettlemoney);
					boolean rs3 = matcher3.matches();

					if (rs3 == true) {
						shopper.setMinsettlemoney(Double
								.valueOf(Minsettlemoney) * 100);
					} else {
						msg = "第" + i + "行数据的结算最小金额输入不正确！";
						request.setAttribute("msg", msg);
						return "shopPerbi/batchreg";
					}

					B2cShopperbargainTemp bar = new B2cShopperbargainTemp();
					bar.setFootfreq(Long.valueOf(Constants.TYPE_3));
					bar.setShopperid(shopperid);

					// 默认添加字段

					shopper.setIfvalid(Short.valueOf(Constants.STATUS1));
					shopper.setOpencheckstatus(Short.valueOf(Constants.STATUS1));
					shopper.setIsformal(Short.valueOf(Constants.STATUS0));
					shopper.setIsupdateshopper(Short.valueOf(Constants.STATUS0));
					shopper.setRecheckmerchantflag(Constants.STATUS0);
					// 进度表
					MposApplicationProgress progress = new MposApplicationProgress();
					progress.setShopperid(shopper.getShopperid().toString()
							.trim());
					progress.setScompany(scompany);
					progress.setApplicationTheme("商户开通");
					progress.setApplicationType(Constants.STATUS1);
					progress.setApplicationStatus(Constants.STATUS1);
					progress.setApplicationRemark("待审核");
					progress.setCreateDate(new Date());
					this.shopperService.insertsbar(shopper, bar, progress, fee,
							top);

					request.setAttribute(Constants.MESSAGE_KEY, "注册成功!");
					request.setAttribute("url",
							"batchreg.htm?method=tobatchregList");
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
			// throw new BusinessException(ExceptionDefine.机构批量注册失败);
			msg = "第" + count + "行数据报错请重新填写！";
			request.setAttribute("msg", msg);
			return "shopPerbi/batchreg";
		}*/
		return "returnPage";
	}

	/**
	 * 下载pdf
	 * 
	 * @param request
	 * @param modelMap
	 * @param mbForm
	 */
	@RequestMapping(params = "method=downBkTemplate")
	@FormToken(save = true)
	public void downBkTemplate(HttpServletRequest request,
			HttpServletResponse response) {
		String path = request.getContextPath();
		String basePath = request.getScheme() + "://" + request.getServerName()
				+ ":" + request.getServerPort() + path + "/";
		String filePath = request.getSession().getServletContext()
				.getRealPath("/")
				+ "upload"
				+ File.separator
				+ "BankFiles"
				+ File.separator
				+ "机构批量注册申请表.xls";
		String fileName = "";
		// 从文件完整路径中提取文件名，并进行编码转换，防止不能正确显示中文名
		try {
			if (filePath.lastIndexOf("/") > 0) {
				fileName = new String(filePath.substring(
						filePath.lastIndexOf("/") + 1, filePath.length())
						.getBytes("GB2312"), "ISO8859_1");
			} else if (filePath.lastIndexOf("\\") > 0) {
				fileName = new String(filePath.substring(
						filePath.lastIndexOf("\\") + 1, filePath.length())
						.getBytes("GB2312"), "ISO8859_1");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		// 打开指定文件的流信息
		InputStream fs = null;
		try {
			fs = new FileInputStream(new File(filePath));

		} catch (Exception e) {
			e.printStackTrace();
		}
		// 设置响应头和保存文件名
		response.setCharacterEncoding("ISO-8859-1");
		response.setContentType("APPLICATION/OCTET-STREAM");
		response.setHeader("Content-Disposition", "attachment; filename=\""
				+ fileName + "\"");
		// 写出流信息
		int b = 0;
		try {
			PrintWriter out = response.getWriter();
			while ((b = fs.read()) != -1) {
				out.write(b);
			}
			out.flush();
			fs.close();
			out.close();
			System.out.println("文件下载完毕.");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("下载文件失败!");
		}

	}

	public String getPosShopperId(String area, String mcc) throws Exception {
		String organization = "800";
		String areacold = "";
		if (area.length() > 4) {
			areacold = area.substring(0, 4);
		} else {
			areacold = area;
		}
		String mcccold = "";
		if (mcc.length() == 1) {
			mcccold = "000" + mcc;
		} else {
			mcccold = "00" + mcc;
		}
		String merchantRadom = RandomStringUtils.randomNumeric(4);
		String posMerchantId = organization + areacold + mcccold
				+ merchantRadom;
		B2cShopperbiTemp b2cShopperbi = shopperService
				.queryShopPerbi(posMerchantId);
		if (b2cShopperbi != null) {
			return getPosShopperId(area, mcc);
		}
		return posMerchantId;
	}
}
