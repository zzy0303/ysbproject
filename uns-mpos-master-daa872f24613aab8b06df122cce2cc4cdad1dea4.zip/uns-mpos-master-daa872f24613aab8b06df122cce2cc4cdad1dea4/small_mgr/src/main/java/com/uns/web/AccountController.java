package com.uns.web;


import java.io.OutputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jxl.SheetSettings;
import jxl.Workbook;
import jxl.format.Alignment;
import jxl.format.UnderlineStyle;
import jxl.write.Label;
import jxl.write.NumberFormats;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.service.AccountService;
import com.uns.web.form.AccountForm;
import com.uns.web.form.AgentSplitFeeForm;

@Controller("accountController")
@RequestMapping("/account.htm")
public class AccountController extends BaseController {

	@Autowired
	private AccountService accountService;
	

	
	
	/**结算统计信息汇总
	 * @param request
	 * @param accountForm
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=accountStatisticsList")
	public String accountStatisticsList(HttpServletRequest request,AccountForm accountForm)throws BusinessException {
	    List<HashMap> accList=accountService.selectByCountList(accountForm);
	    request.setAttribute("accList", accList);
	    request.setAttribute("accountForm", accountForm);
		return "account/accountStatistiHistory";
	}
	
	/**商户结算历史查询
	 * @param request
	 * @param modelMap
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=accountList")
	public String accountList(HttpServletRequest request,AccountForm accountForm)throws BusinessException {
		accountForm.setMerchantNo(request.getParameter("merchantNo"));
		accountForm.setCreatedStart(request.getParameter("createdStart"));
		accountForm.setCreatedEnd(request.getParameter("createdEnd"));
		accountForm.setTrantStart(request.getParameter("trantStart"));
		accountForm.setTrantEnd(request.getParameter("trantEnd"));
		accountForm.setMstart(request.getParameter("mstart"));
		accountForm.setMend(request.getParameter("mend"));
		
		List<HashMap> List=accountService.selectAllList(accountForm);
	    request.setAttribute("List", List);
	    request.setAttribute("accountForm", accountForm);
	    return "account/accountHistory";
	}
	
	/**商户结算历史查询
	 * @param request
	 * @param response
	 * @param splitFeesForm
	 * @return
	 * @throws BusinessException
	 * @throws Exception
	 */
	@RequestMapping(params = "method=toaccountList")
	public String toaccountList(HttpServletRequest request, HttpServletResponse response, AgentSplitFeeForm form)
		throws BusinessException, Exception{
		return "account/accountindex";
	
	}
	/**商户结算历史查询
	 * @param request
	 * @param response
	 * @param splitFeesForm
	 * @return
	 * @throws BusinessException
	 * @throws Exception
	 */
	@RequestMapping(params = "method=toiframeOne")
	public String toiframeOne(HttpServletRequest request, HttpServletResponse response, AgentSplitFeeForm form)
		throws BusinessException, Exception{
		return "account/accountHistory";
	
	}
	/**商户结算历史查询
	 * @param request
	 * @param response
	 * @param splitFeesForm
	 * @return
	 * @throws BusinessException
	 * @throws Exception
	 */
	@RequestMapping(params = "method=toiframeTwo")
	public String toiframeTwo(HttpServletRequest request, HttpServletResponse response, AgentSplitFeeForm form)
		throws BusinessException, Exception{
		return "account/accountStatistiHistory";
	
	}
	/**商户结算明细查询
	 * @param request
	 * @param modelMap
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=detailsList")
	public String detailsList(HttpServletRequest request,AccountForm accountForm)throws BusinessException {
		String merchant_no=request.getParameter("merchant_no");
		String settle_date=request.getParameter("settle_date");
	    accountForm.setMerchantNo(merchant_no);
	    accountForm.setSettleDate(settle_date);
		List<HashMap> accList=	accountService.selectDetailsList(accountForm);
	    request.setAttribute("accList", accList);
		return "account/accountDetails";
	}
	
	/**商户结算导出
	 * @param request
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=outExcleAccount")
	public String outExcleAccount(HttpServletRequest request,
			HttpServletResponse response,
			AccountForm accountForm)throws Exception {
		String tPage = request.getParameter("page");
		
		if (StringUtils.isEmpty(tPage) || !StringUtils.isNumeric(tPage)){
			tPage = "1";
		}
		int currentPage = Integer.valueOf(tPage);
		Page page  = new Page();
		page.setPageSize(Constants.EXCEL_SIZE);
		PageContext context = PageContext.getContext();
		BeanUtils.copyProperties(context, page);
		context.setPagination(true);
		context.setCurrentPage(currentPage);
	    List<HashMap> List=	accountService.getAccountList(accountForm);
	    request.setAttribute("List", List);
	    
		StringBuffer sb= new StringBuffer();
		response.setContentType("application/vnd.ms-excel");
		String fileNames="结算历史信息";
		response.setHeader("content-disposition", "attachment;filename="+new String(fileNames.getBytes("GBK"),"iso8859-1")+".csv");
		//response.setHeader("content-disposition", "attachment;filename=huiyuan.csv");
        response.setCharacterEncoding("GBK");
        if(List.size()<=0){
        	throw new BusinessException(ExceptionDefine.空指针异常);
        }
		for(Map accView:List){
			//终端编号,持卡人,开户行,结算卡号，费率
			String terNo=getTermianl(accView.get("MERCHANT_NO").toString());
			sb.append(""+terNo+"\t,");
			sb.append(accView.get("ACCOUNT_BANK_CLIENT_NAME")==null?",":StringUtils.isEmpty(accView.get("ACCOUNT_BANK_CLIENT_NAME").toString())?",":accView.get("ACCOUNT_BANK_CLIENT_NAME")+"\t,");
			sb.append(accView.get("ACCOUNT_BANK_NAME")==null?",":StringUtils.isEmpty(accView.get("ACCOUNT_BANK_NAME").toString())?",":accView.get("ACCOUNT_BANK_NAME")+"\t,");
			sb.append(accView.get("ACCOUNT_BANK_NO")==null?",":StringUtils.isEmpty(accView.get("ACCOUNT_BANK_NO").toString())?",":accView.get("ACCOUNT_BANK_NO")+"\t,");
			sb.append(accView.get("MERCHANT_NO")==null?",":StringUtils.isEmpty(accView.get("MERCHANT_NO").toString())?",":accView.get("MERCHANT_NO")+"\t,");
			sb.append(accView.get("SCOMPANY")==null?",":StringUtils.isEmpty(accView.get("SCOMPANY").toString())?",":accView.get("SCOMPANY")+"\t,");
			sb.append(accView.get("SETTLE_DATE")==null?",":StringUtils.isEmpty(accView.get("SETTLE_DATE").toString())?",":accView.get("SETTLE_DATE")+"\t,");
			sb.append(accView.get("SA_AMOUNT")==null?",":StringUtils.isEmpty(accView.get("SA_AMOUNT").toString())?",":accView.get("SA_AMOUNT")+"\t,");	
			sb.append(accView.get("SFEE")==null?",":StringUtils.isEmpty(accView.get("SFEE").toString())?",":accView.get("SFEE")+"\t,");
			sb.append(accView.get("FEE_RATE")==null?",":StringUtils.isEmpty(accView.get("FEE_RATE").toString())?",":accView.get("FEE_RATE")+"\t,");
			sb.append(accView.get("SR_AMOUNT")==null?",":StringUtils.isEmpty(accView.get("SR_AMOUNT").toString())?",":accView.get("REAMOUNT")+"\t,");	
			sb.append(accView.get("ALLMONEY")==null?",":StringUtils.isEmpty(accView.get("ALLMONEY").toString())?",":accView.get("ALLMONEY")+"\t,");	
			sb.append("\n");
		}
        
		response.getWriter().println("终端编号,持卡人,开户行,结算卡号,商户号,商户名称 ,结算时间,交易金额(元),费率,手续费(元),退款金额(元),结算金额(元)");
        response.getWriter().println(sb.toString());
		return null;
	}
	
	private String getTermianl(String merchantNo) {
		String terNo="";
		List list=accountService.getTermianl(merchantNo);
		if(list.size()>0&&list!=null){
			for(int i=0;i<list.size();i++){
				Map map=(Map)list.get(i);
				if(map!=null&&map.size()>0){
					if(i>0){
						terNo+="、";	
					}
					terNo+=map.get("NUM");
				}
			}
		}
		return terNo;
	}

	/**
	 * 导出已经结算的列表,获取分页。
	 * @param request
	 * @param tradeForm
	 * @return
	 * @throws BusinessException
	 * @throws Exception
	 */
	
	@RequestMapping(params = "method=getExcelSbPage")
	public String getExcelSbPage(HttpServletRequest request, HttpServletResponse response, AccountForm accountForm)
	    throws BusinessException, Exception{
		accountForm.setMerchantNo(request.getParameter("merchantNo"));
		accountForm.setCreatedStart(request.getParameter("createdStart"));
		accountForm.setCreatedEnd(request.getParameter("createdEnd"));
		accountForm.setTrantStart(request.getParameter("trantStart"));
		accountForm.setTrantEnd(request.getParameter("trantEnd"));
		accountForm.setMstart(request.getParameter("mstart"));
		accountForm.setMend(request.getParameter("mend"));
		Page page  = new Page();
		page.setPageSize(Constants.EXCEL_SIZE);
		PageContext context = PageContext.getContext();
		BeanUtils.copyProperties(context, page);
		context.setPagination(true);
		accountService.getAccountList(accountForm);
		BeanUtils.copyProperties(page, context);
		request.setAttribute("account",accountForm);
		request.setAttribute("page",page);
		return "account/excel_account_page";
	}
	/**
	 * 导出汇总可结算的列表,获取分页。
	 * @param request
	 * @param tradeForm
	 * @return
	 * @throws BusinessException
	 * @throws Exception
	 */
	
	@RequestMapping(params = "method=getExcelNextPage")
	public String getExcelNextPage(HttpServletRequest request, HttpServletResponse response, AccountForm accountForm)
	    throws BusinessException, Exception{
		accountForm.setMerchantNo(request.getParameter("merchantNo"));
		accountForm.setCreatedStart(request.getParameter("createdStart"));
		accountForm.setCreatedEnd(request.getParameter("createdEnd"));
		accountForm.setTrantStart(request.getParameter("trantStart"));
		accountForm.setTrantEnd(request.getParameter("trantEnd"));
		accountForm.setMstart(request.getParameter("mstart"));
		accountForm.setMend(request.getParameter("mend"));
		Page page  = new Page();
		page.setPageSize(Constants.EXCEL_SIZE);
		PageContext context = PageContext.getContext();
		BeanUtils.copyProperties(context, page);
		context.setPagination(true);
		accountService.getysbList(accountForm);
		BeanUtils.copyProperties(page, context);
		request.setAttribute("account",accountForm);
		request.setAttribute("page",page);
		return "account/excel_ysb_page";
	}
	
	
	/**商户未结算列表导出
	 * @param request
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=outExcleNotAccount")
	public String outExcleNotAccount(HttpServletRequest request,
			HttpServletResponse response,
			AccountForm accountForm)throws Exception {
		accountForm.setMerchantNo(request.getParameter("merchantNo"));
		accountForm.setCreatedStart(request.getParameter("createdStart"));
		accountForm.setCreatedEnd(request.getParameter("createdEnd"));
		accountForm.setTrantStart(request.getParameter("trantStart"));
		accountForm.setTrantEnd(request.getParameter("trantEnd"));
		accountForm.setMstart(request.getParameter("mstart"));
		accountForm.setMend(request.getParameter("mend"));
		String tPage = request.getParameter("page");
		if (StringUtils.isEmpty(tPage) || !StringUtils.isNumeric(tPage)){
			tPage = "1";
		}
		int currentPage = Integer.valueOf(tPage);
		Page page  = new Page();
		page.setPageSize(Constants.EXCEL_SIZE);
		PageContext context = PageContext.getContext();
		BeanUtils.copyProperties(context, page);
		context.setPagination(true);
		context.setCurrentPage(currentPage);
	    List<HashMap> List=	accountService.getNotAccountList(accountForm);
	    request.setAttribute("List", List);
		StringBuffer sb= new StringBuffer();
		response.setContentType("application/vnd.ms-excel");
		String fileNames="下载汇总可结算交易";
		response.setHeader("content-disposition", "attachment;filename="+new String(fileNames.getBytes("GBK"),"iso8859-1")+".csv");
		//response.setHeader("content-disposition", "attachment;filename=huiyuan.csv");
        response.setCharacterEncoding("GBK");
        
        if(List.size()<=0){
        	throw new BusinessException(ExceptionDefine.空指针异常);
        }
		for(Map accView:List){
			sb.append(accView.get("MERCHANT_NO")==null?",":accView.get("MERCHANT_NO").toString()+"\t,");
			sb.append(accView.get("SCOMPANY")==null?",":accView.get("SCOMPANY").toString()+"\t,");
			sb.append(accView.get("SETTLE_DATE")==null?",":accView.get("SETTLE_DATE").toString()+"\t,");
			sb.append(accView.get("SA_AMOUNT")==null?",":accView.get("SA_AMOUNT").toString()+"\t,");	
			sb.append(accView.get("SFEE")==null?",":accView.get("SFEE").toString()+"\t,");
			sb.append(accView.get("REAMOUNT")==null?",":accView.get("REAMOUNT").toString()+"\t,");
			sb.append(accView.get("ALLMOUNT")==null?",":accView.get("ALLMOUNT").toString()+"\t,");	
			sb.append(accView.get("ALLD")==null?",":accView.get("ALLD").toString()+"\t,");	
			sb.append(accView.get("DICT")==null?",":accView.get("DICT").toString()+"\t,");
			sb.append(accView.get("ACCOUNT_BANK_PROV")==null?",":accView.get("ACCOUNT_BANK_PROV").toString()+"\t,");
			sb.append(accView.get("ACCOUNT_BANK_NAME")==null?",":accView.get("ACCOUNT_BANK_NAME").toString()+"\t,");
			sb.append(accView.get("ACCOUNT_BANK_CLIENT_NAME")==null?",":accView.get("ACCOUNT_BANK_CLIENT_NAME").toString()+"\t,");
			sb.append(accView.get("ACCOUNT_BANK_NO")==null?",":accView.get("ACCOUNT_BANK_NO").toString()+"\t,");
			sb.append("\n");
		}
		response.getWriter().println("商户号,商户名称 ,结算时间,本期交易金额(元),手续费,本期退款金额(元),上期末结算金额(元),本期结算总额(元),开户银行,开户省份,开户支行,开户姓名,银行账户");
        response.getWriter().println(sb.toString());
		return null;
	}
	
	
	
	
	/**导出银生宝批付文件
	 * @param financingProductInfo
	 * @param request
	 * @param response
	 * @param modelMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=outExcleysb")
	public String toOutRepayExcel(HttpServletRequest request, HttpServletResponse response,ModelMap modelMap,AccountForm accountForm) {
		try{
			String tPage = request.getParameter("page");
			if (StringUtils.isEmpty(tPage) || !StringUtils.isNumeric(tPage)){
				tPage = "1";
			}
			accountForm.setMerchantNo(request.getParameter("merchantNo"));
			accountForm.setCreatedStart(request.getParameter("createdStart"));
			accountForm.setCreatedEnd(request.getParameter("createdEnd"));
			accountForm.setTrantStart(request.getParameter("trantStart"));
			accountForm.setTrantEnd(request.getParameter("trantEnd"));
			accountForm.setMstart(request.getParameter("mstart"));
			accountForm.setMend(request.getParameter("mend"));
			int currentPage = Integer.valueOf(tPage);
			Page page  = new Page();
			page.setPageSize(Constants.EXCEL_SIZE);
			PageContext context = PageContext.getContext();
			BeanUtils.copyProperties(context, page);
			context.setPagination(true);
			context.setCurrentPage(currentPage);
		    List<HashMap> excelList=accountService.getysbList(accountForm);
			Map<String, String> mapField = new LinkedHashMap();
			mapField.put("BANKNAME", "收款方银行");
			mapField.put("ACCOUNT_BANK_NO", "银行卡号");
			mapField.put("ACCOUNT_BANK_CLIENT_NAME", "开户姓名");
			mapField.put("ACCOUNT_BANK_PROV", "开户省份");
			mapField.put("ACCOUNT_BANK_NAME", "开户支行");
			mapField.put("ALLMONEY", "付款金额");
			mapField.put("MONEYUSE", "资金用途");
		    String fileName="银生宝批付文件";
			outExcel(excelList,response,mapField,fileName);
		}catch (Exception e) {
			log.info("导出数据有误！");
			e.printStackTrace();
		}
        return null;
	}
	
	public WritableCellFormat getHeaderCellStyle() throws WriteException{
	    WritableFont font = new WritableFont(WritableFont.createFont("宋体"),   
                13,    
                WritableFont.BOLD,    
                false,   
                UnderlineStyle.NO_UNDERLINE);   
        WritableCellFormat headerFormat = new WritableCellFormat(NumberFormats.TEXT);   
        headerFormat.setFont(font);
        headerFormat.setAlignment(Alignment.CENTRE);
		return headerFormat;
	};
	/**导出excel
	 * @param excelList
	 * @param response
	 * @param mapField
	 * @throws Exception
	 */
	private void outExcel(List excelList, HttpServletResponse response,Map<String, String> mapField,String fileNames) throws Exception {
		
		response.setContentType("application/vnd.ms-excel");
		response.setHeader("content-disposition", "attachment;filename="+new String(fileNames.getBytes("GBK"),"iso8859-1")+".xls");
		response.setCharacterEncoding("UTF-8");
        
        OutputStream os = response.getOutputStream(); 
		WritableWorkbook wwb=Workbook.createWorkbook(os);
		 
		WritableSheet sheet = wwb.createSheet("银生宝批付文件", 0);  
		
        SheetSettings ss = sheet.getSettings();  
        ss.setVerticalFreeze(1);//冻结表头 
        sheet.mergeCells(0,0,5,0);  
        WritableCellFormat wcf = new WritableCellFormat();  
        WritableCellFormat wcf2 = new WritableCellFormat();  
    
        int flag = 0;  
        int columnIndex = 0;
        List<String> methodNameList = new ArrayList<String>();
        if (mapField != null && mapField.size() > 0) {  
        	String key = "";
            //循环写入表头  
        	sheet.addCell(new Label(columnIndex, 0, "银生宝批付文件", getHeaderCellStyle()));
        	for(Iterator<String> i = mapField.keySet().iterator();i.hasNext();){
        		key=i.next();
        		sheet.addCell(new Label(columnIndex, 1, mapField.get(key), wcf));
        		methodNameList.add(key);
        		columnIndex++;
        	}
            //判断表中是否有数据  
            if (excelList != null && excelList.size() > 0) {  
                //循环写入表中数据  
                for (int i = 0; i < excelList.size(); i++) {  
                    //转换成map集合{activyName:测试功能,count:2}  
                    Map<String, Object> map = (Map<String, Object>)excelList.get(i);  
                    //循环输出map中的子集：既列值  
                    int j=0;  
                    sheet.addCell(new Label(0,i+2,(String) map.get("BANKNAME"),wcf2));
                    sheet.addCell(new Label(1,i+2,(String) map.get("ACCOUNT_BANK_NO"),wcf2));
                    sheet.addCell(new Label(2,i+2,(String) map.get("ACCOUNT_BANK_CLIENT_NAME"),wcf2));
                    sheet.addCell(new Label(3,i+2,(String) map.get("ACCOUNT_BANK_PROV"),wcf2));
                    sheet.addCell(new Label(4,i+2,(String) map.get("ACCOUNT_BANK_NAME"),wcf2));
                    sheet.addCell(new Label(5,i+2,String.valueOf(((BigDecimal) map.get("ALLMONEY"))==null?"":(BigDecimal) map.get("ALLMONEY")),wcf2));
                    sheet.addCell(new Label(6,i+2,"",wcf2));
                }  
            }else{  
                flag = -1;  
            }  
            //写入Exel工作表  
            wwb.write();  
            //关闭Excel工作薄对象   
            wwb.close();  
            //关闭流  
            os.flush();  
            os.close();  
              
            os =null;  
        }  
	}
	
	
	/**
	 * 导出未结算的列表,获取分页。
	 * @param request
	 * @param tradeForm
	 * @return
	 * @throws BusinessException
	 * @throws Exception
	 */
	
	@RequestMapping(params = "method=getAccountPage")
	public String getAccountPage(HttpServletRequest request, HttpServletResponse response, AccountForm accountForm)
	    throws BusinessException, Exception{
		accountForm.setMerchantNo(request.getParameter("merchantNo"));
		accountForm.setCreatedStart(request.getParameter("createdStart"));
		accountForm.setCreatedEnd(request.getParameter("createdEnd"));
		accountForm.setTrantStart(request.getParameter("trantStart"));
		accountForm.setTrantEnd(request.getParameter("trantEnd"));
		accountForm.setMstart(request.getParameter("mstart"));
		accountForm.setMend(request.getParameter("mend"));
		Page page  = new Page();
		page.setPageSize(Constants.EXCEL_SIZE);
		PageContext context = PageContext.getContext();
		BeanUtils.copyProperties(context, page);
		context.setPagination(true);
		accountService.getNotAccountList(accountForm);
		BeanUtils.copyProperties(page, context);
		request.setAttribute("account",accountForm);
		request.setAttribute("page",page);
		return "account/excel_next_Page";
	}

	
	/**下载未结算记录（分页）
	 * @param request
	 * @param response
	 * @param accountForm
	 * @return
	 * @throws BusinessException
	 * @throws Exception
	 */
	@RequestMapping(params = "method=outUnbalancedAcounnPage")
	public String outUnbalancedAcounnPage(HttpServletRequest request, HttpServletResponse response, AccountForm accountForm)
	    throws BusinessException, Exception{
		accountForm.setMerchantNo(request.getParameter("merchantNo"));
		accountForm.setTrantStart(request.getParameter("trantStart"));
		accountForm.setTrantEnd(request.getParameter("trantEnd"));
		Page page  = new Page();
		page.setPageSize(Constants.EXCEL_SIZE);
		PageContext context = PageContext.getContext();
		BeanUtils.copyProperties(context, page);
		context.setPagination(true);
		accountService.outUnbalancedAcounntExcelList(accountForm);
		BeanUtils.copyProperties(page, context);
		request.setAttribute("account",accountForm);
		request.setAttribute("page",page);
		return "account/excel_unbalanced_page";
	}
	
	
	/**汇总未结算的金额
	 * @param request
	 * @param response
	 * @param accountForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=outUnbalancedAcounntExcel")
	public String outUnbalancedAcounntExcel(HttpServletRequest request,
			HttpServletResponse response,
			AccountForm accountForm)throws Exception {
		accountForm.setMerchantNo(request.getParameter("merchantNo"));
		accountForm.setTrantStart(request.getParameter("trantStart"));
		accountForm.setTrantEnd(request.getParameter("trantEnd"));
		String tPage = request.getParameter("page");
		if (StringUtils.isEmpty(tPage) || !StringUtils.isNumeric(tPage)){
			tPage = "1";
		}
		int currentPage = Integer.valueOf(tPage);
		Page page  = new Page();
		page.setPageSize(Constants.EXCEL_SIZE);
		PageContext context = PageContext.getContext();
		BeanUtils.copyProperties(context, page);
		context.setPagination(true);
		context.setCurrentPage(currentPage);
	    List<HashMap> List=	accountService.outUnbalancedAcounntExcelList(accountForm);
	    request.setAttribute("List", List);
		StringBuffer sb= new StringBuffer();
		response.setContentType("application/vnd.ms-excel");
		String fileNames="下载汇总未结算交易";
		response.setHeader("content-disposition", "attachment;filename="+new String(fileNames.getBytes("GBK"),"iso8859-1")+".csv");
        response.setCharacterEncoding("GBK");
        
        if(List.size()<=0){
        	throw new BusinessException(ExceptionDefine.空指针异常);
        }
		for(Map accView:List){
			sb.append(accView.get("MERCHANT_NO")==null?",":accView.get("MERCHANT_NO").toString()+"\t,");
			sb.append(accView.get("SCOMPANY")==null?",":accView.get("SCOMPANY").toString()+"\t,");
			sb.append(accView.get("TRAN_DATE")==null?",":accView.get("TRAN_DATE").toString()+"\t,");	
			sb.append(accView.get("SA_AMOUNT")==null?",":accView.get("SA_AMOUNT").toString()+"\t,");
			sb.append("\n");
		}
		response.getWriter().println("商户号,商户名称 ,交易日期,本期交易金额(元)");
        response.getWriter().println(sb.toString());
		return null;
	}
	
	
}
