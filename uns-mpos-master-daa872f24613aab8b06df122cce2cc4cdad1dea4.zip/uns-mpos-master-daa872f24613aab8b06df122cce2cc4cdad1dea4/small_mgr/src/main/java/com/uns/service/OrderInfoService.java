package com.uns.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.page.PageContext;
import com.uns.dao.OrderInfoMapper;
import com.uns.model.OrderInfo;

@Service
public class OrderInfoService {
	@Autowired
	public OrderInfoMapper orderInfoMapper;
	
	public List<OrderInfo> selectOrderInfoList(Map<String, Object> param){
		PageContext.initPageSize(20);
		return orderInfoMapper.selectOrderInfoList(param);
	}
	
    public List<Map<String, String>> selectAllList(Map<String, Object> param){
    	PageContext.initPageSize(20);
    	return orderInfoMapper.selectAllList(param);
    }
    
    public Map<String, String> selectSum(Map<String, Object> param){
    	return orderInfoMapper.selectSum(param);
    }
    
    public List<Map<String, String>> selectTerminalNoCur(List<String> param){
    	Map<String, Object> map = new HashMap<String, Object>();
    	map.put("orderList", param);
    	return orderInfoMapper.selectTerminalNoCur(map);
    }
    
    public List<Map<String, String>> selectTerminalNoHis(List<String> param){
    	Map<String, Object> map = new HashMap<String, Object>();
    	map.put("orderList", param);
    	return orderInfoMapper.selectTerminalNoHis(map);
    }
}
