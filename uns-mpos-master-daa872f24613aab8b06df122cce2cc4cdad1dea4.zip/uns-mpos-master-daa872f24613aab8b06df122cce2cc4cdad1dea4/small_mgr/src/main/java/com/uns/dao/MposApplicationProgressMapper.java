package com.uns.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.MposApplicationProgress;
import com.uns.model.MposPhoto;
import com.uns.web.form.ApplicationProgressForm;

@Repository
public interface MposApplicationProgressMapper {
	
    int insert(MposApplicationProgress record);

    int insertSelective(MposApplicationProgress record);
    
    int updateSelective(MposApplicationProgress record);

    List<Map<String,String>> searchApplicationProgressList(ApplicationProgressForm applicationProgressForm);
    
    List queryall();
    
    List findbyid(long applicationProgressId);

	MposApplicationProgress findMposApplicationProgress(Map map);
	

	void deleteByPrimaryKey(String shopperid);
    
}