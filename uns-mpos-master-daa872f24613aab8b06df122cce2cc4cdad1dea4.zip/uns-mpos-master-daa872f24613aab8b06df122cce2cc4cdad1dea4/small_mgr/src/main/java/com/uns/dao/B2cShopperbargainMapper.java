package com.uns.dao;

import java.math.BigDecimal;

import org.springframework.stereotype.Repository;

import com.uns.model.B2cShopperbargain;
import com.uns.model.B2cShopperbargainTemp;
@Repository
public interface B2cShopperbargainMapper extends BaseMapper<Object> {

    int deleteByPrimaryKey(BigDecimal b2cShopperbargainId);

    int insert(B2cShopperbargainTemp record);

    int insertSelective(B2cShopperbargain record);

    B2cShopperbargain selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(B2cShopperbargain record);

    int updateByPrimaryKey(B2cShopperbargain record);

	B2cShopperbargain selectByShopperbiId(Long shopperbiId);

	void updateByShopperId(B2cShopperbargain b2cShopperbargain);

}