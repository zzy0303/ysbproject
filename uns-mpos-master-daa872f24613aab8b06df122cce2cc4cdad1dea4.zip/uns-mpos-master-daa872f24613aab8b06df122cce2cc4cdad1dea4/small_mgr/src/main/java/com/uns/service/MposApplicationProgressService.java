package com.uns.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.common.page.PageContext;
import com.uns.dao.MposApplicationProgressMapper;
import com.uns.model.MposApplicationProgress;
import com.uns.web.form.ApplicationProgressForm;

@Service
public class MposApplicationProgressService {
	@Autowired
	private MposApplicationProgressMapper  progressmapper;
	
	//插入
	 public void insertprogress(MposApplicationProgress progress) {
		 progressmapper.insertSelective(progress);
			
		}
	 
	public  List queryall(){
		 return progressmapper.queryall();
	 }
	
	 public MposApplicationProgress findbyid(long applicationProgressId){
		 List list=progressmapper.findbyid(applicationProgressId);
		 MposApplicationProgress progress=null;
			if(list!=null&&list.size()>0){
				progress=(MposApplicationProgress)list.get(0);
			}
			return progress;  
	 }
	 
	//申请进度信息
		public List<Map<String,String>> searchApplicationProgressList(ApplicationProgressForm aform){
			PageContext.initPageSize(Constants.page_size);
			return progressmapper.searchApplicationProgressList(aform);
		}
	
}
