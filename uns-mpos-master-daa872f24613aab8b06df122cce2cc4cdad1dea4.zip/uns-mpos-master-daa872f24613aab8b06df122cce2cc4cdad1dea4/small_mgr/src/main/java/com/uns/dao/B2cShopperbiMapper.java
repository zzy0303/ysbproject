package com.uns.dao;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.B2cShopperbi;
import com.uns.model.B2cShopperbiTemp;
import com.uns.web.form.ShopPerbiForm;
@Repository
public interface B2cShopperbiMapper extends BaseMapper<Object>{


    int insert(B2cShopperbiTemp record);


	List<HashMap> ShopFormalManageList(ShopPerbiForm mbForm);

	B2cShopperbi selectFormalshoppId(String b2cShopperbiId);


	void updateFormalBankInfo(B2cShopperbiTemp b2cShopperbi);
	
	void updateShoppbiTemp(B2cShopperbiTemp b2cShopperbi);


	List findB2cShopperbiByParenB2cShopperbitId(String parentid);


	void updateByShopperId(B2cShopperbi b2cShopperbi);
    
	
	List<HashMap>ShopFormalList(ShopPerbiForm mbForm);


	List<HashMap> ShopFormaExcelList(ShopPerbiForm mbForm);


	List findB2cShopperbiList();


	int findB2cShopperbiCount();


	Integer findUploadHkCount();


	List findhkList();


	String findShopperbiByNo(String termNo);


	void updateMerchant(B2cShopperbiTemp b2cShopperbi);


	int findOldMerchantCount();


	List<B2cShopperbi> findOldMerchant(Map<String, Object> params);


	void updateOldB2cShopperbi(B2cShopperbi b2cShopperbi);


	void updateQrPayCode(Map map);


	List findShopperBnakInfoList();


	List<String> findAllShopPerbi();


	List findBlacklist(ShopPerbiForm mbForm);


	void updateBlacklist(Map map);
	
	Map findShopperFormalDetails(Long shopperid);

	Integer findOcrCount(Map map);
}