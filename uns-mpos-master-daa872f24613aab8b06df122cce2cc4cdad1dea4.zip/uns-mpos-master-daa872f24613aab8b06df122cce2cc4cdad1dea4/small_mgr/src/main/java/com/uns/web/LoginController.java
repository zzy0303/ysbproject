package com.uns.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.servlet.ModelAndView;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.model.Operator;
import com.uns.service.OperatorService;
import com.uns.service.RoleService;
import com.uns.util.Md5Encrypt;

@Controller
@RequestMapping(value = "/main.htm")
public class LoginController extends BaseController {
	
	@Autowired
	private OperatorService  operatorService;
	
	@Autowired
	private RoleService roleService;

	@SuppressWarnings("finally")
	@RequestMapping(params = "method=login")
	public ModelAndView login(HttpServletRequest request,HttpServletResponse response,String username,
				String password, String verycode ) throws Exception {
		Map<String, String> map=new HashMap<String, String>();
		try {
		// 判断验证码
		    if(StringUtils.isEmpty(verycode)){
		    	throw new BusinessException(ExceptionDefine.验证码错);
		    }
			if (!verycode.equals( request.getSession().getAttribute(Constants.SESSION_VERIFY_CODE))) {
				throw new BusinessException(ExceptionDefine.验证码错);
			}
	
			// 判断用户是否存在
			if (StringUtils.isEmpty(username)) {
				throw new BusinessException(ExceptionDefine.字段不允许为空,new String[]{"用户名"});
			}else{
				map.put("username", username.trim());
			}
			Operator operator = (Operator) operatorService.findOperatorByCode(map);
			
			if (operator == null) {
				throw new BusinessException(ExceptionDefine.用户名不存在);
			}
			// 判断密码
			if (StringUtils.isNotEmpty(password)) {
				String md5passwd = Md5Encrypt.md5(password.trim());
				if (!operator.getPassword().equals(md5passwd)) {
					throw new BusinessException(ExceptionDefine.密码错);
				}
			}
			if (null != operator && operator.getEnabled() == 0) {
				throw new BusinessException(ExceptionDefine.操作员被冻结);
			}
			operator.setLastlogindate(new Date());
		
			operatorService.updateOperator(operator);
			

			request.getSession().setAttribute(Constants.SESSION_KEY_USER,operator);
			request.getRequestDispatcher("/main.htm?method=home").forward(request, response);
			
		} catch (BusinessException ex) {
			Map<String, String> model=new HashMap<String, String>();
			ApplicationContext ctx = WebApplicationContextUtils.getRequiredWebApplicationContext(request.getSession().getServletContext());
			MessageSource messageSource = (MessageSource) ctx.getBean("messageSource");
			BusinessException e = (BusinessException) ex;
			model.put(Constants.ERROR_MESSAGE, e.getErrMessage(messageSource));
			return new ModelAndView("redirect:/", model);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("更新登陆时间出现异常" + e.getMessage());
		}
		return null;	
	}

	/**
	 * 跳转到主界面
	 * 
	 * @return
	 */
	@RequestMapping(params = "method=home")
	public String home(HttpServletRequest request) throws Exception {
		Operator operator = (Operator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
		List listFuncSelect = new ArrayList();
		request.getSession().setAttribute("funcSelect", listFuncSelect);
		//判断登录权限
		Map maps=null;
		if(StringUtils.isNotEmpty(operator.getUsercode())){
			maps=roleService.findFunction1(operator.getUsercode());
		}
		//欢迎页面统计
		Map operatorMap=null;
		if(StringUtils.isNotEmpty(operator.getUserName())){
			operatorMap=operatorService.getOperaterByUserName(operator.getUserName());
		}
		request.getSession().setAttribute("functionTree", maps);
		request.getSession().setAttribute("operatorMap",operatorMap);
		return "home";
	}
	
	/**
	 * 跳转到主界面
	 * 
	 * @return
	 */
	@RequestMapping(params = "method=logout")
	public String logout(HttpServletRequest request) {
		request.getSession().invalidate();
		return "redirect:/";
	}

	@RequestMapping(params = "method=ssoLogin")
	public ModelAndView ssoLogin(HttpServletRequest request, HttpServletResponse response) {
		try {
			if (null != request.getSession().getAttribute(Constants.SESSION_KEY_USER)){
				request.getRequestDispatcher("/main.htm?method=home").forward(request, response);
				return null;
			}
			String mobile = request.getParameter("mobile");
			Operator operator = operatorService.findOperatorByMobile(mobile);
			if (null == operator){
				throw new BusinessException(ExceptionDefine.用户名不存在);
			}
			request.getSession().setAttribute(Constants.SESSION_KEY_USER, operator);
			request.getRequestDispatcher("/main.htm?method=home").forward(request, response);
		} catch (BusinessException ex) {
			Map<String, String> model=new HashMap<String, String>();
			ApplicationContext ctx = WebApplicationContextUtils.getRequiredWebApplicationContext(request.getSession().getServletContext());
			MessageSource messageSource = (MessageSource) ctx.getBean("messageSource");
			BusinessException e = (BusinessException) ex;
			model.put(Constants.ERROR_MESSAGE, e.getErrMessage(messageSource));
			return new ModelAndView("redirect:/", model);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
		}
		return null;
	}
}
					
