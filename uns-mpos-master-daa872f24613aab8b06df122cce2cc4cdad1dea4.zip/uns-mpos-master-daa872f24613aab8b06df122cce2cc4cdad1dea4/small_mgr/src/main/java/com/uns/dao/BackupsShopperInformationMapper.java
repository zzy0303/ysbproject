package com.uns.dao;

import java.math.BigDecimal;

import org.springframework.stereotype.Repository;

import com.uns.model.BackupsShopperInformation;
@Repository
public interface BackupsShopperInformationMapper extends BaseMapper<Object> {


    int insert(BackupsShopperInformation record);

    int insertSelective(BackupsShopperInformation record);
    
    void updateByShopperId(BackupsShopperInformation shopper);
    
    BackupsShopperInformation findByshopperid(BigDecimal shopperid);
}