package com.uns.model;

import java.util.Date;

public class B2cShopperbiTempModify {
    private Long modifyDetailId;

    private Date modifyDetailCreateDate;

    private Date modifyDetailUpdateDate;

    private String modifyDetailCreateUser;

    private String modifyDetailUpdateUser;

    private Long b2cShopperbiId;

    private String scompany;

    private String saddress;

    private String scity;

    private String city;

    private String sprovince;

    private String province;

    private String stel;

    private Long sifpactid;

    private Long shopperidP;

    private String industry;

    private String billProvince;

    private String billProvinceCode;

    private String billCity;

    private String billCityCode;

    private String billAddress;

    private String billName;

    private String remark;

    private String settlementType;

    private String accountBankDictval;

    private String accountBankName;

    private String accountBankProv;

    private String accountBankProvCode;

    private String accountBankCity;

    private String accountBankCityCode;

    private String accountBankClientName;

    private String accountBankNo;

    private String isSupportT0;

    private String creditFee;

    private String debitFee;

    private Double t0Fee;

    private Double t0FixedAmount;

    private Double t0MinAmount;

    private Double t0MaxAmount;

    private Double t0SingleDayLimit;

    private String handIdentityCardPhoto;

    private String frontIdentityCardPhoto;

    private String reverseIdentityCardPhoto;

    private String storePhoto;

    private String creditCardPhoto;

    private String settlementCardPhoto;

    private String signaturePhoto;
    
    private String licensePhoto;
    
    private String livingbodyFacePhoto;//活体正面照
    
    private String livingbodyLeftPhoto;//活体左侧

    private String livingbodyRightPhoto;//活体右侧
    
    private String livingbodyReturnPhoto;//活体回正
    
    private String idCardHeadPhoto;//大头贴
    
    private String s0creditFee;//秒到贷记卡汇率 
    
    private String s0debitFee;//秒到借记卡汇率 
    
    private String d0creditFee;//即时贷记卡汇率 
    
    private String d0debitFee;//即时借记卡汇率 
    
    private String t1creditFee;//T1贷记卡汇率
    
    private String t1debitFee;//T1借记卡汇率 
    
    private String weChatFee;//微信T1
    
    private String weChatD0Fee;//微信DO
    
    private String alipayFee;//支付宝T1
    
    private String alipayD0Fee;//支付宝DO

    private String ylpayFee;//银联
    
    private String shortCutFee;//快捷T1
    
    private String shortCutDoFee;//快捷DO
    
    /**
     * 10月19号添加
     */
    private String shortCutSHDoFee;//快捷SH-D0
    

	private String b2cFee;//b2cT1
    
    private String b2cDoFee;//b2cDo
    
    private String accountBankClientTel;//结算卡开卡人手机号

    public String getAccountBankClientTel() {
        return accountBankClientTel;
    }

    public void setAccountBankClientTel(String accountBankClientTel) {
        this.accountBankClientTel = accountBankClientTel;
    }

    public String getAccountBankNo() {
        return accountBankNo;
    }

    public void setAccountBankNo(String accountBankNo) {
        this.accountBankNo = accountBankNo;
    }

    public String getIdCardHeadPhoto() {
        return idCardHeadPhoto;
    }

    public void setIdCardHeadPhoto(String idCardHeadPhoto) {
        this.idCardHeadPhoto = idCardHeadPhoto;
    }

    public String getLivingbodyFacePhoto() {
        return livingbodyFacePhoto;
    }

    public void setLivingbodyFacePhoto(String livingbodyFacePhoto) {
        this.livingbodyFacePhoto = livingbodyFacePhoto;
    }

    public String getLivingbodyLeftPhoto() {
        return livingbodyLeftPhoto;
    }

    public void setLivingbodyLeftPhoto(String livingbodyLeftPhoto) {
        this.livingbodyLeftPhoto = livingbodyLeftPhoto;
    }

    public String getLivingbodyRightPhoto() {
        return livingbodyRightPhoto;
    }

    public void setLivingbodyRightPhoto(String livingbodyRightPhoto) {
        this.livingbodyRightPhoto = livingbodyRightPhoto;
    }

    public String getLivingbodyReturnPhoto() {
        return livingbodyReturnPhoto;
    }

    public void setLivingbodyReturnPhoto(String livingbodyReturnPhoto) {
        this.livingbodyReturnPhoto = livingbodyReturnPhoto;
    }

    public String getShortCutSHDoFee() {
    	return shortCutSHDoFee;
    }
    
    public void setShortCutSHDoFee(String shortCutSHDoFee) {
    	this.shortCutSHDoFee = shortCutSHDoFee;
    }
	public String getS0creditFee() {
		return s0creditFee;
	}

	public void setS0creditFee(String s0creditFee) {
		this.s0creditFee = s0creditFee;
	}

	public String getS0debitFee() {
		return s0debitFee;
	}

	public void setS0debitFee(String s0debitFee) {
		this.s0debitFee = s0debitFee;
	}

	public String getD0creditFee() {
		return d0creditFee;
	}

	public void setD0creditFee(String d0creditFee) {
		this.d0creditFee = d0creditFee;
	}

	public String getD0debitFee() {
		return d0debitFee;
	}

	public void setD0debitFee(String d0debitFee) {
		this.d0debitFee = d0debitFee;
	}

	public String getT1creditFee() {
		return t1creditFee;
	}

	public void setT1creditFee(String t1creditFee) {
		this.t1creditFee = t1creditFee;
	}

	public String getT1debitFee() {
		return t1debitFee;
	}

	public void setT1debitFee(String t1debitFee) {
		this.t1debitFee = t1debitFee;
	}


	public String getShortCutFee() {
		return shortCutFee;
	}

	public void setShortCutFee(String shortCutFee) {
		this.shortCutFee = shortCutFee;
	}

	public String getShortCutDoFee() {
		return shortCutDoFee;
	}

	public void setShortCutDoFee(String shortCutDoFee) {
		this.shortCutDoFee = shortCutDoFee;
	}

	public String getB2cFee() {
		return b2cFee;
	}

	public void setB2cFee(String b2cFee) {
		this.b2cFee = b2cFee;
	}

	public String getB2cDoFee() {
		return b2cDoFee;
	}

	public void setB2cDoFee(String b2cDoFee) {
		this.b2cDoFee = b2cDoFee;
	}

	public String getYlpayFee() {
        return ylpayFee;
    }

    public void setYlpayFee(String ylpayFee) {
        this.ylpayFee = ylpayFee;
    }

    public String getLicensePhoto() {
		return licensePhoto;
	}

	public void setLicensePhoto(String licensePhoto) {
		this.licensePhoto = licensePhoto;
	}

	public Date getModifyDetailCreateDate() {
		return modifyDetailCreateDate;
	}

	public void setModifyDetailCreateDate(Date modifyDetailCreateDate) {
		this.modifyDetailCreateDate = modifyDetailCreateDate;
	}

	public Date getModifyDetailUpdateDate() {
		return modifyDetailUpdateDate;
	}

	public void setModifyDetailUpdateDate(Date modifyDetailUpdateDate) {
		this.modifyDetailUpdateDate = modifyDetailUpdateDate;
	}

	public String getModifyDetailCreateUser() {
		return modifyDetailCreateUser;
	}

	public void setModifyDetailCreateUser(String modifyDetailCreateUser) {
		this.modifyDetailCreateUser = modifyDetailCreateUser == null?null:modifyDetailCreateUser.trim();
	}

	public String getModifyDetailUpdateUser() {
		return modifyDetailUpdateUser;
	}

	public void setModifyDetailUpdateUser(String modifyDetailUpdateUser) {
		this.modifyDetailUpdateUser = modifyDetailUpdateUser == null?null:modifyDetailUpdateUser.trim();
	}

	public String getScompany() {
        return scompany;
    }

    public void setScompany(String scompany) {
        this.scompany = scompany == null ? null : scompany.trim();
    }

    public String getSaddress() {
        return saddress;
    }

    public void setSaddress(String saddress) {
        this.saddress = saddress == null ? null : saddress.trim();
    }

    public String getScity() {
        return scity;
    }

    public void setScity(String scity) {
        this.scity = scity == null ? null : scity.trim();
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city == null ? null : city.trim();
    }

    public String getSprovince() {
        return sprovince;
    }

    public void setSprovince(String sprovince) {
        this.sprovince = sprovince == null ? null : sprovince.trim();
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province == null ? null : province.trim();
    }

    public String getStel() {
        return stel;
    }

    public void setStel(String stel) {
        this.stel = stel == null ? null : stel.trim();
    }


    public String getIndustry() {
        return industry;
    }

    public void setIndustry(String industry) {
        this.industry = industry == null ? null : industry.trim();
    }

    public String getBillProvince() {
        return billProvince;
    }

    public void setBillProvince(String billProvince) {
        this.billProvince = billProvince == null ? null : billProvince.trim();
    }

    public String getBillProvinceCode() {
        return billProvinceCode;
    }

    public void setBillProvinceCode(String billProvinceCode) {
        this.billProvinceCode = billProvinceCode == null ? null : billProvinceCode.trim();
    }

    public String getBillCity() {
        return billCity;
    }

    public void setBillCity(String billCity) {
        this.billCity = billCity == null ? null : billCity.trim();
    }

    public String getBillCityCode() {
        return billCityCode;
    }

    public void setBillCityCode(String billCityCode) {
        this.billCityCode = billCityCode == null ? null : billCityCode.trim();
    }

    public String getBillAddress() {
        return billAddress;
    }

    public void setBillAddress(String billAddress) {
        this.billAddress = billAddress == null ? null : billAddress.trim();
    }

    public String getBillName() {
        return billName;
    }

    public void setBillName(String billName) {
        this.billName = billName == null ? null : billName.trim();
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getSettlementType() {
        return settlementType;
    }

    public void setSettlementType(String settlementType) {
        this.settlementType = settlementType == null ? null : settlementType.trim();
    }

    public String getAccountBankDictval() {
        return accountBankDictval;
    }

    public void setAccountBankDictval(String accountBankDictval) {
        this.accountBankDictval = accountBankDictval == null ? null : accountBankDictval.trim();
    }

    public String getAccountBankName() {
        return accountBankName;
    }

    public void setAccountBankName(String accountBankName) {
        this.accountBankName = accountBankName == null ? null : accountBankName.trim();
    }

    public String getAccountBankProv() {
        return accountBankProv;
    }

    public void setAccountBankProv(String accountBankProv) {
        this.accountBankProv = accountBankProv == null ? null : accountBankProv.trim();
    }

    public String getAccountBankProvCode() {
        return accountBankProvCode;
    }

    public void setAccountBankProvCode(String accountBankProvCode) {
        this.accountBankProvCode = accountBankProvCode == null ? null : accountBankProvCode.trim();
    }

    public String getAccountBankCity() {
        return accountBankCity;
    }

    public void setAccountBankCity(String accountBankCity) {
        this.accountBankCity = accountBankCity == null ? null : accountBankCity.trim();
    }

    public String getAccountBankCityCode() {
        return accountBankCityCode;
    }

    public void setAccountBankCityCode(String accountBankCityCode) {
        this.accountBankCityCode = accountBankCityCode == null ? null : accountBankCityCode.trim();
    }

    public String getAccountBankClientName() {
        return accountBankClientName;
    }

    public void setAccountBankClientName(String accountBankClientName) {
        this.accountBankClientName = accountBankClientName == null ? null : accountBankClientName.trim();
    }

    public String getIsSupportT0() {
        return isSupportT0;
    }

    public void setIsSupportT0(String isSupportT0) {
        this.isSupportT0 = isSupportT0 == null ? null : isSupportT0.trim();
    }

    public String getHandIdentityCardPhoto() {
        return handIdentityCardPhoto;
    }

    public void setHandIdentityCardPhoto(String handIdentityCardPhoto) {
        this.handIdentityCardPhoto = handIdentityCardPhoto == null ? null : handIdentityCardPhoto.trim();
    }

    public String getFrontIdentityCardPhoto() {
        return frontIdentityCardPhoto;
    }

    public void setFrontIdentityCardPhoto(String frontIdentityCardPhoto) {
        this.frontIdentityCardPhoto = frontIdentityCardPhoto == null ? null : frontIdentityCardPhoto.trim();
    }

    public String getReverseIdentityCardPhoto() {
        return reverseIdentityCardPhoto;
    }

    public void setReverseIdentityCardPhoto(String reverseIdentityCardPhoto) {
        this.reverseIdentityCardPhoto = reverseIdentityCardPhoto == null ? null : reverseIdentityCardPhoto.trim();
    }

    public String getStorePhoto() {
        return storePhoto;
    }

    public void setStorePhoto(String storePhoto) {
        this.storePhoto = storePhoto == null ? null : storePhoto.trim();
    }

    public String getCreditCardPhoto() {
        return creditCardPhoto;
    }

    public void setCreditCardPhoto(String creditCardPhoto) {
        this.creditCardPhoto = creditCardPhoto == null ? null : creditCardPhoto.trim();
    }

    public String getSettlementCardPhoto() {
        return settlementCardPhoto;
    }

    public void setSettlementCardPhoto(String settlementCardPhoto) {
        this.settlementCardPhoto = settlementCardPhoto == null ? null : settlementCardPhoto.trim();
    }

    public String getSignaturePhoto() {
        return signaturePhoto;
    }

    public void setSignaturePhoto(String signaturePhoto) {
        this.signaturePhoto = signaturePhoto == null ? null : signaturePhoto.trim();
    }

	public Long getModifyDetailId() {
		return modifyDetailId;
	}

	public void setModifyDetailId(Long modifyDetailId) {
		this.modifyDetailId = modifyDetailId;
	}

	public Long getB2cShopperbiId() {
		return b2cShopperbiId;
	}

	public void setB2cShopperbiId(Long b2cShopperbiId) {
		this.b2cShopperbiId = b2cShopperbiId;
	}

	public Long getSifpactid() {
		return sifpactid;
	}

	public void setSifpactid(Long sifpactid) {
		this.sifpactid = sifpactid;
	}

	public Long getShopperidP() {
		return shopperidP;
	}

	public void setShopperidP(Long shopperidP) {
		this.shopperidP = shopperidP;
	}

	public Double getT0Fee() {
		return t0Fee;
	}

	public void setT0Fee(Double t0Fee) {
		this.t0Fee = t0Fee;
	}

	public Double getT0FixedAmount() {
		return t0FixedAmount;
	}

	public void setT0FixedAmount(Double t0FixedAmount) {
		this.t0FixedAmount = t0FixedAmount;
	}

	public Double getT0MinAmount() {
		return t0MinAmount;
	}

	public void setT0MinAmount(Double t0MinAmount) {
		this.t0MinAmount = t0MinAmount;
	}

	public Double getT0MaxAmount() {
		return t0MaxAmount;
	}

	public void setT0MaxAmount(Double t0MaxAmount) {
		this.t0MaxAmount = t0MaxAmount;
	}

	public Double getT0SingleDayLimit() {
		return t0SingleDayLimit;
	}

	public void setT0SingleDayLimit(Double t0SingleDayLimit) {
		this.t0SingleDayLimit = t0SingleDayLimit;
	}

	public String getCreditFee() {
		return creditFee;
	}

	public void setCreditFee(String creditFee) {
		this.creditFee = creditFee;
	}

	public String getDebitFee() {
		return debitFee;
	}

	public void setDebitFee(String debitFee) {
		this.debitFee = debitFee;
	}

	public String getWeChatFee() {
		return weChatFee;
	}

	public void setWeChatFee(String weChatFee) {
		this.weChatFee = weChatFee;
	}

	public String getWeChatD0Fee() {
		return weChatD0Fee;
	}

	public void setWeChatD0Fee(String weChatD0Fee) {
		this.weChatD0Fee = weChatD0Fee;
	}

	public String getAlipayFee() {
		return alipayFee;
	}

	public void setAlipayFee(String alipayFee) {
		this.alipayFee = alipayFee;
	}

	public String getAlipayD0Fee() {
		return alipayD0Fee;
	}

	public void setAlipayD0Fee(String alipayD0Fee) {
		this.alipayD0Fee = alipayD0Fee;
	}
    
}