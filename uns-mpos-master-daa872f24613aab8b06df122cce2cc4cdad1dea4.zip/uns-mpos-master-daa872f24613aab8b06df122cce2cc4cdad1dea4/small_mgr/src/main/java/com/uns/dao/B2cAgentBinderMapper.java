package com.uns.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.B2cAgentBinder;
import com.uns.web.form.TerminalForm;
@Repository
public interface B2cAgentBinderMapper extends BaseMapper<Object> {
	List selectAgentBinderList(TerminalForm form);

    int insert(B2cAgentBinder record);

    int insertSelective(B2cAgentBinder record);
    
    int selectAgentBinderCount();
    
    int updateAgentBinder(Map map);
    
    int deleteAgentBinder(Map map);
    
    int delectAgentBinderBytermId(String Terminalid);
    
    B2cAgentBinder selectAgentBinderByid(String terminalid);
    
    int updateAgentBinder(TerminalForm form);
    
    B2cAgentBinder selectAgentnoByTermNo(String termNum);
    //查询代理商下还未绑定的终端
    List<HashMap> selectBinderNum(String agentNo);
}