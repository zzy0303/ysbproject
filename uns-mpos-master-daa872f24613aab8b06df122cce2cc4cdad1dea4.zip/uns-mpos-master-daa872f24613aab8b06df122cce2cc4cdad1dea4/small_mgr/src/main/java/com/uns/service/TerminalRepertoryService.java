package com.uns.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.PageContext;
import com.uns.dao.AgentMapper;
import com.uns.dao.B2cTermBinderMapper;
import com.uns.dao.TerminalHistoryMapper;
import com.uns.model.B2cTermBinder;
import com.uns.model.Operator;
import com.uns.model.TerminalHistory;
import com.uns.util.StringUtils;
import com.uns.web.form.TerminalForm;

@Service
public class TerminalRepertoryService {

	protected final Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	private B2cTermBinderMapper b2cTermBinderMapper;
	
	@Autowired
	private TerminalHistoryMapper terminalHistoryMapper;
	
	@Autowired
	private AgentMapper agentMapper;
	
	public List findTermBatchNo(String termBatchNo) {
		return b2cTermBinderMapper.findTermBatchNo(termBatchNo);
	}

	public void insert(B2cTermBinder term, TerminalHistory terminalHistory) {
		b2cTermBinderMapper.insertSelective(term);
		terminalHistoryMapper.insertSelective(terminalHistory);
	}

	public List findTerminalRepertoryInList(TerminalForm mbForm) {
		PageContext.initPageSize(Constants.page_size);
		return b2cTermBinderMapper.findTerminalRepertoryInList(mbForm);
	}
	
	/**
	 * 终端移库操作
	 * @param sheet
	 */
	public void saveTerminalMove(HSSFSheet sheet,TerminalForm termForm,HttpServletRequest request) throws Exception{
		String shopperidP = termForm.getShopperid_p();
		//递归查询一级代理商
		String fisrtAgentNo = agentMapper.findFisrtAgentByNo(shopperidP);
		Operator  sessionUser=(Operator)request.getSession().getAttribute(Constants.SESSION_KEY_USER); 
		//当前登录商
		Long merchantId = sessionUser.getMerchantid();
		String currentAgentNo = null==merchantId?"":merchantId.toString();
		
		Map<String, Object> map = new HashMap<String,Object>();
		map.put("upperLevelAgentNo", shopperidP);
		map.put("agentNo", shopperidP);
		map.put("fisrtAgentNo", fisrtAgentNo);
		map.put("updateDate", new Date());
		map.put("updateUser", currentAgentNo);
		
		HSSFRow row=null;
		int rowNum=sheet.getLastRowNum()+1;
		int index=0;
		if(rowNum<=Constants.UPLOAD_SIZE) {
			for (int i = 0; i <= rowNum; i++) {
				row = sheet.getRow(i);
				if (row != null) {
					String termNo=row.getCell(0).toString();
					//处理空格
					termNo=termNo.replaceAll(" ", "");
					
					//正则表达式判断终端序列只能是数字
					if(!termNo.matches(Constants.TERM_REGULAR)) {
						index++;
						logger.info("第"+index+"条上传失败！");
						throw new BusinessException(ExceptionDefine.终端序列有非法数字,new String[]{"终端序列第"+index+"条有非法数字，批次提交失败！"});
					}
					if(termNo.length()!=Constants.TERM_SIZE) {
						index++;
						logger.info("第"+index+"条上传失败！");
						throw new BusinessException(ExceptionDefine.终端序列长度错误,new String[]{"终端序列第"+index+"条长度错误，批次提交失败！"});
						
					}
					
					B2cTermBinder b2cTermBinder = b2cTermBinderMapper.selectTermBinderByTermNo(termNo);
					//终端未入库
					if(b2cTermBinder==null) {
						index++;
						logger.info("第"+index+"条上传失败！");
						throw new BusinessException(ExceptionDefine.终端序列未入库,new String[]{"终端序列第"+index+"条含未入库终端，提交失败！"});
					}
					
					if(StringUtils.isTrimNotEmpty(b2cTermBinder.getMerchantNo())) {
						logger.info("第"+index+"条上传失败！");
						throw new BusinessException(ExceptionDefine.终端序列已绑定,new String[]{"终端序列第"+index+"含已绑定终端，提交失败！"});
					}
					
					map.put("termNo", termNo);
					//移库操作
					try {
						index++;
						editTerminalAgentNoByTermNo(map);
					} catch (Exception e) {
						e.printStackTrace();
						throw new BusinessException(ExceptionDefine.终端序列移库失败,new String[]{"系统错误，终端序列移库失败！"});
					}
				}
			
			}
		}else {
			throw new BusinessException(ExceptionDefine.终端移库操作,new String[]{"终端移库条数大于5000条，批次提交失败！"});
		}
		
	}

	public void insertBatchIn(HttpServletRequest request, String batchNo,
			String terminal_type_no, String factory_no,  HSSFSheet sheet) throws Exception {
		HSSFRow row=null;
		Map<String, Object> resultMap = new HashMap<String, Object>();
		int rowNum=sheet.getLastRowNum()+1;
		int index=0;
		if(rowNum<=Constants.UPLOAD_SIZE) {
			for (int i = 0; i <= rowNum; i++) {
				
					row = sheet.getRow(i);
					if (row != null) {
						String termNo=row.getCell(0)==null?"":row.getCell(0).toString();
						//处理空格
						termNo=termNo.replaceAll(" ", "");
 						B2cTermBinder b2cTermBinder = b2cTermBinderMapper.selectTermBinderByTermNo(termNo);
 						if(b2cTermBinder!=null) {
 							index++;
 							logger.info("第"+index+"条上传失败！");
 							throw new BusinessException(ExceptionDefine.终端序列已过库,new String[]{"终端序列第"+index+"条已过库，批次提交失败！"});
 						}
 						//正则表达式判断终端序列只能是数字
						if(!termNo.matches(Constants.TERM_REGULAR)) {
							index++;
							logger.info("第"+index+"条上传失败！");
							throw new BusinessException(ExceptionDefine.终端序列有非法数字,new String[]{"终端序列第"+index+"条有非法数字，批次提交失败！"});
						}
						if(termNo.length()!=Constants.TERM_SIZE) {
							index++;
							logger.info("第"+index+"条上传失败！");
							throw new BusinessException(ExceptionDefine.终端序列长度错误,new String[]{"终端序第"+index+"条列长度错误，批次提交失败！"});
							
						}
						
						if(StringUtils.isTrimNotEmpty(termNo)){
							index++;
							addTerminalRepertoryIn(request,batchNo,terminal_type_no,factory_no,termNo);
						}
						
					}
				
			}
		}else {
			throw new BusinessException(ExceptionDefine.终端操作入库,new String[]{"终端入库条数大于5000条，批次提交失败！"});
		}
		
		
	}
	
	
	/**
	 * 根据终端序列号更改新的所属代理商
	 * @author yang.liu01
	 * @param map
	 */
	public void editTerminalAgentNoByTermNo(Map<String, Object> map) throws Exception {
		b2cTermBinderMapper.editTerminalAgentNoByTermNo(map);
	}
	
	/**添加终端
	 * @param batchNo
	 * @param terminal_type_no
	 * @param factory_no
	 * @param termNo
	 */
	private void addTerminalRepertoryIn(HttpServletRequest request,String batchNo,String terminal_type_no,String factory_no,String termNo) {
		B2cTermBinder term=new B2cTermBinder();
		term.setBatch_no(batchNo);
		term.setTerminal_type_no(terminal_type_no);
		term.setFactory_no(factory_no);
		term.setTermNo(termNo);
		term.setCreateDate(new Date());
		
		Operator  sessionUser=(Operator)request.getSession().getAttribute(Constants.SESSION_KEY_USER);    
		term.setCreate_user(sessionUser==null?"":sessionUser.getUserName());
		
		term.setInventory_status(Constants.CON_NO);//已入库
		term.setUser_status(Constants.CON_NO);//正常
		term.setStatus(Constants.STATUS2);//0已绑定终端 1取消绑定 2 未绑定过终端
		
		
		
		TerminalHistory terminalHistory=new TerminalHistory();
		terminalHistory.setTermNo(termNo);
		terminalHistory.setCreateDate(new Date());
		terminalHistory.setCreateUser(sessionUser==null?"":sessionUser.getUserName());
		terminalHistory.setStatus(Constants.CON_NO);//已入库
		
		insert(term,terminalHistory);
	}

	public List findTerminalRepertoryOutList(TerminalForm mbForm) {
		PageContext.initPageSize(Constants.page_size);
		return b2cTermBinderMapper.findTerminalRepertoryOutList(mbForm);
	}

	public int updateBatchOut(HttpServletRequest request, String batchNo,
			String shopperid_p, HSSFSheet sheet) throws Exception {
		HSSFRow row=null;
		int y=0;
		int rowNum=sheet.getLastRowNum()+1;
		int index=0;
		if(rowNum<=Constants.UPLOAD_SIZE) {
			for (int i = 0; i <= rowNum; i++) {
				row = sheet.getRow(i);
				if (row != null) {
					String termNo=row.getCell(0).toString();
					//处理空格
					termNo=termNo.replaceAll(" ", "");
					//正则表达式判断二维码只能是数字
					if(!termNo.matches(Constants.TERM_REGULAR)) {
						index++;
						logger.info("第"+index+"条上传失败！");
						throw new BusinessException(ExceptionDefine.终端序列有非法数字,new String[]{"终端序列第"+index+"条有非法数字，批次提交失败！"});
					}
					if(termNo.length()!=Constants.TERM_SIZE) {
						index++;
						logger.info("第"+index+"条上传失败！");
						throw new BusinessException(ExceptionDefine.终端序列长度错误,new String[]{"终端序列第"+index+"条长度错误，批次提交失败！"});
						
					}
					//判断该终端是否出库
					Map map=new HashMap();
					map.put("termNo", termNo);
					map.put("batchNo", batchNo);
					B2cTermBinder term=b2cTermBinderMapper.findTermNo(map);
					if(term!=null&&term.getParent_agent_no()!=null){
						index++;
						throw new BusinessException(ExceptionDefine.库存管理,new String[]{"第"+index+"条数据已出库，不能重复出库！"});
						
					}
					try{
						if(StringUtils.isTrimNotEmpty(termNo)){
							index++;
							int x=updateBatchNo(request,batchNo,shopperid_p,termNo);
							if(x>0){
								y++;
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
						logger.info("第"+index+"条上传失败！");
						throw new BusinessException(ExceptionDefine.库存管理,new String[]{"终端出库失败！第"+index+"条数据上传失败！"});
						
					}
				}
			}
		}else{
			throw new BusinessException(ExceptionDefine.终端出库操作,new String[]{"终端出库条数大于5000条，批次提交失败！"});
		}
			
		return y;
		
	}

	private int updateBatchNo(HttpServletRequest request, String batchNo,
			String shopperid_p, String termNo)throws Exception {
		B2cTermBinder term=new B2cTermBinder();
		term.setBatch_no(batchNo);
		term.setTermNo(termNo);
		
		
		Operator  sessionUser=(Operator)request.getSession().getAttribute(Constants.SESSION_KEY_USER);    
		term.setUpdate_user(sessionUser==null?"":sessionUser.getUserName());
		term.setParent_agent_no(shopperid_p);
		term.setOperation(Constants.CON_NO);
		term.setUpdate_date(new Date());
		term.setUpperLevelAgentNo(shopperid_p);
		term.setAgent_no(shopperid_p);
		
		
		TerminalHistory terminalHistory=new TerminalHistory();
		terminalHistory.setTermNo(termNo);
		terminalHistory.setCreateDate(new Date());
		terminalHistory.setCreateUser(sessionUser==null?"":sessionUser.getUserName());
		terminalHistory.setStatus(Constants.STATUS2);//已分配
		
		
		return update(term,terminalHistory);
	}

	private int update(B2cTermBinder term, TerminalHistory terminalHistory)throws Exception {
		int m=b2cTermBinderMapper.updateSelective(term);
		if(m==1){
			terminalHistoryMapper.insertSelective(terminalHistory);
		}
		return m;
		
	}


}
