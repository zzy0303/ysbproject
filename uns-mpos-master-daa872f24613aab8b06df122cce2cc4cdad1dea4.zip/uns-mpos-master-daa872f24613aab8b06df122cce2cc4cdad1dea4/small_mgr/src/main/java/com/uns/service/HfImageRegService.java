package com.uns.service;

import com.uns.dao.B2cShopperbiTempMapper;
import com.uns.dao.MposPhotoTmpMapper;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.MposPhotoTmp;
import com.uns.util.FastJson;
import com.uns.util.HfImageRegUtil;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/3/15
 * @Modifyed By:
 */
@Service
public class HfImageRegService {

    private Logger log = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private MposPhotoTmpMapper mposPhotoTmpMapper;

    public void hfImageReport() {

        List<MposPhotoTmp> mposPhotoTmps = mposPhotoTmpMapper.findHfRegImage();
        for (MposPhotoTmp mposPhotoTmp : mposPhotoTmps) {
            try {
                log.info("图片报备信息:{}", FastJson.toJson(mposPhotoTmp));
                HfImageRegUtil.hfImagesReg(mposPhotoTmp, String.valueOf(mposPhotoTmp.getShopperId()));
            } catch (Exception e) {
                e.printStackTrace();
                continue;
            }
        }
    }
}
