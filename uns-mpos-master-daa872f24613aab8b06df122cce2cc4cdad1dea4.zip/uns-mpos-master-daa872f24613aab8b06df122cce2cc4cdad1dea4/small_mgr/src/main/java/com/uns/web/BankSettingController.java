package com.uns.web;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.ExceptionDefine;
import com.uns.model.Operator;
import com.uns.service.BankSettingService;
import com.uns.web.form.SupportBankForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller("BankSettingController")
@RequestMapping("/bankSetting.htm")
public class BankSettingController extends BaseController{

    @Autowired
    private BankSettingService bankSettingService;

    /**
     * 快捷银行列表
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(params = "method=bankSettingList")
    public String bankSettingList(HttpServletRequest request, HttpServletResponse response)
            throws Exception{
        List<SupportBankForm> supportBankList = null;
        try {
            String showStatus = request.getParameter("showStatus") == null ? Constants.STATUS1 : request.getParameter("showStatus");
            //查询快捷支持银行列表
            supportBankList = bankSettingService.querySupportBankList(showStatus);
            //模版下载地址
            request.setAttribute("modelUrl",ConstantsEnv.BANK_SETTING_URL);

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute(Constants.ERROR_MESSAGE,ExceptionDefine.查询快捷支持银行列表出错);
        }
        request.setAttribute("supportBankList",supportBankList);
        return "bankSetting/bankSettingList";
    }

    /**
     * 跳转导入快捷银行列表页面
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(params = "method=uploadBankFile")
    public String uploadBankFile(HttpServletRequest request, HttpServletResponse response)
            throws Exception{
        return "bankSetting/uploadBankFile";
    }

    /**
     * 添加快捷支持银行列表
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(params = "method=addBankList")
    @FormToken(save = true)
    public ModelAndView addBankList(ModelAndView model, HttpServletRequest request, SupportBankForm supportBankForm)
            throws Exception{
        log.info("导入快捷支持银行列表");
        try {
            //获取操作员
            Operator user = (Operator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
            supportBankForm.setUploadPerson(user.getUserName());
            Map map = bankSettingService.addBankTempList(supportBankForm);
            String message = map.get(Constants.RSP_MSG).toString();
            log.info(message);
            request.setAttribute(Constants.RSP_MSG,message);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute(Constants.ERROR_MESSAGE,ExceptionDefine.导入快捷支持银行文件出错);
        }
        model.setViewName("forward:/bankSetting.htm?method=bankSettingList&showStatus=0");
        return model;
    }

    /**
     * 确认更新快捷支持银行列表
     *
     * @param request
     * @throws Exception
     */
    @RequestMapping(params = "method=affirmBankList")
    @FormToken(save = true)
    public ModelAndView affirmBankList(HttpServletRequest request) throws Exception {
        log.info("确认更新快捷支持银行列表");
        try {
            Map map = bankSettingService.affirmBankList();
            String message = map.get(Constants.RSP_MSG).toString();
            log.info(message);
            request.setAttribute(Constants.RSP_MSG, message);
        } catch (Exception e){
            log.info(ExceptionDefine.更新快捷支持银行列表出错);
            e.printStackTrace();
            request.setAttribute(Constants.ERROR_MESSAGE,ExceptionDefine.更新快捷支持银行列表出错);
        }
        return new ModelAndView("forward:/bankSetting.htm?method=bankSettingList");
    }
}
