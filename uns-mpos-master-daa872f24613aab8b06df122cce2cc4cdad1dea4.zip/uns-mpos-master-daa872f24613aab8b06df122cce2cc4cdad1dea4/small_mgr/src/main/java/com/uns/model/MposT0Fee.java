package com.uns.model;

import java.util.Date;

public class MposT0Fee {
    private Long id;

    private String orderid;

    private String ordertime;

    private Double t0fee;

    private Double t0fixedfee;

    private Date createdate;

    private String careateuser;

    private String rspcode;

    private String rspmsg;

   

    public Double getT0fee() {
		return t0fee;
	}

	public Double getT0fixedfee() {
		return t0fixedfee;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setT0fee(Double t0fee) {
		this.t0fee = t0fee;
	}

	public void setT0fixedfee(Double t0fixedfee) {
		this.t0fixedfee = t0fixedfee;
	}

	public String getOrderid() {
        return orderid;
    }

    public void setOrderid(String orderid) {
        this.orderid = orderid == null ? null : orderid.trim();
    }

    public String getOrdertime() {
        return ordertime;
    }

    public void setOrdertime(String ordertime) {
        this.ordertime = ordertime == null ? null : ordertime.trim();
    }

  

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public String getCareateuser() {
        return careateuser;
    }

    public void setCareateuser(String careateuser) {
        this.careateuser = careateuser == null ? null : careateuser.trim();
    }

    public String getRspcode() {
        return rspcode;
    }

    public void setRspcode(String rspcode) {
        this.rspcode = rspcode == null ? null : rspcode.trim();
    }

    public String getRspmsg() {
        return rspmsg;
    }

    public void setRspmsg(String rspmsg) {
        this.rspmsg = rspmsg == null ? null : rspmsg.trim();
    }
}