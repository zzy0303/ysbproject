package com.uns.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.MposMerchantFee;
@Repository
public interface MposMerchantFeeMapper {

    int insert(MposMerchantFee record);

    int insertSelective(MposMerchantFee record);

	List findMposMerchantFee(String shopperid);
	
	List<HashMap> selectByMerchantId(Long shopperid);

	List findMerchantFeeById(Long shopperid);
	
	List findMerchantFeeByMpos(Long shopperid);

	List findMerchantT1FeeById(Long shopperid);
	
	List<HashMap> selectByMerchantId1(Long shopperid);
	
	void updateByShopperId(MposMerchantFee merchantfee);
	
	List findfee(Long shopperid);
	
	void deleteByPrimaryKey(Long shopperid);
	
	int insertSelectiveTemp(MposMerchantFee record);

	List<HashMap> selectByMerchantIdTemp(Long shopperid);
	
	void updateByShopperIdTemp(MposMerchantFee merchantfee);

	List findfeeTemp(Long shopperid);

	List<MposMerchantFee> findMposMerchantFeeTempByType(Map<String, Object> paramsMap);

	List<MposMerchantFee> findMposMerchantFeeByType(Map<String, Object> paramsMap);

	List<Map<String, String>> findMposRemoteFeeByType(Map<String, Object> paramsMap);

	List findQrPayMerchantFeeList(String shopperid);

	List findQrPayMerchantTempFeeList(String shopperid);

	List findQrPayMerchantFeeList(Long shopperid);

	List findMerchantFeeTempByMposList(Long shopperid);

	void updateFeeProcedure();

	String findQrPayMerchantFee(String shopperid);

	List<MposMerchantFee> findbyshopperid(String shopperid);
	List<MposMerchantFee> findtempbyshopperid(String shopperid);

	void deleteByshopperid(Long shopperid);

	MposMerchantFee findMerchantFeeTChannelType(Map params);

	MposMerchantFee findTempFeeTChannelType(Map params);

	List<Map<String, String>> findMposRemoteFeeByChannelType(Map params);

	void updateByShopperIdFee(MposMerchantFee mposMerchantFee);
	
	String findTempCountByShopperid(String shopperid);
}