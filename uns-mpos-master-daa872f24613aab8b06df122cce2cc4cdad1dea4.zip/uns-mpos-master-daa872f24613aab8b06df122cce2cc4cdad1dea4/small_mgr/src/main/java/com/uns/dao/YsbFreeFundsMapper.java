package com.uns.dao;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.YsbFreeFunds;
import com.uns.web.form.YsbFreeFundsForm;
@Repository
public interface YsbFreeFundsMapper {

    int deleteByPrimaryKey(BigDecimal id);

    int insert(YsbFreeFunds record);

    int insertSelective(YsbFreeFunds record);

    YsbFreeFunds selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(YsbFreeFunds record);

    int updateByPrimaryKey(YsbFreeFunds record);

	List findYsbFreeFundsList(YsbFreeFundsForm mbform);
}