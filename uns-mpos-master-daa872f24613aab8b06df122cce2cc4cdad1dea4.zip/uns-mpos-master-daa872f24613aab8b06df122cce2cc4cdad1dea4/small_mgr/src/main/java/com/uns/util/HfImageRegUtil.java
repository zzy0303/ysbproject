package com.uns.util;

import com.google.gson.Gson;
import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.model.MposPhotoTmp;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author: KaiFeng
 * @Description: 弘付图片上传
 * @Date: 2018/2/2
 * @Modifyed By:
 */
public class HfImageRegUtil {

    private static Logger log = LoggerFactory.getLogger(HfImageRegUtil.class);

    private static String SUCCESS_CODE = "0000";
    private static String RESULT_CODE_00 = "00";

    public static void main (String[] arr){
        MposPhotoTmp mposPhotoTmp = new MposPhotoTmp();
        mposPhotoTmp.setFrontIdentityCardPhoto("3F0824714645491CE053C906A8C009A9");
        mposPhotoTmp.setCreditCardPhoto("3F0751B3EA0C7044E053C806A8C08AC7");
        mposPhotoTmp.setHandIdentityCardPhoto("3F0751D668DE7048E053C806A8C090B6");
        Map<String, String> map = hfImagesReg(mposPhotoTmp, "800222100015404");
        System.out.println("+++++++++++++" + FastJson.toJson(map));
    }

    /**
     * 弘付商户照片报备
     * @param mposPhotoTmp
     * @param merNo 小商户号
     * cardPhoto:身份证 creditPhoto:信用卡 handCardPhoto:手持身份证
     * @return
     */
    public static Map<String, String> hfImagesReg(MposPhotoTmp mposPhotoTmp, String merNo)  {
        Map<String, String> result = new HashMap<>(2);
        result.put("rspCode", SUCCESS_CODE);
        try {
            Map<String, String> param = new HashMap<>(4);
            param.put("cardPhoto", mposPhotoTmp.getFrontIdentityCardPhoto());
            param.put("creditPhoto", mposPhotoTmp.getSettlementCardPhoto());
            param.put("handCardPhoto", mposPhotoTmp.getHandIdentityCardPhoto());
            param.put("behindCardPhoto", mposPhotoTmp.getReverseIdentityCardPhoto());

            log.info("调用image_get获取Hf报备图片请求参数:{}", FastJson.toJson(param));
            Map<String, String> resultMap = HttpClientUtils.postRequestMap(ConstantsEnv.GET_HF_IMAGE_URL, param, HashMap.class);
            log.info("调用image_get获取Hf报备图片返回参数:{}", resultMap.get("rspCode"));

            if (null == resultMap || !SUCCESS_CODE.equals(resultMap.get("rspCode"))){
                result.put("rspCode", "9001");
                result.put("rspMsg", "获取弘付图片报备信息出错");
                return result;
            }

            String images = resultMap.get("images");

            Map<String, String> dataParam = new HashMap(3);
            dataParam.put("orgNo", ConstantsEnv.HF_ORGNO);
            dataParam.put("jg_dealernum", merNo);
            dataParam.put("pic", images);

            log.info("弘付商户照片报备 请求参数:orgNo：{},jg_dealernum：{}", ConstantsEnv.HF_ORGNO, merNo);
            String response = send(dataParam);
            log.info("弘付商户照片报备 返回参数:{}", response);
            resultMap = FastJson.fromJson(response, Map.class);
            if (!RESULT_CODE_00.equals(resultMap.get("msg_code"))){
                result.put("rspCode", "9003");
                result.put("rspMsg", resultMap.get("msg_info"));
                return result;
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.put("rspCode", "9002");
            result.put("rspMsg", "弘付报备商户信息图片出错");
            return result;
        }
        return result;
    }

    /**
     * ********************************************************.<br>
     * [方法] send <br>
     * [描述] TODO(发送请求) <br>
     * [参数] TODO(dataParam 待发送参数) <br>
     * [返回] String <br>
     * ********************************************************.<br>
     */
    public static String send(Map<String, String> dataParam) throws Exception {
        StringBuffer sb = new StringBuffer();
        Socket socket = null;
        OutputStream os = null;
        PrintWriter pw = null;
        InputStream is = null;
        BufferedReader br = null;
        try {
            String resultJson = new Gson().toJson(dataParam);
            socket = new Socket(ConstantsEnv.HF_IMAGE_REG_SOCKET_IP, ConstantsEnv.HF_IMAGE_REG_SOCKET_PORT);
            os = socket.getOutputStream();
            pw = new PrintWriter(new OutputStreamWriter(os, "utf-8"));
            pw.write(resultJson);
            pw.flush();
            socket.shutdownOutput();
            is = socket.getInputStream();
            br = new BufferedReader(new InputStreamReader(is, "utf-8"));
            String info = null;
            while ((info = br.readLine()) != null) {
                sb.append(info);
            }
        } finally {
            try {
                if (br != null) {
                    br.close();
                }
                if (is != null) {
                    is.close();
                }
                if (pw != null) {
                    pw.close();
                }
                if (os != null) {
                    os.close();
                }
                if (socket != null) {
                    socket.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }
}
