package com.uns.model;

import java.util.Date;

public class B2cShopperbiTemp {
	private Long b2cShopperbiId;
	private String scompany;
	private String gateway;
	private String sqcode;
	private String synum;
	private String sicp;
	private String saddress;
	private String szip;
	private String smanager;
	private String srelation;
	private String semail;
	private String stel;
	private String sfax;
	private String shandset;
	private String sqq;
	private String smsn;
	private Long sshopertypeid;
	private String sshopertype;
	private String sdomain;
	private Long sshoppertypeid;
	private String sshoppertype;
	private String scity;
	private String city;
	private String sprovince;
	private String province;
	private Long transactid;
	private String transactsub;
	private String transact;
	private String operid;
	private String oper;
	private Long sifpactid;
	private String sifpact;
	private String spactoperid;
	private String spactoper;
	private Long sisnew;
	private String shoppercallingid;
	private String shoppercalling;
	private Date created;
	private Long shopperid;
	private Long sagentid;
	private Long battalion;
	private Long persentid;
	private Short ifattend;
	private Long ifagent;
	private Short shoppertypeid;
	private String srelationcredno;
	private String legalentity;
	private String srelationcrededate;
	private String legalecredno;
	private String legalecrededate;
	private String synumedate;
	private String licenseno;
	private String taxregisterno;
	private String remark;
	private String upoperid;
	private String upoper;
	private Date updated;
	private String grade;
	private String division;
	private Long shopperidP;
	private String shortname;
	private String levels;
	private Short ifvalid;
	private String accountbankdictval;
	private String accountbankname;
	private String accountbankclientname;
	private String accountbankno;
	private String  accountbankprov;
	private String accountbankother;
	private String istopmerchant;
	private Double topfee;
	private Double minsettlemoney;
	private String settlefrequency;
	private Short opencheckstatus;
	private String termianlstatus;
	private String termialfile;
	private String bankfile;
	private Date worktime;
	private Short isformal;//判断正式表中是否有数据
	private Short isupdateshopper;//判断商户基本信息是否修改
	private Short isupdatebank;//开户信息是否修改
	private String settlementType;
	private String ysbNo;
	private String ysbScompany;
	//复核
	private String 	recheckmerchantflag;
	private String 	recheckaccountflag;
	private String 	recheckterminalflag;
	private String 	recheckmerchantremark;
	private String 	recheckaccountremark;
	private String 	recheckterminalremark;
	//用户名密码
	private String	muserid;
	private String	mpassword;
	
	//20151118 zzh add
	private Long  photoid;
    private String merchantType;
    private String name;
    private String IDNo;
    private String licenseNo;
    private String industry;
    private String billProvince;
    private String billProvinceCode;
    private String billCity;
    private String billCityCode;
    private String billAddress;
    private String billName;
    private String isSupportT0;
    private String isIcApplyT0;
    private Double T0fee;
    private Double T0SingleDayLimit;
    private String accountBankProvCode;
    private String accountBankCity;
    private String accountBankCityCode;
    private String reportResource;
    private String shopperlimit;
    private String evicenumber;
    private String parentid;
    private String factoringno;
    
    private String photoCheckFlag;
    private String photoRecheckFlag;
    private String photoRecheckRemark;
    private String orgNo;
    private Double t1fee;
    private String t0type;
    
	private String  merchantKey;
	
	private String t1type; 
    private Double t0fixedamount; 
    private Double t0topamount; 
    private Double t0additionfee; 
    private Double t0minamount; 
    private Double t0maxamount; 
    private Double t1topamount;
    
    private String  examineresullt;
    
    private String cardType;
    
    private String firstfeecheck;
    private String firstfeecheckresult;
    private String feerecheck;
    private String feerecheckresult;
    
    //初审日期
    private Date checkdate;
    //复审日期
	private Date recheckdate;
	
	private Date bankUpdateDate;
	
	private String currentLocation ;
	private String longitude;
	private String latitude;
	
	private String aiflag;
	
	private Date open_mpos_create_date;
	
    private String qrPayNo;
    private String qrpayMerchantkey;
    
    //申请弘付接口标志
    private String hfflg;
    private String hfpsam;
    private String hfpsamd0;
    
    private String settleType; //默认收款方式 0是快速收款,1是普通收款(数据库新加字段)
    private String fixqrcodecustomername;
    private String isexternalrevenue;
    private Double creditLines;//授信额度(数据库新家字段)
    private String profitOwner;//分论给谁
    private String agentProfitRatio;//服务商分润
    private String merchProfitRatio1;//商户分润1
    private String merchProfitRatio2;//商户分润2
    private String merchProfitRatio3;//商户分润3
	
	private String sex;//性别
	private Date birthday;//生日
	private String nation;//民族
	private String signunit;//身份证签发机关
	private String usefullife;//身份证有效期限
	private String creditBankDictval;//贷记卡银行数据字典
	private String creditBankNo;//贷记卡号
	private String creditBankUsefullife;//贷记卡有效期
	private String creditBankClientName;//贷记卡开卡人姓名
	private String creditBankClientIdNo;//贷记卡开卡人身份证号
	private String creditBankClientTel;//贷记卡开卡人手机号
	private String checkstatus;//审核状态OCR
	private String accountBankClientTel;//结算卡开卡人手机号
	private Date toManualauditDate;//转人工时间
	private String visualCheckStatus;//人工检查状态（OCR）
	private String notPassReason;//人工审核不通过文本原因（OCR）
	private String notPassStep;//人工审核不通过问题步骤（OCR）
	
	private String ifactivated;//激活状态
	private Date ifactivadate;//激活时间

	private String hkflg;//海科标志

	//新加商户认证
	private String licenseName; //营业执照名称
	private String accountBankLineNumber; //联行号
	private String licenseaddRess; //营业执照详细地址
	private String cibFlag; //上游报件开关
	//新加商户用户审核信息
	private String cibShopperId; //上游商户编号
	private String cibShopperName; //上游商户名称
	private String cibShopperSecretkey; //上游商户密钥
	private String wxPayId; //微信支付授权ID
	private String wxPayKey; //微信支付密钥
	private String bankCode; //银行编码
	private String mac; //签名

    public String getMac() {
        return mac;
    }

    public void setMac(String mac) {
        this.mac = mac;
    }

    public String getWxPayId() {
		return wxPayId;
	}

	public void setWxPayId(String wxPayId) {
		this.wxPayId = wxPayId;
	}

	public String getWxPayKey() {
		return wxPayKey;
	}

	public void setWxPayKey(String wxPayKey) {
		this.wxPayKey = wxPayKey;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getCibShopperId() {
		return cibShopperId;
	}

	public void setCibShopperId(String cibShopperId) {
		this.cibShopperId = cibShopperId;
	}

	public String getCibShopperName() {
		return cibShopperName;
	}

	public void setCibShopperName(String cibShopperName) {
		this.cibShopperName = cibShopperName;
	}

	public String getCibShopperSecretkey() {
		return cibShopperSecretkey;
	}

	public void setCibShopperSecretkey(String cibShopperSecretkey) {
		this.cibShopperSecretkey = cibShopperSecretkey;
	}

	public String getCibFlag() {
		return cibFlag;
	}

	public void setCibFlag(String cibFlag) {
		this.cibFlag = cibFlag;
	}

	public String getLicenseName() {
		return licenseName;
	}

	public void setLicenseName(String licenseName) {
		this.licenseName = licenseName;
	}

	public String getAccountBankLineNumber() {
		return accountBankLineNumber;
	}

	public void setAccountBankLineNumber(String accountBankLineNumber) {
		this.accountBankLineNumber = accountBankLineNumber;
	}

	public String getLicenseaddRess() {
		return licenseaddRess;
	}

	public void setLicenseaddRess(String licenseaddRess) {
		this.licenseaddRess = licenseaddRess;
	}

	public String getHkflg() {
		return hkflg;
	}

	public void setHkflg(String hkflg) {
		this.hkflg = hkflg;
	}

	public String getIfactivated() {
		return ifactivated;
	}

	public void setIfactivated(String ifactivated) {
		this.ifactivated = ifactivated;
	}

	public Date getIfactivadate() {
		return ifactivadate;
	}

	public void setIfactivadate(Date ifactivadate) {
		this.ifactivadate = ifactivadate;
	}

	public String getCreditBankClientIdNo() {
		return creditBankClientIdNo;
	}

	public void setCreditBankClientIdNo(String creditBankClientIdNo) {
		this.creditBankClientIdNo = creditBankClientIdNo;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public String getNation() {
		return nation;
	}

	public void setNation(String nation) {
		this.nation = nation;
	}

	public String getSignunit() {
		return signunit;
	}

	public void setSignunit(String signunit) {
		this.signunit = signunit;
	}

	public String getUsefullife() {
		return usefullife;
	}

	public void setUsefullife(String usefullife) {
		this.usefullife = usefullife;
	}

	public String getCreditBankDictval() {
		return creditBankDictval;
	}

	public void setCreditBankDictval(String creditBankDictval) {
		this.creditBankDictval = creditBankDictval;
	}

	public String getCreditBankNo() {
		return creditBankNo;
	}

	public void setCreditBankNo(String creditBankNo) {
		this.creditBankNo = creditBankNo;
	}

	public String getCreditBankUsefullife() {
		return creditBankUsefullife;
	}

	public void setCreditBankUsefullife(String creditBankUsefullife) {
		this.creditBankUsefullife = creditBankUsefullife;
	}

	public String getCreditBankClientName() {
		return creditBankClientName;
	}

	public void setCreditBankClientName(String creditBankClientName) {
		this.creditBankClientName = creditBankClientName;
	}

	public String getCreditBankClientTel() {
		return creditBankClientTel;
	}

	public void setCreditBankClientTel(String creditBankClientTel) {
		this.creditBankClientTel = creditBankClientTel;
	}

	public String getCheckstatus() {
		return checkstatus;
	}

	public void setCheckstatus(String checkstatus) {
		this.checkstatus = checkstatus;
	}

	public String getAccountBankClientTel() {
		return accountBankClientTel;
	}

	public void setAccountBankClientTel(String accountBankClientTel) {
		this.accountBankClientTel = accountBankClientTel;
	}

	public Date getToManualauditDate() {
		return toManualauditDate;
	}

	public void setToManualauditDate(Date toManualauditDate) {
		this.toManualauditDate = toManualauditDate;
	}

	public String getVisualCheckStatus() {
		return visualCheckStatus;
	}

	public void setVisualCheckStatus(String visualCheckStatus) {
		this.visualCheckStatus = visualCheckStatus;
	}

	public String getNotPassReason() {
		return notPassReason;
	}

	public void setNotPassReason(String notPassReason) {
		this.notPassReason = notPassReason;
	}

	public String getNotPassStep() {
		return notPassStep;
	}

	public void setNotPassStep(String notPassStep) {
		this.notPassStep = notPassStep;
	}

	public String getProfitOwner() {
		return profitOwner;
	}

	public void setProfitOwner(String profitOwner) {
		this.profitOwner = profitOwner;
	}

	public String getAgentProfitRatio() {
		return agentProfitRatio;
	}

	public void setAgentProfitRatio(String agentProfitRatio) {
		this.agentProfitRatio = agentProfitRatio;
	}

	public String getMerchProfitRatio1() {
		return merchProfitRatio1;
	}

	public void setMerchProfitRatio1(String merchProfitRatio1) {
		this.merchProfitRatio1 = merchProfitRatio1;
	}

	public String getMerchProfitRatio2() {
		return merchProfitRatio2;
	}

	public void setMerchProfitRatio2(String merchProfitRatio2) {
		this.merchProfitRatio2 = merchProfitRatio2;
	}

	public String getMerchProfitRatio3() {
		return merchProfitRatio3;
	}

	public void setMerchProfitRatio3(String merchProfitRatio3) {
		this.merchProfitRatio3 = merchProfitRatio3;
	}

	public Double getCreditLines() {
		return creditLines;
	}

	public void setCreditLines(Double creditLines) {
		this.creditLines = creditLines;
	}

	public String getSettleType() {
		return settleType;
	}

	public void setSettleType(String settleType) {
		this.settleType = settleType;
	}

	public String getFixqrcodecustomername() {
		return fixqrcodecustomername;
	}

	public void setFixqrcodecustomername(String fixqrcodecustomername) {
		this.fixqrcodecustomername = fixqrcodecustomername;
	}

	public String getIsexternalrevenue() {
		return isexternalrevenue;
	}

	public void setIsexternalrevenue(String isexternalrevenue) {
		this.isexternalrevenue = isexternalrevenue;
	}

	public String getHfpsamd0() {
		return hfpsamd0;
	}

	public void setHfpsamd0(String hfpsamd0) {
		this.hfpsamd0 = hfpsamd0;
	}

	public String getHfflg() {
		return hfflg;
	}
	public void setHfflg(String hfflg) {
		this.hfflg = hfflg;
	}
	public String getHfpsam() {
		return hfpsam;
	}
	public void setHfpsam(String hfpsam) {
		this.hfpsam = hfpsam;
	}
	public String getQrPayNo() {
		return qrPayNo;
	}
	public void setQrPayNo(String qrPayNo) {
		this.qrPayNo = qrPayNo;
	}
	public String getQrpayMerchantkey() {
		return qrpayMerchantkey;
	}
	public void setQrpayMerchantkey(String qrpayMerchantkey) {
		this.qrpayMerchantkey = qrpayMerchantkey;
	}
	public Date getOpen_mpos_create_date() {
		return open_mpos_create_date;
	}
	public void setOpen_mpos_create_date(Date open_mpos_create_date) {
		this.open_mpos_create_date = open_mpos_create_date;
	}
	
	
  	public String getCurrentLocation() {
		return currentLocation;
	}
	public void setCurrentLocation(String currentLocation) {
		this.currentLocation = currentLocation==null?null:currentLocation.trim();
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude==null?null:longitude.trim();
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude==null?null:latitude.trim();
	}
	public String getAiflag() {
		return aiflag;
	}
	public void setAiflag(String aiflag) {
		this.aiflag = aiflag==null?null:aiflag.trim();
	}
	public Date getBankUpdateDate() {
		return bankUpdateDate;
	}
	public void setBankUpdateDate(Date bankUpdateDate) {
		this.bankUpdateDate = bankUpdateDate;
	}
	public Date getCheckdate() {
		return checkdate;
	}
	public void setCheckdate(Date checkdate) {
		this.checkdate = checkdate;
	}
	public Date getRecheckdate() {
		return recheckdate;
	}
	public void setRecheckdate(Date recheckdate) {
		this.recheckdate = recheckdate;
	}
	public String getFirstfeecheck() {
		return firstfeecheck;
	}
	public void setFirstfeecheck(String firstfeecheck) {
		this.firstfeecheck = firstfeecheck==null?null:firstfeecheck.trim();
	}
	public String getFirstfeecheckresult() {
		return firstfeecheckresult;
	}
	public void setFirstfeecheckresult(String firstfeecheckresult) {
		this.firstfeecheckresult = firstfeecheckresult==null?null:firstfeecheckresult.trim();
	}
	public String getFeerecheck() {
		return feerecheck;
	}
	public void setFeerecheck(String feerecheck) {
		this.feerecheck = feerecheck==null?null:feerecheck.trim();
	}
	public String getFeerecheckresult() {
		return feerecheckresult;
	}
	public void setFeerecheckresult(String feerecheckresult) {
		this.feerecheckresult = feerecheckresult==null?null:feerecheckresult.trim();
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType==null?null:cardType.trim();
	}
	public String getExamineresullt() {
		return examineresullt;
	}
	public void setExamineresullt(String examineresullt) {
		this.examineresullt = examineresullt==null?null:examineresullt.trim();
	}
	public Double getT1topamount() {
  		return t1topamount;
  	}
  	public void setT1topamount(Double t1topamount) {
  		this.t1topamount = t1topamount;
  	}
	public String getT1type() {
		return t1type;
	}
	public void setT1type(String t1type) {
		this.t1type = t1type==null?null:t1type.trim();
	}
	public Double getT0fixedamount() {
		return t0fixedamount;
	}
	public void setT0fixedamount(Double t0fixedamount) {
		this.t0fixedamount = t0fixedamount;
	}
	public Double getT0topamount() {
		return t0topamount;
	}
	public void setT0topamount(Double t0topamount) {
		this.t0topamount = t0topamount;
	}
	public Double getT0additionfee() {
		return t0additionfee;
	}
	public void setT0additionfee(Double t0additionfee) {
		this.t0additionfee = t0additionfee;
	}
	public Double getT0minamount() {
		return t0minamount;
	}
	public void setT0minamount(Double t0minamount) {
		this.t0minamount = t0minamount;
	}
	public Double getT0maxamount() {
		return t0maxamount;
	}
	public void setT0maxamount(Double t0maxamount) {
		this.t0maxamount = t0maxamount;
	}
	
	
	
	public String getMerchantKey() {
		return merchantKey;
	}
	public void setMerchantKey(String merchantKey) {
		this.merchantKey = merchantKey==null?null:merchantKey.trim();
	}
	public String getT0type() {
		return t0type;
	}
	public void setT0type(String t0type) {
		this.t0type = t0type==null?null:t0type.trim();
	}
	public Double getT1fee() {
		return t1fee;
	}
	public void setT1fee(Double t1fee) {
		this.t1fee = t1fee;
	}
	public String getOrgNo() {
		return orgNo;
	}
	public void setOrgNo(String orgNo) {
		this.orgNo = orgNo==null?null:orgNo.trim();
	}
	public String getPhotoCheckFlag() {
		return photoCheckFlag;
	}
	public void setPhotoCheckFlag(String photoCheckFlag) {
		this.photoCheckFlag = photoCheckFlag==null?null:photoCheckFlag.trim();
	}
	public String getPhotoRecheckFlag() {
		return photoRecheckFlag;
	}
	public void setPhotoRecheckFlag(String photoRecheckFlag) {
		this.photoRecheckFlag = photoRecheckFlag==null?null:photoRecheckFlag.trim();
	}
	public String getPhotoRecheckRemark() {
		return photoRecheckRemark;
	}
	public void setPhotoRecheckRemark(String photoRecheckRemark) {
		this.photoRecheckRemark = photoRecheckRemark==null?null:photoRecheckRemark.trim();
	}
	public String getFactoringno() {
		return factoringno;
	}
	public void setFactoringno(String factoringno) {
		this.factoringno = factoringno==null?null:factoringno.trim();
	}
	public String getParentid() {
		return parentid;
	}
	public void setParentid(String parentid) {
		this.parentid = parentid==null?null:parentid.trim();
	}
	public String getBillProvinceCode() {
		return billProvinceCode;
	}
	public void setBillProvinceCode(String billProvinceCode) {
		this.billProvinceCode = billProvinceCode==null?null:billProvinceCode.trim();
	}
	public Long getPhotoid() {
		return photoid;
	}
	public void setPhotoid(Long photoid) {
		this.photoid = photoid;
	}
	public String getMerchantType() {
		return merchantType;
	}
	public void setMerchantType(String merchantType) {
		this.merchantType = merchantType==null?null:merchantType.trim();
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name==null?null:name.trim();
	}
	public String getIDNo() {
		return IDNo;
	}
	public void setIDNo(String iDNo) {
		IDNo = iDNo==null?null:iDNo.trim();
	}
	public String getLicenseNo() {
		return licenseNo;
	}
	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo==null?null:licenseNo.trim();
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry==null?null:industry.trim();
	}
	public String getBillProvince() {
		return billProvince;
	}
	public void setBillProvince(String billProvince) {
		this.billProvince = billProvince==null?null:billProvince.trim();
	}
	public String getBillCity() {
		return billCity;
	}
	public void setBillCity(String billCity) {
		this.billCity = billCity==null?null:billCity.trim();
	}
	public String getBillCityCode() {
		return billCityCode;
	}
	public void setBillCityCode(String billCityCode) {
		this.billCityCode = billCityCode==null?null:billCityCode.trim();
	}
	public String getBillAddress() {
		return billAddress;
	}
	public void setBillAddress(String billAddress) {
		this.billAddress = billAddress==null?null:billAddress.trim();
	}
	public String getBillName() {
		return billName;
	}
	public void setBillName(String billName) {
		this.billName = billName==null?null:billName.trim();
	}
	public String getIsSupportT0() {
		return isSupportT0;
	}
	public void setIsSupportT0(String isSupportT0) {
		this.isSupportT0 = isSupportT0==null?null:isSupportT0.trim();
	}
	public String getIsIcApplyT0() {
		return isIcApplyT0;
	}
	public void setIsIcApplyT0(String isIcApplyT0) {
		this.isIcApplyT0 = isIcApplyT0==null?null:isIcApplyT0.trim();
	}
	
	
	
	
	
	public Double getT0fee() {
		return T0fee;
	}
	public void setT0fee(Double t0fee) {
		T0fee = t0fee;
	}
	public Double getT0SingleDayLimit() {
		return T0SingleDayLimit;
	}
	public void setT0SingleDayLimit(Double t0SingleDayLimit) {
		T0SingleDayLimit = t0SingleDayLimit;
	}
	public String getAccountBankProvCode() {
		return accountBankProvCode;
	}
	public void setAccountBankProvCode(String accountBankProvCode) {
		this.accountBankProvCode = accountBankProvCode==null?null:accountBankProvCode.trim();
	}
	public String getAccountBankCity() {
		return accountBankCity;
	}
	public void setAccountBankCity(String accountBankCity) {
		this.accountBankCity = accountBankCity==null?null:accountBankCity.trim();
	}
	public String getAccountBankCityCode() {
		return accountBankCityCode;
	}
	public void setAccountBankCityCode(String accountBankCityCode) {
		this.accountBankCityCode = accountBankCityCode==null?null:accountBankCityCode.trim();
	}
	public String getReportResource() {
		return reportResource;
	}
	public void setReportResource(String reportResource) {
		this.reportResource = reportResource==null?null:reportResource.trim();
	}
	public String getShopperlimit() {
		return shopperlimit;
	}
	public void setShopperlimit(String shopperlimit) {
		this.shopperlimit = shopperlimit==null?null:shopperlimit.trim();
	}
	public String getEvicenumber() {
		return evicenumber;
	}
	public void setEvicenumber(String evicenumber) {
		this.evicenumber = evicenumber==null?null:evicenumber.trim();
	}
	public Long getB2cShopperbiId() {
		return b2cShopperbiId;
	}
	public void setB2cShopperbiId(Long b2cShopperbiId) {
		this.b2cShopperbiId = b2cShopperbiId;
	}
	public String getScompany() {
		return scompany;
	}
	public void setScompany(String scompany) {
		this.scompany = scompany==null?null:scompany.trim();
	}
	public String getGateway() {
		return gateway;
	}
	public void setGateway(String gateway) {
		this.gateway = gateway==null?null:gateway.trim();
	}
	public String getSqcode() {
		return sqcode;
	}
	public void setSqcode(String sqcode) {
		this.sqcode = sqcode==null?null:sqcode.trim();
	}
	public String getSynum() {
		return synum;
	}
	public void setSynum(String synum) {
		this.synum = synum==null?null:synum.trim();
	}
	public String getSicp() {
		return sicp;
	}
	public void setSicp(String sicp) {
		this.sicp = sicp==null?null:sicp.trim();
	}
	public String getSaddress() {
		return saddress;
	}
	public void setSaddress(String saddress) {
		this.saddress = saddress==null?null:saddress.trim();
	}
	public String getSzip() {
		return szip;
	}
	public void setSzip(String szip) {
		this.szip = szip==null?null:szip.trim();
	}
	public String getSmanager() {
		return smanager;
	}
	public void setSmanager(String smanager) {
		this.smanager = smanager==null?null:smanager.trim();
	}
	public String getSrelation() {
		return srelation;
	}
	public void setSrelation(String srelation) {
		this.srelation = srelation==null?null:srelation.trim();
	}
	public String getSemail() {
		return semail;
	}
	public void setSemail(String semail) {
		this.semail = semail==null?null:semail.trim();
	}
	public String getStel() {
		return stel;
	}
	public void setStel(String stel) {
		this.stel = stel==null?null:stel.trim();
	}
	public String getSfax() {
		return sfax;
	}
	public void setSfax(String sfax) {
		this.sfax = sfax==null?null:sfax.trim();
	}
	public String getShandset() {
		return shandset;
	}
	public void setShandset(String shandset) {
		this.shandset = shandset==null?null:shandset.trim();
	}
	public String getSqq() {
		return sqq;
	}
	public void setSqq(String sqq) {
		this.sqq = sqq==null?null:sqq.trim();
	}
	public String getSmsn() {
		return smsn;
	}
	public void setSmsn(String smsn) {
		this.smsn = smsn==null?null:smsn.trim();
	}
	public Long getSshopertypeid() {
		return sshopertypeid;
	}
	public void setSshopertypeid(Long sshopertypeid) {
		this.sshopertypeid = sshopertypeid;
	}
	public String getSshopertype() {
		return sshopertype;
	}
	public void setSshopertype(String sshopertype) {
		this.sshopertype = sshopertype==null?null:sshopertype.trim();
	}
	public String getSdomain() {
		return sdomain;
	}
	public void setSdomain(String sdomain) {
		this.sdomain = sdomain==null?null:sdomain.trim();
	}
	public Long getSshoppertypeid() {
		return sshoppertypeid;
	}
	public void setSshoppertypeid(Long sshoppertypeid) {
		this.sshoppertypeid = sshoppertypeid;
	}
	public String getSshoppertype() {
		return sshoppertype;
	}
	public void setSshoppertype(String sshoppertype) {
		this.sshoppertype = sshoppertype==null?null:sshoppertype.trim();
	}
	public String getScity() {
		return scity;
	}
	public void setScity(String scity) {
		this.scity = scity==null?null:scity.trim();
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city==null?null:city.trim();
	}
	public String getSprovince() {
		return sprovince;
	}
	public void setSprovince(String sprovince) {
		this.sprovince = sprovince==null?null:sprovince.trim();
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province==null?null:province.trim();
	}
	public Long getTransactid() {
		return transactid;
	}
	public void setTransactid(Long transactid) {
		this.transactid = transactid;
	}
	public String getTransactsub() {
		return transactsub;
	}
	public void setTransactsub(String transactsub) {
		this.transactsub = transactsub==null?null:transactsub.trim();
	}
	public String getTransact() {
		return transact;
	}
	public void setTransact(String transact) {
		this.transact = transact==null?null:transact.trim();
	}
	public String getOperid() {
		return operid;
	}
	public void setOperid(String operid) {
		this.operid = operid==null?null:operid.trim();
	}
	public String getOper() {
		return oper;
	}
	public void setOper(String oper) {
		this.oper = oper==null?null:oper.trim();
	}
	public Long getSifpactid() {
		return sifpactid;
	}
	public void setSifpactid(Long sifpactid) {
		this.sifpactid = sifpactid;
	}
	public String getSifpact() {
		return sifpact;
	}
	public void setSifpact(String sifpact) {
		this.sifpact = sifpact==null?null:sifpact.trim();
	}
	public String getSpactoperid() {
		return spactoperid;
	}
	public void setSpactoperid(String spactoperid) {
		this.spactoperid = spactoperid==null?null:spactoperid.trim();
	}
	public String getSpactoper() {
		return spactoper;
	}
	public void setSpactoper(String spactoper) {
		this.spactoper = spactoper==null?null:spactoper.trim();
	}
	public Long getSisnew() {
		return sisnew;
	}
	public void setSisnew(Long sisnew) {
		this.sisnew = sisnew;
	}
	public String getShoppercallingid() {
		return shoppercallingid;
	}
	public void setShoppercallingid(String shoppercallingid) {
		this.shoppercallingid = shoppercallingid==null?null:shoppercallingid.trim();
	}
	public String getShoppercalling() {
		return shoppercalling;
	}
	public void setShoppercalling(String shoppercalling) {
		this.shoppercalling = shoppercalling==null?null:shoppercalling.trim();
	}
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	public Long getShopperid() {
		return shopperid;
	}
	public void setShopperid(Long shopperid) {
		this.shopperid = shopperid;
	}
	public Long getSagentid() {
		return sagentid;
	}
	public void setSagentid(Long sagentid) {
		this.sagentid = sagentid;
	}
	public Long getBattalion() {
		return battalion;
	}
	public void setBattalion(Long battalion) {
		this.battalion = battalion;
	}
	public Long getPersentid() {
		return persentid;
	}
	public void setPersentid(Long persentid) {
		this.persentid = persentid;
	}
	public Short getIfattend() {
		return ifattend;
	}
	public void setIfattend(Short ifattend) {
		this.ifattend = ifattend;
	}
	public Long getIfagent() {
		return ifagent;
	}
	public void setIfagent(Long ifagent) {
		this.ifagent = ifagent;
	}
	public Short getShoppertypeid() {
		return shoppertypeid;
	}
	public void setShoppertypeid(Short shoppertypeid) {
		this.shoppertypeid = shoppertypeid;
	}
	public String getSrelationcredno() {
		return srelationcredno;
	}
	public void setSrelationcredno(String srelationcredno) {
		this.srelationcredno = srelationcredno==null?null:srelationcredno;
	}
	public String getLegalentity() {
		return legalentity;
	}
	public void setLegalentity(String legalentity) {
		this.legalentity = legalentity==null?null:legalentity.trim();
	}
	public String getSrelationcrededate() {
		return srelationcrededate;
	}
	public void setSrelationcrededate(String srelationcrededate) {
		this.srelationcrededate = srelationcrededate==null?null:srelationcrededate.trim();
	}
	public String getLegalecredno() {
		return legalecredno;
	}
	public void setLegalecredno(String legalecredno) {
		this.legalecredno = legalecredno==null?null:legalecredno.trim();
	}
	public String getLegalecrededate() {
		return legalecrededate;
	}
	public void setLegalecrededate(String legalecrededate) {
		this.legalecrededate = legalecrededate==null?null:legalecrededate.trim();
	}
	public String getSynumedate() {
		return synumedate;
	}
	public void setSynumedate(String synumedate) {
		this.synumedate = synumedate==null?null:synumedate.trim();
	}
	public String getLicenseno() {
		return licenseno;
	}
	public void setLicenseno(String licenseno) {
		this.licenseno = licenseno==null?null:licenseno.trim();
	}
	public String getTaxregisterno() {
		return taxregisterno;
	}
	public void setTaxregisterno(String taxregisterno) {
		this.taxregisterno = taxregisterno==null?null:taxregisterno.trim();
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark==null?null:remark.trim();
	}
	public String getUpoperid() {
		return upoperid;
	}
	public void setUpoperid(String upoperid) {
		this.upoperid = upoperid==null?null:upoperid.trim();
	}
	public String getUpoper() {
		return upoper;
	}
	public void setUpoper(String upoper) {
		this.upoper = upoper==null?null:upoper.trim();
	}
	public Date getUpdated() {
		return updated;
	}
	public void setUpdated(Date updated) {
		this.updated = updated;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade==null?null:grade.trim();
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division==null?null:division.trim();
	}
	public Long getShopperidP() {
		return shopperidP;
	}
	public void setShopperidP(Long shopperidP) {
		this.shopperidP = shopperidP;
	}
	public String getShortname() {
		return shortname;
	}
	public void setShortname(String shortname) {
		this.shortname = shortname==null?null:shortname.trim();
	}
	public String getLevels() {
		return levels;
	}
	public void setLevels(String levels) {
		this.levels = levels==null?null:levels.trim();
	}
	public Short getIfvalid() {
		return ifvalid;
	}
	public void setIfvalid(Short ifvalid) {
		this.ifvalid = ifvalid;
	}
	public String getAccountbankdictval() {
		return accountbankdictval;
	}
	public void setAccountbankdictval(String accountbankdictval) {
		this.accountbankdictval = accountbankdictval==null?null:accountbankdictval.trim();
	}
	public String getAccountbankname() {
		return accountbankname;
	}
	public void setAccountbankname(String accountbankname) {
		this.accountbankname = accountbankname==null?null:accountbankname.trim();
	}
	public String getAccountbankclientname() {
		return accountbankclientname;
	}
	public void setAccountbankclientname(String accountbankclientname) {
		this.accountbankclientname = accountbankclientname==null?null:accountbankclientname.trim();
	}
	public String getAccountbankno() {
		return accountbankno;
	}
	public void setAccountbankno(String accountbankno) {
		this.accountbankno = accountbankno==null?"":accountbankno.trim();
	}
	public String getAccountbankprov() {
		return accountbankprov;
	}
	public void setAccountbankprov(String accountbankprov) {
		this.accountbankprov = accountbankprov==null?null:accountbankprov.trim();
	}
	public String getAccountbankother() {
		return accountbankother;
	}
	public void setAccountbankother(String accountbankother) {
		this.accountbankother = accountbankother==null?null:accountbankother.trim();
	}
	public String getIstopmerchant() {
		return istopmerchant;
	}
	public void setIstopmerchant(String istopmerchant) {
		this.istopmerchant = istopmerchant==null?null:istopmerchant.trim();
	}
	public Double getTopfee() {
		return topfee;
	}
	public void setTopfee(Double topfee) {
		this.topfee = topfee;
	}
	public Double getMinsettlemoney() {
		return minsettlemoney;
	}
	public void setMinsettlemoney(Double minsettlemoney) {
		this.minsettlemoney = minsettlemoney;
	}
	public String getSettlefrequency() {
		return settlefrequency;
	}
	public void setSettlefrequency(String settlefrequency) {
		this.settlefrequency = settlefrequency==null?null:settlefrequency.trim();
	}
	public Short getOpencheckstatus() {
		return opencheckstatus;
	}
	public void setOpencheckstatus(Short opencheckstatus) {
		this.opencheckstatus = opencheckstatus;
	}

	public String getTermianlstatus() {
		return termianlstatus;
	}
	public void setTermianlstatus(String termianlstatus) {
		this.termianlstatus = termianlstatus==null?null:termianlstatus.trim();
	}
	public String getTermialfile() {
		return termialfile;
	}
	public void setTermialfile(String termialfile) {
		this.termialfile = termialfile==null?null:termialfile.trim();
	}
	public String getBankfile() {
		return bankfile;
	}
	public void setBankfile(String bankfile) {
		this.bankfile = bankfile==null?null:bankfile.trim();
	}
	public Date getWorktime() {
		return worktime;
	}
	public void setWorktime(Date worktime) {
		this.worktime = worktime;
	}
	public Short getIsformal() {
		return isformal;
	}
	public void setIsformal(Short isformal) {
		this.isformal = isformal;
	}
	public Short getIsupdateshopper() {
		return isupdateshopper;
	}
	public void setIsupdateshopper(Short isupdateshopper) {
		this.isupdateshopper = isupdateshopper;
	}
	public Short getIsupdatebank() {
		return isupdatebank;
	}
	public void setIsupdatebank(Short isupdatebank) {
		this.isupdatebank = isupdatebank;
	}
	
	public String getSettlementType() {
		return settlementType;
	}
	public void setSettlementType(String settlementType) {
		this.settlementType = settlementType==null?null:settlementType.trim();
	}
	public String getYsbNo() {
		return ysbNo;
	}
	public void setYsbNo(String ysbNo) {
		this.ysbNo = ysbNo==null?null:ysbNo.trim();
	}
	public String getYsbScompany() {
		return ysbScompany;
	}
	public void setYsbScompany(String ysbScompany) {
		this.ysbScompany = ysbScompany==null?null:ysbScompany.trim();
	}
	public String getRecheckmerchantflag() {
		return recheckmerchantflag;
	}
	public void setRecheckmerchantflag(String recheckmerchantflag) {
		this.recheckmerchantflag = recheckmerchantflag==null?null:recheckmerchantflag.trim();
	}
	public String getRecheckaccountflag() {
		return recheckaccountflag;
	}
	public void setRecheckaccountflag(String recheckaccountflag) {
		this.recheckaccountflag = recheckaccountflag==null?null:recheckaccountflag.trim();
	}
	public String getRecheckterminalflag() {
		return recheckterminalflag;
	}
	public void setRecheckterminalflag(String recheckterminalflag) {
		this.recheckterminalflag = recheckterminalflag==null?null:recheckterminalflag.trim();
	}
	public String getRecheckmerchantremark() {
		return recheckmerchantremark;
	}
	public void setRecheckmerchantremark(String recheckmerchantremark) {
		this.recheckmerchantremark = recheckmerchantremark==null?null:recheckmerchantremark.trim();
	}
	public String getRecheckaccountremark() {
		return recheckaccountremark;
	}
	public void setRecheckaccountremark(String recheckaccountremark) {
		this.recheckaccountremark = recheckaccountremark==null?null:recheckaccountremark.trim();
	}
	public String getRecheckterminalremark() {
		return recheckterminalremark;
	}
	public void setRecheckterminalremark(String recheckterminalremark) {
		this.recheckterminalremark = recheckterminalremark==null?null:recheckterminalremark.trim();
	}
	public String getMuserid() {
		return muserid;
	}
	public void setMuserid(String muserid) {
		this.muserid = muserid==null?null:muserid.trim();
	}
	public String getMpassword() {
		return mpassword;
	}
	public void setMpassword(String mpassword) {
		this.mpassword = mpassword==null?null:mpassword.trim();
	}
	
}