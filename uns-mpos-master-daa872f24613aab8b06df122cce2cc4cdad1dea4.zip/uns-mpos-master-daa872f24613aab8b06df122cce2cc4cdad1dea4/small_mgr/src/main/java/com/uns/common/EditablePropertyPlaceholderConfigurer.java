package com.uns.common;

import java.util.Properties;

import org.jpos.iso.ISOUtil;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;

import com.uns.util.AESUtils;


/**
 * 便于对资源文件的内容进行修改,比如数据库访问密码
 * @author Administrator
 *
 */
public class EditablePropertyPlaceholderConfigurer extends PropertyPlaceholderConfigurer{

	
	private static final String DB_PWD_KEY = "datasource.password";
	
	@Override
	protected void convertProperties(Properties props) {
		String _pass = props.getProperty(DB_PWD_KEY);
		byte[] _bsPass = null;
		
		try {
			_bsPass = new AESUtils().decryptor(ISOUtil.hex2byte(_pass));
			props.setProperty(DB_PWD_KEY,new String(_bsPass,"UTF-8"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
