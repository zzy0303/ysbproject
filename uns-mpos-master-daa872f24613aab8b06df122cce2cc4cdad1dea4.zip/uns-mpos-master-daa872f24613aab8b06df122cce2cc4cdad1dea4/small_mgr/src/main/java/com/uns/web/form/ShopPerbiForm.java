package com.uns.web.form;


import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.springframework.web.multipart.MultipartFile;


public class ShopPerbiForm {
	
	private String stel;
	private Long shopperidP;
	private String shopperid;
	private String scompany;
	private String shopperidq;
	private String shopperNameq;
	private String shoppercallingidq;
	private String transactidq;
	private String sagentidq;
	private String belongsAgentq;
	private Long   shopperid_q;
	private String createdStart;
	private String createdEnd;
	private String ifacticreatedStart;
	private String ifacticreatedEnd;
	private String bargainedateStart;
	private String bargainedateEnd;
	private String bargainbdates;
	private String bargainedates; 
	private String writebargains;
	private String effectdt;
	private String belongsAgent;
	private Long shopperid_p;
	private MultipartFile stdFileNames;
	private MultipartFile addFileNames;
	private String stdfilenamesHidden;
	private String addFileNamesHidden;
	private MultipartFile termialfiles;
	private MultipartFile bankfiles;
	private String termialfilesHidden;
	private String bankfilesHidden;
	private Long currentid;//当前代理商id
	private String taskidq;
	private String posCodeq;
	private String tranStart;
	private String tranEnd;
	private String settleStart;
	private String settleEnd;
	private String cardtypeq;
	private String tranStatusq;
	private String taskamountq;
	private String terminalNum;
	private String  hiddenNum;
	private String opencheckstatus;
	private String ifvalid;
	private String sifpactid;
	private String ifactivated;
	private String sprovince;
	private String province;
	private String city;
	private String termianlstatus;
	private Date worktime;
	private Short isformal;//判断正式表中是否有数据
	private Short isupdateshopper;//判断商户基本信息是否修改
	private Short isupdatebank;//开户信息是否修改
	private Long basecost;
	
	//复核
	private String 	recheckmerchantflag;
	private String 	recheckaccountflag;
	private String 	recheckterminalflag;
	private String 	recheckmerchantremark;
	private String 	recheckaccountremark;
	private String 	recheckterminalremark;

	//zzh add
	private MultipartFile handidentitycardphoto;
	private MultipartFile frontidentitycardphoto;
	private MultipartFile reverseidentitycardphoto;
	private MultipartFile storephoto;
	private MultipartFile instorephoto;
	private MultipartFile checkstandphoto;
	private MultipartFile signaturephoto;
	private MultipartFile licensephoto;
	private MultipartFile  creditCardPhoto;
	private MultipartFile  settlementCardPhoto;
	private MultipartFile  fixPhoto;
	private MultipartFile  livingbodyFacePhoto;
	private MultipartFile  livingbodyLeftPhoto;
	private MultipartFile  livingbodyRightPhoto;
	private MultipartFile  livingbodyReturnPhoto;
	private MultipartFile  idCardHeadPhoto;//大头贴
	
	private String telq;
	private String examineresullt;
	
	private String firstfeecheck;
	private String firstfeecheckresult;
	private String feerecheck;
	private String feerecheckresult;
	
	private String photoCheckFlag;
    private String photoRecheckFlag;
    private String photoRecheckRemark;
	private String evicenumber;
	private String parentid;
	
	
	private String firstVerify;
	private String lastVerify;
	private String remark;
	private String merchantNo;
	private String termNo;
	private String orgNo;
	private String open_create_start;
	private String open_create_end;
	
	private boolean checkAgents;
	
	private String recreatedStart;
	private String recreatedEnd;
	
	//费率
	private String weChatFee;
	private String weChatD0Fee;
	private String alipayFee;
	private String alipayD0Fee;
	private String ylpayFee;
	private String ylpayD0Fee;
	//无卡费率
	private String shortCut;//快捷汇率
	private String shortCutDo;//快捷DO汇率
	private String b2c;//b2c汇率
	private String b2cDo;//b2cDO汇率
	private String shortCutSHDo;//快捷速惠D0
	
	private String s0creditFee;
	private String s0debitFee;
	private String s0fixAmount;
	private String d0creditFee;
	private String d0debitFee;
	private String t0fixAmount;
	private String t1creditFee;
	private String t1debitFee;

	private String agentProfitRatio;
	private String merchRatio1;
	private String merchRatio2_1;
	private String merchRatio2_2;
	private String merchRatio3_1;
	private String merchRatio3_2;
	private String merchRatio3_3;

	/**
	 * OCR相关
	 */
	private String updatedStart;//修改时间起始
	private String updatedEnd;//修改时间终止
	private String recheckDateStart;//审核时间起始
	private String recheckDateEnd;//审核时间终止
	private String checkstatus;//审核状态
    private String reportResource;//报件来源
	private String[] notPassStep;//OCR错误步骤
	private String notPassReason;//不通过原因
	private String visualCheckStatus;//人工检查状态
    
    private String haveInviteCodeP;//是否裂变商户

	private String merchantType; //商户类型
	//新加商户用户审核信息
	private String cibShopperId; //上游商户编号
	private String cibShopperName; //上游商户名称
	private String cibShopperSecretkey; //上游商户密钥
	private String wxPayId; //微信支付授权ID
	private String wxPayKey; //微信支付密钥
	private String bankCode; //银行编码

	public String getWxPayId() {
		return wxPayId;
	}

	public void setWxPayId(String wxPayId) {
		this.wxPayId = wxPayId;
	}

	public String getWxPayKey() {
		return wxPayKey;
	}

	public void setWxPayKey(String wxPayKey) {
		this.wxPayKey = wxPayKey;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getMerchantType() {
		return merchantType;
	}

	public void setMerchantType(String merchantType) {
		this.merchantType = merchantType;
	}

	public String getCibShopperId() {
		return cibShopperId;
	}

	public void setCibShopperId(String cibShopperId) {
		this.cibShopperId = cibShopperId;
	}

	public String getCibShopperName() {
		return cibShopperName;
	}

	public void setCibShopperName(String cibShopperName) {
		this.cibShopperName = cibShopperName;
	}

	public String getCibShopperSecretkey() {
		return cibShopperSecretkey;
	}

	public void setCibShopperSecretkey(String cibShopperSecretkey) {
		this.cibShopperSecretkey = cibShopperSecretkey;
	}

	public String getHaveInviteCodeP() {
        return haveInviteCodeP;
    }

    public void setHaveInviteCodeP(String haveInviteCodeP) {
        this.haveInviteCodeP = haveInviteCodeP;
    }

    public String getStel() {
		return stel;
	}

	public void setStel(String stel) {
		this.stel = StringUtils.trim(stel);
	}

	public Long getShopperidP() {
		return shopperidP;
	}

	public void setShopperidP(Long shopperidP) {
		this.shopperidP = shopperidP;
	}

	public String getScompany() {
		return scompany;
	}

	public void setScompany(String scompany) {
		this.scompany = StringUtils.trim(scompany);
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public MultipartFile getIdCardHeadPhoto() {
		return idCardHeadPhoto;
	}

	public void setIdCardHeadPhoto(MultipartFile idCardHeadPhoto) {
		this.idCardHeadPhoto = idCardHeadPhoto;
	}

	public String getVisualCheckStatus() {
		return visualCheckStatus;
	}

	public void setVisualCheckStatus(String visualCheckStatus) {
		this.visualCheckStatus = visualCheckStatus;
	}

	public String getNotPassReason() {
		return notPassReason;
	}

	public void setNotPassReason(String notPassReason) {
		this.notPassReason = notPassReason;
	}

	public String[] getNotPassStep() {
		return notPassStep;
	}

	public void setNotPassStep(String[] notPassStep) {
		this.notPassStep = notPassStep;
	}

	public String getAgentProfitRatio() {
		return agentProfitRatio;
	}

	public void setAgentProfitRatio(String agentProfitRatio) {
		this.agentProfitRatio = agentProfitRatio;
	}

	public String getMerchRatio1() {
		return merchRatio1;
	}

	public void setMerchRatio1(String merchRatio1) {
		this.merchRatio1 = merchRatio1;
	}

	public String getMerchRatio2_1() {
		return merchRatio2_1;
	}

	public void setMerchRatio2_1(String merchRatio2_1) {
		this.merchRatio2_1 = merchRatio2_1;
	}

	public String getMerchRatio2_2() {
		return merchRatio2_2;
	}

	public void setMerchRatio2_2(String merchRatio2_2) {
		this.merchRatio2_2 = merchRatio2_2;
	}

	public String getMerchRatio3_1() {
		return merchRatio3_1;
	}

	public void setMerchRatio3_1(String merchRatio3_1) {
		this.merchRatio3_1 = merchRatio3_1;
	}

	public String getMerchRatio3_2() {
		return merchRatio3_2;
	}

	public void setMerchRatio3_2(String merchRatio3_2) {
		this.merchRatio3_2 = merchRatio3_2;
	}

	public String getMerchRatio3_3() {
		return merchRatio3_3;
	}

	public void setMerchRatio3_3(String merchRatio3_3) {
		this.merchRatio3_3 = merchRatio3_3;
	}

	public MultipartFile getLivingbodyFacePhoto() {
		return livingbodyFacePhoto;
	}

	public void setLivingbodyFacePhoto(MultipartFile livingbodyFacePhoto) {
		this.livingbodyFacePhoto = livingbodyFacePhoto;
	}

	public MultipartFile getLivingbodyLeftPhoto() {
		return livingbodyLeftPhoto;
	}

	public void setLivingbodyLeftPhoto(MultipartFile livingbodyLeftPhoto) {
		this.livingbodyLeftPhoto = livingbodyLeftPhoto;
	}

	public MultipartFile getLivingbodyRightPhoto() {
		return livingbodyRightPhoto;
	}

	public void setLivingbodyRightPhoto(MultipartFile livingbodyRightPhoto) {
		this.livingbodyRightPhoto = livingbodyRightPhoto;
	}

	public MultipartFile getLivingbodyReturnPhoto() {
		return livingbodyReturnPhoto;
	}

	public void setLivingbodyReturnPhoto(MultipartFile livingbodyReturnPhoto) {
		this.livingbodyReturnPhoto = livingbodyReturnPhoto;
	}

	public String getReportResource() {
		return reportResource;
	}

	public void setReportResource(String reportResource) {
		this.reportResource = reportResource;
	}

	public String getCheckstatus() {
		return checkstatus;
	}

	public void setCheckstatus(String checkstatus) {
		this.checkstatus = checkstatus;
	}

	public String getRecheckDateStart() {
		return recheckDateStart;
	}

	public void setRecheckDateStart(String recheckDateStart) {
		this.recheckDateStart = recheckDateStart;
	}

	public String getRecheckDateEnd() {
		return recheckDateEnd;
	}

	public void setRecheckDateEnd(String recheckDateEnd) {
		this.recheckDateEnd = recheckDateEnd;
	}

	public String getUpdatedStart() {
		return updatedStart;
	}

	public void setUpdatedStart(String updatedStart) {
		this.updatedStart = updatedStart;
	}

	public String getUpdatedEnd() {
		return updatedEnd;
	}

	public void setUpdatedEnd(String updatedEnd) {
		this.updatedEnd = updatedEnd;
	}

	public String getShortCutSHDo() {
		return shortCutSHDo;
	}
	public void setShortCutSHDo(String shortCutSHDo) {
		this.shortCutSHDo = shortCutSHDo;
	}
	public String getYlpayD0Fee() {
		return ylpayD0Fee;
	}
	public void setYlpayD0Fee(String ylpayD0Fee) {
		this.ylpayD0Fee = ylpayD0Fee;
	}
	public String getShortCut() {
		return shortCut;
	}
	public void setShortCut(String shortCut) {
		this.shortCut = shortCut;
	}
	public String getShortCutDo() {
		return shortCutDo;
	}
	public void setShortCutDo(String shortCutDo) {
		this.shortCutDo = shortCutDo;
	}
	
	public String getB2c() {
		return b2c;
	}
	public void setB2c(String b2c) {
		this.b2c = b2c;
	}
	public String getB2cDo() {
		return b2cDo;
	}
	public void setB2cDo(String b2cDo) {
		this.b2cDo = b2cDo;
	}
	public MultipartFile getFixPhoto() {
		return fixPhoto;
	}
	public void setFixPhoto(MultipartFile fixPhoto) {
		this.fixPhoto = fixPhoto;
	}
	public String getS0fixAmount() {
		return s0fixAmount;
	}
	public void setS0fixAmount(String s0fixAmount) {
		this.s0fixAmount = s0fixAmount;
	}
	public String getT0fixAmount() {
		return t0fixAmount;
	}
	public void setT0fixAmount(String t0fixAmount) {
		this.t0fixAmount = t0fixAmount;
	}
	
	public String getS0creditFee() {
		return s0creditFee;
	}
	public void setS0creditFee(String s0creditFee) {
		this.s0creditFee = s0creditFee;
	}
	public String getS0debitFee() {
		return s0debitFee;
	}
	public void setS0debitFee(String s0debitFee) {
		this.s0debitFee = s0debitFee;
	}
	
	public String getD0creditFee() {
		return d0creditFee;
	}
	public void setD0creditFee(String d0creditFee) {
		this.d0creditFee = d0creditFee;
	}
	public String getD0debitFee() {
		return d0debitFee;
	}
	public void setD0debitFee(String d0debitFee) {
		this.d0debitFee = d0debitFee;
	}
	
	public String getT1creditFee() {
		return t1creditFee;
	}
	public void setT1creditFee(String t1creditFee) {
		this.t1creditFee = t1creditFee;
	}
	public String getT1debitFee() {
		return t1debitFee;
	}
	public void setT1debitFee(String t1debitFee) {
		this.t1debitFee = t1debitFee;
	}
	public String getWeChatFee() {
		return weChatFee;
	}
	public void setWeChatFee(String weChatFee) {
		this.weChatFee = weChatFee;
	}
	public String getWeChatD0Fee() {
		return weChatD0Fee;
	}
	public void setWeChatD0Fee(String weChatD0Fee) {
		this.weChatD0Fee = weChatD0Fee;
	}
	public String getAlipayFee() {
		return alipayFee;
	}
	public void setAlipayFee(String alipayFee) {
		this.alipayFee = alipayFee;
	}
	public String getAlipayD0Fee() {
		return alipayD0Fee;
	}
	public void setAlipayD0Fee(String alipayD0Fee) {
		this.alipayD0Fee = alipayD0Fee;
	}
	public String getYlpayFee() {
		return ylpayFee;
	}
	public void setYlpayFee(String ylpayFee) {
		this.ylpayFee = ylpayFee;
	}
	public String getRecreatedStart() {
		return recreatedStart;
	}
	public void setRecreatedStart(String recreatedStart) {
		this.recreatedStart = recreatedStart;
	}
	public String getRecreatedEnd() {
		return recreatedEnd;
	}
	public void setRecreatedEnd(String recreatedEnd) {
		this.recreatedEnd = recreatedEnd;
	}
	public boolean isCheckAgents() {
		return checkAgents;
	}
	public void setCheckAgents(boolean checkAgents) {
		this.checkAgents = checkAgents;
	}
	public String getOpen_create_start() {
		return open_create_start;
	}
	public void setOpen_create_start(String open_create_start) {
		this.open_create_start = open_create_start;
	}
	public String getOpen_create_end() {
		return open_create_end;
	}
	public void setOpen_create_end(String open_create_end) {
		this.open_create_end = open_create_end;
	}
	public String getFirstfeecheck() {
		return firstfeecheck;
	}
	public void setFirstfeecheck(String firstfeecheck) {
		this.firstfeecheck = firstfeecheck;
	}
	public String getFirstfeecheckresult() {
		return firstfeecheckresult;
	}
	public void setFirstfeecheckresult(String firstfeecheckresult) {
		this.firstfeecheckresult = firstfeecheckresult;
	}
	public String getFeerecheck() {
		return feerecheck;
	}
	public void setFeerecheck(String feerecheck) {
		this.feerecheck = feerecheck;
	}
	public String getFeerecheckresult() {
		return feerecheckresult;
	}
	public void setFeerecheckresult(String feerecheckresult) {
		this.feerecheckresult = feerecheckresult;
	}
	public String getExamineresullt() {
		return examineresullt;
	}
	public void setExamineresullt(String examineresullt) {
		this.examineresullt = examineresullt;
	}
	public String getTelq() {
		return telq;
	}
	public void setTelq(String telq) {
		this.telq = telq==null?"":telq.trim();
	}
	public MultipartFile getCreditCardPhoto() {
		return creditCardPhoto;
	}
	public void setCreditCardPhoto(MultipartFile creditCardPhoto) {
		this.creditCardPhoto = creditCardPhoto;
	}
	public MultipartFile getSettlementCardPhoto() {
		return settlementCardPhoto;
	}
	public void setSettlementCardPhoto(MultipartFile settlementCardPhoto) {
		this.settlementCardPhoto = settlementCardPhoto;
	}
	
	public String getOrgNo() {
		return orgNo;
	}
	public void setOrgNo(String orgNo) {
		this.orgNo = orgNo;
	}
	public String getMerchantNo() {
		return merchantNo;
	}
	public void setMerchantNo(String merchantNo) {
		this.merchantNo = merchantNo;
	}
	public String getTermNo() {
		return termNo;
	}
	public void setTermNo(String termNo) {
		this.termNo = termNo;
	}
	public String getFirstVerify() {
		return firstVerify;
	}
	public void setFirstVerify(String firstVerify) {
		this.firstVerify = firstVerify;
	}
	public String getLastVerify() {
		return lastVerify;
	}
	public void setLastVerify(String lastVerify) {
		this.lastVerify = lastVerify;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getParentid() {
		return parentid;
	}
	public void setParentid(String parentid) {
		this.parentid = parentid;
	}
	public String getEvicenumber() {
		return evicenumber;
	}
	public void setEvicenumber(String evicenumber) {
		this.evicenumber = evicenumber;
	}
	public String getPhotoCheckFlag() {
		return photoCheckFlag;
	}
	public void setPhotoCheckFlag(String photoCheckFlag) {
		this.photoCheckFlag = photoCheckFlag;
	}
	public String getPhotoRecheckFlag() {
		return photoRecheckFlag;
	}
	public void setPhotoRecheckFlag(String photoRecheckFlag) {
		this.photoRecheckFlag = photoRecheckFlag;
	}
	public String getPhotoRecheckRemark() {
		return photoRecheckRemark;
	}
	public void setPhotoRecheckRemark(String photoRecheckRemark) {
		this.photoRecheckRemark = photoRecheckRemark;
	}
	public MultipartFile getHandidentitycardphoto() {
		return handidentitycardphoto;
	}
	public void setHandidentitycardphoto(MultipartFile handidentitycardphoto) {
		this.handidentitycardphoto = handidentitycardphoto;
	}
	public MultipartFile getFrontidentitycardphoto() {
		return frontidentitycardphoto;
	}
	public void setFrontidentitycardphoto(MultipartFile frontidentitycardphoto) {
		this.frontidentitycardphoto = frontidentitycardphoto;
	}
	public MultipartFile getReverseidentitycardphoto() {
		return reverseidentitycardphoto;
	}
	public void setReverseidentitycardphoto(MultipartFile reverseidentitycardphoto) {
		this.reverseidentitycardphoto = reverseidentitycardphoto;
	}
	public MultipartFile getStorephoto() {
		return storephoto;
	}
	public void setStorephoto(MultipartFile storephoto) {
		this.storephoto = storephoto;
	}
	public MultipartFile getInstorephoto() {
		return instorephoto;
	}
	public void setInstorephoto(MultipartFile instorephoto) {
		this.instorephoto = instorephoto;
	}
	public MultipartFile getCheckstandphoto() {
		return checkstandphoto;
	}
	public void setCheckstandphoto(MultipartFile checkstandphoto) {
		this.checkstandphoto = checkstandphoto;
	}
	public MultipartFile getSignaturephoto() {
		return signaturephoto;
	}
	public void setSignaturephoto(MultipartFile signaturephoto) {
		this.signaturephoto = signaturephoto;
	}
	public MultipartFile getLicensephoto() {
		return licensephoto;
	}
	public void setLicensephoto(MultipartFile licensephoto) {
		this.licensephoto = licensephoto;
	}
	public String getTermianlstatus() {
		return termianlstatus;
	}
	public void setTermianlstatus(String termianlstatus) {
		this.termianlstatus = termianlstatus;
	}
	
	public Long getBasecost() {
		return basecost;
	}
	public void setBasecost(Long basecost) {
		this.basecost = basecost;
	}
	public Short getIsupdateshopper() {
		return isupdateshopper;
	}
	public void setIsupdateshopper(Short isupdateshopper) {
		this.isupdateshopper = isupdateshopper;
	}
	public Short getIsupdatebank() {
		return isupdatebank;
	}
	public void setIsupdatebank(Short isupdatebank) {
		this.isupdatebank = isupdatebank;
	}
	public Short getIsformal() {
		return isformal;
	}
	public void setIsformal(Short isformal) {
		this.isformal = isformal;
	}
	public Date getWorktime() {
		return worktime;
	}
	public void setWorktime(Date worktime) {
		this.worktime = worktime;
	}
	public MultipartFile getTermialfiles() {
		return termialfiles;
	}
	public void setTermialfiles(MultipartFile termialfiles) {
		this.termialfiles = termialfiles;
	}
	public MultipartFile getBankfiles() {
		return bankfiles;
	}
	public void setBankfiles(MultipartFile bankfiles) {
		this.bankfiles = bankfiles;
	}
	public String getTermialfilesHidden() {
		return termialfilesHidden;
	}
	public void setTermialfilesHidden(String termialfilesHidden) {
		this.termialfilesHidden = termialfilesHidden;
	}
	public String getBankfilesHidden() {
		return bankfilesHidden;
	}
	public void setBankfilesHidden(String bankfilesHidden) {
		this.bankfilesHidden = bankfilesHidden;
	}
	public String getHiddenNum() {
		return hiddenNum;
	}
	
	public void setHiddenNum(String hiddenNum) {
		this.hiddenNum = hiddenNum;
	}
	
	public String getSprovince() {
		return sprovince;
	}
	public void setSprovince(String sprovince) {
		this.sprovince = sprovince;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getSifpactid() {
		return sifpactid;
	}
	public void setSifpactid(String sifpactid) {
		this.sifpactid = sifpactid;
	}
	public String getifactivated() {
		return ifactivated;
	}
	public void setifactivated(String ifactivated) {
		this.ifactivated = ifactivated;
	}
	public String getOpencheckstatus() {
		return opencheckstatus;
	}
	public void setOpencheckstatus(String opencheckstatus) {
		this.opencheckstatus = opencheckstatus;
	}
	public String getIfvalid() {
		return ifvalid;
	}
	public void setIfvalid(String ifvalid) {
		this.ifvalid = ifvalid;
	}

	public String getTerminalNum() {
		return terminalNum;
	}
	public void setTerminalNum(String terminalNum) {
		this.terminalNum = terminalNum;
	}
	public String getEffectdt() {
		return effectdt;
	}
	public void setEffectdt(String effectdt) {
		this.effectdt = effectdt;
	}
	public String getTaskidq() {
		return taskidq;
	}
	public void setTaskidq(String taskidq) {
		this.taskidq = taskidq;
	}
	public String getPosCodeq() {
		return posCodeq;
	}
	public void setPosCodeq(String posCodeq) {
		this.posCodeq = posCodeq;
	}
	public String getTranStart() {
		return tranStart;
	}
	public void setTranStart(String tranStart) {
		this.tranStart = tranStart;
	}
	public String getTranEnd() {
		return tranEnd;
	}
	public void setTranEnd(String tranEnd) {
		this.tranEnd = tranEnd;
	}
	public String getSettleStart() {
		return settleStart;
	}
	public void setSettleStart(String settleStart) {
		this.settleStart = settleStart;
	}
	public String getSettleEnd() {
		return settleEnd;
	}
	public void setSettleEnd(String settleEnd) {
		this.settleEnd = settleEnd;
	}
	public String getCardtypeq() {
		return cardtypeq;
	}
	public void setCardtypeq(String cardtypeq) {
		this.cardtypeq = cardtypeq;
	}
	public String getTranStatusq() {
		return tranStatusq;
	}
	public void setTranStatusq(String tranStatusq) {
		this.tranStatusq = tranStatusq;
	}
	public String getTaskamountq() {
		return taskamountq;
	}
	public void setTaskamountq(String taskamountq) {
		this.taskamountq = taskamountq;
	}
	public String getShopperid() {
		return shopperid;
	}
	public void setShopperid(String shopperid) {
		this.shopperid = shopperid;
	}
	
	
	public Long getCurrentid() {
		return currentid;
	}
	public void setCurrentid(Long currentid) {
		this.currentid = currentid;
	}
	public String getBelongsAgentq() {
		return belongsAgentq;
	}
	public void setBelongsAgentq(String belongsAgentq) {
		this.belongsAgentq = belongsAgentq;
	}
	public Long getShopperid_q() {
		return shopperid_q;
	}
	public void setShopperid_q(Long shopperid_q) {
		this.shopperid_q = shopperid_q;
	}
	public String getStdfilenamesHidden() {
		return stdfilenamesHidden;
	}
	public void setStdfilenamesHidden(String stdfilenamesHidden) {
		this.stdfilenamesHidden = stdfilenamesHidden;
	}
	public String getAddFileNamesHidden() {
		return addFileNamesHidden;
	}
	public void setAddFileNamesHidden(String addFileNamesHidden) {
		this.addFileNamesHidden = addFileNamesHidden;
	}
	public MultipartFile getStdFileNames() {
		return stdFileNames;
	}
	public void setStdFileNames(MultipartFile stdFileNames) {
		this.stdFileNames = stdFileNames;
	}
	public MultipartFile getAddFileNames() {
		return addFileNames;
	}
	public void setAddFileNames(MultipartFile addFileNames) {
		this.addFileNames = addFileNames;
	}
	
	public String getShopperidq() {
		return shopperidq;
	}
	public void setShopperidq(String shopperidq) {
		this.shopperidq = StringUtils.isNumeric(shopperidq)?shopperidq.trim():"";
	}
	public String getShopperNameq() {
		return shopperNameq;
	}
	public void setShopperNameq(String shopperNameq) {
		this.shopperNameq = shopperNameq.trim();
	}
	public String getShoppercallingidq() {
		return shoppercallingidq;
	}
	public void setShoppercallingidq(String shoppercallingidq) {
		this.shoppercallingidq = shoppercallingidq;
	}
	public String getTransactidq() {
		return transactidq;
	}
	public void setTransactidq(String transactidq) {
		this.transactidq = transactidq;
	}
	public String getSagentidq() {
		return sagentidq;
	}
	public void setSagentidq(String sagentidq) {
		this.sagentidq = sagentidq;
	}
	
	public String getCreatedStart() {
		return createdStart;
	}
	public void setCreatedStart(String createdStart) {
		this.createdStart = createdStart;
	}
	public String getCreatedEnd() {
		return createdEnd;
	}
	public void setCreatedEnd(String createdEnd) {
		this.createdEnd = createdEnd;
	}
	public String getIfacticreatedStart() {
		return ifacticreatedStart;
	}
	public void setIfacticreatedStart(String ifacticreatedStart) {
		this.ifacticreatedStart = ifacticreatedStart;
	}
	public String getIfacticreatedEnd() {
		return ifacticreatedEnd;
	}
	public void setIfacticreatedEnd(String ifacticreatedEnd) {
		this.ifacticreatedEnd = ifacticreatedEnd;
	}
	public String getBargainedateStart() {
		return bargainedateStart;
	}
	public void setBargainedateStart(String bargainedateStart) {
		this.bargainedateStart = bargainedateStart;
	}
	public String getBargainedateEnd() {
		return bargainedateEnd;
	}
	public void setBargainedateEnd(String bargainedateEnd) {
		this.bargainedateEnd = bargainedateEnd;
	}
	public String getBelongsAgent() {
		return belongsAgent;
	}
	public void setBelongsAgent(String belongsAgent) {
		this.belongsAgent = belongsAgent;
	}
	
	public Long getShopperid_p() {
		return shopperid_p;
	}
	public void setShopperid_p(Long shopperid_p) {
		this.shopperid_p = shopperid_p;
	}
	public String getBargainbdates() {
		return bargainbdates;
	}
	public void setBargainbdates(String bargainbdates) {
		this.bargainbdates = bargainbdates;
	}
	public String getBargainedates() {
		return bargainedates;
	}
	public void setBargainedates(String bargainedates) {
		this.bargainedates = bargainedates;
	}
	public String getWritebargains() {
		return writebargains;
	}
	public void setWritebargains(String writebargains) {
		this.writebargains = writebargains;
	}
	public String getRecheckmerchantflag() {
		return recheckmerchantflag;
	}
	public void setRecheckmerchantflag(String recheckmerchantflag) {
		this.recheckmerchantflag = recheckmerchantflag;
	}
	public String getRecheckaccountflag() {
		return recheckaccountflag;
	}
	public void setRecheckaccountflag(String recheckaccountflag) {
		this.recheckaccountflag = recheckaccountflag;
	}
	public String getRecheckterminalflag() {
		return recheckterminalflag;
	}
	public void setRecheckterminalflag(String recheckterminalflag) {
		this.recheckterminalflag = recheckterminalflag;
	}
	public String getRecheckmerchantremark() {
		return recheckmerchantremark;
	}
	public void setRecheckmerchantremark(String recheckmerchantremark) {
		this.recheckmerchantremark = recheckmerchantremark;
	}
	public String getRecheckaccountremark() {
		return recheckaccountremark;
	}
	public void setRecheckaccountremark(String recheckaccountremark) {
		this.recheckaccountremark = recheckaccountremark;
	}
	public String getRecheckterminalremark() {
		return recheckterminalremark;
	}
	public void setRecheckterminalremark(String recheckterminalremark) {
		this.recheckterminalremark = recheckterminalremark;
	}
	
}
