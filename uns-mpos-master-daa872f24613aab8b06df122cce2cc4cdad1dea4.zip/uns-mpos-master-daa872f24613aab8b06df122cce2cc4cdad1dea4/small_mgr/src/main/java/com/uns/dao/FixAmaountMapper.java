package com.uns.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.FixAmaount;
@Repository
public interface FixAmaountMapper {


    int insert(FixAmaount record);

    int insertSelective(FixAmaount record);
    
    void updateById(FixAmaount limitamount);
    
    List findbyidList();
    
    FixAmaount selectById(Long id);

}