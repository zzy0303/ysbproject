package com.uns.web.form;

import com.uns.model.Users;


public class AgentUserForm extends Users{
	private String codeOrName;
	private Long stateflag;
	private String addStart;
	private String addEnd;
	private String loginStart;
	private String loginEnd;
	private Long currentid;
	private String merchantIdq;
	private String userNameq;
	private String agentq;
	private String enabledq;
	private String loginName;
	private String password;
	private String mobile;
	private String oldMobile;
	private String createdate_start;
	private String createdate_end;
	private String lastdate_start;
	private String lastdate_end;
	
	private String tel;
	private String scompany;
	

	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getScompany() {
		return scompany;
	}
	public void setScompany(String scompany) {
		this.scompany = scompany;
	}
	private String demo;
	
	public String getDemo() {
		return demo;
	}
	public void setDemo(String demo) {
		this.demo = demo;
	}
	public String getCreatedate_start() {
		return createdate_start;
	}
	public void setCreatedate_start(String createdate_start) {
		this.createdate_start = createdate_start;
	}
	public String getCreatedate_end() {
		return createdate_end;
	}
	public void setCreatedate_end(String createdate_end) {
		this.createdate_end = createdate_end;
	}
	public String getLastdate_start() {
		return lastdate_start;
	}
	public void setLastdate_start(String lastdate_start) {
		this.lastdate_start = lastdate_start;
	}
	public String getLastdate_end() {
		return lastdate_end;
	}
	public void setLastdate_end(String lastdate_end) {
		this.lastdate_end = lastdate_end;
	}
	public String getMerchantIdq() {
		return merchantIdq;
	}
	public void setMerchantIdq(String merchantIdq) {
		this.merchantIdq = merchantIdq;
	}
	public String getUserNameq() {
		return userNameq;
	}
	public void setUserNameq(String userNameq) {
		this.userNameq = userNameq.trim();
	}
	public String getAgentq() {
		return agentq;
	}
	public void setAgentq(String agentq) {
		this.agentq = agentq;
	}
	public String getEnabledq() {
		return enabledq;
	}
	public void setEnabledq(String enabledq) {
		this.enabledq = enabledq;
	}
	public Long getCurrentid() {
		return currentid;
	}
	public void setCurrentid(Long currentid) {
		this.currentid = currentid;
	}
	public String getCodeOrName() {
		return codeOrName;
	}
	public void setCodeOrName(String codeOrName) {
		this.codeOrName = codeOrName;
	}
	public Long getStateflag() {
		return stateflag;
	}
	public void setStateflag(Long stateflag) {
		this.stateflag = stateflag;
	}
	public String getAddStart() {
		return addStart;
	}
	public void setAddStart(String addStart) {
		this.addStart = addStart;
	}
	public String getAddEnd() {
		return addEnd;
	}
	public void setAddEnd(String addEnd) {
		this.addEnd = addEnd;
	}
	public String getLoginStart() {
		return loginStart;
	}
	public void setLoginStart(String loginStart) {
		this.loginStart = loginStart;
	}
	public String getLoginEnd() {
		return loginEnd;
	}
	public void setLoginEnd(String loginEnd) {
		this.loginEnd = loginEnd;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName.trim();
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password.trim();
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getOldMobile() {
		return oldMobile;
	}

	public void setOldMobile(String oldMobile) {
		this.oldMobile = oldMobile;
	}
}
