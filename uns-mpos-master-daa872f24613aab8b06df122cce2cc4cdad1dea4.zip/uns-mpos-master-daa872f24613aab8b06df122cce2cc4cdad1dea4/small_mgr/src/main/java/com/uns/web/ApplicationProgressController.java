package com.uns.web;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.service.MposApplicationProgressService;
import com.uns.web.form.ApplicationProgressForm;

@Controller("/ApplicationProgressController")
@RequestMapping("/applicationProgress.htm")
public class ApplicationProgressController extends BaseController {
	@Autowired
	private MposApplicationProgressService mposApplicationProgressService;
	
	/**
	 * 申请进度信息
	 * @param request
	 * @param aform
	 * @return
	 */
	@RequestMapping(params = "method=applicationProgressList")
	public String applicationProgressList(HttpServletRequest request,ApplicationProgressForm aform) {
		List<Map<String,String>> list = mposApplicationProgressService.searchApplicationProgressList(aform);
		request.setAttribute("applicationInfo", list);
		request.setAttribute("aform", aform);
		return "progress/application_progressList";
	}
}
