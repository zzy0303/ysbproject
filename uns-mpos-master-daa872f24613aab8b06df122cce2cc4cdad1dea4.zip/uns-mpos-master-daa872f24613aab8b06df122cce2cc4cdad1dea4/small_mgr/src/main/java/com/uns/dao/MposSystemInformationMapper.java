package com.uns.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.MposSystemInformation;
import com.uns.web.form.InformationForm;
@Repository
public interface MposSystemInformationMapper {


    int insert(MposSystemInformation record);

    int insertSelective(MposSystemInformation record);

	List findInformationList(InformationForm mbform);

	MposSystemInformation findInformationById(Long id);

	void updateSystemInformation(MposSystemInformation systemInformation);

	void updateinformationCrontab();

	List findInformationAgentList(InformationForm mbForm);

	void updateQrcodeInformation(String isQrcode);

	String findQrcodeInformation();

}