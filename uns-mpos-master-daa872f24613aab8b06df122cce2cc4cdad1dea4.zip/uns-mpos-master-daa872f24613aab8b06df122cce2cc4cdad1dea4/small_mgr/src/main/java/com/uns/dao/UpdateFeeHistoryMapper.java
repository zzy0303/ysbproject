package com.uns.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.UpdateFeeHistory;
@Repository
public interface UpdateFeeHistoryMapper {


    int insert(UpdateFeeHistory record);

    int insertSelective(UpdateFeeHistory record);

    List findbyidList(String shopperid);
    
    UpdateFeeHistory selectById(Long id);
    
    List selectByshopperid(Long shopperid);

}