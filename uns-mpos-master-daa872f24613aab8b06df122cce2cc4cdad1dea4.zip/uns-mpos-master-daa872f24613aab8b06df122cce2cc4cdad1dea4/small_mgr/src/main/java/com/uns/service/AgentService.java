package com.uns.service;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.common.page.PageContext;
import com.uns.dao.AgentMapper;
import com.uns.dao.AgentOperatorMapper;
import com.uns.dao.B2cShopperbiTempMapper;
import com.uns.dao.UsersMapper;
import com.uns.model.Agent;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.Users;
import com.uns.web.form.AgentForm;

@Service
public class AgentService {
	
	@Autowired
	private AgentMapper agentMapper;
	
	@Autowired
	private AgentOperatorMapper agentOperatorMapper;
	@Autowired
	private B2cShopperbiTempMapper b2cShopperbiTempMapper;
	
	@Autowired
	private UsersMapper usermapper;
	
	private SimpleDateFormat format=new SimpleDateFormat(Constants.DEFAULT_DATE_FORMAT); 
	
	/**
	 * 查询代理商
	 * @param agent
	 * @return
	 * @throws ParseException 
	 */
	public List<Agent> queryAgentList(AgentForm agentForm) throws ParseException{
		PageContext.initPageSize(20);
		List<Agent> agentList = agentMapper.searchAgentList(agentForm);
		return agentList;
	}
	/**
	 * 查询商户
	 * @param shopperUser
	 * @return
	 * @throws ParseException 
	 */
	public B2cShopperbiTemp queryShopPerbi(String b2cShopperbiId)throws Exception {
		return b2cShopperbiTempMapper.selectByshopperId(Long.valueOf(b2cShopperbiId));
	}
	/**
	 * 查询代理商树
	 * @return
	 */
	public List<Agent> searchAgentTree(){
		return agentMapper.searchAgentTree();
	}
	
	public List<Agent> findAgentByMerchantId(){
		return agentMapper.findAgentByMerchantId();
	}
	
	/**
	 * 新增代理商操作
	 */
	public void addAgent(Agent agent){
		
		//是否为代理商标志：1-是，0-否
		agent.setIfagent(new Long(Constants.CON_YES));
		
		agent.setCreated(new Date());
		agentMapper.addAgent(agent);
	}
	public Agent searchAgentById(String id) {
		return agentMapper.searchAgentById(id);
	}
	
	public Agent searchAgentByShopperId(String shopperId) {
		return agentMapper.searchAgentByShopperid(shopperId);
	}
	public Agent searchAgentByName(String scompany) {
		return agentMapper.searchAgentByName(scompany);
	}
	
	public Long searchUserByNameAndShopperid(Map params){
		return agentMapper.searchUserByNameAndShopperid(params);
	}
	public void updateAgent(Agent agent){
		agentMapper.updateAgent(agent);
	}
	/**代理商地图
	 * @param merchantId
	 * @return
	 */
	public List findAgentByMerchantIdMap(String merchantId) {
		return agentMapper.findAgentByMerchantIdMap(merchantId);
	}
	public List updateAgentByMerchantId(String merchantId, String shopperid) {
		Map map=new HashMap();
		map.put("merchantId", Long.valueOf(merchantId));
		map.put("shopperid", Long.valueOf(shopperid));
		return agentMapper.updateAgentByMerchantId(map);
	}
	public Agent findbytel(String tel){
		List list=agentMapper.findbytel(tel);
  		Agent agent=null;
		if(list!=null&&list.size()>0){
			agent=(Agent)list.get(0);
		}
		return agent;
	}
	
	public void updateuseragent(Users users,Agent agent,String loginName){
		//判断有没有修改费率,如果修改了费率，需要在保存修改日志
		Map<String, Object> param = new HashMap<String, Object>();
		Agent a = agentMapper.searchAgentByShopperid(String.valueOf(agent.getShopperid()));//old查询代理商信息
		boolean flag = false;
	//不一样的就最新的
		if(a.getSmWechatD0Fee() == null || !agent.getSmWechatD0Fee().equals(a.getSmWechatD0Fee())){
			flag = true;
			param.put("smWechatD0Fee", agent.getSmWechatD0Fee());
		}
		if(a.getSmWechatT1Fee() == null || !agent.getSmWechatT1Fee().equals(a.getSmWechatT1Fee())){
			flag = true;
			param.put("smWechatT1Fee", agent.getSmWechatT1Fee());
		}
		if(a.getSmAlipayD0Fee() == null || !agent.getSmAlipayD0Fee().equals(a.getSmAlipayD0Fee())){
			flag = true;
			param.put("smAlipayD0Fee", agent.getSmAlipayD0Fee());
		}
		if(a.getSmAlipayT1Fee() == null || !agent.getSmAlipayT1Fee().equals(a.getSmAlipayT1Fee())){
			flag = true;
			param.put("smAlipayT1Fee", agent.getSmAlipayT1Fee());
		}
		if(a.getSmYlzfT1Fee() == null || !agent.getSmYlzfT1Fee().equals(a.getSmYlzfT1Fee())){
			flag = true;
			param.put("smYlzfT1Fee", agent.getSmYlzfT1Fee());
		}
		if(a.getSmYlzfD0Fee() == null || !agent.getSmYlzfD0Fee().equals(a.getSmYlzfD0Fee())){
			flag = true;
			param.put("smYlzfD0Fee", agent.getSmYlzfD0Fee());
		}
		if(a.getSkSecondFee() == null ||!agent.getSkSecondFee().equals(a.getSkSecondFee())){
			flag = true;
			param.put("skSecondFee", agent.getSkSecondFee());
		}
		
		if(a.getSkImmediateFee() == null || !agent.getSkImmediateFee().equals(a.getSkImmediateFee())){
			flag = true;
			param.put("skImmediateFee", agent.getSkImmediateFee());
		}
		
		if(a.getSkT1Fee() ==null || !agent.getSkT1Fee().equals(a.getSkT1Fee())){
			flag = true;
			param.put("skT1Fee", agent.getSkT1Fee());
		}
		if(a.getSmShortCutT1Fee() ==null || !agent.getSmShortCutT1Fee().equals(a.getSmShortCutT1Fee())){
			flag = true;
			param.put("smShortCutT1Fee", agent.getSmShortCutT1Fee());
		}
		if(a.getSmShortCutD0Fee() ==null || !agent.getSmShortCutD0Fee().equals(a.getSmShortCutD0Fee())){
			flag = true;
			param.put("smShortCutD0Fee", agent.getSmShortCutD0Fee());
		}
		if(a.getSmShortCutSHD0Fee() ==null || !agent.getSmShortCutSHD0Fee().equals(a.getSmShortCutSHD0Fee())){
			flag = true;
			param.put("smShortCutSHD0Fee", agent.getSmShortCutSHD0Fee());
		}
		if(a.getSmB2cT1Fee() ==null || !agent.getSmB2cT1Fee().equals(a.getSmB2cT1Fee())){
			flag = true;
			param.put("smB2cT1Fee", agent.getSmB2cT1Fee());
		}
		if(a.getSmB2cD0Fee() ==null || !agent.getSmB2cD0Fee().equals(a.getSmB2cD0Fee())){
			flag = true;
			param.put("smB2cD0Fee", agent.getSmB2cD0Fee());
		}
		//新加商户扫码签约费率
		if(a.getMerchantWxT1Fee() == null || !agent.getMerchantWxT1Fee().equals(a.getMerchantWxT1Fee())){
			flag = true;
			param.put("merchantWxT1Fee", agent.getMerchantWxT1Fee());
		}
		if(a.getMerchantWxT1Fee() == null || !agent.getMerchantWxT1Fee().equals(a.getMerchantWxT1Fee())){
			flag = true;
			param.put("merchantZfbT1Fee", agent.getMerchantZfbT1Fee());
		}
		//如果有修改
		if(flag){
			param.put("createDate", new Date());
			param.put("updateUser", loginName);
			param.put("shopperid", agent.getShopperid());
			param.put("updateScompany", "卡宝管理员");
			agentMapper.insertUpdateAgentfeeAlog(param);//插入代理商操作费率表
		}
		
		agentMapper.updateAgent(agent);
		users.setIsAgent(Constants.CON_YES); 
		usermapper.updateByUsresId(users);
	}
	
	public void addagent(Users users,Agent agent,Map param){
		agentMapper.addAgent(agent);
		agentMapper.insertUpdateAgentfeeAlog(param);
		usermapper.insertUsers(users);
	}
	
	
	public List<Agent> selectAgentList(AgentForm agentForm) throws ParseException{
		PageContext.initPageSize(20);
		List<Agent> agentList = agentMapper.selectAgentList(agentForm);
		return agentList;
	}
	
	
	public List<Agent> findAgentByMerchantId1(String scompany){
		return agentMapper.findAgentByMerchantId1(scompany);
	}
	
	public List<Map<String,Object>> selectUpdateAgentfeeAlogList(String shopperid){
		PageContext.initPageSize(20);
		return agentMapper.selectUpdateAgentfeeAlogList(shopperid);
	}
	public List findfirstAgent(String scompany) {
		return agentMapper.findfirstAgent(scompany.trim());
	}
	public List findfirstAgent2() {
		return agentMapper.findfirstAgent2();
	}
	
	/**
	 * 获取一级代理商
	 * @param agent_no
	 * @return
	 */
	public String findFisrtAgentByNo(String agentNo) {
		// TODO Auto-generated method stub
		return agentMapper.findFisrtAgentByNo(agentNo);
	}
	
	public String findFisrtParma(String agentNo){
		return agentMapper.findFisrtParma(agentNo);
		
	}
}	
