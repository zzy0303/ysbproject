package com.uns.web.form;

public class SudokuForm {
	
	
	private String[] top_sudoku;//app首页控制
	private String[] mpos_tran_type;//mpos 交易方式
	private String[] sm_tran_type;//扫码 交易方式
	private String[] sm_pay_flag;//扫码 收款方式
	private String[] fix_pay_flag;//固码 收款方式
	private String[] cardService;//信用卡服务
	private String[] creditService;//贷款服务
	private String[] kj_pay_flag;//快捷收款方式
	private String[] search_tran;//交易查询
	
	private String[] mer_sudoku;//商户平台
	private String[] mer_sm_tran_type;//扫码交易方式
	private String[] mer_sm_pay_flag;//扫码收款方式

	private String merchant_type; //商户类型

	public String getMerchant_type() {
		return merchant_type;
	}

	public void setMerchant_type(String merchant_type) {
		this.merchant_type = merchant_type;
	}

	public String[] getMer_sudoku() {
		return mer_sudoku;
	}
	public void setMer_sudoku(String[] mer_sudoku) {
		this.mer_sudoku = mer_sudoku;
	}
	public String[] getMer_sm_tran_type() {
		return mer_sm_tran_type;
	}
	public void setMer_sm_tran_type(String[] mer_sm_tran_type) {
		this.mer_sm_tran_type = mer_sm_tran_type;
	}
	public String[] getMer_sm_pay_flag() {
		return mer_sm_pay_flag;
	}
	public void setMer_sm_pay_flag(String[] mer_sm_pay_flag) {
		this.mer_sm_pay_flag = mer_sm_pay_flag;
	}
	public String[] getTop_sudoku() {
		return top_sudoku;
	}
	public void setTop_sudoku(String[] top_sudoku) {
		this.top_sudoku = top_sudoku;
	}
	public String[] getMpos_tran_type() {
		return mpos_tran_type;
	}
	public void setMpos_tran_type(String[] mpos_tran_type) {
		this.mpos_tran_type = mpos_tran_type;
	}
	public String[] getSm_tran_type() {
		return sm_tran_type;
	}
	public void setSm_tran_type(String[] sm_tran_type) {
		this.sm_tran_type = sm_tran_type;
	}
	public String[] getSm_pay_flag() {
		return sm_pay_flag;
	}
	public void setSm_pay_flag(String[] sm_pay_flag) {
		this.sm_pay_flag = sm_pay_flag;
	}
	public String[] getFix_pay_flag() {
		return fix_pay_flag;
	}
	public void setFix_pay_flag(String[] fix_pay_flag) {
		this.fix_pay_flag = fix_pay_flag;
	}
	public String[] getCardService() {
		return cardService;
	}
	public void setCardService(String[] cardService) {
		this.cardService = cardService;
	}
	public String[] getCreditService() {
		return creditService;
	}
	public void setCreditService(String[] creditService) {
		this.creditService = creditService;
	}
	public String[] getKj_pay_flag() {
		return kj_pay_flag;
	}
	public void setKj_pay_flag(String[] kj_pay_flag) {
		this.kj_pay_flag = kj_pay_flag;
	}
	public String[] getSearch_tran() {
		return search_tran;
	}
	public void setSearch_tran(String[] search_tran) {
		this.search_tran = search_tran;
	}
	
	
	
}
