package com.uns.web;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.model.*;
import com.uns.service.ShopPerbiService;
import com.uns.util.RegMposAndQrcode;
import com.uns.util.StringUtils;
import com.uns.web.form.ShopPerbiForm;
import jxl.SheetSettings;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import oracle.jdbc.driver.Const;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.util.*;

/**
 * 聚合支付商户用户信息
 */
@Controller("shopperInfoAggController")
@RequestMapping("shopperInfoAgg.htm")
public class ShopperInfoAggController extends BaseController{

    @Autowired
    ShopPerbiService shopPerbiService;

    @Autowired
    RegMposAndQrcode regMposAndQrcode;

    /**
     * 查询商户用户预约列表
     * @param request
     * @param modelMap
     * @param form
     * @return
     */
    @RequestMapping(params = "method=shopperAggTempList")
    public String shopperAggTempList(HttpServletRequest request,ModelMap modelMap, ShopPerbiForm form) throws BusinessException {
        try {
            //获取省
            List<Area> Provincial = shopPerbiService.searchProvince();
            request.setAttribute("Provincial", Provincial);
            //获取市
            List<Area> list = shopPerbiService.searchArea();
            request.setAttribute("area", list);
            //查询商户用户信息
            List<HashMap> shopperTempList = shopPerbiService.findShopperAggTempList(form);
            modelMap.put("shopperTempList", shopperTempList);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }
        return "aggShopper/shopperAggTempList";
    }

    /**
     * 查询商户用户详情
     *
     * @param request
     * @param modelMap
     * @param mbForm
     * @return
     */
    @RequestMapping(params = "method=shopperAggDetails")
    public String shopperAggDetails(HttpServletRequest request, ModelMap modelMap, ShopPerbiForm mbForm) throws BusinessException {

        try {
            //获取shopperid
            String shopperid = mbForm.getShopperid();

            //更新人工检查状态
            shopPerbiService.updateVisualCheckStatus(shopperid, Constants.TYPE_1);
            //商户预约信息详情
            Map shopperTemp = shopPerbiService.findAggShopperDetails(Long.valueOf(shopperid));

            // 获取证照信息
            if (null != shopperTemp.get("PHOTO_ID")) {
                Long photoid = ((BigDecimal) shopperTemp.get("PHOTO_ID")).longValue();
                MposPhotoTmp photo = shopPerbiService.selectPhotoTmpById(photoid);
                request.setAttribute("photo", photo);
                request.setAttribute("image_get_url", ConstantsEnv.IMAGE_GET_URL);
            }

            //获取银行名称
            if(shopperTemp.get("ACCOUNT_BANK_OTHER") != null){
                String bankDictvalName = shopperTemp.get("ACCOUNT_BANK_OTHER").toString();
                request.setAttribute("accountBankDictvalName", bankDictvalName);
            }

            //获取费率信息 手续费，临时表

            MposMerchantFee weChatMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_WECHAT);
            MposMerchantFee alipayMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_ALIPAY);

            request.setAttribute("weChatMerchantFeeTemp", weChatMerchantFeeTemp);
            request.setAttribute("alipayMerchantFeeTemp", alipayMerchantFeeTemp);

            //获取手续费正式表

            MposMerchantFee weChatMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_WECHAT);
            MposMerchantFee alipayMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_ALIPAY);

            request.setAttribute("weChatMerchantFee", weChatMerchantFee);
            request.setAttribute("alipayMerchantFee", alipayMerchantFee);

            request.setAttribute("shopper", shopperTemp);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }

        return "aggShopper/shopperAggDetails";
    }

    /**
     * 商户初、复审核详情
     *
     * @param request
     * @param modelMap
     * @param mbForm
     * @return
     */
    @RequestMapping(params = "method=shopperAggAuditDetails")
    public String shopperAggAuditDetails(HttpServletRequest request, ModelMap modelMap, ShopPerbiForm mbForm) throws BusinessException {
        try {

            //获取shopperid
            String shopperid = mbForm.getShopperid();

            //更新人工检查状态
            shopPerbiService.updateVisualCheckStatus(shopperid, Constants.TYPE_1);

            //查询商户版预约表详情
            Map shopperTemp = shopPerbiService.findAggShopperDetails(Long.valueOf(shopperid));
            //Map shopperFormal = shopPerbiService.findShopperFormalDetails(Long.valueOf(shopperid));
            if (null == shopperTemp) {
                throw new BusinessException(ExceptionDefine.获取商户信息失败);
            }
            // 预约图片
            Long photoid = null;
            if (null != shopperTemp.get("PHOTO_ID")) {
                photoid = ((BigDecimal) shopperTemp.get("PHOTO_ID")).longValue();
                MposPhotoTmp photo = shopPerbiService.selectPhotoTmpById(photoid);
                request.setAttribute("photo", photo);
                request.setAttribute("image_get_url", ConstantsEnv.IMAGE_GET_URL);
            }

            /*// 正式图片
            if (null != shopperFormal.get("PHOTO_ID")) {
                photoid = ((BigDecimal) shopperFormal.get("PHOTO_ID")).longValue();
                MposPhoto photo = shopPerbiService.selectPhotoById(photoid);
                request.setAttribute("photoFormal", photo);
                request.setAttribute("image_get_urlFormal", ConstantsEnv.IMAGE_GET_URL);
            }*/

            //获取银行名称
            /*String bankDictval = (String) shopperTemp.get("ACCOUNT_BANK_DICTVAL");
            B2cDict bankInfo = shopPerbiService.findBankName(bankDictval);
            String bankDictvalName = bankInfo.getDict();*/
            if(shopperTemp.get("ACCOUNT_BANK_OTHER") != null){
                String bankDictvalName = shopperTemp.get("ACCOUNT_BANK_OTHER").toString();
                request.setAttribute("accountBankDictvalName", bankDictvalName);
            }

            //获取费率信息 手续费，临时表

            MposMerchantFee weChatMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_WECHAT);
            MposMerchantFee alipayMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_ALIPAY);


            request.setAttribute("weChatMerchantFeeTemp", weChatMerchantFeeTemp);
            request.setAttribute("alipayMerchantFeeTemp", alipayMerchantFeeTemp);

            //获取手续费正式表

            MposMerchantFee weChatMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_WECHAT);
            MposMerchantFee alipayMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_ALIPAY);

            request.setAttribute("weChatMerchantFee", weChatMerchantFee);
            request.setAttribute("alipayMerchantFee", alipayMerchantFee);
            request.setAttribute("mbForm",mbForm);
            request.setAttribute("shopper", shopperTemp);
            //request.setAttribute("shopperFormal", shopperFormal);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }
        return "aggShopper/aggShopperAuditDetails";
    }

    /**
     * 商户用户状态列表查询
     * @param request
     * @param modelMap
     * @param form
     * @return
     * @throws BusinessException
     */
    @RequestMapping(params = "method=shopperAggStatusList")
    public String shopperAggStatusList(HttpServletRequest request,ModelMap modelMap, ShopPerbiForm form) throws BusinessException {
        try {
            //查询商户用户状态信息
            List<HashMap> shopperTempList = shopPerbiService.findShopperAggStatusList(form);
            modelMap.put("shopperTempList", shopperTempList);
            modelMap.put("param",request);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }
        return "aggShopper/shopperAggStatusList";
    }

    /**
     * 商户用户初审
     * @param request
     * @param mbForm
     * @return
     */
    @RequestMapping(params = "method=saveShopperAggFirstAudit")
    @FormToken(save = true)
    public String saveShopperAggFirstAudit(HttpServletRequest request, ShopPerbiForm mbForm) throws Exception {
        String shopperid = null;
        B2cShopperbiTemp b2cShopperbiTemp = null;
        //获取审核状态
        String checkstatus = mbForm.getCheckstatus();
        shopperid = mbForm.getShopperid();
        b2cShopperbiTemp = shopPerbiService.queryShopPerbi(shopperid);
        //商户审核状态
        b2cShopperbiTemp.setCheckstatus(checkstatus);
        b2cShopperbiTemp.setCheckdate(new Date());//审核时间
        b2cShopperbiTemp.setVisualCheckStatus(Constants.TYPE_1);//人工检查状态

        if (Constants.CHECK_STATUS_8.equals(checkstatus)) {//商户初审通过
            log.info("商户初级审核：同意！");
            shopPerbiService.firstCheckAggShopper(b2cShopperbiTemp, request);
        } else {//人工审核不通过
            log.info("商户初级审核：拒绝！");
            b2cShopperbiTemp.setIfvalid(Short.valueOf(Constants.TYPE_1));//初审不通过
            b2cShopperbiTemp.setRecheckmerchantflag(Constants.TYPE_2);//复审不通过
            b2cShopperbiTemp.setRecheckmerchantremark(mbForm.getNotPassReason());// 复审不通过原因

            b2cShopperbiTemp.setNotPassReason(mbForm.getNotPassReason());
            shopPerbiService.updateShopperManualaudit(b2cShopperbiTemp);//更新预约信息
            shopPerbiService.updateShopperAggCheckStatus(b2cShopperbiTemp); //更新正式信息
        }
        request.setAttribute(Constants.URL_KEY, "shopperInfoAgg.htm?method=shopperAggTempList");
        request.setAttribute(Constants.MESSAGE_KEY, "审核成功");
        return "/returnPage";

    }

    /**
     * 商户用户复审
     * @param request
     * @param mbForm
     * @return
     */
    @RequestMapping(params = "method=saveShopperAggReAudit")
    @FormToken(save = true)
    public String saveShopperAggReAudit(HttpServletRequest request, ShopPerbiForm mbForm) throws Exception {
        String shopperid = null;
        B2cShopperbiTemp b2cShopperbiTemp = null;
        try {
            //获取审核状态
            String checkstatus = mbForm.getCheckstatus();
            shopperid = mbForm.getShopperid();
            b2cShopperbiTemp = shopPerbiService.queryShopPerbi(shopperid);
            //商户审核状态
            b2cShopperbiTemp.setCheckstatus(checkstatus);
            b2cShopperbiTemp.setCheckdate(new Date());//审核时间
            if (Constants.CHECK_STATUS_10.equals(checkstatus)) {//商户复审通过
                log.info("商户复审：同意！");
                b2cShopperbiTemp.setCibShopperId(mbForm.getCibShopperId());
                b2cShopperbiTemp.setCibShopperName(mbForm.getCibShopperName());
                b2cShopperbiTemp.setCibShopperSecretkey(mbForm.getCibShopperSecretkey());
                b2cShopperbiTemp.setWxPayId(mbForm.getWxPayId());
                b2cShopperbiTemp.setWxPayKey(mbForm.getWxPayKey());
                b2cShopperbiTemp.setBankCode(mbForm.getBankCode());
                //b2cShopperbiTemp.setIfvalid(Short.valueOf(Constants.TYPE_1));//审核通过
                //b2cShopperbiTemp.setRecheckmerchantflag(Constants.TYPE_1);//维护复审状态
                shopPerbiService.reCheckAggShopper(b2cShopperbiTemp, request);
            } else {//审核不通过
                log.info("商户复审：拒绝！");
                b2cShopperbiTemp.setIfvalid(Short.valueOf(Constants.TYPE_1));//初审通过（老app）
                b2cShopperbiTemp.setRecheckmerchantflag(Constants.TYPE_2);//复审不通过（老app）
                b2cShopperbiTemp.setRecheckmerchantremark(mbForm.getNotPassReason());//商户复审不通过原因
                b2cShopperbiTemp.setNotPassReason(mbForm.getNotPassReason());
                shopPerbiService.updateShopperManualaudit(b2cShopperbiTemp);//更新预约信息
                shopPerbiService.updateShopperAggCheckStatus(b2cShopperbiTemp); //更新正式信息
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.审核失败);
        }
        request.setAttribute(Constants.URL_KEY, "shopperInfoAgg.htm?method=shopperAggTempList");
        request.setAttribute(Constants.MESSAGE_KEY, "审核成功");
        return "/returnPage";

    }

    /**
     * 修改商户状态
     * @return
     */
    @RequestMapping(params = "method=updateAggShopperStatus")
    public String updateAggShopperStatus(HttpServletRequest request){
        String shopperid = request.getParameter("shopperid") == null ? null:request.getParameter("shopperid").toString();
        String status = request.getParameter("status") == null ? null:request.getParameter("status").toString();;
        if(StringUtils.isEmpty(shopperid)){
            request.setAttribute(Constants.URL_KEY,"shopperInfoAgg.htm?method=shopperAggStatusList");
            request.setAttribute(Constants.MESSAGE_KEY,"操作失败！商户不存在");
        } else {
            Map param = new HashMap();
            param.put("shopperid",shopperid);
            param.put("status",status);
            //更新商户状态
            shopPerbiService.updateShopperAggStatus(param);

            request.setAttribute(Constants.URL_KEY,"shopperInfoAgg.htm?method=shopperAggStatusList");
            request.setAttribute(Constants.MESSAGE_KEY,"操作成功！");
        }

        return "/returnPage";
    }



    /**
     * 导出查询列表
     * @param request
     * @param response
     * @param mbForm
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=findShopperAggPage")
    public String findShopperAggPage(HttpServletRequest request, HttpServletResponse response,
                                  ShopPerbiForm mbForm) throws Exception {

        if (mbForm.getSprovince() != null) {
            List searchProvincialList = shopPerbiService.searchProvincial(mbForm.getSprovince());
            if (searchProvincialList != null && searchProvincialList.size() > 0) {
                Area spro = (Area) searchProvincialList.get(0);
                if (spro != null) {
                    String sprov = spro.getProvincialname();
                    mbForm.setSprovince(sprov);
                }
            }
        }
        if (mbForm.getCity() != null) {
            List cityList = shopPerbiService.searchCity(mbForm.getCity());
            if (cityList != null && cityList.size() > 0) {
                Area area = (Area) cityList.get(0);
                if (area != null) {
                    String cityName = (String) area.getCityname();
                    mbForm.setCity(cityName);
                }
            }
        }
        String checkAgent = request.getParameter("checkAgent");
        if (StringUtils.isEmpty(checkAgent)) {
            mbForm.setCheckAgents(false);
        } else {
            if (checkAgent.equals("true")) {
                mbForm.setCheckAgents(true);
            } else {
                mbForm.setCheckAgents(false);
            }
        }
        Page page = new Page();
        page.setPageSize(Constants.EXCEL_SIZE);
        PageContext context = PageContext.getContext();
        BeanUtils.copyProperties(context, page);
        context.setPagination(true);
        shopPerbiService.findShopperAggTempList(mbForm);
        BeanUtils.copyProperties(page, context);
        request.setAttribute("mbForm", mbForm);
        request.setAttribute("page", page);
        request.setAttribute("checkAgent", checkAgent);

        return "aggShopper/exportShopperAggPage";
    }


    @RequestMapping(params = "method=downShopperAggExcel")
    public String downShopperAggExcel(HttpServletRequest request, HttpServletResponse response, ShopPerbiForm form)
            throws BusinessException, Exception {
        try {
            String checkAgent = request.getParameter("checkAgent");
            if (StringUtils.isEmpty(checkAgent)) {
                form.setCheckAgents(false);
            } else {
                if (checkAgent.equals("true")) {
                    form.setCheckAgents(true);
                } else {
                    form.setCheckAgents(false);
                }
            }
            String tPage = request.getParameter("page");
            if (StringUtils.isEmpty(tPage) || !org.apache.commons.lang3.StringUtils.isNumeric(tPage)) {
                tPage = "1";
            }
            int currentPage = Integer.valueOf(tPage);
            Page page = new Page();
            page.setPageSize(Constants.EXCEL_SIZE);
            PageContext context = PageContext.getContext();
            BeanUtils.copyProperties(context, page);
            context.setPagination(true);
            context.setCurrentPage(currentPage);
            List excelList = shopPerbiService.findShopperAggTempList(form);
            //标题
            Map<String, String> mapField = new LinkedHashMap();
            mapField.put("SHOPPERID", "商户编号");
            mapField.put("SCOMPANY", "商户名称");
            mapField.put("SPROVINCE", "商户地区(省份)");
            mapField.put("SCITY", "商户地区(城市)");
            mapField.put("STEL", "商户手机号");
            mapField.put("AGENTNAME", "代理商名称");
            mapField.put("AGENTTEL", "代理商编号");
            mapField.put("SIFPACTID", "商户状态");
            mapField.put("SIFPACTID", "业务类型");
            mapField.put("SIFPACTID", "审核状态");
            mapField.put("CREATED", "申请时间");
            mapField.put("CHECK_DATE", "审核时间");
            mapField.put("IFACTIVATED", "激活状态");

            String fileName = "MPOS商户注册信息数据导出";
            outExcel(excelList, response, mapField, fileName);
        } catch (Exception e) {
            log.info("导出数据有误！");
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 导出excel
     *
     * @param excelList
     * @param response
     * @param mapField
     * @throws Exception
     */
    private void outExcel(List excelList, HttpServletResponse response, Map<String, String> mapField, String fileNames) throws Exception {

        response.setContentType("application/vnd.ms-excel");
        response.setHeader("content-disposition", "attachment;filename=" + new String(fileNames.getBytes("UTF-8"), "iso8859-1") + ".xls");
        response.setCharacterEncoding("UTF-8");

        OutputStream os = response.getOutputStream();
        WritableWorkbook wwb = Workbook.createWorkbook(os);
        WritableSheet sheet = wwb.createSheet("商户用户注册信息", 0);
        SheetSettings ss = sheet.getSettings();
        ss.setVerticalFreeze(1);// 冻结表头

        WritableCellFormat wcf = new WritableCellFormat();
        WritableCellFormat wcf2 = new WritableCellFormat();

        int flag = 0;
        int columnIndex = 0;
        List<String> methodNameList = new ArrayList<String>();

        if (mapField != null && mapField.size() > 0) {
            String key = "";
            // 循环写入表头
            for (Iterator<String> i = mapField.keySet().iterator(); i.hasNext(); ) {
                key = i.next();
                sheet.addCell(new Label(columnIndex, 0, mapField.get(key), wcf));
                methodNameList.add(key);
                columnIndex++;
            }
            // 判断表中是否有数据
            if (excelList != null && excelList.size() > 0) {
                // 循环写入表中数据
                for (int i = 0; i < excelList.size(); i++) {
                    Map<String, Object> map = (Map<String, Object>) excelList.get(i);
                    // 循环输出map中的子集：既列值
                    int j = 0;
                    for (Object o : map.keySet()) {

                        //第一个参数为列坐标，第二个参数为行坐标，第三个参数为内容
                        sheet.addCell(new Label(0, i + 1, String.valueOf(map.get("SHOPPERID") == null ? "" : map.get("SHOPPERID")), wcf2));
                        sheet.addCell(new Label(1, i + 1, String.valueOf(map.get("SCOMPANY") == null ? "" : map.get("SCOMPANY")), wcf2));
                        sheet.addCell(new Label(2, i + 1, String.valueOf(map.get("SPROVINCE") == null ? "" : map.get("SPROVINCE")), wcf2));
                        sheet.addCell(new Label(3, i + 1, String.valueOf(map.get("SCITY") == null ? "" : map.get("SCITY")), wcf2));
                        sheet.addCell(new Label(4, i + 1, String.valueOf(map.get("STEL") == null ? "" : map.get("STEL")), wcf2));
                        sheet.addCell(new Label(5, i + 1, String.valueOf(map.get("SAGENTID") == null ? "" : map.get("SAGENTID")), wcf2));
                        sheet.addCell(new Label(6, i + 1, String.valueOf(map.get("SHOPPERBIID") == null ? "" : map.get("SHOPPERBIID")), wcf2));
                        String checkstatus = "";
                        switch (map.get("CHECKSTATUS").toString()){
                            case "6" :
                                checkstatus = "未审核";
                                break;
                            case "7" :
                                checkstatus = "审核中";
                                break;
                            case "8" :
                                checkstatus = "初审通过";
                                break;
                            case "9" :
                                checkstatus = "初审不通过";
                                break;
                            case "10" :
                                checkstatus = "复审通过";
                                break;
                            case "11" :
                                checkstatus = "复审不通过";
                                break;
                            default:
                                checkstatus = "未知";
                                break;

                        }
                        sheet.addCell(new Label(7, i + 1, checkstatus, wcf2));
                        sheet.addCell(new Label(8, i + 1, String.valueOf(map.get("CREATED") == null ? "" : map.get("CREATED")), wcf2));
                        sheet.addCell(new Label(9, i + 1, String.valueOf(map.get("CHECK_DATE") == null ? "" : map.get("CHECK_DATE")), wcf2));
                        String status = "";
                        if (Constants.CON_NO.equals(String.valueOf(map.get("SIFPACTID")))) {
                            status = "正常";
                        } else if (Constants.CON_YES.equals(String.valueOf(map.get("SIFPACTID")))) {
                            status = "冻结";
                        } else {
                            status = "注销";
                        }
                        sheet.addCell(new Label(10, i + 1, status, wcf2));

                    }

                }
            } else {
                flag = -1;
            }
            // 写入Exel工作表
            wwb.write();
            // 关闭Excel工作薄对象
            wwb.close();
            // 关闭流
            os.flush();
            os.close();
            os = null;
        }
    }

    /**
     * 商户用户状态列表导出查询
     * @param request
     * @param response
     * @param mbForm
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=findShopperAggStatusPage")
    public String findShopperAggStatusPage(HttpServletRequest request, HttpServletResponse response,
                                     ShopPerbiForm mbForm) throws Exception {

        Page page = new Page();
        page.setPageSize(Constants.EXCEL_SIZE);
        PageContext context = PageContext.getContext();
        BeanUtils.copyProperties(context, page);
        context.setPagination(true);
        shopPerbiService.findShopperAggStatusList(mbForm);
        BeanUtils.copyProperties(page, context);
        request.setAttribute("mbForm", mbForm);
        request.setAttribute("page", page);

        return "aggShopper/exportAggStatusPage";
    }


    @RequestMapping(params = "method=downShopperAggStatusExcel")
    public String downShopperAggStatusExcel(HttpServletRequest request, HttpServletResponse response, ShopPerbiForm form)
            throws BusinessException, Exception {
        try {
            String checkAgent = request.getParameter("checkAgent");
            if (StringUtils.isEmpty(checkAgent)) {
                form.setCheckAgents(false);
            } else {
                if (checkAgent.equals("true")) {
                    form.setCheckAgents(true);
                } else {
                    form.setCheckAgents(false);
                }
            }
            String tPage = request.getParameter("page");
            if (StringUtils.isEmpty(tPage) || !org.apache.commons.lang3.StringUtils.isNumeric(tPage)) {
                tPage = "1";
            }
            int currentPage = Integer.valueOf(tPage);
            Page page = new Page();
            page.setPageSize(Constants.EXCEL_SIZE);
            PageContext context = PageContext.getContext();
            BeanUtils.copyProperties(context, page);
            context.setPagination(true);
            context.setCurrentPage(currentPage);
            List excelList = shopPerbiService.findShopperAggTempList(form);
            //标题
            Map<String, String> mapField = new LinkedHashMap();
            mapField.put("SHOPPERID", "商户编号");
            mapField.put("SCOMPANY", "商户名称");
            mapField.put("SIFPACTID", "商户状态");

            String fileName = "MPOS商户状态信息数据导出";
            outStatusExcel(excelList, response, mapField, fileName);
        } catch (Exception e) {
            log.info("导出数据有误！");
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 商户状态导出excel
     *
     * @param excelList
     * @param response
     * @param mapField
     * @throws Exception
     */
    private void outStatusExcel(List excelList, HttpServletResponse response, Map<String, String> mapField, String fileNames) throws Exception {

        response.setContentType("application/vnd.ms-excel");
        response.setHeader("content-disposition", "attachment;filename=" + new String(fileNames.getBytes("UTF-8"), "iso8859-1") + ".xls");
        response.setCharacterEncoding("UTF-8");

        OutputStream os = response.getOutputStream();
        WritableWorkbook wwb = Workbook.createWorkbook(os);
        WritableSheet sheet = wwb.createSheet("商户用户状态信息", 0);
        SheetSettings ss = sheet.getSettings();
        ss.setVerticalFreeze(1);// 冻结表头

        WritableCellFormat wcf = new WritableCellFormat();
        WritableCellFormat wcf2 = new WritableCellFormat();

        int flag = 0;
        int columnIndex = 0;
        List<String> methodNameList = new ArrayList<String>();

        if (mapField != null && mapField.size() > 0) {
            String key = "";
            // 循环写入表头
            for (Iterator<String> i = mapField.keySet().iterator(); i.hasNext(); ) {
                key = i.next();
                sheet.addCell(new Label(columnIndex, 0, mapField.get(key), wcf));
                methodNameList.add(key);
                columnIndex++;
            }
            // 判断表中是否有数据
            if (excelList != null && excelList.size() > 0) {
                // 循环写入表中数据
                for (int i = 0; i < excelList.size(); i++) {
                    Map<String, Object> map = (Map<String, Object>) excelList.get(i);
                    // 循环输出map中的子集：既列值
                    int j = 0;
                    for (Object o : map.keySet()) {
                        sheet.setRowView(1,i+1);   //设置坐标
                        sheet.setColumnView(0,30); //设置单元格宽度
                        //第一个参数为列坐标，第二个参数为行坐标，第三个参数为内容
                        sheet.addCell(new Label(0, i + 1, String.valueOf(map.get("SHOPPERID") == null ? "" : map.get("SHOPPERID")), wcf2));
                        sheet.addCell(new Label(1, i + 1, String.valueOf(map.get("SCOMPANY") == null ? "" : map.get("SCOMPANY")), wcf2));
                        String status = "";
                        if (Constants.CON_NO.equals(String.valueOf(map.get("SIFPACTID")))) {
                            status = "正常";
                        } else if (Constants.CON_YES.equals(String.valueOf(map.get("SIFPACTID")))) {
                            status = "冻结";
                        } else {
                            status = "注销";
                        }
                        sheet.addCell(new Label(2, i + 1, status, wcf2));


                    }

                }
            } else {
                flag = -1;
            }
            // 写入Exel工作表
            wwb.write();
            // 关闭Excel工作薄对象
            wwb.close();
            // 关闭流
            os.flush();
            os.close();
            os = null;
        }
    }



}
