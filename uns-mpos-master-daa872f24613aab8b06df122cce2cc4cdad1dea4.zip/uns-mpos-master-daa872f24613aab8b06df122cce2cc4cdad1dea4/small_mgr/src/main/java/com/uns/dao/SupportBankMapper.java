package com.uns.dao;

import com.uns.web.form.SupportBankForm;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public interface SupportBankMapper extends BaseMapper<Object>{

    List<SupportBankForm> findSupportBankList(String showStatus);

    void insertSupportBankList(SupportBankForm supportBankForm);

    void deleteSupportBank(String showStatus);

    void updateSupportBank(Map map);

    Integer countSupportBank();
}
