package com.uns.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.dao.AgentMccMapper;
import com.uns.model.AgentMcc;
import com.uns.model.AgentSplit;

@Service
public class AgentMccService {
	
	@Autowired
	private AgentMccMapper agentMccMapper;

	public AgentMcc findAgentMcc(Long amid) {
		return agentMccMapper.findAgentMcc(amid);
	}
	
	public Boolean isMcc(Long agentidP) {
		List<Map> list = agentMccMapper.isMcc(agentidP);
		if(list!=null && list.size()>0)
			return true;
		else 
			return false;
	}

	public Map searchAgentMccById(Long amid) {
		// TODO Auto-generated method stub
		return agentMccMapper.searchAgentMccById(amid);
	}
	
	public Boolean isMccTmp(Long agentidP) {
		List<Map> list = agentMccMapper.isMccTmp(agentidP);
		if(list!=null && list.size()>0)
			return true;
		else 
			return false;
	}
	public List searchAgentMccList(String agentId) {
		return agentMccMapper.searchAgentMccList(agentId);
	}
	
	public List<AgentSplit> findAgentMcc6(Long agentid) {
		return agentMccMapper.findAgentMcc6(agentid);
	}

	public List<AgentMcc> findAgentMccMccid(Long agentid) throws Exception{
		return agentMccMapper.findAgentMccMccid(agentid);
	}
	public List<AgentMcc> findAgentMccTmpMccid(Long agentid) throws Exception{
		return agentMccMapper.findAgentMccTmpMccid(agentid);
	}
	
	
	public AgentMcc findAgentMccTmp(Long amid) throws Exception{
		return agentMccMapper.findAgentMccTmp(amid);
	}
	public AgentMcc findAgentMccTmp2(Long amid) throws Exception{
		return agentMccMapper.findAgentMccTmp2(amid);
	}

	public Long findAgentMccSq() {
		return agentMccMapper.findAgentMccSq();
	}

	public List findAgentMccTmpBySgentId(Long editAgentid) {
		return agentMccMapper.findAgentMccTmpBySgentId(editAgentid);
	}

	public List<AgentMcc> findAgentMccByAgentid(Long agentid) {
		return agentMccMapper.findAgentMccByAgentid(agentid);
	}

	public List<AgentMcc> findAgentMccTmpByAgentid(Long agentid) {
		return agentMccMapper.findAgentMccTmpByAgentid(agentid);
	}
}
