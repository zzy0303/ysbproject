package com.uns.util;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;

/**
 * 验证签名
 * @author yaxiong.zhai
 *
 */
public class CheckMacUtil {
	
	private static Logger logger = LoggerFactory.getLogger(CheckMacUtil.class);
	
	/**
	 * 将实体类的参数放入容器进行排序,并剔除需要剔除的参数(不包括mac)
	 * @param object
	 * @param eliminate
	 * @return
	 */
	public static <T> Map<String,String> getParamsOrdered(T object ,String... eliminate){
		//将实体类的属性放入treeMap
		Map<String,String> objectParams = JSONObject.parseObject(JSON.toJSONString(object), new TypeReference<Map<String, String>>(){});

		//声明要剔除的参数
		List<String> list = Arrays.asList(eliminate);
		
		//存放排序后的结果
		Map<String,String> params = new TreeMap<>();

		//将参数放入treeMap排序
		for(Map.Entry<String, String> entry : objectParams.entrySet()){
			if(!list.contains(entry.getKey())){
				params.put(entry.getKey(),entry.getValue());
			}
		}

		return params;
	}
	
	/**
	 * 将参数拼接起来比较MAC
	 * @param params
	 */
	public static String spellMac(Map<String, String> params){
		//参与验签的参数不能为空
		if(null==params||0==params.size()){
			return null;
		}
		
		//将其他的参数拼接起来
		StringBuffer sb = new StringBuffer();
		Iterator<String> ite = params.keySet().iterator();
		//params.forEach((k,v) ->sb.append(k).append("=").append(v).append("&"));
        while(ite.hasNext()){
            String key = ite.next();
            String value = params.get(key);
            sb.append(key).append("=").append(value).append("&");
        }

		//是否验签出错
		String result = sb.subSequence(0, sb.length()-1).toString();
		System.out.println(result);
		return result;
	}
	

	/**
	 * 字符串MD5加密
	 * @param str
	 * @return
	 */
	public static String stringToMd5(String str) {
		try {
			MessageDigest md5 = MessageDigest.getInstance(Algorithms.MD5.toString());
			md5.update(str.getBytes(Code.UTF.getName()));
			byte[] encryption = md5.digest();
			StringBuffer strBuf = new StringBuffer();
			for (int i = 0; i < encryption.length; i++) {
			    if (Integer.toHexString(0xff & encryption[i]).length() == 1) {
			        strBuf.append("0").append(Integer.toHexString(0xff & encryption[i]));
			    } else {
			        strBuf.append(Integer.toHexString(0xff & encryption[i]));
			    }
			}
			return strBuf.toString();
		} catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return "";
    }

	/**
	 * 验证签名（有需要剔除的字段）
	 * @param object
	 * @param eliminate
	 */
	public static <T> String assembleMac(T object ,String... eliminate){
		//剔除参数并排序
		Map<String,String> params = getParamsOrdered(object, eliminate);

		//拼接MAC
		String result = stringToMd5(spellMac(params)).toUpperCase();
		System.out.println(result);
		return result;
	}
	
	/**
	 * 加密算法
	 * @author yaxiong.zhai
	 *
	 */
	enum Algorithms{
		MD5;
	}
	
	/**
	 * 编码
	 * @author yaxiong.zhai
	 *
	 */
	enum Code{
		
		GBK("GBK"),
		
		UTF("UTF-8");
		
		String name;

		private Code(String name) {
			this.name = name;
		}
		
		public String getName() {
			return name;
		}
	}
	
	/**
	 * 剔除字段枚举
	 * @author yaxiong.zhai
	 *
	 */
	public enum Eliminates{
		
		serialVersionUID,
		
		userAgent,
		
		mac;
	}
	
	public static void main(String[] args) {
        Map params = new HashMap();
        params.put("smallMerchNo","123123123");
        params.put("wxAppId","asdasda");
        params.put("wxAppSecret","fdgdg");
        params.put("bankCode","paBank");
        params.put("mchId","qweq");
        params.put("mchKey","hghhhgg");

        assembleMac(params);
	}
}