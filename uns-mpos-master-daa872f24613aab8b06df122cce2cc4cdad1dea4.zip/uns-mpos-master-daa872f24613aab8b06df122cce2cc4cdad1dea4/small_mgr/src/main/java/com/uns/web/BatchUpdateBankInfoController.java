package com.uns.web;

import com.uns.common.Global;
import com.uns.service.ShopPerbiService;

public class BatchUpdateBankInfoController extends BaseController {

	
	
	 /**
	 * 
	 * 批量修改结算信息
	 */
	public  static void run(String[] args) throws Exception {
		 ShopPerbiService shopPerbiService = (ShopPerbiService) Global.getSpringContext().getBean("shopPerbiService");
		 shopPerbiService.batchBankInfo();
	   }
	
}
