package com.uns.web;

import com.uns.service.CountOcrUseService;
import jxl.SheetSettings;
import jxl.Workbook;
import jxl.write.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.util.*;
import java.util.List;

@Controller("CountOcrUseController")
@RequestMapping("/countOcrUse.htm")
public class CountOcrUseController extends BaseController{

    @Autowired
    private CountOcrUseService countOcrUseService;

    /**
     * 统计OCR使用情况
     * @param countStartDate
     * @param countEndDate
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(params = "method=findCountOcrUseList")
    public String findCountOcrUseList(Date countStartDate, Date countEndDate, ModelMap modelMap,HttpServletRequest request){
        List<HashMap> countList = new ArrayList<>();
        if(countStartDate != null && countEndDate != null){
            HashMap countMap = countOcrUseService.findCountOcrUse(countStartDate,countEndDate);
            countList.add(countMap);
            modelMap.put("countList",countList);
        }
        request.setAttribute("countList",countList);
        return "shopperOCRnew/countOcrUse";
    }

    /**
     * 导出OCR操作统计
     * @param request
     * @param response
     */
    @RequestMapping(params = "method=downCountOcrUseExcel")
    public void downCountOcrUseExcel(HttpServletRequest request, HttpServletResponse response){
        try {
            Map<String,String> count = new HashMap<>();
            count.put("countDate",request.getParameter("countDate"));
            count.put("htCount",request.getParameter("htCount"));
            count.put("sfzCount",request.getParameter("sfzCount"));
            count.put("yhkCount",request.getParameter("yhkCount"));

            if(count != null){
                Map<String, String> mapField = new LinkedHashMap();
                //标题
                mapField.put("countDate", "日期");
                mapField.put("htCount", "活体OCR统计");
                mapField.put("sfzCount", "身份证OCR统计");
                mapField.put("yhkCount", "银行卡OCR统计");
                //YSB-OCR统计新加字段
                if(null != request.getParameter("policeCount") || null != request.getParameter("faceCount")){
                    count.put("policeCount",request.getParameter("policeCount"));
                    count.put("faceCount",request.getParameter("faceCount"));
                    count.put("projectName","供应链金融");
                    mapField.put("policeCount","公安接口统计");
                    mapField.put("faceCount","人脸比对统计");
                    mapField.put("projectName","项目名称");
                }

                String fileName = "OCR使用情况统计数据导出";
                outExcel(count, response, mapField, fileName);
            }

        } catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     * 导出excel
     * @param count
     * @param response
     * @param mapField
     * @param fileNames
     * @throws IOException
     * @throws WriteException
     */
    public void outExcel(Map count, HttpServletResponse response, Map<String, String> mapField, String fileNames) throws IOException, WriteException {
        response.setContentType("application/vnd.ms-excel");
        response.setHeader("content-disposition", "attachment;filename=" + new String(fileNames.getBytes("UTF-8"), "iso8859-1") + ".xls");
        response.setCharacterEncoding("UTF-8");
        OutputStream os = response.getOutputStream();
        WritableWorkbook wwb = Workbook.createWorkbook(os);
        WritableSheet sheet = wwb.createSheet("OCR使用情况统计数据", 0);
        SheetSettings ss = sheet.getSettings();
        ss.setVerticalFreeze(1);// 冻结表头

        WritableCellFormat wcf = new WritableCellFormat();
        WritableCellFormat wcf2 = new WritableCellFormat();

        int columnIndex = 0;
        List<String> methodNameList = new ArrayList<String>();

        if (mapField != null && mapField.size() > 0) {
            String key = "";
            // 循环写入表头
            for (Iterator<String> i = mapField.keySet().iterator(); i.hasNext(); ) {
                key = i.next();
                sheet.addCell(new Label(columnIndex, 0, mapField.get(key), wcf));
                methodNameList.add(key);
                columnIndex++;
            }
            //第一个参数为列坐标，第二个参数为行坐标，第三个参数为内容
            sheet.addCell(new Label(0, 1, String.valueOf(count.get("countDate") == null ? "" : count.get("countDate")), wcf2));
            sheet.addCell(new Label(1, 1, String.valueOf(count.get("htCount") == null ? "" : count.get("htCount")), wcf2));
            sheet.addCell(new Label(2, 1, String.valueOf(count.get("sfzCount") == null ? "" : count.get("sfzCount")), wcf2));
            sheet.addCell(new Label(3, 1, String.valueOf(count.get("yhkCount") == null ? "" : count.get("yhkCount")), wcf2));
            if(null != count.get("policeCount") || null != count.get("faceCount")){
                sheet.addCell(new Label(4,1,String.valueOf(count.get("policeCount").toString()),wcf2));
                sheet.addCell(new Label(5,1,String.valueOf(count.get("faceCount").toString()),wcf2));
                sheet.addCell(new Label(6,1,String.valueOf(count.get("projectName").toString()),wcf2));
            }

            // 写入Exel工作表
            wwb.write();
            // 关闭Excel工作薄对象
            wwb.close();
            // 关闭流
            os.flush();
            os.close();
            os = null;
        }
    }


    /**
     * 银生宝统计OCR使用情况
     * @param countStartDate
     * @param countEndDate
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(params = "method=findCountYsbOcrUseList")
    public String findCountYsbOcrUseList(Date countStartDate, Date countEndDate, ModelMap modelMap,HttpServletRequest request){
        List<HashMap> countList = new ArrayList<>();
        try {
            if(countStartDate != null && countEndDate != null){
                HashMap countMap = countOcrUseService.findYsbOcrCount(countStartDate,countEndDate);
                countList.add(countMap);
                modelMap.put("countList",countList);
            }
        } catch (Exception e){
            e.printStackTrace();
        }
        request.setAttribute("countList",countList);
        return "shopperOCRnew/countYsbOcrUse";
    }


}
