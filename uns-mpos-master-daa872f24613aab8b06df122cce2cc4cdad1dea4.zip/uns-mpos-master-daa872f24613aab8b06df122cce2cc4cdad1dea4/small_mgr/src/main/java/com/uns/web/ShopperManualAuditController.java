package com.uns.web;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.model.Area;
import com.uns.model.B2cDict;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.MposMerchantFee;
import com.uns.model.MposPhoto;
import com.uns.model.MposPhotoTmp;
import com.uns.service.ShopPerbiService;
import com.uns.util.AcmsMapUtils;
import com.uns.util.RegMposAndQrcode;
import com.uns.util.ReportHFandHK;
import com.uns.web.form.ShopPerbiForm;


/**
 * 商户人工审核controller
 */
@Controller
@RequestMapping("/shopperManualAudit.htm")
public class ShopperManualAuditController extends BaseController {

    @Autowired
    private AcmsMapUtils acmsMapUtils;
    
    @Autowired
    ShopPerbiService shopPerbiService;
    
    @Autowired
    ReportHFandHK reportHFandHK;
    
    @Autowired
    RegMposAndQrcode regMposAndQrcode;

    /**
     * 商户人工审核列表
     *
     * @param request
     * @param modelMap
     * @param mbForm
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=shopperManualAuditList")
    public String shopperManualAuditList(HttpServletRequest request, ModelMap modelMap, ShopPerbiForm mbForm) throws Exception {
        try {
            //获取省
            List<Area> Provincial = shopPerbiService.searchProvince();
            request.setAttribute("Provincial", Provincial);
            //获取市
            List<Area> list = shopPerbiService.searchArea();
            request.setAttribute("area", list);
            //查询商户信息
            List<HashMap> shopperTempList = shopPerbiService.findShopperTempCheckList(mbForm);
            Map<String, String> checkstatus = shopPerbiService.findCheckstatusCount();//商户人工检查统计
            modelMap.put("checkstatus", checkstatus);
            modelMap.put("shopperTempList", shopperTempList);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }
        return "shopperOCRnew/shopperManualAuditList";
    }

    /**
     * 人工审核详情
     *
     * @param request
     * @param modelMap
     * @param mbForm
     * @return
     */
    @RequestMapping(params = "method=shopperManualAuditDetails")
    @FormToken(save = true)
    public String shopperManualAuditDetails(HttpServletRequest request, ModelMap modelMap, ShopPerbiForm mbForm) throws BusinessException {
        try {

            //获取shopperid
            String shopperid = mbForm.getShopperid();

            //更新人工检查状态
            shopPerbiService.updateVisualCheckStatus(shopperid, Constants.TYPE_1);

            Map shopperTemp = shopPerbiService.findShopperTempDetails(Long.valueOf(shopperid));
            Map shopperFormal = shopPerbiService.findShopperFormalDetails(Long.valueOf(shopperid));
            if (null == shopperTemp || null == shopperFormal) {
                throw new BusinessException(ExceptionDefine.获取商户信息失败);
            }
            // 预约图片
            Long photoid = null;
            if (null != shopperTemp.get("PHOTO_ID")) {
                photoid = ((BigDecimal) shopperTemp.get("PHOTO_ID")).longValue();
                MposPhotoTmp photo = shopPerbiService.selectPhotoTmpById(photoid);
                request.setAttribute("photo", photo);
                request.setAttribute("image_get_url", DynamicConfigLoader.getByEnv("imageget.url"));
            }

            // 正式图片
            if (null != shopperFormal.get("PHOTO_ID")) {
                photoid = ((BigDecimal) shopperFormal.get("PHOTO_ID")).longValue();
                MposPhoto photo = shopPerbiService.selectPhotoById(photoid);
                request.setAttribute("photoFormal", photo);
                request.setAttribute("image_get_urlFormal", DynamicConfigLoader.getByEnv("imageget.url"));
            }

            //获取银行名称
            String bankDictval = (String) shopperTemp.get("ACCOUNT_BANK_DICTVAL");
            B2cDict bankInfo = shopPerbiService.findBankName(bankDictval);
            String bankDictvalName = bankInfo.getDict();
            request.setAttribute("accountBankDictvalName", bankDictvalName);

            bankDictval = (String) shopperTemp.get("CREDIT_BANK_DICTVAL");
            request.setAttribute("creditBankDictvalName", bankDictval);
            
            //获取费率信息
            // 手续费，临时表
            MposMerchantFee s0creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_CREDIT, Constants.S0_CHANNEL_TYPE);
            MposMerchantFee s0debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_DEBIT, Constants.S0_CHANNEL_TYPE);

            MposMerchantFee d0creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_CREDIT, Constants.D0_CHANNEL_TYPE);
            MposMerchantFee d0debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_DEBIT, Constants.D0_CHANNEL_TYPE);

            MposMerchantFee t1creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_CREDIT, Constants.T1_CHANNEL_TYPE);
            MposMerchantFee t1debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_DEBIT, Constants.T1_CHANNEL_TYPE);

            MposMerchantFee weChatMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_WECHAT);
            MposMerchantFee alipayMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_ALIPAY);
            MposMerchantFee ylpayMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_YLPAY);

            MposMerchantFee shortCutMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_SHORTCUT);//快捷汇率
            MposMerchantFee shortCutSHMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_SHD0);//速惠汇率
            MposMerchantFee b2cMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_B2C);//B2C汇率

            request.setAttribute("shortCutSHMerchantFeeTemp", shortCutSHMerchantFeeTemp);
            request.setAttribute("shortCutMerchantFeeTemp", shortCutMerchantFeeTemp);
            request.setAttribute("b2cMerchantFeeTemp", b2cMerchantFeeTemp);

            request.setAttribute("s0creditMerchantFeeTemp", s0creditMerchantFeeTemp);
            request.setAttribute("s0debitMerchantFeeTemp", s0debitMerchantFeeTemp);

            request.setAttribute("d0creditMerchantFeeTemp", d0creditMerchantFeeTemp);
            request.setAttribute("d0debitMerchantFeeTemp", d0debitMerchantFeeTemp);

            request.setAttribute("t1creditMerchantFeeTemp", t1creditMerchantFeeTemp);
            request.setAttribute("t1debitMerchantFeeTemp", t1debitMerchantFeeTemp);

            request.setAttribute("weChatMerchantFeeTemp", weChatMerchantFeeTemp);
            request.setAttribute("alipayMerchantFeeTemp", alipayMerchantFeeTemp);
            request.setAttribute("ylpayMerchantFeeTemp", ylpayMerchantFeeTemp);

            //获取手续费正式表
            MposMerchantFee s0creditMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_CREDIT, Constants.S0_CHANNEL_TYPE);
            MposMerchantFee s0debitMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_DEBIT, Constants.S0_CHANNEL_TYPE);

            MposMerchantFee d0creditMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_CREDIT, Constants.D0_CHANNEL_TYPE);
            MposMerchantFee d0debitMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_DEBIT, Constants.D0_CHANNEL_TYPE);

            MposMerchantFee t1creditMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_CREDIT, Constants.T1_CHANNEL_TYPE);
            MposMerchantFee t1debitMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_DEBIT, Constants.T1_CHANNEL_TYPE);

            MposMerchantFee weChatMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_WECHAT);
            MposMerchantFee alipayMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_ALIPAY);
            MposMerchantFee ylpayMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_YLPAY);

            MposMerchantFee shortCutMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_SHORTCUT);//快捷汇率
            MposMerchantFee shortCutSHMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_SHD0);//速惠汇率
            MposMerchantFee b2cMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_B2C);//B2C汇率

            request.setAttribute("shortCutSHMerchantFee", shortCutSHMerchantFee);
            request.setAttribute("shortCutMerchantFee", shortCutMerchantFee);
            request.setAttribute("b2cMerchantFee", b2cMerchantFee);

            request.setAttribute("s0creditMerchantFee", s0creditMerchantFee);
            request.setAttribute("s0debitMerchantFee", s0debitMerchantFee);

            request.setAttribute("d0creditMerchantFee", d0creditMerchantFee);
            request.setAttribute("d0debitMerchantFee", d0debitMerchantFee);

            request.setAttribute("t1creditMerchantFee", t1creditMerchantFee);
            request.setAttribute("t1debitMerchantFee", t1debitMerchantFee);

            request.setAttribute("weChatMerchantFee", weChatMerchantFee);
            request.setAttribute("alipayMerchantFee", alipayMerchantFee);
            request.setAttribute("ylpayMerchantFee", ylpayMerchantFee);

            //分润
            String merchProfitRatio2 = (String) shopperTemp.get("MERCH_PROFIT_RATIO2");
            String merchProfitRatio3 = (String) shopperTemp.get("MERCH_PROFIT_RATIO3");
            if (null != merchProfitRatio2 && null != merchProfitRatio3) {
                //分润方案2
                String[] split2 = merchProfitRatio2.split("\\|");
                //分润方案3
                String[] split3 = merchProfitRatio3.split("\\|");
                request.setAttribute("split2", split2);
                request.setAttribute("split3", split3);
            }
            
            //正式分润
            String merchProfitRatioFormal2 = (String) shopperFormal.get("MERCH_PROFIT_RATIO2");
            String merchProfitRatioFormal3 = (String) shopperFormal.get("MERCH_PROFIT_RATIO3");
            if (null != merchProfitRatioFormal2 && null != merchProfitRatioFormal3) {
                //分润方案2
                String[] splitFormal2 = merchProfitRatioFormal2.split("\\|");
                //分润方案3
                String[] splitFormal3 = merchProfitRatioFormal3.split("\\|");
                request.setAttribute("splitFormal2", splitFormal2);
                request.setAttribute("splitFormal3", splitFormal3);
            }

            request.setAttribute("shopper", shopperTemp);
            request.setAttribute("shopperFormal", shopperFormal);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }
        return "shopperOCRnew/shopperManualAuditDetails";
    }

    /**
     * 保存商户审核结果（激活商户）
     *
     * @param request
     * @param mbForm
     * @return
     */
    @RequestMapping(params = "method=saveShopperManualAudit")
    @FormToken(remove = true)
    public String saveShopperManualAudit(HttpServletRequest request, ShopPerbiForm mbForm) throws Exception {
        String shopperid = null;
        B2cShopperbiTemp b2cShopperbiTemp = null;
        //获取审核状态
        String checkstatus = mbForm.getCheckstatus();
        shopperid = mbForm.getShopperid();
        b2cShopperbiTemp = shopPerbiService.queryShopPerbi(shopperid);
        //修改商户审核状态
        b2cShopperbiTemp.setCheckstatus(checkstatus);
        b2cShopperbiTemp.setRecheckdate(new Date());//审核时间
        b2cShopperbiTemp.setVisualCheckStatus(Constants.TYPE_1);//人工检查状态

        if (Constants.TYPE_5.equals(checkstatus)) {//人工审核通过
            b2cShopperbiTemp.setIfvalid(Short.valueOf(Constants.TYPE_1));//审核通过
            b2cShopperbiTemp.setRecheckmerchantflag(Constants.TYPE_1);//维护复审状态
           //如果开启弘付注册
            if(acmsMapUtils.getAcmsMap().get("hf_open_flg").equals(Constants.CON_YES)){
               //如果之前弘付报备失败
                  reportHFandHK.reportHF(b2cShopperbiTemp);
            }
            if (acmsMapUtils.getAcmsMap().get("hk_open_flg").equals(Constants.CON_YES)){
                  reportHFandHK.reportHK(b2cShopperbiTemp);//报备海科
            }
            if(!(Short.valueOf(Constants.TYPE_1) == b2cShopperbiTemp.getIsformal())){//注册
                log.info("商户人工审核：注册！");
                regMposAndQrcode.regMposMerchant(b2cShopperbiTemp, request);
            }else{
                log.info("商户人工审核：修改！");
                regMposAndQrcode.updateYsbMerchant(b2cShopperbiTemp, request);
            }
        } else {//人工审核不通过
            b2cShopperbiTemp.setIfvalid(Short.valueOf(Constants.TYPE_1));//初审通过（老app）
            b2cShopperbiTemp.setRecheckmerchantflag(Constants.TYPE_2);//复审不通过（老app）
            b2cShopperbiTemp.setRecheckmerchantremark(mbForm.getNotPassReason());//维护老商户复审不通过原因
            
            String oldNotPassStep = b2cShopperbiTemp.getNotPassStep();
            //老商户没有错误步骤,给一个默认值
            if(null == oldNotPassStep){
                oldNotPassStep = Constants.OLD_NOT_PASS_STEP;
            }
            //获取错误步骤复选框
            String[] notPassStep = mbForm.getNotPassStep();
            String flag = Constants.TYPE_0;//贷记卡错误标志
            for (String str : notPassStep) {
                if(Constants.TYPE_4.equals(str)){
                    flag = Constants.TYPE_1;
                }
                oldNotPassStep = shopPerbiService.changeNotPassStep(oldNotPassStep, str);
            }
            if(Constants.TYPE_0.equals(flag)){//如果贷记卡未提交通过
                oldNotPassStep = shopPerbiService.replaceIndex(Constants.INT_4, oldNotPassStep, Constants.TYPE_3);
            }
            b2cShopperbiTemp.setNotPassStep(oldNotPassStep);
            b2cShopperbiTemp.setNotPassReason(mbForm.getNotPassReason());
            shopPerbiService.updateShopperManualaudit(b2cShopperbiTemp);//更新预约信息
        }
        request.setAttribute(Constants.URL_KEY, "shopperManualAudit.htm?method=shopperManualAuditList");
        request.setAttribute(Constants.MESSAGE_KEY, "审核成功");
        return "/returnPage";
       
    }
}
