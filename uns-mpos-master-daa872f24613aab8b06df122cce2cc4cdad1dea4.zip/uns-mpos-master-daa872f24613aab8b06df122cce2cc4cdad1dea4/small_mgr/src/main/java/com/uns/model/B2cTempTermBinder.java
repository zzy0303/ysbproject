package com.uns.model;

import java.util.Date;

public class B2cTempTermBinder {
    
    private String merchantNo;
    private String termNo;
    private Date createDate;
    private String  status ;
    
    private String firstVerify;
	private String lastVerify;
	private String remark; 
    
	
	
    public String getFirstVerify() {
		return firstVerify;
	}
	public void setFirstVerify(String firstVerify) {
		this.firstVerify = firstVerify;
	}
	public String getLastVerify() {
		return lastVerify;
	}
	public void setLastVerify(String lastVerify) {
		this.lastVerify = lastVerify;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
    public String getMerchantNo() {
		return merchantNo;
	}
	public void setMerchantNo(String merchantNo) {
		this.merchantNo = merchantNo;
	}
	public String getTermNo() {
		return termNo;
	}
	public void setTermNo(String termNo) {
		this.termNo = termNo;
	}
	public Date getCreateDate() {
        return createDate;
    }
   
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
}