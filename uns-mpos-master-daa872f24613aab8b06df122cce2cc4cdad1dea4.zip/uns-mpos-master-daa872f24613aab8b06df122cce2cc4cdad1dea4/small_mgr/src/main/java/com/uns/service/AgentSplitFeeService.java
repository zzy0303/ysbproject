package com.uns.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.exception.BusinessException;
import com.uns.common.page.PageContext;
import com.uns.dao.B2cAgentSplitFeesMapper;
import com.uns.dao.B2cTranhisMapper;
import com.uns.model.B2cTranhis;
import com.uns.web.form.AgentSplitFeeForm;

@Service
public class AgentSplitFeeService {
	
	@Autowired
	private B2cAgentSplitFeesMapper b2cAgentSplitFeesMapper;
	
	@Autowired
	private B2cTranhisMapper tradeMapper;

	/**分润历史统计信息汇总
	 * @param form
	 * @return
	 */
	public List getSplitFeesList(AgentSplitFeeForm form) {
		PageContext.initPageSize(5);
		return b2cAgentSplitFeesMapper.getSplitFeesList(form);
	}

	/**分润历史统计信息列表
	 * @param form
	 * @return
	 */
	public List getAgentSplitFeeList(AgentSplitFeeForm form) {
		PageContext.initPageSize(5);
		return b2cAgentSplitFeesMapper.getAgentSplitFeeList(form);
	}

	
	public List findExcelList(AgentSplitFeeForm form) throws BusinessException, Exception
	{
		
		PageContext.initPageSize(500);
		List trades = b2cAgentSplitFeesMapper.getExcelAgentSplitFeeList(form);
		if(trades!=null && trades.size()!=0)
		{
			return trades;
		}
		return new ArrayList<B2cTranhis>();
	}

	/**根据代理商查询商户的交易详情
	 * @param agengId
	 * @return
	 */
	public List<B2cTranhis> findTradeSbList(String agengId) {
		PageContext.initPageSize(20);
		return tradeMapper.findTradeSbListByAgentIdList(Long.valueOf(agengId));
	}

}
