package com.uns.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.OrderInfo;

@Repository
public interface OrderInfoMapper {
	List<OrderInfo> selectOrderInfoList(Map<String, Object> param);
	
	List<Map<String, String>> selectAllList(Map<String, Object> param);
	
	Map<String, String> selectSum(Map<String, Object> param);
	
	List<Map<String, String>> selectTerminalNoCur(Map<String, Object> param);
	
	List<Map<String, String>> selectTerminalNoHis(Map<String, Object> param);
}