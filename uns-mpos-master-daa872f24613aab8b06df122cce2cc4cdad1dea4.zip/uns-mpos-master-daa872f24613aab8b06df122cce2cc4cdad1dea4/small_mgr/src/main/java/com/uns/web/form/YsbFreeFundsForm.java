package com.uns.web.form;

public class YsbFreeFundsForm {

	private String orderidq;
	private String createdStart;
	private String createdEnd;
	private String ysbFreeFundsType;
	private String rspcodeq;
	
	public String getOrderidq() {
		return orderidq;
	}
	public void setOrderidq(String orderidq) {
		this.orderidq = orderidq==null?"":orderidq.trim();
	}
	public String getCreatedStart() {
		return createdStart;
	}
	public void setCreatedStart(String createdStart) {
		this.createdStart = createdStart==null?"":createdStart.trim();
	}
	public String getCreatedEnd() {
		return createdEnd;
	}
	public void setCreatedEnd(String createdEnd) {
		this.createdEnd = createdEnd==null?"":createdEnd.trim();
	}
	public String getYsbFreeFundsType() {
		return ysbFreeFundsType;
	}
	public void setYsbFreeFundsType(String ysbFreeFundsType) {
		this.ysbFreeFundsType = ysbFreeFundsType==null?"":ysbFreeFundsType.trim();
	}
	public String getRspcodeq() {
		return rspcodeq;
	}
	public void setRspcodeq(String rspcodeq) {
		this.rspcodeq = rspcodeq==null?"":rspcodeq.trim();
	}
	
}
