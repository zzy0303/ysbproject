package com.uns.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.common.page.PageContext;
import com.uns.dao.YsbFreeFundsMapper;
import com.uns.model.YsbFreeFunds;
import com.uns.web.form.YsbFreeFundsForm;

@Service
public class YsbFreeFundsService {

	@Autowired
	private YsbFreeFundsMapper ysbFreeFundsMapper;
	
	public List findYsbFreeFundsList(YsbFreeFundsForm mbform) {
		PageContext.initPageSize(Constants.page_size);
		return ysbFreeFundsMapper.findYsbFreeFundsList(mbform);
	}

	public void insert(YsbFreeFunds ysbFreeFunds) {
		ysbFreeFundsMapper.insertSelective(ysbFreeFunds);
	}

	public YsbFreeFunds findRechargeById(String ysbFreeFundsId) {
		return ysbFreeFundsMapper.selectByPrimaryKey(Long.valueOf(ysbFreeFundsId));
	}

}
