package com.uns.service;

import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.uns.common.ConstantsEnv;
import com.uns.common.exception.ExceptionDefine;
import com.uns.util.*;
import com.uns.web.ShopperInfoOCRController;
import net.sf.json.JSONObject;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.dao.AgentMapper;
import com.uns.dao.AgentTopFeeMapper;
import com.uns.dao.AreaMapper;
import com.uns.dao.B2cAgentBinderMapper;
import com.uns.dao.B2cDictMapper;
import com.uns.dao.B2cFootfreqMapper;
import com.uns.dao.B2cShopperbargainMapper;
import com.uns.dao.B2cShopperbargainTempMapper;
import com.uns.dao.B2cShopperbiMapper;
import com.uns.dao.B2cShopperbiTempHistoryMapper;
import com.uns.dao.B2cShopperbiTempMapper;
import com.uns.dao.B2cShopperbiTempModifyMapper;
import com.uns.dao.B2cTempTermBinderMapper;
import com.uns.dao.B2cTermBinderMapper;
import com.uns.dao.B2cTerminalMapper;
import com.uns.dao.B2cUserMapper;
import com.uns.dao.BackupsShopperInformationMapper;
import com.uns.dao.FixAmaountMapper;
import com.uns.dao.MposApplicationProgressMapper;
import com.uns.dao.MposMerchantFeeMapper;
import com.uns.dao.MposPhotoMapper;
import com.uns.dao.MposPhotoTmpMapper;
import com.uns.dao.MposRemoteInvitationMapper;
import com.uns.dao.OperatorMapper;
import com.uns.dao.UpdateFeeHistoryMapper;
import com.uns.dao.UsersMapper;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.model.Agent;
import com.uns.model.AgentTopFee;
import com.uns.model.Area;
import com.uns.model.B2cAgentBinder;
import com.uns.model.B2cDict;
import com.uns.model.B2cFixedCode;
import com.uns.model.B2cFootfreq;
import com.uns.model.B2cShopperbargain;
import com.uns.model.B2cShopperbargainTemp;
import com.uns.model.B2cShopperbi;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.B2cShopperbiTempHistory;
import com.uns.model.B2cShopperbiTempModify;
import com.uns.model.B2cTempTermBinder;
import com.uns.model.B2cTermBinder;
import com.uns.model.B2cTerminal;
import com.uns.model.B2cUser;
import com.uns.model.BackupsShopperInformation;
import com.uns.model.FixAmaount;
import com.uns.model.MposApplicationProgress;
import com.uns.model.MposMerchantFee;
import com.uns.model.MposPhoto;
import com.uns.model.MposPhotoTmp;
import com.uns.model.Operator;
import com.uns.model.UpdateFeeHistory;
import com.uns.model.Users;
import com.uns.web.form.ShopPerbiForm;

import javax.servlet.http.HttpServletRequest;

import static com.uns.util.JsonUtil.jsonStrToMap;


/**
 * @author ting.zeng
 *
 */
@Service
public class ShopPerbiService {
	
	protected Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private UsersMapper usersMapper;
	@Autowired
	private OperatorMapper operatorMapper;
	@Autowired
	private B2cDictMapper b2cDictMapper;
	@Autowired
	private MposMerchantFeeMapper  mposMerchantFeeMapper;
	
	@Autowired
	private B2cFootfreqMapper b2cFootfreqMapper;
	
	@Autowired
	private AreaMapper areaMapper;
	
	@Autowired
	private B2cAgentBinderMapper b2cAgentBinderMapper;
	
	@Autowired
	private B2cUserMapper b2cUserMapper;
	
	@Autowired
	private AgentMapper agentMapper;
	
	@Autowired
	private AgentTopFeeMapper agenttopfeeMapper;
	
	@Autowired
	private FixAmaountMapper fixamountmapper;
	
	
	@Autowired
	private B2cShopperbiMapper b2cShopperbiMapper;
	
	@Autowired
	private B2cShopperbiTempMapper b2cShopperbiTempMapper;
	
	@Autowired
	private B2cShopperbargainTempMapper b2cShopperbargainTempMapper;
	
	@Autowired
	private B2cShopperbargainMapper b2cShopperbargainMapper;

	@Autowired
	private B2cTermBinderMapper b2cTermBinderMapper;
	
	@Autowired
	private B2cTerminalMapper b2cTerminalMapper;
	
	@Autowired
	private B2cTempTermBinderMapper b2cTempTermBinderMapper;
	
	@Autowired
	private MposPhotoTmpMapper mposphototmpmapper;
	
	@Autowired
	private MposApplicationProgressMapper  progressmapper;
	
	
	@Autowired
	private B2cDictMapper b2cdictmapper;
	
	@Autowired	
	private B2cShopperbargainTempMapper  bartemp;
//	@Autowired
//	private  B2cFormalShopperbiMapper b2cFormalShopperbiMapper;
//	@Autowired
//	private  B2cFormalShopperbargainMapper  b2cFormalShopperbargainMapper;
	
	@Autowired
	private B2cShopperbiTempHistoryMapper b2cShopperbiTempHistoryMapper;
	
	@Autowired
	private MposRemoteInvitationMapper mposRemoteInvitationMapper;
	
    @Autowired
    private MposApplicationProgressMapper  mposapplicationprogressmapper;
    
    
    @Autowired
    private BackupsShopperInformationMapper  bkshoppermapper;
    
    
    @Autowired
	private UpdateFeeHistoryMapper feehismapper;
    
    @Autowired
    private B2cShopperbiTempModifyMapper modifyMapper;
    
    @Autowired
    private MposPhotoMapper mposPhotoMapper;
    
	public List<HashMap> selectAgentNum(String agentNo){
		List<HashMap> list=b2cAgentBinderMapper.selectBinderNum(agentNo);
		return list;
	}
	/**
	 * 
	 * 查询中间表终端信息
	 * @return 
	 */
	public B2cTempTermBinder selectTempTermNo(String terminalid) {
		List list=b2cTempTermBinderMapper.selectByTempBinder(terminalid);
		B2cTempTermBinder b2cTempTermBinder=null;
		if(list!=null&&list.size()>0){
			b2cTempTermBinder=(B2cTempTermBinder)list.get(0);
		}
		return b2cTempTermBinder;
	}
	/**
	 * 
	 * 删除未绑定成功的终端号
	 * @return 
	 */
	public void deleteTempTermianl(String termno){
		b2cTempTermBinderMapper.deleteByTermno(termno);
	}
	/**
	 * 
	 * 添加绑定的中间表
	 */
	public void addTempBinder(B2cTempTermBinder b2cTempTermBinder) {
		b2cTempTermBinderMapper.insert(b2cTempTermBinder);
	}
	
	/**
	 * 
	 * 根据terNUM查询代理商编号
	 */
	public B2cAgentBinder selectByTermNo(String termNum){
		B2cAgentBinder agentbinder=b2cAgentBinderMapper.selectAgentnoByTermNo(termNum);
		return agentbinder;
	};
	/**
	 * 
	 * 查询出终端信息
	 * @return 
	 */
	public B2cTerminal findtermainal(String terminalid) {
		return b2cTerminalMapper.selectByPrimaryKey(terminalid);
	}
	/**
	 * 
	 * 查询出终端号是否绑定了商户
	 * @return 
	 */
	public String selectBindtermainal(String terminalid) {
		return b2cTerminalMapper.selectTerminalbind(terminalid);
	}
	
	/** 查询省
	 * @return
	 */
	public List<Area> searchProvince()throws Exception {
		List<Area> list=areaMapper.searchProvince();
		return list;
	}
	public List<Area> searchArea()throws Exception {
		List<Area> list=areaMapper.searchArea();
		return list;
	}
	/** 查询银行
	 * @return
	 */
	public List<B2cDict> searchBank()throws Exception {
		List<B2cDict> list=b2cDictMapper.searchDictBank();
		return list;
	}
	
	/** 查询银行名字
	 * @return
	 */
	public B2cDict findBankName(String b2cDictId)throws Exception {
		B2cDict b2cdict=b2cDictMapper.findDictBankName(b2cDictId);
		return b2cdict;
	}
	/**�̻���Ӧ��ҵ
	 * @param conDictclsCalling
	 * @return
	 */
	public List searchDictCls (String dictclsid)throws BusinessException {
		List<B2cDict> list=b2cDictMapper.searchDictCls(dictclsid);
		return list;
	}

	/**��������
	 * @return
	 */
	public List searchFootFreqList()throws Exception {
		return b2cFootfreqMapper.searchFootFreqList();
	}
	/**
	 * 查询商户信息未审核的个数
	 * @return
	 */
	public String selectCheckCount(){
		String ckCount = b2cShopperbiTempMapper.selectCheckCount();
		return ckCount!=null&&!"".equals(ckCount)?ckCount:"0";
	}
	/**
	 * 查询商户开户银行的信息未审核的个数
	 * @return
	 */
	public String selectCheckBkCount(){
		String bankCount = b2cShopperbiTempMapper.selectCheckBkCount();
		return bankCount!=null&&!"".equals(bankCount)?bankCount:"0";
	}
	
	/**
	 * 查询商户终端未审核的个数
	 * @return
	 */
	public String selectTerminalCount(){
		String TerCount = b2cShopperbiTempMapper.selectTerminalCount();
		return TerCount!=null&&!"".equals(TerCount)?TerCount:"0";
	}
	
	
	
	//根据merchantid 查询单个的username
	public Users selectByUserId(String shopperid) throws Exception {
		Users user = usersMapper.selectByUserId(shopperid);
		return user;
	}
	
	//根据shopperid 查询单个的fomalshopper
	public B2cShopperbi selectFormalShopperId(String shopperid) throws Exception {
		B2cShopperbi forshopperbi = b2cShopperbiMapper.selectFormalshoppId(shopperid);
		return forshopperbi;
	}
	
	//判断是否有重复的userName
	public List selectByUsersName(String userName) throws Exception {
		List<Users>  Users= usersMapper.selectByUsesrName(userName);
		return Users;
	}

	/**查询代理商
	 * @param agentId
	 * @return
	 */
	public Agent searchAgent(Long agentId)throws Exception {
		return agentMapper.searchAgentByShopperid(agentId.toString());
	}
	
	/**查询代理商
	 * @param agentId
	 * @return
	 */
	public Agent selectAgent(Long agentId)throws Exception {
		return agentMapper.searchAgentById(agentId.toString());
	}

	/**省
	 * @param province
	 * @return
	 */
	public List searchProvincial(String province)throws Exception {
		Area area=new Area();
		area.setProvincial(province);
		return areaMapper.searchProvincial(area);
	}
	
	/**城市
	 * @param city
	 * @return
	 */
	public List searchCity(String city)throws Exception {
		Area area=new Area();
		area.setCity(city);
		return areaMapper.searchCity(area);
	}
	/**查询商户信息
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	public List<HashMap> queryShopPerbiManageList(ShopPerbiForm mbForm) throws BusinessException{
		PageContext.initPageSize(20);
		return b2cShopperbiTempMapper.ShopPerbiManageList(mbForm);
	}
	
	
	/**查询出待审核商户的列表信息
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	public List<HashMap> ShopPerbiCheckList(ShopPerbiForm mbForm) throws BusinessException{
		PageContext.initPageSize(20);
		return b2cShopperbiTempMapper.ShopPerbiCheckList(mbForm);
	}
	/**查询出待审核证照信息的列表信息
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	public List<HashMap> ShopPerbiPhotoList(ShopPerbiForm mbForm) throws BusinessException{
		PageContext.initPageSize(20);
		return b2cShopperbiTempMapper.ShopPerbiPhotoList(mbForm);
	}
	
	/**开户信息
	 * @param mbForm
	 * @return
	 */
	public List<HashMap> shopPerbiBankList(ShopPerbiForm mbForm) {
		PageContext.initPageSize(20);
		return b2cShopperbiTempMapper.shopPerbiBankList(mbForm);
	}
	
	public List<HashMap> shopPerbiTerminalList(ShopPerbiForm mbForm) {
		PageContext.initPageSize(20);
		return b2cShopperbiTempMapper.shopPerbiTerminalList(mbForm);
	
	}
	
	/**查询商户信息
	 * @param shopPerbiregId
	 * @return
	 */
	public B2cShopperbiTemp queryShopPerbi(String b2cShopperbiId)throws Exception {
		return b2cShopperbiTempMapper.selectByshopperId(Long.valueOf(b2cShopperbiId));
	}
	/**查询正式商户信息
	 * @param shopPerbiregId
	 * @return
	 */
	public B2cShopperbi queryFormalShopPerbi(String b2cShopperbiId)throws Exception {
		return b2cShopperbiMapper.selectFormalshoppId(b2cShopperbiId);
	}
	/**查询商户合同表信息
	 * @param shopPerbiregId
	 * @return
	 */
	public B2cShopperbargainTemp queryShopPerbargain(String shopperbiId)throws Exception {
		return b2cShopperbargainTempMapper.selectByShopperbiId(Long.valueOf(shopperbiId));
	}
	
	/**判断是否有同样的公司名
	 * @param userName
	 * @return
	 */
	public B2cShopperbiTemp findB2cShopperbiScompany(String scompany) {
		B2cShopperbiTemp b2cShopperbiTemp=null;
		 List list=b2cShopperbiTempMapper.selectByScompany(scompany);
		 if(list!=null&&list.size()>0){
			 b2cShopperbiTemp=(B2cShopperbiTemp)list.get(0);
		 }
		 return b2cShopperbiTemp;
	}
	/**修改小商户的资料
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @throws Exception
	 */
	public void updateByShopperId(B2cShopperbiTemp b2cShopperbi)throws Exception {
		b2cShopperbiTempMapper.updateByShopperId(b2cShopperbi);
		saveOrUpdateProgress(b2cShopperbi,Constants.TYPE_2);
		
	}
	
	
	
	/**修改小商户开户银行的资料
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @throws Exception
	 */
	public void updateBankInfo(B2cShopperbiTemp b2cShopperbi,BackupsShopperInformation bkshopper) throws Exception{
		b2cShopperbiTempMapper.updateBankInfo(b2cShopperbi);
		//申请进度
		saveOrUpdateProgress(b2cShopperbi,Constants.TYPE_3);
		BackupsShopperInformation bk=findbkshopper(new BigDecimal(b2cShopperbi.getShopperid()));
		if(bk==null){
			this.bkshoppermapper.insert(bkshopper);
		}
		
	}
	
	/**审核成功时候，修改正式表中小商户开户银行的资料
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @throws Exception
	 */
	public void b2cShopperbi(B2cShopperbiTemp b2cShopperbi){
		b2cShopperbiMapper.updateFormalBankInfo(b2cShopperbi);
	}
	
	/**
	 * @param b2cShopperbi
	 * @param remark 
	 * @param type22 
	 * @param type2 
	 * @param b2cShopperbargain
	 * @throws Exception
	 */
	public void updateCheckShopper(B2cShopperbiTemp b2cShopperbi, String type,String status, String remark)throws Exception {
		b2cShopperbiTempMapper.updateBankInfo(b2cShopperbi);
			
		updateProgress(b2cShopperbi.getShopperid().toString(),type,status,remark);
	}
	public void updatephotoShopper(B2cShopperbiTemp b2cShopperbi, String type,String status, String remark)throws Exception {
		b2cShopperbiTempMapper.updateByShopperId(b2cShopperbi);
			
		updateProgress(b2cShopperbi.getShopperid().toString(),type,status,remark);
	}
	
	public void updateCheckShopper1(B2cShopperbiTemp b2cShopperbi,B2cShopperbi shopper, String type,String status, String remark)throws Exception {
		b2cShopperbiTempMapper.updateByShopperId(b2cShopperbi);
		shopper.setPhotoid(b2cShopperbi.getPhotoid());
		b2cShopperbiMapper.updateByShopperId(shopper);
		updateProgress(b2cShopperbi.getShopperid().toString(),type,status,remark);
	}
	
	/**审核绑定终端
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @throws Exception
	 */
	public void updateTermianl(B2cShopperbiTemp b2cShopperbi,String Shopperid,String status)throws Exception {
		B2cTermBinder Termbinder=new B2cTermBinder();
		b2cShopperbiTempMapper.updateByShopperId(b2cShopperbi);
		if(status.equals("1")){
			//先删除原来取消绑定的的终端
			b2cTermBinderMapper.deleteBinderId(Shopperid);
			//获取商户原绑定终端
			List<HashMap> oldTerminl=b2cTempTermBinderMapper.selectNewBinder(Shopperid);
			if(oldTerminl!=null){
				for (int i = 0; i < oldTerminl.size(); i++) {
					Termbinder.setStatus("1");
					Termbinder.setCreateDate(new Date());
					Termbinder.setMerchantNo(Shopperid);
					Termbinder.setMerchantNo(Shopperid);
					Termbinder.setTermNo(oldTerminl.get(i).get("TERMINALID").toString());
					b2cTermBinderMapper.insert(Termbinder);
				}
			}
			b2cTempTermBinderMapper.deleteByMerchantNo(Shopperid);
			B2cShopperbiTemp shopper2=new B2cShopperbiTemp();
			shopper2.setShopperid(Long.valueOf(Shopperid));
			shopper2.setTermianlstatus("1");
			b2cShopperbiTempMapper.updateByShopperId(shopper2);
			String remark="审核通过";
			updateProgress(Shopperid,Constants.TYPE_4,Constants.TYPE_2,remark);

		}else{
			B2cTermBinder b2c=new B2cTermBinder();
			b2c.setMerchantNo(Shopperid);
			b2c.setStatus("0");
			b2cTermBinderMapper.updateBackBinder(b2c);
			B2cShopperbiTemp shopper=new B2cShopperbiTemp();
			shopper.setShopperid(Long.valueOf(Shopperid));
			shopper.setTermianlstatus("2");
			b2cShopperbiTempMapper.updateByShopperId(shopper);
			String remark="审核不通过";
			updateProgress(Shopperid,Constants.TYPE_4,Constants.TYPE_3,remark);
		}
		
	}
	

	/**变更商户信息
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param shopperpriIds
	 */
	public void updateByB2cShopperId(B2cShopperbiTemp b2cShopperbi,B2cShopperbargainTemp b2cShopperbargain, String shopperId)throws Exception {
		b2cShopperbiTempMapper.updateByShopperId(b2cShopperbi);
		//B2cShopperbargainTemp b2cShopperbargains=b2cShopperbargainTempMapper.selectByShopperbiId(Long.valueOf(b2cShopperbargain.getShopperid()));
	/*	if(b2cShopperbargains!=null){
			b2cShopperbargainTempMapper.updateByShopperId(b2cShopperbargain);
		}else{
			insertB2cShopperbargain(b2cShopperbargain);
		}*/
		saveOrUpdateProgress(b2cShopperbi,Constants.TYPE_2);
	}
	/**
	 * @param shopperId
	 * @param agentId
	 * @return
	 */
	public List<B2cTermBinder> selectByB2cTermBinder(String shopperId,String agentId) {
		Map map=new HashMap();
		map.put("shopperId", shopperId);
		map.put("agentId", agentId);
		return b2cTerminalMapper.selectB2cb2cTerminal(map);
	}
	/**查询商户绑定好的终端
	 * @param shopperId
	 * @param agentId
	 * @return
	 */
	public List<HashMap> shopperB2cTermBinder(String shopperId) {
		return b2cTerminalMapper.selectExistTerminal(shopperId);
	}
	
	/**查询商户绑定好的终端
	 * @param shopperId
	 * @param agentId
	 * @return
	 */
	public List<HashMap> selectBinderNum(String shopperId) {
		return b2cTerminalMapper.selectBinderNum(shopperId);
	}
	
	/**查询即将商户绑定好的终端
	 * @param shopperId
	 * @param agentId
	 * @return
	 */
	public List<HashMap> shopperAjaxBinder(String shopperId) {
		return b2cTerminalMapper.selectAjaxTerminal(shopperId);
	}
	
	/**查询商户绑定的终端数量
	 * @param shopperId
	 * @param agentId
	 * @return
	 */
	public String selectTerminalCount(String shopperId) {
		String tercount=b2cTerminalMapper.selectTerminalCount(shopperId);
		return  tercount!=null&&!"".equals(tercount)?tercount:"0";
	}
	
	/**查询中间表的终端信息
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @throws Exception
	 */
	public  B2cTempTermBinder selectByTempBinder(String terNo){
		List list=b2cTempTermBinderMapper.selectByTempBinder(terNo);
		B2cTempTermBinder b2cTempTermBinder=null;
		if(list!=null&&list.size()>0){
			b2cTempTermBinder=(B2cTempTermBinder)list.get(0);
		}
		return b2cTempTermBinder;
	}
	
	/**
	 * 将A集合与B集合进行比较，返回A集合中不包含B集合的元素集合
	 * @param arg0
	 * @param arg1
	 * @return
	 */
	public List<String> compareList(String[] arg0, String[] arg1) {
		List<String> startList = transformList(arg0);
		List<String> endList = transformList(arg1);
		for (int i = 0; i < startList.size(); i++) {
			String start = (String) startList.get(i);
			for (int k = 0; k < endList.size(); k++) {
				String end = (String) endList.get(k);
				if ((start).equals(end)) {
					startList.remove(i);
					i = i - 1;
				}
			}
		}
		return startList;
	}
	
	/**
	 * 将数组转换成集合
	 * @param arg0 
	 * @return
	 */
	public List<String> transformList(String[] arg0){
		List<String> transList = new ArrayList<String>();
		for (int i = 0; i < arg0.length; i++) {
			transList.add(i, arg0[i]);
		}
		return transList;
	}
	public void updateBindTerminal( String bindTerminal,String hiddNum)throws Exception {
		 String[] hiddenNum=hiddNum.split(",");
		if(bindTerminal==null || StringUtils.isEmpty(bindTerminal)){
		    for (int i = 0; i < hiddenNum.length; i++) {
			    B2cTempTermBinder termBinder=selectByTempBinder(hiddenNum[i]);
				if(termBinder!=null){
					b2cTempTermBinderMapper.deleteByTermno(termBinder.getTermNo());
				}else{
				    B2cTermBinder  b2cTermBinder=b2cTermBinderMapper.selectOneBinder(hiddenNum[i]);
				    if(b2cTermBinder!=null && b2cTermBinder.getStatus().equals("0")){
					    b2cTermBinder.setStatus("1");
					    b2cTermBinderMapper.updateIsBinder(b2cTermBinder);
				    }else{
				    	System.out.println("dd");
				    }
				}
		    }
			}else{
		    String[] bindTerminals=bindTerminal.split(",");
			List<String> bindter=compareList(hiddenNum,bindTerminals);
			if(bindter.size()>0){
				for(int j=0;j<bindter.size();j++){
				    B2cTermBinder  b2cTermBinder=b2cTermBinderMapper.selectOneBinder(bindter.get(j));
				    if(b2cTermBinder!=null && b2cTermBinder.getStatus().equals("0")){
					    b2cTermBinder.setStatus("1");
					    b2cTermBinderMapper.updateIsBinder(b2cTermBinder);
				    }
				    else{
				        B2cTempTermBinder termBinder=selectByTempBinder(bindter.get(j));
				        if(termBinder!=null){
				            b2cTempTermBinderMapper.deleteByTermno(termBinder.getTermNo());
				        }
				    }
				}
			}
			if(bindTerminals.length>0){
				for(int i=0;i<bindTerminals.length;i++){
					B2cTempTermBinder termBinder=selectByTempBinder(bindTerminals[i]);
					if(termBinder!=null){
						termBinder.setStatus("1");
						b2cTempTermBinderMapper.updateTermBinder(termBinder);
					}else{
					    B2cTermBinder  b2cTermBinder=b2cTermBinderMapper.selectOneBinder(bindTerminals[i]);
					    if(b2cTermBinder!=null && b2cTermBinder.getStatus().equals("1")){
						    b2cTermBinder.setStatus("0");
						    b2cTermBinderMapper.updateIsBinder(b2cTermBinder);
					    }else{
					    	System.out.println("dd");
					    }
					}
				}
			}
	    }
	  
	}
	/**添加终端
	 * @param shopperid
	 * @param bindTerminal
	 * @throws Exception
	 */
	public void insertBindTerminal(String shopperId, String bindTerminal)throws Exception {
		b2cTermBinderMapper.deleteByShopperId(shopperId);
		String[] bindTerminals=bindTerminal.split(",");
		if(bindTerminals.length>0){
			for(int i=0;i<bindTerminals.length;i++){
				B2cTermBinder b2cTermBinder=new B2cTermBinder();
				b2cTermBinder.setMerchantNo(shopperId);
				b2cTermBinder.setTermNo(bindTerminals[i]);
				b2cTermBinder.setCreateDate(new Date());
				b2cTermBinderMapper.insert(b2cTermBinder);
			}
		}
	}
	/**跟胡商户号查询终端
	 * @param shopperId
	 * @return
	 */
	public List<B2cTermBinder> selectByB2cTermBinderList(String shopperId) {
		return b2cTermBinderMapper.selectByB2cTermBinderList(shopperId);
	}
	/**注册
	 * @param map
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @throws Exception 
	 */
	public void saveReg( B2cShopperbiTemp b2cShopperbi,MposApplicationProgress pro,ShopPerbiForm mbForm) throws Exception {
		insertMerchantFeeList(b2cShopperbi,mbForm);
		b2cShopperbiTempMapper.insert(b2cShopperbi);
		progressmapper.insertSelective(pro);
	}
	
	public void insertMerchantFeeList(B2cShopperbiTemp b2cShopperbi,ShopPerbiForm mbForm) {
		String shopperid=b2cShopperbi.getShopperid().toString();
		List<MposMerchantFee> moFees = mposMerchantFeeMapper.findbyshopperid(shopperid);
		if(moFees != null && moFees.size() > 0){
			mposMerchantFeeMapper.deleteByshopperid(Long.valueOf(shopperid));
		}
		//秒到
		MposMerchantFee S0mposDebitfee=new MposMerchantFee();
		S0mposDebitfee.setShopperid(Long.valueOf(shopperid));
		S0mposDebitfee.setFeeType(Constants.CON_NO);//借记卡
		S0mposDebitfee.setFee(ToolsUtils.div(Double.parseDouble(mbForm.getS0debitFee()), 1, 4)+"");
		S0mposDebitfee.setCreateDate(new Date());
		S0mposDebitfee.setStatus(Constants.CON_YES);
		S0mposDebitfee.setEachamount(new BigDecimal(mbForm.getS0fixAmount()));
		S0mposDebitfee.setProType(Constants.CON_YES);
		S0mposDebitfee.setChannelType(Constants.S0_CHANNEL_TYPE);

		MposMerchantFee S0mposCreditFee=new MposMerchantFee();
		S0mposCreditFee.setShopperid(Long.valueOf(shopperid));
		S0mposCreditFee.setFeeType(Constants.CON_YES);//贷记卡
		S0mposCreditFee.setFee(ToolsUtils.div(Double.parseDouble(mbForm.getS0creditFee()), 1, 4)+"");
		S0mposCreditFee.setCreateDate(new Date());
		S0mposCreditFee.setStatus(Constants.CON_YES);
		S0mposCreditFee.setEachamount(new BigDecimal(mbForm.getS0fixAmount()));
		S0mposCreditFee.setProType(Constants.CON_YES);
		S0mposCreditFee.setChannelType(Constants.S0_CHANNEL_TYPE);
		

		//即时
		MposMerchantFee d0mposDebitfee=new MposMerchantFee();
		d0mposDebitfee.setShopperid(Long.valueOf(shopperid));
		d0mposDebitfee.setFeeType(Constants.CON_NO);//借记卡
		d0mposDebitfee.setFee(ToolsUtils.div(Double.parseDouble(mbForm.getD0debitFee()), 1, 4)+"");
		d0mposDebitfee.setCreateDate(new Date());
		d0mposDebitfee.setStatus(Constants.CON_YES);
		d0mposDebitfee.setEachamount(new BigDecimal(mbForm.getT0fixAmount()));
		d0mposDebitfee.setProType(Constants.CON_YES);
		d0mposDebitfee.setChannelType(Constants.D0_CHANNEL_TYPE);

		MposMerchantFee d0mposCreditFee=new MposMerchantFee();
		d0mposCreditFee.setShopperid(Long.valueOf(shopperid));
		d0mposCreditFee.setFeeType(Constants.CON_YES);//贷记卡
		d0mposCreditFee.setFee(ToolsUtils.div(Double.parseDouble(mbForm.getD0creditFee()), 1, 4)+"");
		d0mposCreditFee.setCreateDate(new Date());
		d0mposCreditFee.setStatus(Constants.CON_YES);
		d0mposCreditFee.setEachamount(new BigDecimal(mbForm.getT0fixAmount()));
		d0mposCreditFee.setProType(Constants.CON_YES);
		d0mposCreditFee.setChannelType(Constants.D0_CHANNEL_TYPE);
		

		//T1
		MposMerchantFee T1mposDebitfee=new MposMerchantFee();
		T1mposDebitfee.setShopperid(Long.valueOf(shopperid));
		T1mposDebitfee.setFeeType(Constants.CON_NO);//借记卡
		T1mposDebitfee.setFee(ToolsUtils.div(Double.parseDouble(mbForm.getT1debitFee()), 1, 4)+"");
		T1mposDebitfee.setCreateDate(new Date());
		T1mposDebitfee.setStatus(Constants.CON_YES);
		T1mposDebitfee.setProType(Constants.CON_YES);
		T1mposDebitfee.setChannelType(Constants.T1_CHANNEL_TYPE);
		T1mposDebitfee.setEachamount(new BigDecimal(Constants.TYPE_0));

		MposMerchantFee T1mposCreditFee=new MposMerchantFee();
		T1mposCreditFee.setShopperid(Long.valueOf(shopperid));
		T1mposCreditFee.setFeeType(Constants.CON_YES);//贷记卡
		T1mposCreditFee.setFee(ToolsUtils.div(Double.parseDouble(mbForm.getT1creditFee()), 1, 4)+"");
		T1mposCreditFee.setCreateDate(new Date());
		T1mposCreditFee.setStatus(Constants.CON_YES);
		T1mposCreditFee.setProType(Constants.CON_YES);
		T1mposCreditFee.setChannelType(Constants.T1_CHANNEL_TYPE);
		T1mposCreditFee.setEachamount(new BigDecimal(Constants.TYPE_0));
		

		//微信
		MposMerchantFee mweChatfee=new MposMerchantFee();
		mweChatfee.setShopperid(Long.valueOf(shopperid));
		mweChatfee.setFeeType(Constants.STATUS2);//微信
		mweChatfee.setFee(ToolsUtils.div(Double.parseDouble(mbForm.getWeChatFee()), 1, 4)+"");
		mweChatfee.setCreateDate(new Date());
		mweChatfee.setStatus(Constants.CON_YES);
		mweChatfee.setD0Fee(ToolsUtils.div(Double.parseDouble(mbForm.getWeChatD0Fee()), 1, 4)+"");
		mweChatfee.setProType(Constants.CON_OUT);
		//支付宝
		MposMerchantFee mposAliPayFee=new MposMerchantFee();
		mposAliPayFee.setShopperid(Long.valueOf(shopperid));
		mposAliPayFee.setFeeType(Constants.STATUS3);//支付宝
		mposAliPayFee.setFee(ToolsUtils.div(Double.parseDouble(mbForm.getAlipayFee()), 1, 4)+"");
		mposAliPayFee.setCreateDate(new Date());
		mposAliPayFee.setStatus(Constants.CON_YES);
		mposAliPayFee.setD0Fee(ToolsUtils.div(Double.parseDouble(mbForm.getAlipayD0Fee()), 1, 4)+"");
		mposAliPayFee.setProType(Constants.CON_OUT);
		//添加银联二维码费率
		MposMerchantFee mposYlsmFee = new MposMerchantFee(); //银联二维码费率
		mposYlsmFee.setShopperid(Long.valueOf(shopperid));
		mposYlsmFee.setFeeType(Constants.STATUS4); //银联二维码
		mposYlsmFee.setFee(ToolsUtils.div(Double.parseDouble(mbForm.getYlpayFee()), 1, 4)+"");
		mposYlsmFee.setCreateDate(new Date());
		mposYlsmFee.setStatus(Constants.CON_YES);
		mposYlsmFee.setD0Fee(ToolsUtils.div(Double.parseDouble(mbForm.getYlpayD0Fee()), 1, 4)+"");
		mposYlsmFee.setProType(Constants.CON_OUT);
		//快捷支付
		MposMerchantFee shortCut=new MposMerchantFee();
		shortCut.setShopperid(Long.valueOf(shopperid));//商户编码id
		shortCut.setFeeType(Constants.FEE_TYPE_SHORTCUT);//汇率类型
		shortCut.setFee(ToolsUtils.div(Double.parseDouble(mbForm.getShortCut()), 1, 4)+"");//商户手续费汇率
		shortCut.setCreateDate(new Date());//创建时间
		shortCut.setStatus(Constants.CON_YES);//状态
		shortCut.setD0Fee(ToolsUtils.div(Double.parseDouble(mbForm.getShortCutDo()), 1, 4)+"");//商户DO提现汇率
		shortCut.setProType(Constants.CON_OUT);

		//B2C支付
		MposMerchantFee b2c=new MposMerchantFee();
		b2c.setShopperid(Long.valueOf(shopperid));
		b2c.setFeeType(Constants.FEE_TYPE_B2C);
		b2c.setFee(ToolsUtils.div(Double.parseDouble(mbForm.getB2c()), 1, 4)+"");
		b2c.setCreateDate(new Date());
		b2c.setStatus(Constants.CON_YES);
		b2c.setD0Fee(ToolsUtils.div(Double.parseDouble(mbForm.getB2cDo()), 1, 4)+"");
		b2c.setProType(Constants.CON_OUT);
		
		/**
		 * 10月20号
		 */
		//速惠快捷费率
		MposMerchantFee shortCutSH=new MposMerchantFee();
		shortCutSH.setShopperid(Long.valueOf(shopperid));//商户编码id
		shortCutSH.setFeeType(Constants.FEE_TYPE_SHD0);//汇率类型
		shortCutSH.setFee(Constants.STATUS0);//商户手续费汇率
		shortCutSH.setCreateDate(new Date());//创建时间
		shortCutSH.setStatus(Constants.CON_YES);//状态
		shortCutSH.setD0Fee(ToolsUtils.div(Double.parseDouble(mbForm.getShortCutSHDo()), 1, 4)+"");//商户DO提现汇率
		shortCutSH.setProType(Constants.CON_OUT);
		
		
		//微信
		mposMerchantFeeMapper.insertSelective(mweChatfee);
		//快捷支付
		shortCut.setId(mweChatfee.getId());
		mposMerchantFeeMapper.insert(shortCut);
		
		//速惠快捷支付
		shortCutSH.setId(mweChatfee.getId());
		mposMerchantFeeMapper.insert(shortCutSH);
		
		//B2C支付
		b2c.setId(mweChatfee.getId());
		mposMerchantFeeMapper.insert(b2c);
		//支付宝
		mposAliPayFee.setId(mweChatfee.getId());
		mposMerchantFeeMapper.insert(mposAliPayFee);
		//银联
		mposYlsmFee.setId(mweChatfee.getId());
		mposMerchantFeeMapper.insert(mposYlsmFee);
		
		S0mposDebitfee.setId(mweChatfee.getId());
		mposMerchantFeeMapper.insert(S0mposDebitfee);
		
		S0mposCreditFee.setId(mweChatfee.getId());
		mposMerchantFeeMapper.insert(S0mposCreditFee);
		
		d0mposDebitfee.setId(mweChatfee.getId());
		mposMerchantFeeMapper.insert(d0mposDebitfee);
		
		d0mposCreditFee.setId(mweChatfee.getId());
		mposMerchantFeeMapper.insert(d0mposCreditFee);
		
		T1mposDebitfee.setId(mweChatfee.getId());
		mposMerchantFeeMapper.insert(T1mposDebitfee);
		
		T1mposCreditFee.setId(mweChatfee.getId());
		mposMerchantFeeMapper.insert(T1mposCreditFee);
		
	}
	
	
	
	/**变更证照信息
	 * @param map
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @throws Exception 
	 */
	public void updatePhoto(MposPhotoTmp photo1,MposApplicationProgress  pro) throws Exception {
		
		
		mposphototmpmapper.updatePhotoTmpById(photo1);
		progressmapper.insertSelective(pro);
	}
	
	
	
	
	public void updatePhoto1(Map maphoto, MposApplicationProgress pro,B2cShopperbiTemp b2cShopperbi,String photoid)
			throws Exception {
		MposPhotoTmp photo = this.mposphototmpmapper.findbyphotoid(photoid);
		String s1 = (String) maphoto.get("signaturePhoto");
		String s2 = (String) maphoto.get("handIdentityCardPhoto");
		String s3 = (String) maphoto.get("frontIdentityCardPhoto");
		String s4 = (String) maphoto.get("reverseIdentityCardPhoto");
		String s5 = (String) maphoto.get("storePhoto");
		/*String s7 = (String) maphoto.get("licensePhotoph");
		String s8 = (String) maphoto.get("instorePhotoph");*/
		String s9 = (String) maphoto.get("creditCardPhoto");
		String s10 = (String) maphoto.get("settlementCardPhoto");
		String s11 = (String) maphoto.get("fixPhoto");
		String s12 = (String) maphoto.get("livingbodyFacePhoto");
		String s13 = (String) maphoto.get("livingbodyLeftPhoto");
		String s14 = (String) maphoto.get("livingbodyRightPhoto");
		String s15 = (String) maphoto.get("livingbodyReturnPhoto");
		String s16 = (String) maphoto.get("idCardHeadPhoto");

		if (!com.uns.util.StringUtils.isEmpty(s1)) {
			photo.setSignaturePhoto(s1);
		}else{
			photo.setSignaturePhoto(null);
		}
		if (!com.uns.util.StringUtils.isEmpty(s2)) {
			photo.setHandIdentityCardPhoto(s2);
		}else{
			photo.setHandIdentityCardPhoto(null);
		}
		if (!com.uns.util.StringUtils.isEmpty(s3)) {
			photo.setFrontIdentityCardPhoto(s3);
		}else{
			photo.setFrontIdentityCardPhoto(null);
		}
		if (!com.uns.util.StringUtils.isEmpty(s4)) {
			photo.setReverseIdentityCardPhoto(s4);
		}else{
			photo.setReverseIdentityCardPhoto(null);
		}
		if (!com.uns.util.StringUtils.isEmpty(s5)) {
			photo.setStorePhoto(s5);
		}else{
			photo.setStorePhoto(null);
		}
		/*if (s7 != null) {
			photo.setLicensePhoto(s7);
		}
		if (s8 != null) {
			photo.setInstorePhoto(s8);
		}*/
		if (!com.uns.util.StringUtils.isEmpty(s9)) {
			photo.setCreditCardPhoto(s9);
		}else{
			photo.setCreditCardPhoto(null);
		}
		if (!com.uns.util.StringUtils.isEmpty(s10)) {
			photo.setSettlementCardPhoto(s10);
		}else{
			photo.setSettlementCardPhoto(null);
		}
		
		if (!com.uns.util.StringUtils.isEmpty(s11)) {
			photo.setFixphoto(s11);
		}else{
			photo.setFixphoto(null);
		}

		if (!com.uns.util.StringUtils.isEmpty(s12)) {
			photo.setLivingbodyFacePhoto(s12);
		}else{
			photo.setLivingbodyFacePhoto(null);
		}
		if (!com.uns.util.StringUtils.isEmpty(s13)) {
			photo.setLivingbodyLeftPhoto(s13);
		}else{
			photo.setLivingbodyLeftPhoto(null);
		}
		if (!com.uns.util.StringUtils.isEmpty(s14)) {
			photo.setLivingbodyRightPhoto(s14);
		}else{
			photo.setLivingbodyRightPhoto(null);
		}
		if (!com.uns.util.StringUtils.isEmpty(s15)) {
			photo.setLivingbodyReturnPhoto(s15);
		}else{
			photo.setLivingbodyReturnPhoto(null);
		}
		if (!com.uns.util.StringUtils.isEmpty(s16)) {
			photo.setIdCardHeadPhoto(s16);
		}else{
			photo.setIdCardHeadPhoto(null);
		}
		b2cShopperbiTempMapper.updateByShopperId(b2cShopperbi);
		mposphototmpmapper.updatePhotoTmpById(photo);
		  MposApplicationProgress ap=this.findMposApplicationProgress(b2cShopperbi.getShopperid().toString(), Constants.TYPE_5);
		  if(null == ap){
			  progressmapper.insertSelective(pro);
		  }
		
	}

	/**
	 * 根据用户名查询
	 * 
	 */
	public List selectByMuserid(String userName) {
		return b2cShopperbiTempMapper.selectByMuserid(userName);
	}
	/**查找进度
	 * @param shopperid
	 * @param type1
	 * @return
	 */
	public MposApplicationProgress findMposApplicationProgress(String shopperid, String type1) {
		Map map=new HashMap();
		map.put("shopperid",shopperid);
		map.put("applicationType", type1);
		return progressmapper.findMposApplicationProgress(map);
	}
	
	
	/**修改进度
	 * @param alp
	 */
	public void updateMposApplicationProgress(MposApplicationProgress alp) {
		progressmapper.updateSelective(alp);
	}
	/**保存或修改进度表
	 * @param b2cShopperbi
	 * @param applicationType
	 */
	public void  saveOrUpdateProgress(B2cShopperbiTemp b2cShopperbi,String applicationType){
		//在进度表中插入数据
		MposApplicationProgress  alp=findMposApplicationProgress(b2cShopperbi.getShopperid().toString(),applicationType);
		if(alp!=null){
			alp.setApplicationStatus(Constants.TYPE_1);
			alp.setApplicationRemark(b2cShopperbi.getRemark());
			alp.setUpdateDate(new Date());
			updateMposApplicationProgress(alp);
		}else{
			alp=new MposApplicationProgress();
			if(b2cShopperbi.getShopperidP()!=null){
				Agent ag=agentMapper.searchAgentByShopperid(b2cShopperbi.getShopperidP().toString());
				alp.setShopperidP(b2cShopperbi.getShopperidP().toString());
				alp.setAgentName(ag.getScompany());
			}
			
			alp.setShopperid(b2cShopperbi.getShopperid().toString());
			alp.setScompany(b2cShopperbi.getScompany());			
			String theme=getThemeByType(applicationType);
			alp.setApplicationTheme(theme);
			alp.setApplicationType(applicationType);
			alp.setApplicationStatus(Constants.TYPE_1);
			alp.setApplicationRemark(b2cShopperbi.getRemark());
			alp.setCreateDate(new Date());
			progressmapper.insertSelective(alp);
		}
		
	}
	
	/**根据状态获取主题
	 * @param applicationType
	 * @return
	 */
	private String getThemeByType(String applicationType) {
		String theme="";
		if(applicationType.equals(Constants.TYPE_1)){
			theme="商户开通";
		}else if(applicationType.equals(Constants.TYPE_2)){
			theme="变更商户信息";
		}else if(applicationType.equals(Constants.TYPE_3)){
			theme="变更开户信息";
		}else if(applicationType.equals(Constants.TYPE_4)){
			theme="变更终端信息";
		}else if(applicationType.equals(Constants.TYPE_5)){
			theme="变更证照";
		}
		return theme;
	}
	/**修改进度状态
	 * @param b2cShopperbi
	 * @param type
	 */
	public void updateProgress(String shopperid, String type,String status,String remark) {
		MposApplicationProgress  alp=findMposApplicationProgress(shopperid,type);
		if(alp!=null){
			alp.setApplicationStatus(status);
			alp.setApplicationRemark(remark);
			updateMposApplicationProgress(alp);
		}
		
	}
	public void updateTerminal(String bindTerminal, String hiddNum,
			B2cShopperbiTemp shopperbi) throws Exception {
		updateBindTerminal(bindTerminal,hiddNum);
		b2cShopperbiTempMapper.updateByShopperId(shopperbi);
		//修改申请进度
		saveOrUpdateProgress(shopperbi,Constants.TYPE_4);
		
	}
	
	
	public MposPhotoTmp selectPhotoTmpById(Long id){
		return mposphototmpmapper.selectByPrimaryKey(new BigDecimal(id));
	}
	
	public Operator selectOperatorById(Long id){
		return operatorMapper.selectByPrimaryKey(new BigDecimal(id));
	}
	/**根据父id查询记录
	 * @param parentid
	 * @return
	 */
	public B2cShopperbi findB2cShopperbiByParenB2cShopperbitId(String parentid) {
		List list=b2cShopperbiMapper.findB2cShopperbiByParenB2cShopperbitId(parentid);
		B2cShopperbi b2cShopperbi=null;
		if(list!=null&&list.size()>0){
			b2cShopperbi=(B2cShopperbi)list.get(0);
		}
				
		 
		return b2cShopperbi;
	}
	
	public List<HashMap> selectFeeByShopperid(Long shopperid){
		return mposMerchantFeeMapper.selectByMerchantId(shopperid);
	}
	
	public List<HashMap> selectFeeByShopperid1(Long shopperid){
		return mposMerchantFeeMapper.selectByMerchantId1(shopperid);
	}
	
		
	public String selectmerchantCount(){
		String TerCount = b2cShopperbiTempMapper.selectmerchantCount();
		return TerCount!=null&&!"".equals(TerCount)?TerCount:"0";
	}
	
	
	/**
	 * 根据用户名查询
	 * 
	 */
	public List findbytel(String stel) {
		return b2cShopperbiTempMapper.findbytel(stel);
	}
	public List findMerchantFeeById(Long shopperid) {
		return mposMerchantFeeMapper.findMerchantFeeById(shopperid);
	}
	public List findMerchantFeeByMpos(Long shopperid) {
		return mposMerchantFeeMapper.findMerchantFeeByMpos(shopperid);
	}
	public B2cDict findbyhCname(String industryType) {
		List list=b2cdictmapper.findbyhCname(industryType);
		B2cDict industry=null;
		if(list!=null&&list.size()>0){
			industry=(B2cDict)list.get(0);
		}
		return industry; 
	}
	
	public B2cDict findbankName(String dict) {
		List list=b2cdictmapper.findBankName(dict);
		B2cDict industry=null;
		if(list!=null&&list.size()>0){
			industry=(B2cDict)list.get(0);
		}
		return industry; 
	}
	
	
	public Area findbyareaname(String provincialname,String cityname){
  		Map map=new HashMap();       
        map.put("provincialname", provincialname);
        map.put("cityname", cityname);
        List list=(List) areaMapper.findbyareaname(map);
        Area are=null;
        if(list!=null&&list.size()>0){
			are=(Area)list.get(0);
		}
		return are;
       	      
  	}
	
	public void insertsbarb(B2cShopperbiTemp shopper,B2cShopperbargainTemp bar,MposApplicationProgress progress){
  		b2cShopperbiTempMapper.insert(shopper);
		progressmapper.insertSelective(progress);
		//bartemp.insert(bar);
  	}
	
	public void insertsbar(B2cShopperbiTemp shopper,B2cShopperbargainTemp bar,MposApplicationProgress progress,String fee,String top){
		b2cShopperbiTempMapper.insert(shopper);
		progressmapper.insertSelective(progress);
		//bartemp.insert(bar);
  
		MposMerchantFee merchantfee = new MposMerchantFee();
		String[] str1 = fee.split("\\|");
		String[] str2 = top.split("\\|");
		for (int i1 = 0; i1 < str1.length; i1++) {
			String a = str1[i1];
			String b=str2[i1];
			if(b.equals("#")){
				merchantfee.setTopAmount("");
			}else{
				merchantfee.setTopAmount(b);
			}
			merchantfee.setFee(a);
			
			merchantfee.setStatus(Constants.TYPE_1);
			merchantfee.setCreateDate(new Date());
			merchantfee.setShopperid(shopper.getShopperid());
			mposMerchantFeeMapper.insertSelective(merchantfee);
		}
		
	}
	public List findMposMerchantFee(String merchantNo) {
		return mposMerchantFeeMapper.findMposMerchantFee(merchantNo);
	}
	
	public List findbysid(String id){
		return b2cShopperbiTempMapper.findbysid(id);
	}
	public List findMerchantT1FeeById(Long shopperid) {
		return mposMerchantFeeMapper.findMerchantT1FeeById(shopperid);
	}
	
	public MposPhotoTmp findbsid(String sid){
		return mposphototmpmapper.findbysid(sid);
	}
	  public void delphoto(String sid){
		  mposphototmpmapper.delphoto(sid);
	  }
	  public MposPhotoTmp findbyphotoid(String photoid){
			return mposphototmpmapper.findbyphotoid(photoid);
		}
	/**
	 * 1.现在历史表中插入删除记录
	 * 2.修改远程邀请表(已提交的改为已撤回)
	 * 3.删除记录
	 */
	public void deleteShopperbi(B2cShopperbiTemp b2cShopperbiTemp) {
		b2cShopperbiTempMapper.updateByShopperId(b2cShopperbiTemp);
		b2cShopperbiTempHistoryMapper.insert(b2cShopperbiTemp);
		Map map=new HashMap();
		map.put("status", Constants.STATUS3);
		map.put("tel", b2cShopperbiTemp.getStel());
		map.put("statusq", Constants.STATUS2);
		mposRemoteInvitationMapper.updateByTel(map);
		
		mposMerchantFeeMapper.deleteByPrimaryKey(b2cShopperbiTemp.getShopperid());
		b2cShopperbiTempMapper.deleteByShopperbiId(b2cShopperbiTemp);
		mposapplicationprogressmapper.deleteByPrimaryKey(b2cShopperbiTemp.getShopperid().toString());
	}
	
	
	/**查询删除商户信息
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	public List<HashMap> querydelshopperList(ShopPerbiForm mbForm) throws BusinessException{
		PageContext.initPageSize(20);
		return b2cShopperbiTempHistoryMapper.querydelshopperList(mbForm);
	}
	
	/**查询删除商户信息
	 * @param shopPerbiregId
	 * @return
	 */
	public B2cShopperbiTempHistory queryShopPerbi1(String b2cShopperbiId)throws Exception {
		return b2cShopperbiTempHistoryMapper.selectByshopperId(Long.valueOf(b2cShopperbiId));
	}
	
	
	/**查询交易手续费
	 * @return
	 */
	public MposMerchantFee querymerchantfee(String shopperid)throws Exception{
		List list=mposMerchantFeeMapper.findfee(Long.valueOf(shopperid));
		
		MposMerchantFee merchantfee=null;
		if(list!=null&&list.size()>0){
			merchantfee=(MposMerchantFee)list.get(0);
		}
		return merchantfee; 
		
	}
	
	
	
	/** 保存手续费修改后的值
	 * @param merchantfee
	 * @param shopper
	 */
	public void updatefee(B2cShopperbiTemp shopper,MposMerchantFee merchantfee,BackupsShopperInformation bkshopper,UpdateFeeHistory feehis,UpdateFeeHistory feehis1){
		b2cShopperbiTempMapper.updateByShopperId(shopper);
		mposMerchantFeeMapper.updateByShopperId(merchantfee);
		BackupsShopperInformation bk=findbkshopper(new BigDecimal(shopper.getShopperid()));
		if(bk==null){
			this.bkshoppermapper.insert(bkshopper);
		}
		this.feehismapper.insertSelective(feehis1);
		this.feehismapper.insertSelective(feehis);
		
		
	}
	
	
	/**手续费审核信息
	 * @param mbForm
	 * @return
	 */
	public List<HashMap> shopPerbiFeeList(ShopPerbiForm mbForm) {
		PageContext.initPageSize(20);
		return b2cShopperbiTempMapper.shopPerbiFeeList(mbForm);
	}
	
	
	/**
	 * 查询商户手续费信息未审核的个数
	 * @return
	 */
	public String selectCheckFeeCount(){
		String feeCount = b2cShopperbiTempMapper.selectCheckFeeCount();
		return feeCount!=null&&!"".equals(feeCount)?feeCount:"0";
	}
	
	public void updatecheckfeeY(B2cShopperbiTemp shopper){
		b2cShopperbiTempMapper.updateByShopperId(shopper);
	}
	public void updatecheckfeeN(B2cShopperbiTemp shopper,MposMerchantFee mfee){
		b2cShopperbiTempMapper.updateByShopperId(shopper);
		mposMerchantFeeMapper.updateByShopperId(mfee);
	}
	
	
	public BackupsShopperInformation  findbkshopper(BigDecimal shopperid){
		return this.bkshoppermapper.findByshopperid(shopperid);
	}
	
	public List finagentfeeList(){
		PageContext.initPageSize(Constants.page_size);
		return this.agenttopfeeMapper.findbyidList();
	}
	
	public AgentTopFee selectById(Long id){
		return this.agenttopfeeMapper.selectById(id);
	}
	
	public void updateagentfee(AgentTopFee agenttopfee) throws Exception {
		this.agenttopfeeMapper.updateById(agenttopfee);
	}
	
	
	public Users selectByUsersmerchantid(String shopperid) throws Exception {
		Users user = usersMapper.selectByUsersmerchantid(shopperid);
		return user;
	}
	
	
	/**
	 * @param mbForm
	 * @return
	 * @throws BusinessException 正式信息导出
	 */
	public List<HashMap> queryFormalList(ShopPerbiForm mbForm) throws BusinessException{
		PageContext.initPageSize(20);
		return b2cShopperbiMapper.ShopFormalList(mbForm);
		
	}
	public void queryFormalListexportPage(ShopPerbiForm mbForm) {
		PageContext.initPageSize(Constants.EXCEL_PAGE_SIZE);
		
	}
	
	public List<HashMap> queryFormalListexport(ShopPerbiForm mbForm) throws BusinessException{
		PageContext.initPageSize(Constants.EXCEL_SIZE);
		return b2cShopperbiMapper.ShopFormaExcelList(mbForm);
		
	}
	
	public List findReChargePageList(ShopPerbiForm mbForm) {
		PageContext.initPageSize(Constants.EXCEL_SIZE);
		List list = b2cShopperbiMapper.ShopFormalList(mbForm);
		if(list!=null && list.size()!=0)
		{
			return list;
		}
		return new ArrayList();
		
	}
	
	
	public List findfixamountList(){
		return this.fixamountmapper.findbyidList();
	}
	
	
	public FixAmaount selectByfixamount(Long id){
		return this.fixamountmapper.selectById(id);
	}
	
	
	public void updatefixamount(FixAmaount amount){
		this.fixamountmapper.updateById(amount);
	}
	
	
	
	/**
	 * @return /商户修改手续费历史表
	 */
	public List showfeeList(String shopperid){
		PageContext.initPageSize(Constants.page_size);
		return this.feehismapper.findbyidList(shopperid);
	}
	
	public UpdateFeeHistory selectByfeehis(Long id){
		return this.feehismapper.selectById(id);
	}
	
	public UpdateFeeHistory selectByfeeshopperid(Long shopperid){
		UpdateFeeHistory feehis=null;
		List list=this.feehismapper.selectByshopperid(shopperid);
		if(list!=null&&list.size()>0){
			feehis=(UpdateFeeHistory)list.get(0);
		}
		return feehis; 
	}
	
	/**
	 * 可以批量上传的文件
	 */
	public Integer findUploadHkCount() {
		return b2cShopperbiMapper.findUploadHkCount();
	}
	public List findhkList() {
		PageContext.initPageSize(Constants.UPLOAD_HK_SIZE);
		return b2cShopperbiMapper.findhkList();
	}
	
	/** 保存手续费修改后的值,修改
	 * @param merchantfee
	 * @param shopper
	 */
	public void updatefeeTemp(B2cShopperbiTemp shopper,BackupsShopperInformation bkshopper,Map<String, Object> feeMap)throws Exception{
		
		MposMerchantFee s0creditMerchantFee = (MposMerchantFee) feeMap.get("s0creditMerchantFee");
		MposMerchantFee s0debitMerchantFee = (MposMerchantFee) feeMap.get("s0debitMerchantFee");
		MposMerchantFee d0creditMerchantFee = (MposMerchantFee) feeMap.get("d0creditMerchantFee");
		MposMerchantFee d0debitMerchantFee = (MposMerchantFee) feeMap.get("d0debitMerchantFee");
		MposMerchantFee t1creditMerchantFee = (MposMerchantFee) feeMap.get("t1creditMerchantFee");
		MposMerchantFee t1debitMerchantFee = (MposMerchantFee) feeMap.get("t1debitMerchantFee");
		
		MposMerchantFee weChatMerchantFee = (MposMerchantFee) feeMap.get("weChatMerchantFee");
		MposMerchantFee alipayMerchantFee = (MposMerchantFee) feeMap.get("alipayMerchantFee");
		MposMerchantFee ylpayMerchantFee = (MposMerchantFee) feeMap.get("ylpayMerchantFee");
		//从Map中获取最新费率
		MposMerchantFee shortCutMerchantFee = (MposMerchantFee) feeMap.get("shortCutMerchantFee");
		MposMerchantFee b2cMerchantFee = (MposMerchantFee) feeMap.get("b2cMerchantFee");
		MposMerchantFee shortCutSHMerchantFee = (MposMerchantFee) feeMap.get("shortCutSHMerchantFee");
		
/*		UpdateFeeHistory debitFeeHis = (UpdateFeeHistory) feeMap.get("debitFeeHis");
		UpdateFeeHistory creditFeeHis = (UpdateFeeHistory) feeMap.get("creditFeeHis");
		UpdateFeeHistory weChatFeeHis = (UpdateFeeHistory) feeMap.get("weChatFeeHis");
		UpdateFeeHistory alipayFeeHis = (UpdateFeeHistory) feeMap.get("alipayFeeHis");
		UpdateFeeHistory ylpayFeeHis = (UpdateFeeHistory) feeMap.get("ylpayFeeHis");*/
		
		
		
		MposMerchantFee s0creditMerchantFeeO = this.findTempFeeTChannelType(shopper.getShopperid().toString(),Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
		MposMerchantFee s0debitMerchantFeeO = this.findTempFeeTChannelType(shopper.getShopperid().toString(),Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
		
		MposMerchantFee d0creditMerchantFeeO = this.findTempFeeTChannelType(shopper.getShopperid().toString(),Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
		MposMerchantFee d0debitMerchantFeeO = this.findTempFeeTChannelType(shopper.getShopperid().toString(),Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
		
		MposMerchantFee t1creditMerchantFeeO = this.findTempFeeTChannelType(shopper.getShopperid().toString(),Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
		MposMerchantFee t1debitMerchantFeeO = this.findTempFeeTChannelType(shopper.getShopperid().toString(),Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
		
		MposMerchantFee weChatMerchantFeeO = this.findMposMerchantFeeTemp(shopper.getShopperid().toString(),Constants.FEE_TYPE_WECHAT);
		MposMerchantFee alipayMerchantFeeO = this.findMposMerchantFeeTemp(shopper.getShopperid().toString(),Constants.FEE_TYPE_ALIPAY);
		MposMerchantFee ylpayMerchantFeeO = this.findMposMerchantFeeTemp(shopper.getShopperid().toString(),Constants.FEE_TYPE_YLPAY);
		//无卡费率临时表
		MposMerchantFee shortCutMerchantFeeO = this.findMposMerchantFeeTemp(shopper.getShopperid().toString(),Constants.FEE_TYPE_SHORTCUT);
		MposMerchantFee b2cMerchantFeeO = this.findMposMerchantFeeTemp(shopper.getShopperid().toString(),Constants.FEE_TYPE_B2C);
		MposMerchantFee shortCutSHMerchantFeeO = this.findMposMerchantFeeTemp(shopper.getShopperid().toString(),Constants.FEE_TYPE_SHD0);
		
		if(s0creditMerchantFeeO!=null){
			mposMerchantFeeMapper.updateByShopperIdTemp(s0creditMerchantFee);
		}else {
			mposMerchantFeeMapper.insertSelectiveTemp(s0creditMerchantFee);
		}
		if(s0debitMerchantFeeO!=null){
			mposMerchantFeeMapper.updateByShopperIdTemp(s0debitMerchantFee);
		}else {
			mposMerchantFeeMapper.insertSelectiveTemp(s0debitMerchantFee);
		}
		
		if(d0creditMerchantFeeO!=null){
			mposMerchantFeeMapper.updateByShopperIdTemp(d0creditMerchantFee);
		}else {
			mposMerchantFeeMapper.insertSelectiveTemp(d0creditMerchantFee);
		}
		if(d0debitMerchantFeeO!=null){
			mposMerchantFeeMapper.updateByShopperIdTemp(d0debitMerchantFee);
		}else {
			mposMerchantFeeMapper.insertSelectiveTemp(d0debitMerchantFee);
		}
		
		if(t1creditMerchantFeeO!=null){
			mposMerchantFeeMapper.updateByShopperIdTemp(t1creditMerchantFee);
		}else {
			mposMerchantFeeMapper.insertSelectiveTemp(t1creditMerchantFee);
		}
		if(t1debitMerchantFeeO!=null){
			mposMerchantFeeMapper.updateByShopperIdTemp(t1debitMerchantFee);
		}else {
			mposMerchantFeeMapper.insertSelectiveTemp(t1debitMerchantFee);
		}
		
		
		if(weChatMerchantFeeO!=null){
			mposMerchantFeeMapper.updateByShopperIdTemp(weChatMerchantFee);
		}else {
			mposMerchantFeeMapper.insertSelectiveTemp(weChatMerchantFee);
		}
		if(alipayMerchantFeeO!=null){
			mposMerchantFeeMapper.updateByShopperIdTemp(alipayMerchantFee);
		}else {
			mposMerchantFeeMapper.insertSelectiveTemp(alipayMerchantFee);
		}
		if(ylpayMerchantFeeO!= null){
			mposMerchantFeeMapper.updateByShopperIdTemp(ylpayMerchantFee);
		}else{
			mposMerchantFeeMapper.insertSelectiveTemp(ylpayMerchantFee);
		}
		//无卡费率如果有值就是更新如果没有值就是插入(临时表)
		if(shortCutMerchantFeeO!= null){
			mposMerchantFeeMapper.updateByShopperIdTemp(shortCutMerchantFee);
		}else{
			mposMerchantFeeMapper.insertSelectiveTemp(shortCutMerchantFee);
		}
		if(b2cMerchantFeeO!= null){
			mposMerchantFeeMapper.updateByShopperIdTemp(b2cMerchantFee);
		}else{
			mposMerchantFeeMapper.insertSelectiveTemp(b2cMerchantFee);
		}
		
		/**
		 * 10月19日添加
		 */
		if(shortCutSHMerchantFeeO!= null){
			mposMerchantFeeMapper.updateByShopperIdTemp(shortCutSHMerchantFee);
		}else{
			mposMerchantFeeMapper.insertSelectiveTemp(shortCutSHMerchantFee);
		}
		
		BackupsShopperInformation bk=findbkshopper(new BigDecimal(shopper.getShopperid()));
		if(bkshopper!=null){
		if(bk==null){
			this.bkshoppermapper.insert(bkshopper);
		}else{
			bkshoppermapper.updateByShopperId(bkshopper);
		}
		}
		/*this.feehismapper.insertSelective(debitFeeHis);
		this.feehismapper.insertSelective(creditFeeHis);
		this.feehismapper.insertSelective(weChatFeeHis);
		this.feehismapper.insertSelective(alipayFeeHis);
		this.feehismapper.insertSelective(ylpayFeeHis);*/
	}
	/**查询商户修改历史
	 */
	public List<B2cShopperbiTempModify> findModifyByShopperbiIdList(Map<String, String> param){
		PageContext.initPageSize(Constants.PAGE_SIZE);
		return modifyMapper.selectByShopperbiIdList(param);
	}
	
	
	/**
	 * 商户信息修改明细保存
	 */
	public void insertB2cShopperbiTempModify(B2cShopperbiTempModify shopperbiTempModify) throws Exception{
		modifyMapper.insert(shopperbiTempModify);
	}
	
	/**查询交易手续费,temp表
	 */
	public MposMerchantFee querymerchantfeeTemp(String shopperid){
		List list=mposMerchantFeeMapper.findfeeTemp(Long.valueOf(shopperid));
		MposMerchantFee merchantfee=null;
		if(list!=null&&list.size()>0){
			merchantfee=(MposMerchantFee)list.get(0);
		}
		return merchantfee; 
		
	}
	/**查询修改明细
	 */
	public B2cShopperbiTempModify findModifyById(String modefyDetailId) {
		return modifyMapper.selectById(Long.parseLong(modefyDetailId));
	}
	
	/**商户信息修改保存方法
	 */
	public void saveShopPerbiUpdate(B2cShopperbiTempModify shopperbiTempModify,
			B2cShopperbiTemp b2cShopperbiTemp, BackupsShopperInformation bkshopper,  Map maphoto, MposApplicationProgress pro,
			Map<String, Object> feeMap) throws Exception{
		
		updatefeeTemp(b2cShopperbiTemp,bkshopper,feeMap);
		log.info("商户图片信息修改，修改的图片内容：" + maphoto);
		//如果图片存在
		if (null != maphoto){
			updatePhoto1(maphoto, pro, b2cShopperbiTemp, b2cShopperbiTemp.getPhotoid().toString());
		}else{
			b2cShopperbiTempMapper.updateByShopperId(b2cShopperbiTemp);
		}
		b2cShopperbiTempMapper.updateBankInfo(b2cShopperbiTemp);
		this.insertB2cShopperbiTempModify(shopperbiTempModify);
	}
	/**证照查找正式表
	 */
	public MposPhoto selectPhotoById(Long fphotoid) {
		return mposPhotoMapper.selectByPrimaryKey(fphotoid);
	}
	
	/**证照修改正式表
	 */
	public void PhotoById(Long fphotoid,MposPhoto mposPhoto) throws Exception{
		MposPhoto photo = mposPhotoMapper.selectByPrimaryKey(fphotoid);
		if (photo!=null) {
			mposPhotoMapper.updateByPrimaryKeySelective(mposPhoto);
		}else{
			mposPhotoMapper.insertSelective(mposPhoto);
		}
	}
	
	/**获取费率from AGENT_TOP_FEE
	 * @param feeType 费率类型
	 */
	public List<AgentTopFee> findAgentFeeByType(String feeType) {
			return agenttopfeeMapper.findAgentFeeByType(feeType);
	}
	/**按类型获取费率from MPOS_MERCHANT_TEMP
	 * @param feeType 费率类型
	 * @param shopperId 商户编号
	 */
	public MposMerchantFee findMposMerchantFeeTemp(String shopperId,String feeType) {
		Map<String, Object> paramsMap = new HashMap<String, Object>();
		paramsMap.put("shopperId", shopperId);
		paramsMap.put("feeType", feeType);
		List<MposMerchantFee> mposMerchantFeeTempList = mposMerchantFeeMapper.findMposMerchantFeeTempByType(paramsMap);
		if(mposMerchantFeeTempList!=null&&mposMerchantFeeTempList.size()>0){
			return mposMerchantFeeTempList.get(0);
		}else{
		    return null;
		}
	}
	/**按类型获取费率from MPOS_MERCHANT_FEE
	 * @param feeType 费率类型
	 * @param shopperId 商户编号
	 */
	public MposMerchantFee findMposMerchantFee(String shopperId, String feeType) {
		Map<String, Object> paramsMap = new HashMap<String, Object>();
		paramsMap.put("shopperId", new BigDecimal(shopperId));
		paramsMap.put("feeType", feeType);
		List<MposMerchantFee> mposMerchantFeeList = mposMerchantFeeMapper.findMposMerchantFeeByType(paramsMap);
		if(mposMerchantFeeList!=null&&mposMerchantFeeList.size()>0){
			return mposMerchantFeeList.get(0);
		}else{
		    return null;
		}
	}
	/**按类型获取费率from MPOS_REMOTE_FEE
	 * @param feeType 费率类型
	 * @param shopperTel 商户电话
	 */
	public MposMerchantFee findMposRemoteFee(String shopperTel, String feeType) {
		MposMerchantFee mposMerchantFee = new MposMerchantFee();
		Map<String, Object> paramsMap = new HashMap<String, Object>();
		paramsMap.put("shopperTel", shopperTel);
		paramsMap.put("feeType", feeType);
		List<Map<String, String>> mposRemoteFeeList = mposMerchantFeeMapper.findMposRemoteFeeByType(paramsMap);
		if(mposRemoteFeeList!=null&&mposRemoteFeeList.size()>0){
			Map<String, String> map = mposRemoteFeeList.get(0);
			mposMerchantFee.setFee(map.get("fee"));
			mposMerchantFee.setD0Fee(map.get("d0Fee"));
			return mposMerchantFee;
		}else{
			return null;
		}
	}
	public List findQrPayMerchantFeeList(String shopperid) {
		return mposMerchantFeeMapper.findQrPayMerchantFeeList(shopperid);
	}
	public List findQrPayMerchantTempFeeList(String shopperid) {
		return mposMerchantFeeMapper.findQrPayMerchantTempFeeList(shopperid);
	}
	public List findMerchantFeeTempByMposList(Long shopperid) {
		return mposMerchantFeeMapper.findMerchantFeeTempByMposList(shopperid);
	}
	/**
	 * 查询旧商户总数
	 */
	public int findOldMerchantCount() {
		return b2cShopperbiMapper.findOldMerchantCount();
	}
	/**
	 * 查询旧商户
	 */
	public List<B2cShopperbi> findOldMerchant(int startRow,int endRow) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("startRow", startRow);
		params.put("endRow", endRow);
		return b2cShopperbiMapper.findOldMerchant(params);
	}
	/**
	 * 更新旧商户
	 */
	public void updateOldB2cShopperbi(B2cShopperbi b2cShopperbi) {
		List list = b2cShopperbiTempMapper.findbysid(b2cShopperbi.getIDNo());
		if (list!=null&&list.size()>0) {
			b2cShopperbiTempMapper.updateOldB2cShopperbiTemp(b2cShopperbi);
		}
		b2cShopperbiMapper.updateOldB2cShopperbi(b2cShopperbi);
	}
	/**
	 * 查询remote_fee
	 */
	public List findMposRemoteFee(String tel) {
		Map<String, Object> paramsMap = new HashMap<String, Object>();
		paramsMap.put("shopperTel", tel);
		paramsMap.put("feeType",null);
		return mposMerchantFeeMapper.findMposRemoteFeeByType(paramsMap);
	}
	/**
	 * 执行Update_fee存储过程
	 */
	public void updateFeeProcedure() {
		mposMerchantFeeMapper.updateFeeProcedure();
	}
	public String findQrPayMerchantFee(String shopperid) {
		return mposMerchantFeeMapper.findQrPayMerchantFee(shopperid);
	}
	
	
	
	public void batchBankInfo() throws Exception {
		int merchantCount=b2cShopperbiMapper.findB2cShopperbiCount();
		 int merchantCounts=ToolsUtils.Counts(merchantCount,Constants.BATCH_SIZE);
		 for(int y=0;y<merchantCounts;y++){
		        int currentPage = Integer.valueOf(y+1);
		        Page page  = new Page();

		        PageContext context = PageContext.getContext();
		        page.setCurrentPage(currentPage);
		        BeanUtils.copyProperties(context, page);
		        context.setPageSize(Constants.BATCH_SIZE);
		        context.setPagination(true);
				List b2cShopperbiList=b2cShopperbiMapper.findShopperBnakInfoList();
				
				for(int i=0;i<b2cShopperbiList.size();i++){
					Map map =(Map) b2cShopperbiList.get(i);
					log.info("第"+i+"条修改！");
					updateBankPort(map);
					Thread.sleep(1000);
				}
				
			}
		
	}
	
	
	private Map updateBankPort(Map map) throws  Exception {
		
		HashMap params=new HashMap();
		
		Date dates = new Date();
		String mradom = RandomStringUtils.randomNumeric(6);
		String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +map.get("B2C_SHOPPERBI_ID");
		String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");
		
		String idNum=map.get("ID_NO")==null?"":map.get("ID_NO").toString();
		String bankNo=map.get("ACCOUNT_BANK_NO")==null?"":map.get("ACCOUNT_BANK_NO").toString();
		String bankName=map.get("ACCOUNT_BANK_NAME")==null?"":map.get("ACCOUNT_BANK_NAME").toString();
		String prov=map.get("ACCOUNT_BANK_PROV_CODE")==null?"":map.get("ACCOUNT_BANK_PROV_CODE").toString();
	    String city=map.get("ACCOUNT_BANK_CITY_CODE")==null?"":map.get("ACCOUNT_BANK_CITY_CODE").toString();
	    String bankCode=map.get("BANK_CODE")==null?"":map.get("BANK_CODE").toString();
	    
        params.put("orderId", orderId);
        params.put("orderTime", orderTime);
        params.put("idNum", idNum);
        params.put("bankCode", bankCode);
        params.put("bankNo", bankNo);
        params.put("bankName", bankName);
        params.put("prov", prov);
        params.put("city", city);
       
        log.info("批量修改银行卡账户信息："+DynamicConfigLoader.getByEnv("modify_bank_card_url")+params.toString());
        Map resultMap =HttpClientUtils.postRequestMap(DynamicConfigLoader.getByEnv("modify_bank_card_url"),params,Map.class);
        log.info("批量修改银行卡账户信息返回码:"+resultMap);
		return resultMap;
	}
	public List<String> findAllShopPerbi() {
		
		List<String> resultList = null;
		try {
			PageContext.initPageSize(20);
			resultList = b2cShopperbiMapper.findAllShopPerbi();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultList;
		
	}
	/** mpos_merchant_fee_temp
	 * @param shopperId
	 * @param feeTypeDebit
	 * @param s0ChannelType
	 * @return
	 */
	public MposMerchantFee findTempFeeTChannelType(String shopperId, String feeTypeDebit, String s0ChannelType) {
		Map params=new HashMap();
		params.put("shopperId", shopperId);
		params.put("feeType", feeTypeDebit);
		params.put("channelType", s0ChannelType);
		return mposMerchantFeeMapper.findTempFeeTChannelType(params);
	}
	/** MPOS_MERCHANT_FEE
	 * @param shopperId
	 * @param feeTypeDebit
	 * @param s0ChannelType
	 * @return
	 */
	public MposMerchantFee findMposMerchantFee(String shopperId, String feeTypeDebit, String s0ChannelType) {
		Map params=new HashMap();
		params.put("shopperId", shopperId);
		params.put("feeType", feeTypeDebit);
		params.put("channelType", s0ChannelType);
		return mposMerchantFeeMapper.findMerchantFeeTChannelType(params);
	}
	
	/**mpos_remote_fee
	 * @param shopperTel
	 * @param feeTypeDebit
	 * @param s0ChannelType
	 * @return
	 */
	public MposMerchantFee findMposRemoteFee(String shopperTel, String feeTypeDebit, String s0ChannelType) {
		MposMerchantFee mposMerchantFee = new MposMerchantFee();
		Map params=new HashMap();
		params.put("shopperTel", shopperTel);
		params.put("feeType", feeTypeDebit);
		params.put("channelType", s0ChannelType);
		List<Map<String, String>> mposRemoteFeeList = mposMerchantFeeMapper.findMposRemoteFeeByChannelType(params);
		if(mposRemoteFeeList!=null&&mposRemoteFeeList.size()>0){
			Map<String, String> map = mposRemoteFeeList.get(0);
			mposMerchantFee.setFee(map.get("fee"));
			mposMerchantFee.setD0Fee(map.get("d0Fee"));
			return mposMerchantFee;
		}else{
			return null;
		}
	}
	public String findB2cDictBank(String b2cdictid) {
		
		return b2cDictMapper.findB2cDictBank(b2cdictid);
	}
	
	//查询银行卡所在联行号
	public String findUnionBankCode(String accountbankdictval){
		return b2cDictMapper.findUnionBankCode(accountbankdictval);
	}
	
	//查询速惠城市和速惠省份
	public Area findPayeeBankProvinceAndCity(String cityCode){
		return areaMapper.findPayeeBankProvinceAndCity(cityCode);
	}
	
	//OCR新商户列表页面
	public List<HashMap> findShopperTempList(ShopPerbiForm form){
		PageContext.initPageSize(Constants.PAGE_SIZE);
		return b2cShopperbiTempMapper.findShopperTempList(form);
	}
	
	//OCR新商户详情页面
	public Map findShopperTempDetails(Long shopperid){
		return b2cShopperbiTempMapper.findShopperTempDetails(shopperid);
	}

	//聚合支付商户详情页面
	public Map findAggShopperDetails(Long shopperid){
		return b2cShopperbiTempMapper.findAggShopperDetails(shopperid);
	}
	/**
	 * 查询审核状态统计
	 * @param checkstatus
	 * @return
	 */
	public Map<String, String> findCheckstatusCount(){
		return b2cShopperbiTempMapper.findCheckstatusCount();
	}

	public Map findShopperFormalDetails(Long shopperid){
		return b2cShopperbiMapper.findShopperFormalDetails(shopperid);
	}
	
	public List<HashMap> findShopperTempCheckList(ShopPerbiForm mbForm){
		PageContext.initPageSize(Constants.PAGE_SIZE);
		return b2cShopperbiTempMapper.findShopperTempCheckList(mbForm);
	}


    /**
     * 更新人工检查状态
     * @param shopperid
     * @param visualCheckStatus
     */
	public void updateVisualCheckStatus(String shopperid, String visualCheckStatus){
	    B2cShopperbiTemp b2cShopperbiTemp = new B2cShopperbiTemp();
        b2cShopperbiTemp.setShopperid(Long.valueOf(shopperid));
        b2cShopperbiTemp.setVisualCheckStatus(visualCheckStatus);
	    b2cShopperbiTempMapper.updateByShopperId(b2cShopperbiTemp);
    }

	/**
	 * 更新商户人工审核
	 */
    public void updateShopperManualaudit(B2cShopperbiTemp shopper){
		b2cShopperbiTempMapper.updateByShopperId(shopper);
	}

	/**
	 * 商户OCR错误步骤设置
	 * @param oldNotPassStep
	 * @param change
	 */
	public String changeNotPassStep(String oldNotPassStep, String change){
    	int changeIndex = Integer.valueOf(change);
		return replaceIndex(changeIndex, oldNotPassStep, Constants.TYPE_0);//设置对应错误步骤状态为未提交
	}

	/**
	 *字符串替换
	 * @param index
	 * @param res
	 * @param str
	 * @return
	 */
	public static String replaceIndex(int index,String res,String str){
		return res.substring(0, index)+str+res.substring(index+1);
	}

    /**
     * 审核通过保存商户正式表信息
     * @param b2cShopperbiTemp
     */
	public void updateShopperFormalByTemp(B2cShopperbiTemp b2cShopperbiTemp){
	    b2cShopperbiMapper.updateShoppbiTemp(b2cShopperbiTemp);
    }


    /**
     * 审核通过保存商户费率
     * @param shopperid
     */
    public void updateShopperFee(String shopperid){
    	
		MposMerchantFee s0creditMerchantFee;
		MposMerchantFee s0debitMerchantFee;
		MposMerchantFee d0creditMerchantFee;
		MposMerchantFee d0debitMerchantFee;
		MposMerchantFee t1creditMerchantFee;
		MposMerchantFee t1debitMerchantFee;
		MposMerchantFee weChatMerchantFee;
		MposMerchantFee alipayMerchantFee;
		MposMerchantFee ylpayMerchantFee;
		MposMerchantFee shortCutMerchantFee;
		MposMerchantFee shortCutSHMerchantFee;
		MposMerchantFee b2cMerchantFee;
		
		List<MposMerchantFee> feeList = mposMerchantFeeMapper.findtempbyshopperid(shopperid);
		//如果商户预约表有信息
		if(null != feeList && feeList.size() > 0){
			//获取商户预约费率
			s0creditMerchantFee = findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
			s0debitMerchantFee = findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);

			d0creditMerchantFee = findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
			d0debitMerchantFee = findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);

			t1creditMerchantFee = findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
			t1debitMerchantFee = findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);

			weChatMerchantFee = findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_WECHAT);
			alipayMerchantFee = findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_ALIPAY);
			ylpayMerchantFee = findMposMerchantFeeTemp(shopperid,Constants.FEE_TYPE_YLPAY);

			shortCutMerchantFee = findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_SHORTCUT);//快捷汇率
			shortCutSHMerchantFee = findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_SHD0);//速惠汇率
			b2cMerchantFee= findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_B2C);//B2C汇率
			//更新商户正式费率
			mposMerchantFeeMapper.updateByShopperIdFee(s0creditMerchantFee);
			mposMerchantFeeMapper.updateByShopperIdFee(s0debitMerchantFee);
			mposMerchantFeeMapper.updateByShopperIdFee(d0creditMerchantFee);
			mposMerchantFeeMapper.updateByShopperIdFee(d0debitMerchantFee);

			mposMerchantFeeMapper.updateByShopperIdFee(t1creditMerchantFee);
			mposMerchantFeeMapper.updateByShopperIdFee(t1debitMerchantFee);

			mposMerchantFeeMapper.updateByShopperId(weChatMerchantFee);
			mposMerchantFeeMapper.updateByShopperId(alipayMerchantFee);
			mposMerchantFeeMapper.updateByShopperId(ylpayMerchantFee);

			mposMerchantFeeMapper.updateByShopperId(shortCutMerchantFee);
			mposMerchantFeeMapper.updateByShopperId(shortCutSHMerchantFee);
			mposMerchantFeeMapper.updateByShopperId(b2cMerchantFee);
		}
        
    }

	/**
	 * 更新照片信息
	 * @param b2cShopperbiTemp
	 * @throws Exception
	 */
    public void updateShopperPhoto(B2cShopperbiTemp b2cShopperbiTemp) throws Exception {
    	Long photoid = null;
    	if(null != b2cShopperbiTemp.getPhotoid()){
			photoid = b2cShopperbiTemp.getPhotoid();
			MposPhotoTmp mposPhotoTmp = mposphototmpmapper.selectByPrimaryKey(BigDecimal.valueOf(photoid));
			MposPhoto mposPhoto = new MposPhoto();
			BeanUtils.copyProperties(mposPhoto, mposPhotoTmp);
    		mposPhotoMapper.updateByPrimaryKeySelective(mposPhoto);
		}
	}

	/**
	 * 更新商户基本信息
	 */
	public void setShopperTempBaseInfo(B2cShopperbiTemp shopper, ShopPerbiForm mbForm){

		//获取所在地省市
		String province = shopper.getProvince();
		String city = shopper.getCity();
		Map provAndCity = new HashMap();
		provAndCity.put("provincial",province);
		provAndCity.put("city",city);
		Map areaMap = areaMapper.findByProvAndCity(provAndCity);
		shopper.setSprovince((String)areaMap.get("PROVINCIALNAME"));
		shopper.setScity((String)areaMap.get("CITYNAME"));

		//获取票据省市
		province = shopper.getBillProvinceCode();
		city = shopper.getBillCityCode();
		provAndCity = new HashMap();
		provAndCity.put("provincial",province);
		provAndCity.put("city",city);
		areaMap = areaMapper.findByProvAndCity(provAndCity);
		shopper.setBillProvince((String)areaMap.get("PROVINCIALNAME"));
		shopper.setBillCity((String)areaMap.get("CITYNAME"));

		shopper.setIfagent(Constants.LONG_0);// 0为商户，1为代理商
		shopper.setUpdated(new Date());
		
		if(null != mbForm.getShopperid_p()){
			shopper.setShopperidP(Long.valueOf(mbForm.getShopperid_p()));
		}

		//设置商户信息修改了
		shopper.setIsupdateshopper(new Short(Constants.TYPE_1));
		
		//审核状态
		shopper.setCheckstatus(Constants.TYPE_4);//人工审核中
		shopper.setNotPassReason("");

		//转人工时间
		shopper.setToManualauditDate(new Date());

		//结算卡修改日期
		shopper.setBankUpdateDate(new Date());

	}

	/**
	 * 设置商户备份
	 */
	public void setBackupShopperInfo(HttpServletRequest request, B2cShopperbiTemp b2cShopperbiTemp, BackupsShopperInformation backupShopper){
		backupShopper.setCreateUser(((Operator) request.getSession().getAttribute(Constants.SESSION_KEY_USER)).getId().toString());
		backupShopper.setCreateDate(new Date());
		backupShopper.setT0fee(new BigDecimal(b2cShopperbiTemp.getT0fee() == null ? "0.0" : b2cShopperbiTemp.getT0fee().toString()));
		backupShopper.setShopperid(new BigDecimal(b2cShopperbiTemp.getShopperid() == null ? 0.0 : b2cShopperbiTemp.getShopperid()));
		backupShopper.setT0additionfee(new BigDecimal(b2cShopperbiTemp.getT0additionfee() == null ? 0.0 : b2cShopperbiTemp.getT0additionfee()));
		backupShopper.setT0fixedamount(new BigDecimal(b2cShopperbiTemp.getT0fixedamount() == null ? 0.0 : b2cShopperbiTemp.getT0fixedamount()));
		backupShopper.setT0maxamount(new BigDecimal(b2cShopperbiTemp.getT0maxamount() == null ? 0.0 : b2cShopperbiTemp.getT0maxamount()));
		backupShopper.setT0minamount(new BigDecimal(b2cShopperbiTemp.getT0minamount() == null ? 0.0 : b2cShopperbiTemp.getT0minamount()));
		backupShopper.setT0singledaylimit(new BigDecimal(b2cShopperbiTemp.getT0SingleDayLimit() == null ? 0.0 : b2cShopperbiTemp.getT0SingleDayLimit()));
		backupShopper.setAccountBankClientName(b2cShopperbiTemp.getAccountbankclientname() == null ? "" : b2cShopperbiTemp.getAccountbankclientname());
		backupShopper.setAccountBankDictval(b2cShopperbiTemp.getAccountbankdictval() == null ? "" : b2cShopperbiTemp.getAccountbankdictval());
		backupShopper.setAccountBankName(b2cShopperbiTemp.getAccountbankname() == null ? "" : b2cShopperbiTemp.getAccountbankname());
		backupShopper.setAccountBankNo(b2cShopperbiTemp.getAccountbankno() == null ? "" : b2cShopperbiTemp.getAccountbankno());
		backupShopper.setAccountBankProv(b2cShopperbiTemp.getAccountbankprov() == null ? "" : b2cShopperbiTemp.getAccountbankprov());
	}

	/**
	 * 激活商户
	 * @param b2cShopperbiTemp
	 */
	public boolean activateMerchant(B2cShopperbiTemp b2cShopperbiTemp) throws Exception {
		//激活MPOS
		Map activateMposResultMap = activateMerchantPort(b2cShopperbiTemp);
		JSONObject ob= JSONObject.fromObject(activateMposResultMap);
		String rspCode=(String)ob.get("rspCode");
		String rspMsg=(String)ob.get("rspMsg");
		log.info("激活MPOS结果：" + rspMsg);

		//激活扫码
		Map activateQrPayResultMap = activateQrPayMerchantPort(b2cShopperbiTemp);
		JSONObject qrpay= JSONObject.fromObject(activateQrPayResultMap);
		String qrpayRspCode=(String)qrpay.get("rspCode");
		log.info("激活扫码结果：" + qrpayRspCode);

		//MPOS和扫码全部成功
		if (Constants.RESPONSE_CODE.equals(rspCode) && Constants.RESPONSE_CODE.equals(qrpayRspCode)) {
			return true;
		}else{
			return false;
		}
	}

	/**
	 * 激活MPOS
	 * @throws Exception
	 */
	private Map activateMerchantPort(B2cShopperbiTemp b2cShopperbiTemp) throws Exception {
		HashMap params=new HashMap();

		Date dates = new Date();
		String mradom = RandomStringUtils.randomNumeric(6);
		String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbiTemp.getB2cShopperbiId();
		String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");

		params.put("orderId", orderId);
		params.put("userId", b2cShopperbiTemp.getYsbNo());
		params.put("activeStatus", Constants.TYPE_2);//已激活

		JSONObject obs = JSONObject.fromObject(params);
		String request = "activeStatus=" + Constants.TYPE_2 + "&orderId="+orderId+"&userId="+ b2cShopperbiTemp.getYsbNo() ;
		log.info("请求激活银生宝账号请求参数："+request);
		log.info("请求激活银生宝账号："+DynamicConfigLoader.getByEnv("update_user_status_url")+request);
		String result = HttpClientUtils.REpostRequestStrNormal(DynamicConfigLoader.getByEnv("update_user_status_url"), request);
		Map resultMap = jsonStrToMap(result);

		return resultMap;

	}


	/**激活扫码
	 * @param b2cShopperbi
	 * @return
	 * @throws Exception
	 */
	private Map activateQrPayMerchantPort(B2cShopperbiTemp b2cShopperbi) throws Exception {

		HashMap params=new HashMap();

		Date dates = new Date();
		String mradom = RandomStringUtils.randomNumeric(6);
		String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbi.getB2cShopperbiId();
		String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");

		params.put("orderId", orderId);
		params.put("userId", b2cShopperbi.getQrPayNo());
		params.put("activeStatus", Constants.TYPE_2);//已激活

		JSONObject obs = JSONObject.fromObject(params);
		String request = "activeStatus=" + Constants.TYPE_2 + "&orderId="+orderId+"&userId="+ b2cShopperbi.getQrPayNo();
		log.info("请求激活扫码支付账号："+DynamicConfigLoader.getByEnv("update_qrpay_user_status_url")+request.toString());
		String result = HttpClientUtils.REpostRequestStrNormal(DynamicConfigLoader.getByEnv("update_qrpay_user_status_url"), request);

		Map resultMap = jsonStrToMap(result);
		log.info("请求激活扫码支付账号返回码："+resultMap.toString());
		return resultMap;
	}

	/**
	 * 通过预约商户信息更新正式商户
	 */
	public void updateShopperFormalByShopperTemp(B2cShopperbiTemp b2cShopperbiTemp){
		b2cShopperbiMapper.updateMerchant(b2cShopperbiTemp);
	}

	/**
	 * 根据shopperid查询所有费率
	 * @param shopperid
	 * @return
	 */
	public List<MposMerchantFee> findtempbyshopperid(String shopperid){
		return mposMerchantFeeMapper.findtempbyshopperid(shopperid);
	}

	// 聚合支付商户用户列表页面
	public List<HashMap> findShopperAggTempList(ShopPerbiForm form){
		PageContext.initPageSize(Constants.PAGE_SIZE);
		return b2cShopperbiTempMapper.findShopperAggTempList(form);
	}

	// 聚合支付商户用户状态列表查询
	public List<HashMap> findShopperAggStatusList(ShopPerbiForm form){
		PageContext.initPageSize(Constants.PAGE_SIZE);
		return b2cShopperbiTempMapper.findShopperAggStatusList(form);
	}

	/**
	 *
	 * 商户用户初审通过
	 *
	 * @param b2cShopperbi
	 * @param request
	 * @throws Exception
	 */
	public void firstCheckAggShopper(B2cShopperbiTemp b2cShopperbi,
								HttpServletRequest request) throws Exception {

		String password="";
		if((!(b2cShopperbi.getReportResource().equals("3")))&&b2cShopperbi.getShopperidP()!=null){
			password=RandomStringUtils.randomNumeric(6);
			b2cShopperbi.setMpassword(Md5Encrypt.md5(password));
		}
		//代理商注册
		String merchantKey=com.uns.util.StringUtils.getCharAndNumr(8);
		b2cShopperbi.setMerchantKey(merchantKey);


		b2cShopperbi.setIsformal(new Short(Constants.CON_YES));//0表示非正式商户，1表示审核过的正式商户

		b2cShopperbi.setIfvalid(Short.valueOf(Constants.TYPE_1));//初审通过
		b2cShopperbi.setIfactivated(Constants.CON_YES);
		b2cShopperbi.setIfactivadate(new Date());

		updateShopperTempAggCheckStatus(b2cShopperbi);//更新预约信息
		updateShopperAggCheckStatus(b2cShopperbi);//更新正式信息
		request.setAttribute(Constants.MESSAGE_KEY,"审核成功!");

	}

    /**
     *
     * 商户用户复审通过
     *
     * @param b2cShopperbi
     * @param request
     * @throws Exception
     */
    public void reCheckAggShopper(B2cShopperbiTemp b2cShopperbi,
                                     HttpServletRequest request) throws Exception {

        String password="";
        if((!(b2cShopperbi.getReportResource().equals("3")))&&b2cShopperbi.getShopperidP()!=null){
            password=RandomStringUtils.randomNumeric(6);
            b2cShopperbi.setMpassword(Md5Encrypt.md5(password));
        }
        //代理商注册
        String merchantKey=com.uns.util.StringUtils.getCharAndNumr(8);
        b2cShopperbi.setMerchantKey(merchantKey);

        //调用业务接口
        if(ConstantsEnv.OPEN_CIB_REGISTER.equals(Constants.OPEN_CIB_YES)){
            if(null != b2cShopperbi.getShopperidP() &&
                    null == b2cShopperbi.getIfactivated()){//如果商户没有激活

                //调用业务系统注册账号
                Map activateMap = activateAggMerchantPort(b2cShopperbi);
                log.info("激活账户返回码:"+activateMap);
                JSONObject ob = JSONObject.fromObject(activateMap);
                String rspCode=(String)ob.get("rspCode");
                String rspMsg=(String)ob.get("rspMsg");
                if(!Constants.RESPONSE_CODE.equals(rspCode)){
                    throw new BusinessException(ExceptionDefine.激活商户失败,new String[]{rspMsg});
                }
                //激活账户成功
                Map openMap = activateAggPay(b2cShopperbi);
                log.info("开通支付业务码：" + openMap);
                JSONObject openJo = JSONObject.fromObject(openMap);
                String openCode = (String)openJo.get("result_code");
                String openMsg = (String)openJo.get("result_msg");
                if(!Constants.RESPONSE_CODE.equals(openCode)){
                    throw new BusinessException(ExceptionDefine.激活商户失败,new String[]{openMsg});
                }
                b2cShopperbi.setTransact(Constants.TYPE_2);//已激活
            }
            b2cShopperbi.setCibFlag(Constants.TYPE_1); //已报备
        } else {
            b2cShopperbi.setCibFlag(Constants.TYPE_0);
            log.info("调用上游cib通道接口未打开{未报备}");
        }
        b2cShopperbi.setIsformal(new Short(Constants.CON_YES));//0表示非正式商户，1表示审核过的正式商户
		b2cShopperbi.setNotPassReason("");
        b2cShopperbi.setIfvalid(Short.valueOf(Constants.TYPE_1));//初审通过
        b2cShopperbi.setRecheckmerchantflag(Constants.TYPE_1);//复审通过
        b2cShopperbi.setIfactivated(Constants.CON_YES);
        b2cShopperbi.setIfactivadate(new Date());

        updateShopperTempAggCheckStatus(b2cShopperbi);//更新预约信息
        updateShopperAggCheckStatus(b2cShopperbi);//更新正式信息
        request.setAttribute(Constants.MESSAGE_KEY,"审核成功!");

    }

	/**
	 * 更新商户用户预约审核状态
	 */
	public void updateShopperTempAggCheckStatus(B2cShopperbiTemp shopper){
		b2cShopperbiTempMapper.updateShopperAggTempCheckStatus(shopper);
	}
	/**
	 * 更新商户用户正式审核状态
	 */
	public void updateShopperAggCheckStatus(B2cShopperbiTemp shopper){
		b2cShopperbiTempMapper.updateShopperAggCheckStatus(shopper);
	}

	public void updateShopperAggStatus(Map param){
        b2cShopperbiTempMapper.updateShopperAggStatus(param);
    }


	/**
	 * 聚合支付版
	 * 商户用户调业务系统报备
	 * @param b2cShopperbiTemp
	 * @return
	 * @throws Exception
	 */
    private Map activateAggPay(B2cShopperbiTemp b2cShopperbiTemp) throws Exception{
		Map params = new HashMap();
		params.put("smallMerchNo",b2cShopperbiTemp.getShopperid());
		params.put("wxAppId",b2cShopperbiTemp.getWxPayId());
		params.put("wxAppSecret",b2cShopperbiTemp.getWxPayKey());
		params.put("bankCode",b2cShopperbiTemp.getBankCode());
		params.put("mchId",b2cShopperbiTemp.getCibShopperId());
		params.put("mchKey",b2cShopperbiTemp.getCibShopperSecretkey());

        String mac = CheckMacUtil.assembleMac(params);
        b2cShopperbiTemp.setMac(mac);
        params.put("mac",mac);
        //调用业务平台注册账户
        JSONObject obs = JSONObject.fromObject(params);
        System.out.println("obs:" + obs);
        log.info("报备业务系统参数："+ ConstantsEnv.AGGREGATE_PAY_REG_PORT + obs.toString());
        String resultString =HttpClientUtils.REpostRequestStr(ConstantsEnv.AGGREGATE_PAY_REG_PORT,obs.toString());
        Map resultMap = jsonStrToMap(resultString);

		return resultMap;
	}

    /**
     * 聚合支付版
     * 商户用户激活
     * @throws BusinessException
     */
    private Map activateAggMerchantPort(B2cShopperbiTemp b2cShopperbi) throws Exception {

        Date dates = new Date();
        String mradom = RandomStringUtils.randomNumeric(6);
        String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbi.getB2cShopperbiId();
        HashMap params=new HashMap();

        String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");
        //基本信息
        String linkName=b2cShopperbi.getScompany();
        String idCard=b2cShopperbi.getIDNo();
        String tel=b2cShopperbi.getStel();
        String merchantNo=b2cShopperbi.getShopperid()==null?"":b2cShopperbi.getShopperid().toString();
        Long agentNo=b2cShopperbi.getShopperidP();
        String platformType="";
        if(agentNo!=null){
            platformType=Constants.CON_NO;//0 自有
        }else{
            platformType=Constants.CON_YES;//机构
        }
        //结算信息
        //String settlementType=b2cShopperbi.getSettlementType();
        String accountbankname=b2cShopperbi.getAccountbankother(); //开户银行
        String accountbankprovCode=b2cShopperbi.getProvince();
        String accountBankCityCode=b2cShopperbi.getCity();
        String accountbankno=b2cShopperbi.getAccountbankno(); //结算卡号
        // String CardType=b2cShopperbi.getCardType();
        // 手续费
        List merchantFeeList= findMerchantFeeByMpos(b2cShopperbi.getShopperid());


        //t1type
        params.put("t1Type", b2cShopperbi.getT1type()==null?"0":b2cShopperbi.getT1type());
        //params.put("t1fee", b2cShopperbi.getT1fee()==null?"0":b2cShopperbi.getT1fee());
        params.put("t1topamount",b2cShopperbi.getT1topamount()==null?"0":b2cShopperbi.getT1topamount());

        //t+0手续费
        String issupportt0=b2cShopperbi.getIsSupportT0(); //0支持
        Double t0singledaylimit=0.00;
        if(Constants.CON_NO.equals(issupportt0)){
            //isicapplyt0=b2cShopperbi.getIsIcApplyT0();
            t0singledaylimit=b2cShopperbi.getT0SingleDayLimit();
            // params.put("isicapplyt0", isicapplyt0==null?"":isicapplyt0);
            params.put("creditAmount", t0singledaylimit==null?"":t0singledaylimit);
        }else{
            params.put("t0Type","0");
            params.put("t0fee","0");
            params.put("creditAmount",Constants.CON_NO);
        }
        params.put("orderId", orderId==null?"":orderId);
        params.put("orderTime", orderTime==null?"":orderTime);
        params.put("name", linkName==null?"": URLDecoder.decode(linkName,"UTF-8"));
        params.put("idNum", idCard==null?"":idCard);
        params.put("mobilePhoneNum", tel==null?"":tel);
        String bankCode= findBankName(b2cShopperbi.getAccountbankdictval())==null?"":URLDecoder.decode( findBankName(b2cShopperbi.getAccountbankdictval()).getDictid(),"UTF-8");
        params.put("bankCode", bankCode == "" ? "0":bankCode); //银行总行编码
        params.put("bankNo", accountbankno==null ? "":accountbankno);
        params.put("bankName", accountbankname==null ? "":URLDecoder.decode(accountbankname,"UTF-8"));
        params.put("prov", accountbankprovCode==null ? "":accountbankprovCode);
        params.put("city", accountBankCityCode==null ? "":accountBankCityCode);
        params.put("cityName", b2cShopperbi.getScity());

        params.put("merchantNo", merchantNo==null?"":merchantNo);
        params.put("proxyId", agentNo==null?"":agentNo);
        params.put("platformType", platformType==null?"":platformType);

        params.put("commissionIds", merchantFeeList);
        params.put("issupportt0", issupportt0==null?"":issupportt0);//是否支持T0提现

        params.put("scompany", b2cShopperbi.getScompany());
        params.put("agentNo", b2cShopperbi.getShopperidP());
        params.put("terminalNo", b2cShopperbi.getHfpsam());
        //分润方案
        params.put("profitOwner", b2cShopperbi.getProfitOwner());//分润给那个代理商
        params.put("agentProfitRatio", b2cShopperbi.getAgentProfitRatio()); //代理商分润百分比
        params.put("merchProfitRatio1", b2cShopperbi.getMerchProfitRatio1());//商户分润方案1
        params.put("merchProfitRatio2", b2cShopperbi.getMerchProfitRatio2()); //商户分润方案2
        params.put("merchProfitRatio3", b2cShopperbi.getMerchProfitRatio3()); //商户分润方案3

		//存量字段处理
		params.put("creditLines","0");
		params.put("settleType","1");
		params.put("isExternalRevenue","0");
		params.put("fixQrcodeCustomerName",linkName);
		params.put("qrMerchantKey","123456"); //
		params.put("userType","S"); //P个人 C机构 S商户
		params.put("provinceName",b2cShopperbi.getProvince()); //P个人 C机构 S商户
        params.put("openingBankName",b2cShopperbi.getAccountbankother()); //开户银行名称
		params.put("merchAddress",b2cShopperbi.getBillAddress());
		params.put("payeeBankId","0");
		params.put("payeeBankProvince","0");
		params.put("payeeBankCity","0");
		params.put("tradeSource","2"); //商户类型
		//调用业务平台注册账户
        JSONObject obs = JSONObject.fromObject(params);
        log.info("请求mpos_qrcode注册账号请求参数："+ ConstantsEnv.QR_CODE_REG_PORT+obs.toString());
        String resultString =HttpClientUtils.REpostRequestStr(ConstantsEnv.QR_CODE_REG_PORT,obs.toString());
        Map resultMap = jsonStrToMap(resultString);

        return resultMap;

    }


}
