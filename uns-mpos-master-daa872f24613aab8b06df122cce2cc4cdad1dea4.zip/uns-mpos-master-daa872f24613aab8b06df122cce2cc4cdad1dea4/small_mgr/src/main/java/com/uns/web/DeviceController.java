package com.uns.web;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.model.Agent;
import com.uns.model.B2cShopperbi;
import com.uns.model.B2cTempTermBinder;
import com.uns.model.B2cTermBinder;
import com.uns.service.DeviceService;
import com.uns.service.ShopPerbiService;
import com.uns.util.HttpClientUtils;
import com.uns.util.StringUtils;
import com.uns.web.form.ShopPerbiForm;

import jxl.SheetSettings;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import net.sf.json.JSONObject;

@Controller("deviceController")
@RequestMapping("/device.htm")
public class DeviceController extends BaseController{
	@Autowired
	private DeviceService deviceservice;
	@Autowired
	private ShopPerbiService shopPerbiService;
	
	 @RequestMapping(params = "method=showdeviceList")
		public String showdeviceList(HttpServletRequest request, ModelMap modelMap, ShopPerbiForm mbForm) throws Exception {
			try{
                List<HashMap> shopPerbilist=null;
				
				//判断商户编号是否为数字
				String shopperIdq=mbForm.getTermNo();
				if(!StringUtils.isEmpty(shopperIdq)){
					boolean b=isFigure(shopperIdq);
					if(!b){
						mbForm.setShopperidq("");
					}
				}
				shopPerbilist = deviceservice.showdeviceList(mbForm);
				request.setAttribute("shopPerbilist", shopPerbilist);
				
		    	//获取未审核的商户开户行信息的个数
				String Tercount = deviceservice.selectfirstCount();
		    	request.setAttribute("Tercount",Tercount);
		    	
				request.setAttribute("belongsAgent", mbForm.getBelongsAgent());
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				throw new BusinessException(ExceptionDefine.商户查询失败);
			}
				
			
			return "shopPerbi/shopPerbiTermianlList";
		}
	 
	 /**审核终端信息变更
		 * @param request
		 * @param b2cShopperbi
		 * @param b2cShopperbargain
		 * @param modelMap
		 * @return
		 * @throws Exception 
		 */
		@RequestMapping(params = "method=queryCheckTerminal")
		@FormToken(save=true)
		public String queryCheckTerminal(HttpServletRequest request, 
				ModelMap modelMap,B2cShopperbi b2cShopperbi,
				B2cTempTermBinder term,
				ShopPerbiForm mbForm) throws Exception {
			try {
				String termNo= request.getParameter("termNo");
				if(StringUtils.isEmpty(termNo)){
				    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
	                mbForm.setBelongsAgent(null);
	                request.setAttribute("url","device.htm?method=");
				}else{
					term=deviceservice.selectterm(termNo);
					b2cShopperbi=shopPerbiService.queryFormalShopPerbi(term.getMerchantNo());
				}
		        if(b2cShopperbi!=null){
		        	//获取代理商
		            Long shopperId= b2cShopperbi.getShopperidP();
		            if(shopperId!=null){
		            	Agent agent=shopPerbiService.searchAgent(shopperId);
		                modelMap.put("agentName", agent.getScompany());
		                modelMap.put("agentId", agent.getShopperid());
		            }
		        }
		        modelMap.put("b2cShopperbi", b2cShopperbi);
		        modelMap.put("term", term);
			} catch (Exception e) {
				e.printStackTrace();
				throw new BusinessException(ExceptionDefine.获取商户信息失败);
			}
			return "shopPerbi/shopPerbiCheckTerminal";
		}
	 

		/**审核商户基本信息(保存):
		 * @param request
		 * @param response
		 * @param modelMap
		 * @param b2cShopperbi
		 * @param b2cShopperbargain
		 * @param mbForm
		 * @return
		 * @throws IOException
		 * @throws BusinessException 
		 */
		@RequestMapping(params = "method=savedevicenum")
		@FormToken(remove=true)
	    public String savedevicenum(HttpServletRequest request, ModelMap modelMap,B2cTempTermBinder term,	ShopPerbiForm mbForm) throws Exception, BusinessException {
			try {
				String terms=request.getParameter("terms");
				if(mbForm.getFirstVerify()!=null&& mbForm.getFirstVerify().equals("1"))
				{
					B2cTempTermBinder term1=new B2cTempTermBinder();
					term1=deviceservice.selectterm(terms);
					
					term1.setFirstVerify("1");//审核通过
					deviceservice.updateterm(term1);
					request.setAttribute(Constants.MESSAGE_KEY,"审核成功!");
					request.setAttribute("url","device.htm?method=showdeviceList");
				}
				
			} catch (Exception e) {
				e.printStackTrace();
				throw new BusinessException(ExceptionDefine.审核失败);
			}
			return "/returnPage";
			
		}
		
		
		
		/**
		 * @param request
		 * @param modelMap
		 * @param mbForm
		 * @return   复审
		 * @throws Exception
		 */
		@RequestMapping(params = "method=recheckdeviceList")
		public String recheckdeviceList(HttpServletRequest request, ModelMap modelMap, ShopPerbiForm mbForm) throws Exception {
			try{
                List<HashMap> shopPerbilist=null;
                String  checkAgent=request.getParameter("checkAgent");
    			if(StringUtils.isEmpty(checkAgent)){
    				mbForm.setCheckAgents(false);
    			}else{
    				if(checkAgent.equals("true")){
    					mbForm.setCheckAgents(true);
    				}else{
    					mbForm.setCheckAgents(false);
    				}
    			}
				shopPerbilist = deviceservice.showdeviceList(mbForm);
				modelMap.put("shopPerbilist", shopPerbilist);
				
		    	//获取未审核的商户开户行信息的个数
				String Tercount = deviceservice.selectlastsCount();
		    	request.setAttribute("Tercount",Tercount);
		    	
				request.setAttribute("belongsAgent", mbForm.getBelongsAgent());
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				throw new BusinessException(ExceptionDefine.商户查询失败);
			}
				
			
			return "recheck/reCheckTerminalList";
		}
	 
		
		
		
		/**终端复核
		 * @param request
		 * @param modelMap
		 * @param mbForm
		 * @return
		 * @throws Exception
		 */
		@RequestMapping(params = "method=reCheckTerminal")
		@FormToken(save=true)
		public String reCheckTerminal(HttpServletRequest request, ModelMap modelMap,
				ShopPerbiForm mbForm)throws Exception {
			B2cShopperbi b2cShopperbi=null;
			B2cTempTermBinder term=null;
			String termNo=request.getParameter("termNo");
			if(StringUtils.isEmpty(termNo)){
			    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
	            mbForm.setBelongsAgent(null);
	            request.setAttribute("url","device.htm?method=recheckdeviceList");
			}else{
				term=deviceservice.selectterm(termNo);
				b2cShopperbi=shopPerbiService.queryFormalShopPerbi(term.getMerchantNo());
			}
            
			if(b2cShopperbi!=null){
	        	//获取代理商
				
	            Long shopperId1= b2cShopperbi.getShopperidP();
	            if(termNo!=null){
	            	Agent agent=shopPerbiService.searchAgent(shopperId1);
	                modelMap.put("agentName", agent.getScompany());
	                modelMap.put("agentId", agent.getShopperid());
	            }
	        }
	        
	        modelMap.put("term", term);
			return "recheck/reCheckTerminal";
		}
		
		/**终端复核详情
		 * @param request
		 * @param modelMap
		 * @param mbForm
		 * @return
		 * @throws Exception
		 */
		@RequestMapping(params = "method=reCheckTerminalDetails")
		public String reCheckTerminalDetails(HttpServletRequest request, ModelMap modelMap,
				ShopPerbiForm mbForm)throws Exception {
			B2cTempTermBinder term=null;
 			String termNo=request.getParameter("termNo");
			if(StringUtils.isEmpty(termNo)){
			    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
	            mbForm.setBelongsAgent(null);
	            request.setAttribute("url","device.htm?method=recheckdeviceList");
			}else{
				term=deviceservice.selectterm(termNo);
			}

			B2cShopperbi b2cShopperbi=shopPerbiService.queryFormalShopPerbi(term.getMerchantNo());
	        
			if(b2cShopperbi!=null){
	        	//获取代理商
	            Long shopperId1= b2cShopperbi.getShopperidP();
	            if(termNo!=null){
	            	Agent agent=shopPerbiService.searchAgent(shopperId1);
	                modelMap.put("agentName", agent.getScompany());
	                modelMap.put("agentId", agent.getShopperid());
	            }
	        }
	        modelMap.put("term", term);
			return "recheck/reCheckTerminalDetails";
		}
		
		
		/**终端复审：
		 * 审核通过：1.将商户绑定的终端，状态改成0 2.修改审核状态
		 * 审核不通过：修改审核状态
		 * @param request
		 * @param mbForm
		 * @return
		 * @throws Exception
		 */
		@RequestMapping(params = "method=saveReCheck")
		@FormToken(remove=true)
		public String saveReCheck(HttpServletRequest request,ShopPerbiForm mbForm)throws Exception {
			String termNo=request.getParameter("termNo");
			String lastVerift=mbForm.getLastVerify();
			String remark=request.getParameter("remark");
			if(StringUtils.isEmpty(termNo)){
				request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
	            mbForm.setBelongsAgent(null);
			}else{
				B2cTempTermBinder term=deviceservice.selectterm(termNo);
				if(term!=null){
					if(lastVerift.equals("1")){
						
						term.setRemark(remark);
						
						
						B2cTermBinder newterm=new B2cTermBinder();
						Date date=new Date();
						newterm.setCreateDate(date);
						newterm .setMerchantNo(term.getMerchantNo());
						newterm.setTermNo(term.getTermNo());
						newterm.setStatus("0");
						String message=deviceservice.updateorinsertterm(term,newterm,lastVerift,request);
						request.setAttribute(Constants.MESSAGE_KEY,message);
					}else if(lastVerift.equals("2")){
						term.setLastVerify(lastVerift);
						term.setRemark(remark);
						deviceservice.updateterm(term);
						request.setAttribute(Constants.MESSAGE_KEY,"复审不成功!");
					}
					
					
				}
			}
			request.setAttribute("url","device.htm?method=recheckdeviceList");
			return "/returnPage";
		}
		
		
	public boolean isFigure(String shopperIdq){
		boolean b=shopperIdq.matches(Constants.CON_FIGURE);
		return b;
	}
	
	
	
	
	
	/**
	 * @param request
	 * @param response
	 * @param mbForm
	 * @return
	 * @throws Exception  zt
	 */
	@RequestMapping(params = "method=finddevicePage")
	public String finddevicePage(HttpServletRequest request, HttpServletResponse response,
			ShopPerbiForm mbForm)throws Exception {
		String  checkAgent=request.getParameter("checkAgent");
		if(StringUtils.isEmpty(checkAgent)){
				mbForm.setCheckAgents(false);
			}else{
				if(checkAgent.equals("true")){
					mbForm.setCheckAgents(true);
				}else{
					mbForm.setCheckAgents(false);
				}
		}
		Page page  = new Page();
		page.setPageSize(Constants.EXCEL_SIZE);
		PageContext context = PageContext.getContext();
		BeanUtils.copyProperties(context, page);
		context.setPagination(true);
		deviceservice.showdeviceListexport(mbForm);
		BeanUtils.copyProperties(page, context);
		request.setAttribute("mbForm",mbForm);
		request.setAttribute("page",page);
		request.setAttribute("checkAgent",checkAgent);
		
		return "recheck/exportdevicePage";
	}
	
	
	
	@RequestMapping(params = "method=downdeviceExcel")
	public String downdeviceExcel(HttpServletRequest request, HttpServletResponse response, ShopPerbiForm form)
			throws BusinessException, Exception{
			try{
				String tPage = request.getParameter("page");
				if (StringUtils.isEmpty(tPage) || !org.apache.commons.lang3.StringUtils.isNumeric(tPage)){
					tPage = "1";
				}
				String  checkAgent=request.getParameter("checkAgent");
				if(StringUtils.isEmpty(checkAgent)){
					form.setCheckAgents(false);
					}else{
						if(checkAgent.equals("true")){
							form.setCheckAgents(true);
						}else{
							form.setCheckAgents(false);
						}
				}
				int currentPage = Integer.valueOf(tPage);
				Page page  = new Page();
				page.setPageSize(Constants.EXCEL_SIZE);
				PageContext context = PageContext.getContext();
				BeanUtils.copyProperties(context, page);
				context.setPagination(true);
				context.setCurrentPage(currentPage);
			List excelList = deviceservice.finddevicePageList(form);
			// 标题
			Map<String, String> mapField = new LinkedHashMap();
			    mapField.put("shopperid","商户编号");
	        	mapField.put("scompany","商户名称");
	        	mapField.put("stel","商户手机号");
	        	mapField.put("agentname","代理商名称");
	        	mapField.put("agenttel","代理商手机号");
	        	mapField.put("pagentname","所属一级代理商");
	        	mapField.put("pagenttel","所属一级代理商手机号");
	        	mapField.put("term_no","MPOS终端编号");
	        	mapField.put("create_date","添加时间");
	        	mapField.put("first","初审结果");
	        	mapField.put("last","复审结果");
			String fileName="MPOS终端审核与绑定信息数据导出";
			outExcel(excelList, response, mapField, fileName);
		} catch (Exception e) {
			log.info("导出数据有误！");
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 导出excel
	 * 
	 * @param excelList
	 * @param response
	 * @param mapField
	 * @throws Exception
	 */
	private void outExcel(List excelList, HttpServletResponse response, Map<String, String> mapField, String fileNames) throws Exception {

		response.setContentType("application/vnd.ms-excel");
		response.setHeader("content-disposition", "attachment;filename=" + new String(fileNames.getBytes("UTF-8"), "iso8859-1") + ".xls");
		response.setCharacterEncoding("UTF-8");

		OutputStream os = response.getOutputStream();
		WritableWorkbook wwb = Workbook.createWorkbook(os);
		WritableSheet sheet = wwb.createSheet("终端信息", 0);
		SheetSettings ss = sheet.getSettings();
		ss.setVerticalFreeze(1);// 冻结表头

		WritableCellFormat wcf = new WritableCellFormat();
		WritableCellFormat wcf2 = new WritableCellFormat();

		int flag = 0;
		int columnIndex = 0;
		List<String> methodNameList = new ArrayList<String>();

		if (mapField != null && mapField.size() > 0) {
			String key = "";
			// 循环写入表头
			for (Iterator<String> i = mapField.keySet().iterator(); i.hasNext();) {
				key = i.next();
				sheet.addCell(new Label(columnIndex, 0, mapField.get(key), wcf));
				methodNameList.add(key);
				columnIndex++;
			}
			// 判断表中是否有数据
			if (excelList != null && excelList.size() > 0) {
				// 循环写入表中数据
				for (int i = 0; i < excelList.size(); i++) {
					Map<String, Object> map = (Map<String, Object>) excelList.get(i);
					// 循环输出map中的子集：既列值
					int j = 0;
					for (Object o : map.keySet()) {
									
					//第一个参数为列坐标，第二个参数为行坐标，第三个参数为内容	
					sheet.addCell(new Label(0, i+1, String.valueOf(map.get("SHOPPERID")), wcf2));
					sheet.addCell(new Label(1, i+1, String.valueOf(map.get("SCOMPANY")), wcf2));
					sheet.addCell(new Label(2, i+1, String.valueOf(map.get("STEL")), wcf2));
					sheet.addCell(new Label(3, i+1, String.valueOf(map.get("AGENTNAME")), wcf2));
					sheet.addCell(new Label(4, i+1, String.valueOf(map.get("AGENTTEL")), wcf2));
					sheet.addCell(new Label(5, i+1, String.valueOf(map.get("PAGENTNAME")), wcf2));
					sheet.addCell(new Label(6, i+1, String.valueOf(map.get("PAGENTTEL")), wcf2));
					sheet.addCell(new Label(7, i+1, String.valueOf(map.get("TERM_NO")), wcf2));
					sheet.addCell(new Label(8, i+1, String.valueOf(map.get("CREATE_DATE")), wcf2));
					sheet.addCell(new Label(9, i+1, String.valueOf(map.get("FIRST")), wcf2));
					sheet.addCell(new Label(10, i+1, String.valueOf(map.get("LAST")), wcf2));
					
					}			
					
				}
			} else {
				flag = -1;
			}
			// 写入Exel工作表
			wwb.write();
			// 关闭Excel工作薄对象
			wwb.close();
			// 关闭流
			os.flush();
			os.close();
			os = null;
		}
	}
	
	
	
	
	/** 设备号解绑
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=deldevice")
    public 	String deldevice(HttpServletRequest request,HttpServletResponse response) throws Exception{
		String termNo=request.getParameter("termNo");
		B2cTempTermBinder tempbinder=this.deviceservice.selectterm(termNo);
		B2cTermBinder  binder=this.deviceservice.getDiveceNo(termNo);
		String last=tempbinder.getLastVerify();
		if(Constants.STATUS0.equals(last)||Constants.STATUS2.equals(last)){
			deviceservice.deltemp(termNo);
			request.setAttribute(Constants.MESSAGE_KEY,"解绑成功!");
		}else{
			HashMap hashmap=new HashMap();
			hashmap.put("termNo", termNo);
			Map resultMap=HttpClientUtils.postRequestMap(DynamicConfigLoader.getByEnv("deldevice.url"),hashmap,Map.class);
			JSONObject ob= JSONObject.fromObject(resultMap);
			String rspCode=(String)ob.get("returnCode");
			
			if(Constants.RESPONSE_CODE.equals(rspCode)){
				deviceservice.deldevice(termNo);
				request.setAttribute(Constants.MESSAGE_KEY,"解绑成功!");
			}else{
				request.setAttribute(Constants.MESSAGE_KEY,"解绑失败!");
			}
		}
		request.setAttribute("url","device.htm?method=recheckdeviceList");
		return "/returnPage";
	}
	
	
	

	
}
