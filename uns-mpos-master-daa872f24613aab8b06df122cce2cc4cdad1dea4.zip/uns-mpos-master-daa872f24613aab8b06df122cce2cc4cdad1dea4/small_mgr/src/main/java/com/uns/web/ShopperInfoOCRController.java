package com.uns.web;

import com.uns.common.Base64;
import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.ImageCompressUtil;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.dao.MposMerchantFeeMapper;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.model.*;
import com.uns.service.ShopPerbiService;
import com.uns.util.AESUtils;
import com.uns.util.AesEncrypt;
import com.uns.util.HttpClientUtils;
import com.uns.web.form.ShopPerbiForm;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * OCR商户信息
 */
@Controller("shopperInfoOCRController")
@RequestMapping("shopperInfoOCR.htm")
public class ShopperInfoOCRController extends BaseController {

    @Autowired
    ShopPerbiService shopPerbiService;
    
    /**
     * 查询商户预约列表
     *
     * @param request
     * @param modelMap
     * @param form
     * @return
     */
    @RequestMapping(params = "method=shopperTempList")
    @FormToken(save = true)
    public String shopperTempList(HttpServletRequest request, ModelMap modelMap, ShopPerbiForm form) throws BusinessException {
        try {
            //获取省
            List<Area> Provincial = shopPerbiService.searchProvince();
            request.setAttribute("Provincial", Provincial);
            //获取市
            List<Area> list = shopPerbiService.searchArea();
            request.setAttribute("area", list);
            //查询商户信息
            List<HashMap> shopperTempList = shopPerbiService.findShopperTempList(form);
            modelMap.put("shopperTempList", shopperTempList);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }
        return "shopperOCRnew/shopperTempList";
    }

    /**
     * 查询商户预约详情
     *
     * @param request
     * @param modelMap
     * @param mbForm
     * @return
     */
    @RequestMapping(params = "method=shopperTempDetails")
    public String shopperTempDetails(HttpServletRequest request, ModelMap modelMap, ShopPerbiForm mbForm) throws BusinessException {

        try {
            //获取shopperid
            String shopperid = mbForm.getShopperid();

            //更新人工检查状态
            shopPerbiService.updateVisualCheckStatus(shopperid, Constants.TYPE_1);
            
            Map shopperTemp = shopPerbiService.findShopperTempDetails(Long.valueOf(shopperid));

            // 获取证照信息
            if (null != shopperTemp.get("PHOTO_ID")) {
                Long photoid = ((BigDecimal) shopperTemp.get("PHOTO_ID")).longValue();
                MposPhotoTmp photo = shopPerbiService.selectPhotoTmpById(photoid);
                request.setAttribute("photo", photo);
                request.setAttribute("image_get_url", DynamicConfigLoader.getByEnv("imageget.url"));
            }

            //获取银行名称
            String bankDictval = (String) shopperTemp.get("ACCOUNT_BANK_DICTVAL");
            B2cDict bankInfo = null;
            String bankDictvalName = null;
            if (null != bankDictval) {
                bankInfo = shopPerbiService.findBankName(bankDictval);
                bankDictvalName = bankInfo.getDict();
                request.setAttribute("accountBankDictvalName", bankDictvalName);
            }
            bankDictval = (String) shopperTemp.get("CREDIT_BANK_DICTVAL");
            request.setAttribute("creditBankDictvalName", bankDictval);

            //获取费率信息
            // 手续费，临时表
            MposMerchantFee s0creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_CREDIT, Constants.S0_CHANNEL_TYPE);
            MposMerchantFee s0debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_DEBIT, Constants.S0_CHANNEL_TYPE);

            MposMerchantFee d0creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_CREDIT, Constants.D0_CHANNEL_TYPE);
            MposMerchantFee d0debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_DEBIT, Constants.D0_CHANNEL_TYPE);

            MposMerchantFee t1creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_CREDIT, Constants.T1_CHANNEL_TYPE);
            MposMerchantFee t1debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_DEBIT, Constants.T1_CHANNEL_TYPE);

            MposMerchantFee weChatMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_WECHAT);
            MposMerchantFee alipayMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_ALIPAY);
            MposMerchantFee ylpayMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_YLPAY);

            MposMerchantFee shortCutMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_SHORTCUT);//快捷汇率
            MposMerchantFee shortCutSHMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_SHD0);//速惠汇率
            MposMerchantFee b2cMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_B2C);//B2C汇率

            request.setAttribute("shortCutSHMerchantFeeTemp", shortCutSHMerchantFeeTemp);
            request.setAttribute("shortCutMerchantFeeTemp", shortCutMerchantFeeTemp);
            request.setAttribute("b2cMerchantFeeTemp", b2cMerchantFeeTemp);

            request.setAttribute("s0creditMerchantFeeTemp", s0creditMerchantFeeTemp);
            request.setAttribute("s0debitMerchantFeeTemp", s0debitMerchantFeeTemp);

            request.setAttribute("d0creditMerchantFeeTemp", d0creditMerchantFeeTemp);
            request.setAttribute("d0debitMerchantFeeTemp", d0debitMerchantFeeTemp);

            request.setAttribute("t1creditMerchantFeeTemp", t1creditMerchantFeeTemp);
            request.setAttribute("t1debitMerchantFeeTemp", t1debitMerchantFeeTemp);

            request.setAttribute("weChatMerchantFeeTemp", weChatMerchantFeeTemp);
            request.setAttribute("alipayMerchantFeeTemp", alipayMerchantFeeTemp);
            request.setAttribute("ylpayMerchantFeeTemp", ylpayMerchantFeeTemp);

            //获取手续费正式表
            MposMerchantFee s0creditMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_CREDIT, Constants.S0_CHANNEL_TYPE);
            MposMerchantFee s0debitMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_DEBIT, Constants.S0_CHANNEL_TYPE);

            MposMerchantFee d0creditMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_CREDIT, Constants.D0_CHANNEL_TYPE);
            MposMerchantFee d0debitMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_DEBIT, Constants.D0_CHANNEL_TYPE);

            MposMerchantFee t1creditMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_CREDIT, Constants.T1_CHANNEL_TYPE);
            MposMerchantFee t1debitMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_DEBIT, Constants.T1_CHANNEL_TYPE);

            MposMerchantFee weChatMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_WECHAT);
            MposMerchantFee alipayMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_ALIPAY);
            MposMerchantFee ylpayMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_YLPAY);

            MposMerchantFee shortCutMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_SHORTCUT);//快捷汇率
            MposMerchantFee shortCutSHMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_SHD0);//速惠汇率
            MposMerchantFee b2cMerchantFee = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_B2C);//B2C汇率

            request.setAttribute("shortCutSHMerchantFee", shortCutSHMerchantFee);
            request.setAttribute("shortCutMerchantFee", shortCutMerchantFee);
            request.setAttribute("b2cMerchantFee", b2cMerchantFee);

            request.setAttribute("s0creditMerchantFee", s0creditMerchantFee);
            request.setAttribute("s0debitMerchantFee", s0debitMerchantFee);

            request.setAttribute("d0creditMerchantFee", d0creditMerchantFee);
            request.setAttribute("d0debitMerchantFee", d0debitMerchantFee);

            request.setAttribute("t1creditMerchantFee", t1creditMerchantFee);
            request.setAttribute("t1debitMerchantFee", t1debitMerchantFee);

            request.setAttribute("weChatMerchantFee", weChatMerchantFee);
            request.setAttribute("alipayMerchantFee", alipayMerchantFee);
            request.setAttribute("ylpayMerchantFee", ylpayMerchantFee);
            //分润
            String merchProfitRatio2 = (String) shopperTemp.get("MERCH_PROFIT_RATIO2");
            String merchProfitRatio3 = (String) shopperTemp.get("MERCH_PROFIT_RATIO3");
            if (null != merchProfitRatio2 && null != merchProfitRatio3) {
                //分润方案2
                String[] split2 = merchProfitRatio2.split("\\|");
                //分润方案3
                String[] split3 = merchProfitRatio3.split("\\|");
                request.setAttribute("split2", split2);
                request.setAttribute("split3", split3);
            }


            request.setAttribute("shopper", shopperTemp);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }

        return "shopperOCRnew/shopperTempDetails";
    }

    /**
     * 商户预约详情修改
     *
     * @param request
     * @param modelMap
     * @param mbForm
     * @return
     */
    @RequestMapping(params = "method=shopperTempEditDetails")
    @FormToken(save = true)
    public String shopperTempEditDetails(HttpServletRequest request, ModelMap modelMap, ShopPerbiForm mbForm) throws BusinessException {

        try {
            //获取shopperid
            String shopperid = mbForm.getShopperid();
            Map shopperTemp = shopPerbiService.findShopperTempDetails(Long.valueOf(shopperid));

            // 获取证照信息
            if (null != shopperTemp.get("PHOTO_ID")) {
                Long photoid = ((BigDecimal) shopperTemp.get("PHOTO_ID")).longValue();
                MposPhotoTmp photo = shopPerbiService.selectPhotoTmpById(photoid);
                request.setAttribute("photo", photo);
                request.setAttribute("image_get_url", DynamicConfigLoader.getByEnv("imageget.url"));
            }

            // 获取银行
            List<B2cDict> dicbank = shopPerbiService.searchBank();
            request.setAttribute("bank", dicbank);

            //获取银行名称
            String bankDictval = (String) shopperTemp.get("CREDIT_BANK_DICTVAL");
            request.setAttribute("creditBankDictvalName", bankDictval);

            // 行业类型
            List<B2cDict> industryList = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
            request.setAttribute("industryList", industryList);

            //费率下拉框
            List<AgentTopFee> d0creditCardFee = shopPerbiService.findAgentFeeByType(Constants.FEE_TYPE_DEBIT);
            List<AgentTopFee> d0debitCardFee = shopPerbiService.findAgentFeeByType(Constants.FEE_TYPE_CREDIT);

            List<AgentTopFee> s0creditCardFee = shopPerbiService.findAgentFeeByType(Constants.S0_FEE_TYPE_DEBIT);
            List<AgentTopFee> s0debitCardFee = shopPerbiService.findAgentFeeByType(Constants.S0_FEE_TYPE_CREDIT);

            List<AgentTopFee> t1creditCardFee = shopPerbiService.findAgentFeeByType(Constants.T1_FEE_TYPE_DEBIT);
            List<AgentTopFee> t1debitCardFee = shopPerbiService.findAgentFeeByType(Constants.T1_FEE_TYPE_CREDIT);

            List<AgentTopFee> weChatFee = shopPerbiService.findAgentFeeByType(Constants.FEE_TYPE_WECHAT);
            List<AgentTopFee> alipayFee = shopPerbiService.findAgentFeeByType(Constants.FEE_TYPE_ALIPAY);
            List<AgentTopFee> ylpayFee = shopPerbiService.findAgentFeeByType(Constants.FEE_TYPE_YLPAY);

            List<AgentTopFee> shortCut = shopPerbiService.findAgentFeeByType(Constants.AGENT_TYPE_SHORTCUT);//查询字典表9
            List<AgentTopFee> b2c = shopPerbiService.findAgentFeeByType(Constants.AGENT_TYPE_B2C);//查询字典表10
            List<AgentTopFee> shortCutSH = shopPerbiService.findAgentFeeByType(Constants.AGENT_TYPE_SHORTCUTSH);//查询字典表9

            request.setAttribute("d0creditCardFee", d0creditCardFee);
            request.setAttribute("d0debitCardFee", d0debitCardFee);
            request.setAttribute("s0creditCardFee", s0creditCardFee);
            request.setAttribute("s0debitCardFee", s0debitCardFee);
            request.setAttribute("t1creditCardFee", t1creditCardFee);
            request.setAttribute("t1debitCardFee", t1debitCardFee);
            request.setAttribute("weChatFee", weChatFee);
            request.setAttribute("alipayFee", alipayFee);
            request.setAttribute("ylpayFee", ylpayFee);
            request.setAttribute("shortCut", shortCut);
            request.setAttribute("b2c", b2c);
            request.setAttribute("shortCutSH", shortCutSH);

            //判断预约表有没有信息
            List<MposMerchantFee> feeList = shopPerbiService.findtempbyshopperid(shopperid);

            MposMerchantFee s0creditMerchantFeeTemp;
            MposMerchantFee s0debitMerchantFeeTemp;
            MposMerchantFee d0creditMerchantFeeTemp;
            MposMerchantFee d0debitMerchantFeeTemp;
            MposMerchantFee t1creditMerchantFeeTemp;
            MposMerchantFee t1debitMerchantFeeTemp;
            MposMerchantFee weChatMerchantFeeTemp;
            MposMerchantFee alipayMerchantFeeTemp;
            MposMerchantFee ylpayMerchantFeeTemp;
            MposMerchantFee shortCutMerchantFeeTemp;
            MposMerchantFee shortCutSHMerchantFeeTemp;
            MposMerchantFee b2cMerchantFeeTemp;
            if(null != feeList && feeList.size() > 0){
                //获取手续费预约信息
                s0creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_CREDIT, Constants.S0_CHANNEL_TYPE);
                s0debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_DEBIT, Constants.S0_CHANNEL_TYPE);

                d0creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_CREDIT, Constants.D0_CHANNEL_TYPE);
                d0debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_DEBIT, Constants.D0_CHANNEL_TYPE);

                t1creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_CREDIT, Constants.T1_CHANNEL_TYPE);
                t1debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperid, Constants.FEE_TYPE_DEBIT, Constants.T1_CHANNEL_TYPE);

                weChatMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_WECHAT);
                alipayMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_ALIPAY);
                ylpayMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_YLPAY);

                shortCutMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_SHORTCUT);//快捷汇率
                shortCutSHMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_SHD0);//速惠汇率
                b2cMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperid, Constants.FEE_TYPE_B2C);//B2C汇率
            }else{
                //获取手续费正式表
                s0creditMerchantFeeTemp = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_CREDIT, Constants.S0_CHANNEL_TYPE);
                s0debitMerchantFeeTemp = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_DEBIT, Constants.S0_CHANNEL_TYPE);

                d0creditMerchantFeeTemp = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_CREDIT, Constants.D0_CHANNEL_TYPE);
                d0debitMerchantFeeTemp = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_DEBIT, Constants.D0_CHANNEL_TYPE);

                t1creditMerchantFeeTemp = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_CREDIT, Constants.T1_CHANNEL_TYPE);
                t1debitMerchantFeeTemp = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_DEBIT, Constants.T1_CHANNEL_TYPE);

                weChatMerchantFeeTemp = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_WECHAT);
                alipayMerchantFeeTemp = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_ALIPAY);
                ylpayMerchantFeeTemp = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_YLPAY);

                shortCutMerchantFeeTemp = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_SHORTCUT);//快捷汇率
                shortCutSHMerchantFeeTemp = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_SHD0);//速惠汇率
                b2cMerchantFeeTemp = shopPerbiService.findMposMerchantFee(shopperid, Constants.FEE_TYPE_B2C);//B2C汇率
            }

            request.setAttribute("shortCutSHMerchantFeeTemp", shortCutSHMerchantFeeTemp);
            request.setAttribute("shortCutMerchantFeeTemp", shortCutMerchantFeeTemp);
            request.setAttribute("b2cMerchantFeeTemp", b2cMerchantFeeTemp);

            request.setAttribute("s0creditMerchantFeeTemp", s0creditMerchantFeeTemp);
            request.setAttribute("s0debitMerchantFeeTemp", s0debitMerchantFeeTemp);

            request.setAttribute("d0creditMerchantFeeTemp", d0creditMerchantFeeTemp);
            request.setAttribute("d0debitMerchantFeeTemp", d0debitMerchantFeeTemp);

            request.setAttribute("t1creditMerchantFeeTemp", t1creditMerchantFeeTemp);
            request.setAttribute("t1debitMerchantFeeTemp", t1debitMerchantFeeTemp);

            request.setAttribute("weChatMerchantFeeTemp", weChatMerchantFeeTemp);
            request.setAttribute("alipayMerchantFeeTemp", alipayMerchantFeeTemp);
            request.setAttribute("ylpayMerchantFeeTemp", ylpayMerchantFeeTemp);

            //分润
            String merchProfitRatio2 = (String) shopperTemp.get("MERCH_PROFIT_RATIO2");
            String merchProfitRatio3 = (String) shopperTemp.get("MERCH_PROFIT_RATIO3");
            if (null != merchProfitRatio2 && null != merchProfitRatio3) {
                //分润方案2
                String[] split2 = merchProfitRatio2.split("\\|");
                //分润方案3
                String[] split3 = merchProfitRatio3.split("\\|");
                request.setAttribute("split2", split2);
                request.setAttribute("split3", split3);
            }

            // 获取省
            List<Area> provinceList = shopPerbiService.searchProvince();
            request.setAttribute("provinceList", provinceList);
            // 获取地区
            List<Area> areaList = shopPerbiService.searchArea();
            request.setAttribute("areaList", areaList);

            request.setAttribute("shopper", shopperTemp);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }

        return "shopperOCRnew/shopperTempEditDetails";
    }

    /**
     * 保存商户信息修改
     *
     * @param request
     * @param shopper
     * @param mbForm
     * @return
     * @throws BusinessException
     */
    @RequestMapping(params = "method=saveShopperTempEdit")
    @FormToken(save = true)
    public String saveShopperTempEdit(HttpServletRequest request, B2cShopperbiTemp shopper, ShopPerbiForm mbForm) throws BusinessException {
        String shopperid = null;
        BackupsShopperInformation backupShopper = null;
        Operator user = null;
        try {
            shopperid = String.valueOf(shopper.getShopperid());
            B2cShopperbiTemp b2cShopperbiTemp = shopPerbiService.queryShopPerbi(shopperid);

            //设置商户备份
            backupShopper = new BackupsShopperInformation();
            shopPerbiService.setBackupShopperInfo(request, b2cShopperbiTemp, backupShopper);

            //设置商户基本信息
            shopPerbiService.setShopperTempBaseInfo(shopper, mbForm);

            //商户费率修改
            MposMerchantFee s0creditMerchantFeeM = new MposMerchantFee();//贷记卡
            MposMerchantFee s0debitMerchantFeeM = new MposMerchantFee();//借记卡

            MposMerchantFee d0creditMerchantFeeM = new MposMerchantFee();
            MposMerchantFee d0debitMerchantFeeM = new MposMerchantFee();

            MposMerchantFee t1creditMerchantFeeM = new MposMerchantFee();
            MposMerchantFee t1debitMerchantFeeM = new MposMerchantFee();

            MposMerchantFee weChatMerchantFeeM = new MposMerchantFee();
            MposMerchantFee alipayMerchantFeeM = new MposMerchantFee();
            MposMerchantFee ylpayMerchantFeeM = new MposMerchantFee();
            MposMerchantFee shortCutMerchantFeeM = new MposMerchantFee();
            MposMerchantFee b2cMerchantFeeM = new MposMerchantFee();
            MposMerchantFee shortCutSHMerchantFeeM = new MposMerchantFee();

            // 费率信息处理.如果信息汇率修改了那么久是新对象有值了用于明细修改作用
            Map<String, Object> feeMap = updateshopPerbiFee(shopper, mbForm,
                    s0debitMerchantFeeM, s0creditMerchantFeeM, d0debitMerchantFeeM, d0creditMerchantFeeM, t1debitMerchantFeeM,
                    t1creditMerchantFeeM, weChatMerchantFeeM, alipayMerchantFeeM, ylpayMerchantFeeM, shortCutMerchantFeeM,
                    b2cMerchantFeeM, shortCutSHMerchantFeeM);


            // 基本信息的修改记录
            B2cShopperbiTempModify shopperbiTempModify = getBaseInfoModify(b2cShopperbiTemp, shopper);

            //费率信息的修改记录
            if (s0creditMerchantFeeM.getFee() != null)
                shopperbiTempModify.setS0creditFee(s0creditMerchantFeeM.getFee());
            if (s0debitMerchantFeeM.getFee() != null)
                shopperbiTempModify.setS0debitFee(s0debitMerchantFeeM.getFee());

            if (d0creditMerchantFeeM.getFee() != null)
                shopperbiTempModify.setD0creditFee(d0creditMerchantFeeM.getFee());
            if (d0debitMerchantFeeM.getFee() != null)
                shopperbiTempModify.setD0debitFee(d0debitMerchantFeeM.getFee());

            if (t1creditMerchantFeeM.getFee() != null)
                shopperbiTempModify.setT1creditFee(t1creditMerchantFeeM.getFee());
            if (t1debitMerchantFeeM.getFee() != null)
                shopperbiTempModify.setT1debitFee(t1debitMerchantFeeM.getFee());

            if (weChatMerchantFeeM.getFee() != null)
                shopperbiTempModify.setWeChatFee(weChatMerchantFeeM.getFee());
            if (weChatMerchantFeeM.getD0Fee() != null)
                shopperbiTempModify.setWeChatD0Fee(weChatMerchantFeeM.getD0Fee());
            if (alipayMerchantFeeM.getFee() != null)
                shopperbiTempModify.setAlipayFee(alipayMerchantFeeM.getFee());
            if (alipayMerchantFeeM.getD0Fee() != null)
                shopperbiTempModify.setAlipayD0Fee(alipayMerchantFeeM.getD0Fee());
            if (ylpayMerchantFeeM.getFee() != null)
                shopperbiTempModify.setYlpayFee(ylpayMerchantFeeM.getFee());
            if (shortCutMerchantFeeM.getFee() != null)
                shopperbiTempModify.setShortCutFee(shortCutMerchantFeeM.getFee());
            if (shortCutMerchantFeeM.getD0Fee() != null)
                shopperbiTempModify.setShortCutDoFee(shortCutMerchantFeeM.getD0Fee());
            if (b2cMerchantFeeM.getFee() != null)
                shopperbiTempModify.setB2cFee(b2cMerchantFeeM.getFee());
            if (b2cMerchantFeeM.getD0Fee() != null)
                shopperbiTempModify.setB2cDoFee(b2cMerchantFeeM.getD0Fee());
            if (shortCutSHMerchantFeeM.getD0Fee() != null) {
                shopperbiTempModify.setShortCutSHDoFee(shortCutSHMerchantFeeM.getD0Fee());
            }

            shopperbiTempModify.setB2cShopperbiId(Long.parseLong(shopperid));

            Map<String, String> param = new HashMap<String, String>();
            param.put("shopperID", shopperid);
            List<B2cShopperbiTempModify> list = shopPerbiService.findModifyByShopperbiIdList(param);
            user = (Operator) request.getSession().getAttribute("sessionUser");
            //如果没有修改过（添加创建时间、更新时间）
            if (null == list || list.size() == 0) {
                shopperbiTempModify.setModifyDetailCreateDate(new Date());
                shopperbiTempModify.setModifyDetailUpdateDate(new Date());
            }
            shopperbiTempModify.setModifyDetailUpdateDate(new Date());
            shopperbiTempModify.setModifyDetailUpdateUser(user.getUserName());

            MposApplicationProgress pro = new MposApplicationProgress();

            // 照片上传，返回存放Image表中图片uuid的Map
            shopper.setPhotoid(b2cShopperbiTemp.getPhotoid());
            shopper.setIDNo(b2cShopperbiTemp.getIDNo());
            Map maphoto = saveShopPerbiPhotoUpdate(request, shopper, mbForm, shopperbiTempModify, pro);


            //获取方案分润百分比
            String merchRatio1 = mbForm.getMerchRatio1();
            String merchRatio21 = mbForm.getMerchRatio2_1();
            String merchRatio22 = mbForm.getMerchRatio2_2();
            String merchRatio31 = mbForm.getMerchRatio3_1();
            String merchRatio32 = mbForm.getMerchRatio3_2();
            String merchRatio33 = mbForm.getMerchRatio3_3();
            shopper.setMerchProfitRatio1(merchRatio1);//方案1
            shopper.setMerchProfitRatio2(merchRatio21 + "|" + merchRatio22);//方案2
            shopper.setMerchProfitRatio3(merchRatio31 + "|" + merchRatio32 + "|" + merchRatio33);//方案3
            
            // 保存的方法
            shopPerbiService.saveShopPerbiUpdate(shopperbiTempModify, shopper, backupShopper, maphoto, pro, feeMap);

            request.setAttribute(Constants.MESSAGE_KEY, "修改成功!");
            request.setAttribute(Constants.URL_KEY, "shopperInfoOCR.htm?method=shopperTempList");
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.保存商户修改信息失败);
        }
        return "/returnPage";
    }

    /**
     * 保存商户证照变更
     *
     * @param request
     * @param b2cShopperbi
     * @param mbForm
     * @throws BusinessException
     */
    private Map saveShopPerbiPhotoUpdate(HttpServletRequest request, B2cShopperbiTemp b2cShopperbi, ShopPerbiForm mbForm,
                                         B2cShopperbiTempModify shopperbiTempModify, MposApplicationProgress pro) throws Exception {
        Map hashmap = new HashMap();
        Map maphoto = new HashMap();
        JSONObject ob = null;
        try {
            Long photoid = b2cShopperbi.getPhotoid();
            if (null != photoid) {
                hashmap.put("photoid", photoid.toString());
            }
            hashmap.put("identityId", AesEncrypt.encryptAES(b2cShopperbi.getIDNo() == null ? "" : b2cShopperbi.getIDNo().toUpperCase(), Constants.APP_AES_KEY));
            String shopperType = b2cShopperbi.getMerchantType();//个人或者企业

            String uploadpath = request.getSession().getServletContext().getRealPath("/");
            String uploadpath1 = uploadpath + "image1.jpg";
            String uploadpath2 = uploadpath + "image2.jpg";
            String uploadpath3 = uploadpath + "image3.jpg";
            String uploadpath4 = uploadpath + "image4.jpg";
            String uploadpath5 = uploadpath + "image5.jpg";
            String uploadpath6 = uploadpath + "image6.jpg";
            String uploadpath7 = uploadpath + "image7.jpg";
            String uploadpath8 = uploadpath + "image8.jpg";
            String uploadpath9 = uploadpath + "image9.jpg";
            //活体
            String uploadpath10 = uploadpath + "image10.jpg";
            String uploadpath11 = uploadpath + "image11.jpg";
            String uploadpath12 = uploadpath + "image12.jpg";
            String uploadpath13 = uploadpath + "image13.jpg";
            String uploadpath14 = uploadpath + "image14.jpg";//大头贴
            String uploadpath15 = uploadpath + "image14.jpg";//结算卡
            
            InputStream input1 = mbForm.getHandidentitycardphoto()
                    .getInputStream();
            int inputsize1 = inputsize(input1);

            if (inputsize1 != Constants.INT_0) {
                ImageCompressUtil.saveMinPhoto(input1, uploadpath1, Constants.COM_BASE, Constants.SCALE);//压缩传来的图片
                InputStream input11 = new FileInputStream(uploadpath1);//获取图片的输入流
                String handIdentityCardPhoto = photoString(input11);//从输入流获取Base64编码字符串
                //编码后的图片加入hashMap（get方式传值加号被当成空格，所以用'%2B'替代）
                hashmap.put("handIdentityCardPhoto", handIdentityCardPhoto.replace("+", "%2B"));
            }

            InputStream input2 = mbForm.getFrontidentitycardphoto()
                    .getInputStream();
            int inputsize2 = inputsize(input2);
            if (inputsize2 != Constants.INT_0) {
                ImageCompressUtil.saveMinPhoto(input2, uploadpath2, Constants.COM_BASE, Constants.SCALE);
                InputStream input22 = new FileInputStream(uploadpath2);
                String frontIdentityCardPhoto = photoString(input22);
                hashmap.put("frontIdentityCardPhoto", frontIdentityCardPhoto.replace("+", "%2B"));
            }

            InputStream input3 = mbForm.getReverseidentitycardphoto()
                    .getInputStream();
            int inputsize3 = inputsize(input3);
            if (inputsize3 != Constants.INT_0) {
                ImageCompressUtil.saveMinPhoto(input3, uploadpath3, Constants.COM_BASE, Constants.SCALE);
                InputStream input33 = new FileInputStream(uploadpath3);
                String reverseIdentityCardPhoto = photoString(input33);
                hashmap.put("reverseIdentityCardPhoto", reverseIdentityCardPhoto.replace("+", "%2B"));
            }

            InputStream input7 = mbForm.getSignaturephoto().getInputStream();
            int inputsize7 = inputsize(input7);
            if (inputsize7 != Constants.INT_0) {
                ImageCompressUtil.saveMinPhoto(input7, uploadpath5, Constants.COM_BASE, Constants.SCALE);
                InputStream input77 = new FileInputStream(uploadpath5);
                String signaturePhoto = photoString(input77);
                hashmap.put("signaturePhoto", signaturePhoto.replace("+", "%2B"));
            }

            InputStream input9 = mbForm.getCreditCardPhoto().getInputStream();
            int inputsize9 = inputsize(input9);
            if (inputsize9 != Constants.INT_0) {
                ImageCompressUtil.saveMinPhoto(input9, uploadpath6, Constants.COM_BASE, Constants.SCALE);
                InputStream input99 = new FileInputStream(uploadpath6);
                String creditCardPhoto = photoString(input99);
                hashmap.put("creditCardPhoto", creditCardPhoto.replace("+", "%2B"));
            }

            InputStream input11 = mbForm.getFixPhoto()
                    .getInputStream();
            int inputsize11 = inputsize(input11);
            if (inputsize11 != Constants.INT_0) {
                ImageCompressUtil.saveMinPhoto(input11, uploadpath9, Constants.COM_BASE, Constants.SCALE);
                InputStream input1111 = new FileInputStream(uploadpath9);
                String fixPhoto = photoString(input1111);
                hashmap.put("fixPhoto", fixPhoto.replace("+", "%2B"));
            }

            //活体
            InputStream input12 = mbForm.getLivingbodyFacePhoto()
                    .getInputStream();
            int inputsize12 = inputsize(input12);
            if (inputsize12 != Constants.INT_0) {
                ImageCompressUtil.saveMinPhoto(input12, uploadpath10, Constants.COM_BASE, Constants.SCALE);
                InputStream input1212 = new FileInputStream(uploadpath10);
                String livingbodyFacePhoto = photoString(input1212);
                hashmap.put("livingbodyFacePhoto", livingbodyFacePhoto.replace("+", "%2B"));
            }

            InputStream input13 = mbForm.getLivingbodyLeftPhoto()
                    .getInputStream();
            int inputsize13 = inputsize(input13);
            if (inputsize13 != Constants.INT_0) {
                ImageCompressUtil.saveMinPhoto(input13, uploadpath11, Constants.COM_BASE, Constants.SCALE);
                InputStream input1313 = new FileInputStream(uploadpath11);
                String livingbodyLeftPhoto = photoString(input1313);
                hashmap.put("livingbodyLeftPhoto", livingbodyLeftPhoto.replace("+", "%2B"));
            }

            InputStream input14 = mbForm.getLivingbodyRightPhoto()
                    .getInputStream();
            int inputsize14 = inputsize(input14);
            if (inputsize14 != Constants.INT_0) {
                ImageCompressUtil.saveMinPhoto(input14, uploadpath12, Constants.COM_BASE, Constants.SCALE);
                InputStream input1414 = new FileInputStream(uploadpath12);
                String livingbodyRightPhoto = photoString(input1414);
                hashmap.put("livingbodyRightPhoto", livingbodyRightPhoto.replace("+", "%2B"));
            }

            InputStream input15 = mbForm.getLivingbodyReturnPhoto()
                    .getInputStream();
            int inputsize15 = inputsize(input15);
            if (inputsize15 != Constants.INT_0) {
                ImageCompressUtil.saveMinPhoto(input15, uploadpath13, Constants.COM_BASE, Constants.SCALE);
                InputStream input1515 = new FileInputStream(uploadpath13);
                String livingbodyReturnPhoto = photoString(input1515);
                hashmap.put("livingbodyReturnPhoto", livingbodyReturnPhoto.replace("+", "%2B"));
            }

            //大头贴
            InputStream input16 = mbForm.getIdCardHeadPhoto()
                    .getInputStream();
            int inputsize16 = inputsize(input16);
            if (inputsize16 != Constants.INT_0) {
                ImageCompressUtil.saveMinPhoto(input16, uploadpath14, Constants.COM_BASE, Constants.SCALE);
                InputStream input1616 = new FileInputStream(uploadpath14);
                String idCardHeadPhoto = photoString(input1616);
                hashmap.put("idCardHeadPhoto", idCardHeadPhoto.replace("+", "%2B"));
            }

            //结算卡
            InputStream input17 = mbForm.getSettlementCardPhoto()
                    .getInputStream();
            int inputsize17 = inputsize(input17);
            if (inputsize17 != Constants.INT_0) {
                ImageCompressUtil.saveMinPhoto(input17, uploadpath15, Constants.COM_BASE, Constants.SCALE);
                InputStream input1717 = new FileInputStream(uploadpath15);
                String settlementCardPhoto = photoString(input1717);
                hashmap.put("settlementCardPhoto", settlementCardPhoto.replace("+", "%2B"));
            }

            hashmap.put("shopperType", shopperType);
            Map resultMap = HttpClientUtils.postRequestMap(ConstantsEnv.UPDATEPHOTO, hashmap, Map.class);

            // 返回值得到photo
            ob = JSONObject.fromObject(resultMap);
            maphoto = (Map) ob.get("maphoto");
            // 给modify值
            if (null != maphoto) {
                String s1 = (String) maphoto.get("signaturePhoto");
                String s2 = (String) maphoto.get("handIdentityCardPhoto");
                String s3 = (String) maphoto.get("frontIdentityCardPhoto");
                String s4 = (String) maphoto.get("reverseIdentityCardPhoto");
                String s5 = (String) maphoto.get("storePhoto");
                String s6 = (String) maphoto.get("creditCardPhoto");
                String s7 = (String) maphoto.get("settlementCardPhoto");
                String s8 = (String) maphoto.get("licensePhoto");
                String s9 = (String) maphoto.get("livingbodyFacePhoto");
                String s10 = (String) maphoto.get("livingbodyLeftPhoto");
                String s11 = (String) maphoto.get("livingbodyRightPhoto");
                String s12 = (String) maphoto.get("livingbodyReturnPhoto");
                String s13 = (String) maphoto.get("idCardHeadPhoto");

                if (s1 != null) {
                    shopperbiTempModify.setSignaturePhoto(s1);
                }
                if (s2 != null) {
                    shopperbiTempModify.setHandIdentityCardPhoto(s2);
                }
                if (s3 != null) {
                    shopperbiTempModify.setFrontIdentityCardPhoto(s3);
                }
                if (s4 != null) {
                    shopperbiTempModify.setReverseIdentityCardPhoto(s4);
                }
                if (s5 != null) {
                    shopperbiTempModify.setStorePhoto(s5);
                }
                if (s6 != null) {
                    shopperbiTempModify.setCreditCardPhoto(s6);
                }
                if (s7 != null) {
                    shopperbiTempModify.setSettlementCardPhoto(s7);
                }
                if (s8 != null) {
                    shopperbiTempModify.setLicensePhoto(s8);
                }
                //活体
                if (s9 != null) {
                    shopperbiTempModify.setLivingbodyFacePhoto(s9);
                }
                if (s10 != null) {
                    shopperbiTempModify.setLivingbodyLeftPhoto(s10);
                }
                if (s11 != null) {
                    shopperbiTempModify.setLivingbodyRightPhoto(s11);
                }
                if (s12 != null) {
                    shopperbiTempModify.setLivingbodyReturnPhoto(s12);
                }
                //大头贴
                if (s13 != null) {
                    shopperbiTempModify.setIdCardHeadPhoto(s13);
                }
            }
            // 插入图片，插入一条进度记录
            MposApplicationProgress ap = this.shopPerbiService.findMposApplicationProgress(b2cShopperbi.getShopperid().toString(), Constants.TYPE_5);
            if (ap == null) {
                pro.setShopperid(mbForm.getShopperid());
                pro.setScompany(b2cShopperbi.getScompany());
                pro.setApplicationTheme(Constants.APPLICATIONTHEME变更证照);
                pro.setApplicationType(Constants.TYPE_5);
                pro.setCreateUser(((Operator) request.getSession().getAttribute(Constants.SESSION_KEY_USER)).getId());
                pro.setCreateDate(new Date());
                if (null != mbForm.getShopperid_p()) {
                    pro.setShopperidP(mbForm.getShopperid_p().toString());
                    pro.setAgentName(shopPerbiService.searchAgent(Long.valueOf(mbForm.getShopperid_p())).getScompany());
                }

                pro.setApplicationStatus(Constants.TYPE_1);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.保存商户修改信息失败);
        }
        return maphoto;
    }

    private String photoString(InputStream input1) throws IOException {
        byte[] data = null;
        // 读取图片字节数组
        try {
            data = new byte[input1.available()];
            input1.read(data);
            input1.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        String ss = Base64.encode(data);
        return ss;
    }

    private int inputsize(InputStream input1) throws Exception {
        byte[] by = new byte[1000];
        /*inputstream.available()方法返回的值是该inputstream在不被阻塞的情况下一次可以读取到的数据长度。
            如果数据还没有传输过来，那么这个inputstream势必会被阻塞，从而导致inputstream.available返回0。*/
        int size = input1.available();
        if (size == 0) {
            log.info("文件为空!!");
            return size;
        }
        return 1;
    }

    /**
     * 获取基本信息修改记录
     *
     * @param shopperbiTempOld
     * @param shopperbiTempNew
     * @return
     */
    private B2cShopperbiTempModify getBaseInfoModify(B2cShopperbiTemp shopperbiTempOld, B2cShopperbiTemp shopperbiTempNew) {

        //更改实体
        B2cShopperbiTempModify shopperbiTempModify = new B2cShopperbiTempModify();

        if (null != shopperbiTempOld.getScompany() && !shopperbiTempOld.getScompany().equals(shopperbiTempNew.getScompany())) {
            shopperbiTempModify.setScompany(shopperbiTempNew.getScompany());
        }
        if (null != shopperbiTempOld.getProvince() && !shopperbiTempOld.getProvince().equals(shopperbiTempNew.getProvince())) {
            shopperbiTempModify.setProvince(shopperbiTempNew.getProvince());
        }
        if (null != shopperbiTempOld.getCity() && !shopperbiTempOld.getCity().equals(shopperbiTempNew.getCity())) {
            shopperbiTempModify.setCity(shopperbiTempNew.getCity());
        }
        if (null != shopperbiTempOld.getScity() && !shopperbiTempOld.getScity().equals(shopperbiTempNew.getScity())) {
            shopperbiTempModify.setScity(shopperbiTempNew.getScity());
        }
        if (null != shopperbiTempOld.getSaddress() && !shopperbiTempOld.getSaddress().equals(shopperbiTempNew.getSaddress())) {
            shopperbiTempModify.setSaddress(shopperbiTempNew.getSaddress());
        }
        if (null != shopperbiTempOld.getStel() && !shopperbiTempOld.getStel().equals(shopperbiTempNew.getStel())) {
            shopperbiTempModify.setStel(shopperbiTempNew.getStel());
        }
        if ((null != shopperbiTempOld.getShopperidP() && !shopperbiTempOld.getShopperidP().equals(shopperbiTempNew.getShopperidP()))
                || null == shopperbiTempOld.getShopperidP()) {
            shopperbiTempModify.setShopperidP(shopperbiTempNew.getShopperidP());
        }
        if (null != shopperbiTempOld.getIndustry() && !shopperbiTempOld.getIndustry().equals(shopperbiTempNew.getIndustry())) {
            shopperbiTempModify.setIndustry(shopperbiTempNew.getIndustry());
        }
        if (null != shopperbiTempOld.getBillProvinceCode() && !shopperbiTempOld.getBillProvinceCode().equals(shopperbiTempNew.getBillProvinceCode())) {
            shopperbiTempModify.setBillProvinceCode(shopperbiTempNew.getBillProvinceCode());
        }
        if (null != shopperbiTempOld.getBillCityCode() && !shopperbiTempOld.getBillCityCode().equals(shopperbiTempNew.getBillCityCode())) {
            shopperbiTempModify.setBillCityCode(shopperbiTempNew.getBillCityCode());
        }
        if (null != shopperbiTempOld.getBillProvince() && !shopperbiTempOld.getBillProvince().equals(shopperbiTempNew.getBillProvince())) {
            shopperbiTempModify.setBillProvince(shopperbiTempNew.getBillProvince());
        }
        if (null != shopperbiTempOld.getBillCity() && !shopperbiTempOld.getBillCity().equals(shopperbiTempNew.getBillCity())) {
            shopperbiTempModify.setBillCity(shopperbiTempNew.getBillCity());
        }
        if (null != shopperbiTempOld.getBillAddress() && !shopperbiTempOld.getBillAddress().equals(shopperbiTempNew.getBillAddress())) {
            shopperbiTempModify.setBillAddress(shopperbiTempNew.getBillAddress());
        }
        if (null != shopperbiTempOld.getAccountbankclientname() && !shopperbiTempOld.getAccountbankclientname().equals(shopperbiTempNew.getAccountbankclientname())) {
            shopperbiTempModify.setAccountBankClientName(shopperbiTempNew.getAccountbankclientname());
        }
        if (null != shopperbiTempOld.getAccountbankno() && !shopperbiTempOld.getAccountbankno().equals(shopperbiTempNew.getAccountbankno())) {
            shopperbiTempModify.setAccountBankNo(shopperbiTempNew.getAccountbankno());
        }
        if (null != shopperbiTempOld.getAccountbankdictval() && !shopperbiTempOld.getAccountbankdictval().equals(shopperbiTempNew.getAccountbankdictval())) {
            shopperbiTempModify.setAccountBankDictval(shopperbiTempNew.getAccountbankdictval());
        }
        if (null != shopperbiTempOld.getAccountbankname() && !shopperbiTempOld.getAccountbankname().equals(shopperbiTempNew.getAccountbankname())) {
            shopperbiTempModify.setAccountBankName(shopperbiTempNew.getAccountbankname());
        }
        if (null != shopperbiTempOld.getAccountBankClientTel() && !shopperbiTempOld.getAccountBankClientTel().equals(shopperbiTempNew.getAccountBankClientTel())) {
            shopperbiTempModify.setAccountBankClientTel(shopperbiTempNew.getAccountBankClientTel());
        }

        return shopperbiTempModify;
    }

    /**
     * 向临时表保存修改的手续费信息
     */
    private Map<String, Object> updateshopPerbiFee(B2cShopperbiTemp b2cShopperbi,
                                                   ShopPerbiForm mbForm, MposMerchantFee s0debitMerchantFeeM, MposMerchantFee s0creditMerchantFeeM, MposMerchantFee d0debitMerchantFeeM, MposMerchantFee d0creditMerchantFeeM, MposMerchantFee t1debitMerchantFeeM,
                                                   MposMerchantFee t1creditMerchantFeeM, MposMerchantFee weChatMerchantFeeM, MposMerchantFee alipayMerchantFeeM, MposMerchantFee ylpayMerchantFeeM, MposMerchantFee shortCutMerchantFeeM,
                                                   MposMerchantFee b2cMerchantFeeM, MposMerchantFee shortCutSHMerchantFeeM) throws Exception, BusinessException {
        Map<String, Object> feeMap = new HashMap<String, Object>();
        try {
            String shopperpriIds = String.valueOf(b2cShopperbi.getShopperid());

            //查询原有费率,先查询临时表如果是空就查询正式表
            MposMerchantFee s0creditMerchantFee = shopPerbiService.findTempFeeTChannelType(shopperpriIds, Constants.FEE_TYPE_CREDIT, Constants.S0_CHANNEL_TYPE);
            if (null == s0creditMerchantFee)
                s0creditMerchantFee = shopPerbiService.findMposMerchantFee(shopperpriIds, Constants.FEE_TYPE_CREDIT, Constants.S0_CHANNEL_TYPE);

            MposMerchantFee s0debitMerchantFee = shopPerbiService.findTempFeeTChannelType(shopperpriIds, Constants.FEE_TYPE_DEBIT, Constants.S0_CHANNEL_TYPE);
            if (null == s0debitMerchantFee)
                s0debitMerchantFee = shopPerbiService.findMposMerchantFee(shopperpriIds, Constants.FEE_TYPE_DEBIT, Constants.S0_CHANNEL_TYPE);

            MposMerchantFee d0creditMerchantFee = shopPerbiService.findTempFeeTChannelType(shopperpriIds, Constants.FEE_TYPE_CREDIT, Constants.D0_CHANNEL_TYPE);
            if (null == d0creditMerchantFee)
                d0creditMerchantFee = shopPerbiService.findMposMerchantFee(shopperpriIds, Constants.FEE_TYPE_CREDIT, Constants.D0_CHANNEL_TYPE);

            MposMerchantFee d0debitMerchantFee = shopPerbiService.findTempFeeTChannelType(shopperpriIds, Constants.FEE_TYPE_DEBIT, Constants.D0_CHANNEL_TYPE);
            if (null == d0debitMerchantFee)
                d0debitMerchantFee = shopPerbiService.findMposMerchantFee(shopperpriIds, Constants.FEE_TYPE_DEBIT, Constants.D0_CHANNEL_TYPE);

            MposMerchantFee t1creditMerchantFee = shopPerbiService.findTempFeeTChannelType(shopperpriIds, Constants.FEE_TYPE_CREDIT, Constants.T1_CHANNEL_TYPE);
            if (null == t1creditMerchantFee)
                t1creditMerchantFee = shopPerbiService.findMposMerchantFee(shopperpriIds, Constants.FEE_TYPE_CREDIT, Constants.T1_CHANNEL_TYPE);


            MposMerchantFee t1debitMerchantFee = shopPerbiService.findTempFeeTChannelType(shopperpriIds, Constants.FEE_TYPE_DEBIT, Constants.T1_CHANNEL_TYPE);
            if (null == t1debitMerchantFee)
                t1debitMerchantFee = shopPerbiService.findMposMerchantFee(shopperpriIds, Constants.FEE_TYPE_DEBIT, Constants.T1_CHANNEL_TYPE);

            MposMerchantFee weChatMerchantFee = shopPerbiService.findMposMerchantFeeTemp(shopperpriIds, Constants.FEE_TYPE_WECHAT);
            if (null == weChatMerchantFee)
                weChatMerchantFee = shopPerbiService.findMposMerchantFee(shopperpriIds, Constants.FEE_TYPE_WECHAT);

            MposMerchantFee alipayMerchantFee = shopPerbiService.findMposMerchantFeeTemp(shopperpriIds, Constants.FEE_TYPE_ALIPAY);
            if (null == alipayMerchantFee)
                alipayMerchantFee = shopPerbiService.findMposMerchantFee(shopperpriIds, Constants.FEE_TYPE_ALIPAY);

            MposMerchantFee ylpayMerchantFee = shopPerbiService.findMposMerchantFeeTemp(shopperpriIds, Constants.FEE_TYPE_YLPAY);
            if (null == ylpayMerchantFee)
                ylpayMerchantFee = shopPerbiService.findMposMerchantFee(shopperpriIds, Constants.FEE_TYPE_YLPAY);

            //无卡
            MposMerchantFee shortCutMerchantFee = shopPerbiService.findMposMerchantFeeTemp(shopperpriIds, Constants.FEE_TYPE_SHORTCUT);
            if (null == shortCutMerchantFee)
                shortCutMerchantFee = shopPerbiService.findMposMerchantFee(shopperpriIds, Constants.FEE_TYPE_SHORTCUT);

            MposMerchantFee b2cMerchantFee = shopPerbiService.findMposMerchantFeeTemp(shopperpriIds, Constants.FEE_TYPE_B2C);
            if (null == b2cMerchantFee)
                b2cMerchantFee = shopPerbiService.findMposMerchantFee(shopperpriIds, Constants.FEE_TYPE_B2C);

            MposMerchantFee shortCutSHMerchantFee = shopPerbiService.findMposMerchantFeeTemp(shopperpriIds, Constants.FEE_TYPE_SHD0);
            if (null == shortCutSHMerchantFee)
                shortCutSHMerchantFee = shopPerbiService.findMposMerchantFee(shopperpriIds, Constants.FEE_TYPE_SHD0);

            //获取页面传来的费率
            String s0creditFee = mbForm.getS0creditFee();//秒到贷记卡
            String s0debitFee = mbForm.getS0debitFee();//秒到借记卡

            String d0creditFee = mbForm.getD0creditFee();//即时贷记卡
            String d0debitFee = mbForm.getD0debitFee();//即时借记卡

            String t1creditFee = mbForm.getT1creditFee();//T1贷记卡
            String t1debitFee = mbForm.getT1debitFee();//T1借记卡

            String s0fixAmount = mbForm.getS0fixAmount();//秒到收款固定金额
            String t0fixAmount = mbForm.getT0fixAmount();//即时收款固定金额

            String weChatFee = mbForm.getWeChatFee();//微信T1费率
            String alipayFee = mbForm.getAlipayFee();//支付宝T1费率
            String weChatD0Fee = mbForm.getWeChatD0Fee();//微信D0费率
            String alipayD0Fee = mbForm.getAlipayD0Fee();//支付宝D0费率
            String ylpayFee = mbForm.getYlpayFee();//银联T1费率
            String ylpayD0Fee = mbForm.getYlpayD0Fee();//银联D0费率
            //无卡汇率
            String shortCut = mbForm.getShortCut();//快捷T1费率
            String shortCutDo = mbForm.getShortCutDo();//快捷D0费率
            String shortCutSHDo = mbForm.getShortCutSHDo();//快捷速惠费率
            String b2c = mbForm.getB2c();//b2c T1费率
            String b2cDo = mbForm.getB2cDo();//b2c D0费率

            //判断费率是否修改
            if (s0creditFee != null && s0creditMerchantFee != null) {
                if (!s0creditFee.equals(s0creditMerchantFee.getFee())) {
                    s0creditMerchantFeeM.setFee(s0creditFee);
                }
                s0creditMerchantFee.setFee(s0creditFee);
                s0creditMerchantFee.setEachamount(new BigDecimal(s0fixAmount));
                s0creditMerchantFee.setUpdateDate(new Date());
            }
            if (s0debitFee != null && s0debitMerchantFee != null) {
                if (!s0debitFee.equals(s0debitMerchantFee.getFee())) {
                    s0debitMerchantFeeM.setFee(s0debitFee);
                }
                s0debitMerchantFee.setFee(s0debitFee);
                s0debitMerchantFee.setEachamount(new BigDecimal(s0fixAmount));
                s0debitMerchantFee.setUpdateDate(new Date());
            }

            if (d0creditFee != null && d0creditMerchantFee != null) {
                if (!d0creditFee.equals(d0creditMerchantFee.getFee())) {
                    d0creditMerchantFeeM.setFee(d0creditFee);
                }
                d0creditMerchantFee.setFee(d0creditFee);
                d0creditMerchantFee.setEachamount(new BigDecimal(t0fixAmount));
                d0creditMerchantFee.setUpdateDate(new Date());
            }
            if (d0debitFee != null && d0debitMerchantFee != null) {
                if (!d0debitFee.equals(d0debitMerchantFee.getFee())) {
                    d0debitMerchantFeeM.setFee(d0debitFee);
                }
                d0debitMerchantFee.setFee(d0debitFee);
                d0debitMerchantFee.setEachamount(new BigDecimal(t0fixAmount));
                d0debitMerchantFee.setUpdateDate(new Date());
            }

            if (t1creditFee != null && t1creditMerchantFee != null) {
                if (!t1creditFee.equals(t1creditMerchantFee.getFee())) {
                    t1creditMerchantFeeM.setFee(t1creditFee);
                }
                t1creditMerchantFee.setFee(t1creditFee);
                t1creditMerchantFee.setEachamount(new BigDecimal(0));
                t1creditMerchantFee.setUpdateDate(new Date());
            }
            if (t1debitFee != null && t1debitMerchantFee != null) {
                if (!t1debitFee.equals(t1debitMerchantFeeM.getFee())) {
                    t1debitMerchantFeeM.setFee(t1debitFee);
                }
                t1debitMerchantFee.setFee(t1debitFee);
                t1debitMerchantFee.setEachamount(new BigDecimal(0));
                t1debitMerchantFee.setUpdateDate(new Date());
            }

            if (weChatFee != null && weChatMerchantFee != null && weChatD0Fee != null) {
                if (!weChatFee.equals(weChatMerchantFee.getFee())) {
                    weChatMerchantFeeM.setFee(weChatFee);

                }
                if (!weChatD0Fee.equals(weChatMerchantFee.getD0Fee())) {
                    weChatMerchantFeeM.setD0Fee(weChatD0Fee);
                }
                weChatMerchantFee.setFee(weChatFee);
                weChatMerchantFee.setD0Fee(weChatD0Fee);
                weChatMerchantFee.setUpdateDate(new Date());
            }
            if (alipayFee != null && alipayMerchantFee != null && alipayD0Fee != null) {
                if (!alipayFee.equals(alipayMerchantFee.getFee())) {
                    alipayMerchantFeeM.setFee(alipayFee);
                }
                if (!alipayD0Fee.equals(alipayMerchantFee.getD0Fee())) {
                    alipayMerchantFeeM.setD0Fee(alipayD0Fee);
                }
                alipayMerchantFee.setFee(alipayFee);
                alipayMerchantFee.setD0Fee(alipayD0Fee);
                alipayMerchantFee.setUpdateDate(new Date());
            }
            if (ylpayFee != null && ylpayMerchantFee != null) {
                if (!ylpayFee.equals(ylpayMerchantFee.getFee())) {
                    ylpayMerchantFeeM.setFee(ylpayFee);
                }
                if (!ylpayD0Fee.equals(ylpayMerchantFee.getD0Fee())) {
                    ylpayMerchantFeeM.setD0Fee(ylpayD0Fee);
                }
                ylpayMerchantFee.setD0Fee(ylpayD0Fee);
                ylpayMerchantFee.setFee(ylpayFee);
                ylpayMerchantFee.setUpdateDate(new Date());
            }
            //比较数据库和传入的是否一样,如果不一样就取传入的放入新对象,如果一样就取传入的放入查询的对象
            if (shortCut != null && shortCutMerchantFee != null && shortCutDo != null) {
                if (!shortCut.equals(shortCutMerchantFee.getFee())) {
                    shortCutMerchantFeeM.setFee(shortCut);

                }
                if (!shortCutDo.equals(shortCutMerchantFee.getD0Fee())) {
                    shortCutMerchantFeeM.setD0Fee(shortCutDo);
                }
                shortCutMerchantFee.setFee(shortCut);
                shortCutMerchantFee.setD0Fee(shortCutDo);
                shortCutMerchantFee.setUpdateDate(new Date());
            }

            if (shortCutSHDo != null && shortCutSHMerchantFee != null) {
                if (!shortCutSHDo.equals(shortCutSHMerchantFee.getD0Fee())) {
                    shortCutSHMerchantFeeM.setD0Fee(shortCutSHDo);
                }
                shortCutSHMerchantFee.setD0Fee(shortCutSHDo);
                shortCutSHMerchantFee.setUpdateDate(new Date());
            }

            if (b2c != null && b2cMerchantFee != null && b2cDo != null) {
                if (!b2c.equals(b2cMerchantFee.getFee())) {
                    b2cMerchantFeeM.setFee(b2c);

                }
                if (!b2cDo.equals(b2cMerchantFee.getD0Fee())) {
                    b2cMerchantFeeM.setD0Fee(b2cDo);
                }
                b2cMerchantFee.setFee(b2c);
                b2cMerchantFee.setD0Fee(b2cDo);
                b2cMerchantFee.setUpdateDate(new Date());
            }

            feeMap.put("s0debitMerchantFee", s0debitMerchantFee);
            feeMap.put("s0creditMerchantFee", s0creditMerchantFee);
            feeMap.put("d0debitMerchantFee", d0debitMerchantFee);
            feeMap.put("d0creditMerchantFee", d0creditMerchantFee);

            feeMap.put("t1debitMerchantFee", t1debitMerchantFee);
            feeMap.put("t1creditMerchantFee", t1creditMerchantFee);

            feeMap.put("weChatMerchantFee", weChatMerchantFee);
            feeMap.put("alipayMerchantFee", alipayMerchantFee);
            feeMap.put("ylpayMerchantFee", ylpayMerchantFee);
            feeMap.put("shortCutMerchantFee", shortCutMerchantFee);
            feeMap.put("b2cMerchantFee", b2cMerchantFee);
            feeMap.put("shortCutSHMerchantFee", shortCutSHMerchantFee);

        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.保存商户修改信息失败);
        }
        return feeMap;
    }
}
