package com.uns.service;

import com.uns.common.Constants;
import com.uns.dao.B2cShopperbiMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service
public class CountOcrUseService {

    @Autowired
    private B2cShopperbiMapper b2cShopperbiMapper;


    /**
     * 查询OCR操作统计
     * @param countStartDate
     * @param countEndDate
     * @return
     */
    public HashMap findCountOcrUse(Date countStartDate,Date countEndDate){
        HashMap countOcr = new HashMap();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String startDate = sdf.format(countStartDate);
        String endDate = sdf.format(countEndDate);
        countOcr.put("countStartDate",startDate);
        countOcr.put("countEndDate",endDate);
        Map dateMap = new HashMap();
        Integer htCount,sfzCount,yhkCount = null;
        dateMap.put("startDate",startDate);
        dateMap.put("endDate",endDate);
        //活体OCR检测
        dateMap.put("type", Constants.HT_OCR);
        htCount =  b2cShopperbiMapper.findOcrCount(dateMap);
        //身份证OCR检测
        dateMap.put("type", Constants.SFZ_OCR);
        sfzCount = b2cShopperbiMapper.findOcrCount(dateMap);
        //银行卡OCR检测
        dateMap.put("type", Constants.YHK_OCR);
        yhkCount = b2cShopperbiMapper.findOcrCount(dateMap);

        countOcr.put("htCount",htCount);
        countOcr.put("sfzCount",sfzCount);
        countOcr.put("yhkCount",yhkCount);
        return countOcr;
    }

    /**
     * 统计银生宝ocr使用情况
     * @param countStartDate
     * @param countEndDate
     * @return
     */
    public HashMap findYsbOcrCount(Date countStartDate,Date countEndDate) throws Exception{
        HashMap countOcr = new HashMap();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String startDate = sdf.format(countStartDate);
        String endDate = sdf.format(countEndDate);
        countOcr.put("countStartDate",startDate);
        countOcr.put("countEndDate",endDate);
        Map dateMap = new HashMap();
        Integer htCount,sfzCount,yhkCount,policeCount,faceCount = null;
        dateMap.put("startDate",startDate);
        dateMap.put("endDate",endDate);
        dateMap.put("projectType","gyl");
        //活体OCR检测
        dateMap.put("type", Constants.HT_OCR);
        htCount =  b2cShopperbiMapper.findOcrCount(dateMap);
        //身份证OCR检测
        dateMap.put("type", Constants.SFZ_OCR);
        sfzCount = b2cShopperbiMapper.findOcrCount(dateMap);
        //银行卡OCR检测
        dateMap.put("type", Constants.YHK_OCR);
        yhkCount = b2cShopperbiMapper.findOcrCount(dateMap);
        //公安检测
        dateMap.put("type", Constants.POLICE_OCR);
        policeCount = b2cShopperbiMapper.findOcrCount(dateMap);
        //人脸比对
        dateMap.put("type", Constants.FACE_THAN_OCR);
        faceCount = b2cShopperbiMapper.findOcrCount(dateMap);

        countOcr.put("htCount",htCount);
        countOcr.put("sfzCount",sfzCount);
        countOcr.put("yhkCount",yhkCount);
        countOcr.put("policeCount",policeCount);
        countOcr.put("faceCount",faceCount);
        return countOcr;
    }


}
