package com.uns.web;


import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.font.FontRenderContext;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.model.B2cFixedCode;
import com.uns.model.Operator;
import com.uns.service.AgentService;
import com.uns.service.B2cFixedCodeService;
import com.uns.service.ShopPerbiService;
import com.uns.util.DateUtils;
import com.uns.util.FilePathUtils;
import com.uns.util.ImageUtil;
import com.uns.util.Md5Encrypt;

import net.sf.json.JSONObject;
@Controller
@RequestMapping("/b2cFixedCode.htm")
public class B2cFixedCodeController extends BaseController {

	@Autowired
	private B2cFixedCodeService b2cFixedCodeService;
	
	@Autowired 
	private ShopPerbiService shopPerbiService;
	
	@Autowired
	private AgentService agentService;
	

	
	
	/**
	 * 固码入库页面
	 * @author yang.liu01
	 * @param request
	 * @param b2cFixedCode
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=findFixedCodeInList")
	public String findFixedCodeInList(HttpServletRequest request,B2cFixedCode b2cFixedCode)throws BusinessException {
	    
	    List<B2cFixedCode> resultList = b2cFixedCodeService.findFixedCodeList(b2cFixedCode);
	    request.setAttribute("resultList", resultList);
	    request.setAttribute("belongsAgent", b2cFixedCode.getBelongsAgent());
		return "fixedCode/fixedCodeInList";
	}
	
	
	/**
	 * 固码出库页面
	 * @author yang.liu01
	 * @param request
	 * @param b2cFixedCode
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=findFixedCodeOutList")
	public String findFixedCodeOutList(HttpServletRequest request,B2cFixedCode b2cFixedCode)throws BusinessException {
	    
	    List<B2cFixedCode> resultList = b2cFixedCodeService.findFixedCodeOutList(b2cFixedCode);
	    
	    request.setAttribute("resultList", resultList);
	    request.setAttribute("belongsAgent", b2cFixedCode.getBelongsAgent());
		return "fixedCode/fixedCodeOutList";
	}
	
	/**
	 * 固码入库页面
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(params = "method=fixedCodeIn")
	@FormToken(save=true)
	public String fixedCodeIn(HttpServletRequest request,HttpServletResponse response) {
		
		return "fixedCode/fixedCodeIn";
	}
	/**
	 * 固码出库页面
	 * @param request
	 * @param response
	 * @return
	 */
	@FormToken(save=true)
	@RequestMapping(params = "method=fixedCodeOut")
	public String fixedCodeOut(HttpServletRequest request,HttpServletResponse response){
		return "fixedCode/fixedCodeOut";
	}
	
	
	/**
	 * 模板下载
	 * @param fileName
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/download")
	public void download(HttpServletRequest request,
			HttpServletResponse response) {

		String path = request.getContextPath();
		String basePath = request.getScheme() + "://"
				+ request.getServerName() + ":" + request.getServerPort()
				+ path + "/";
		String filePath =request.getSession().getServletContext().getRealPath("/")+
				"upload"+File.separator+"fixedCode"+File.separator+"templatae.xls" ;
    	String fileName = "";
    	
    	//从文件完整路径中提取文件名，并进行编码转换，防止不能正确显示中文名
    	try {
        	if(filePath.lastIndexOf("/") > 0) {
        		fileName = new String(filePath.substring(filePath.lastIndexOf("/")+1, filePath.length()).getBytes("GB2312"), "ISO8859_1");
        	}else if(filePath.lastIndexOf("\\") > 0) {
        		fileName = new String(filePath.substring(filePath.lastIndexOf("\\")+1, filePath.length()).getBytes("GB2312"), "ISO8859_1");
        	}
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    	//打开指定文件的流信息
    	InputStream fs = null;
    	try {
    		fs = new FileInputStream(new File(filePath));
    		
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    	//设置响应头和保存文件名 
    	response.setCharacterEncoding("ISO-8859-1");
    	response.setContentType("APPLICATION/OCTET-STREAM"); 
    	response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
    	//写出流信息
    	int b = 0;
    	try {
        	PrintWriter out = response.getWriter();
        	while((b=fs.read())!=-1) {
        		out.write(b);
        	}
        	out.flush();
        	fs.close();
        	out.close();
        	System.out.println("文件下载完毕.");
    	}catch(Exception e) {
        	e.printStackTrace();
        	System.out.println("下载文件失败!");
    	}
		
	}
	
	/**
	 * 固码入库
	 * @param request
	 * @param response
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=saveFixedCodeIn")
	@FormToken(remove=true)
	public String saveFixedCodeIn(HttpServletRequest request,HttpServletResponse response,B2cFixedCode model) throws Exception {
		HSSFSheet sheet;
		Map map = new HashMap();
		try {
				MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
				// 获得文件
				MultipartFile file = multipartRequest.getFile("termNosFile");
				// 获取输出流
				InputStream in = file.getInputStream();
				HSSFWorkbook workbook = new HSSFWorkbook(in);
				sheet = workbook.getSheetAt(0);
			} catch (Exception e) {
				e.printStackTrace();
				throw new BusinessException(ExceptionDefine.库存管理,new String[]{"文件上传失败"});
			}
		
			if (sheet != null) {
				map =insertBatchIn(request, sheet);
			}
		JSONObject json =JSONObject.fromObject(map);
		log.info(map.get("rspMsg") + json.toString());
		if(map.get("rspCode").equals(Constants.RESPONSE_CODE)){
			request.setAttribute("url","b2cFixedCode.htm?method=findFixedCodeInList");
			response.setContentType("UTF-8");
			
			request.setAttribute(Constants.MESSAGE_KEY, map.get("rspMsg"));
		}
		
		if(map.get("rspCode").equals(Constants.QRCODE_STATUS1)) {
			throw new BusinessException(ExceptionDefine.固码编号已经入库);
		}
		if(map.get("rspCode").equals(Constants.QRCODE_STATUS2)) {
			throw new BusinessException(ExceptionDefine.固码编号不正确);
		}
		if(map.get("rspCode").equals(Constants.QRCODE_UNNUM)) {
			throw new BusinessException(ExceptionDefine.固码编号有非法数字);
		}
		if(map.get("rspCode").equals(Constants.QRCODE_LONG)) {
			throw new BusinessException(ExceptionDefine.上传条数超限制);
		}
		return "/returnPage";
	}
	
	
	/**
	 * 固码出库
	 * @param request
	 * @param response
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=saveFixedCodeOut")
	@FormToken(remove=true)
	public String saveFixedCodeOut(HttpServletRequest request,HttpServletResponse response,B2cFixedCode model) throws Exception {
		HSSFSheet sheet;
		Map map = new HashMap();
		try {
				MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
				// 获得文件
				MultipartFile file = multipartRequest.getFile("termNosFile");
				// 获取输出流
				InputStream in = file.getInputStream();
				HSSFWorkbook workbook = new HSSFWorkbook(in);
				sheet = workbook.getSheetAt(0);
			} catch (Exception e) {
				e.printStackTrace();
				throw new BusinessException(ExceptionDefine.库存管理,new String[]{"文件上传失败"});
			}
		
			if (sheet != null) {
				map =insertBatchOut(request, sheet,model.getShopperidP());
			}
		JSONObject json =JSONObject.fromObject(map);
		log.info(map.get("rspMsg") + json.toString());
		if(map.get("rspCode").equals(Constants.RESPONSE_CODE)){
			request.setAttribute("url","b2cFixedCode.htm?method=findFixedCodeOutList");
			response.setContentType("UTF-8");
			
			request.setAttribute(Constants.MESSAGE_KEY, map.get("rspMsg"));
		}
		
		if(map.get("rspCode").equals(Constants.QRCODE_UN)) {
			throw new BusinessException(ExceptionDefine.固码没有入库);
		}
		if(map.get("rspCode").equals(Constants.QRCODE_STATUS2)) {
			throw new BusinessException(ExceptionDefine.固码编号不正确);
		}
		if(map.get("rspCode").equals(Constants.QRCODE_Y)){
			throw new BusinessException(ExceptionDefine.固码已经出过库);
		}
		if(map.get("rspCode").equals(Constants.QRCODE_UNNUM)) {
			throw new BusinessException(ExceptionDefine.固码编号有非法数字);
		}
		if(map.get("rspCode").equals(Constants.QRCODE_LONG)) {
			throw new BusinessException(ExceptionDefine.上传条数超限制);
		}
		return "/returnPage";
	}
	
	/**
	 * 出库操作
	 * @param request
	 * @param sheet
	 * @return
	 * @throws BusinessException 
	 */
	public  Map insertBatchOut(HttpServletRequest request, HSSFSheet sheet,String outAgentNo) throws BusinessException {
		HSSFRow row=null;
		int index=0;
		Map msgMap = new HashMap();		
		Operator  sessionUser=(Operator)request.getSession().getAttribute(Constants.SESSION_KEY_USER);    
		List<B2cFixedCode> bactList = new ArrayList<B2cFixedCode>();
		int rowNum =sheet.getLastRowNum()+1;
		if(rowNum<=Constants.UPLOAD_SIZE) {
			//根据Excel表格里面的数据循环
			for (int i = 0; i < rowNum; i++) {
				try{
					row = sheet.getRow(i);
					if (null != row) {
						
						String qrCodeNo=row.getCell(0).toString();
						//处理空格
						qrCodeNo=qrCodeNo.replaceAll(" ", "");
						if(qrCodeNo !=null) {
							//正则判断
							if(qrCodeNo.matches("^[0-9]*$")) {
								if(qrCodeNo.length()==Constants.QRCODE_SIZE) {
									B2cFixedCode b2cFixedCode =b2cFixedCodeService.findFixedCodeByParam(qrCodeNo);
									//如果有数据
									if(b2cFixedCode!=null) {
										if(b2cFixedCode.getParentAgentNo()!=null){
											index++;
											msgMap.put("rspCode", Constants.QRCODE_Y);
											msgMap.put("rspMsg", "第"+index+"条，固码编号已经出库");
											return msgMap;
										}else {
											index++;
											//封装出库数据
											b2cFixedCode.setUpdateUser(sessionUser==null?"":sessionUser.getUserName());
											b2cFixedCode.setParentAgentNo(outAgentNo);
											b2cFixedCode.setShopperidP(outAgentNo);
											b2cFixedCode.setAgentNo(outAgentNo);
											b2cFixedCode.setUpdateDate(new Date());
											bactList.add(b2cFixedCode);
										}
										
									}else {
										index++;
										msgMap.put("rspCode", Constants.QRCODE_UN);
										msgMap.put("rspMsg", "第"+index+"条，固码编号没有入库");
										return msgMap;
									}
									
								}else {
									index++;
									msgMap.put("rspCode", Constants.QRCODE_STATUS2);
									msgMap.put("rspMsg", "第"+index+"条，固码编号长度不正确");
									return msgMap;
								}
							}else {
								index++;
								msgMap.put("rspCode", Constants.QRCODE_UNNUM);
								msgMap.put("rspMsg", "第"+index+"条，固码编号有非法数字");
								return msgMap;
							}
							
						
						}
					}	
						
				} catch (Exception e) {
					e.printStackTrace();
					throw new BusinessException(ExceptionDefine.固码出库失败);
					
				}
			}
		}else {
			msgMap.put("rspCode", Constants.QRCODE_LONG);
			msgMap.put("rspMsg", "上传失败，每次最多上传5000条");
		}
			
		//如果没有异常统一出库
		try {
			if(!bactList.isEmpty()) {
				//更新
				for (B2cFixedCode b2cFixedCode2 : bactList) {
					this.b2cFixedCodeService.updateBatchModel(b2cFixedCode2);
				}
				
				msgMap.put("rspCode", Constants.RESPONSE_CODE);
				msgMap.put("rspMsg", "共"+index+"条，终端编号出库成功");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.固码出库失败);
		}
		
		
		return msgMap;
	}


	/**
	 * 入库操作
	 * @param request
	 * @param qrCodeNo
	 * @param sheet
	 * @return
	 * @throws BusinessException
	 */
	public Map insertBatchIn(HttpServletRequest request,HSSFSheet sheet) throws BusinessException {
		HSSFRow row=null;
		int index=0;
		Map msgMap = new HashMap();		
		Operator  sessionUser=(Operator)request.getSession().getAttribute(Constants.SESSION_KEY_USER);    
		List<B2cFixedCode> bactList = new ArrayList<B2cFixedCode>();
		int rowNum =sheet.getLastRowNum()+1;
		if(rowNum<=Constants.UPLOAD_SIZE) {
			//根据Excel表格里面的数据循环
			for (int i = 0; i <= rowNum; i++) {
				try{
					row = sheet.getRow(i);
					if (null != row) {
						
						String qrCodeNo=row.getCell(0).toString();
						//处理空格
						qrCodeNo=qrCodeNo.replaceAll(" ", "");
						if(qrCodeNo !=null) {
							if(qrCodeNo.matches("^[0-9]*$")) {
								if(qrCodeNo.length()==Constants.QRCODE_SIZE) {
									B2cFixedCode b2cFixedCode =b2cFixedCodeService.findFixedCodeByParam(qrCodeNo);
									
									if(null==b2cFixedCode) {
										b2cFixedCode = new B2cFixedCode();
										index++;
										//开始入库
										b2cFixedCode.setQrCodeNo(qrCodeNo);
										b2cFixedCode.setCreateDate(new Date());
										b2cFixedCode.setStorageDate(new Date());
										b2cFixedCode.setStatus(Constants.QRCODE_IN);
										b2cFixedCode.setCreateUser(sessionUser==null?"":sessionUser.getUserName());
										bactList.add(b2cFixedCode);
									}else {
										index++;
										msgMap.put("rspCode", Constants.QRCODE_STATUS1);
										msgMap.put("rspMsg", "第"+index+"条，固码编号已经入库");
										return msgMap;
									}
								}else {
									index++;
									msgMap.put("rspCode", Constants.QRCODE_STATUS2);
									msgMap.put("rspMsg", "第"+index+"条，固码编号长度不正确");
									return msgMap;
								}
							}else {
								index++;
								msgMap.put("rspCode", Constants.QRCODE_UNNUM);
								msgMap.put("rspMsg", "第"+index+"条，固码编号有非法数字");
								return msgMap;
							}
						}
					}	
						
				} catch (Exception e) {
					e.printStackTrace();
					throw new BusinessException(ExceptionDefine.固码入库失败);
					
				}
			}
		}else {
			msgMap.put("rspCode", Constants.QRCODE_LONG);
			msgMap.put("rspMsg", "上传失败，每次最多上传5000条");
		}
		
		
		//如果没有异常统一入库
		try {
			
			if(!bactList.isEmpty()) {
				
				this.b2cFixedCodeService.insertBatchModel(bactList);
			}
			msgMap.put("rspCode", Constants.RESPONSE_CODE);
	 		msgMap.put("rspMsg", "共"+index+"条，固码编号入库成功");
		}catch(RuntimeException e ) {
 			String errMsg = e.getMessage();
 		    if(StringUtils.isNotBlank(errMsg)) {
 		    	throw new BusinessException(ExceptionDefine.固码重复);
 		    }
 		   e.printStackTrace();
 		}catch (Exception e) {
 			e.printStackTrace();
 			throw new BusinessException(ExceptionDefine.固码入库失败);
 		}
		
		return msgMap;
	}
	
	/**
	 * 密钥处理
	 * @param qrCode
	 * @return
	 */
	public String encryptionDispose(String qrCode) {
		StringBuffer sBuffer=new StringBuffer();
		sBuffer.append(qrCode);
		sBuffer.append(DynamicConfigLoader.getByEnv("merchantkey"));
		String smacs=Md5Encrypt.md5(sBuffer.toString());
		return smacs;
	}
	
	/**
	 * 下载二维码图片压缩包
	 * @param request
	 * @param response
	 * @param model
	 * @throws WriterException
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=downloadZipQrCode")
	public void downloadZipQrCode(HttpServletRequest request, HttpServletResponse response,
			B2cFixedCode model) throws BusinessException {
		
		String[] qrCodes=request.getParameterValues("selectId");
		
		Date date = new Date();
		String dtfmt=DateUtils.getFormatDate(date, "yyyyMMddHHmmss");
	    try {  
	    	OutputStream os = response.getOutputStream();
	    	//压缩包流
	    	ByteArrayOutputStream byteTest2 = new ByteArrayOutputStream();
	    	//图片存压缩包
			ZipOutputStream zos = new ZipOutputStream(byteTest2); 
			//头部logo路径
			String topFilepath=FilePathUtils.getContextPath(request, "images", "qrCode", "top.png");
			//尾部logo路径
 			String botFilepath=FilePathUtils.getContextPath(request, "images", "qrCode", "bottom.png");
	    	for (String string : qrCodes) {
	    		 
	 		   // String content= "http://www.baidu.com";
	 		    //获取加密后的二维码编号 
	 		    String smacs=encryptionDispose(string);
	 		    String qrCodeUrl = DynamicConfigLoader.getByEnv("fixed_qr_code.url")+"qrCode="+string+"&mac="+smacs;
	 		    
	 			Hashtable<Object, Object> hints = new Hashtable<Object, Object>();
	 			hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
	 			//生成二维码  指定编码格式
	 			hints.put(EncodeHintType.CHARACTER_SET, "utf-8");
	 			BitMatrix bitMatrix = new MultiFormatWriter().encode(qrCodeUrl,BarcodeFormat.QR_CODE, 240,240);
	 			
	 			BufferedImage qrCodeimage =MatrixToImageWriter.toBufferedImage(bitMatrix);
	 			//画一张白的图片把二维码放进画布里面去
	 			BufferedImage biImage = new BufferedImage(250, 250, BufferedImage.TYPE_4BYTE_ABGR_PRE);
	 			Graphics2D g2Graphics2d = (Graphics2D)biImage.getGraphics();
	 			g2Graphics2d.setBackground(Color.WHITE); 
	 			g2Graphics2d.clearRect(0,0, biImage.getWidth(),biImage.getHeight());
	 			g2Graphics2d.drawImage(qrCodeimage, (biImage.getWidth()-qrCodeimage.getWidth())/2, (biImage.getHeight()-qrCodeimage.getHeight())/2, Color.WHITE, null);
	 			
	 			qrCodeimage=biImage;
	 			
	 			BufferedImage topImage = ImageIO.read(new File(topFilepath));
	 			//BufferedImage qrCodeimage = ImageIO.read(new File(qrCodePath));
	 			BufferedImage botImage = ImageIO.read(new File(botFilepath));
		        
		        int owidth = qrCodeimage.getWidth();
	 			//处理数字
	 			BufferedImage bi = new BufferedImage(owidth , 50 , BufferedImage.TYPE_4BYTE_ABGR_PRE);
	 			int width = bi.getWidth();   
	 	        int height = bi.getHeight();
	 			Graphics2D g2 = (Graphics2D)bi.getGraphics();
	 	        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
	 	        g2.setBackground(Color.WHITE);   
	 	        g2.clearRect(0, 0, width, height);
	 	        
	 	        FontRenderContext context = g2.getFontRenderContext();
	 	        g2.setPaint(Color.BLACK);
	 	        Font font = new Font("宋体" ,Font.PLAIN ,15);
	 	        g2.setFont(font);
	 	        String fontNO = Constants.QRCODE_NO+string;
	 	        Rectangle2D topBounds = font.getStringBounds(fontNO, context);
	 	        double topX = (width - topBounds.getWidth()) / 2;   
	 	        double topY = (height - topBounds.getHeight()) / 2;   
	 	        double topAscent = - topBounds.getY();   
	 	        double topBaseY = topY + topAscent;
	 	        g2.drawString(fontNO, (float)topX, (float)topBaseY);
	 	        
	 	        
	 	       /***先用第一张图和第二张图合成一张图，再用合成后的图和第三张合成一张新图，依次得到想要的合成图***/
	 	       BufferedImage merge1 = ImageUtil.merge(topImage, qrCodeimage);
	 	       BufferedImage merge2 = ImageUtil.merge(merge1, bi);
	 	       BufferedImage merge3 = ImageUtil.merge(merge2, botImage);
	 			 // 调用mergeImage方法获得合并后的图像
	 	       // BufferedImage destImg = ImageUtil.mergeMuchImage(false,topImage,qrCodeimage,bi,botImage);
 	           // System.out.println("垂直合并完毕!");
 	            

 				//图片转byte
 				ByteArrayOutputStream byteTest = new ByteArrayOutputStream();
 				ImageIO.write(merge3, "png", byteTest);
 				byte[] bt = byteTest.toByteArray();
 				
 				ZipEntry zipEntry = new ZipEntry(string+".png");
 	            zos.putNextEntry(zipEntry);
 	            zos.write(bt);  
 				
 	          
			}
            response.setContentType("application/octet-stream"); 
            response.setHeader("content-disposition", "attachment;filename="+new String(dtfmt.getBytes("UTF-8"),"iso8859-1")+".zip");
			response.setCharacterEncoding("UTF-8");
			
			//关闭相关流
			zos.flush();
		    zos.closeEntry();
		    zos.close();
		    //输出
            os.write(byteTest2.toByteArray());  
            os.flush();  
            os.close(); 
            logger.info("压缩包下载成功！");
            System.out.println();
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.固码编号下载失败);
		}
		
	}
	
	
	@RequestMapping(params = "method=disposeFixedCode")
	public void disposeFixedCode(HttpServletRequest request, HttpServletResponse response,
			B2cFixedCode model) throws BusinessException {
		//先查询出所有的二维码编号信息
		List<B2cFixedCode> fixedCodeList = b2cFixedCodeService.findAllFixedCode();
		//查询所有的商户
		List<String> shopperidList= shopPerbiService.findAllShopPerbi();
		//循环遍历，根据二维码编号更新所属代理商
		String agentNo="";
		String firstAgentNo="";
		
		int index=0;
		int len=shopperidList.size();
		if(fixedCodeList.size()>shopperidList.size()) {
			len=shopperidList.size();
		}
		if (fixedCodeList.size()<shopperidList.size()) {
			len=fixedCodeList.size();
		}
		
		String qrcodeNo ="";
		for (int i = 0; i < len; i++) {
			index++;
			String  shopperid = shopperidList.get(i);
			B2cFixedCode fixedCode = fixedCodeList.get(i);
			qrcodeNo=fixedCode.getQrCodeNo();
			//判断是够已经绑定商户
			if(fixedCode.getMerchantid()!=null&&fixedCode.getMerchantid()!="") {
				logger.info("二维码编号"+fixedCode.getQrCodeNo()+"已经绑定过商户");	
			}else{
				//取出代理商对应所属服务商
				//agentNo = shopperbi.getShopperidP()==null?"":shopperbi.getShopperidP().toString();
				//查询出代理商对应的一级代理商
				if(!StringUtils.isEmpty(shopperid)) {
					firstAgentNo =agentService.findFisrtParma(shopperid);

					//根据二维码编号更新所属代理商
					fixedCode.setAgentNo(shopperid);
					fixedCode.setShopperidP(shopperid);
					fixedCode.setParentAgentNo(firstAgentNo);
					b2cFixedCodeService.updateAgentNoByModel(fixedCode);
				}
				
				
			}
		}
		logger.info("共"+index+"条二维码编号配置成功");
		request.setAttribute(Constants.MESSAGE_KEY, index+"条二维码配置代理商成功");
		
	}
	

	 
	
}
