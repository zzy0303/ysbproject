package com.uns.model;

import java.math.BigDecimal;
import java.util.Date;

public class UpdateFeeHistory {
    private Long id;

    private Long shopperid;

    private String cardtype;

    private BigDecimal fee;

    private BigDecimal topAmount;

    private BigDecimal t0fee;

    private String t0type;

    private BigDecimal t0fixedamount;

    private BigDecimal t0topamount;

    private BigDecimal t0additionfee;

    private BigDecimal t0minamount;

    private BigDecimal t0maxamount;

    private Date updateDate;

    private String updateUser;

    private BigDecimal t0SingleDayLimit;

    private Date checkDate;

    private String checkResult;

    private Date recheckDate;

    private String recheckResult;
    private String issupportt0;
    
    private String feeType;
  

	public String getIssupportt0() {
		return issupportt0;
	}

	public void setIssupportt0(String issupportt0) {
		this.issupportt0 = issupportt0;
	}

	

    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	

    public Long getShopperid() {
		return shopperid;
	}

	public void setShopperid(Long shopperid) {
		this.shopperid = shopperid;
	}

	public String getCardtype() {
        return cardtype;
    }

    public void setCardtype(String cardtype) {
        this.cardtype = cardtype == null ? null : cardtype.trim();
    }

    public BigDecimal getFee() {
        return fee;
    }

    public void setFee(BigDecimal fee) {
        this.fee = fee;
    }

    public BigDecimal getTopAmount() {
        return topAmount;
    }

    public void setTopAmount(BigDecimal topAmount) {
        this.topAmount = topAmount;
    }

    public BigDecimal getT0fee() {
        return t0fee;
    }

    public void setT0fee(BigDecimal t0fee) {
        this.t0fee = t0fee;
    }

    public String getT0type() {
        return t0type;
    }

    public void setT0type(String t0type) {
        this.t0type = t0type == null ? null : t0type.trim();
    }

    public BigDecimal getT0fixedamount() {
        return t0fixedamount;
    }

    public void setT0fixedamount(BigDecimal t0fixedamount) {
        this.t0fixedamount = t0fixedamount;
    }

    public BigDecimal getT0topamount() {
        return t0topamount;
    }

    public void setT0topamount(BigDecimal t0topamount) {
        this.t0topamount = t0topamount;
    }

    public BigDecimal getT0additionfee() {
        return t0additionfee;
    }

    public void setT0additionfee(BigDecimal t0additionfee) {
        this.t0additionfee = t0additionfee;
    }

    public BigDecimal getT0minamount() {
        return t0minamount;
    }

    public void setT0minamount(BigDecimal t0minamount) {
        this.t0minamount = t0minamount;
    }

    public BigDecimal getT0maxamount() {
        return t0maxamount;
    }

    public void setT0maxamount(BigDecimal t0maxamount) {
        this.t0maxamount = t0maxamount;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser == null ? null : updateUser.trim();
    }

    public BigDecimal getT0SingleDayLimit() {
        return t0SingleDayLimit;
    }

    public void setT0SingleDayLimit(BigDecimal t0SingleDayLimit) {
        this.t0SingleDayLimit = t0SingleDayLimit;
    }

    public Date getCheckDate() {
        return checkDate;
    }

    public void setCheckDate(Date checkDate) {
        this.checkDate = checkDate;
    }

    public String getCheckResult() {
        return checkResult;
    }

    public void setCheckResult(String checkResult) {
        this.checkResult = checkResult == null ? null : checkResult.trim();
    }

    public Date getRecheckDate() {
        return recheckDate;
    }

    public void setRecheckDate(Date recheckDate) {
        this.recheckDate = recheckDate;
    }

    public String getRecheckResult() {
        return recheckResult;
    }

    public void setRecheckResult(String recheckResult) {
        this.recheckResult = recheckResult == null ? null : recheckResult.trim();
    }

	public String getFeeType() {
		return feeType;
	}

	public void setFeeType(String feeType) {
		this.feeType = feeType;
	}
    
}