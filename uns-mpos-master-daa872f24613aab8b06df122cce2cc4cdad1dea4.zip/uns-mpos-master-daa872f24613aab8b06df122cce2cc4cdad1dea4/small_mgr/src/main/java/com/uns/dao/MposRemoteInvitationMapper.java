package com.uns.dao;

import java.math.BigDecimal;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.MposRemoteInvitation;
@Repository
public interface MposRemoteInvitationMapper {


    int deleteByPrimaryKey(BigDecimal remoteInvitationId);

    int insert(MposRemoteInvitation record);

    int insertSelective(MposRemoteInvitation record);

    MposRemoteInvitation selectByPrimaryKey(BigDecimal remoteInvitationId);

    int updateByPrimaryKeySelective(MposRemoteInvitation record);

    int updateByPrimaryKey(MposRemoteInvitation record);

	void updateByTel(Map map);
}