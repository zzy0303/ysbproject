package com.uns.web;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.service.BlackListService;
import com.uns.web.form.ShopPerbiForm;


@Controller("BlackListController")
@RequestMapping("/blackList.htm")
public class BlackListController extends BaseController {

	
	@Autowired
	private BlackListService blackListService;
	
	
	/**
	 * 添加黑名单
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=addBlacklist")
	public String addBlacklist(HttpServletRequest request, HttpServletResponse response) throws Exception {
	    try {
	    	String shopperpriId=request.getParameter("shopperpriId");
	    	if(StringUtils.isNotEmpty(shopperpriId)){
	    		blackListService.addBlacklist(shopperpriId);
	    	}
	    	request.setAttribute(Constants.MESSAGE_KEY,"添加商户黑名单成功");
		    request.setAttribute("url","shopPerbi.htm?method=shopFormalManageList");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.添加商户黑名单出错);
		}
	    return "/returnPage";
	}
	
	/**
	 * 查询商户黑名单
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=findBlacklist")
	public String findBlacklist(HttpServletRequest request, HttpServletResponse response,ShopPerbiForm mbForm) throws Exception {
	    try {
	    	List blackList=blackListService.findBlacklist(mbForm);
	    	request.setAttribute("blackList", blackList);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.查询商户黑名单出错);
		}
	    return "shopPerbi/blacklist";
	}
	
	
	/**
	 * 移除黑名单
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=removeBlacklist")
	public String removeBlacklist(HttpServletRequest request, HttpServletResponse response) throws Exception {
	    try {
	    	String shopperpriId=request.getParameter("shopperpriId");
	    	if(StringUtils.isNotEmpty(shopperpriId)){
	    		blackListService.removeBlacklist(shopperpriId);
	    	}
	    	request.setAttribute(Constants.MESSAGE_KEY,"移除商户黑名单成功");
		    request.setAttribute("url","blackList.htm?method=findBlacklist");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.移除商户黑名单出错);
		}
	    return "/returnPage";
	}
}
