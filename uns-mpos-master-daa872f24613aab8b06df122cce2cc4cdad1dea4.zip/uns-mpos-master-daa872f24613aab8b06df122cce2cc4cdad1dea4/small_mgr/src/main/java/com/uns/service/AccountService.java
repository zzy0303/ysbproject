package com.uns.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.exception.BusinessException;
import com.uns.common.page.PageContext;
import com.uns.dao.B2cSettleDetailMapper;
import com.uns.dao.B2cTerminalMapper;
import com.uns.model.B2cSettleDetail;
import com.uns.model.B2cTerminal;
import com.uns.web.form.AccountForm;


@Service
public class AccountService {
	
	@Autowired
	private B2cSettleDetailMapper b2cSettleDetailMapper;
	
	@Autowired
	private B2cTerminalMapper b2cTerminalMapper;
	/**查询结算统计信息汇总
	 * @param 
	 * @return
	 */
	public List selectByCountList(AccountForm accountForm){
		PageContext.initPageSize(8);
		List<HashMap> accountList=b2cSettleDetailMapper.selectHistoryList(accountForm);
		return accountList;
	}
	
	public List selectAllList(AccountForm accountForm){
		PageContext.initPageSize(5);
		List<HashMap> List=b2cSettleDetailMapper.selectAllList(accountForm);
		return List;
	}
	
	
	/**查询明细
	 * @param 
	 * @return
	 */
	public List selectDetailsList(AccountForm accountForm){
		PageContext.initPageSize(8);
		List<HashMap> List=b2cSettleDetailMapper.selectDetailsList(accountForm);
		return List;
	}
	
	/**下载结算
	 * @param 
	 * @return
	 */
	public List getAccountList(AccountForm accountForm) throws BusinessException, Exception
	{
		PageContext.initPageSize(3000);
		List<HashMap> List=b2cSettleDetailMapper.getAccountList(accountForm);
		if(List!=null && List.size()!=0)
		{
			return List;
		}
		return new ArrayList<B2cSettleDetail>();
	}
	/**下载银生宝结算
	 * @param 
	 * @return
	 */
	public List getysbList(AccountForm accountForm) throws BusinessException, Exception
	{
		PageContext.initPageSize(3000);
		List<HashMap> List=b2cSettleDetailMapper.getysbList(accountForm);
		if(List!=null && List.size()!=0)
		{
			return List;
		}
		return new ArrayList<B2cSettleDetail>();
	}
	
	/**下载汇总可结算信息
	 * @param 
	 * @return
	 */
	public List getNotAccountList(AccountForm accountForm) throws BusinessException, Exception
	{
		PageContext.initPageSize(3000);
		List<HashMap> List=b2cSettleDetailMapper.getNotAccountList(accountForm);
		if(List!=null && List.size()!=0)
		{
			return List;
		}
		return new ArrayList<B2cSettleDetail>();
	}

	public List outUnbalancedAcounntExcelList(
			AccountForm accountForm) {
		PageContext.initPageSize(3000);
		List<HashMap> List=b2cSettleDetailMapper.outUnbalancedAcounntExcelList(accountForm);
		if(List!=null && List.size()!=0)
		{
			return List;
		}
		return new ArrayList<B2cSettleDetail>();
	}

	public List getTermianl(String merchantNo) {
		return b2cTerminalMapper.getTerminByMerchantNo(merchantNo);
	}

	
}
