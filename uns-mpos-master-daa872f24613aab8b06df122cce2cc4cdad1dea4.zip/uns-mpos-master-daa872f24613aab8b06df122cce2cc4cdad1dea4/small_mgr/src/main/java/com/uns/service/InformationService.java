package com.uns.service;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.PageContext;
import com.uns.dao.B2cShopperbiMapper;
import com.uns.dao.MposSystemInformationMapper;
import com.uns.dao.SInfomationMerchantRelationMapper;
import com.uns.model.MposSystemInformation;
import com.uns.util.DateUtils;
import com.uns.util.HttpClientUtils;
import com.uns.web.form.InformationForm;

import net.sf.json.JSONObject;

@Service
public class InformationService {
	protected final Logger logger = Logger.getLogger(this.getClass());
	@Autowired
	private MposSystemInformationMapper mposSystemInformationMapper;

	@Autowired
	private SInfomationMerchantRelationMapper sInfomationMerchantRelationMapper;

	@Autowired
	private B2cShopperbiMapper b2cShopperbiMapper;

	public List findInformationList(InformationForm mbform) {
		PageContext.initPageSize(Constants.page_size);
		return mposSystemInformationMapper.findInformationList(mbform);
	}

	/**
	 * 批量插入：分页，每次10000条
	 * @throws InvocationTargetException
	 * @throws Exception
	 */
	public void insertSystemInformation(MposSystemInformation systemInformation) throws Exception{
		mposSystemInformationMapper.insertSelective(systemInformation);
		sInfomationMerchantRelationMapper.insertInfo(systemInformation.getId());
		//调用消息模块
		sendInfoToApp(systemInformation);
		
		/*List list=new ArrayList();
		list.add(systemInformation.getId());
		int merchantCount=b2cShopperbiMapper.findB2cShopperbiCount();
		int merchantCounts=ToolsUtils.Counts(merchantCount,Constants.BATCH_SIZE);
		for(int y=0;y<merchantCounts;y++){
	        int currentPage = Integer.valueOf(y+1);
	        Page page  = new Page();
	
	        PageContext context = PageContext.getContext();
	        page.setCurrentPage(currentPage);
	        BeanUtils.copyProperties(context, page);
	        context.setPageSize(Constants.BATCH_SIZE);
	        context.setPagination(true);
			List b2cShopperbiList=b2cShopperbiMapper.findB2cShopperbiList();
			
			list.add(b2cShopperbiList);
			
			for(int i=0;i<b2cShopperbiList.size();i++){
				Map map=(Map) b2cShopperbiList.get(i);
				SInfomationMerchantRelation sInfomationMerchantRelation=new SInfomationMerchantRelation();
				sInfomationMerchantRelation.setCreateDate(new Date());
				sInfomationMerchantRelation.setInformationId(systemInformation.getId());
				sInfomationMerchantRelation.setMerchantNo(map.get("MERCHANTNO")==null?null:Long.valueOf(map.get("MERCHANTNO").toString()));
				sInfomationMerchantRelation.setFlag(Constants.CON_YES);
				.insertSelective(sInfomationMerchantRelation);
			}
		}*/
	}
	/**
	 * 服务商保存相关信息
	 * @param systemInformation
	 * @throws Exception
	 */
	public void insertAgentInformation(MposSystemInformation systemInformation) throws Exception{
		mposSystemInformationMapper.insertSelective(systemInformation);
		sInfomationMerchantRelationMapper.insertAgentInfo(systemInformation.getId());
		//调用消息模块
		sendAgentInfoToApp(systemInformation);
	}

	/**
	 * 推送消息给代理商APP
	 * @param info
	 * @throws BusinessException
	 */
	private void sendAgentInfoToApp(MposSystemInformation info) throws BusinessException {
		Map pramsMap=new HashMap();
		if(info.getId()!=null){
			List infoMerchant=sInfomationMerchantRelationMapper.findSInfoMRelation(info.getId());
			pramsMap.put("text", info.getTheme());
			pramsMap.put("infoid", info.getId());
			pramsMap.put("agentNos", infoMerchant);
			pramsMap.put("msgDate", DateUtils.getTypeDate(info.getValidenddate(), "yyyyMMdd"));

			JSONObject obs = JSONObject.fromObject(pramsMap);
		    logger.info("代理商发送消息："+ ConstantsEnv.SYSTEM_AGENT_MESSAGES_URL+obs.toString());
		    String resultString =HttpClientUtils.REpostRequestStr(ConstantsEnv.SYSTEM_AGENT_MESSAGES_URL,obs.toString());

		}else{
			throw new BusinessException(ExceptionDefine.消息发送失败);
		}
	}

	/**
	 * 推送消息给商户APP
	 * @param info
	 * @throws BusinessException
	 */
	private void sendInfoToApp(MposSystemInformation info) throws BusinessException {
		Map pramsMap=new HashMap();
		if(info.getId()!=null){
			List infoMerchant=sInfomationMerchantRelationMapper.findSInfoMRelation(info.getId());
			pramsMap.put("text", info.getTheme());
			pramsMap.put("infoid", info.getId());
			pramsMap.put("smallMerchNos", infoMerchant);
			pramsMap.put("msgDate", DateUtils.getTypeDate(info.getValidenddate(), "yyyyMMdd"));

			JSONObject obs = JSONObject.fromObject(pramsMap);
		    logger.info("发送消息："+ ConstantsEnv.SYSTEM_MESSAGES_URL+obs.toString());
		    String resultString =HttpClientUtils.REpostRequestStr(ConstantsEnv.SYSTEM_MESSAGES_URL,obs.toString());
		}else{
			throw new BusinessException(ExceptionDefine.消息发送失败);
		}
	}
	/**
	 * 添加固码消息
	 * @param systemInformation
	 * @throws Exception
	 */
	public void insertQrcodeInformation(MposSystemInformation systemInformation) throws Exception{
		mposSystemInformationMapper.insertSelective(systemInformation);
	}


	public MposSystemInformation findInformationById(String informationId) {
		return mposSystemInformationMapper.findInformationById(Long.valueOf(informationId));
	}


	public void updateCloseSystemInformation(MposSystemInformation systemInformation) throws BusinessException {
		updateSystemInformation(systemInformation);
		sendCloseInfo(systemInformation);

	}

	private void sendCloseInfo(MposSystemInformation info) throws BusinessException {
		Map pramsMap=new HashMap();
		if(info.getId()!=null){
			pramsMap.put("infoid", info.getId());
			JSONObject obs = JSONObject.fromObject(pramsMap);
		    logger.info("关闭 发送消息："+ ConstantsEnv.CLOSE_MSG_URL+obs.toString());
		    String resultString =HttpClientUtils.REpostRequestStr(ConstantsEnv.CLOSE_MSG_URL,obs.toString());
		}else{
			throw new BusinessException(ExceptionDefine.消息发送失败);
		}

	}

	public void updateSystemInformation(MposSystemInformation systemInformation) {
		mposSystemInformationMapper.updateSystemInformation(systemInformation);

	}

	public void updateinformationCrontab() {

		mposSystemInformationMapper.updateinformationCrontab();
	}

	/**服务商消息管理查询模块
	 * @param request
	 * @param mbform
	 * @return
	 * @throws Exception
	 */
	public List findInformationAgentList(InformationForm mbForm) {
		PageContext.initPageSize(Constants.page_size);
		return mposSystemInformationMapper.findInformationAgentList(mbForm);
	}
	/**
	 * 关闭固码消息
	 * @param isQrcode
	 */
	public void updateQrcodeInformation(String isQrcode) {
		mposSystemInformationMapper.updateQrcodeInformation(isQrcode);

	}

	public String findQrcodeInformation() {
		return mposSystemInformationMapper.findQrcodeInformation();
	}


}
