package com.uns.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class B2cAgentSplitFees implements Serializable{
   
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private BigDecimal splitfeesid;
    private String settdate;
    private BigDecimal shopperid;
    private BigDecimal agentid;
    private BigDecimal agentpid;
    private BigDecimal levels;
    private BigDecimal mccid;
    private BigDecimal mccratio;
    private BigDecimal merratio;
    private BigDecimal basecast;
    private BigDecimal agtratio;
    private BigDecimal pdg;
    private Long cnt;
    private BigDecimal amt;
    private BigDecimal agtamt;
    private BigDecimal nextagtamt;
    private BigDecimal agtsplit;

	public BigDecimal getSplitfeesid() {
		return splitfeesid;
	}

	public void setSplitfeesid(BigDecimal splitfeesid) {
		this.splitfeesid = splitfeesid;
	}

	public String getSettdate() {
		return settdate;
	}

	public void setSettdate(String settdate) {
		this.settdate = settdate;
	}

	public BigDecimal getShopperid() {
		return shopperid;
	}

	public void setShopperid(BigDecimal shopperid) {
		this.shopperid = shopperid;
	}

	public BigDecimal getAgentid() {
		return agentid;
	}

	public void setAgentid(BigDecimal agentid) {
		this.agentid = agentid;
	}

	public BigDecimal getAgentpid() {
		return agentpid;
	}

	public void setAgentpid(BigDecimal agentpid) {
		this.agentpid = agentpid;
	}

	public BigDecimal getLevels() {
		return levels;
	}

	public void setLevels(BigDecimal levels) {
		this.levels = levels;
	}

	public BigDecimal getMccid() {
		return mccid;
	}

	public void setMccid(BigDecimal mccid) {
		this.mccid = mccid;
	}

	public BigDecimal getMccratio() {
		return mccratio;
	}

	public void setMccratio(BigDecimal mccratio) {
		this.mccratio = mccratio;
	}

	public BigDecimal getMerratio() {
		return merratio;
	}

	public void setMerratio(BigDecimal merratio) {
		this.merratio = merratio;
	}

	public BigDecimal getBasecast() {
		return basecast;
	}

	public void setBasecast(BigDecimal basecast) {
		this.basecast = basecast;
	}

	public BigDecimal getAgtratio() {
		return agtratio;
	}

	public void setAgtratio(BigDecimal agtratio) {
		this.agtratio = agtratio;
	}

	public BigDecimal getPdg() {
		return pdg;
	}

	public void setPdg(BigDecimal pdg) {
		this.pdg = pdg;
	}

	public Long getCnt() {
		return cnt;
	}

	public void setCnt(Long cnt) {
		this.cnt = cnt;
	}

	public BigDecimal getAmt() {
		return amt;
	}

	public void setAmt(BigDecimal amt) {
		this.amt = amt;
	}

	public BigDecimal getAgtamt() {
		return agtamt;
	}

	public void setAgtamt(BigDecimal agtamt) {
		this.agtamt = agtamt;
	}

	public BigDecimal getNextagtamt() {
		return nextagtamt;
	}

	public void setNextagtamt(BigDecimal nextagtamt) {
		this.nextagtamt = nextagtamt;
	}

	public BigDecimal getAgtsplit() {
		return agtsplit;
	}

	public void setAgtsplit(BigDecimal agtsplit) {
		this.agtsplit = agtsplit;
	}
    
    
    
    
}