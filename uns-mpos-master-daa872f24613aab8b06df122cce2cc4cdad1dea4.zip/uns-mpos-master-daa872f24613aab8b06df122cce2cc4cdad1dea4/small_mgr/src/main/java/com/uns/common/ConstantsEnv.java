package com.uns.common;

import com.uns.inf.acms.client.DynamicConfigLoader;

public class ConstantsEnv {

	public static final String HF_OPEN_FLG = DynamicConfigLoader.getByEnv("hf_open_flg");
	public static final String HF_KEY =DynamicConfigLoader.getByEnv("hf_key");
	public static final String HF_MERCHANT_URL = DynamicConfigLoader.getByEnv("hf_merchant_url");
	public static final String HF_USERSIGN = DynamicConfigLoader.getByEnv("hf_usersign");
	public static final String HF_ORGNO = DynamicConfigLoader.getByEnv("hf_orgno");
	public static final String HF_CODE_UPDATE = DynamicConfigLoader.getByEnv("hf_code_update");
	public static final String HF_CODE_ADD = DynamicConfigLoader.getByEnv("hf_code_add");
	public static final String SYSTEM_MESSAGES_URL = DynamicConfigLoader.getByEnv("system_messages_url");
	public static final String UPDATE_ACCOUNT_HFPSAM_URL = DynamicConfigLoader.getByEnv("update_account_hfpsam_url");
	public static final String ISTHIRDPOS = DynamicConfigLoader.getByEnv("hf_isthirdpos");
	public static final String MERCHANT_MODE = DynamicConfigLoader.getByEnv("hf_merchant_mode");
	public static final String SYSTEM_AGENT_MESSAGES_URL=DynamicConfigLoader.getByEnv("system_agent_messages_url");
	public static final String INSER_INTO_PHOTO = DynamicConfigLoader.getByEnv("photo.url");
	public static final String MPOS_UPDATE_MERCHANT=DynamicConfigLoader.getByEnv("mpos_update_merchant_url");
	//分润方案参数
	public static final String PROFIT_OWNER=DynamicConfigLoader.getByEnv("profit_owner_mgr");
	public static final String AGENT_PROFIT_RATIO=DynamicConfigLoader.getByEnv("agent_profit_ratio_mgr");
	public static final String MERCH_PROFIT1=DynamicConfigLoader.getByEnv("merch_profit1_mgr");
	public static final String MERCH_RATIO2_1=DynamicConfigLoader.getByEnv("merch_ratio2_1_mgr");
	public static final String MERCH_RATIO2_2=DynamicConfigLoader.getByEnv("merch_ratio2_2_mgr");
	public static final String MERCH_RATIO3_1=DynamicConfigLoader.getByEnv("merch_ratio3_1_mgr");
	public static final String MERCH_RATIO3_2=DynamicConfigLoader.getByEnv("merch_ratio3_2_mgr");
	public static final String MERCH_RATIO3_3=DynamicConfigLoader.getByEnv("merch_ratio3_3_mgr");
	public static final String UPDATE_PROFIT_URL = DynamicConfigLoader.getByEnv("update_profit_url");
	//黑名单
	public static final String BLACK_LIST_URL=DynamicConfigLoader.getByEnv("black_list_url");
	public static final String CLOSE_MSG_URL = DynamicConfigLoader.getByEnv("close_msg_url");

	public static final String MPOS_QRCODE_QUERY_CONFIG = DynamicConfigLoader.getByEnv("MPOS_QRCODE_QUERY_CONFIG");
	public static final String MPOS_QRCODE_UPDATE_CONFIG = DynamicConfigLoader.getByEnv("MPOS_QRCODE_UPDATE_CONFIG");
	
	public static final String UPDATEPHOTO = DynamicConfigLoader.getByEnv("update.photo");//image_pos更新图片接口
	
	/**
	 * 弘付图片报备socket IP 端口
	 */
	public static final String HF_IMAGE_REG_SOCKET_IP = DynamicConfigLoader.getByEnv("hf_image_reg_socket_ip");
	public static final int HF_IMAGE_REG_SOCKET_PORT = Integer.valueOf(DynamicConfigLoader.getByEnv("hf_image_reg_socket_port"));
	public static final String GET_HF_IMAGE_URL = DynamicConfigLoader.getByEnv("get_hf_image_url");
	
	public static final String SMS_CONTENT_OCR = DynamicConfigLoader.getByEnv("sms.content.url.ocr");

	public static final String HK_REPORT_URL = DynamicConfigLoader.getByEnv("hk_report_url");

	public static final String OPEN_CIB_REGISTER = DynamicConfigLoader.getByEnv("open_cib_register"); //上游通道报件开关

	public static final String QR_CODE_REG_PORT = DynamicConfigLoader.getByEnv("REG_QR_PAY_MERCHANT_URL"); //业务注册商户接口

	public static final String AGGREGATE_PAY_REG_PORT = DynamicConfigLoader.getByEnv("AGGREGATE_PAY_REG_URL"); //商户业务开通支付接口

    public static final String IMAGE_GET_URL = DynamicConfigLoader.getByEnv("imageget.url"); //获取图片地址

	public static final String BANK_SETTING_URL = DynamicConfigLoader.getByEnv("bank_setting_url"); //快捷银行设置模版下载地址

}
