package com.uns.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.PageContext;
import com.uns.dao.B2cTranhisMapper;
import com.uns.model.B2cTranhis;
import com.uns.web.form.TradeForm;

@Service
public class TradeService {
	@Autowired
	private B2cTranhisMapper tradeMapper;
	
	/**商户交易详情
	 * @param tranid
	 * @return
	 * @throws BusinessException
	 * @throws Exception
	 */
	public Map getTradeView(String tranid) throws BusinessException, Exception
	{
		
		if(StringUtils.isBlank(tranid))
		{
			throw new BusinessException(ExceptionDefine.交易流水的ID不存在);
		}
		List trades = tradeMapper.findTradeById(tranid);
		if(trades!=null && trades.size()==1)
		{
			return (Map) trades.get(0);
		}
		if(trades!=null && trades.size()>1)
		{
			throw new BusinessException(ExceptionDefine.交易流水重复);
		}		
		return new HashMap();
	}
	
	public List<String> getTerminalSb(String shopperid) throws BusinessException, Exception{
		
		if(StringUtils.isBlank(shopperid))
		{
			throw new BusinessException(ExceptionDefine.获取商户POS终端号失败无效商户号);
		}
		List<String> terminals = tradeMapper.getTerminalSb(shopperid);
		if(terminals!=null)
		{
			return terminals;
		}
		return new ArrayList<String>();
	}
	
	public List<B2cTranhis> findTradeSbList(TradeForm tradeForm) throws BusinessException, Exception
	{
		
		PageContext.initPageSize(20);
		List<B2cTranhis> trades = tradeMapper.findTradeSbList(tradeForm);
		if(trades!=null && trades.size()!=0)
		{
			return trades;
		}
		return new ArrayList<B2cTranhis>();
	}
	
	public List findTradeExcelSbList(TradeForm tradeForm) throws BusinessException, Exception
	{
		
		PageContext.initPageSize(3000);
		List<B2cTranhis> trades = tradeMapper.findTradeSbList(tradeForm);
		if(trades!=null && trades.size()!=0)
		{
			return trades;
		}
		return new ArrayList<B2cTranhis>();
	}
	//笔数
	public HashMap getb2cTranhis(TradeForm tradeForm) {
		return tradeMapper.getb2cTranhis(tradeForm);
		/*long onenum=0;
		long twonum=0;
		long threenum=0;
		long fournum=0;
		long fivenum=0;
		long sixnum=0;
		long sevnum=0;
		HashMap map=new HashMap();
		if(trades!=null&&trades.size()>0){
			for(int i=0;i<trades.size();i++){
				Map b2cTranhis=(Map)trades.get(i);
				if(b2cTranhis!=null){
					if(b2cTranhis.get("TRANTYPE").equals(Constants.TYPE_1)){
						onenum++;
					}	
					if(b2cTranhis.get("TRANTYPE").equals(Constants.TYPE_2)){
						twonum++;
					}
					if(b2cTranhis.get("TRANTYPE").equals(Constants.TYPE_3)){
						threenum++;
					}
					if(b2cTranhis.get("TRANTYPE").equals(Constants.TYPE_4)){
						fournum++;
					}
					if(b2cTranhis.get("TRANTYPE").equals(Constants.TYPE_5)){
						fivenum++;
					}
					if(b2cTranhis.get("TRANTYPE").equals(Constants.TYPE_6)){
						sixnum++;
					}
					if(b2cTranhis.get("TRANTYPE").equals(Constants.TYPE_7)){
						sevnum++;
					}
				}
				
			}
		}
		
		map.put("ONENUM", onenum);
		map.put("TWONUM", twonum);
		map.put("THREENUM", threenum);
		map.put("FOURNUM", fournum);
		map.put("FIVENUM", fivenum);
		map.put("SIXNUM", sixnum);
		map.put("SEVNUM", sevnum);
	 return  map;*/
	}

	public List<B2cTranhis> getTradeList(String terId) {
		PageContext.initPageSize(20);
		return tradeMapper.getTradeList(terId);
	}

	/**金额
	 * @param tradeForm
	 * @return
	 */
	public HashMap getb2cTranhisAmount(TradeForm tradeForm) {
		return tradeMapper.getb2cTranhisAmount(tradeForm);
	}
}	
