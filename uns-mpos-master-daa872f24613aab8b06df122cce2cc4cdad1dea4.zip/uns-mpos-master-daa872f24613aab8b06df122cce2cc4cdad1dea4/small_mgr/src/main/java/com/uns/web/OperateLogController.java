package com.uns.web;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.model.MtOperateLog;
import com.uns.service.OperateLogService;
import com.uns.web.form.OperateLogForm;

@Controller("OperateLogController")
@RequestMapping("/operatelog.htm")
public class OperateLogController {
	@Autowired
	private OperateLogService operatelogService;

	@RequestMapping(params = "method=toOperateLogList")
	public String toOperateLogList(HttpServletRequest request,OperateLogForm form, ModelMap modelMap){
		List<MtOperateLog> operatelog = operatelogService.selectAccesslogList(form);
		modelMap.put("operatelogs", operatelog);
		return "operatelog/operatelogList";
	}
	
	@RequestMapping(params = "method=toOperateLogDetail")
	public String toOperateLogDetail(HttpServletRequest request,OperateLogForm form,ModelMap modelMap){
		String logid = request.getParameter("logid");
		MtOperateLog log = operatelogService.selectByPrimaryKey(logid);
		modelMap.put("log", log);
		return "operatelog/operateLogDetail";
	}
}
