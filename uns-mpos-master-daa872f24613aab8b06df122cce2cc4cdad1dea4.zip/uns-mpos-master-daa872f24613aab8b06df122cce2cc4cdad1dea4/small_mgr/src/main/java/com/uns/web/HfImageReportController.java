package com.uns.web;

import com.uns.service.HfImageRegService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/3/15
 * @Modifyed By:
 */
@Controller
@RequestMapping(value = "/hfImageReport.htm")
public class HfImageReportController {

    @Autowired
    private HfImageRegService hfImageRegService;

    @ResponseBody
    @RequestMapping(params = "method=hfImageReport")
    public String hfImageReport() {
        try {
            hfImageRegService.hfImageReport();
        } catch (Exception e) {
            e.printStackTrace();
            return e.getMessage();
        }
        return "success";
    }

}
