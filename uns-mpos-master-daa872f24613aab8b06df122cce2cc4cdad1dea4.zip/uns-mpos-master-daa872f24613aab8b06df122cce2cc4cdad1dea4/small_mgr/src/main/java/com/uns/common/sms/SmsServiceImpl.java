package com.uns.common.sms;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.util.HTTP;
import com.uns.util.SmsReturnObj;

public class SmsServiceImpl {

	private String url;
	private String sname;
	private String spwd;
	private String ssrc;
	private String encode;
	private int maxlength;
	private String successCode;
	private Map returnMessage;
	
	
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSpwd() {
		return spwd;
	}
	public void setSpwd(String spwd) {
		this.spwd = spwd;
	}
	public String getSsrc() {
		return ssrc;
	}
	public void setSsrc(String ssrc) {
		this.ssrc = ssrc;
	}
	public String getEncode() {
		return encode;
	}
	public void setEncode(String encode) {
		this.encode = encode;
	}
	public int getMaxlength() {
		return maxlength;
	}
	public void setMaxlength(int maxlength) {
		this.maxlength = maxlength;
	}
	public String getSuccessCode() {
		return successCode;
	}
	public void setSuccessCode(String successCode) {
		this.successCode = successCode;
	}
	public Map getReturnMessage() {
		return returnMessage;
	}
	public void setReturnMessage(Map returnMessage) {
		this.returnMessage = returnMessage;
	}
	
	/**
	 * 封装发送对象
	 */
	protected Map populateSendData(String mobile, String content) {
		Map map = new HashMap();
		map.put("Sname", this.getSname());
		map.put("Spwd", this.getSpwd());
		map.put("Ssrc", this.getSsrc());
		map.put("Sdest", mobile);
		
		try {
			map.put("Smsg", URLEncoder.encode(content,this.getEncode()));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return map;
	}
	/**
	 * 封装返回对象
	 */
	protected SmsReturnObj populateRuturnData(String message) {
		int begin = message.indexOf("<Result>")+8;
		int end = message.indexOf("</Result>");
		String code = message.substring(begin, end);
		SmsReturnObj smsReturnObj = new SmsReturnObj();
		smsReturnObj.setReturnCode(code);
		smsReturnObj.setReturnMessage((String)returnMessage.get(code));
		return smsReturnObj;
	}
	/**
	 * 是否发送成功
	 */
	protected boolean isSuccess(SmsReturnObj smsReturnObj) {
		if(successCode.equals(smsReturnObj.getReturnCode())) {
			return true;
		} else {
			return false;
		}
	}
	public Map sendMessage(String[] distMobiles, String content) throws BusinessException {
		Map map = new HashMap();
		List successList = new ArrayList();//成功List
		List failureList = new ArrayList();//失败List
		map.put(Constants.SMS_SUCCESS_KEY,successList);
		map.put(Constants.SMS_FAILURE_KEY,failureList);

		for(int i=0;i<distMobiles.length;i++) {
			try {
				HTTP http = new HTTP();
				String mobile = distMobiles[i];
				String message = http.SendByURL(populateHttpUrl(mobile, content));
				System.out.println("返回值"+message);
				SmsReturnObj smsReturnObj = populateRuturnData(message);
				if(smsReturnObj == null) {
					smsReturnObj = new SmsReturnObj();
				}
				smsReturnObj.setMobile(mobile);
				smsReturnObj.setContent(content);
				if(isSuccess(smsReturnObj)) {
					successList.add(smsReturnObj);
				} else {
					failureList.add(smsReturnObj);
				}
				Thread.sleep(1000);
			} catch (Exception e) {
				throw new BusinessException(ExceptionDefine.短信通道错误);
			}
		}
		return map;
		
	}
	/**
	 * 构造请求的Url
	 * @return
	 */
	public String parseHttpHead() {
		return this.getUrl();
	}
	
	/**
	 * 构造Http形式的url地址
	 * @param mobile
	 * @param content
	 * @return
	 */
	private String populateHttpUrl(String mobile, String content) {
		StringBuffer sb = new StringBuffer();
		sb.append(parseHttpHead());
		sb.append(populateHttpParam(mobile,content));
		System.out.println("sb:"+sb.toString());
		return sb.toString();
	}

	/**
	 * 
	 * @return
	 */
	private String populateHttpParam(String mobile, String content) {
		Map map = populateSendData(mobile,content);
		return com.uns.util.SmsUtils.convertMap2String(map);
	}

}
