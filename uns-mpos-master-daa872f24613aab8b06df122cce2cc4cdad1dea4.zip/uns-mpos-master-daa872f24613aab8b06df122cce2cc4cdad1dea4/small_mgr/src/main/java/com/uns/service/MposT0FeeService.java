package com.uns.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.common.page.PageContext;
import com.uns.dao.MposT0FeeMapper;
import com.uns.model.MposT0Fee;
import com.uns.web.form.MposT0FeeForm;

@Service
public class MposT0FeeService {

	@Autowired
	private MposT0FeeMapper mposT0FeeMapper;
	
	public List findMposT0FeeList(MposT0FeeForm mbform) {
		PageContext.initPageSize(Constants.page_size);
		return mposT0FeeMapper.findMposT0FeeList(mbform);
	}

	public void insert(MposT0Fee mposT0Fee) {
		mposT0FeeMapper.insertSelective(mposT0Fee);
		
	}

	public MposT0Fee findMposT0ById(String t0feeId) {
		return mposT0FeeMapper.selectByPrimaryKey(Long.valueOf(t0feeId));
	}

}
