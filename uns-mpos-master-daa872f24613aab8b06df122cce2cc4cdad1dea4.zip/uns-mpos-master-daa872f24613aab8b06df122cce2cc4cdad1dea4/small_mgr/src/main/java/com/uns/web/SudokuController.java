package com.uns.web;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.jdbc.driver.Const;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.model.Agent;
import com.uns.model.AgentTopFee;
import com.uns.model.Area;
import com.uns.model.B2cDict;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.MposPhotoTmp;
import com.uns.model.UpdateFeeHistory;
import com.uns.service.SudokuService;
import com.uns.util.StringUtils;
import com.uns.web.form.ShopPerbiForm;
import com.uns.web.form.SudokuForm;

/**
 * 
 * 九宫格
 *
 */
@Controller("SudokuController")
@RequestMapping("/sudoku.htm")
public class SudokuController extends BaseController {
	
	
	@Autowired
	private SudokuService sudokuService;
	
	
	/**
	 * APP 九宫格控制
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=findAppSudoku")
	public String findAppSudoku(HttpServletRequest request,HttpServletResponse response) throws Exception {
        String topSudokuStr=sudokuService.findDictType(Constants.APP_TOP_SUDOKU);
		request.setAttribute("topSudoku", topSudokuStr);
		
		String mpostranTypeStr=sudokuService.findDictType(Constants.APP_MPOS_TRAN_TYPE);
		request.setAttribute("mposTranType", mpostranTypeStr);
			
		String smTranTypeStr=sudokuService.findDictType(Constants.APP_SM_TRAN_TYPE);
		request.setAttribute("smTranType", smTranTypeStr);
			
		String smPayFlagStr=sudokuService.findDictType(Constants.APP_SM_PAY_FLAG);
		request.setAttribute("smPayFlag", smPayFlagStr);
				
		String kjPayFlagStr=sudokuService.findDictType(Constants.APP_KJ_PAY_FLAG);
		request.setAttribute("kjPayFlag", kjPayFlagStr);

		return "sudoku/appsudoku";
	}
	
	
	/**
	 * 九空格修改
	 * @param request
	 * @param response
	 * @param sudokuForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=updateAppSudoku")
	public String updateAppSudoku(HttpServletRequest request,HttpServletResponse response,SudokuForm sudokuForm) throws Exception {
		try {
			sudokuForm.setMerchant_type(Constants.TYPE_0); //个人用户
			sudokuService.updateAppSudoku(sudokuForm);
			request.setAttribute(Constants.MESSAGE_KEY, "修改成功!");
			request.setAttribute("url", "sudoku.htm?method=findAppSudoku");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.APP九宫格控制修改出错);
		}
		
		
		return "/returnPage";
	}
	
	/**
	 * 商户平台控制
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=findMerSudoku")
	public String findMerSudoku(HttpServletRequest request,HttpServletResponse response) throws Exception {
		
	    String merSudokuStr=sudokuService.findDictType(Constants.MER_SUDOKU);
		request.setAttribute("merSudoku", merSudokuStr);
		
		String merSmtranTypeStr=sudokuService.findDictType(Constants.MER_SM_TRAN_TYPE);
		request.setAttribute("merSmtranType", merSmtranTypeStr);
			
		String merSmPayFlagStr=sudokuService.findDictType(Constants.MER_SM_PAY_FLAG);
		request.setAttribute("merSmPayFlag", merSmPayFlagStr);
		

		return "sudoku/mersudoku";
	}

	@RequestMapping(params = "method=updateMerSudoku")
	public String updateMerSudoku(HttpServletRequest request,HttpServletResponse response,SudokuForm sudokuForm) throws Exception {
		try {
			sudokuService.updateMerSudoku(sudokuForm);
			request.setAttribute(Constants.MESSAGE_KEY, "修改成功!");
			request.setAttribute("url", "sudoku.htm?method=findMerSudoku");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.商户控制修改出错);
		}
		
		
		return "/returnPage";
	}

	/**
	 * App商户版控制
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=findAppMerSudoku")
	public String findAppMerSudoku(HttpServletRequest request,HttpServletResponse response) throws Exception {

        String topSudokuStr=sudokuService.findDictType(Constants.APP_MER_SUDOKU);
        request.setAttribute("topSudoku", topSudokuStr);

        String mpostranTypeStr=sudokuService.findDictType(Constants.APP_MER_SM_TRAN_TYPE);
        request.setAttribute("mposTranType", mpostranTypeStr);

        String smTranTypeStr=sudokuService.findDictType(Constants.APP_MER_SM_PAY_FLAG);
        request.setAttribute("smTranType", smTranTypeStr);

        String smPayFlagStr=sudokuService.findDictType(Constants.APP_MER_SM_TRAN_FLAG);
        request.setAttribute("smPayFlag", smPayFlagStr);

		return "sudoku/appMerSudoku";
	}

	/**
	 * 商户APP九宫格控制修改
	 * @param request
	 * @param response
	 * @param sudokuForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=updateAppMerSudoku")
	public String updateAppMerSudoku(HttpServletRequest request,HttpServletResponse response,SudokuForm sudokuForm) throws Exception {
		try {
			//商户类型
			sudokuForm.setMerchant_type(Constants.TYPE_2);
			sudokuService.updateAppSudoku(sudokuForm);
			request.setAttribute(Constants.MESSAGE_KEY, "修改成功!");
			request.setAttribute("url", "sudoku.htm?method=findAppMerSudoku");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.商户控制修改出错);
		}


		return "/returnPage";
	}
}
