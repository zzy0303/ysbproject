package com.uns.util;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.model.Area;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.MposPhoto;
import com.uns.model.MposPhotoTmp;
import com.uns.service.ReCheckService;
import com.uns.service.SendMessageService;
import com.uns.service.ShopPerbiService;

import net.sf.json.JSONObject;
import oracle.jdbc.driver.Const;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 注册mpos和扫码
 */
@Component
public class RegMposAndQrcode {

    protected Log log = LogFactory.getLog(this.getClass());

    protected final Logger logger = Logger.getLogger(this.getClass());

    @Autowired
    private SendMessageService sendmessageService;
    
    @Autowired
    private ReCheckService reCheckService;

    @Autowired
    private ShopPerbiService shopPerbiService;
  
  
    
    /**
     *
     * 1.调用功能平台的注册接口，注册成功激活账户。
     * 2.注册成功，发送短信验证码。
     *
     * @param b2cShopperbi
     * @param request
     * @throws Exception
     */
    public void regMposMerchant(B2cShopperbiTemp b2cShopperbi,
			HttpServletRequest request) throws Exception {

        String password="";
        if((!(b2cShopperbi.getReportResource().equals("3")))&&b2cShopperbi.getShopperidP()!=null){
            password=RandomStringUtils.randomNumeric(6);
            b2cShopperbi.setMpassword(Md5Encrypt.md5(password));
        }
        //代理商注册
        String merchantKey=com.uns.util.StringUtils.getCharAndNumr(8);
        b2cShopperbi.setMerchantKey(merchantKey);

        if(null != b2cShopperbi.getShopperidP() &&
                null == b2cShopperbi.getIfactivated()){//如果商户没有激活
            //激活mpos
            Map activateMap=activateMerchantPort(b2cShopperbi);
            logger.info("激活账户返回码:"+activateMap);
            JSONObject ob= JSONObject.fromObject(activateMap);
            String rspCode=(String)ob.get("rspCode");
            String rspMsg=(String)ob.get("rspMsg");

            //激活扫码
            Map qrPayactivateMap=activateQrPayMerchantPort(b2cShopperbi);
            JSONObject qrpay= JSONObject.fromObject(qrPayactivateMap);
            String qrpayRspCode=(String)qrpay.get("rspCode");
            if(!Constants.RESPONSE_CODE.equals(rspCode) || !Constants.RESPONSE_CODE.equals(qrpayRspCode)){
                throw new BusinessException(ExceptionDefine.激活商户失败,new String[]{rspMsg});
            }
            b2cShopperbi.setTransact(Constants.TYPE_2);//已激活
        }
        b2cShopperbi.setIsformal(new Short(Constants.CON_YES));//0表示非正式商户，1表示审核过的正式商户

        //没有贷记卡信息则设置贷记卡状态为未提交通过
        if (org.apache.commons.lang.StringUtils.isEmpty(b2cShopperbi.getCreditBankNo())) {
            b2cShopperbi.setNotPassStep(Constants.NOT_PASS_STEP_ALL_PASS_NO_CREDIT_CARD);
        } else {
            b2cShopperbi.setNotPassStep(Constants.NOT_PASS_STEP_ALL_PASS);
        }
        b2cShopperbi.setIfvalid(Short.valueOf(Constants.TYPE_1));//初审通过
        b2cShopperbi.setRecheckmerchantflag(Constants.TYPE_1);//复审通过
        b2cShopperbi.setNotPassReason(null);
        b2cShopperbi.setIfactivated(Constants.CON_YES);
        b2cShopperbi.setIfactivadate(new Date());
        b2cShopperbi.setTransact(Constants.TYPE_2);//已激活
        shopPerbiService.updateShopperManualaudit(b2cShopperbi);//更新预约信息
        shopPerbiService.updateShopperFormalByTemp(b2cShopperbi);//更新正式信息
        shopPerbiService.updateShopperFee(String.valueOf(b2cShopperbi.getShopperid()));//更新商户正式费率
        shopPerbiService.updateShopperPhoto(b2cShopperbi);//更新商户照片
        shopPerbiService.saveOrUpdateProgress(b2cShopperbi,Constants.TYPE_4);//更新进度
        //发送短信
        sendmessageService.sendMessageOCR(b2cShopperbi);
        request.setAttribute(Constants.MESSAGE_KEY,"审核成功!");

    }

    /**判断注册商户是否绑定银生宝账号
     * @param request
     * @param b2cShopperbi
     * @param userType
     * @throws Exception
     */
    private String saveCreate(HttpServletRequest request, B2cShopperbiTemp b2cShopperbi, String userType) throws Exception {

        JSONObject ob=null;
        String rspCode="";
        String ysbNo="";
        String factoringNo="";
        //区分企业还是个人
        Map ysbMap=null;
        if(Constants.TYPE_P.equals(userType)){
            ysbMap=regMerchant(b2cShopperbi,userType);
        }
        if(Constants.TYPE_C.equals(userType)){
            ysbMap=regCompany(b2cShopperbi,userType);
        }
        logger.info("银生宝注册返回码:"+ysbMap);
        ob= JSONObject.fromObject(ysbMap);
        rspCode=(String)ob.get("rspCode");
        String rspMsg=(String)ob.get("rspMsg");
        if(Constants.RESPONSE_CODE.equals(rspCode)){

            //注册扫码支付
            Map qrPayMap=saveQrPay(request,b2cShopperbi,userType);

            if(Constants.RESPONSE_CODE.equals(qrPayMap.get("rspCode"))){
                ysbNo=(String)ob.get("userId");
                factoringNo=(String)ob.get("factor_userId");
                b2cShopperbi.setYsbNo(ysbNo);
                b2cShopperbi.setFactoringno(factoringNo);
                b2cShopperbi.setOpen_mpos_create_date(new Date());
                b2cShopperbi.setQrPayNo(qrPayMap.get("qrPayNo")==null?"":qrPayMap.get("qrPayNo").toString());
                b2cShopperbi.setQrpayMerchantkey(qrPayMap.get("qrpayMerchantkey")==null?"":qrPayMap.get("qrpayMerchantkey").toString());

                saveB2cShopperbi(request,b2cShopperbi);
                return rspCode;
            }
            else{
                throw new BusinessException(ExceptionDefine.注册银生宝失败,new String[]{"注册扫码支付"});
            }

        }else{
            if(rspCode.equals("6012")){
                throw new BusinessException(ExceptionDefine.注册银生宝失败,new String[]{rspMsg});
            }else{
                throw new BusinessException(ExceptionDefine.注册银生宝失败,new String[]{"注册银生宝"});
            }
        }
    }

    /**转化商户类型
     * @param merchantType
     * @return
     */
    private String getType(String merchantType) {
        String type="";
        if(Constants.CON_NO.equals(merchantType)){
            type=Constants.TYPE_P;
        }else{
            type=Constants.TYPE_C;
        }
        return type;
    }

    /**
     * 激活商户
     * @throws BusinessException
     */
    private Map activateMerchantPort(B2cShopperbiTemp b2cShopperbi) throws Exception {
        HashMap params=new HashMap();

        Date dates = new Date();
        String mradom = RandomStringUtils.randomNumeric(6);
        String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbi.getB2cShopperbiId();
        String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");

        params.put("orderId", orderId);
        params.put("userId", b2cShopperbi.getYsbNo());
        params.put("activeStatus", Constants.TYPE_2);//已激活

        JSONObject obs = JSONObject.fromObject(params);
        String request = "activeStatus=" + Constants.TYPE_2 + "&orderId="+orderId+"&userId="+ b2cShopperbi.getYsbNo() ;
        log.info("请求激活银生宝账号请求参数："+request);
        log.info("请求激活银生宝账号："+DynamicConfigLoader.getByEnv("update_user_status_url")+request);
        String result = HttpClientUtils.REpostRequestStrNormal(DynamicConfigLoader.getByEnv("update_user_status_url"), request);
        Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(result);

        return resultMap;

    }

    /**扫码支付激活
     * @param b2cShopperbi
     * @return
     * @throws Exception
     */
    private Map activateQrPayMerchantPort(B2cShopperbiTemp b2cShopperbi) throws Exception {

        HashMap params=new HashMap();

        Date dates = new Date();
        String mradom = RandomStringUtils.randomNumeric(6);
        String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbi.getB2cShopperbiId();
        String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");

        params.put("orderId", orderId);
        params.put("userId", b2cShopperbi.getQrPayNo());
        params.put("activeStatus", Constants.TYPE_2);//已激活

        JSONObject obs = JSONObject.fromObject(params);
        String request = "activeStatus=" + Constants.TYPE_2 + "&orderId="+orderId+"&userId="+ b2cShopperbi.getQrPayNo();
        log.info("请求激活扫码支付账号："+DynamicConfigLoader.getByEnv("update_qrpay_user_status_url")+request.toString());
        String result = HttpClientUtils.REpostRequestStrNormal(DynamicConfigLoader.getByEnv("update_qrpay_user_status_url"), request);

        Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(result);
        log.info("请求激活扫码支付账号返回码："+resultMap.toString());
        return resultMap;
    }

    /**个人商户注册（注册参数）
     * @param b2cShopperbi
     * @return
     * @throws Exception
     */
    private Map regMerchant(B2cShopperbiTemp b2cShopperbi,String userTypes) throws Exception {
        HashMap params=new HashMap();

        Date dates = new Date();
        String mradom = RandomStringUtils.randomNumeric(6);
        String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbi.getB2cShopperbiId();
        String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");
        //基本信息
        String userType=userTypes;
        String linkName=b2cShopperbi.getName();
        String idCard=b2cShopperbi.getIDNo();
        String tel=b2cShopperbi.getStel();
        String merchantNo=b2cShopperbi.getShopperid()==null?"":b2cShopperbi.getShopperid().toString();
        Long agentNo=b2cShopperbi.getShopperidP();
        String institutionNo=b2cShopperbi.getOrgNo();
        String platformType="";
        if(agentNo!=null){
            platformType=Constants.CON_NO;//0 自有
        }else{
            platformType=Constants.CON_YES;//机构
        }
        //结算信息
        //String settlementType=b2cShopperbi.getSettlementType();
        String accountbankname=b2cShopperbi.getAccountbankname();
        String accountbankprovCode=b2cShopperbi.getAccountBankProvCode();
        String accountBankCityCode=b2cShopperbi.getAccountBankCityCode();
        String accountbankclientname=b2cShopperbi.getAccountbankclientname();
        String accountbankno=b2cShopperbi.getAccountbankno();
        // String CardType=b2cShopperbi.getCardType();
        //刷卡手续费
        List merchantFeeList=shopPerbiService.findMerchantFeeByMpos(b2cShopperbi.getShopperid());
        //T+1提现手续费
        // Double t1fee=b2cShopperbi.getT1fee();


        //t1type
        params.put("t1Type", b2cShopperbi.getT1type()==null?"0":b2cShopperbi.getT1type());
        //params.put("t1fee", b2cShopperbi.getT1fee()==null?"0":b2cShopperbi.getT1fee());
        params.put("t1topamount",b2cShopperbi.getT1topamount()==null?"0":b2cShopperbi.getT1topamount());

        //t+0手续费
        String issupportt0=b2cShopperbi.getIsSupportT0(); //0支持
        Double t0singledaylimit=0.00;
        if(Constants.CON_NO.equals(issupportt0)){
            //isicapplyt0=b2cShopperbi.getIsIcApplyT0();
            t0singledaylimit=b2cShopperbi.getT0SingleDayLimit();
            // params.put("isicapplyt0", isicapplyt0==null?"":isicapplyt0);
            params.put("t0Type", b2cShopperbi.getT0type()==null?"0":b2cShopperbi.getT0type());
            params.put("t0fee", Constants.D0_FEE);
            params.put("t0fixedamount", Constants.T0_FIXED_AMOUNT);
            params.put("t0topamount", b2cShopperbi.getT0topamount()==null?"":b2cShopperbi.getT0topamount());
            // params.put("t0additionfee",b2cShopperbi.getT0additionfee()==null?"":b2cShopperbi.getT0additionfee()); 
            params.put("t0minamount", b2cShopperbi.getT0minamount());
            params.put("t0maxamount", b2cShopperbi.getT0maxamount());
            params.put("creditAmount", t0singledaylimit==null?"":t0singledaylimit);
        }else{
            // params.put("isicapplyt0","");
            params.put("t0Type","0");
            params.put("t0fee","");
            params.put("t0fixedamount","");
            params.put("t0topamount","");
            // params.put("t0additionfee",""); 
            params.put("t0minamount","");
            params.put("t0maxamount","");
            params.put("creditAmount",Constants.CON_NO);
        }
        params.put("userType", userType==null?"":userType);
        params.put("orderId", orderId==null?"":orderId);
        params.put("orderTime", orderTime==null?"":orderTime);
        params.put("name", linkName==null?"":URLDecoder.decode(linkName,"UTF-8"));
        params.put("idNum", idCard==null?"":idCard);
        params.put("mobilePhoneNum", tel==null?"":tel);
        String bankCode=shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval())==null?"":URLDecoder.decode(shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval()).getDictid(),"UTF-8");
        params.put("bankCode", bankCode==null?"":bankCode);
        params.put("bankNo", accountbankno==null?"":accountbankno);
        params.put("bankName", accountbankname==null?"":URLDecoder.decode(accountbankname,"UTF-8"));
        params.put("prov", accountbankprovCode==null?"":accountbankprovCode);
        params.put("city", accountBankCityCode==null?"":accountBankCityCode);

        params.put("merchantNo", merchantNo==null?"":merchantNo);
        params.put("proxyId", agentNo==null?"":agentNo);
        params.put("institutionNo", institutionNo==null?"":institutionNo);
        params.put("platformType", platformType==null?"":platformType);
        // params.put("settlementType", settlementType==null?"":settlementType);

        params.put("commissionIds", merchantFeeList);
        params.put("issupportt0", issupportt0==null?"":issupportt0);//是否支持T0提现

        params.put("scompany", b2cShopperbi.getName());
        params.put("agentNo", b2cShopperbi.getShopperidP());
        params.put("terminalNo", b2cShopperbi.getHfpsam());
        //分润方案
        params.put("profitOwner", b2cShopperbi.getProfitOwner());//分润给那个代理商
        params.put("agentProfitRatio", b2cShopperbi.getAgentProfitRatio()); //代理商分润百分比
        params.put("merchProfitRatio1", b2cShopperbi.getMerchProfitRatio1());//商户分润方案1
        params.put("merchProfitRatio2", b2cShopperbi.getMerchProfitRatio2()); //商户分润方案2
        params.put("merchProfitRatio3", b2cShopperbi.getMerchProfitRatio3()); //商户分润方案3


        JSONObject obs = JSONObject.fromObject(params);
        log.info("注册银生宝个人："+ DynamicConfigLoader.getByEnv("simple_register_url")+obs.toString());
        String resultString =HttpClientUtils.REpostRequestStr( DynamicConfigLoader.getByEnv("simple_register_url"),obs.toString());
        Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);

        return resultMap;
    }

    /**注册企业
     * @param b2cShopperbi
     * @param userType
     * @return
     * @throws Exception
     */
    private Map regCompany(B2cShopperbiTemp b2cShopperbi, String userType) throws Exception {
        HashMap params=new HashMap();
        Date dates = new Date();
        String mradom = RandomStringUtils.randomNumeric(6);
        String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbi.getB2cShopperbiId();
        String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");

        //基本信息
        String name=b2cShopperbi.getName();
        String idCard=b2cShopperbi.getIDNo();
        String tel=b2cShopperbi.getStel();
        String merchantNo=b2cShopperbi.getShopperid()==null?"":b2cShopperbi.getShopperid().toString();
        Long agentNo=b2cShopperbi.getShopperidP();
        String institutionNo=b2cShopperbi.getOrgNo();
        String platformType="";
        if(agentNo!=null){
            platformType=Constants.CON_NO;//0 自有
        }else{
            platformType=Constants.CON_YES;//机构
        }
        //结算信息
//        String settlementType=b2cShopperbi.getSettlementType();
        String accountBankDictval=b2cShopperbi.getAccountbankdictval();
        String accountbankname=b2cShopperbi.getAccountbankname();
        String accountbankprovCode=b2cShopperbi.getAccountBankProvCode();
        String accountBankCityCode=b2cShopperbi.getAccountBankCityCode();
        String accountbankclientname=b2cShopperbi.getAccountbankclientname();
        String accountbankno=b2cShopperbi.getAccountbankno();
//        String CardType=b2cShopperbi.getCardType();
        //T+1提现手续费
//        Double t1fee=b2cShopperbi.getT1fee();
        //T+1封顶值
//        String t1topamount="";
        //刷卡手续费
        List merchantFeeList=shopPerbiService.findMerchantFeeByMpos(b2cShopperbi.getShopperid());

        //t1type
        params.put("t1Type", b2cShopperbi.getT1type()==null?"0":b2cShopperbi.getT1type());
//     	params.put("t1fee", b2cShopperbi.getT1fee()==null?"0":b2cShopperbi.getT1fee());//t+1提现手续费费率
        params.put("t1topamount", b2cShopperbi.getT1topamount()==null?"0":b2cShopperbi.getT1topamount());//t+1提现手续费

        //t+0手续费
        String issupportt0=b2cShopperbi.getIsSupportT0(); //0支持
//        String isicapplyt0="";
        Double t0singledaylimit=0.00;
        if(Constants.CON_NO.equals(issupportt0)){
//        	  isicapplyt0=b2cShopperbi.getIsIcApplyT0();
            t0singledaylimit=b2cShopperbi.getT0SingleDayLimit();
//              params.put("isicapplyt0", isicapplyt0==null?"":isicapplyt0);
            params.put("t0Type", b2cShopperbi.getT0type()==null?"0":b2cShopperbi.getT0type());
            params.put("t0fee", Constants.D0_FEE);
            params.put("t0fixedamount", Constants.T0_FIXED_AMOUNT);
            params.put("t0topamount", b2cShopperbi.getT0topamount()==null?"":b2cShopperbi.getT0topamount());
//              params.put("t0additionfee",b2cShopperbi.getT0additionfee()==null?"":b2cShopperbi.getT0additionfee()); 
            params.put("t0minamount", b2cShopperbi.getT0minamount());
            params.put("t0maxamount", b2cShopperbi.getT0maxamount());
            params.put("creditAmount", t0singledaylimit==null?"":t0singledaylimit);
            params.put("t0singledaylimit", t0singledaylimit==null?"":t0singledaylimit);
        }else{
//        	 params.put("isicapplyt0","");
            params.put("t0Type","0");
            params.put("t0fee","");
            params.put("t0fixedamount","");
            params.put("t0topamount","");
//             params.put("t0additionfee",""); 
            params.put("t0minamount","");
            params.put("t0maxamount","");
            params.put("creditAmount",Constants.CON_NO);
            params.put("t0singledaylimit","");
        }
        params.put("userType", userType==null?"":userType);
        params.put("orderId", orderId==null?"":orderId);
        params.put("orderTime", orderTime==null?"":orderTime);
        params.put("idNum", idCard==null?"":idCard);
        params.put("register_corpTel", tel==null?"":tel);
        params.put("register_prinName",  URLDecoder.decode(name==null?"":name,"UTF-8"));
        params.put("prov", accountbankprovCode==null?"":accountbankprovCode);
        params.put("city", accountBankCityCode==null?"":accountBankCityCode);
        String bankCode=shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval())==null?"":URLDecoder.decode(shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval()).getDictid(),"UTF-8");
        params.put("bankCode", bankCode);
        params.put("bankNo", accountbankno==null?"":accountbankno);
        params.put("bankName", accountbankname==null?"":URLDecoder.decode(accountbankname,"UTF-8"));
        params.put("register_corpFinanceName", URLDecoder.decode(name,"UTF-8"));
        params.put("linkman", name==null?"":URLDecoder.decode(name,"UTF-8"));
        params.put("register_corpLicenceNo",b2cShopperbi.getLicenseNo()==null?"":b2cShopperbi.getLicenseNo());
        params.put("register_corpName", accountbankclientname==null?"":URLDecoder.decode(accountbankclientname,"UTF-8"));
        params.put("register_email",b2cShopperbi.getSemail()==null?"":b2cShopperbi.getSemail());
        params.put("register_corpAccountLicenceNo",b2cShopperbi.getLicenseNo()==null?"":b2cShopperbi.getLicenseNo());
        params.put("register_corpOrganizeNo",b2cShopperbi.getLicenseNo()==null?"":b2cShopperbi.getLicenseNo());
        params.put("register_corpTaxId",b2cShopperbi.getLicenseNo()==null?"":b2cShopperbi.getLicenseNo());
        params.put("register_corpAddr", b2cShopperbi.getSaddress()==null?"":URLDecoder.decode(b2cShopperbi.getSaddress(),"UTF-8"));
        params.put("register_corpZip",b2cShopperbi.getSzip()==null?"":b2cShopperbi.getSzip());
        params.put("proxyId", agentNo==null?"":agentNo);
        params.put("merchantNo", merchantNo==null?"":merchantNo);
        params.put("institutionNo", institutionNo==null?"":institutionNo);
        //params.put("platformType", platformType);
//        params.put("settlementType", settlementType==null?"":settlementType);
        params.put("commissionIds", merchantFeeList);
        // params.put("CardType", CardType);

        params.put("issupportt0", issupportt0==null?"":issupportt0);//是否支持T0提现

        params.put("scompany", b2cShopperbi.getScompany());
        params.put("agentNo", b2cShopperbi.getShopperidP());
        params.put("terminalNo", b2cShopperbi.getHfpsam());
        //分润方案
        params.put("profitOwner", b2cShopperbi.getProfitOwner());//分润给那个代理商
        params.put("agentProfitRatio", b2cShopperbi.getAgentProfitRatio()); //代理商分润百分比
        params.put("merchProfitRatio1", b2cShopperbi.getMerchProfitRatio1());//商户分润方案1
        params.put("merchProfitRatio2", b2cShopperbi.getMerchProfitRatio2()); //商户分润方案2
        params.put("merchProfitRatio3", b2cShopperbi.getMerchProfitRatio3()); //商户分润方案3

        JSONObject obs = JSONObject.fromObject(params);
        log.info("注册银生宝企业："+DynamicConfigLoader.getByEnv("simple_register_company_url")+obs.toString());
        String resultString =HttpClientUtils.REpostRequestStr(DynamicConfigLoader.getByEnv("simple_register_company_url"),obs.toString());
        Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);

        return resultMap;
    }

    /**扫码支付
     * @param request
     * @param b2cShopperbi
     * @param userType
     * @return
     * @throws Exception
     */
    private Map saveQrPay(HttpServletRequest request,
                          B2cShopperbiTemp b2cShopperbi, String userType) throws Exception {
        String qrpayMerchantkey=RandomStringUtils.random(32, "0123456789ABCDEF");
        b2cShopperbi.setQrpayMerchantkey(qrpayMerchantkey);
        Map map=new HashMap();
        String flag="";
        JSONObject ob = null;
        String rspCode = "";
        String qrPayNo="";
        // 区分企业还是个人
        Map ysbMap = null;
        if (Constants.TYPE_P.equals(userType)) {
            ysbMap = regQrPayMerchant(b2cShopperbi, userType);
        }
        if (Constants.TYPE_C.equals(userType)) {
            ysbMap = regQrPayCompany(b2cShopperbi, userType);
        }
        logger.info("扫码支付注册返回码:" + ysbMap);
        ob = JSONObject.fromObject(ysbMap);
        rspCode = (String) ob.get("rspCode");
        if (Constants.RESPONSE_CODE.equals(rspCode)) {
            qrPayNo = (String) ob.get("userId");

            map.put("qrPayNo", qrPayNo);
            map.put("qrpayMerchantkey", qrpayMerchantkey);
            map.put("rspCode", rspCode);
            return map;
        } else {
            logger.info("扫码支付实名认证失败（6012）！");
            map.put("rspCode", rspCode);
            return map;
        }

    }

    /**
     * 2.子账户：注册收单
     * 3.注册收单：手续费传list
     * @param request
     * @param b2cShopperbi
     * @throws Exception
     */
    private void saveB2cShopperbi(HttpServletRequest request,
                                  B2cShopperbiTemp b2cShopperbi) throws Exception {
        reCheckService.saveMerchant(b2cShopperbi);
        request.setAttribute(Constants.MESSAGE_KEY,"审核成功!");
    }

    /**扫码支付
     * @param b2cShopperbi
     * @param userType
     * @return
     * @throws Exception
     */
    private Map regQrPayMerchant(B2cShopperbiTemp b2cShopperbi, String userType) throws Exception {

        HashMap params = new HashMap();

        Date dates = new Date();
        String mradom = RandomStringUtils.randomNumeric(6);
        String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom+ b2cShopperbi.getShopperid();
        String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");
        // 基本信息
        String linkName = b2cShopperbi.getName();
        String idCard = b2cShopperbi.getIDNo();
        String tel = b2cShopperbi.getStel();
        String merchantNo = b2cShopperbi.getShopperid() == null ? "": b2cShopperbi.getShopperid().toString();
        Long agentNo = b2cShopperbi.getShopperidP();
        String institutionNo = b2cShopperbi.getOrgNo();
        String platformType = "";
        if (agentNo != null) {
            platformType = Constants.CON_NO;// 0 自有
        } else {
            platformType = Constants.CON_YES;// 机构
        }
        // 结算信息 accountbankdictval
        String settlementType = b2cShopperbi.getSettlementType();
        String accountbankname = b2cShopperbi.getAccountbankname();//支行
        String accountbankprovCode = b2cShopperbi.getAccountBankProvCode();
        String accountBankCityCode = b2cShopperbi.getAccountBankCityCode();
        String accountbankclientname = b2cShopperbi.getAccountbankclientname();
        String accountbankno = b2cShopperbi.getAccountbankno();
        //省市
        String accountBankCity = b2cShopperbi.getAccountBankCity();
        String accountbankprov = b2cShopperbi.getAccountbankprov();
        // 扫码支付
        List merchantFeeList = shopPerbiService.findQrPayMerchantFeeList(b2cShopperbi.getShopperid().toString());

        String qrD0fee=shopPerbiService.findQrPayMerchantFee(b2cShopperbi.getShopperid().toString());
        // t+0手续费
        String issupportt0 = b2cShopperbi.getIsSupportT0(); // 0支持
        String isicapplyt0 = "";
        Double t0singledaylimit = 0.00;
        if (Constants.CON_NO.equals(issupportt0)) {
            isicapplyt0 = b2cShopperbi.getIsIcApplyT0();
            t0singledaylimit = b2cShopperbi.getT0SingleDayLimit();
            params.put("t0fee", qrD0fee);
            params.put("t0fixedamount", b2cShopperbi.getT0fixedamount());
            params.put("t0minamount", b2cShopperbi.getT0minamount());
            params.put("t0maxamount", b2cShopperbi.getT0maxamount());
            params.put("creditAmount", t0singledaylimit == null ? "": t0singledaylimit);
        } else {
            params.put("t0fee", "0");
            params.put("t0fixedamount", "0");
            params.put("t0minamount", "0");
            params.put("t0maxamount", "0");
            params.put("creditAmount", "0");
        }
        params.put("userType", userType == null ? "" : userType);
        params.put("orderId", orderId == null ? "" : orderId);
        params.put("orderTime", orderTime == null ? "" : orderTime);
        params.put("name",linkName == null ? "" : URLDecoder.decode(linkName, "UTF-8"));
        params.put("idNum", idCard == null ? "" : idCard);
        params.put("mobilePhoneNum", tel == null ? "" : tel);
        String bankCode=shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval())==null?"":URLDecoder.decode(shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval()).getDictid(),"UTF-8");
        params.put("bankCode", bankCode == null ? "" : bankCode);
        params.put("bankNo", accountbankno == null ? "" : accountbankno);
        params.put("bankName",accountbankname == null ? "" : URLDecoder.decode(accountbankname, "UTF-8"));
        params.put("prov", accountbankprovCode == null ? "": accountbankprovCode);
        params.put("city", accountBankCityCode == null ? "": accountBankCityCode);
        params.put("cityName",accountBankCity);
        params.put("provinceName",accountbankprov);
        //开户银行
        String openingBankName=shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval())==null?"":shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval()).getDict();
        params.put("openingBankName",openingBankName);
        params.put("merchantNo", merchantNo == null ? "" : merchantNo);
        params.put("proxyId", agentNo == null ? "" : agentNo);
        params.put("institutionNo", institutionNo == null ? "" : institutionNo);
        params.put("platformType", platformType == null ? "" : platformType);

        params.put("commissionIds", merchantFeeList);
        params.put("issupportt0", issupportt0 == null ? "" : issupportt0);// 是否支持T0提现

        String scompany = b2cShopperbi.getScompany();
        String qrMerchantKey =b2cShopperbi.getQrpayMerchantkey();
        params.put("scompany",null==scompany ?"" :scompany );
        params.put("qrMerchantKey",null==qrMerchantKey ?"" : qrMerchantKey );
        params.put("agentNo", null==agentNo?"":agentNo);

        //固码信息
        MposPhotoTmp photo=this.shopPerbiService.selectPhotoTmpById(b2cShopperbi.getPhotoid());
        params.put("fixQrcodePic", photo==null?"":photo.getFixphoto());
        params.put("fixQrcodeCustomerName", b2cShopperbi.getFixqrcodecustomername());
        params.put("isExternalRevenue", b2cShopperbi.getIsexternalrevenue());
        params.put("settleType", b2cShopperbi.getSettleType());//默认结算方式1普通0快速
        params.put("creditLines", b2cShopperbi.getCreditLines().toString());//授信额度
        //分润方案
        params.put("agentProfitRatio", b2cShopperbi.getAgentProfitRatio());//服务商分润
        params.put("profitOwner", b2cShopperbi.getProfitOwner());//分润给那个服务商
        params.put("merchProfitRatio1", b2cShopperbi.getMerchProfitRatio1());//商户分润方案1
        params.put("merchProfitRatio2", b2cShopperbi.getMerchProfitRatio2());//商户分润方案2
        params.put("merchProfitRatio3", b2cShopperbi.getMerchProfitRatio3());//商户分润方案3


        //扫码注册睿付添加四个字段
        String cityCode = b2cShopperbi.getCity();
        Area area1 = shopPerbiService.findPayeeBankProvinceAndCity(b2cShopperbi.getCity());

        params.put("merchAddress", b2cShopperbi.getSaddress());//商户地址
        params.put("payeeBankId", shopPerbiService.findUnionBankCode(b2cShopperbi.getAccountbankdictval()));//银行卡所在联行总行号
        params.put("payeeBankProvince", area1.getShProvincial());//睿付开户行省份编码
        params.put("payeeBankCity", area1.getShCity());//睿付开户行城市编码

        JSONObject obs = JSONObject.fromObject(params);
        log.info("注册扫码支付个人：" + DynamicConfigLoader.getByEnv("reg_qr_pay_merchant_url") + obs.toString());
        String resultString = HttpClientUtils.REpostRequestStr(
                DynamicConfigLoader.getByEnv("reg_qr_pay_merchant_url"), obs.toString());
        Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);

        return resultMap;

    }

    /**扫码支付企业注册
     * @param b2cShopperbi
     * @param userType
     * @return
     * @throws UnsupportedEncodingException
     */
    private Map regQrPayCompany(B2cShopperbiTemp b2cShopperbi, String userType) throws Exception {

        HashMap params = new HashMap();
        Date dates = new Date();
        String mradom = RandomStringUtils.randomNumeric(6);
        String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom+ b2cShopperbi.getShopperid();
        String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");

        // 基本信息
        String name = b2cShopperbi.getName();
        String idCard = b2cShopperbi.getIDNo();
        String tel = b2cShopperbi.getStel();
        String merchantNo = b2cShopperbi.getShopperid() == null ? "": b2cShopperbi.getShopperid().toString();
        Long agentNo = b2cShopperbi.getShopperidP();
        String institutionNo = b2cShopperbi.getOrgNo();
        String platformType = "";
        if (agentNo != null) {
            platformType = Constants.CON_NO;// 0 自有
        } else {
            platformType = Constants.CON_YES;// 机构
        }
        // 结算信息
        String settlementType = b2cShopperbi.getSettlementType();
        String accountBankDictval = b2cShopperbi.getAccountbankdictval();
        String accountbankname = b2cShopperbi.getAccountbankname();
        String accountbankprovCode = b2cShopperbi.getAccountBankProvCode();
        String accountBankCityCode = b2cShopperbi.getAccountBankCityCode();
        String accountbankclientname = b2cShopperbi.getAccountbankclientname();
        String accountbankno = b2cShopperbi.getAccountbankno();
        //省市
        String accountBankCity = b2cShopperbi.getAccountBankCity();
        String accountbankprov = b2cShopperbi.getAccountbankprov();
        // 刷卡手续费
        List merchantFeeList = shopPerbiService.findQrPayMerchantFeeList(b2cShopperbi.getShopperid().toString());
        String qrD0fee=shopPerbiService.findQrPayMerchantFee(b2cShopperbi.getShopperid().toString());
        // t+0手续费
        String issupportt0 = b2cShopperbi.getIsSupportT0(); // 0支持
        String isicapplyt0 = "";
        Double t0singledaylimit = 0.00;
        if (Constants.CON_NO.equals(issupportt0)) {
            isicapplyt0 = b2cShopperbi.getIsIcApplyT0();
            t0singledaylimit = b2cShopperbi.getT0SingleDayLimit();
            params.put("t0fee", qrD0fee);
            params.put("t0fixedamount", b2cShopperbi.getT0fixedamount());
            params.put("t0minamount", b2cShopperbi.getT0minamount());
            params.put("t0maxamount", b2cShopperbi.getT0maxamount());
            params.put("creditAmount", t0singledaylimit == null ? "": t0singledaylimit);
            params.put("t0singledaylimit", t0singledaylimit == null ? "": t0singledaylimit);
        } else {
            params.put("t0fee", "0");
            params.put("t0fixedamount", "0");
            params.put("t0minamount", "0");
            params.put("t0maxamount", "0");
            params.put("creditAmount", "0");
            params.put("t0singledaylimit", "0");
        }
        params.put("userType", userType == null ? "" : userType);
        params.put("orderId", orderId == null ? "" : orderId);
        params.put("orderTime", orderTime == null ? "" : orderTime);
        params.put("idNum", idCard == null ? "" : idCard);
        params.put("register_corpTel", tel == null ? "" : tel);
        params.put("register_prinName",URLDecoder.decode(name == null ? "" : name, "UTF-8"));
        params.put("prov", accountbankprovCode == null ? "": accountbankprovCode);
        params.put("city", accountBankCityCode == null ? ""	: accountBankCityCode);
        String bankCode=shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval())==null?"":URLDecoder.decode(shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval()).getDictid(),"UTF-8");
        params.put("bankCode", bankCode);
        params.put("bankNo", accountbankno == null ? "" : accountbankno);
        params.put("bankName",accountbankname == null ? "" : URLDecoder.decode(accountbankname, "UTF-8"));
        params.put("cityName",accountBankCity);
        params.put("provinceName",accountbankprov);
        //开户银行
        String openingBankName=shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval())==null?"":shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval()).getDict();
        params.put("openingBankName",openingBankName);
        params.put("register_corpFinanceName", URLDecoder.decode(name, "UTF-8"));
        params.put("linkman",name == null ? "" : URLDecoder.decode(name, "UTF-8"));
        params.put("register_corpLicenceNo",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi	.getLicenseNo());
        params.put("register_corpName", accountbankclientname == null ? "": URLDecoder.decode(accountbankclientname, "UTF-8"));
        params.put("register_email", b2cShopperbi.getSemail() == null ? "": b2cShopperbi.getSemail());
        params.put("register_corpAccountLicenceNo",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi.getLicenseNo());
        params.put("register_corpOrganizeNo",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi.getLicenseNo());
        params.put("register_corpTaxId",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi	.getLicenseNo());
        params.put("register_corpAddr", b2cShopperbi.getSaddress() == null ? ""	: URLDecoder.decode(b2cShopperbi.getSaddress(), "UTF-8"));
        params.put("register_corpZip", b2cShopperbi.getSzip() == null ? "": b2cShopperbi.getSzip());
        params.put("proxyId", agentNo == null ? "" : agentNo);
        params.put("merchantNo", merchantNo == null ? "" : merchantNo);
        params.put("institutionNo", institutionNo == null ? "" : institutionNo);
        //params.put("settlementType", settlementType == null ? "": settlementType);
        params.put("commissionIds", merchantFeeList);
        params.put("issupportt0", issupportt0 == null ? "" : issupportt0);// 是否支持T0提现

        String qrMerchantKey =b2cShopperbi.getQrpayMerchantkey();
        params.put("qrMerchantKey", null==qrMerchantKey?"":qrMerchantKey);
        params.put("agentNo", null==agentNo?"":agentNo);

        //固码信息
        MposPhotoTmp photo=this.shopPerbiService.selectPhotoTmpById(b2cShopperbi.getPhotoid());
        params.put("fixQrcodePic", photo==null?"":photo.getFixphoto());
        params.put("fixQrcodeCustomerName", b2cShopperbi.getFixqrcodecustomername());
        params.put("isExternalRevenue", b2cShopperbi.getIsexternalrevenue());
        params.put("settleType", b2cShopperbi.getSettleType());//默认结算方式1普通0快速
        params.put("creditLines", b2cShopperbi.getCreditLines().toString());//授信额度
        //分润方案
        params.put("agentProfitRatio", b2cShopperbi.getAgentProfitRatio());//服务商分润
        params.put("profitOwner", b2cShopperbi.getProfitOwner());//分润给那个服务商
        params.put("merchProfitRatio1", b2cShopperbi.getMerchProfitRatio1());//商户分润方案1
        params.put("merchProfitRatio2", b2cShopperbi.getMerchProfitRatio2());//商户分润方案2
        params.put("merchProfitRatio3", b2cShopperbi.getMerchProfitRatio3());//商户分润方案3


        //扫码注册睿付添加四个字段
        String cityCode = b2cShopperbi.getCity();
        Area area1 = shopPerbiService.findPayeeBankProvinceAndCity(b2cShopperbi.getCity());

        params.put("merchAddress", b2cShopperbi.getSaddress());//商户地址
        params.put("payeeBankId", shopPerbiService.findUnionBankCode(b2cShopperbi.getAccountbankdictval()));//银行卡所在联行总行号
        params.put("payeeBankProvince", area1.getShProvincial());//睿付开户行省份编码
        params.put("payeeBankCity", area1.getShCity());//睿付开户行城市编码


        JSONObject obs = JSONObject.fromObject(params);
        log.info("扫码支付企业注册：" + DynamicConfigLoader.getByEnv("reg_qr_pay_company_url")+ obs.toString());
        String resultString = HttpClientUtils.REpostRequestStr(DynamicConfigLoader.getByEnv("reg_qr_pay_company_url"), obs.toString());
        Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);

        return resultMap;

    }

    /**
     * 修改商户信息:
     * 		1.调用结算信息修改接口，手续费修改接口
     * 		2.判断是否注册扫码支付接口
     * @param b2cShopperbi
     * @param request
     * @throws Exception
     */
    public void updateYsbMerchant(B2cShopperbiTemp b2cShopperbi, HttpServletRequest request) throws Exception {
        b2cShopperbi.setRecheckdate(new Date());
        b2cShopperbi.setPhotoRecheckFlag(Constants.CON_YES);

        if(null!=b2cShopperbi.getShopperidP()){
	        if(!(Constants.TYPE_2.equals(b2cShopperbi.getTransact()))){
	        		 Map activateMap=activateMerchantPort(b2cShopperbi);//激活银生宝（mpos）
	                 log.info("激活银生宝返回码:"+activateMap);
	                 JSONObject ob= JSONObject.fromObject(activateMap);
	                 String rspCode=(String)ob.get("rspCode");
	                 String rspMsg=(String)ob.get("rspMsg");
	                 if(!Constants.RESPONSE_CODE.equals(rspCode)){
	               	  throw new BusinessException(ExceptionDefine.激活商户失败,new String[]{"激活银生宝失败"});
	                 }
	                 //判断扫码是否注册成功
	                 if(StringUtils.isEmpty(b2cShopperbi.getQrPayNo())){
	               	  //扫码注册
	                     String userType=getType(b2cShopperbi.getMerchantType());
	                     Map qrPayMap=saveQrPay(request,b2cShopperbi,userType);
	
	                     if(Constants.RESPONSE_CODE.equals(qrPayMap.get("rspCode"))){
	                         b2cShopperbi.setQrPayNo(qrPayMap.get("qrPayNo")==null?"":qrPayMap.get("qrPayNo").toString());
	                         b2cShopperbi.setQrpayMerchantkey(qrPayMap.get("qrpayMerchantkey")==null?"":qrPayMap.get("qrpayMerchantkey").toString());
	                         reCheckService.updateB2cshopper(b2cShopperbi);
	                     }else{
	                         throw new BusinessException(ExceptionDefine.激活商户失败,new String[]{"扫码注册失败"});
	                     }
	               	 
	                 }
	                 //激活扫码支付商户
	                 Map qrPayactivateMap=activateQrPayMerchantPort(b2cShopperbi);
	                 JSONObject qrpay= JSONObject.fromObject(qrPayactivateMap);
	                 String qrpayRspCode=(String)qrpay.get("rspCode");
	                 if(!Constants.RESPONSE_CODE.equals(qrpayRspCode)){//如果激活扫码失败
	                     throw new BusinessException(ExceptionDefine.激活商户失败,new String[]{"扫码注册激活失败"});
	                 }
	             }
	        //mpos 绑定关系 信息修改
	        Map mposMerchantMap=updateMposAgent(b2cShopperbi);
	        JSONObject mposMerchant= JSONObject.fromObject(mposMerchantMap);
	        String mposMerchantCode=(String)mposMerchant.get("rspCode");
	        if(!Constants.RESPONSE_CODE.equals(mposMerchantCode)){
	            throw new BusinessException(ExceptionDefine.复核商户,new String[]{"mpos修改服务商信息失败"});
	        }
             
        }
        
        /**************************************Mpos修改***************************************************/
       
        
        //修改银行卡
        Map bankMap=updateBankPort(b2cShopperbi);
        JSONObject BankOb= JSONObject.fromObject(bankMap);
        String bankRspCode=(String)BankOb.get("rspCode");
        if(!Constants.RESPONSE_CODE.equals(bankRspCode)){
            throw new BusinessException(ExceptionDefine.复核商户,new String[]{"mpos修改结算信息失败"});
        }

        //修改费率
        Map feeMap=updateFeePort(b2cShopperbi);
        JSONObject obs= JSONObject.fromObject(feeMap);
        String feeRspCode=(String)obs.get("rspCode");
        if(!Constants.RESPONSE_CODE.equals(feeRspCode)){
            throw new BusinessException(ExceptionDefine.复核商户,new String[]{"mpos修改商户手续费失败"});
        }
        
        /**************************************扫码修改***************************************************/
        //扫码注册信息修改
        Map qrMerchantMap=updateQrMerchant(b2cShopperbi);
        JSONObject qrMerchant= JSONObject.fromObject(qrMerchantMap);
        String qrcodeMerchantCode=(String)qrMerchant.get("rspCode");
        if(!Constants.RESPONSE_CODE.equals(qrcodeMerchantCode)){
            throw new BusinessException(ExceptionDefine.复核商户,new String[]{"qrcode支付修改商户信息失败"});
        }

        //扫码支付修改商户结算卡号
        Map bankQrPayMap=updateQrPayBankPort(b2cShopperbi);
        JSONObject BankQrPayOb= JSONObject.fromObject(bankQrPayMap);
        String bankQrPayRspCode=(String)BankQrPayOb.get("rspCode");
        if(!Constants.RESPONSE_CODE.equals(bankQrPayRspCode)){
            throw new BusinessException(ExceptionDefine.复核商户,new String[]{"qrcode注册修改结算信息失败"});
        }

        //扫码支付修改商户手续费
        Map feeQrPayMap=updateQrPayFeePort(b2cShopperbi);
        JSONObject obqrPay= JSONObject.fromObject(feeQrPayMap);
        String feeQrPayMapRspCode=(String)obqrPay.get("rspCode");
        if(!Constants.RESPONSE_CODE.equals(feeQrPayMapRspCode)){
            throw new BusinessException(ExceptionDefine.复核商户,new String[]{"qrcode支付修改商户手续费失败"});
        }
        
        //裂变分润
        updateProfit(b2cShopperbi);
        
        //没有贷记卡信息则设置贷记卡状态为未提交通过
        if (org.apache.commons.lang.StringUtils.isEmpty(b2cShopperbi.getCreditBankNo())) {
            b2cShopperbi.setNotPassStep(Constants.NOT_PASS_STEP_ALL_PASS_NO_CREDIT_CARD);
        } else {
            b2cShopperbi.setNotPassStep(Constants.NOT_PASS_STEP_ALL_PASS);
        }
        //如果有贷记卡信息则支持D+0
        if(null != b2cShopperbi.getCreditBankNo() && !"".equals(b2cShopperbi.getCreditBankNo())){
            b2cShopperbi.setIsSupportT0(Constants.TYPE_0);
        }
        b2cShopperbi.setIfvalid(Short.valueOf(Constants.TYPE_1));//初审通过（老app）
        b2cShopperbi.setRecheckmerchantflag(Constants.TYPE_1);//复审通过（老app）
        b2cShopperbi.setNotPassReason(null);
        b2cShopperbi.setIfactivated(Constants.CON_YES);
        b2cShopperbi.setIfactivadate(new Date());
        shopPerbiService.updateShopperManualaudit(b2cShopperbi);//更新预约信息
        shopPerbiService.updateShopperFormalByTemp(b2cShopperbi);//更新正式信息
        shopPerbiService.updateShopperFee(String.valueOf(b2cShopperbi.getShopperid()));//更新商户正式费率
        shopPerbiService.updateShopperPhoto(b2cShopperbi);//更新商户照片

        //修改审核进度
        reCheckService.updateProgress(b2cShopperbi.getB2cShopperbiId().toString(),null,Constants.STATUS4,"");
        request.setAttribute(Constants.MESSAGE_KEY,"审核成功!");
    }

   

	/**
     * 裂变分润
     * @param b2cShopperbi
     * @return
     * @throws Exception
     */
    private Map updateProfit(B2cShopperbiTemp b2cShopperbi) throws Exception {
        HashMap hashMap = new HashMap();
        hashMap.put("merchantNo",b2cShopperbi.getShopperid());
        //分润方案
        hashMap.put("profitOwner", b2cShopperbi.getProfitOwner());//分润给那个代理商
        hashMap.put("agentProfitRatio", b2cShopperbi.getAgentProfitRatio()); //代理商分润百分比
        hashMap.put("merchProfitRatio1", b2cShopperbi.getMerchProfitRatio1());//商户分润方案1
        hashMap.put("merchProfitRatio2", b2cShopperbi.getMerchProfitRatio2()); //商户分润方案2
        hashMap.put("merchProfitRatio3", b2cShopperbi.getMerchProfitRatio3()); //商户分润方案3

        String json = JsonUtil.toJSONString(hashMap);
        log.info("mpos 裂变分润请求:"+ ConstantsEnv.UPDATE_PROFIT_URL+json);
        String result = HttpClientUtils.REpostRequestStr(ConstantsEnv.UPDATE_PROFIT_URL, json);
        Map map = JsonUtil.jsonStrToMap(result);
        log.info("mpos 裂变分润返回值："+map.toString());
        return map;
    }

    /**修改 弘付 psam号
     * @param b2cShopperbi
     * @return
     * @throws Exception
     */
    private Map updateAccount(B2cShopperbiTemp b2cShopperbi) throws Exception {
        HashMap hashMap = new HashMap();
        hashMap.put("merchantNo",b2cShopperbi.getShopperid());
        hashMap.put("terminalNo", b2cShopperbi.getHfpsamd0() == null ? "" : b2cShopperbi.getHfpsamd0());
        hashMap.put("pscmNo", b2cShopperbi.getHfpsam()==null?"":b2cShopperbi.getHfpsam());
        String json = JsonUtil.toJSONString(hashMap);
        log.info("修改account弘付psam:"+ json);
        String result = HttpClientUtils.REpostRequestStr(ConstantsEnv.UPDATE_ACCOUNT_HFPSAM_URL, json);
        Map map = JsonUtil.jsonStrToMap(result);
        return map;
    }

    /**
     * 扫码修改
     * @param b2cShopperbi
     * @return
     * @throws Exception
     */
    private Map updateQrMerchant(B2cShopperbiTemp b2cShopperbi) throws Exception {
        //判断个人还是企业
        String userType=getType(b2cShopperbi.getMerchantType());
        Map ysbMap = null;
        if(Constants.TYPE_P.equals(userType)){
            ysbMap=updateQrMerchantP(b2cShopperbi,userType);
        }
        if(Constants.TYPE_C.equals(userType)){
            ysbMap=updateQrScompay(b2cShopperbi,userType);
        }

        return ysbMap;
    }

    /**
     * 个人
     * @param b2cShopperbi
     * @param userType
     * @return
     * @throws Exception
     */
    private Map updateQrMerchantP(B2cShopperbiTemp b2cShopperbi, String userType)throws Exception {
        HashMap params = new HashMap();
        String userId =b2cShopperbi.getQrPayNo();   //小商户平台账户唯一标识
        String scompany = b2cShopperbi.getScompany();//商户名称
        String mobilePhoneNum =b2cShopperbi.getStel(); //手机号码
        Long agentNo = b2cShopperbi.getShopperidP();//代理商编号
        params.put("userId", userId);
        params.put("scompany", null==scompany?"":scompany);
        params.put("mobilePhoneNum", mobilePhoneNum);
        params.put("agentNo", null==agentNo?"":agentNo);
        //固码信息
        MposPhotoTmp photo=this.shopPerbiService.selectPhotoTmpById(b2cShopperbi.getPhotoid());

        params.put("fixQrcodePic", photo==null?"":photo.getFixphoto());
        params.put("fixQrcodeCustomerName", b2cShopperbi.getFixqrcodecustomername());
        params.put("isExternalRevenue", b2cShopperbi.getIsexternalrevenue());
        params.put("settleType", b2cShopperbi.getSettleType());//默认扫码
        params.put("creditLines", b2cShopperbi.getCreditLines().toString());//授信额度
        //分润方案
        params.put("profitOwner", b2cShopperbi.getProfitOwner());//分润给谁
        params.put("agentProfitRatio", b2cShopperbi.getAgentProfitRatio());//服务商分润方案
        params.put("merchProfitRatio1", b2cShopperbi.getMerchProfitRatio1());//商户分润方案1
        params.put("merchProfitRatio2", b2cShopperbi.getMerchProfitRatio2());//商户分润方案2
        params.put("merchProfitRatio3", b2cShopperbi.getMerchProfitRatio3());//商户分润方案3

        JSONObject obs = JSONObject.fromObject(params);

        log.info("扫码修改个人信息：" + DynamicConfigLoader.getByEnv("update_qr_merchant_p.url") + obs.toString());
        String resultString = HttpClientUtils.REpostRequestStr(
                DynamicConfigLoader.getByEnv("update_qr_merchant_p.url"), obs.toString());
        Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);
        log.info("扫码修改个人信息返回码："+resultMap);
        return resultMap;
    }
    
    /**
     * 企业
     * @param b2cShopperbi
     * @param userType
     * @return
     * @throws BusinessException
     */
    private Map updateQrScompay(B2cShopperbiTemp b2cShopperbi, String userType) throws BusinessException {
        HashMap params = new HashMap();
        String userId =b2cShopperbi.getQrPayNo();   //小商户平台账户唯一标识
        String register_corpTel =b2cShopperbi.getStel(); //手机号码
        String register_corpName=b2cShopperbi.getScompany();//企业名称
        Long agentNo = b2cShopperbi.getShopperidP();//代理商编号
        params.put("userId", userId);
        params.put("register_corpTel", register_corpTel);
        params.put("register_corpName", register_corpName);
        params.put("agentNo", agentNo);
        //固码信息
        MposPhotoTmp photo=this.shopPerbiService.selectPhotoTmpById(b2cShopperbi.getPhotoid());
        params.put("fixQrcodePic", photo==null?"":photo.getFixphoto());
        params.put("fixQrcodeCustomerName", b2cShopperbi.getFixqrcodecustomername());
        params.put("isExternalRevenue", b2cShopperbi.getIsexternalrevenue());
        params.put("settleType", b2cShopperbi.getSettleType());//默认扫码
        params.put("creditLines", b2cShopperbi.getCreditLines().toString());//授信额度
        //分润方案
        params.put("profitOwner", b2cShopperbi.getProfitOwner());//分润给谁
        params.put("agentProfitRatio", b2cShopperbi.getAgentProfitRatio());//服务商分润方案
        params.put("merchProfitRatio1", b2cShopperbi.getMerchProfitRatio1());//商户分润方案1
        params.put("merchProfitRatio2", b2cShopperbi.getMerchProfitRatio2());//商户分润方案2
        params.put("merchProfitRatio3", b2cShopperbi.getMerchProfitRatio3());//商户分润方案3
        JSONObject obs = JSONObject.fromObject(params);
        log.info("扫码修改企业信息：" + DynamicConfigLoader.getByEnv("update_qr_merchant_p.url")+ obs.toString());
        String resultString = HttpClientUtils.REpostRequestStr(
                DynamicConfigLoader.getByEnv("update_qr_scompay_c.url"), obs.toString());
        Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);
        log.info("扫码修改企业信息返回码："+resultMap);
        return resultMap;
    }

    /**扫码支付修改结算信息
     * @param b2cShopperbi
     * @return
     * @throws Exception
     * @throws UnsupportedEncodingException
     */
    private Map updateQrPayBankPort(B2cShopperbiTemp b2cShopperbi) throws Exception {


        HashMap params=new HashMap();

        Date dates = new Date();
        String mradom = RandomStringUtils.randomNumeric(6);
        String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbi.getB2cShopperbiId();
        String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");

        String idNum=b2cShopperbi.getIDNo();
        String bankCode=shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval())==null?"":URLDecoder.decode(shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval()).getDictid(),"UTF-8");
        String openingBankName=shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval())==null?"":shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval()).getDict();
        String bankNo=b2cShopperbi.getAccountbankno();
        String bankName=b2cShopperbi.getAccountbankname();
        String prov=b2cShopperbi.getAccountBankProvCode();
        String city=b2cShopperbi.getAccountBankCityCode();
        //省市
        String accountBankCity = b2cShopperbi.getAccountBankCity();
        String accountbankprov = b2cShopperbi.getAccountbankprov();
        params.put("cityName",accountBankCity);
        params.put("provinceName",accountbankprov);
        params.put("openingBankName",openingBankName);
        params.put("userId", b2cShopperbi.getQrPayNo());
        //   params.put("orderId", orderId);
        //  params.put("orderTime", orderTime);
        params.put("idNum", idNum);
        params.put("bankCode", bankCode);
        params.put("bankNo", bankNo);
        params.put("bankName", bankName);
        params.put("prov", prov);
        params.put("city", city);


        /**
         * 10月20号添加三个字段
         */
        /*Area area1 = shopPerbiService.findPayeeBankProvinceAndCity(b2cShopperbi.getCity());
		
		params.put("payeeBankId", shopPerbiService.findUnionBankCode(b2cShopperbi.getAccountbankdictval()));//银行卡所在联行总行号
		params.put("payeeBankProvince", area1.getShProvincial());//睿付开户行省份编码
		params.put("payeeBankCity", area1.getShCity());//睿付开户行城市编码
*/

        log.info("扫码支付修改银行卡账户信息："+DynamicConfigLoader.getByEnv("modify_qrpay_bank_card_url")+params.toString());
        // Map resultMap =HttpClientUtils.postRequestMap(DynamicConfigLoader.getByEnv("modify_qrpay_bank_card_url"),params,Map.class);
        Map resultMap =HttpClientUtils.postJsonRequestMap(DynamicConfigLoader.getByEnv("modify_qrpay_bank_card_url"),params,Map.class);
        logger.info("扫码支付修改银行卡账户信息返回码:"+resultMap);
        return resultMap;

    }

    /**
     * 修改扫码支付手续费费率
     * @param b2cShopperbi
     * @return
     * @throws Exception
     */
    private Map updateQrPayFeePort(B2cShopperbiTemp b2cShopperbi) throws Exception {
        HashMap params=new HashMap();
        List merchantFeeList=shopPerbiService.findQrPayMerchantTempFeeList(b2cShopperbi.getShopperid().toString());
        Date dates = new Date();
        String mradom = RandomStringUtils.randomNumeric(6);
        String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbi.getB2cShopperbiId();
        String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");
        String userId=b2cShopperbi.getQrPayNo();
        params.put("userId", userId);
        params.put("t0fee", Constants.D0_FEE);
        params.put("t0fixedamount", Constants.T0_FIXED_AMOUNT);
        params.put("t0topamount", b2cShopperbi.getT0topamount()==null?"0.00":b2cShopperbi.getT0topamount());
        params.put("t0minamount", b2cShopperbi.getT0minamount()==null?"0.00":b2cShopperbi.getT0minamount());
        params.put("t0maxamount", b2cShopperbi.getT0maxamount()==null?"0.00":b2cShopperbi.getT0maxamount());
        params.put("creditAmount", b2cShopperbi.getT0SingleDayLimit()==null?"0.00":b2cShopperbi.getT0SingleDayLimit());
        params.put("commissionIds", merchantFeeList);
        params.put("isSupportT0", b2cShopperbi.getIsSupportT0());
        log.info("修改扫码支付手续费信息："+DynamicConfigLoader.getByEnv("update_qrpay_fee_url")+params.toString());
        Map resultMap =HttpClientUtils.postJsonRequestMap(DynamicConfigLoader.getByEnv("update_qrpay_fee_url"),params,Map.class);
        logger.info("修改扫码支付手续费信息返回码:"+resultMap);
        return resultMap;

    }

    /**
     * 修改银行信息的远程接口
     * @param b2cShopperbi
     * @throws Exception
     * @throws UnsupportedEncodingException
     */
    private Map updateBankPort(B2cShopperbiTemp b2cShopperbi) throws  Exception {

        HashMap params=new HashMap();

        Date dates = new Date();
        String mradom = RandomStringUtils.randomNumeric(6);
        String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbi.getB2cShopperbiId();
        String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");

        String idNum=b2cShopperbi.getIDNo();
        String bankCode=shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval())==null?"":URLDecoder.decode(shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval()).getDictid(),"UTF-8");
        String bankNo=b2cShopperbi.getAccountbankno();
        String bankName=b2cShopperbi.getAccountbankname();
        String prov=b2cShopperbi.getAccountBankProvCode();
        String city=b2cShopperbi.getAccountBankCityCode();

        params.put("orderId", orderId);
        params.put("orderTime", orderTime);
        params.put("idNum", idNum);
        params.put("bankCode", bankCode);
        params.put("bankNo", bankNo);
        params.put("bankName", bankName);
        params.put("prov", prov);
        params.put("city", city);

        log.info("修改银行卡账户信息："+DynamicConfigLoader.getByEnv("modify_bank_card_url")+params.toString());
        Map resultMap =HttpClientUtils.postRequestMap(DynamicConfigLoader.getByEnv("modify_bank_card_url"),params,Map.class);
        logger.info("修改银行卡账户信息返回码:"+resultMap);
        return resultMap;
    }

    /**
     * 修改手续费信息的远程接口
     * @param b2cShopperbi
     * @throws Exception
     * @throws UnsupportedEncodingException
     */
    private Map updateFeePort(B2cShopperbiTemp b2cShopperbi) throws  Exception {

        HashMap params=new HashMap();
        List merchantFeeList=shopPerbiService.findMerchantFeeTempByMposList(b2cShopperbi.getShopperid());
        Date dates = new Date();
        String mradom = RandomStringUtils.randomNumeric(6);
        String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbi.getB2cShopperbiId();
        String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");
        String userId=b2cShopperbi.getYsbNo();
        params.put("userId", userId);
        params.put("t0fee", Constants.D0_FEE);
        params.put("t0Type", b2cShopperbi.getT0type()==null?"0":b2cShopperbi.getT0type());
        params.put("t1topamount", b2cShopperbi.getT1topamount()==null?"0":b2cShopperbi.getT1topamount()==null);
        params.put("t1Type", b2cShopperbi.getT0type()==null?"0":b2cShopperbi.getT0type());
        params.put("t1fee",b2cShopperbi.getT1fee()==null?"0":b2cShopperbi.getT1fee());
        params.put("t0fixedamount", Constants.T0_FIXED_AMOUNT);
        params.put("t0topamount", b2cShopperbi.getT0topamount()==null?"0.00":b2cShopperbi.getT0topamount());
        params.put("t0additionfee", b2cShopperbi.getT0additionfee()==null?"0.00":b2cShopperbi.getT0additionfee());
        params.put("t0minamount", b2cShopperbi.getT0minamount()==null?"0.00":b2cShopperbi.getT0minamount());
        params.put("t0maxamount", b2cShopperbi.getT0maxamount()==null?"0.00":b2cShopperbi.getT0maxamount());
        params.put("creditAmount", b2cShopperbi.getT0SingleDayLimit()==null?"0.00":b2cShopperbi.getT0SingleDayLimit());
        params.put("commissionIds", merchantFeeList);
        params.put("isSupportT0", b2cShopperbi.getIsSupportT0());
        log.info("修改手续费信息："+DynamicConfigLoader.getByEnv("modify_fee_url")+params.toString());
        Map resultMap =HttpClientUtils.postJsonRequestMap(DynamicConfigLoader.getByEnv("modify_fee_url"),params,Map.class);
        logger.info("修改手续费信息返回码:"+resultMap);
        return resultMap;
    }
    
    /**修改 mpos 商户服务商
     * @param b2cShopperbi
     * @return
     * @throws BusinessException
     */
    private Map updateMposAgent(B2cShopperbiTemp b2cShopperbi) throws BusinessException {
        Map params = new HashMap();
        params.put("merchantNo", b2cShopperbi.getShopperid());
        params.put("agentNo", b2cShopperbi.getShopperidP());
        JSONObject obs = net.sf.json.JSONObject.fromObject(params);
        log.info("mpos 修改服务商请求参数:"+obs.toString());
        String resultString = HttpClientUtils.REpostRequestStr(ConstantsEnv.MPOS_UPDATE_MERCHANT, obs.toString());
        Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);
        log.info("mpos mpos修改服务商 信息返回码："+ FastJson.fromJson(resultString));
        return resultMap;
    }




    /**
     * 聚合支付版
     * 商户用户激活
     * @throws BusinessException
     */
    private Map activateAggMerchantPort(B2cShopperbiTemp b2cShopperbi) throws Exception {

        Date dates = new Date();
        String mradom = RandomStringUtils.randomNumeric(6);
        String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbi.getB2cShopperbiId();

        //激活商户类型“2”
        String request = "activeStatus=" + Constants.TYPE_2 + "&orderId="+ orderId +"&merchantType="+ Constants.TYPE_2 ;
        log.info("请求激活银生宝账号请求参数："+request);
        log.info("请求激活银生宝账号："+DynamicConfigLoader.getByEnv("update_user_status_url")+request);
        String result = HttpClientUtils.REpostRequestStrNormal(DynamicConfigLoader.getByEnv("update_user_status_url"), request);
        Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(result);

        return resultMap;

    }


    /**
     * 聚合支付版
     * 商户扫码支付激活
     * @param b2cShopperbi
     * @return
     * @throws Exception
     */
    private Map activateQrPayAggMerchantPort(B2cShopperbiTemp b2cShopperbi) throws Exception {

        Date dates = new Date();
        String mradom = RandomStringUtils.randomNumeric(6);
        String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbi.getB2cShopperbiId();

        String request = "activeStatus=" + Constants.TYPE_2 + "&orderId="+orderId+"&merchantType="+ Constants.TYPE_2;
        log.info("请求激活扫码支付账号："+DynamicConfigLoader.getByEnv("update_qrpay_user_status_url")+request.toString());
        String result = HttpClientUtils.REpostRequestStrNormal(DynamicConfigLoader.getByEnv("update_qrpay_user_status_url"), request);

        Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(result);
        log.info("请求激活扫码支付账号返回码："+resultMap.toString());
        return resultMap;
    }
}
