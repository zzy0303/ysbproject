package com.uns.service;

import com.uns.common.Constants;
import com.uns.common.page.PageContext;
import com.uns.dao.SupportBankMapper;
import com.uns.web.form.SupportBankForm;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class BankSettingService {

    @Autowired
    private SupportBankMapper supportBankMapper;

    /**
     * 查询支持银行列表
     * @return
     */
    public List<SupportBankForm> querySupportBankList(String showStatus) throws Exception{
        PageContext.initPageSize(Constants.PAGE_SIZE);
        return supportBankMapper.findSupportBankList(showStatus);
    }

    public void deleteSupportBank() throws Exception{
        //删除导入数据
        supportBankMapper.deleteSupportBank(Constants.STATUS0);
    }

    /**
     * 添加快捷支持银行列表
     * @param supportBankForm
     */
    public Map addBankTempList(SupportBankForm supportBankForm) throws Exception {
        Map map = new HashMap();
        InputStream inputStream = null;
        try {
            //覆盖已导入数据
            deleteSupportBank();
            MultipartFile bankFile = supportBankForm.getSupportBankFile();
            inputStream = bankFile.getInputStream();
            HSSFWorkbook workbook = new HSSFWorkbook(inputStream);
            HSSFRow row = null;
            // 得到上传Excel文件的第一页
            HSSFSheet sheet = workbook.getSheetAt(0);
            //跳过标题
            for(int i = 1;i <= sheet.getLastRowNum(); i++){
                row = sheet.getRow(i);
                if(null != row){
                    //根据对应下标保存模版文件
                    supportBankForm.setDebitCardSupport(row.getCell(Constants.SUPPORT_BANK_EXCEL_0) == null ? "":row.getCell(Constants.SUPPORT_BANK_EXCEL_0).toString());
                    supportBankForm.setClearingBankNo(row.getCell(Constants.SUPPORT_BANK_EXCEL_1) == null ? "":row.getCell(Constants.SUPPORT_BANK_EXCEL_1).toString());
                    supportBankForm.setDebitSingleQuota(row.getCell(Constants.SUPPORT_BANK_EXCEL_2) == null ? "":row.getCell(Constants.SUPPORT_BANK_EXCEL_2).toString());
                    supportBankForm.setDebitDayQuota(row.getCell(Constants.SUPPORT_BANK_EXCEL_3) == null ? "":row.getCell(Constants.SUPPORT_BANK_EXCEL_3).toString());
                    supportBankForm.setCreditCardSupport(row.getCell(Constants.SUPPORT_BANK_EXCEL_4) == null ? "":row.getCell(Constants.SUPPORT_BANK_EXCEL_4).toString());
                    supportBankForm.setCreditClearingBankNo(row.getCell(Constants.SUPPORT_BANK_EXCEL_5) == null ? "":row.getCell(Constants.SUPPORT_BANK_EXCEL_5).toString());
                    supportBankForm.setCreditSingleQuota(row.getCell(Constants.SUPPORT_BANK_EXCEL_6)  == null ? "":row.getCell(Constants.SUPPORT_BANK_EXCEL_6).toString());
                    supportBankForm.setCreditDayQuota(row.getCell(Constants.SUPPORT_BANK_EXCEL_7) == null ? "":row.getCell(Constants.SUPPORT_BANK_EXCEL_7).toString());
                    supportBankForm.setUploadDate(new Date());
                    //显示状态为：已导入
                    supportBankForm.setShowStatus(Constants.STATUS0);
                    //保存快捷支持银行列表数据
                    supportBankMapper.insertSupportBankList(supportBankForm);
                }
            }
            map.put(Constants.RSP_MSG,"导入数据成功！");
        } catch (Exception e) {
            e.printStackTrace();
            map.put(Constants.ERROR_MESSAGE,"导入数据出错！！");
        } finally {
            if(inputStream != null){
                inputStream.close();
            }
        }
        return map;
    }

    /**
     * 确认更新导入银行列表
     */
    public Map affirmBankList(){
        Map map = new HashMap();
        //统计导入条数
        Integer countNum = supportBankMapper.countSupportBank();
        if(countNum > 0){
            //至老数据为失效
            Map param = new HashMap();
            param.put("updateStatus",Constants.BANK_SHOW_STATUS_2);
            param.put("showStatus",Constants.BANK_SHOW_STATUS_1);
            supportBankMapper.updateSupportBank(param);

            //再将当前导入列表更新为已确认
            param.put("updateStatus",Constants.BANK_SHOW_STATUS_1);
            param.put("showStatus", Constants.BANK_SHOW_STATUS_0);
            supportBankMapper.updateSupportBank(param);
            map.put("rspMsg","更新快捷银行列表成功！更新:" + countNum + "条数据");
        } else {
            map.put("rspMsg","导入数据为空，未更新列表！");
        }
        return map;
    }
}
