package com.uns.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.B2cTermBinder;
import com.uns.web.form.TerminalForm;
@Repository
public interface B2cTermBinderMapper extends BaseMapper<Object>{

    int insert(B2cTermBinder record);

    int insertSelective(B2cTermBinder record);
    
   
    /**
	 * ############################start##################################
	 */
    B2cTermBinder selectOneBinder(String terNo);
    
    int deleteByShopperId(String shopperId);
    //是否取消绑定 1为取消绑定
    void updateIsBinder(B2cTermBinder b2cTermBinder);

	List<B2cTermBinder> selectByB2cTermBinderList(String shopperId);
	
	void deleteBinderId(String shopperId);
	//审核不通过
	void updateBackBinder(B2cTermBinder b2cTermBinder);

	void updateTerminalStatus(Map map);

	List findDiveceNo(String merchantNo);
	
	
	void deleteByTermno(String termNo);

	/**
	 * ##############################end################################
	 */
	
	List findTermBatchNo(String termBatchNo);

	List findTerminalRepertoryInList(TerminalForm mbForm);

	List findTerminalRepertoryOutList(TerminalForm mbForm);

	int updateSelective(B2cTermBinder term);

	List findTerminalList(TerminalForm mbForm);
	
	List findTerminalExcelList(TerminalForm mbForm);

	List findTerminalOperateList(TerminalForm mbForm);

	B2cTermBinder findB2cTermBinderByTermNo(String terNo);

	void updateTermNo(B2cTermBinder term);

	void updateUnBinder(B2cTermBinder term);

	void updateFreeze(B2cTermBinder term);

	B2cTermBinder findTermNo(Map map);

	B2cTermBinder selectTermBinderByTermNo(String termNo);

	void editTerminalAgentNoByTermNo(Map<String, Object> map);
	

}