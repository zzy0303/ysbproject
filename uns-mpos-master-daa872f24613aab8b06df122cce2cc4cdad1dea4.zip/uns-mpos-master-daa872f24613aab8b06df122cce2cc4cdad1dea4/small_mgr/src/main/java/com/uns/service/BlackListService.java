package com.uns.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.PageContext;
import com.uns.dao.B2cShopperbiMapper;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.util.HttpClientUtils;
import com.uns.web.form.ShopPerbiForm;

import net.sf.json.JSONObject;

@Service
public class BlackListService {

	protected Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private B2cShopperbiMapper b2cShopperbiMapper;
	
	public void addBlacklist(String shopperpriId) throws BusinessException {
		Map map=new HashMap();
		map.put("smallMerchantNo", shopperpriId);
		map.put("flag", Constants.CON_YES);
		//调用添加黑名单接口
		JSONObject obs = JSONObject.fromObject(map);
	    log.info("添加黑名单 请求："+ConstantsEnv.BLACK_LIST_URL+obs.toString());
	    String resultString =HttpClientUtils.REpostRequestStr(ConstantsEnv.BLACK_LIST_URL,obs.toString());
	    Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);
	    JSONObject ob= JSONObject.fromObject(resultMap);
	    log.info("添加黑名单 返回值："+resultMap.toString());
	    String rspCode=(String)ob.get("rspCode");
	    if(Constants.RESPONSE_CODE.equals(rspCode)){
	    	b2cShopperbiMapper.updateBlacklist(map);
	    }else{
	    	throw new BusinessException(ExceptionDefine.添加商户黑名单出错);
	    }
		
	}

	public List findBlacklist(ShopPerbiForm mbForm) {
		PageContext.initPageSize(Constants.page_size);
		return b2cShopperbiMapper.findBlacklist(mbForm);
	}

	public void removeBlacklist(String shopperpriId) throws BusinessException {
		Map map=new HashMap();
		map.put("smallMerchantNo", shopperpriId);
		map.put("flag", Constants.CON_NO);
		//调用添加黑名单接口
		JSONObject obs = JSONObject.fromObject(map);
	    log.info("移除黑名单 请求："+ConstantsEnv.BLACK_LIST_URL+obs.toString());
	    String resultString =HttpClientUtils.REpostRequestStr(ConstantsEnv.BLACK_LIST_URL,obs.toString());
	    Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);
	    JSONObject ob= JSONObject.fromObject(resultMap);
	    log.info("移除黑名单 返回值："+resultMap.toString());
	    String rspCode=(String)ob.get("rspCode");
	    if(Constants.RESPONSE_CODE.equals(rspCode)){
	    	b2cShopperbiMapper.updateBlacklist(map);
	    }else{
	    	throw new BusinessException(ExceptionDefine.移除商户黑名单出错);
	    }
	}
	
	
	

}
