package com.uns.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.SInfomationMerchantRelation;
@Repository
public interface SInfomationMerchantRelationMapper {


    int insert(SInfomationMerchantRelation record);

    int insertSelective(SInfomationMerchantRelation record);

	void insertBatch(List list);

	void insertInfo(Long infoId);

	List findSInfoMRelation(Long infoId);
	
	void insertAgentInfo(Long infoId);

}