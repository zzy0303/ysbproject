package com.uns.web;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.model.Agent;
import com.uns.model.Area;
import com.uns.model.B2cDict;
import com.uns.model.B2cShopperbargainTemp;
import com.uns.model.B2cShopperbiTempHistory;
import com.uns.model.MposPhotoTmp;
import com.uns.service.AgentMccService;
import com.uns.service.ShopPerbiService;
import com.uns.util.StringUtils;
import com.uns.web.form.ShopPerbiForm;


@Controller("delshopperController")
@RequestMapping("/delshopper.htm")

public class DelshopperController extends BaseController{
	
	@Autowired
	private ShopPerbiService shopPerbiService;
	
	@Autowired
	private AgentMccService agentMccService;
	
	@RequestMapping(params = "method=delshopperList")
	@FormToken(save=true)
	public String delshopperList(HttpServletRequest request, ModelMap modelMap,B2cShopperbiTempHistory b2cShopperbitemphistory,ShopPerbiForm mbForm)throws Exception{
		try{
			//行业类型
			List cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
			request.setAttribute("cillinglist",cillinglist);
			List<HashMap> shopPerbilist=null;
			//判断商户编号是否为数字
			String shopperIdq=mbForm.getShopperidq();
			if(!StringUtils.isEmpty(shopperIdq)){
				boolean b=isFigure(shopperIdq);
				if(!b){
					mbForm.setShopperidq("");
				}
			}
			if(mbForm.getSprovince()!=null){
				List searchProvincialList=shopPerbiService.searchProvincial(mbForm.getSprovince());
	    		if(searchProvincialList!=null&&searchProvincialList.size()>0){
	    			Area spro=(Area)searchProvincialList.get(0);
	        		if(spro!=null){
	        			String sprov=spro.getProvincialname();
	        			mbForm.setSprovince(sprov);
	        		}
	    		}
			}
			if(mbForm.getCity()!=null){
				List cityList = shopPerbiService.searchCity(mbForm.getCity());
				if (cityList != null && cityList.size() > 0) {
					Area area = (Area) cityList.get(0);
					if (area != null) {
						String cityName = (String) area.getCityname();
						mbForm.setCity(cityName);
		    		}
				}
			}
			shopPerbilist = shopPerbiService.querydelshopperList(mbForm);
			modelMap.put("shopPerbilist", shopPerbilist);
			//获取省
			List<Area> Provincial=shopPerbiService.searchProvince();
			request.setAttribute("Provincial",Provincial);
			//获取市
			List<Area> list = shopPerbiService.searchArea();
	    	request.setAttribute("area",list);
			request.setAttribute("belongsAgent", mbForm.getBelongsAgent());
		}catch (BusinessException e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.商户查询失败);
		}
		
		
    return "shopPerbi/delshopper";
		
	}
	
	/**查看商户详情
	 * @param request
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=queryShopPerbiDetails")
	@FormToken(save=true)
	public String queryShopPerbiDetails(HttpServletRequest request, 
			ModelMap modelMap,B2cShopperbiTempHistory b2cShopperbi,
			B2cShopperbargainTemp b2cShopperbargain,
			 ShopPerbiForm mbForm) throws Exception {
		try {
			String shopPerbiregId=request.getParameter("shopperpriId");
			String terCount="0";
			if(StringUtils.isEmpty(shopPerbiregId)){
			    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url","shopPerbi.htm?method=shopPerbiManageList");
			}else{
				b2cShopperbi=shopPerbiService.queryShopPerbi1(shopPerbiregId);
				b2cShopperbargain=shopPerbiService.queryShopPerbargain(shopPerbiregId);
			}
			  //代理商手续费底价
	        String agentMccName="";
	        if(b2cShopperbargain!=null){
	        	 Long baseCostId=b2cShopperbargain.getBasecost();
	 	        if(baseCostId!=null){
	 		    	Map agentMccList=(HashMap)agentMccService.searchAgentMccById(baseCostId);
	 		        if(agentMccList!=null&&agentMccList.size()>0){
	 		        	agentMccName=agentMccList.get("MCC_FEE").toString()+"	"+agentMccList.get("FIRM_NAME").toString()+"	底价	"+agentMccList.get("BASE_COST").toString();
	 		        }
	 	        }
	        }
	       
	        modelMap.put("agentMccName", agentMccName);
			//获取当前绑定终端的个数
			terCount=shopPerbiService.selectTerminalCount(shopPerbiregId);
			request.setAttribute("terCount", terCount);
			//获取当前商户绑定的终端
			List<HashMap> terminalInfo=shopPerbiService.shopperB2cTermBinder(shopPerbiregId);
			request.setAttribute("terminalInfo", terminalInfo);
			//获取省
			List<Area> Provincial=shopPerbiService.searchProvince();
			request.setAttribute("Provincial",Provincial);
			//获取市
			List<Area> list = shopPerbiService.searchArea();
	    	request.setAttribute("area",list);
			//获取银行
			B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval());
	    	request.setAttribute("bankName",dicbank);
			
	        //代理商
	        String path = request.getSession().getServletContext().getContextPath();
	        request.setAttribute("agentlist",path+"agent/selectAgentTree.htm");
	        
	        if(b2cShopperbi!=null){
	        	//获取代理商
	            Long shopperId= b2cShopperbi.getShopperidP();
	            if(shopperId!=null){
	            	Agent agent=shopPerbiService.searchAgent(shopperId);
	                modelMap.put("agentName", agent.getScompany());
	                modelMap.put("agentId", agent.getShopperid());
	            }
	        }
	        
	        Long photoid = b2cShopperbi.getPhotoid();
	        if(photoid!=null){
	        	MposPhotoTmp photo =  shopPerbiService.selectPhotoTmpById(photoid);
				modelMap.put("photo", photo);
	        }
				modelMap.put("image_get_url", DynamicConfigLoader.getByEnv("sms.content.url"));
				modelMap.put("feeList", shopPerbiService.selectFeeByShopperid1(b2cShopperbi.getShopperid()));
		        modelMap.put("b2cShopperbi", b2cShopperbi);
		        modelMap.put("b2cShopperbargain", b2cShopperbargain);
	        
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取商户信息失败);
		}
		
        
		return "shopPerbi/delshopperDetails";
	}
	
	
	
	
	/**查看代理商详情
	 * @param request
	 * @param b2cShopperbi
	 * @param b2cShopperbargain
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=selectAgent")
	@FormToken(save=true)
	public String selectAgent(HttpServletRequest request, 
			ModelMap modelMap,ShopPerbiForm mbForm) throws Exception {
		try {
			Agent agent=null;
			String Id=request.getParameter("id");
			if(StringUtils.isEmpty(Id)){
			    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url","shopPerbi.htm?method=shopPerbiManageList");
			}else{
				agent=shopPerbiService.selectAgent(Long.valueOf(Id));
			}
			request.getSession().setAttribute("agent", agent);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取商户信息失败);
		}
		
        
		return "shopPerbi/delagentDetails";
	}
	
	
	/**
	 * 判断商户号
	 * 
	 * @param userName
	 * @param mpassword
	 * @param shopperid
	 */
	public boolean isFigure(String shopperIdq){
		boolean b=shopperIdq.matches(Constants.CON_FIGURE);
		return b;
	}
		

}
