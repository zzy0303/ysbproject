package com.uns.web.form;

public class InformationForm {
	
	private String themeq;
	private String createdate_start;
	private String createdate_end;
	private String statusq;
	private String ifagent;
	
	public String getThemeq() {
		return themeq;
	}
	public void setThemeq(String themeq) {
		this.themeq = themeq==null?"":themeq.trim();
	}
	public String getCreatedate_start() {
		return createdate_start;
	}
	public void setCreatedate_start(String createdate_start) {
		this.createdate_start = createdate_start==null?"":createdate_start.trim();
	}
	public String getCreatedate_end() {
		return createdate_end;
	}
	public void setCreatedate_end(String createdate_end) {
		this.createdate_end = createdate_end==null?"":createdate_end.trim();
	}
	public String getStatusq() {
		return statusq;
	}
	public void setStatusq(String statusq) {
		this.statusq = statusq==null?"":statusq.trim();
	}
	public String getIfagent() {
		return ifagent;
	}
	public void setIfagent(String ifagent) {
		this.ifagent = ifagent;
	}
	
	

}
