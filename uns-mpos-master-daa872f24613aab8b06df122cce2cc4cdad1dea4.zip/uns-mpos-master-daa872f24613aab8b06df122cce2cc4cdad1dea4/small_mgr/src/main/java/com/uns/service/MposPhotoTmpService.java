package com.uns.service;

import com.uns.dao.MposPhotoTmpMapper;
import com.uns.model.MposPhotoTmp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2018/2/4
 * @Modifyed By:
 */
@Service
public class MposPhotoTmpService {
    @Autowired
    private MposPhotoTmpMapper mposPhotoTmpMapper;

    public MposPhotoTmp findByPhotoId(Long photoid) {
        return mposPhotoTmpMapper.findbyphotoid(String.valueOf(photoid));
    }
}
