package com.uns.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.common.exception.BusinessException;
import com.uns.model.B2cDict;
@Repository
public interface B2cDictMapper extends BaseMapper<Object>{


	 /**根据分类编码，查询行业类型
	 * @param dictdlsid
	 * @return
	 */
	List<B2cDict> searchDictCls(String  dictclsid)throws BusinessException;
	
	/* (non-Javadoc)根据分类编码和外部编码，获取对象
	 */
	public List searchDictName(Map<String,String> map)throws BusinessException;
	
	/**
	 * 查询银行
	 */
	public List searchDictBank();
	/**
	 * 查询银行名字
	 */
	public B2cDict findDictBankName(String b2cDictId);
	
	//根据行业名查询id
	List findbyhCname(String dict);
	
	List findBankName(String dict);

	String findB2cDictBank(String b2cdictid);
	

	void updateB2cDictById(String b2cdictid);

	void updateB2cDict(String dicttype);

	 String findUnionBankCode(String accountbankdictval);

}