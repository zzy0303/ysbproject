package com.uns.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.exception.BusinessException;
import com.uns.common.page.PageContext;
import com.uns.dao.AgentOperatorMapper;
import com.uns.model.Users;
import com.uns.web.form.AgentUserForm;
import com.uns.web.form.ShopPerbiForm;

@Service
public class AOperatorService {
	
	@Autowired
	private AgentOperatorMapper agentOperatorMapper;

	/**查询代理商的一级操作员
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	public List selectUsersList(AgentUserForm mbForm) throws Exception {
		PageContext.initPageSize(20);
		return agentOperatorMapper.selectByUsersList(mbForm);
	}

	public Users selectUsersById(Long id) throws Exception{
		return agentOperatorMapper.selectUsersById(id);
	}

	public void update(Users user)throws Exception {
		agentOperatorMapper.update(user);
	}

	
	public List<HashMap> selectUsersListB(AgentUserForm mbForm) throws BusinessException{
		PageContext.initPageSize(20);
		return agentOperatorMapper.selectByUsersListB(mbForm);
	}
	
	
	
	

	
	
}
