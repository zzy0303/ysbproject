package com.uns.dao;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.MposPhotoTmp;
@Repository
public interface MposPhotoTmpMapper {


    int deleteByPrimaryKey(BigDecimal photoId);

    int insert(MposPhotoTmp record);

    int insertSelective(MposPhotoTmp record);

    MposPhotoTmp selectByPrimaryKey(BigDecimal photoId);

    int updateByPrimaryKeySelective(MposPhotoTmp record);

    int updateByPrimaryKey(MposPhotoTmp record);
    
    int updatePhotoTmpById(MposPhotoTmp record);
    
    MposPhotoTmp findbysid(String sid);
    MposPhotoTmp findbyphotoid(String photoId);
    
   void  delphoto(String sid);


    List<MposPhotoTmp> findHfRegImage();
}