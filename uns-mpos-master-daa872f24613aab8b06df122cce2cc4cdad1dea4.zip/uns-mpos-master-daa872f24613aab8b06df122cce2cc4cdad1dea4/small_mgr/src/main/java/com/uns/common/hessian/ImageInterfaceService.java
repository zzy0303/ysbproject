package com.uns.common.hessian;

import java.io.InputStream;

public interface ImageInterfaceService {
	
	/**
	 * 
	 * @param moduleName 是否创建目录名， 如填写small，图片将保存在D：/image/small目录下
	 * @param fileName   文件名
	 * @param imageFrom  保存在imageForm目录下，如D：/image
	 * @param input      文件流
	 * @return
	 * @throws Exception
	 */
	public String saveImage(String moduleName,String fileName,String imageFrom,InputStream input) throws Exception;

	public String saveAppImage(String moduleName,String imageFrom,String StringStream) throws Exception;
}
