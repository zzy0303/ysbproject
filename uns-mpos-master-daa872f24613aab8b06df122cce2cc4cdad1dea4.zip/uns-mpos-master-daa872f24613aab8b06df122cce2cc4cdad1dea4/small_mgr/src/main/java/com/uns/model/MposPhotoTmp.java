package com.uns.model;


public class MposPhotoTmp extends MposPhoto{
    private Long photoId;

    private String handIdentityCardPhoto;

    private String frontIdentityCardPhoto;

    private String reverseIdentityCardPhoto;

    private String storePhoto;
    
    private String instorePhoto;

    private String licensePhoto;

    private String checkstandPhoto;
    
    private String signaturePhoto;
    
    private String checkFlag;
    
    
    private String creditCardPhoto;
    
    
    private String settlementCardPhoto;
    
    private String identityid;
    
    private String fixphoto;
    
    //活体
    private String livingbodyFacePhoto;

    private String livingbodyLeftPhoto;

    private String livingbodyRightPhoto;

    private String livingbodyReturnPhoto;

    private String idCardHeadPhoto;

    private String shopperId;

    //新加商户认证
    private String openLicensePhoto;//开户许可证
    private String lobbyPhoto; //大堂照片
    private String merchantType; //商户类型

    public String getMerchantType() {
        return merchantType;
    }

    public void setMerchantType(String merchantType) {
        this.merchantType = merchantType;
    }

    public String getOpenLicensePhoto() {
        return openLicensePhoto;
    }

    public void setOpenLicensePhoto(String openLicensePhoto) {
        this.openLicensePhoto = openLicensePhoto;
    }

    public String getLobbyPhoto() {
        return lobbyPhoto;
    }

    public void setLobbyPhoto(String lobbyPhoto) {
        this.lobbyPhoto = lobbyPhoto;
    }

    public String getShopperId() {
        return shopperId;
    }

    public void setShopperId(String shopperId) {
        this.shopperId = shopperId;
    }

    public String getLivingbodyFacePhoto() {
        return livingbodyFacePhoto;
    }

    public void setLivingbodyFacePhoto(String livingbodyFacePhoto) {
        this.livingbodyFacePhoto = livingbodyFacePhoto;
    }

    public String getLivingbodyLeftPhoto() {
        return livingbodyLeftPhoto;
    }

    public void setLivingbodyLeftPhoto(String livingbodyLeftPhoto) {
        this.livingbodyLeftPhoto = livingbodyLeftPhoto;
    }

    public String getLivingbodyRightPhoto() {
        return livingbodyRightPhoto;
    }

    public void setLivingbodyRightPhoto(String livingbodyRightPhoto) {
        this.livingbodyRightPhoto = livingbodyRightPhoto;
    }

    public String getLivingbodyReturnPhoto() {
        return livingbodyReturnPhoto;
    }

    public void setLivingbodyReturnPhoto(String livingbodyReturnPhoto) {
        this.livingbodyReturnPhoto = livingbodyReturnPhoto;
    }

    public String getIdCardHeadPhoto() {
        return idCardHeadPhoto;
    }

    public void setIdCardHeadPhoto(String idCardHeadPhoto) {
        this.idCardHeadPhoto = idCardHeadPhoto;
    }

    public String getFixphoto() {
		return fixphoto;
	}

	public void setFixphoto(String fixphoto) {
		this.fixphoto = fixphoto;
	}

	public String getIdentityid() {
		return identityid;
	}

	public void setIdentityid(String identityid) {
		this.identityid = identityid;
	}

	public String getCreditCardPhoto() {
		return creditCardPhoto;
	}

	public void setCreditCardPhoto(String creditCardPhoto) {
		this.creditCardPhoto = creditCardPhoto;
	}

	public String getSettlementCardPhoto() {
		return settlementCardPhoto;
	}

	public void setSettlementCardPhoto(String settlementCardPhoto) {
		this.settlementCardPhoto = settlementCardPhoto;
	}

	public String getCheckFlag() {
		return checkFlag;
	}

	public void setCheckFlag(String checkFlag) {
		this.checkFlag = checkFlag;
	}

	public String getSignaturePhoto() {
		return signaturePhoto;
	}

	public void setSignaturePhoto(String signaturePhoto) {
		this.signaturePhoto = signaturePhoto;
	}
	
    public Long getPhotoId() {
		return photoId;
	}

	public void setPhotoId(Long photoId) {
		this.photoId = photoId;
	}

	public String getHandIdentityCardPhoto() {
        return handIdentityCardPhoto;
    }

    public void setHandIdentityCardPhoto(String handIdentityCardPhoto) {
        this.handIdentityCardPhoto = handIdentityCardPhoto == null ? null : handIdentityCardPhoto.trim();
    }

    public String getFrontIdentityCardPhoto() {
        return frontIdentityCardPhoto;
    }

    public void setFrontIdentityCardPhoto(String frontIdentityCardPhoto) {
        this.frontIdentityCardPhoto = frontIdentityCardPhoto == null ? null : frontIdentityCardPhoto.trim();
    }

    public String getReverseIdentityCardPhoto() {
        return reverseIdentityCardPhoto;
    }

    public void setReverseIdentityCardPhoto(String reverseIdentityCardPhoto) {
        this.reverseIdentityCardPhoto = reverseIdentityCardPhoto == null ? null : reverseIdentityCardPhoto.trim();
    }

    public String getStorePhoto() {
        return storePhoto;
    }

    public void setStorePhoto(String storePhoto) {
        this.storePhoto = storePhoto == null ? null : storePhoto.trim();
    }

    public String getLicensePhoto() {
        return licensePhoto;
    }

    public void setLicensePhoto(String licensePhoto) {
        this.licensePhoto = licensePhoto == null ? null : licensePhoto.trim();
    }

    public String getInstorePhoto() {
        return instorePhoto;
    }

    public void setInstorePhoto(String instorePhoto) {
        this.instorePhoto = instorePhoto == null ? null : instorePhoto.trim();
    }

    public String getCheckstandPhoto() {
        return checkstandPhoto;
    }

    public void setCheckstandPhoto(String checkstandPhoto) {
        this.checkstandPhoto = checkstandPhoto == null ? null : checkstandPhoto.trim();
    }
}