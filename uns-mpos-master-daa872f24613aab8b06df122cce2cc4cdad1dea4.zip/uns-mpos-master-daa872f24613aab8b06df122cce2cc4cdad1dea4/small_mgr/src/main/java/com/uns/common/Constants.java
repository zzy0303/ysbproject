package com.uns.common;

import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import com.uns.inf.acms.client.DynamicConfigLoader;

public class Constants {
	
	/**
	 * 统一错误消息KEY
	 */
	public static final String MESSAGE_KEY="message";
	
	public static final String SESSION_VERIFY_CODE="sessionVerifycode";
	//操作员个人信息Session
	public static final String SESSION_KEY_USER="sessionUser";
	//商户绑定的终端Session
	public static final String SESSION_KEY_SHOPPER="b2cTermBinderNo";
	//判断商户编号
	public static final String CON_FIGURE="^[-+]?(([0-9]+)([.]([0-9]+))?|([.]([0-9]+))?)$";

	//提示信息
	public static final String SAVE_MESSAGE = "保存成功!";
	//提示信息
	public static final String DEL_MESSAGE = "删除成功!";
	//退款策略
	public static final String CON_DICTCLS_RETURNPOLICY = "022";
	//结算策略
	public static final String CON_DICTCLS_FOOTFPOLICY = "023"; 
	//转帐费承担方
	public static final String CON_DICTCLS_FOOTTRANSAMOUNT = "024";
	//退款手续费策略
	public static final String CON_DICTCLS_RETURN_POUND = "030";
	//行业类型
	public static final String CON_DICTCLS_CALLING = "200";
	
	/*
	 * 代理商注册时，用于生成商户号的行业类型,暂时写为1
	 */
	public static final String CON_MCC = "1";
	/*
	 * 代理商是否准入,'N' 未准入 'Y' 已准入
	 */
	public static final String CON_AUDIT_YES = "Y";
	public static final String CON_AUDIT_NO = "N";
	
	
	public static final String Sk="sk";
	public static final String SM="sm";
	
	public static final String CON_YES = "1";
	public static final String CON_NO = "0";
	public static final String CON_OUT ="2"; //出库
	
	public static final String PASSWORD_FOR_SHOW = "unspay";
	
	public static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd";
	
	public static final String DEFAULT_DATETIME_FORMAT = "yyyy-MM-dd hh:mm:ss";

	public static final int EXCEL_PAGE_SIZE = 10000;
	/**
	 * 交易流水导出excel,每页3000行
	 */
	public static  int EXCEL_SIZE=2000;
	
	/**
	 * 交易流水展示,每页20行
	 */
	public static final int PAGE_SIZE=20;
	
	/**
	 * 默认代理商与终端绑定状态
	 * 
	 */
	public static final String TERM_AGENT_BINDER="0";

	public static final String ERROR_MESSAGE = "errMsg";
	
	public static final String DATE_TYPE="yyyy/MM/dd HH:mm:ss";
	
	private static ResourceBundle MPOSMSG = ResourceBundle.getBundle("mposMessages");
	
	public static final String TYPE_0="0";
	public static final String TYPE_1="1";
	public static final String TYPE_2="2";
	public static final String TYPE_3="3";
	public static final String TYPE_4="4";
	public static final String TYPE_5="5";
	public static final String TYPE_6="6";
	public static final String TYPE_7="7";
	
	public static final String TYPE_P="P";//个人
	public static final String TYPE_C="C";//C企业
	
	public static final String ADD="add";
	public static final String EDIT="edit";
	
	public static final String RESPONSE_CODE="0000";
	
	public static final int page_size=20;

	public static final String UPADTELIMIT_CODE="7899";
	
	public static final String SMS_SUCCESS_KEY = "sms_success_key";
	    
	public static final String SMS_FAILURE_KEY = "sms_failure_key";
	
	public static final String IS_AGENT = "2";
	public static final String IS_MERCHANT = "1";
	public static final String IS_QRCODE="3";
	public static final Integer ONE=1;
	
	    
	public static final String STATUS0="0";
	public static final String STATUS1="1";
	public static final String STATUS2="2";
	public static final String STATUS3="3";
	public static final String STATUS4 = "4";
	public static final String STATUS5 = "5";
	public static final String STATUS6 = "6";
	public static final String STATUS7 = "7";
	
	public static final String ORGTYPE="1";
	public static final Map<String, String> CZ_DATA = new HashMap<String, String>();
	public static final Map<String, String> mapReturnMsg = new HashMap<String, String>();
	static{
		mapReturnMsg.put("0000", MPOSMSG.getString("0000"));
		mapReturnMsg.put("11110001", MPOSMSG.getString("11110001"));
		mapReturnMsg.put("11110002", MPOSMSG.getString("11110002"));
		mapReturnMsg.put("11110003", MPOSMSG.getString("11110003"));
		mapReturnMsg.put("11110004", MPOSMSG.getString("11110004"));
		mapReturnMsg.put("11110005", MPOSMSG.getString("11110005"));
		mapReturnMsg.put("11110006", MPOSMSG.getString("11110006"));
		mapReturnMsg.put("11110007", MPOSMSG.getString("11110007"));
		mapReturnMsg.put("11110008", MPOSMSG.getString("11110008"));
		mapReturnMsg.put("11110009", MPOSMSG.getString("11110009"));
		mapReturnMsg.put("11110010", MPOSMSG.getString("11110010"));
		
		mapReturnMsg.put("10100001", MPOSMSG.getString("10100001"));
		mapReturnMsg.put("10100002", MPOSMSG.getString("10100002"));
		mapReturnMsg.put("10100003", MPOSMSG.getString("10100003"));
		mapReturnMsg.put("10100004", MPOSMSG.getString("10100004"));
		mapReturnMsg.put("3000", MPOSMSG.getString("3000"));
		mapReturnMsg.put("3001", MPOSMSG.getString("3001"));
		mapReturnMsg.put("1000", MPOSMSG.getString("1000"));
		mapReturnMsg.put("0001", MPOSMSG.getString("0001"));
		
		mapReturnMsg.put("3005", MPOSMSG.getString("3005"));
		mapReturnMsg.put("7001", MPOSMSG.getString("7001"));
	}
	
	public static final Map<String,String> convertCode = new HashMap<String, String>();
	static{
		convertCode.put("10800000", "11110002");
		convertCode.put("10100000", "11110002");
		convertCode.put("1001", "11110002");
		
		convertCode.put("3006", "11110002");
		convertCode.put("3007", "3005");
		convertCode.put("5001", "0001");
		convertCode.put("6004", "11110002");
		convertCode.put("6006", "11110002");
		convertCode.put("6011", "11110002");
		convertCode.put("7002", "11110002");
		convertCode.put("7003", "11110002");
		convertCode.put("7005", "11110002");
		convertCode.put("7006", "11110002");
		convertCode.put("9001", "11110002");
		
		convertCode.put("2100", "11110002");
		convertCode.put("2000", "11110002");
		convertCode.put("2200", "11110002");
		convertCode.put("9999", "11110002");
	}

	public static final int INT_PAGE = 5;

	public static  String HK_SUCCESS_CODE = "00";
	public static String HK_SUCCESS_CODE_01 = "01";
	public static  String HK_REPEAT_CODE = "S8";

	public static  int BATCH_SIZE = 10000;
	public static  int UPLOAD_SIZE = 5000;

	public static  int UPLOAD_HK_SIZE = 5000;

	public static  String ADD_RS_PMSG = "添加成功";
	
	public static  String UPDATE_RS_PMSG = "修改成功";

	public static  int HK_SERVERPORT = 8088;


	
	public static final String FEE_TYPE_DEBIT = "0";//即时借记储蓄卡
	public static final String FEE_TYPE_CREDIT = "1"; //即时贷记储蓄卡
	public static final String FEE_TYPE_WECHAT = "2"; //微信支付
	public static final String FEE_TYPE_ALIPAY = "3";//支付宝支付
	public static final String FEE_TYPE_YLPAY = "4";//银联支付
	public static final String FEE_TYPE_SHORTCUT = "5";//快捷
	public static final String FEE_TYPE_B2C = "6";//B2C
	public static final String FEE_TYPE_SHD0 = "7";//速惠收款费率类型（11）
	//新加商户版费率
	public static final String FEE_TYPE_SWXT1 = "20";//商户版微信费率类型(20)
	public static final String FEE_TYPE_SZFBT1 = "21";//商户版支付宝费率类型（21）

	public static final String S0_FEE_TYPE_DEBIT = "5";
	public static final String S0_FEE_TYPE_CREDIT = "6";
	public static final String T1_FEE_TYPE_DEBIT = "7";
	public static final String T1_FEE_TYPE_CREDIT = "8";
	
	public static final String AGENT_TYPE_SHORTCUT = "9";//快捷字典表
	public static final String AGENT_TYPE_B2C = "10";//B2C字典表
	public static final String AGENT_TYPE_SHORTCUTSH = "11";//快捷速惠字典表
	
	public static final String HK_REPEAT_CODE_H2 = "H2"; 
	
	/*public static final String HF_KEY = "F27614B025A35F9D2C795A0FD0768F4C";
	
	public static final String HF_USERSIGN = "kabao";
	
	public static final String HF_ORGNO = "100415";
	
	public static final String HF_CODE_ADD = "00"; 
	
	public static final String HF_CODE_UPDATE = "07";
	
	public static final String HF_FEE_TYPE = "2";
	
	public static final String ZERO = "0";
	
	public static final String ONE = "1"; 
	*/
	
	//固定编码模块
	public static final String QRCODE_STATUS1="4051";
	public static final String QRCODE_STATUS2="4061";
	public static final String QRCODE_UN="4062";//编码未入库
	public static final String QRCODE_Y="4063";//编码已经出过库
	public static final String QRCODE_UNNUM="4064";//非法数字
	public static final String QRCODE_LONG="4066";//Excel长度错误限制
	public static final String QRCODE_IN="0";//入库
	public static final String QRCODE_B="1";//绑定商户
	public static final int    QRCODE_SIZE=8;
	public static final String QRCODE_NO="NO.";
	public static final int    TERM_SIZE = 16;

	/**
	 * 正则表达式模块
	 */
	public static final String TERM_REGULAR="^[0-9]*$";

	
	
	public static final String T0_FEE = "0.07";
	public static final String T0_FIXED_AMOUNT = "2";
	public static final String T0_MIN_AMOUNT = "197.00";
	public static final String T0_MAX_AMOUNT="50000.00";
	public static final String T0_SINGLEDAY_LIMIT="50000.00";

	public static final String S0_CHANNEL_TYPE = "1001";
	public static final String D0_CHANNEL_TYPE = "2001";
	public static final String T1_CHANNEL_TYPE = "2002";

	public static final String D0_FEE = "0.0007";


	public static final String HUNDRED="10000";

	public static final String S0_FIX_AMOUNT = "3";

	public static final String PHOTO_VERSION = "2.1.0";
	private static ResourceBundle CONF = ResourceBundle.getBundle("conf");

	


	public static final String ORGANIZATION = CONF.getString("hsm_shoper_id");

	public static final String APP_TOP_SUDOKU = "600";
	public static final String APP_MPOS_TRAN_TYPE="501";
	public static final String APP_SM_TRAN_TYPE="502";
	public static final String APP_SM_PAY_FLAG = "701";
	public static final String APP_KJ_PAY_FLAG = "901";

	public static final String MER_SUDOKU = "610";
	public static final String MER_SM_TRAN_TYPE = "702";
	public static final String MER_SM_PAY_FLAG = "703";
	//商户版九宫格
	public static final String APP_MER_SUDOKU = "620";
	public static final String APP_MER_SM_TRAN_TYPE = "520"; //T1收款
	public static final String APP_MER_SM_PAY_FLAG = "720"; //扫码支付
	public static final String APP_MER_SM_TRAN_FLAG = "730"; //普通收款

	public static final Long LONG_0 = 0L;
	public static final Long LONG_1 = 1L;

	public static final String OLD_NOT_PASS_STEP = "1,1,1,1,1,1";//处理老商户的不通过步骤
	public static final String NOT_PASS_STEP_ALL_PASS = "2,2,2,2,2,2";//所有报件审核通过
	public static final String NOT_PASS_STEP_ALL_PASS_NO_CREDIT_CARD = "2,2,3,2,2,2";//贷记卡未上传通过
	//统一跳转地址key
	public static final String URL_KEY="url";
	
	public static final String SUCCESS_CODE_0000 = "0000";

	public static final int INT_0 = 0;
	public static final int INT_1 = 1;
	
	public static double COM_BASE = 800;//图片压缩算法的基准宽高
	public static double SCALE = 0.9d;//图片压缩算法的宽高比
	
	public static String APPLICATIONTHEME变更证照 = "变更证照";
	public static int INT_4 = 4;

	public static final String RSP_CODE = "rspCode";//rspCode

	public static final String RSP_MSG = "rspMsg";//rspMsg
	
	public static String APP_AES_KEY = DynamicConfigLoader.getByEnv("app_aes_key");//APP AES加密解密key

	public static final String HK_10A = "10A";
	public static final String HK_10B = "10B";

	/**
	 * OCR检测统计
	 * 10：活体检OCR测
	 * 11：身份证OCR检测
	 * 12：银行卡OCR检测
	 * 13: 公安接口
	 * 14: 人脸比对
	 */
	public static final String HT_OCR = "10";
	public static final String SFZ_OCR = "11";
	public static final String YHK_OCR = "12";

	//商户版审核状态：6 未审核 7 审核中 8 初审通过 9初审不通过 10复审通过 11复审不通过）
	public static final String CHECK_STATUS_6 = "6";
	public static final String CHECK_STATUS_7 = "7";
	public static final String CHECK_STATUS_8 = "8";
	public static final String CHECK_STATUS_9 = "9";
	public static final String CHECK_STATUS_10 = "10";
	public static final String CHECK_STATUS_11 = "11";
	public static final String OPEN_CIB_YES = "Y";
	public static final String OPEN_CIB_NO = "N";


	/*
	 * 快捷支持银行参数下标
	 * 0:借记卡支持银行1:人行清算行号2:借记卡单笔限额3:借记卡单日限额
	 * 4:贷记卡支持银行5:贷记卡人行清算行号6:贷记卡单笔限额7:贷记卡单日限额
	 */
	public static final int SUPPORT_BANK_EXCEL_0 = 0;
	public static final int SUPPORT_BANK_EXCEL_1 = 1;
	public static final int SUPPORT_BANK_EXCEL_2 = 2;
	public static final int SUPPORT_BANK_EXCEL_3 = 3;
	public static final int SUPPORT_BANK_EXCEL_4 = 4;
	public static final int SUPPORT_BANK_EXCEL_5 = 5;
	public static final int SUPPORT_BANK_EXCEL_6 = 6;
	public static final int SUPPORT_BANK_EXCEL_7 = 7;

	/**
	 * 支持银行显示状态 0:已导入, 1:已确认, 2：已失效
	 */
	public static final String BANK_SHOW_STATUS_0 = "0";
	public static final String BANK_SHOW_STATUS_1 = "1";
	public static final String BANK_SHOW_STATUS_2 = "2";


	public static final String POLICE_OCR = "13";
	public static final String FACE_THAN_OCR = "14";
}
