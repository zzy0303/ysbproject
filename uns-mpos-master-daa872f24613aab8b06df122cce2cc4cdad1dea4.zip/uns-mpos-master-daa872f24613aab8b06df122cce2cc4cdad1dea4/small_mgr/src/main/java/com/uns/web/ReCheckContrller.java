package com.uns.web;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.atomic.AtomicReference;

import javax.servlet.http.HttpServletRequest;

import com.uns.service.MposPhotoTmpService;
import com.uns.util.*;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;
import org.jpos.iso.BaseChannel;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOUtil;
import org.jpos.iso.channel.PostChannel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.model.Agent;
import com.uns.model.Area;
import com.uns.model.B2cDict;
import com.uns.model.B2cShopperbi;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.BackupsShopperInformation;
import com.uns.model.MposMerchantFee;
import com.uns.model.MposPhoto;
import com.uns.model.MposPhotoTmp;
import com.uns.service.ReCheckService;
import com.uns.service.SendMessageService;
import com.uns.service.ShopPerbiService;
import com.uns.web.form.ShopPerbiForm;

import net.sf.json.JSONObject;

@Controller("ReCheckContrller")
@RequestMapping("/reCheck.htm")
public class ReCheckContrller extends BaseController{
	
	@Autowired
	private ReCheckService  reCheckService;
	
	@Autowired
	private ShopPerbiService shopPerbiService;
	
	
	@Autowired
	private SendMessageService sendmessageService;

	@Autowired
	private MposPhotoTmpService mposPhotoTmpService;

	@Autowired
	private AcmsMapUtils acmsMapUtils;
	private ISO8583Packager pack = new ISO8583Packager();
	
	/**商户基本信息复核
	 * @param request
	 * @param modelMap
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=reCheckShoperBiList")
	public String reCheckShoperBiList(HttpServletRequest request, ModelMap modelMap,
			ShopPerbiForm mbForm)throws Exception {
		//城市省份条件查询设置
		if(mbForm.getSprovince()!=null){
			List searchProvincialList=shopPerbiService.searchProvincial(mbForm.getSprovince());
    		if(searchProvincialList!=null&&searchProvincialList.size()>0){
    			Area spro=(Area)searchProvincialList.get(0);
        		if(spro!=null){
        			String sprov=spro.getProvincialname();
        			mbForm.setSprovince(sprov);
        		}
    		}
		}
		if(mbForm.getCity()!=null){
			List cityList = shopPerbiService.searchCity(mbForm.getCity());
			if (cityList != null && cityList.size() > 0) {
				Area area = (Area) cityList.get(0);
				if (area != null) {
					String cityName = (String) area.getCityname();
					mbForm.setCity(cityName);
	    		}
			}
		}
		//获取省
		List<Area> Provincial=shopPerbiService.searchProvince();
		request.setAttribute("Provincial",Provincial);
		//获取市
		List<Area> list = shopPerbiService.searchArea();
    	request.setAttribute("area",list);
		//复核
    	List reCheckList=reCheckService.getReCheckList(mbForm);
		request.setAttribute("reCheckList", reCheckList);
		request.setAttribute("belongsAgent", mbForm.getBelongsAgent());
		//未复核
		String reCheckMerchantCount=reCheckService.getReCheckMerchantCount();
		request.setAttribute("reCheckMerchantCount", reCheckMerchantCount);
		
		return "recheck/recheckList";
	}
	
	/**根据商户编号获取复核商户信息
	 * 
	 * @param request
	 * @param modelMap
	 * @param shopperId
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=reCheckMerchant")
	@FormToken(save=true)
	public String reCheckMerchant(HttpServletRequest request,String  shopperId,ShopPerbiForm mbForm)throws Exception {
		B2cShopperbi b2cShopperbiFormal = null;
		B2cShopperbiTemp b2cShopperbi = null;
		try {
			String shopPerbiregId = request.getParameter("shopperId");
			if (StringUtils.isEmpty(shopPerbiregId)) {
				request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
				mbForm.setBelongsAgent(null);
				request.setAttribute("url",
						"shopPerbi.htm?method=shopPerbiCheckList");
			} else {
				b2cShopperbi = shopPerbiService.queryShopPerbi(shopPerbiregId);
				b2cShopperbiFormal = shopPerbiService.queryFormalShopPerbi(shopPerbiregId);
			}
			// 获取省
			List<Area> Provincial = shopPerbiService.searchProvince();
			request.setAttribute("Provincial", Provincial);
			// 获取市
			List<Area> list = shopPerbiService.searchArea();
			request.setAttribute("area", list);

			// 行业类型
			List<B2cDict> cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
			request.setAttribute("cillinglist", cillinglist);
			// 代理商列表
			String path = request.getSession().getServletContext()
					.getContextPath();
			request.setAttribute("agentlist", path
					+ "agent/selectAgentTree.htm");

			if (b2cShopperbi != null) {
				// 获取临时表代理商
				Long shopperIdP = b2cShopperbi.getShopperidP();
				if (shopperIdP != null) {
					Agent agent = shopPerbiService.searchAgent(shopperIdP);
					request.setAttribute("agentName", agent.getScompany());
					request.setAttribute("agentId", agent.getShopperid());
				}
				// 获取银行
				B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi
						.getAccountbankdictval());
				request.setAttribute("bankName", dicbank);
				// 证照
				Long photoid = b2cShopperbi.getPhotoid();
				if (photoid != null) {
					MposPhotoTmp photo = shopPerbiService
							.selectPhotoTmpById(photoid);
					request.setAttribute("photo", photo);
					request.setAttribute("image_get_url", DynamicConfigLoader.getByEnv("imageget.url"));
				}
			}
			if (b2cShopperbiFormal != null) {
				// 获取正式表代理商
				Long shopperIdFormal = b2cShopperbiFormal.getShopperidP();
				if (shopperIdFormal != null) {
					Agent agent = shopPerbiService.searchAgent(shopperIdFormal);
					request.setAttribute("agentNameFormal", agent.getScompany());
					request.setAttribute("agentIdFormal", agent.getShopperid());
				}
				// 获取银行
				B2cDict dicbank = shopPerbiService
						.findBankName(b2cShopperbiFormal
								.getAccountbankdictval());
				request.setAttribute("bankNameFormal", dicbank);
				// 证照
				Long photoid = b2cShopperbiFormal.getPhotoid();
				if (photoid != null) {
					MposPhoto photo = shopPerbiService.selectPhotoById(photoid);
					request.setAttribute("photoFormal", photo);
					request.setAttribute("image_get_urlFormal", DynamicConfigLoader.getByEnv("imageget.url"));
				}
			}
			String shopperTel = null;
			if(b2cShopperbi!=null){
				shopperTel = b2cShopperbi.getStel();
			if(b2cShopperbiFormal!=null&&shopperTel==null){
				shopperTel = b2cShopperbiFormal.getStel();
				}
			}
			
			// 手续费，临时表
			MposMerchantFee s0creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
			MposMerchantFee s0debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
			
			MposMerchantFee d0creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
			MposMerchantFee d0debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
			
			MposMerchantFee t1creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
			MposMerchantFee t1debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
			
			MposMerchantFee weChatMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId, Constants.FEE_TYPE_WECHAT);
			MposMerchantFee alipayMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId, Constants.FEE_TYPE_ALIPAY);
			MposMerchantFee ylpayMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId,Constants.FEE_TYPE_YLPAY);
			//无卡汇率临时表
			MposMerchantFee shortCutMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId, Constants.FEE_TYPE_SHORTCUT);
			/**
			 * 10月20号添加速惠费率临时
			 */
			MposMerchantFee shortCutSHMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId, Constants.FEE_TYPE_SHD0);
			
			MposMerchantFee b2cMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId, Constants.FEE_TYPE_B2C);
			
			request.setAttribute("shortCutSHMerchantFeeTemp", shortCutSHMerchantFeeTemp);
			request.setAttribute("shortCutMerchantFeeTemp", shortCutMerchantFeeTemp);
			request.setAttribute("b2cMerchantFeeTemp", b2cMerchantFeeTemp);
			
			request.setAttribute("s0creditMerchantFeeTemp", s0creditMerchantFeeTemp);
			request.setAttribute("s0debitMerchantFeeTemp", s0debitMerchantFeeTemp);
			
			request.setAttribute("d0creditMerchantFeeTemp", d0creditMerchantFeeTemp);
			request.setAttribute("d0debitMerchantFeeTemp", d0debitMerchantFeeTemp);
			
			request.setAttribute("t1creditMerchantFeeTemp", t1creditMerchantFeeTemp);
			request.setAttribute("t1debitMerchantFeeTemp", t1debitMerchantFeeTemp);
			
			request.setAttribute("weChatMerchantFeeTemp", weChatMerchantFeeTemp);
			request.setAttribute("alipayMerchantFeeTemp",  alipayMerchantFeeTemp);
			request.setAttribute("ylpayMerchantFeeTemp",ylpayMerchantFeeTemp);
			// 手续费
			MposMerchantFee s0creditMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
			if(s0creditMerchantFee==null&&shopperTel!=null){
				s0creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
			}
			MposMerchantFee s0debitMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
			if(s0debitMerchantFee==null&&shopperTel!=null){
				s0debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
			}
			
			MposMerchantFee d0creditMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
			if(d0creditMerchantFee==null&&shopperTel!=null){
				d0creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
			}
			MposMerchantFee d0debitMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
			if(d0debitMerchantFee==null&&shopperTel!=null){
				d0debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
			}
			
			MposMerchantFee t1creditMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
			if(t1creditMerchantFee==null&&shopperTel!=null){
				t1creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
			}
			MposMerchantFee t1debitMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
			if(t1debitMerchantFee==null&&shopperTel!=null){
				t1debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
			}
			
			MposMerchantFee weChatMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_WECHAT);
			if(weChatMerchantFee==null&&shopperTel!=null){
				weChatMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_WECHAT);
			}
			MposMerchantFee alipayMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_ALIPAY);
			if(alipayMerchantFee==null&&shopperTel!=null){
				alipayMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_ALIPAY);
			}
			MposMerchantFee ylpayMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId,Constants.FEE_TYPE_YLPAY);
			if(ylpayMerchantFee == null && shopperTel != null){
				ylpayMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_YLPAY);
			}
			//无卡汇率正式表
			MposMerchantFee shortCutMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_SHORTCUT);
			MposMerchantFee b2cMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_B2C);
			
			/**
			 * 10月20号添加速惠费率正式
			 */
			MposMerchantFee shortCutSHMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_SHD0);
			
			request.setAttribute("s0creditMerchantFee", s0creditMerchantFee);
			request.setAttribute("s0debitMerchantFee", s0debitMerchantFee);
			
			request.setAttribute("shortCutMerchantFee", shortCutMerchantFee);
			request.setAttribute("shortCutSHMerchantFee", shortCutSHMerchantFee);
			request.setAttribute("b2cMerchantFee", b2cMerchantFee);
			
			request.setAttribute("d0creditMerchantFee", d0creditMerchantFee);
			request.setAttribute("d0debitMerchantFee", d0debitMerchantFee);
			
			request.setAttribute("t1creditMerchantFee", t1creditMerchantFee);
			request.setAttribute("t1debitMerchantFee", t1debitMerchantFee);
			
			request.setAttribute("weChatMerchantFee", weChatMerchantFee);
			request.setAttribute("alipayMerchantFee",  alipayMerchantFee);
			request.setAttribute("ylpayMerchantFee",ylpayMerchantFee);


			request.setAttribute("b2cShopperbi", b2cShopperbi);
			request.setAttribute("b2cShopperbiFormal", b2cShopperbiFormal);
			if (b2cShopperbi.getMerchProfitRatio2()!=null&&b2cShopperbi.getMerchProfitRatio3()!=null) {			
			//分润方案2
			String[] split2 = b2cShopperbi.getMerchProfitRatio2().split("\\|");
			//分润方案3
			String[] split3 = b2cShopperbi.getMerchProfitRatio3().split("\\|");
			request.setAttribute("split2", split2);
			request.setAttribute("split3", split3);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取商户信息失败);
		}
			
		return "recheck/recheckmerchant";
	}

	/**
	 * 1.判断是否审核通过：
	 * 	 a.复核不通过：保存不通过原因与复核状态。
	 * 2.判断是否首次审核还是非首次审核。
	 * 3.首次审核：
	 *   	a.结算信息上报到海科(调用注册)，上报失败，抛出溢出，成功（上报成功，已上报），继续往下。
	 *      a2.信息上报弘付，上报失败，抛出溢出，成功，继续往下
	 *   	b.判断是否已注册，否：调用注册（个人，企业）接口。
	 *   	c.调用激活接口，激活商户。
	 *   	d.发送短信。
	 *   	e.预约信息,正式信息同步。
	 *  4.非首次审核：
	 *  	a.结算信息上报到海科(调用注册)，上报失败，抛出溢出，成功（上报成功，已上报），继续往下。
	 *      a2.信息上报弘付，上报失败，抛出溢出，成功，继续往下
	 *  	b.调用修改结算信息接口，调用手续费修改接口。
	 *  	c.预约信息与正式信息同步。
	 *  5.添加扫码支付
	 * @param request
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=saveReCheckShopper")
	@FormToken(remove=true)
	public String saveReCheckShopper(HttpServletRequest request,ShopPerbiForm mbForm)throws Exception {
		String shopperId=mbForm.getShopperid();
		String recheckmerchantflag=mbForm.getRecheckmerchantflag();//复核结果
		String recheckmerchantremark=mbForm.getRecheckmerchantremark();//不通的原因
		if(!StringUtils.isNotEmpty(shopperId)){
			throw new BusinessException(ExceptionDefine.复核商户,new String[]{"商户编号为空"});
		}
		
		B2cShopperbiTemp b2cShopperbi=shopPerbiService.queryShopPerbi(shopperId);
		B2cShopperbi b2cshopperbis=shopPerbiService.queryFormalShopPerbi(shopperId);
		
		//1通过,
		if(recheckmerchantflag.equals(Constants.CON_YES)){
			//增加判读是否启用弘付注册 1启用 0 不起用
			if(acmsMapUtils.getAcmsMap().get("hf_open_flg").equals(Constants.CON_YES)){
				 //海科成功后调弘付,判断是否申请过,0未申请，1已申请去修改
				String respCede="";
				String hf_psam_d0 = "";

				//弘付商户信息图片报备
				MposPhotoTmp mposPhotoTmp = mposPhotoTmpService.findByPhotoId(b2cShopperbi.getPhotoid());
				Map<String, String> hfimagesRegResult = HfImageRegUtil.hfImagesReg(mposPhotoTmp, String.valueOf(b2cShopperbi.getShopperid()));
				if (!Constants.SUCCESS_CODE_0000.equals(hfimagesRegResult.get("rspCode"))){
					throw new BusinessException(ExceptionDefine.弘付报备商户信息图片出错, new String[]{"弘付报备商户信息图片出错"});
				}
				if(Constants.CON_NO.equals(b2cShopperbi.getHfflg())||StringUtils.isEmpty(b2cShopperbi.getHfflg())){
					net.sf.json.JSONObject jsonObject1 = addHfMerchantPortD0(b2cShopperbi);
					respCede = (String) jsonObject1.get("respCode");
					hf_psam_d0 = (String) jsonObject1.get("hf_psam");

					if(!ConstantsEnv.HF_CODE_ADD.equals(respCede)){
						throw new BusinessException(ExceptionDefine.复核商户,new String[]{"弘付报备D0申请失败"});
					}
					b2cShopperbi.setHfflg(Constants.CON_YES);
					b2cShopperbi.setHfpsamd0(hf_psam_d0);
				}else{
					net.sf.json.JSONObject jsonObject1 = addHfMerchantPortD0(b2cShopperbi);
					respCede = (String) jsonObject1.get("respCode");

					if(!ConstantsEnv.HF_CODE_UPDATE.equals(respCede)){
						throw new BusinessException(ExceptionDefine.复核商户,new String[]{"弘付报备D0修改失败"});
					}
				}
			}
			
			if (acmsMapUtils.getAcmsMap().get("hk_open_flg").equals(Constants.CON_YES)){
				String hkCOde=addHkMerchantPort(b2cShopperbi);
				if(Constants.HK_SUCCESS_CODE.equals(hkCOde)||Constants.HK_REPEAT_CODE_H2.equals(hkCOde)){
					if(Constants.HK_REPEAT_CODE_H2.equals(hkCOde)){
						String updateHkCOde=updateHkMerchantPort(b2cShopperbi);
						if(!(Constants.RESPONSE_CODE.equals(updateHkCOde))){
							throw new BusinessException(ExceptionDefine.复核商户,new String[]{"海科"});
						}
					}
				}else{
					throw new BusinessException(ExceptionDefine.复核商户,new String[]{"海科报备添加失败"});
				}
			}

			if(b2cshopperbis==null){
				regYsbMerchant(recheckmerchantflag,recheckmerchantremark,b2cShopperbi,request);
			}else{				
				updateYsbMerchant(recheckmerchantflag,recheckmerchantremark,b2cShopperbi,request);
			}
			
			
		}else{
			if(b2cshopperbis!=null){
				b2cShopperbi.setShopperidP(b2cshopperbis.getShopperidP());
			}
			b2cShopperbi.setRecheckmerchantflag(recheckmerchantflag);
			b2cShopperbi.setRecheckmerchantremark(recheckmerchantremark);
			b2cShopperbi.setRecheckdate(new Date());
			reCheckService.updateNOtCheck(b2cShopperbi,b2cshopperbis);
			sendmessageService.sendMessageFail(b2cShopperbi,request);
			request.setAttribute(Constants.MESSAGE_KEY,"复审成功!");
		}
		request.setAttribute("url","reCheck.htm?method=reCheckShoperBiList");
		return "/returnPage";
	}
	
	

	/**
	 * 激活商户
	 * @throws BusinessException 
	 */
	private Map activateMerchantPort(B2cShopperbiTemp b2cShopperbi) throws Exception {
		HashMap params=new HashMap();
		
		Date dates = new Date();
		String mradom = RandomStringUtils.randomNumeric(6);
		String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbi.getB2cShopperbiId();
		String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");
		
	    params.put("orderId", orderId);	
        params.put("userId", b2cShopperbi.getYsbNo());
        params.put("activeStatus", Constants.TYPE_2);//已激活

        JSONObject obs = JSONObject.fromObject(params);
        String request = "activeStatus=" + Constants.TYPE_2 + "&orderId="+orderId+"&userId="+ b2cShopperbi.getYsbNo() ;
        log.info("请求激活银生宝账号请求参数："+request);
	    log.info("请求激活银生宝账号："+DynamicConfigLoader.getByEnv("update_user_status_url")+request);
	    String result = HttpClientUtils.REpostRequestStrNormal(DynamicConfigLoader.getByEnv("update_user_status_url"), request);	  
		Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(result);
        
        return resultMap;
		
	}

	/**判断注册商户是否绑定银生宝账号
	 * @param request
	 * @param b2cShopperbi
	 * @param userType
	 * @throws Exception
	 */
	private String saveCreate(HttpServletRequest request, B2cShopperbiTemp b2cShopperbi, String userType) throws Exception {
		
		JSONObject ob=null;
		String rspCode="";
		String ysbNo="";
		String factoringNo="";
		//区分企业还是个人
		Map ysbMap=null;
		if(Constants.TYPE_P.equals(userType)){
			ysbMap=regMerchant(b2cShopperbi,userType);
		}
		if(Constants.TYPE_C.equals(userType)){
			ysbMap=regCompany(b2cShopperbi,userType);
		}
		logger.info("银生宝注册返回码:"+ysbMap);
		ob= JSONObject.fromObject(ysbMap);
		rspCode=(String)ob.get("rspCode");
		String rspMsg=(String)ob.get("rspMsg");
		if(Constants.RESPONSE_CODE.equals(rspCode)){
			
			//注册扫码支付
			Map qrPayMap=saveQrPay(request,b2cShopperbi,userType);
			
			if(Constants.RESPONSE_CODE.equals(qrPayMap.get("rspCode"))){
				ysbNo=(String)ob.get("userId");
				factoringNo=(String)ob.get("factor_userId");
				b2cShopperbi.setYsbNo(ysbNo);
				b2cShopperbi.setFactoringno(factoringNo);
				b2cShopperbi.setOpen_mpos_create_date(new Date());
				b2cShopperbi.setQrPayNo(qrPayMap.get("qrPayNo")==null?"":qrPayMap.get("qrPayNo").toString());
				b2cShopperbi.setQrpayMerchantkey(qrPayMap.get("qrpayMerchantkey")==null?"":qrPayMap.get("qrpayMerchantkey").toString());
				
				saveB2cShopperbi(request,b2cShopperbi);
				return rspCode;
			}
			else{
				throw new BusinessException(ExceptionDefine.注册银生宝失败,new String[]{"注册扫码支付"});
			}
			
		}else{
			if(rspCode.equals("6012")){
				throw new BusinessException(ExceptionDefine.注册银生宝失败,new String[]{rspMsg});
			}else{
				throw new BusinessException(ExceptionDefine.注册银生宝失败,new String[]{"注册银生宝"});
			}
		}
	}

	/**注册企业
	 * @param b2cShopperbi
	 * @param userType
	 * @return
	 * @throws Exception 
	 */
	private Map regCompany(B2cShopperbiTemp b2cShopperbi, String userType) throws Exception {
		HashMap params=new HashMap();
		Date dates = new Date();
		String mradom = RandomStringUtils.randomNumeric(6);
		String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbi.getB2cShopperbiId();
		String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");
	
		//基本信息
		String name=b2cShopperbi.getName();
		String idCard=b2cShopperbi.getIDNo();
		String tel=b2cShopperbi.getStel();
		String merchantNo=b2cShopperbi.getShopperid()==null?"":b2cShopperbi.getShopperid().toString();
		Long agentNo=b2cShopperbi.getShopperidP();
		String institutionNo=b2cShopperbi.getOrgNo();
		String platformType="";
		if(agentNo!=null){
			platformType=Constants.CON_NO;//0 自有
		}else{
			platformType=Constants.CON_YES;//机构
		}
		//结算信息
//        String settlementType=b2cShopperbi.getSettlementType();
        String accountBankDictval=b2cShopperbi.getAccountbankdictval();
        String accountbankname=b2cShopperbi.getAccountbankname();
        String accountbankprovCode=b2cShopperbi.getAccountBankProvCode();
        String accountBankCityCode=b2cShopperbi.getAccountBankCityCode();
        String accountbankclientname=b2cShopperbi.getAccountbankclientname();
        String accountbankno=b2cShopperbi.getAccountbankno();
//        String CardType=b2cShopperbi.getCardType();
        //T+1提现手续费
//        Double t1fee=b2cShopperbi.getT1fee();
        //T+1封顶值
//        String t1topamount="";
        //刷卡手续费
        List merchantFeeList=shopPerbiService.findMerchantFeeByMpos(b2cShopperbi.getShopperid());
        
        //t1type
        params.put("t1Type", b2cShopperbi.getT1type()==null?"0":b2cShopperbi.getT1type());
//     	params.put("t1fee", b2cShopperbi.getT1fee()==null?"0":b2cShopperbi.getT1fee());//t+1提现手续费费率
    	params.put("t1topamount", b2cShopperbi.getT1topamount()==null?"0":b2cShopperbi.getT1topamount());//t+1提现手续费

        //t+0手续费
        String issupportt0=b2cShopperbi.getIsSupportT0(); //0支持
//        String isicapplyt0="";
        Double t0singledaylimit=0.00;
        if(Constants.CON_NO.equals(issupportt0)){
//        	  isicapplyt0=b2cShopperbi.getIsIcApplyT0();
              t0singledaylimit=b2cShopperbi.getT0SingleDayLimit();
//              params.put("isicapplyt0", isicapplyt0==null?"":isicapplyt0);
              params.put("t0Type", b2cShopperbi.getT0type()==null?"0":b2cShopperbi.getT0type());
              params.put("t0fee", Constants.D0_FEE); 
              params.put("t0fixedamount", Constants.T0_FIXED_AMOUNT);
              params.put("t0topamount", b2cShopperbi.getT0topamount()==null?"":b2cShopperbi.getT0topamount());
//              params.put("t0additionfee",b2cShopperbi.getT0additionfee()==null?"":b2cShopperbi.getT0additionfee()); 
              params.put("t0minamount", b2cShopperbi.getT0minamount());
              params.put("t0maxamount", b2cShopperbi.getT0maxamount());
              params.put("creditAmount", t0singledaylimit==null?"":t0singledaylimit);
              params.put("t0singledaylimit", t0singledaylimit==null?"":t0singledaylimit);
        }else{
//        	 params.put("isicapplyt0","");
             params.put("t0Type","0");
             params.put("t0fee",""); 
             params.put("t0fixedamount","");
             params.put("t0topamount","");
//             params.put("t0additionfee",""); 
             params.put("t0minamount","");
             params.put("t0maxamount","");
             params.put("creditAmount",Constants.CON_NO);
             params.put("t0singledaylimit","");
        }
        params.put("userType", userType==null?"":userType);
        params.put("orderId", orderId==null?"":orderId);
        params.put("orderTime", orderTime==null?"":orderTime);
        params.put("idNum", idCard==null?"":idCard);
        params.put("register_corpTel", tel==null?"":tel);
        params.put("register_prinName",  URLDecoder.decode(name==null?"":name,"UTF-8"));
        params.put("prov", accountbankprovCode==null?"":accountbankprovCode);
        params.put("city", accountBankCityCode==null?"":accountBankCityCode);
        String bankCode=shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval())==null?"":URLDecoder.decode(shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval()).getDictid(),"UTF-8");
        params.put("bankCode", bankCode);
        params.put("bankNo", accountbankno==null?"":accountbankno);
        params.put("bankName", accountbankname==null?"":URLDecoder.decode(accountbankname,"UTF-8"));
        params.put("register_corpFinanceName", URLDecoder.decode(name,"UTF-8"));
        params.put("linkman", name==null?"":URLDecoder.decode(name,"UTF-8"));
        params.put("register_corpLicenceNo",b2cShopperbi.getLicenseNo()==null?"":b2cShopperbi.getLicenseNo());
        params.put("register_corpName", accountbankclientname==null?"":URLDecoder.decode(accountbankclientname,"UTF-8"));
        params.put("register_email",b2cShopperbi.getSemail()==null?"":b2cShopperbi.getSemail());
        params.put("register_corpAccountLicenceNo",b2cShopperbi.getLicenseNo()==null?"":b2cShopperbi.getLicenseNo());
        params.put("register_corpOrganizeNo",b2cShopperbi.getLicenseNo()==null?"":b2cShopperbi.getLicenseNo());
        params.put("register_corpTaxId",b2cShopperbi.getLicenseNo()==null?"":b2cShopperbi.getLicenseNo());
        params.put("register_corpAddr", b2cShopperbi.getSaddress()==null?"":URLDecoder.decode(b2cShopperbi.getSaddress(),"UTF-8"));
        params.put("register_corpZip",b2cShopperbi.getSzip()==null?"":b2cShopperbi.getSzip());
        params.put("proxyId", agentNo==null?"":agentNo);
        params.put("merchantNo", merchantNo==null?"":merchantNo);
        params.put("institutionNo", institutionNo==null?"":institutionNo);
        //params.put("platformType", platformType);
//        params.put("settlementType", settlementType==null?"":settlementType);
        params.put("commissionIds", merchantFeeList);
       // params.put("CardType", CardType);
        
        params.put("issupportt0", issupportt0==null?"":issupportt0);//是否支持T0提现
        
        params.put("scompany", b2cShopperbi.getScompany());
		params.put("agentNo", b2cShopperbi.getShopperidP());
		params.put("terminalNo", b2cShopperbi.getHfpsam());
		//分润方案
		params.put("profitOwner", b2cShopperbi.getProfitOwner());//分润给那个代理商
		params.put("agentProfitRatio", b2cShopperbi.getAgentProfitRatio()); //代理商分润百分比
		params.put("merchProfitRatio1", b2cShopperbi.getMerchProfitRatio1());//商户分润方案1
		params.put("merchProfitRatio2", b2cShopperbi.getMerchProfitRatio2()); //商户分润方案2
		params.put("merchProfitRatio3", b2cShopperbi.getMerchProfitRatio3()); //商户分润方案3
        
        JSONObject obs = JSONObject.fromObject(params);
        log.info("注册银生宝企业："+DynamicConfigLoader.getByEnv("simple_register_company_url")+obs.toString());
        String resultString =HttpClientUtils.REpostRequestStr(DynamicConfigLoader.getByEnv("simple_register_company_url"),obs.toString());
		Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);
        
        return resultMap;
	}

	/**个人商户注册（注册参数）
	 * @param b2cShopperbi
	 * @return
	 * @throws Exception 
	 */
	private Map regMerchant(B2cShopperbiTemp b2cShopperbi,String userTypes) throws Exception {
		HashMap params=new HashMap();
		
		Date dates = new Date();
		String mradom = RandomStringUtils.randomNumeric(6);
		String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbi.getB2cShopperbiId();
		String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");
		//基本信息
		String userType=userTypes;
		String linkName=b2cShopperbi.getName();
		String idCard=b2cShopperbi.getIDNo();
		String tel=b2cShopperbi.getStel();
		String merchantNo=b2cShopperbi.getShopperid()==null?"":b2cShopperbi.getShopperid().toString();
		Long agentNo=b2cShopperbi.getShopperidP();
		String institutionNo=b2cShopperbi.getOrgNo();
		String platformType="";
		if(agentNo!=null){
			platformType=Constants.CON_NO;//0 自有
		}else{
			platformType=Constants.CON_YES;//机构
		}
		//结算信息
        //String settlementType=b2cShopperbi.getSettlementType();
        String accountbankname=b2cShopperbi.getAccountbankname();
        String accountbankprovCode=b2cShopperbi.getAccountBankProvCode();
        String accountBankCityCode=b2cShopperbi.getAccountBankCityCode();
        String accountbankclientname=b2cShopperbi.getAccountbankclientname();
        String accountbankno=b2cShopperbi.getAccountbankno();
       // String CardType=b2cShopperbi.getCardType();
        //刷卡手续费
        List merchantFeeList=shopPerbiService.findMerchantFeeByMpos(b2cShopperbi.getShopperid());
        //T+1提现手续费
       // Double t1fee=b2cShopperbi.getT1fee();

      
        //t1type
        params.put("t1Type", b2cShopperbi.getT1type()==null?"0":b2cShopperbi.getT1type());
        //params.put("t1fee", b2cShopperbi.getT1fee()==null?"0":b2cShopperbi.getT1fee());
        params.put("t1topamount",b2cShopperbi.getT1topamount()==null?"0":b2cShopperbi.getT1topamount());
        
        //t+0手续费
        String issupportt0=b2cShopperbi.getIsSupportT0(); //0支持
        Double t0singledaylimit=0.00;
        if(Constants.CON_NO.equals(issupportt0)){
        	  //isicapplyt0=b2cShopperbi.getIsIcApplyT0();
              t0singledaylimit=b2cShopperbi.getT0SingleDayLimit();
             // params.put("isicapplyt0", isicapplyt0==null?"":isicapplyt0);
              params.put("t0Type", b2cShopperbi.getT0type()==null?"0":b2cShopperbi.getT0type());
              params.put("t0fee", Constants.D0_FEE); 
              params.put("t0fixedamount", Constants.T0_FIXED_AMOUNT);
              params.put("t0topamount", b2cShopperbi.getT0topamount()==null?"":b2cShopperbi.getT0topamount());
             // params.put("t0additionfee",b2cShopperbi.getT0additionfee()==null?"":b2cShopperbi.getT0additionfee()); 
              params.put("t0minamount", b2cShopperbi.getT0minamount());
              params.put("t0maxamount", b2cShopperbi.getT0maxamount());
              params.put("creditAmount", t0singledaylimit==null?"":t0singledaylimit);
        }else{
        	// params.put("isicapplyt0","");
             params.put("t0Type","0");
             params.put("t0fee",""); 
             params.put("t0fixedamount","");
             params.put("t0topamount","");
            // params.put("t0additionfee",""); 
             params.put("t0minamount","");
             params.put("t0maxamount","");
             params.put("creditAmount",Constants.CON_NO);
        }
        params.put("userType", userType==null?"":userType);
        params.put("orderId", orderId==null?"":orderId);
        params.put("orderTime", orderTime==null?"":orderTime);
        params.put("name", linkName==null?"":URLDecoder.decode(linkName,"UTF-8"));
        params.put("idNum", idCard==null?"":idCard);
        params.put("mobilePhoneNum", tel==null?"":tel);
        String bankCode=shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval())==null?"":URLDecoder.decode(shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval()).getDictid(),"UTF-8");
        params.put("bankCode", bankCode==null?"":bankCode);
        params.put("bankNo", accountbankno==null?"":accountbankno);
        params.put("bankName", accountbankname==null?"":URLDecoder.decode(accountbankname,"UTF-8"));
        params.put("prov", accountbankprovCode==null?"":accountbankprovCode);
        params.put("city", accountBankCityCode==null?"":accountBankCityCode);
        
        params.put("merchantNo", merchantNo==null?"":merchantNo);
        params.put("proxyId", agentNo==null?"":agentNo);
        params.put("institutionNo", institutionNo==null?"":institutionNo);
        params.put("platformType", platformType==null?"":platformType);
       // params.put("settlementType", settlementType==null?"":settlementType);
       
        params.put("commissionIds", merchantFeeList);
        params.put("issupportt0", issupportt0==null?"":issupportt0);//是否支持T0提现
        
        params.put("scompany", b2cShopperbi.getName());
		params.put("agentNo", b2cShopperbi.getShopperidP());
		params.put("terminalNo", b2cShopperbi.getHfpsam());
		//分润方案
		params.put("profitOwner", b2cShopperbi.getProfitOwner());//分润给那个代理商
		params.put("agentProfitRatio", b2cShopperbi.getAgentProfitRatio()); //代理商分润百分比
		params.put("merchProfitRatio1", b2cShopperbi.getMerchProfitRatio1());//商户分润方案1
		params.put("merchProfitRatio2", b2cShopperbi.getMerchProfitRatio2()); //商户分润方案2
		params.put("merchProfitRatio3", b2cShopperbi.getMerchProfitRatio3()); //商户分润方案3
		
		
        JSONObject obs = JSONObject.fromObject(params);
        log.info("注册银生宝个人："+ DynamicConfigLoader.getByEnv("simple_register_url")+obs.toString());
        String resultString =HttpClientUtils.REpostRequestStr( DynamicConfigLoader.getByEnv("simple_register_url"),obs.toString());
		Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);
        
        return resultMap;
	}
	
	
	/**
	 * 2.子账户：注册收单
	 * 3.注册收单：手续费传list
	 * @param request
	 * @param b2cShopperbi
	 * @param ysbNo
	 * @throws Exception 
	 */
	private void saveB2cShopperbi(HttpServletRequest request,
			B2cShopperbiTemp b2cShopperbi) throws Exception {
			reCheckService.saveMerchant(b2cShopperbi);
			request.setAttribute(Constants.MESSAGE_KEY,"审核成功!");
	}

	/**转化商户类型
	 * @param merchantType
	 * @return
	 */
	private String getType(String merchantType) {
		String type="";
		if(Constants.CON_NO.equals(merchantType)){
			type=Constants.TYPE_P;
		}else{
			type=Constants.TYPE_C;
		}
		return type;
	}


	/**商户复核详情
	 * @param request
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=reCheckMerchantDetails")
	public String reCheckMerchantDetails(HttpServletRequest request,ShopPerbiForm mbForm)throws Exception {
		B2cShopperbi b2cShopperbiFormal = null;
		B2cShopperbiTemp b2cShopperbi =null;
		try {
			String shopperID=request.getParameter("shopperId");
			if(StringUtils.isEmpty(shopperID)){
			    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url","shopPerbi.htm?method=shopPerbiCheckList");
			}else{
				b2cShopperbi = shopPerbiService.queryShopPerbi(shopperID);
				b2cShopperbiFormal = shopPerbiService.queryFormalShopPerbi(shopperID);
			}
			//获取省
			List<Area> Provincial=shopPerbiService.searchProvince();
			request.setAttribute("Provincial",Provincial);
			//获取市
			List<Area> list = shopPerbiService.searchArea();
	    	request.setAttribute("area",list);
			
	    	//行业类型
			List<B2cDict> cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
			request.setAttribute("cillinglist", cillinglist);
	        //代理商列表
	        String path = request.getSession().getServletContext().getContextPath();
	        request.setAttribute("agentlist",path+"agent/selectAgentTree.htm");
	        
	        if(b2cShopperbi!=null){
	        	//获取临时表代理商
	            Long shopperId = b2cShopperbi.getShopperidP();
	            if(shopperId!=null){
	            	Agent agent=shopPerbiService.searchAgent(shopperId);
	            	if(agent!=null){
	            		request.setAttribute("agentName", agent.getScompany());
	            		request.setAttribute("agentId", agent.getShopperid());
	            	}else{
	            		//防止错误数据为空
	            		request.setAttribute("agentName", "");
	            		request.setAttribute("agentId", "");
	            	}
	            }
	           //获取银行
				B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval());
		    	request.setAttribute("bankName",dicbank);
		       //证照
		    	Long photoid = b2cShopperbi.getPhotoid();
		    	if(photoid!=null){
		    		MposPhotoTmp photo =  shopPerbiService.selectPhotoTmpById(photoid);
		    		request.setAttribute("photo", photo);
		    		request.setAttribute("image_get_url", DynamicConfigLoader.getByEnv("imageget.url"));
		    	}
	        }
	        if(b2cShopperbiFormal!=null){
	        	//获取正式表代理商
	        	Long shopperIdFormal = b2cShopperbiFormal.getShopperidP();
	        	if(shopperIdFormal!=null){
	            	Agent agent=shopPerbiService.searchAgent(shopperIdFormal);
	            	request.setAttribute("agentNameFormal", agent.getScompany());
	            	request.setAttribute("agentIdFormal", agent.getShopperid());
	            }
	        	//获取银行
	        	B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbiFormal.getAccountbankdictval());
		    	request.setAttribute("bankNameFormal",dicbank);
		    	//证照
		    	Long photoid = b2cShopperbiFormal.getPhotoid();
		    	if(photoid!=null){
		    		MposPhotoTmp photo = shopPerbiService.selectPhotoTmpById(photoid);
		    		request.setAttribute("photoFormal", photo);
		    		request.setAttribute("image_get_urlFormal", DynamicConfigLoader.getByEnv("imageget.url"));
		    	}
	        }
	        
	        String shopperTel = null;
			if(b2cShopperbi!=null){
				shopperTel = b2cShopperbi.getStel();
			if(b2cShopperbiFormal!=null&&shopperTel==null){
				shopperTel = b2cShopperbiFormal.getStel();
				}
			}
			
			
			// 手续费，临时表
			MposMerchantFee s0creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperID, Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
			MposMerchantFee s0debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperID, Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
			
			MposMerchantFee d0creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperID, Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
			MposMerchantFee d0debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperID, Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
			
			MposMerchantFee t1creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperID, Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
			MposMerchantFee t1debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperID, Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
			
			MposMerchantFee weChatMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperID, Constants.FEE_TYPE_WECHAT);
			MposMerchantFee alipayMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperID, Constants.FEE_TYPE_ALIPAY);
			MposMerchantFee ylpayMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperID,Constants.FEE_TYPE_YLPAY);
			//无卡临时汇率
			MposMerchantFee shortCutMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperID, Constants.FEE_TYPE_SHORTCUT);
			MposMerchantFee b2cMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperID, Constants.FEE_TYPE_B2C);
			
			
			/**
			 * 10月20号添加速惠费率
			 */
			MposMerchantFee shortCutSHMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperID, Constants.FEE_TYPE_SHD0);
			request.setAttribute("shortCutSHMerchantFeeTemp", shortCutSHMerchantFeeTemp);
			request.setAttribute("shortCutMerchantFeeTemp", shortCutMerchantFeeTemp);
			request.setAttribute("b2cMerchantFeeTemp", b2cMerchantFeeTemp);
			
			request.setAttribute("s0creditMerchantFeeTemp", s0creditMerchantFeeTemp);
			request.setAttribute("s0debitMerchantFeeTemp", s0debitMerchantFeeTemp);
			
			request.setAttribute("d0creditMerchantFeeTemp", d0creditMerchantFeeTemp);
			request.setAttribute("d0debitMerchantFeeTemp", d0debitMerchantFeeTemp);
			
			request.setAttribute("t1creditMerchantFeeTemp", t1creditMerchantFeeTemp);
			request.setAttribute("t1debitMerchantFeeTemp", t1debitMerchantFeeTemp);
			
			request.setAttribute("weChatMerchantFeeTemp", weChatMerchantFeeTemp);
			request.setAttribute("alipayMerchantFeeTemp",  alipayMerchantFeeTemp);
			request.setAttribute("ylpayMerchantFeeTemp",ylpayMerchantFeeTemp);
			
			
			MposMerchantFee s0creditMerchantFee = shopPerbiService.findMposMerchantFee(shopperID, Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
			if(s0creditMerchantFee==null&&shopperTel!=null){
				s0creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
			}
			MposMerchantFee s0debitMerchantFee = shopPerbiService.findMposMerchantFee(shopperID, Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
			if(s0debitMerchantFee==null&&shopperTel!=null){
				s0debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
			}
			
			MposMerchantFee d0creditMerchantFee = shopPerbiService.findMposMerchantFee(shopperID, Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
			if(d0creditMerchantFee==null&&shopperTel!=null){
				d0creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
			}
			MposMerchantFee d0debitMerchantFee = shopPerbiService.findMposMerchantFee(shopperID, Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
			if(d0debitMerchantFee==null&&shopperTel!=null){
				d0debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
			}
			
			MposMerchantFee t1creditMerchantFee = shopPerbiService.findMposMerchantFee(shopperID, Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
			if(t1creditMerchantFee==null&&shopperTel!=null){
				t1creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
			}
			MposMerchantFee t1debitMerchantFee = shopPerbiService.findMposMerchantFee(shopperID, Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
			if(t1debitMerchantFee==null&&shopperTel!=null){
				t1debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
			}
			
			MposMerchantFee weChatMerchantFee = shopPerbiService.findMposMerchantFee(shopperID, Constants.FEE_TYPE_WECHAT);
			if(weChatMerchantFee==null&&shopperTel!=null){
				weChatMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_WECHAT);
			}
			MposMerchantFee alipayMerchantFee = shopPerbiService.findMposMerchantFee(shopperID, Constants.FEE_TYPE_ALIPAY);
			if(alipayMerchantFee==null&&shopperTel!=null){
				alipayMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_ALIPAY);
			}
			MposMerchantFee ylpayMerchantFee = shopPerbiService.findMposMerchantFee(shopperID,Constants.FEE_TYPE_YLPAY);
			if(ylpayMerchantFee == null && shopperTel != null){
				ylpayMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_YLPAY);
			}
			//无卡正式汇率
			MposMerchantFee shortCutMerchantFee = shopPerbiService.findMposMerchantFee(shopperID, Constants.FEE_TYPE_SHORTCUT);
			MposMerchantFee b2cMerchantFee = shopPerbiService.findMposMerchantFee(shopperID, Constants.FEE_TYPE_B2C);
			
			/**
			 * 10月20号添加速惠费率正式
			 */
			MposMerchantFee shortCutSHMerchantFee = shopPerbiService.findMposMerchantFee(shopperID, Constants.FEE_TYPE_SHD0);
			request.setAttribute("shortCutSHMerchantFee", shortCutSHMerchantFee);
			
			request.setAttribute("shortCutMerchantFee", shortCutMerchantFee);
			request.setAttribute("b2cMerchantFee", b2cMerchantFee);
			
			request.setAttribute("s0creditMerchantFee", s0creditMerchantFee);
			request.setAttribute("s0debitMerchantFee", s0debitMerchantFee);
			
			request.setAttribute("d0creditMerchantFee", d0creditMerchantFee);
			request.setAttribute("d0debitMerchantFee", d0debitMerchantFee);
			
			request.setAttribute("t1creditMerchantFee", t1creditMerchantFee);
			request.setAttribute("t1debitMerchantFee", t1debitMerchantFee);
			
			request.setAttribute("weChatMerchantFee", weChatMerchantFee);
			request.setAttribute("alipayMerchantFee",  alipayMerchantFee);
			request.setAttribute("ylpayMerchantFee",ylpayMerchantFee);
	        
 			request.setAttribute("b2cShopperbi", b2cShopperbi);
 			request.setAttribute("b2cShopperbiFormal", b2cShopperbiFormal);
 			request.setAttribute("recheck", "recheck");
 			if (b2cShopperbi.getMerchProfitRatio2()!=null&&b2cShopperbi.getMerchProfitRatio3()!=null) {	
 			//分润方案2
			String[] split2 = b2cShopperbi.getMerchProfitRatio2().split("\\|");
			//分润方案3
			String[] split3 = b2cShopperbi.getMerchProfitRatio3().split("\\|");
			request.setAttribute("split2", split2);
			request.setAttribute("split3", split3);
 			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取商户信息失败);
		}
		
		return "merchant/shopPerbiInfoDetailsNew";
	}
	
	
	/**开户信息复核
	 * @param request
	 * @param modelMap
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=reCheckBankList")
	public String reCheckBankList(HttpServletRequest request, ModelMap modelMap,
			ShopPerbiForm mbForm)throws Exception {
		//获取省
		List<Area> Provincial=shopPerbiService.searchProvince();
		request.setAttribute("Provincial",Provincial);
		//获取市
		List<Area> list = shopPerbiService.searchArea();
		request.setAttribute("area",list);
		//复核
		List reCheckBankList=reCheckService.getReCheckList(mbForm);
		request.setAttribute("reCheckBankList", reCheckBankList);
		
		String bakCount=reCheckService.getBankCount();
		request.setAttribute("Bankcount", bakCount);
		
		return "recheck/reCheckBankList";
	}
	
	/**开户信息复核
	 * @param request
	 * @param modelMap
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	
	
	@RequestMapping(params = "method=reCheckBank")
	@FormToken(save=true)
	public String reCheckBank(HttpServletRequest request, ModelMap modelMap,
			ShopPerbiForm mbForm,String shopperId)throws Exception {
		B2cShopperbiTemp b2cShopperbi=null;
		if(StringUtils.isEmpty(shopperId)){
		    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
            mbForm.setBelongsAgent(null);
            request.setAttribute("url","reCheck.htm?method=reCheckBankList");
		}else{
			b2cShopperbi=shopPerbiService.queryShopPerbi(shopperId);
		
		}
		//获取银行
		B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval());
    	request.setAttribute("bankName",dicbank);
        
        modelMap.put("b2cShopperbi", b2cShopperbi);
		
		return "recheck/reCheckBank";
	}
	
	
	/**保存复审信息
	 * 1.审核通过：将开户信息同步到正式表中，修改审核状态
	 * 2.审核不通过：修改状态
	 * @param request
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=saveReCheckBank")
	@FormToken(remove=true)
	public String saveReCheckBank(HttpServletRequest request,ShopPerbiForm mbForm)throws Exception {
		String shopperId=mbForm.getShopperid();
		String recheckaccountflag=mbForm.getRecheckaccountflag();
		String recheckaccountremark=mbForm.getRecheckaccountremark();
		if(StringUtils.isEmpty(shopperId)){
			request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
            mbForm.setBelongsAgent(null);
		}else{
			B2cShopperbiTemp b2cShopperbi=shopPerbiService.queryShopPerbi(shopperId);
			BackupsShopperInformation bkshopper=shopPerbiService.findbkshopper(new BigDecimal(shopperId));
			if(b2cShopperbi!=null){
				if(recheckaccountflag.equals("1")){
					String hkCode=updateHkMerchantPort(b2cShopperbi);
					if(Constants.RESPONSE_CODE.equals(hkCode)){
						//复审通过
						b2cShopperbi.setRecheckaccountflag(recheckaccountflag);
						b2cShopperbi.setRecheckaccountremark(recheckaccountremark);
						//复审通过更新备份表数据
						bkshopper.setAccountBankClientName(b2cShopperbi.getAccountbankclientname());
						bkshopper.setAccountBankDictval(b2cShopperbi.getAccountbankdictval());
						bkshopper.setAccountBankName(b2cShopperbi.getAccountbankname());
						bkshopper.setAccountBankNo(b2cShopperbi.getAccountbankno());
						bkshopper.setAccountBankProv(b2cShopperbi.getAccountbankprov());
						B2cShopperbiTemp shopper=shopPerbiService.queryShopPerbi(shopperId);
						//判断正式表是否存在
						B2cShopperbi bs=shopPerbiService.selectFormalShopperId(shopperId);
						if(bs!=null){
							Map map=null;
							try{
								 map=updateBankPort(b2cShopperbi);
							}catch (Exception e) {
								e.printStackTrace();
								throw new BusinessException(ExceptionDefine.修改银行卡信息失败);
							}
							JSONObject ob= JSONObject.fromObject(map);
							String rspCode=(String)ob.get("rspCode");
							if(Constants.RESPONSE_CODE.equals(rspCode)){
								
								reCheckService.updateReCheckBankY(b2cShopperbi,shopper,bkshopper);
							}else{
								throw new BusinessException(ExceptionDefine.修改银行卡信息失败);
							}
						}else{
							reCheckService.updateReCheckBank(b2cShopperbi,shopper);
						}
					}else{
						throw new BusinessException(ExceptionDefine.海科修改小商户失败,new String[]{"修改商户结算信息失败！"});
					}
			}else{
				
				//审核不通过数据还原
			
				b2cShopperbi.setAccountbankclientname(bkshopper.getAccountBankClientName());
				b2cShopperbi.setAccountbankdictval(bkshopper.getAccountBankDictval());
				b2cShopperbi.setAccountbankprov(bkshopper.getAccountBankProv());
				b2cShopperbi.setAccountbankname(bkshopper.getAccountBankName());
				b2cShopperbi.setAccountbankno(bkshopper.getAccountBankNo());
			    b2cShopperbi.setRecheckaccountflag(recheckaccountflag);
			    b2cShopperbi.setRecheckaccountremark(recheckaccountremark);
				reCheckService.updateNotReCheckBank(b2cShopperbi);
				}
				request.setAttribute(Constants.MESSAGE_KEY,"复审成功!");
				
			}
		}
		request.setAttribute("url","reCheck.htm?method=reCheckBankList");
		return "/returnPage";
	}
	
	/**
	 * 修改银行信息的远程接口
	 * @param b2cShopperbi
	 * @throws Exception 
	 * @throws UnsupportedEncodingException 
	 */
	private Map updateBankPort(B2cShopperbiTemp b2cShopperbi) throws  Exception {
		
		HashMap params=new HashMap();
		
		Date dates = new Date();
		String mradom = RandomStringUtils.randomNumeric(6);
		String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbi.getB2cShopperbiId();
		String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");
		
		String idNum=b2cShopperbi.getIDNo();
		String bankCode=shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval())==null?"":URLDecoder.decode(shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval()).getDictid(),"UTF-8");
		String bankNo=b2cShopperbi.getAccountbankno();
		String bankName=b2cShopperbi.getAccountbankname();
		String prov=b2cShopperbi.getAccountBankProvCode();
	    String city=b2cShopperbi.getAccountBankCityCode();
       
        params.put("orderId", orderId);
        params.put("orderTime", orderTime);
        params.put("idNum", idNum);
        params.put("bankCode", bankCode);
        params.put("bankNo", bankNo);
        params.put("bankName", bankName);
        params.put("prov", prov);
        params.put("city", city);
        
        log.info("修改银行卡账户信息："+DynamicConfigLoader.getByEnv("modify_bank_card_url")+params.toString());
        Map resultMap =HttpClientUtils.postRequestMap(DynamicConfigLoader.getByEnv("modify_bank_card_url"),params,Map.class);
		logger.info("修改银行卡账户信息返回码:"+resultMap);
		return resultMap;
	}

	/**开户信息复核详情
	 * @param request
	 * @param modelMap
	 * @param mbForm
	 * @param shopperId
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=reCheckBankDetails")
	public String reCheckBankDetails(HttpServletRequest request, ModelMap modelMap,
			ShopPerbiForm mbForm,String shopperId)throws Exception {
		B2cShopperbiTemp b2cShopperbi=null;
		if(StringUtils.isEmpty(shopperId)){
		    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
            mbForm.setBelongsAgent(null);
            request.setAttribute("url","reCheck.htm?method=reCheckBankList");
		}else{
			b2cShopperbi=shopPerbiService.queryShopPerbi(shopperId);
		}
		//获取银行
		B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval());
    	request.setAttribute("bankName",dicbank);
        
        modelMap.put("b2cShopperbi", b2cShopperbi);
		
		return "recheck/reCheckBankDetails";
	}

	
	/**商户证照信息复核
	 * @param request
	 * @param modelMap
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=reCheckPhotoList")
	public String reCheckPhotoList(HttpServletRequest request, ModelMap modelMap,
			ShopPerbiForm mbForm)throws Exception {
		//获取省
		List<Area> Provincial=shopPerbiService.searchProvince();
		request.setAttribute("Provincial",Provincial);
		//获取市
		List<Area> list = shopPerbiService.searchArea();
    	request.setAttribute("area",list);
		//复核
    	List reCheckList=reCheckService.getReCheck1List(mbForm);
		request.setAttribute("reCheckList", reCheckList);
		//未复核
		String reCheckMerchantCount=reCheckService.getReCheckMerchantCount();
		request.setAttribute("reCheckMerchantCount", reCheckMerchantCount);
		
		return "recheck/recheckPhotoList";
	}
	
	/**根据商户编号获取复核证照信息
	 * 
	 * @param request
	 * @param modelMap
	 * @param shopperId
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=reCheckPhoto")
	@FormToken(save=true)
	public String reCheckPhoto(HttpServletRequest request, ModelMap modelMap,String  shopperId,ShopPerbiForm mbForm)throws Exception {
		int flag;
		if(StringUtils.isEmpty(shopperId)){
			 request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
             mbForm.setBelongsAgent(null);
             request.setAttribute("url","reCheck.htm?method=reCheckPhotoList");
		}else{
			B2cShopperbiTemp b2cShopperbi=shopPerbiService.queryShopPerbi(shopperId);
			B2cShopperbi    shopper=shopPerbiService.queryFormalShopPerbi(shopperId);
			if(shopper!=null){
				flag=1;
			}else{
				flag=0;
			}
			Long photoId = b2cShopperbi.getPhotoid();
			MposPhotoTmp photo =  shopPerbiService.selectPhotoTmpById(photoId);
			modelMap.put("photo", photo);
			modelMap.put("flag", flag);
			modelMap.put("b2cShopperbi", b2cShopperbi);
			modelMap.put("image_get_url", DynamicConfigLoader.getByEnv("imageget.url"));
		}
		return "recheck/reCheckPhoto";
	}
	
	/**证照复核详情
	 * @param request
	 * @param modelMap
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=reCheckPhotoDetails")
	public String reCheckPhotoDetails(HttpServletRequest request, ModelMap modelMap,
			ShopPerbiForm mbForm)throws Exception {
		B2cShopperbiTemp b2cShopperbi=null;
		String shopperId=request.getParameter("shopperId");
		if(StringUtils.isEmpty(shopperId)){
		    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
            mbForm.setBelongsAgent(null);
            request.setAttribute("url","reCheck.htm?method=reCheckTerminalList");
		}else{
			b2cShopperbi=shopPerbiService.queryShopPerbi(shopperId);
			Long photoId = b2cShopperbi.getPhotoid();
			MposPhotoTmp photo =  shopPerbiService.selectPhotoTmpById(photoId);
			modelMap.put("photo", photo);
		}
        modelMap.put("b2cShopperbi", b2cShopperbi);
        modelMap.put("image_get_url", DynamicConfigLoader.getByEnv("imageget.url"));
		return "recheck/reCheckPhotoDetails";
	}
	
	/**保存复核证照信息
	 * @param request
	 * @param modelMap
	 * @param shopperId
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=saveReCheckPhoto")
	@FormToken(remove=true)
	public String saveReCheckPhoto(HttpServletRequest request,ShopPerbiForm mbForm)throws Exception {
		String shopperId=mbForm.getShopperid();
		String photoRecheckFlag=mbForm.getPhotoRecheckFlag();
		String remark=mbForm.getPhotoRecheckRemark();
		if(StringUtils.isEmpty(shopperId)){
			request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
            mbForm.setBelongsAgent(null);
		}else{
			B2cShopperbiTemp b2cShopperbi=shopPerbiService.queryShopPerbi(shopperId);
			if(b2cShopperbi!=null){
				if(photoRecheckFlag.equals("1")){
					b2cShopperbi.setPhotoRecheckFlag(photoRecheckFlag);
					b2cShopperbi.setPhotoRecheckRemark(remark);
					B2cShopperbi   shopper=shopPerbiService.queryFormalShopPerbi(shopperId);
					
					shopPerbiService.updateCheckShopper1(b2cShopperbi,shopper,Constants.TYPE_5,Constants.TYPE_4,remark);
					
				}else{
					b2cShopperbi.setPhotoRecheckFlag(photoRecheckFlag);
					b2cShopperbi.setPhotoRecheckRemark(remark);
					shopPerbiService.updateCheckShopper(b2cShopperbi,Constants.TYPE_5,Constants.TYPE_5,remark);
				}
				request.setAttribute(Constants.MESSAGE_KEY,"复审成功!");
				
			}
		}
		request.setAttribute("url","reCheck.htm?method=reCheckPhotoList");
		return "/returnPage";
	}
	
	
	
	
	/**随机生成数字与字母组合
	 * @param length
	 * @return
	 */
	public static String getCharAndNumr(int length)     
	{     
	    String val = "";     
	             
	    Random random = new Random();     
	    for(int i = 0; i < length; i++)     
	    {     
	        String charOrNum = random.nextInt(2) % 2 == 0 ? "char" : "num"; // 输出字母还是数字     
	                 
	        if("char".equalsIgnoreCase(charOrNum)) // 字符串     
	        {     
	            int choice = random.nextInt(2) % 2 == 0 ? 65 : 97; //取得大写字母还是小写字母     
	            val += (char) (choice + random.nextInt(26));     
	        }     
	        else if("num".equalsIgnoreCase(charOrNum)) // 数字     
	        {     
	            val += String.valueOf(random.nextInt(10));     
	        }     
	    }     
	             
	    return val;     
	}  
	
	
	
	
	/**手续费信息复审
	 * @param request
	 * @param modelMap
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=reCheckFeeList")
	public String reCheckFeeList(HttpServletRequest request, ModelMap modelMap,
			ShopPerbiForm mbForm)throws Exception {
		//获取省
		List<Area> Provincial=shopPerbiService.searchProvince();
		request.setAttribute("Provincial",Provincial);
		//获取市
		List<Area> list = shopPerbiService.searchArea();
		request.setAttribute("area",list);
		//复核
		List shopPerbilist=reCheckService.reCheckFeeList(mbForm);
		request.setAttribute("shopPerbilist", shopPerbilist);
		
		String feeCount=reCheckService.getFeeCount();
		request.setAttribute("Feecount", feeCount);
		
		return "recheck/reCheckFeeList";
	}
	
	
	
	/**手续费信息复核
	 * @param request
	 * @param modelMap
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	
	@RequestMapping(params = "method=reCheckFee")
	@FormToken(save=true)
	public String reCheckFee(HttpServletRequest request, ModelMap modelMap,
			ShopPerbiForm mbForm,String shopperId)throws Exception {
		B2cShopperbiTemp b2cShopperbi=null;
		if(StringUtils.isEmpty(shopperId)){
		    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
            mbForm.setBelongsAgent(null);
            request.setAttribute("url","reCheck.htm?method=reCheckFeeList");
		}else{
			b2cShopperbi=shopPerbiService.queryShopPerbi(shopperId);
		
		}
		//获取银行
        
        modelMap.put("b2cShopperbi", b2cShopperbi);
        modelMap.put("feeList", shopPerbiService.selectFeeByShopperid(b2cShopperbi.getShopperid()));
		return "recheck/reCheckfee";
	}
	
	
	
	
	/**
	 * 修改手续费信息的远程接口
	 * @param b2cShopperbi
	 * @throws Exception 
	 * @throws UnsupportedEncodingException 
	 */
	private Map updateFeePort(B2cShopperbiTemp b2cShopperbi) throws  Exception {
		
		HashMap params=new HashMap();
		List merchantFeeList=shopPerbiService.findMerchantFeeTempByMposList(b2cShopperbi.getShopperid());
		Date dates = new Date();
		String mradom = RandomStringUtils.randomNumeric(6);
		String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbi.getB2cShopperbiId();
		String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");
		String userId=b2cShopperbi.getYsbNo();
        params.put("userId", userId);
        params.put("t0fee", Constants.D0_FEE);
        params.put("t0Type", b2cShopperbi.getT0type()==null?"0":b2cShopperbi.getT0type());
        params.put("t1topamount", b2cShopperbi.getT1topamount()==null?"0":b2cShopperbi.getT1topamount()==null);
        params.put("t1Type", b2cShopperbi.getT0type()==null?"0":b2cShopperbi.getT0type());
        params.put("t1fee",b2cShopperbi.getT1fee()==null?"0":b2cShopperbi.getT1fee());
        params.put("t0fixedamount", Constants.T0_FIXED_AMOUNT);
        params.put("t0topamount", b2cShopperbi.getT0topamount()==null?"0.00":b2cShopperbi.getT0topamount());
        params.put("t0additionfee", b2cShopperbi.getT0additionfee()==null?"0.00":b2cShopperbi.getT0additionfee());
        params.put("t0minamount", b2cShopperbi.getT0minamount()==null?"0.00":b2cShopperbi.getT0minamount());
        params.put("t0maxamount", b2cShopperbi.getT0maxamount()==null?"0.00":b2cShopperbi.getT0maxamount());
        params.put("creditAmount", b2cShopperbi.getT0SingleDayLimit()==null?"0.00":b2cShopperbi.getT0SingleDayLimit());
        params.put("commissionIds", merchantFeeList);
        params.put("isSupportT0", b2cShopperbi.getIsSupportT0());
        log.info("修改手续费信息："+DynamicConfigLoader.getByEnv("modify_fee_url")+params.toString());
        Map resultMap =HttpClientUtils.postJsonRequestMap(DynamicConfigLoader.getByEnv("modify_fee_url"),params,Map.class);
		logger.info("修改手续费信息返回码:"+resultMap);
		return resultMap;
	}

	/**手续费信息复核详情
	 * @param request
	 * @param modelMap
	 * @param mbForm
	 * @param shopperId
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=reCheckFeeDetails")
	public String reCheckFeeDetails(HttpServletRequest request, ModelMap modelMap,
			ShopPerbiForm mbForm,String shopperId)throws Exception {
		B2cShopperbiTemp b2cShopperbi=null;
		if(StringUtils.isEmpty(shopperId)){
		    request.setAttribute(Constants.MESSAGE_KEY,"请检查，id为空！");
            mbForm.setBelongsAgent(null);
            request.setAttribute("url","reCheck.htm?method=reCheckFeeList");
		}else{
			b2cShopperbi=shopPerbiService.queryShopPerbi(shopperId);
			//获取银行
	        
	        modelMap.put("b2cShopperbi", b2cShopperbi);
	        modelMap.put("feeList", shopPerbiService.selectFeeByShopperid(b2cShopperbi.getShopperid()));
		
		}
		
		return "recheck/reCheckFeeDetails";

	}
	
	/**新增小商户到海科
	 * @param b2cShopperbi
	 * @return
	 * @throws Exception
	 */
	public String addHkMerchantPort(B2cShopperbiTemp b2cShopperbi) throws Exception {
		ISOMsg reqMsg = new ISOMsg();
		BaseChannel channel = new PostChannel(DynamicConfigLoader.getByEnv("hk_erverip"), Constants.HK_SERVERPORT, pack);
		channel.setTimeout(60000);
		channel.setHeader(DynamicConfigLoader.getByEnv("hk_header"));
	
		ISOMsg resMsg = send(buildMsgAdd(reqMsg, b2cShopperbi),channel);
		if(null == resMsg)
			throw new BusinessException(ExceptionDefine.海科增加小商户失败,new String[]{"新增商户信息为空!"});
		
		resMsg.setPackager(pack);
		String code = resMsg.getString(39);
		log.info("海科新增小商户查询响应码:" + code);
		Map map=setResult(resMsg);
		String rspMsg=new String((byte[])resMsg.getValue(61),"UTF-8");
		return code;
	}

	
	
	/**新增商户信息解析
	 * @param reqMsg
	 * @param b2cShopperbi
	 * @return
	 * @throws BusinessException
	 */
	private ISOMsg buildMsgAdd(ISOMsg reqMsg,B2cShopperbiTemp b2cShopperbi) throws BusinessException {
		reqMsg.setDirection(ISOMsg.OUTGOING);//位元表
		reqMsg.setPackager(pack);
		try {
			reqMsg.set(0, "0600");
			reqMsg.set(2,  b2cShopperbi.getAccountbankno()+ "");//提现卡号（与报备小商户号结算账号校验） BCD
			reqMsg.set(38, b2cShopperbi.getAccountbankclientname().getBytes("UTF-8"));//银行开户名 BCD
			
			reqMsg.set(44, DynamicConfigLoader.getByEnv("hk_channelid"));//附加响应数据  渠道ID
			reqMsg.set(48, b2cShopperbi.getShopperid()+"");//小商户号 BCD
			
			String bankName=shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval())==null?"":shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval()).getDict();
			String banknames=shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval())==null?"":shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval()).getDictcls();
			reqMsg.set(54,banknames.getBytes("UTF-8"));//开户银行 
			reqMsg.set(57,b2cShopperbi.getAccountbankprov().getBytes("UTF-8"));//开户行省份
			reqMsg.set(58,b2cShopperbi.getAccountBankCity().getBytes("UTF-8"));//开户行城市
			reqMsg.set(59,b2cShopperbi.getAccountBankCity().getBytes("UTF-8"));//开户行县区
			reqMsg.set(61,(bankName+b2cShopperbi.getAccountBankCity()+b2cShopperbi.getAccountbankname()).getBytes("UTF-8"));//开户行网点
			reqMsg.set(63,"10B");//清算银行账户类型
			
			HkUtils.macCalc(reqMsg, DynamicConfigLoader.getByEnv("hk_merkey"));//MAC
			log.info("新增小商户信息组装    2:"+b2cShopperbi.getAccountbankno()+"	38:"+b2cShopperbi.getAccountbankclientname()+
					"	44:"+DynamicConfigLoader.getByEnv("hk_channelid")+"	48:"+b2cShopperbi.getShopperid()+"	54:"+banknames+"	57:"+b2cShopperbi.getAccountbankprov()
					+"	58:"+b2cShopperbi.getAccountBankCity()+"	59:"+b2cShopperbi.getAccountBankCity()+
					"	61:"+(bankName+b2cShopperbi.getAccountBankCity()+b2cShopperbi.getAccountbankname())
					+"	63:"+"10B");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.海科增加小商户失败,new String[]{"海科增加小商户失败，数据组装异常！"});

		}
		return reqMsg;
	}

	
	/**修改商户信息
	 * @param b2cShopperbi
	 * @return
	 * @throws Exception 
	 */
	public String updateHkMerchantPort(B2cShopperbiTemp b2cShopperbi) throws Exception {
		Map<String, Object> parameter = new HashMap<String, Object>();
		ISOMsg reqMsg = new ISOMsg();
		BaseChannel channel = new PostChannel(DynamicConfigLoader.getByEnv("hk_erverip"), Constants.HK_SERVERPORT, pack);
		channel.setTimeout(60000);
		channel.setHeader(DynamicConfigLoader.getByEnv("hk_header"));
	
		ISOMsg resMsg = send(buildMsgUpdate(reqMsg, b2cShopperbi,parameter),channel);
		if(null == resMsg)
			throw new BusinessException(ExceptionDefine.海科修改小商户失败,new String[]{"修改商户结算信息出错！"});
		
		resMsg.setPackager(pack);
		String code = resMsg.getString(39);
		log.info("海科修改商户查询响应码:" + code);
		Map map=setResult(resMsg);
		String rspMsg=new String((byte[])resMsg.getValue(61),"UTF-8");
		if("00".equals(code)){
			String resMac = resMsg.getString(64);
			if(null != resMac){
				HkUtils.macCalc(resMsg, DynamicConfigLoader.getByEnv("hk_merkey"));
				String localMac = resMsg.getString(64);
				if(!resMac.equals(localMac)){
					throw new BusinessException(ExceptionDefine.海科修改小商户失败,new String[]{"修改商户结算信息，秘钥验证出错！"});
				}else{
					if(Constants.UPDATE_RS_PMSG.equals(rspMsg)){
						return Constants.RESPONSE_CODE;//成功
					}else{
						throw new BusinessException(ExceptionDefine.海科修改小商户失败,new String[]{rspMsg});
					}
				}
			}else{
				throw new BusinessException(ExceptionDefine.海科修改小商户失败,new String[]{rspMsg});
			}
		}else{
			throw new BusinessException(ExceptionDefine.海科修改小商户失败,new String[]{rspMsg});
		}
	}
	/**修改小商户信息
	 * @param reqMsg
	 * @param b2cShopperbi
	 * @param parameter
	 * @return
	 * @throws BusinessException 
	 */
	private ISOMsg buildMsgUpdate(ISOMsg reqMsg, B2cShopperbiTemp b2cShopperbi,
			Map<String, Object> parameter) throws BusinessException {
		reqMsg.setDirection(ISOMsg.OUTGOING);//位元表
		reqMsg.setPackager(pack);
		try {
			reqMsg.set(0, "0700");
			reqMsg.set(2,  b2cShopperbi.getAccountbankno()+ "");//提现卡号（与报备小商户号结算账号校验） BCD
			reqMsg.set(38, b2cShopperbi.getAccountbankclientname().getBytes("UTF-8"));//银行开户名 BCD
			
			reqMsg.set(44, DynamicConfigLoader.getByEnv("hk_channelid"));//附加响应数据  渠道ID
			reqMsg.set(48, b2cShopperbi.getShopperid()+"");//小商户号 BCD
			
			String bankName=shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval())==null?"":shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval()).getDict();
			String banknames=shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval())==null?"":shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval()).getDictcls();
			reqMsg.set(54,banknames.getBytes("UTF-8"));//开户银行 
			reqMsg.set(57,b2cShopperbi.getAccountbankprov().getBytes("UTF-8"));//开户行省份
			reqMsg.set(58,b2cShopperbi.getAccountBankCity().getBytes("UTF-8"));//开户行城市
			reqMsg.set(59,b2cShopperbi.getAccountBankCity().getBytes("UTF-8"));//开户行县区
			reqMsg.set(61,(bankName+b2cShopperbi.getAccountBankCity()+b2cShopperbi.getAccountbankname()).getBytes("UTF-8"));//开户行网点
			reqMsg.set(63,"10B");//清算银行账户类型
			
			HkUtils.macCalc(reqMsg, DynamicConfigLoader.getByEnv("hk_merkey"));//MAC
			log.info("修改小商户信息组装    2:"+b2cShopperbi.getAccountbankno()+"	38:"+b2cShopperbi.getAccountbankclientname()+
					"	44:"+DynamicConfigLoader.getByEnv("hk_channelid")+"	48:"+b2cShopperbi.getShopperid()+"	54:"+banknames+"	57:"+b2cShopperbi.getAccountbankprov()
					+"	58:"+b2cShopperbi.getAccountBankCity()+"	59:"+b2cShopperbi.getAccountBankCity()+
					"	61:"+(bankName+b2cShopperbi.getAccountBankCity()+b2cShopperbi.getAccountbankname())
					+"	63:"+"10B");
			reqMsg.set(63,"10B");//清算银行账户类型
			
			HkUtils.macCalc(reqMsg, DynamicConfigLoader.getByEnv("hk_merkey"));//MAC
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.海科修改小商户失败,new String[]{"组装修改商户结算信息失败！"});
		}
		return reqMsg;
	}


	/**发送信息到海科
	 * @param reqMsg
	 * @param channel
	 * @return
	 * @throws Exception
	 */
	public ISOMsg send(ISOMsg reqMsg,BaseChannel channel) throws Exception {
		try {
			channel.connect();
			log.info("查询请求报文：" + ISOUtil.hexString(reqMsg.pack()));
			channel.send(reqMsg);
			ISOMsg retMsg = channel.receive();
			log.info("海科代付查询响应报文：" + ISOUtil.hexString(retMsg.pack()));
			channel.disconnect();
			return retMsg;
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.海科增加小商户失败,new String[]{"海科小商户失败，数据转换异常！"});
		}
	}
	
	
	/**返回结果解析
	 * @param resMsg
	 * @return
	 * @throws Exception
	 */
	private Map<String, Object>  setResult(ISOMsg resMsg) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("2:", resMsg.getString(2));
		map.put("34:", resMsg.getString(34));
		map.put("39:", resMsg.getString(39));
		map.put("44:", resMsg.getString(44));
		map.put("48:", resMsg.getString(48));
		map.put("54:", new String((byte[])resMsg.getValue(54),"UTF-8"));
		map.put("57:", new String((byte[])resMsg.getValue(57),"UTF-8"));
		map.put("58:", new String((byte[])resMsg.getValue(58),"UTF-8"));
		map.put("59:", new String((byte[])resMsg.getValue(59),"UTF-8"));
		map.put("61:", new String((byte[])resMsg.getValue(61),"UTF-8"));
		map.put("63:", resMsg.getString(63));
		log.info("海科新增小商户查询响应报文map:" + map);
		return map;
	}
	


	
	
	



	/**
	 * 
	 * 1.调用功能平台的注册接口，注册成功激活账户。
	 * 2.注册成功，发送短信验证码。
	 * 
	 * @param recheckmerchantflag
	 * @param recheckmerchantremark
	 * @param b2cShopperbi
	 * @param request
	 * @throws Exception 
	 */
	private void regYsbMerchant(String recheckmerchantflag,
			String recheckmerchantremark,
			B2cShopperbiTemp b2cShopperbi, HttpServletRequest request) throws Exception {
		
		String password="";
		if((!(b2cShopperbi.getReportResource().equals("3")))&&b2cShopperbi.getShopperidP()!=null){
		    password=RandomStringUtils.randomNumeric(6);
			b2cShopperbi.setMpassword(Md5Encrypt.md5(password));
		}
		//代理商注册
		String merchantKey=com.uns.util.StringUtils.getCharAndNumr(8);
		b2cShopperbi.setMerchantKey(merchantKey);
	
		String userType=getType(b2cShopperbi.getMerchantType());
		//注册接口
		String mposCode=saveCreate(request,b2cShopperbi,userType);
		if(!Constants.RESPONSE_CODE.equals(mposCode)){
			throw new BusinessException(ExceptionDefine.激活商户失败,new String[]{"注册mpos或扫码失败"});
		}
		
		//将商户激活
		Map activateMap=activateMerchantPort(b2cShopperbi);
		logger.info("激活账户返回码:"+activateMap);
		JSONObject ob= JSONObject.fromObject(activateMap);
		String rspCode=(String)ob.get("rspCode");
		String rspMsg=(String)ob.get("rspMsg");
		
		//激活扫码支付商户
		Map qrPayactivateMap=activateQrPayMerchantPort(b2cShopperbi);
		JSONObject qrpay= JSONObject.fromObject(qrPayactivateMap);
		String qrpayRspCode=(String)qrpay.get("rspCode");
		
		if(Constants.RESPONSE_CODE.equals(rspCode)&&Constants.RESPONSE_CODE.equals(qrpayRspCode)){
	
			
			b2cShopperbi.setIsformal(new Short(Constants.CON_YES));//0表示正式表中未有信息，1表示正式表中有信息
			b2cShopperbi.setRecheckaccountflag(Constants.CON_YES);//商户开户信息复核
			b2cShopperbi.setRecheckmerchantflag(recheckmerchantflag);//商户基本信息复核(0:未审核 1：审核通过 2：审核未通过)
			b2cShopperbi.setRecheckmerchantremark(recheckmerchantremark);//商户基本信息复核备注
			b2cShopperbi.setPhotoRecheckFlag(Constants.CON_YES);//证照信息初审 0：未审核，1:审核通过，2：审核不通过
			b2cShopperbi.setRecheckdate(new Date());

			//启动事务
			b2cShopperbi.setTransact(Constants.TYPE_2);//已复核
		
			//更新证照对象
			MposPhoto photoTmp = shopPerbiService.selectPhotoTmpById(b2cShopperbi.getPhotoid());
			//更新汇率正式表信息
			reCheckService.updateMerchant(b2cShopperbi,photoTmp);
		}else{
			throw new BusinessException(ExceptionDefine.激活商户失败,new String[]{rspMsg});
		}

		//修改审核进度
		reCheckService.updateProgress(b2cShopperbi.getB2cShopperbiId().toString(),null,Constants.STATUS4,"");
		if(b2cShopperbi.getShopperidP()!=null){
			if(StringUtils.isNotEmpty(password)){
				sendmessageService.sendMessage(b2cShopperbi,password,request);
			}
		}
		request.setAttribute(Constants.MESSAGE_KEY,"复审成功!");
		
		
	}


	/**
	 * 修改商户信息:
	 * 		1.调用结算信息修改接口，手续费修改接口
	 * 		2.判断是否注册扫码支付接口
	 * @param recheckmerchantflag
	 * @param recheckmerchantremark
	 * @param stel
	 * @param b2cShopperbi
	 * @param request
	 * @throws Exception
	 */
	private void updateYsbMerchant(String recheckmerchantflag,
			String recheckmerchantremark, 
			B2cShopperbiTemp b2cShopperbi, HttpServletRequest request) throws Exception {
		b2cShopperbi.setRecheckmerchantflag(recheckmerchantflag);
		b2cShopperbi.setRecheckmerchantremark(recheckmerchantremark);
		b2cShopperbi.setRecheckdate(new Date());
		b2cShopperbi.setPhotoRecheckFlag(Constants.CON_YES);
		
		//裂变分润
		updateProfit(b2cShopperbi);

		if(!(Constants.TYPE_2.equals(b2cShopperbi.getTransact()))){
			Map activateMap=activateMerchantPort(b2cShopperbi);
			JSONObject ob=null;
			String rspCode="";
			logger.info("激活账户返回码:"+activateMap);
			ob= JSONObject.fromObject(activateMap);
			rspCode=(String)ob.get("rspCode");
			String rspMsg=(String)ob.get("rspMsg");
			//商户账户信息修改 弘付 psam
			if(b2cShopperbi.getHfpsamd0() != null && !"".equals(b2cShopperbi.getHfpsamd0())){
				Map accountMap = updateAccount(b2cShopperbi);
				JSONObject accountMapJson = JSONObject.fromObject(accountMap);
				String accountMapCode = (String) accountMapJson.get("rspCode");
				if(!Constants.RESPONSE_CODE.equals(accountMapCode)){
					throw new BusinessException(ExceptionDefine.复核商户,new String[]{"商户弘付PSAM修改失败"});
				}
			}

			if(StringUtils.isEmpty(b2cShopperbi.getQrPayNo())){//扫码
				
				//扫码注册
				String userType=getType(b2cShopperbi.getMerchantType());
				Map qrPayMap=saveQrPay(request,b2cShopperbi,userType);
			
				if(Constants.RESPONSE_CODE.equals(qrPayMap.get("rspCode"))){
					b2cShopperbi.setQrPayNo(qrPayMap.get("qrPayNo")==null?"":qrPayMap.get("qrPayNo").toString());
					b2cShopperbi.setQrpayMerchantkey(qrPayMap.get("qrpayMerchantkey")==null?"":qrPayMap.get("qrpayMerchantkey").toString());
					reCheckService.updateB2cshopper(b2cShopperbi);

				}else{
					throw new BusinessException(ExceptionDefine.激活商户失败,new String[]{"扫码注册失败"});
				}
			}else{
				//扫码注册信息修改
				Map qrMerchantMap=updateQrMerchant(b2cShopperbi);
				JSONObject qrMerchant= JSONObject.fromObject(qrMerchantMap);
				String qrcodeMerchantCode=(String)qrMerchant.get("rspCode");
				if(!Constants.RESPONSE_CODE.equals(qrcodeMerchantCode)){
					throw new BusinessException(ExceptionDefine.复核商户,new String[]{"扫码支付修改商户信息失败"});
				}
				
				//扫码支付修改商户结算卡号
				Map bankQrPayMap=updateQrPayBankPort(b2cShopperbi);
				JSONObject BankQrPayOb= JSONObject.fromObject(bankQrPayMap);
				String bankQrPayRspCode=(String)BankQrPayOb.get("rspCode");
				if(!Constants.RESPONSE_CODE.equals(bankQrPayRspCode)){
					throw new BusinessException(ExceptionDefine.复核商户,new String[]{"扫码注册修改结算信息失败"});
				}
				
				//扫码支付修改商户手续费
				Map feeQrPayMap=updateQrPayFeePort(b2cShopperbi);
				JSONObject obqrPay= JSONObject.fromObject(feeQrPayMap);
				String feeQrPayMapRspCode=(String)obqrPay.get("rspCode");
				if(!Constants.RESPONSE_CODE.equals(feeQrPayMapRspCode)){
					throw new BusinessException(ExceptionDefine.复核商户,new String[]{"扫码支付修改商户手续费失败"});
				}
				
			}
			
			//激活扫码支付商户
			Map qrPayactivateMap=activateQrPayMerchantPort(b2cShopperbi);
			JSONObject qrpay= JSONObject.fromObject(qrPayactivateMap);
			String qrpayRspCode=(String)qrpay.get("rspCode");
			//修改 mpos 银行卡
			AtomicReference<Map> bankMap= new AtomicReference<>(updateBankPort(b2cShopperbi));
			JSONObject BankOb= JSONObject.fromObject(bankMap);
			String bankRspCode=(String)BankOb.get("rspCode");
			if(!Constants.RESPONSE_CODE.equals(bankRspCode)){
				throw new BusinessException(ExceptionDefine.复核商户,new String[]{"修改结算信息失败"});
			}
			
			//修改费率
			Map feeMap=updateFeePort(b2cShopperbi);
			JSONObject obs= JSONObject.fromObject(feeMap);
			String feeRspCode=(String)obs.get("rspCode");
			if(!Constants.RESPONSE_CODE.equals(feeRspCode)){
				throw new BusinessException(ExceptionDefine.复核商户,new String[]{"mpos修改商户手续费失败"});
			}
			
			if(Constants.RESPONSE_CODE.equals(rspCode)){
				if(Constants.RESPONSE_CODE.equals(qrpayRspCode)){
					b2cShopperbi.setRecheckaccountflag(Constants.CON_YES);
					b2cShopperbi.setRecheckmerchantflag(recheckmerchantflag);
					b2cShopperbi.setRecheckmerchantremark(recheckmerchantremark);
					b2cShopperbi.setPhotoRecheckFlag(Constants.CON_NO);
					b2cShopperbi.setRecheckdate(new Date());
					b2cShopperbi.setTransact(Constants.TYPE_2);//已复核
					
					//更新证照对象
					MposPhoto photoTmp = shopPerbiService.selectPhotoTmpById(b2cShopperbi.getPhotoid());
					//同步数据
					reCheckService.updateMerchant(b2cShopperbi,photoTmp);
					if(b2cShopperbi.getShopperidP()!=null){
						//发送短信
						sendmessageService.sendCheckMessage(b2cShopperbi,request);
					}
					
					//修改审核进度
					reCheckService.updateProgress(b2cShopperbi.getB2cShopperbiId().toString(),null,Constants.STATUS4,"");
					request.setAttribute(Constants.MESSAGE_KEY,"审核成功!");
				}else{
					throw new BusinessException(ExceptionDefine.激活商户失败,new String[]{"扫码注册激活失败"});
				}
				
			}else{
				throw new BusinessException(ExceptionDefine.激活商户失败,new String[]{"mpos激活失败"});
			}
		
		}else{
			//商户账户信息修改 弘付 psam
			if(b2cShopperbi.getHfpsamd0() != null && !"".equals(b2cShopperbi.getHfpsamd0())){
				Map accountMap = updateAccount(b2cShopperbi);
				JSONObject accountMapJson = JSONObject.fromObject(accountMap);
				String accountMapCode = (String) accountMapJson.get("rspCode");
				if(!Constants.RESPONSE_CODE.equals(accountMapCode)){
					throw new BusinessException(ExceptionDefine.复核商户,new String[]{"商户弘付PSAM修改失败"});
				}
			}
			//mpos 绑定关系 信息修改
			if(b2cShopperbi.getShopperid()!=null){
				Map mposMerchantMap=updateMposAgent(b2cShopperbi);
				JSONObject mposMerchant= JSONObject.fromObject(mposMerchantMap);
				String mposMerchantCode=(String)mposMerchant.get("rspCode");
				if(!Constants.RESPONSE_CODE.equals(mposMerchantCode)){
					throw new BusinessException(ExceptionDefine.复核商户,new String[]{"mpos修改商户信息失败"});
				}
			}
			
			//mpos 修改银行卡
			Map bankMap=updateBankPort(b2cShopperbi);
			JSONObject BankOb= JSONObject.fromObject(bankMap);
			String bankRspCode=(String)BankOb.get("rspCode");
			if(!Constants.RESPONSE_CODE.equals(bankRspCode)){
				throw new BusinessException(ExceptionDefine.复核商户,new String[]{"mpos修改结算信息失败"});
			}
		
			//修改费率
			Map feeMap=updateFeePort(b2cShopperbi);
			JSONObject ob= JSONObject.fromObject(feeMap);
			String feeRspCode=(String)ob.get("rspCode");
			if(!Constants.RESPONSE_CODE.equals(feeRspCode)){
				throw new BusinessException(ExceptionDefine.复核商户,new String[]{"mpos修改商户手续费失败"});
			}
			
			//扫码注册信息修改
			Map qrMerchantMap=updateQrMerchant(b2cShopperbi);
			JSONObject qrMerchant= JSONObject.fromObject(qrMerchantMap);
			String qrcodeMerchantCode=(String)qrMerchant.get("rspCode");
			if(!Constants.RESPONSE_CODE.equals(qrcodeMerchantCode)){
				throw new BusinessException(ExceptionDefine.复核商户,new String[]{"扫码支付修改商户信息失败"});
			}
			//扫码支付修改商户结算卡号
			Map bankQrPayMap=updateQrPayBankPort(b2cShopperbi);
			JSONObject BankQrPayOb= JSONObject.fromObject(bankQrPayMap);
			String bankQrPayRspCode=(String)BankQrPayOb.get("rspCode");
			if(!Constants.RESPONSE_CODE.equals(bankQrPayRspCode)){
				throw new BusinessException(ExceptionDefine.复核商户,new String[]{"扫码注册修改结算信息失败"});
			}
			
			//扫码支付修改商户手续费
			Map feeQrPayMap=updateQrPayFeePort(b2cShopperbi);
			JSONObject obqrPay= JSONObject.fromObject(feeQrPayMap);
			String feeQrPayMapRspCode=(String)obqrPay.get("rspCode");
			if(!Constants.RESPONSE_CODE.equals(feeQrPayMapRspCode)){
				throw new BusinessException(ExceptionDefine.复核商户,new String[]{"扫码支付修改商户手续费失败"});
			}
			
			
			
			//更新证照对象
			MposPhoto photoTmp = shopPerbiService.selectPhotoTmpById(b2cShopperbi.getPhotoid());
			//同步数据
			reCheckService.updateMerchant(b2cShopperbi,photoTmp);
			//修改审核进度
			reCheckService.updateProgress(b2cShopperbi.getB2cShopperbiId().toString(),null,Constants.STATUS4,"");
			request.setAttribute(Constants.MESSAGE_KEY,"审核成功!");
		}
		
	}
	

	
	/**修改 mpos 商户服务商
	 * @param b2cShopperbi
	 * @return
	 * @throws BusinessException
	 */
	private Map updateMposAgent(B2cShopperbiTemp b2cShopperbi) throws BusinessException {
		Map params = new HashMap();
		params.put("merchantNo", b2cShopperbi.getShopperid());
		params.put("agentNo", b2cShopperbi.getShopperidP());
		JSONObject obs = net.sf.json.JSONObject.fromObject(params);
		log.info("mpos 修改服务商请求参数:"+obs.toString());
		String resultString = HttpClientUtils.REpostRequestStr(ConstantsEnv.MPOS_UPDATE_MERCHANT, obs.toString());
		Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);
		log.info("mpos mpos修改服务商 信息返回码："+ FastJson.fromJson(resultString));
		return resultMap;
	}

	/**修改 弘付 psam号
	 * @param b2cShopperbi
	 * @return
	 * @throws Exception
	 */
	private Map updateAccount(B2cShopperbiTemp b2cShopperbi) throws Exception {
		HashMap hashMap = new HashMap();
		hashMap.put("merchantNo",b2cShopperbi.getShopperid());
		hashMap.put("terminalNo", b2cShopperbi.getHfpsamd0() == null ? "" : b2cShopperbi.getHfpsamd0());
		hashMap.put("pscmNo", b2cShopperbi.getHfpsam()==null?"":b2cShopperbi.getHfpsam());
		String json = JsonUtil.toJSONString(hashMap);
		log.info("修改account弘付psam:"+ json);
		String result = HttpClientUtils.REpostRequestStr(ConstantsEnv.UPDATE_ACCOUNT_HFPSAM_URL, json);
		Map map = JsonUtil.jsonStrToMap(result);
		return map;
	}


	/**
	 * 扫码修改
	 * @param b2cShopperbi
	 * @return
	 * @throws Exception
	 */
	private Map updateQrMerchant(B2cShopperbiTemp b2cShopperbi) throws Exception {
		//判断个人还是企业
		String userType=getType(b2cShopperbi.getMerchantType());
		Map ysbMap = null;
		if(Constants.TYPE_P.equals(userType)){
			ysbMap=updateQrMerchantP(b2cShopperbi,userType);
		}
		if(Constants.TYPE_C.equals(userType)){
			ysbMap=updateQrScompay(b2cShopperbi,userType);
		}
		
		return ysbMap;
	}

	/**
	 * 企业
	 * @param b2cShopperbi
	 * @param userType
	 * @return
	 * @throws BusinessException 
	 */
	private Map updateQrScompay(B2cShopperbiTemp b2cShopperbi, String userType) throws BusinessException {
		HashMap params = new HashMap();
		String userId =b2cShopperbi.getQrPayNo();   //小商户平台账户唯一标识
		String register_corpTel =b2cShopperbi.getStel(); //手机号码
		String register_corpName=b2cShopperbi.getScompany();//企业名称
		Long agentNo = b2cShopperbi.getShopperidP();//代理商编号
		params.put("userId", userId);
		params.put("register_corpTel", register_corpTel);
		params.put("register_corpName", register_corpName);
		params.put("agentNo", agentNo);
		//固码信息
		MposPhotoTmp photo=this.shopPerbiService.selectPhotoTmpById(b2cShopperbi.getPhotoid());
		params.put("fixQrcodePic", photo==null?"":photo.getFixphoto());
		params.put("fixQrcodeCustomerName", b2cShopperbi.getFixqrcodecustomername());
		params.put("isExternalRevenue", b2cShopperbi.getIsexternalrevenue());
		params.put("settleType", b2cShopperbi.getSettleType());//默认扫码
		params.put("creditLines", b2cShopperbi.getCreditLines().toString());//授信额度
		//分润方案
		params.put("profitOwner", b2cShopperbi.getProfitOwner());//分润给谁
		params.put("agentProfitRatio", b2cShopperbi.getAgentProfitRatio());//服务商分润方案
		params.put("merchProfitRatio1", b2cShopperbi.getMerchProfitRatio1());//商户分润方案1
		params.put("merchProfitRatio2", b2cShopperbi.getMerchProfitRatio2());//商户分润方案2
		params.put("merchProfitRatio3", b2cShopperbi.getMerchProfitRatio3());//商户分润方案3
		JSONObject obs = JSONObject.fromObject(params);
		log.info("扫码修改企业信息：" + DynamicConfigLoader.getByEnv("update_qr_merchant_p.url")+ obs.toString());
		String resultString = HttpClientUtils.REpostRequestStr(
				DynamicConfigLoader.getByEnv("update_qr_scompay_c.url"), obs.toString());
		Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);
		log.info("扫码修改企业信息返回码："+resultMap);
		return resultMap;
	}
	/**
	 * 个人
	 * @param b2cShopperbi
	 * @param userType
	 * @return
	 * @throws Exception
	 */
	private Map updateQrMerchantP(B2cShopperbiTemp b2cShopperbi, String userType)throws Exception {
		HashMap params = new HashMap();
		String userId =b2cShopperbi.getQrPayNo();   //小商户平台账户唯一标识
		String scompany = b2cShopperbi.getScompany();//商户名称
		String mobilePhoneNum =b2cShopperbi.getStel(); //手机号码
		Long agentNo = b2cShopperbi.getShopperidP();//代理商编号
		params.put("userId", userId);
		params.put("scompany", null==scompany?"":scompany);
		params.put("mobilePhoneNum", mobilePhoneNum);
		params.put("agentNo", null==agentNo?"":agentNo);
		//固码信息
		MposPhotoTmp photo=this.shopPerbiService.selectPhotoTmpById(b2cShopperbi.getPhotoid());
		
		params.put("fixQrcodePic", photo==null?"":photo.getFixphoto());
		params.put("fixQrcodeCustomerName", b2cShopperbi.getFixqrcodecustomername());
		params.put("isExternalRevenue", b2cShopperbi.getIsexternalrevenue());
		params.put("settleType", b2cShopperbi.getSettleType());//默认扫码
		params.put("creditLines", b2cShopperbi.getCreditLines().toString());//授信额度
		//分润方案
		params.put("profitOwner", b2cShopperbi.getProfitOwner());//分润给谁
		params.put("agentProfitRatio", b2cShopperbi.getAgentProfitRatio());//服务商分润方案
		params.put("merchProfitRatio1", b2cShopperbi.getMerchProfitRatio1());//商户分润方案1
		params.put("merchProfitRatio2", b2cShopperbi.getMerchProfitRatio2());//商户分润方案2
		params.put("merchProfitRatio3", b2cShopperbi.getMerchProfitRatio3());//商户分润方案3
		
		JSONObject obs = JSONObject.fromObject(params);	
		
		log.info("扫码修改个人信息：" + DynamicConfigLoader.getByEnv("update_qr_merchant_p.url") + obs.toString());
		String resultString = HttpClientUtils.REpostRequestStr(
				DynamicConfigLoader.getByEnv("update_qr_merchant_p.url"), obs.toString());
		Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);
		log.info("扫码修改个人信息返回码："+resultMap);
		return resultMap;
	}

	/**扫码支付
	 * @param request
	 * @param b2cShopperbi
	 * @param userType
	 * @return 
	 * @throws Exception 
	 */
	private Map saveQrPay(HttpServletRequest request,
			B2cShopperbiTemp b2cShopperbi, String userType) throws Exception {
		String qrpayMerchantkey=RandomStringUtils.random(32, "0123456789ABCDEF");
		b2cShopperbi.setQrpayMerchantkey(qrpayMerchantkey);
		Map map=new HashMap();
		String flag="";
		JSONObject ob = null;
		String rspCode = "";
		String qrPayNo="";
		// 区分企业还是个人
		Map ysbMap = null;
		if (Constants.TYPE_P.equals(userType)) {
			ysbMap = regQrPayMerchant(b2cShopperbi, userType);
		}
		if (Constants.TYPE_C.equals(userType)) {
			ysbMap = regQrPayCompany(b2cShopperbi, userType);
		}
		logger.info("扫码支付注册返回码:" + ysbMap);
		ob = JSONObject.fromObject(ysbMap);
		rspCode = (String) ob.get("rspCode");
		if (Constants.RESPONSE_CODE.equals(rspCode)) {
			qrPayNo = (String) ob.get("userId");
			
			map.put("qrPayNo", qrPayNo);
			map.put("qrpayMerchantkey", qrpayMerchantkey);
			map.put("rspCode", rspCode);
			return map;
		} else {
			logger.info("扫码支付实名认证失败（6012）！");
			map.put("rspCode", rspCode);
			return map;
		}
		
	}

	/**扫码支付企业注册
	 * @param b2cShopperbi
	 * @param userType
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	private Map regQrPayCompany(B2cShopperbiTemp b2cShopperbi, String userType) throws Exception {

		HashMap params = new HashMap();
		Date dates = new Date();
		String mradom = RandomStringUtils.randomNumeric(6);
		String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom+ b2cShopperbi.getShopperid();
		String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");

		// 基本信息
		String name = b2cShopperbi.getName();
		String idCard = b2cShopperbi.getIDNo();
		String tel = b2cShopperbi.getStel();
		String merchantNo = b2cShopperbi.getShopperid() == null ? "": b2cShopperbi.getShopperid().toString();
		Long agentNo = b2cShopperbi.getShopperidP();
		String institutionNo = b2cShopperbi.getOrgNo();
		String platformType = "";
		if (agentNo != null) {
			platformType = Constants.CON_NO;// 0 自有
		} else {
			platformType = Constants.CON_YES;// 机构
		}
		// 结算信息
		String settlementType = b2cShopperbi.getSettlementType();
		String accountBankDictval = b2cShopperbi.getAccountbankdictval();
		String accountbankname = b2cShopperbi.getAccountbankname();
		String accountbankprovCode = b2cShopperbi.getAccountBankProvCode();
		String accountBankCityCode = b2cShopperbi.getAccountBankCityCode();
		String accountbankclientname = b2cShopperbi.getAccountbankclientname();
		String accountbankno = b2cShopperbi.getAccountbankno();
		//省市
		String accountBankCity = b2cShopperbi.getAccountBankCity();
		String accountbankprov = b2cShopperbi.getAccountbankprov();
		// 刷卡手续费
		List merchantFeeList = shopPerbiService.findQrPayMerchantFeeList(b2cShopperbi.getShopperid().toString());
		String qrD0fee=shopPerbiService.findQrPayMerchantFee(b2cShopperbi.getShopperid().toString());
		// t+0手续费
		String issupportt0 = b2cShopperbi.getIsSupportT0(); // 0支持
		String isicapplyt0 = "";
		Double t0singledaylimit = 0.00;
		if (Constants.CON_NO.equals(issupportt0)) {
			isicapplyt0 = b2cShopperbi.getIsIcApplyT0();
			t0singledaylimit = b2cShopperbi.getT0SingleDayLimit();
			params.put("t0fee", qrD0fee);
			params.put("t0fixedamount", b2cShopperbi.getT0fixedamount());
			params.put("t0minamount", b2cShopperbi.getT0minamount());
			params.put("t0maxamount", b2cShopperbi.getT0maxamount());
			params.put("creditAmount", t0singledaylimit == null ? "": t0singledaylimit);
			params.put("t0singledaylimit", t0singledaylimit == null ? "": t0singledaylimit);
		} else {
			params.put("t0fee", "0");
			params.put("t0fixedamount", "0");
			params.put("t0minamount", "0");
			params.put("t0maxamount", "0");
			params.put("creditAmount", "0");
			params.put("t0singledaylimit", "0");
		}
		params.put("userType", userType == null ? "" : userType);
		params.put("orderId", orderId == null ? "" : orderId);
		params.put("orderTime", orderTime == null ? "" : orderTime);
		params.put("idNum", idCard == null ? "" : idCard);
		params.put("register_corpTel", tel == null ? "" : tel);
		params.put("register_prinName",URLDecoder.decode(name == null ? "" : name, "UTF-8"));
		params.put("prov", accountbankprovCode == null ? "": accountbankprovCode);
		params.put("city", accountBankCityCode == null ? ""	: accountBankCityCode);
		String bankCode=shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval())==null?"":URLDecoder.decode(shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval()).getDictid(),"UTF-8");
		params.put("bankCode", bankCode);
		params.put("bankNo", accountbankno == null ? "" : accountbankno);
		params.put("bankName",accountbankname == null ? "" : URLDecoder.decode(accountbankname, "UTF-8"));
		params.put("cityName",accountBankCity);
        params.put("provinceName",accountbankprov);
        //开户银行
    	String openingBankName=shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval())==null?"":shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval()).getDict();
        params.put("openingBankName",openingBankName);
		params.put("register_corpFinanceName", URLDecoder.decode(name, "UTF-8"));
		params.put("linkman",name == null ? "" : URLDecoder.decode(name, "UTF-8"));
		params.put("register_corpLicenceNo",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi	.getLicenseNo());
		params.put("register_corpName", accountbankclientname == null ? "": URLDecoder.decode(accountbankclientname, "UTF-8"));
		params.put("register_email", b2cShopperbi.getSemail() == null ? "": b2cShopperbi.getSemail());
		params.put("register_corpAccountLicenceNo",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi.getLicenseNo());
		params.put("register_corpOrganizeNo",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi.getLicenseNo());
		params.put("register_corpTaxId",b2cShopperbi.getLicenseNo() == null ? "" : b2cShopperbi	.getLicenseNo());
		params.put("register_corpAddr", b2cShopperbi.getSaddress() == null ? ""	: URLDecoder.decode(b2cShopperbi.getSaddress(), "UTF-8"));
		params.put("register_corpZip", b2cShopperbi.getSzip() == null ? "": b2cShopperbi.getSzip());
		params.put("proxyId", agentNo == null ? "" : agentNo);
		params.put("merchantNo", merchantNo == null ? "" : merchantNo);
		params.put("institutionNo", institutionNo == null ? "" : institutionNo);
		//params.put("settlementType", settlementType == null ? "": settlementType);
		params.put("commissionIds", merchantFeeList);
		params.put("issupportt0", issupportt0 == null ? "" : issupportt0);// 是否支持T0提现
		
		String qrMerchantKey =b2cShopperbi.getQrpayMerchantkey();
		params.put("qrMerchantKey", null==qrMerchantKey?"":qrMerchantKey);
		params.put("agentNo", null==agentNo?"":agentNo);
		
		//固码信息
		MposPhotoTmp photo=this.shopPerbiService.selectPhotoTmpById(b2cShopperbi.getPhotoid());
		params.put("fixQrcodePic", photo==null?"":photo.getFixphoto());
		params.put("fixQrcodeCustomerName", b2cShopperbi.getFixqrcodecustomername());
		params.put("isExternalRevenue", b2cShopperbi.getIsexternalrevenue());
		params.put("settleType", b2cShopperbi.getSettleType());//默认结算方式1普通0快速
		params.put("creditLines", b2cShopperbi.getCreditLines().toString());//授信额度
		//分润方案
		params.put("agentProfitRatio", b2cShopperbi.getAgentProfitRatio());//服务商分润
		params.put("profitOwner", b2cShopperbi.getProfitOwner());//分润给那个服务商
		params.put("merchProfitRatio1", b2cShopperbi.getMerchProfitRatio1());//商户分润方案1
		params.put("merchProfitRatio2", b2cShopperbi.getMerchProfitRatio2());//商户分润方案2
		params.put("merchProfitRatio3", b2cShopperbi.getMerchProfitRatio3());//商户分润方案3

		
		//扫码注册睿付添加四个字段
		String cityCode = b2cShopperbi.getCity();
		Area area1 = shopPerbiService.findPayeeBankProvinceAndCity(b2cShopperbi.getCity());
		
		params.put("merchAddress", b2cShopperbi.getSaddress());//商户地址
		params.put("payeeBankId", shopPerbiService.findUnionBankCode(b2cShopperbi.getAccountbankdictval()));//银行卡所在联行总行号
		params.put("payeeBankProvince", area1.getShProvincial());//睿付开户行省份编码
		params.put("payeeBankCity", area1.getShCity());//睿付开户行城市编码
		
		
		JSONObject obs = JSONObject.fromObject(params);
		log.info("扫码支付企业注册：" + DynamicConfigLoader.getByEnv("reg_qr_pay_company_url")+ obs.toString());
		String resultString = HttpClientUtils.REpostRequestStr(DynamicConfigLoader.getByEnv("reg_qr_pay_company_url"), obs.toString());
		Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);

		return resultMap;
	
	}

	/**扫码支付
	 * @param b2cShopperbi
	 * @param userType
	 * @return
	 * @throws Exception
	 */
	private Map regQrPayMerchant(B2cShopperbiTemp b2cShopperbi, String userType) throws Exception {

		HashMap params = new HashMap();

		Date dates = new Date();
		String mradom = RandomStringUtils.randomNumeric(6);
		String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom+ b2cShopperbi.getShopperid();
		String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");
		// 基本信息
		String linkName = b2cShopperbi.getName();
		String idCard = b2cShopperbi.getIDNo();
		String tel = b2cShopperbi.getStel();
		String merchantNo = b2cShopperbi.getShopperid() == null ? "": b2cShopperbi.getShopperid().toString();
		Long agentNo = b2cShopperbi.getShopperidP();
		String institutionNo = b2cShopperbi.getOrgNo();
		String platformType = "";
		if (agentNo != null) {
			platformType = Constants.CON_NO;// 0 自有
		} else {
			platformType = Constants.CON_YES;// 机构
		}
		// 结算信息 accountbankdictval
		String settlementType = b2cShopperbi.getSettlementType();
		String accountbankname = b2cShopperbi.getAccountbankname();//支行
		String accountbankprovCode = b2cShopperbi.getAccountBankProvCode();
		String accountBankCityCode = b2cShopperbi.getAccountBankCityCode();
		String accountbankclientname = b2cShopperbi.getAccountbankclientname();
		String accountbankno = b2cShopperbi.getAccountbankno();
		//省市
		String accountBankCity = b2cShopperbi.getAccountBankCity();
		String accountbankprov = b2cShopperbi.getAccountbankprov();
		// 扫码支付
		List merchantFeeList = shopPerbiService.findQrPayMerchantFeeList(b2cShopperbi.getShopperid().toString());
		
		String qrD0fee=shopPerbiService.findQrPayMerchantFee(b2cShopperbi.getShopperid().toString());
		// t+0手续费
		String issupportt0 = b2cShopperbi.getIsSupportT0(); // 0支持
		String isicapplyt0 = "";
		Double t0singledaylimit = 0.00;
		if (Constants.CON_NO.equals(issupportt0)) {
			isicapplyt0 = b2cShopperbi.getIsIcApplyT0();
			t0singledaylimit = b2cShopperbi.getT0SingleDayLimit();
			params.put("t0fee", qrD0fee);
			params.put("t0fixedamount", b2cShopperbi.getT0fixedamount());
			params.put("t0minamount", b2cShopperbi.getT0minamount());
			params.put("t0maxamount", b2cShopperbi.getT0maxamount());
			params.put("creditAmount", t0singledaylimit == null ? "": t0singledaylimit);
		} else {
			params.put("t0fee", "0");
			params.put("t0fixedamount", "0");
			params.put("t0minamount", "0");
			params.put("t0maxamount", "0");
			params.put("creditAmount", "0");
		}
		params.put("userType", userType == null ? "" : userType);
		params.put("orderId", orderId == null ? "" : orderId);
		params.put("orderTime", orderTime == null ? "" : orderTime);
		params.put("name",linkName == null ? "" : URLDecoder.decode(linkName, "UTF-8"));
		params.put("idNum", idCard == null ? "" : idCard);
		params.put("mobilePhoneNum", tel == null ? "" : tel);
		String bankCode=shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval())==null?"":URLDecoder.decode(shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval()).getDictid(),"UTF-8");
		params.put("bankCode", bankCode == null ? "" : bankCode);
		params.put("bankNo", accountbankno == null ? "" : accountbankno);
		params.put("bankName",accountbankname == null ? "" : URLDecoder.decode(accountbankname, "UTF-8"));
		params.put("prov", accountbankprovCode == null ? "": accountbankprovCode);
		params.put("city", accountBankCityCode == null ? "": accountBankCityCode);
        params.put("cityName",accountBankCity);
        params.put("provinceName",accountbankprov);
        //开户银行
    	String openingBankName=shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval())==null?"":shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval()).getDict();
        params.put("openingBankName",openingBankName);
		params.put("merchantNo", merchantNo == null ? "" : merchantNo);
		params.put("proxyId", agentNo == null ? "" : agentNo);
		params.put("institutionNo", institutionNo == null ? "" : institutionNo);
		params.put("platformType", platformType == null ? "" : platformType);

		params.put("commissionIds", merchantFeeList);
		params.put("issupportt0", issupportt0 == null ? "" : issupportt0);// 是否支持T0提现
		
		String scompany = b2cShopperbi.getScompany();
		String qrMerchantKey =b2cShopperbi.getQrpayMerchantkey();
		params.put("scompany",null==scompany ?"" :scompany );
		params.put("qrMerchantKey",null==qrMerchantKey ?"" : qrMerchantKey );
		params.put("agentNo", null==agentNo?"":agentNo);
		
		//固码信息
		MposPhotoTmp photo=this.shopPerbiService.selectPhotoTmpById(b2cShopperbi.getPhotoid());
		params.put("fixQrcodePic", photo==null?"":photo.getFixphoto());
		params.put("fixQrcodeCustomerName", b2cShopperbi.getFixqrcodecustomername());
		params.put("isExternalRevenue", b2cShopperbi.getIsexternalrevenue());
		params.put("settleType", b2cShopperbi.getSettleType());//默认结算方式1普通0快速
		params.put("creditLines", b2cShopperbi.getCreditLines().toString());//授信额度
		//分润方案
		params.put("agentProfitRatio", b2cShopperbi.getAgentProfitRatio());//服务商分润
		params.put("profitOwner", b2cShopperbi.getProfitOwner());//分润给那个服务商
		params.put("merchProfitRatio1", b2cShopperbi.getMerchProfitRatio1());//商户分润方案1
		params.put("merchProfitRatio2", b2cShopperbi.getMerchProfitRatio2());//商户分润方案2
		params.put("merchProfitRatio3", b2cShopperbi.getMerchProfitRatio3());//商户分润方案3
		

		//扫码注册睿付添加四个字段
		String cityCode = b2cShopperbi.getCity();
		Area area1 = shopPerbiService.findPayeeBankProvinceAndCity(b2cShopperbi.getCity());

		params.put("merchAddress", b2cShopperbi.getSaddress());//商户地址
		params.put("payeeBankId", shopPerbiService.findUnionBankCode(b2cShopperbi.getAccountbankdictval()));//银行卡所在联行总行号
		params.put("payeeBankProvince", area1.getShProvincial());//睿付开户行省份编码
		params.put("payeeBankCity", area1.getShCity());//睿付开户行城市编码

		JSONObject obs = JSONObject.fromObject(params);
		log.info("注册扫码支付个人：" + DynamicConfigLoader.getByEnv("reg_qr_pay_merchant_url") + obs.toString());
		String resultString = HttpClientUtils.REpostRequestStr(
				DynamicConfigLoader.getByEnv("reg_qr_pay_merchant_url"), obs.toString());
		Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(resultString);

		return resultMap;
	
	}

	/**扫码支付激活
	 * @param b2cShopperbi
	 * @return
	 * @throws Exception 
	 */
	private Map activateQrPayMerchantPort(B2cShopperbiTemp b2cShopperbi) throws Exception {

		HashMap params=new HashMap();
		
		Date dates = new Date();
		String mradom = RandomStringUtils.randomNumeric(6);
		String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbi.getB2cShopperbiId();
		String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");
		
	    params.put("orderId", orderId);	    
        params.put("userId", b2cShopperbi.getQrPayNo());
        params.put("activeStatus", Constants.TYPE_2);//已激活
        
        JSONObject obs = JSONObject.fromObject(params);
        String request = "activeStatus=" + Constants.TYPE_2 + "&orderId="+orderId+"&userId="+ b2cShopperbi.getQrPayNo();
        log.info("请求激活扫码支付账号："+DynamicConfigLoader.getByEnv("update_qrpay_user_status_url")+request.toString());
	    String result = HttpClientUtils.REpostRequestStrNormal(DynamicConfigLoader.getByEnv("update_qrpay_user_status_url"), request);
	   
		Map resultMap = com.uns.util.JsonUtil.jsonStrToMap(result);
		 log.info("请求激活扫码支付账号返回码："+resultMap.toString());
        return resultMap;
	}
	

	

	/**扫码支付修改结算信息
	 * @param b2cShopperbi
	 * @return
	 * @throws Exception 
	 * @throws UnsupportedEncodingException 
	 */
	private Map updateQrPayBankPort(B2cShopperbiTemp b2cShopperbi) throws Exception {

		
		HashMap params=new HashMap();
		
		Date dates = new Date();
		String mradom = RandomStringUtils.randomNumeric(6);
		String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbi.getB2cShopperbiId();
		String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");
		
		String idNum=b2cShopperbi.getIDNo();
		String bankCode=shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval())==null?"":URLDecoder.decode(shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval()).getDictid(),"UTF-8");
		String openingBankName=shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval())==null?"":shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval()).getDict();
		String bankNo=b2cShopperbi.getAccountbankno();
		String bankName=b2cShopperbi.getAccountbankname();
		String prov=b2cShopperbi.getAccountBankProvCode();
	    String city=b2cShopperbi.getAccountBankCityCode();
		//省市
		String accountBankCity = b2cShopperbi.getAccountBankCity();
		String accountbankprov = b2cShopperbi.getAccountbankprov();
	    params.put("cityName",accountBankCity);
        params.put("provinceName",accountbankprov);
        params.put("openingBankName",openingBankName);
	    params.put("userId", b2cShopperbi.getQrPayNo());
     //   params.put("orderId", orderId);
      //  params.put("orderTime", orderTime);
        params.put("idNum", idNum);
        params.put("bankCode", bankCode);
        params.put("bankNo", bankNo);
        params.put("bankName", bankName);
        params.put("prov", prov);
        params.put("city", city);
        
        
        /**
         * 10月20号添加三个字段
         */
        /*Area area1 = shopPerbiService.findPayeeBankProvinceAndCity(b2cShopperbi.getCity());
		
		params.put("payeeBankId", shopPerbiService.findUnionBankCode(b2cShopperbi.getAccountbankdictval()));//银行卡所在联行总行号
		params.put("payeeBankProvince", area1.getShProvincial());//睿付开户行省份编码
		params.put("payeeBankCity", area1.getShCity());//睿付开户行城市编码
*/        
        
        log.info("扫码支付修改银行卡账户信息："+DynamicConfigLoader.getByEnv("modify_qrpay_bank_card_url")+params.toString());
       // Map resultMap =HttpClientUtils.postRequestMap(DynamicConfigLoader.getByEnv("modify_qrpay_bank_card_url"),params,Map.class);
        Map resultMap =HttpClientUtils.postJsonRequestMap(DynamicConfigLoader.getByEnv("modify_qrpay_bank_card_url"),params,Map.class);
		logger.info("扫码支付修改银行卡账户信息返回码:"+resultMap);
		return resultMap;
	
	}
	
	/**
	 * 修改扫码支付手续费费率
	 * @param b2cShopperbi
	 * @return
	 * @throws Exception 
	 */
	private Map updateQrPayFeePort(B2cShopperbiTemp b2cShopperbi) throws Exception {
		HashMap params=new HashMap();
		List merchantFeeList=shopPerbiService.findQrPayMerchantTempFeeList(b2cShopperbi.getShopperid().toString());
		Date dates = new Date();
		String mradom = RandomStringUtils.randomNumeric(6);
		String orderId = DateUtils.getTypeDate(dates, "yyyyMMdd") + mradom +b2cShopperbi.getB2cShopperbiId();
		String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");
		String userId=b2cShopperbi.getQrPayNo();
        params.put("userId", userId);
        params.put("t0fee", Constants.D0_FEE);
        params.put("t0fixedamount", Constants.T0_FIXED_AMOUNT);
        params.put("t0topamount", b2cShopperbi.getT0topamount()==null?"0.00":b2cShopperbi.getT0topamount());
        params.put("t0minamount", b2cShopperbi.getT0minamount()==null?"0.00":b2cShopperbi.getT0minamount());
        params.put("t0maxamount", b2cShopperbi.getT0maxamount()==null?"0.00":b2cShopperbi.getT0maxamount());
        params.put("creditAmount", b2cShopperbi.getT0SingleDayLimit()==null?"0.00":b2cShopperbi.getT0SingleDayLimit());
        params.put("commissionIds", merchantFeeList);
        params.put("isSupportT0", b2cShopperbi.getIsSupportT0());
        log.info("修改扫码支付手续费信息："+DynamicConfigLoader.getByEnv("update_qrpay_fee_url")+params.toString());
        Map resultMap =HttpClientUtils.postJsonRequestMap(DynamicConfigLoader.getByEnv("update_qrpay_fee_url"),params,Map.class);
		logger.info("修改扫码支付手续费信息返回码:"+resultMap);
		return resultMap;
	
	}

	/**
	 * =申请弘付D0
	 * 费率规则：例  封顶35千78费率，费率代号为（FD35Q78）。终端分
	 * 为借记卡费率与贷记卡费率填写格式  借记卡费率|贷记卡费率 例（FD20Q5|Q5）
	 * 修改费率时需要将借记卡费率与贷记卡费率一起上送
	 * @param b2cShopperbi
	 * @return
	 * @throws Exception
	 */
	public net.sf.json.JSONObject addHfMerchantPortD0(B2cShopperbiTemp b2cShopperbi) throws BusinessException {
		String respCode = null;
		try {
			String key = ConstantsEnv.HF_KEY;//加密key
			String URL = ConstantsEnv.HF_MERCHANT_URL;//请求地址

			Map<String, String> reqMap = new HashMap<String, String>();
			reqMap.put("orgMerno", b2cShopperbi.getShopperid()==null?"":b2cShopperbi.getShopperid().toString());		//机构商户唯一标识
			if(Constants.CON_NO.equals(b2cShopperbi.getHfflg())||StringUtils.isEmpty(b2cShopperbi.getHfflg())){
				reqMap.put("txnType", Constants.CON_NO);
			}else{
				reqMap.put("txnType", Constants.CON_YES);
			}
			reqMap.put("posType", Constants.CON_YES);																		//pos类型,给默认值1
			reqMap.put("bankName", b2cShopperbi.getAccountbankname());													//开户行名称
			reqMap.put("licenseEndDate", "2050-01-01");																	//营业执照到期时间   yyyy-MM-dd，无数据给默认日期
			reqMap.put("linkMan", b2cShopperbi.getName());																//联系人
			reqMap.put("areaCode", b2cShopperbi.getCity());																//受理区域代码
			reqMap.put("linkPhone", b2cShopperbi.getStel());															//联系电话
			reqMap.put("idCard", b2cShopperbi.getIDNo());																//法人身份证号
			reqMap.put("businessLicense", b2cShopperbi.getLicenseno()==null?"":b2cShopperbi.getLicenseno());			//营业执照号
			reqMap.put("accountNo", b2cShopperbi.getAccountbankno());													//账号
			reqMap.put("legalPerson", b2cShopperbi.getName());															//法人
			reqMap.put("shortName", b2cShopperbi.getName());															//商户简称
			reqMap.put("groupNo", Constants.STATUS2);
			reqMap.put("businessAddress", b2cShopperbi.getSaddress());													//营业地址
			reqMap.put("accountName", b2cShopperbi.getAccountbankclientname());												//账户名
			reqMap.put("regionCode", b2cShopperbi.getCity());															//行政地区码
			
			reqMap.put("bankNo", shopPerbiService.findB2cDictBank(b2cShopperbi.getAccountbankdictval()));																				//开户行行号,无数据给0000
			
			reqMap.put("merName", b2cShopperbi.getScompany());															//商户名称
			reqMap.put("registeredAddress", b2cShopperbi.getSaddress());												//注册地址
			
			
			reqMap.put("args", Constants.CON_YES);																			//机构自定义，给默认值1
			reqMap.put("userSign", ConstantsEnv.HF_USERSIGN);																//机构标识，由上游提供，请联系技术
			reqMap.put("requestUrl", "");																				//异步密钥通知地址  接收到返回请返回 success字符串 意味着成功接收到异步通知 则停止通知
			//，若未响应则会连续推三次，三次之后则不会继续推送
			reqMap.put("isthirdpos", ConstantsEnv.ISTHIRDPOS);								//秘钥类型   0机构秘钥 1 终端秘钥	(不填写,默认 1终端秘钥)								
	    	reqMap.put("merchant_mode", ConstantsEnv.MERCHANT_MODE); 							//商户模式 0 一户一码 1 大商户	(不填写 默认 1 大商户)
	    	
	    	reqMap.put("arMark", acmsMapUtils.getAcmsMap().get("hf_arMark"));			// CAP2100R610|R620&CAP2100R610|R620(D1费率（借|贷）& S0费率（借|贷））)   
	    	reqMap.put("sRate", acmsMapUtils.getAcmsMap().get("hf_sRate"));				//S0附加手续费填写代号，例：例(FJ200)代表加收2块（FJ250）代表加收2块5
			reqMap.put("posDealType", Constants.CON_YES);								//必填 终端交易类型 0 D1 1 S0  445347692

 
			NameValuePair[] data = {
					new NameValuePair("orgNo", ConstantsEnv.HF_ORGNO),		//机构编号，由上游提供，请联系技术
					new NameValuePair("data",new EncryptionDES(key).encrypt(URLEncoder.encode(net.sf.json.JSONObject.fromObject(reqMap).toString(),"UTF-8")))
			};
			log.info("请求弘付D0参数："+net.sf.json.JSONObject.fromObject(reqMap).toString());
			String responseStr = null;
			HttpClient httpClient = new HttpClient();
			httpClient.getParams().setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, "UTF-8");
			PostMethod postMethod = new PostMethod(URL);
			postMethod.setRequestBody(data);
			httpClient.getHttpConnectionManager().getParams()
					.setConnectionTimeout(10000);
			httpClient.getHttpConnectionManager().getParams().setSoTimeout(10000);
			httpClient.executeMethod(postMethod);

			responseStr = postMethod.getResponseBodyAsString();
			postMethod.releaseConnection();
			net.sf.json.JSONObject jsonObject = net.sf.json.JSONObject.fromObject(URLDecoder.decode(responseStr,"UTF-8"));
			log.info("弘付D0返回参数："+URLDecoder.decode(responseStr,"UTF-8"));
			return jsonObject;
//			respCode = (String) jsonObject.get("respCode");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.复核商户,new String[]{"弘付报备D0添加失败"});
		}
	}
	

	/**
	 * @param b2cShopperbi 
	 * @param feeType
	 * @return
	 */
	private String gethffee(B2cShopperbiTemp b2cShopperbi, String feeType) {
		String shopperId=b2cShopperbi.getShopperid()==null?null:b2cShopperbi.getShopperid().toString();
		MposMerchantFee s0MposMerchantFee=null;
		String fee="";
		if(org.apache.commons.lang3.StringUtils.isNotEmpty(shopperId)){
			MposMerchantFee s0debitMposMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperId,feeType,Constants.S0_CHANNEL_TYPE);
			if(s0debitMposMerchantFeeTemp!=null){
				s0MposMerchantFee = s0debitMposMerchantFeeTemp;
			}else{
				// 如果没有修改过没有临时表信息，就去查正式表
				s0MposMerchantFee = shopPerbiService.findMposMerchantFee(shopperId,feeType,Constants.S0_CHANNEL_TYPE);
			}
			int s0fee=new BigDecimal(s0MposMerchantFee.getFee()).multiply(new BigDecimal(Constants.HUNDRED)).intValue();
		    fee="Q"+s0fee;
		}else{
			fee="Q65";
		}
		return fee;
	}

	/**
	 * =申请弘付
	 * 费率规则：例  封顶35千78费率，费率代号为（FD35Q78）。终端分
	 * 为借记卡费率与贷记卡费率填写格式  借记卡费率|贷记卡费率 例（FD20Q5|Q5）
	 * 修改费率时需要将借记卡费率与贷记卡费率一起上送
	 * @param b2cShopperbi
	 * @return
	 * @throws Exception 
	 */
	private JSONObject addHfMerchantPort(B2cShopperbiTemp b2cShopperbi) throws Exception {
		String respCode = null;
		try {
			String key = ConstantsEnv.HF_KEY;//加密key
			String URL = ConstantsEnv.HF_MERCHANT_URL;//请求地址
			
			Map<String, String> reqMap = new HashMap<String, String>();
			reqMap.put("orgMerno", b2cShopperbi.getShopperid()==null?"":b2cShopperbi.getShopperid().toString());		//机构商户唯一标识
			reqMap.put("bankName", b2cShopperbi.getAccountbankname());													//开户行名称
			reqMap.put("licenseEndDate", "2050-01-01");																	//营业执照到期时间   yyyy-MM-dd，无数据给默认日期
			reqMap.put("linkMan", b2cShopperbi.getName());																//联系人
			reqMap.put("areaCode", b2cShopperbi.getCity());																//受理区域代码
			reqMap.put("linkPhone", b2cShopperbi.getStel());															//联系电话
			reqMap.put("idCard", b2cShopperbi.getIDNo());																//法人身份证号
			reqMap.put("businessLicense", b2cShopperbi.getLicenseno()==null?"":b2cShopperbi.getLicenseno());			//营业执照号
			reqMap.put("accountNo", b2cShopperbi.getAccountbankno());													//账号
			reqMap.put("legalPerson", b2cShopperbi.getName());															//法人
			reqMap.put("shortName", b2cShopperbi.getName());															//商户简称
			reqMap.put("businessAddress", b2cShopperbi.getSaddress());													//营业地址
			reqMap.put("accountName", b2cShopperbi.getAccountbankname());												//账户名
			reqMap.put("regionCode", b2cShopperbi.getCity());															//行政地区码
			reqMap.put("bankNo", "0000");																				//开户行行号,无数据给0000
			reqMap.put("merName", b2cShopperbi.getScompany());															//商户名称
			reqMap.put("registeredAddress", b2cShopperbi.getSaddress());												//注册地址
			reqMap.put("arMark", "");																					// 终端交易费率代号(注：商户直清时需上送，机构自清时无需上送)
			reqMap.put("txnType", Constants.CON_NO);																		//交易类型 0申请 1变更
			reqMap.put("posType", Constants.CON_YES);																		//pos类型,给默认值1
			reqMap.put("groupNo", Constants.STATUS2);																//费率类型（0标准类 1优惠类2综合类）

			reqMap.put("args", Constants.CON_YES);																			//机构自定义，给默认值1
			reqMap.put("userSign", ConstantsEnv.HF_USERSIGN);																//机构标识，由上游提供，请联系技术
			reqMap.put("requestUrl", "");																				//异步密钥通知地址  接收到返回请返回 success字符串 意味着成功接收到异步通知 则停止通知
																														//，若未响应则会连续推三次，三次之后则不会继续推送 
			NameValuePair[] data = {
				 	new NameValuePair("orgNo", ConstantsEnv.HF_ORGNO),		//机构编号，由上游提供，请联系技术
					new NameValuePair("data",new EncryptionDES(key).encrypt(URLEncoder.encode(JSONObject.fromObject(reqMap).toString(),"UTF-8")))
			};
			log.info("请求弘付参数："+JSONObject.fromObject(reqMap).toString());
			String responseStr = null;
			HttpClient httpClient = new HttpClient();
			httpClient.getParams().setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, "UTF-8");
			PostMethod postMethod = new PostMethod(URL);
			postMethod.setRequestBody(data);
			httpClient.getHttpConnectionManager().getParams()
					.setConnectionTimeout(10000);
			httpClient.getHttpConnectionManager().getParams().setSoTimeout(10000);
			httpClient.executeMethod(postMethod);

			responseStr = postMethod.getResponseBodyAsString();
			postMethod.releaseConnection();
			JSONObject jsonObject = JSONObject.fromObject(URLDecoder.decode(responseStr,"UTF-8"));
			log.info("弘付返回参数："+URLDecoder.decode(responseStr,"UTF-8"));
//			respCode = (String) jsonObject.get("respCode");
			return jsonObject;
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.复核商户,new String[]{"弘付报备修改失败"});
		}
	}
	/**
	 * =修改弘付
	 * @param b2cShopperbi
	 * @return
	 * @throws Exception 
	 */
	private JSONObject updateHfMerchantPort(B2cShopperbiTemp b2cShopperbi) throws Exception{
		String respCode = null;
		try {
			    String key = ConstantsEnv.HF_KEY;                                                                              //加密key
			    String URL = ConstantsEnv.HF_MERCHANT_URL;                                                                     //请求地址
				Map<String, String> reqMap = new HashMap<String, String>();
				reqMap.put("orgMerno", b2cShopperbi.getShopperid()==null?"":b2cShopperbi.getShopperid().toString());		//机构商户唯一标识
				reqMap.put("bankName", b2cShopperbi.getAccountbankname());	                                                //开户行名称
				reqMap.put("licenseEndDate", "2050-01-01");					                                                //营业执照到期时间   yyyy-MM-dd，无数据给默认日期
				reqMap.put("linkMan", b2cShopperbi.getName());								                                //联系人
				reqMap.put("areaCode", b2cShopperbi.getCity());								                                //受理区域代码
				reqMap.put("linkPhone", b2cShopperbi.getStel());						                                    //联系电话
				reqMap.put("idCard", b2cShopperbi.getIDNo());					                                            //法人身份证号
				reqMap.put("businessLicense", b2cShopperbi.getLicenseno()==null?"":b2cShopperbi.getLicenseno());			//营业执照号
				reqMap.put("accountNo", b2cShopperbi.getAccountbankno());				                                    //账号
				reqMap.put("legalPerson", b2cShopperbi.getName());							                                //法人
				reqMap.put("shortName", b2cShopperbi.getName());							                                //商户简称
				reqMap.put("businessAddress", b2cShopperbi.getSaddress());				                                    //营业地址
				reqMap.put("accountName", b2cShopperbi.getAccountbankname());							                    //账户名
				reqMap.put("regionCode", b2cShopperbi.getCity());							                                //行政地区码
				reqMap.put("bankNo", "0000");						                                                        //开户行行号,无数据给0000
				reqMap.put("merName", b2cShopperbi.getScompany());								                            //商户名称
				reqMap.put("registeredAddress", b2cShopperbi.getSaddress());				                                //注册地址
				reqMap.put("arMark", "");									                                                // 终端交易费率代号(注：商户直清时需上送，机构自清时无需上送)
														                                                //费率规则：例  封顶35千78费率，费率代号为（FD35Q78）。终端分
																			                                                //为借记卡费率与贷记卡费率填写格式  借记卡费率|贷记卡费率 例（FD20Q5|Q5）
																			                                                //修改费率时需要将借记卡费率与贷记卡费率一起上送
				reqMap.put("txnType", Constants.CON_YES);									                                    //交易类型 0申请 1变更
				reqMap.put("posType", Constants.CON_YES);									                                    //pos类型,默认值
				reqMap.put("groupNo", Constants.STATUS2);									                            //费率类型（0标准类 1优惠类2综合类）
				reqMap.put("args", Constants.CON_YES);									                                        //机构自定义
				reqMap.put("userSign", ConstantsEnv.HF_USERSIGN);								                                //机构标识，由上游提供，请联系技术
				reqMap.put("requestUrl", "");								                                                //异步密钥通知地址  接收到返回请返回 success字符串 意味着成功接收到异步通知 则停止通知
																			                                                //，若未响应则会连续推三次，三次之后则不会继续推送 
				NameValuePair[] data = {
					 	new NameValuePair("orgNo", ConstantsEnv.HF_ORGNO),				                                        //机构编号，由上游提供，请联系技术
						new NameValuePair("data",new EncryptionDES(key).encrypt(URLEncoder.encode(JSONObject.fromObject(reqMap).toString(),"UTF-8")))
				};
				log.info("请求弘付参数"+JSONObject.fromObject(reqMap).toString());
			 	String responseStr = null;
				HttpClient httpClient = new HttpClient();
				httpClient.getParams().setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, "UTF-8");
				PostMethod postMethod = new PostMethod(URL);
				postMethod.setRequestBody(data);
				httpClient.getHttpConnectionManager().getParams()
						.setConnectionTimeout(10000);
				httpClient.getHttpConnectionManager().getParams().setSoTimeout(10000);
				httpClient.executeMethod(postMethod);

				responseStr = postMethod.getResponseBodyAsString();
				postMethod.releaseConnection();
				JSONObject jsonObject = JSONObject.fromObject(URLDecoder.decode(responseStr,"UTF-8"));
				log.info("弘付返回参数"+URLDecoder.decode(responseStr,"UTF-8"));
//				respCode = (String) jsonObject.get("respCode");
				return jsonObject;
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.复核商户,new String[]{"弘付报备修改失败"});
		}
	}
	
	
	/**
	 * 裂变分润
	 * @param b2cShopperbi
	 * @return
	 * @throws Exception
	 */
	private Map updateProfit(B2cShopperbiTemp b2cShopperbi) throws Exception {
		HashMap hashMap = new HashMap();
		hashMap.put("merchantNo",b2cShopperbi.getShopperid());
		//分润方案
		hashMap.put("profitOwner", b2cShopperbi.getProfitOwner());//分润给那个代理商
		hashMap.put("agentProfitRatio", b2cShopperbi.getAgentProfitRatio()); //代理商分润百分比
		hashMap.put("merchProfitRatio1", b2cShopperbi.getMerchProfitRatio1());//商户分润方案1
		hashMap.put("merchProfitRatio2", b2cShopperbi.getMerchProfitRatio2()); //商户分润方案2
		hashMap.put("merchProfitRatio3", b2cShopperbi.getMerchProfitRatio3()); //商户分润方案3
		
		String json = JsonUtil.toJSONString(hashMap);
		log.info("mpos 裂变分润请求:"+ ConstantsEnv.UPDATE_PROFIT_URL+json);
		String result = HttpClientUtils.REpostRequestStr(ConstantsEnv.UPDATE_PROFIT_URL, json);
		Map map = JsonUtil.jsonStrToMap(result);
		log.info("mpos 裂变分润返回值："+map.toString());
		return map;
	}
	
}
