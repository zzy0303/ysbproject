package com.uns.web;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.exception.BusinessException;
import com.uns.model.SysConfig;
import com.uns.service.FissionService;
import com.uns.util.FastJson;
import com.uns.util.HttpClientUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/12/25
 * @Modifyed By:
 */
@Controller
@RequestMapping(value = "/fission.htm")
public class FissionController extends BaseController {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private FissionService fissionService;

    @RequestMapping(params = "method=fissionAmount")
    public String fissionAmount(HttpServletRequest request) throws BusinessException {
        try {
            Map<String, Object> param = new HashMap<>(1);
            param.put("configKey", "merProfitDrawAmount");
            List<SysConfig> sysConfigs = fissionService.querySysConfig(param);
            request.setAttribute("sysConfig", sysConfigs.get(0));
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException("1111", "查询mpos_qrcode配置出错");
        }
        return "fission/fissionAmount";
    }

    @RequestMapping(params = "method=fissionAudit")
    public String fissionAudit(HttpServletRequest request) throws BusinessException {
        try {
            Map<String, Object> param = new HashMap<>(1);
            param.put("configKey", "merProfitAuditFlag");
            List<SysConfig> sysConfigs = fissionService.querySysConfig(param);
            request.setAttribute("sysConfig", sysConfigs.get(0));
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException("1111", "查询mpos_qrcode配置出错");
        }
        return "fission/fissionAudit";
    }

    /**
     * 调用mpos_qrocd接口修改配置信息
     *
     * @param sysConfig
     * @return
     */
    @ResponseBody
    @RequestMapping(params = "method=configure")
    public String configure(SysConfig sysConfig) {
        String flag = "true";
        try {
            Map<String, Object> param = new HashMap<>(3);
            param.put("configKey", sysConfig.getKeyName());
            param.put("configValue", sysConfig.getKeyValue());
            param.put("operationFlag", sysConfig.getOperationFlag());
            logger.info("修改mpos_qrcode配置请求参数：{}", FastJson.toJson(param));
            Map<String, Object> result = FastJson.fromJson(HttpClientUtils.postRequest(ConstantsEnv.MPOS_QRCODE_UPDATE_CONFIG, param));
            logger.info("修改mpos_qrcode配置返回：{}", FastJson.toJson(result));
            if (null == result || !Constants.SUCCESS_CODE_0000.equals(result.get("rspCode"))) {
                flag = "false";
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "false";
        }
        return flag;
    }

}
