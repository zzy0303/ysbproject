package com.uns.web;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Base64;
import com.uns.common.Constants;
import com.uns.common.ImageCompressUtil;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.model.Agent;
import com.uns.model.AgentTopFee;
import com.uns.model.Area;
import com.uns.model.B2cDict;
import com.uns.model.B2cShopperbargainTemp;
import com.uns.model.B2cShopperbi;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.B2cShopperbiTempModify;
import com.uns.model.BackupsShopperInformation;
import com.uns.model.MposApplicationProgress;
import com.uns.model.MposMerchantFee;
import com.uns.model.MposPhoto;
import com.uns.model.MposPhotoTmp;
import com.uns.model.Operator;
import com.uns.model.UpdateFeeHistory;
import com.uns.service.ShopPerbiService;
import com.uns.util.HttpClientUtils;
import com.uns.util.StringUtils;
import com.uns.util.ToolsUtils;
import com.uns.web.form.ShopPerbiForm;

import net.sf.json.JSONObject;

@Controller("shopPerbiUpdateController")
@RequestMapping("/shopPerbiUpdate.htm")
public class ShopPerbiUpdateController extends BaseController {

	@Autowired
	private ShopPerbiService shopPerbiService;

	/**
	 * 商户预约信息修改，查询
	 * 
	 * @param request
	 * @param modelMap
	 * @param mbForm
	 * @return String shopPerbiUpdateAll 进入修改页面
	 * @throws Exception
	 */
	@RequestMapping(params = "method=queryShopPerbiUpdate")
	@FormToken(save = true)
	public String queryShopPerbiUpdate(HttpServletRequest request,
			ShopPerbiForm mbForm) throws Exception {

		B2cShopperbiTemp b2cShopperbiTemp = null;
		UpdateFeeHistory updateFeeHistory = null;

		try {
			// 检查shopperpriIds
			String shopperId = request.getParameter("shopperpriId");
			if (StringUtils.isEmpty(shopperId)) {
				request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
				mbForm.setBelongsAgent(null);
				request.setAttribute("url",
						"reCheck.htm?method=reCheckShoperBiList");
			} else {
				// 查询临时表信息
				b2cShopperbiTemp = shopPerbiService.queryShopPerbi(shopperId);
			}

			// 获取省
			List<Area> provincial = shopPerbiService.searchProvince();
			request.setAttribute("provincial", provincial);
			// 获取市
			List<Area> citys = shopPerbiService.searchArea();
			request.setAttribute("area", citys);
			// 行业类型
			List<B2cDict> cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
			request.setAttribute("cillinglist", cillinglist);
			// 代理商
			String path = request.getSession().getServletContext()
					.getContextPath();
			request.setAttribute("agentlist", path + "agent/selectAgentTree.htm");
			// 获取银行
			List<B2cDict> dicbank = shopPerbiService.searchBank();
			request.setAttribute("bank", dicbank);
			
			  //费率下拉框的取值
			List<AgentTopFee> d0creditCardFee = shopPerbiService.findAgentFeeByType(Constants.FEE_TYPE_DEBIT);
			List<AgentTopFee> d0debitCardFee = shopPerbiService.findAgentFeeByType(Constants.FEE_TYPE_CREDIT);
			
			List<AgentTopFee> s0creditCardFee = shopPerbiService.findAgentFeeByType(Constants.S0_FEE_TYPE_DEBIT);
			List<AgentTopFee> s0debitCardFee = shopPerbiService.findAgentFeeByType(Constants.S0_FEE_TYPE_CREDIT);
			
			List<AgentTopFee> t1creditCardFee = shopPerbiService.findAgentFeeByType(Constants.T1_FEE_TYPE_DEBIT);
			List<AgentTopFee> t1debitCardFee = shopPerbiService.findAgentFeeByType(Constants.T1_FEE_TYPE_CREDIT);
			
			request.setAttribute("d0creditCardFee", d0creditCardFee);
			request.setAttribute("d0debitCardFee", d0debitCardFee);
			
			request.setAttribute("s0creditCardFee", s0creditCardFee);
			request.setAttribute("s0debitCardFee", s0debitCardFee);
			
			request.setAttribute("t1creditCardFee", t1creditCardFee);
			request.setAttribute("t1debitCardFee", t1debitCardFee);
			
			List<AgentTopFee> weChatFee = shopPerbiService.findAgentFeeByType(Constants.FEE_TYPE_WECHAT);
			List<AgentTopFee> alipayFee = shopPerbiService.findAgentFeeByType(Constants.FEE_TYPE_ALIPAY);
			List<AgentTopFee> ylpayFee = shopPerbiService.findAgentFeeByType(Constants.FEE_TYPE_YLPAY);
			request.setAttribute("weChatFee", weChatFee);
			request.setAttribute("alipayFee", alipayFee);
			request.setAttribute("ylpayFee",ylpayFee);
			//获取应该存在的汇率
			List<AgentTopFee> shortCut = shopPerbiService.findAgentFeeByType(Constants.AGENT_TYPE_SHORTCUT);//查询字典表9
			List<AgentTopFee> b2c = shopPerbiService.findAgentFeeByType(Constants.AGENT_TYPE_B2C);//查询字典表10
			List<AgentTopFee> shortCutSH = shopPerbiService.findAgentFeeByType(Constants.AGENT_TYPE_SHORTCUTSH);//查询字典表9
			
			request.setAttribute("shortCut", shortCut);
			request.setAttribute("b2c",b2c);
			request.setAttribute("shortCutSH", shortCutSH);
			
			//获取费率信息
			queryShopPerbiUpdateFee(request, b2cShopperbiTemp, shopperId);
			
			// 获取证照
			Long photoid = b2cShopperbiTemp.getPhotoid();
			MposPhotoTmp photo = shopPerbiService.selectPhotoTmpById(photoid);
			if(photo==null)
				photo = (MposPhotoTmp) shopPerbiService.selectPhotoById(photoid);
			request.setAttribute("photo", photo);
			request.setAttribute("image_get_url", DynamicConfigLoader.getByEnv("imageget.url"));

			if (b2cShopperbiTemp != null) {
				// 获取上级代理商
				Long shopperIdP = b2cShopperbiTemp.getShopperidP();
				if (shopperIdP != null) {
					Agent agent = shopPerbiService.searchAgent(shopperIdP);
					request.setAttribute("agentName", agent.getScompany());
					request.setAttribute("agentId", agent.getShopperid());
				}
			}

			request.setAttribute("b2cShopperbi", b2cShopperbiTemp);
			if (b2cShopperbiTemp.getMerchProfitRatio2()!=null&&b2cShopperbiTemp.getMerchProfitRatio3()!=null) {	
			//分润方案2
			String[] split2 = b2cShopperbiTemp.getMerchProfitRatio2().split("\\|");
			//分润方案3
			String[] split3 = b2cShopperbiTemp.getMerchProfitRatio3().split("\\|");
			request.setAttribute("split2", split2);
			request.setAttribute("split3", split3);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取商户信息失败);
		}

		return "merchant/shopPerbiUpdateAll";
	}

	/**
	 * 获取费率信息
	 */
	private void queryShopPerbiUpdateFee(HttpServletRequest request, B2cShopperbiTemp b2cShopperbiTemp, String shopperId) {
		
		MposMerchantFee s0debitMposMerchantFee = null;
		MposMerchantFee s0creditMposMerchantFee = null;
		
		MposMerchantFee d0debitMposMerchantFee = null;
		MposMerchantFee d0creditMposMerchantFee = null;
		
		MposMerchantFee t1debitMposMerchantFee = null;
		MposMerchantFee t1creditMposMerchantFee = null;
		
		MposMerchantFee weChatMposMerchantFee = null;
		MposMerchantFee alipayMposMerchantFee = null;
		MposMerchantFee ylpayMposMerchantFee = null;
		
		MposMerchantFee shortCutMerchantFee=null;//快捷支付对象
		MposMerchantFee b2cMerchantFee=null;//B2C对象
		
		/**
		 * 10月19号添加
		 */
		MposMerchantFee shortCutSHMerchantFee = null;//速惠d0费率对象
		
		//快捷支付费率，临时表 根据汇率类型和商户id查询汇率表
		MposMerchantFee shortCutMposMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperId,Constants.FEE_TYPE_SHORTCUT);
		if(shortCutMposMerchantFeeTemp!=null){
			shortCutMerchantFee = shortCutMposMerchantFeeTemp;
		}else{
			// 如果没有修改过没有临时表信息，就去查正式表
			shortCutMerchantFee = shopPerbiService.findMposMerchantFee(shopperId,Constants.FEE_TYPE_SHORTCUT);
		}
		
		//B2C支付费率，临时表  根据汇率类型和商户id查询汇率表
		MposMerchantFee b2cMposMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperId,Constants.FEE_TYPE_B2C);
		if(b2cMposMerchantFeeTemp!=null){
			b2cMerchantFee = b2cMposMerchantFeeTemp;
		}else{
					// 如果没有修改过没有临时表信息，就去查正式表
			b2cMerchantFee = shopPerbiService.findMposMerchantFee(shopperId,Constants.FEE_TYPE_B2C);
		}
		//速惠d0费率
		MposMerchantFee shortCutSHMposMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperId,Constants.FEE_TYPE_SHD0);
		if(shortCutSHMposMerchantFeeTemp!=null){
			shortCutSHMerchantFee = shortCutSHMposMerchantFeeTemp;
		}else{
			// 如果没有修改过没有临时表信息，就去查正式表
			shortCutSHMerchantFee = shopPerbiService.findMposMerchantFee(shopperId,Constants.FEE_TYPE_SHD0);
		}
		
		//不是第一次修改，查询临时表，如果临时表数据为空，则是第一次修改查询正式表，远程邀请注册商户费率在remote_fee，面签在merchant_fee
		//商户借记卡费率，临时表
		MposMerchantFee s0debitMposMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperId,Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
		if(s0debitMposMerchantFeeTemp!=null){
			s0debitMposMerchantFee = s0debitMposMerchantFeeTemp;
		}else{
			// 如果没有修改过没有临时表信息，就去查正式表
			s0debitMposMerchantFee = shopPerbiService.findMposMerchantFee(shopperId,Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
		}
		//商户贷记卡费率，临时表
		MposMerchantFee s0creditMposMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperId,Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
		if(s0creditMposMerchantFeeTemp!=null){
			s0creditMposMerchantFee = s0creditMposMerchantFeeTemp;
		}else{
			// 如果没有修改过没有临时表信息，就去查正式表
			s0creditMposMerchantFee = shopPerbiService.findMposMerchantFee(shopperId,Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
		}
		
		MposMerchantFee d0debitMposMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperId,Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
		if(d0debitMposMerchantFeeTemp!=null){
			d0debitMposMerchantFee = d0debitMposMerchantFeeTemp;
		}else{
			// 如果没有修改过没有临时表信息，就去查正式表
			d0debitMposMerchantFee = shopPerbiService.findMposMerchantFee(shopperId,Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
		}
		//商户贷记卡费率，临时表
		MposMerchantFee d0creditMposMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperId,Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
		if(d0creditMposMerchantFeeTemp!=null){
			d0creditMposMerchantFee = d0creditMposMerchantFeeTemp;
		}else{
			// 如果没有修改过没有临时表信息，就去查正式表
			d0creditMposMerchantFee = shopPerbiService.findMposMerchantFee(shopperId,Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
		}
		
		MposMerchantFee t1debitMposMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperId,Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
		if(t1debitMposMerchantFeeTemp!=null){
			t1debitMposMerchantFee = t1debitMposMerchantFeeTemp;
		}else{
			// 如果没有修改过没有临时表信息，就去查正式表
			t1debitMposMerchantFee = shopPerbiService.findMposMerchantFee(shopperId,Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
		}
		//商户贷记卡费率，临时表
		MposMerchantFee t1creditMposMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopperId,Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
		if(t1creditMposMerchantFeeTemp!=null){
			t1creditMposMerchantFee = t1creditMposMerchantFeeTemp;
		}else{
			// 如果没有修改过没有临时表信息，就去查正式表
			t1creditMposMerchantFee = shopPerbiService.findMposMerchantFee(shopperId,Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
		}
		
		
		//微信支付费率，临时表
		MposMerchantFee weChatMposMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperId,Constants.FEE_TYPE_WECHAT);
		if(weChatMposMerchantFeeTemp!=null){
			weChatMposMerchantFee = weChatMposMerchantFeeTemp;
		}else{
			// 如果没有修改过没有临时表信息，就去查正式表
			weChatMposMerchantFee = shopPerbiService.findMposMerchantFee(shopperId,Constants.FEE_TYPE_WECHAT);
		}
		
		//支付宝支付费率，临时表
		MposMerchantFee alipayMposMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperId,Constants.FEE_TYPE_ALIPAY);
		if(alipayMposMerchantFeeTemp!=null){
			alipayMposMerchantFee = alipayMposMerchantFeeTemp;
		}else{
			// 如果没有修改过没有临时表信息，就去查正式表
			alipayMposMerchantFee = shopPerbiService.findMposMerchantFee(shopperId,Constants.FEE_TYPE_ALIPAY);
		}

		MposMerchantFee ylpayMposMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperId,Constants.FEE_TYPE_YLPAY);
		if(ylpayMposMerchantFeeTemp != null){
			ylpayMposMerchantFee = ylpayMposMerchantFeeTemp;
		}else{
			ylpayMposMerchantFee = shopPerbiService.findMposMerchantFee(shopperId,Constants.FEE_TYPE_YLPAY);
		}

		//remote表查询
		String shopperTel = b2cShopperbiTemp.getStel();
		if(s0debitMposMerchantFee == null){
			s0debitMposMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
		}
		if(s0creditMposMerchantFee == null){
			s0creditMposMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
		}
		
		if(d0debitMposMerchantFee == null){
			d0debitMposMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
		}
		if(d0creditMposMerchantFee == null){
			d0creditMposMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
		}
		
		if(t1debitMposMerchantFee == null){
			t1debitMposMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
		}
		if(t1creditMposMerchantFee == null){
			t1creditMposMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
		}
		if(weChatMposMerchantFee == null){
			weChatMposMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_WECHAT);
		}
		if(alipayMposMerchantFee == null){
			alipayMposMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_ALIPAY);
		}
		if(ylpayMposMerchantFee == null){
			ylpayMposMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_YLPAY);
		}
		
		request.setAttribute("shortCutMerchantFee", shortCutMerchantFee);//快捷汇率
		request.setAttribute("b2cMerchantFee", b2cMerchantFee);//b2c汇率
		
		request.setAttribute("s0debitMposMerchantFee", s0debitMposMerchantFee);
		request.setAttribute("s0creditMposMerchantFee", s0creditMposMerchantFee);
		
		request.setAttribute("d0debitMposMerchantFee", d0debitMposMerchantFee);
		request.setAttribute("d0creditMposMerchantFee", d0creditMposMerchantFee);
		
		request.setAttribute("t1debitMposMerchantFee", t1debitMposMerchantFee);
		request.setAttribute("t1creditMposMerchantFee", t1creditMposMerchantFee);
		
		request.setAttribute("weChatMposMerchantFee", weChatMposMerchantFee);
		request.setAttribute("alipayMposMerchantFee", alipayMposMerchantFee);
		request.setAttribute("ylpayMposMerchantFee",ylpayMposMerchantFee);
		request.setAttribute("shortCutSHMerchantFee",shortCutSHMerchantFee);
		
	}

	/**
	 * 商户预约信息修改，保存
	 * 
	 * @param request
	 * @param modelMap
	 * @param mbForm
	 * @param b2cShopperbiTemp
	 * @param b2cShopperbargain
	 * @return 返回修改结果页面
	 * @throws Exception
	 */
	@RequestMapping(params = "method=saveShopPerbiUpdate")
	@FormToken(remove = true)
	public String saveShopPerbiUpdate(HttpServletRequest request,
			B2cShopperbiTemp b2cShopperbiTemp,B2cShopperbargainTemp b2cShopperbargain, ShopPerbiForm mbForm)
			throws Exception {

		String shopperID = request.getParameter("shopperpriIds");
		try {
			if (StringUtils.isEmpty(shopperID)) {
				request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
				mbForm.setBelongsAgent(null);
				request.setAttribute("url",
						"shopPerbi.htm?method=shopPerbiCheckList");
			} else {
				// 相关变量初始化
				BackupsShopperInformation bkshopper = new BackupsShopperInformation();
				
				
				MposMerchantFee s0creditMerchantFeeM = new MposMerchantFee();//贷记卡
				MposMerchantFee s0debitMerchantFeeM = new MposMerchantFee();//借记卡
				
				MposMerchantFee d0creditMerchantFeeM = new MposMerchantFee();
				MposMerchantFee d0debitMerchantFeeM = new MposMerchantFee();
				
				MposMerchantFee t1creditMerchantFeeM = new MposMerchantFee();
				MposMerchantFee t1debitMerchantFeeM = new MposMerchantFee();
				
				MposMerchantFee weChatMerchantFeeM = new MposMerchantFee();
				MposMerchantFee alipayMerchantFeeM = new MposMerchantFee();
				MposMerchantFee ylpayMerchantFeeM = new MposMerchantFee();
				MposMerchantFee shortCutMerchantFeeM = new MposMerchantFee();
				MposMerchantFee b2cMerchantFeeM = new MposMerchantFee();
				MposMerchantFee shortCutSHMerchantFeeM = new MposMerchantFee();
				
				MposApplicationProgress pro = new MposApplicationProgress();
				
				B2cShopperbiTemp old = shopPerbiService
						.queryShopPerbi(shopperID);

				// 基本信息处理
				saveShopPerbiInfoUpdate(request, b2cShopperbiTemp,mbForm);

				// 开户信息处理,返回备份用的bkshopper
				saveShopPerbiBankInfoUpdate(request, b2cShopperbiTemp, mbForm,
						bkshopper);

				// 费率信息处理.如果信息汇率修改了那么久是新对象有值了用于明细修改作用
				Map<String, Object> feeMap = updateshopPerbiFee(request, b2cShopperbiTemp,
						mbForm,s0debitMerchantFeeM,s0creditMerchantFeeM,d0debitMerchantFeeM,d0creditMerchantFeeM,t1debitMerchantFeeM,
						t1creditMerchantFeeM,weChatMerchantFeeM,alipayMerchantFeeM,ylpayMerchantFeeM,shortCutMerchantFeeM,b2cMerchantFeeM, shortCutSHMerchantFeeM);

				// 判断正式表中是否有数据
			/*	B2cShopperbiTemp shopper = shopPerbiService
						.queryShopPerbi(shopperID);*/

				// 设置商户信息已修改
				b2cShopperbiTemp.setIsupdateshopper(new Short("1"));

				// 修改上级代理商
				Long bAgentId = mbForm.getShopperid_p();
//				if (b2cShopperbiTemp.getShopperidP() != null) {
//					if (!bAgentId.equals(b2cShopperbiTemp.getShopperidP()
//							.toString())) {
//						b2cShopperbiTemp.setShopperidP(bAgentId);
//					}
//				}
				b2cShopperbiTemp.setShopperidP(bAgentId);
				// 产生修改明细 新老信息做比较
				B2cShopperbiTempModify shopperbiTempModify = findModify(old,
						b2cShopperbiTemp);
				/**注意:下列字段数据库表有重新添加列**/
				//当心对象有值得时候说明修改了,这时候将新对象的值放入对于的字段中存入
				if (s0creditMerchantFeeM.getFee() != null) 
					shopperbiTempModify.setS0creditFee(s0creditMerchantFeeM.getFee());
				if (s0debitMerchantFeeM.getFee() != null) 
					shopperbiTempModify.setS0debitFee(s0debitMerchantFeeM.getFee());
						
				if (d0creditMerchantFeeM.getFee() != null) 
					shopperbiTempModify.setD0creditFee(d0creditMerchantFeeM.getFee());
				if (d0debitMerchantFeeM.getFee() != null) 
					shopperbiTempModify.setD0debitFee(d0debitMerchantFeeM.getFee());
				
				if (t1creditMerchantFeeM.getFee() != null) 
					shopperbiTempModify.setT1creditFee(t1creditMerchantFeeM.getFee());
				if (t1debitMerchantFeeM.getFee() != null) 
					shopperbiTempModify.setT1debitFee(t1debitMerchantFeeM.getFee());
				
				if (weChatMerchantFeeM.getFee() != null) 
					shopperbiTempModify.setWeChatFee(weChatMerchantFeeM.getFee());
				if (weChatMerchantFeeM.getD0Fee() != null)
					shopperbiTempModify.setWeChatD0Fee(weChatMerchantFeeM.getD0Fee());
				if (alipayMerchantFeeM.getFee() != null) 
					shopperbiTempModify.setAlipayFee(alipayMerchantFeeM.getFee());
				if (alipayMerchantFeeM.getD0Fee() !=null)
					shopperbiTempModify.setAlipayD0Fee(alipayMerchantFeeM.getD0Fee());
				if(ylpayMerchantFeeM.getFee()!=null)
					shopperbiTempModify.setYlpayFee(ylpayMerchantFeeM.getFee());
				//如果新的对象里面有值说明传入的值和数据库的值不一样,那么肯定有修改了
				if (shortCutMerchantFeeM.getFee() != null) 
					shopperbiTempModify.setShortCutFee(shortCutMerchantFeeM.getFee());
				if (shortCutMerchantFeeM.getD0Fee() != null)
					shopperbiTempModify.setShortCutDoFee(shortCutMerchantFeeM.getD0Fee());
				if (b2cMerchantFeeM.getFee() != null) 
					shopperbiTempModify.setB2cFee(b2cMerchantFeeM.getFee());
				if (b2cMerchantFeeM.getD0Fee() != null)
					shopperbiTempModify.setB2cDoFee(b2cMerchantFeeM.getD0Fee());
			
				/**
				 * 10月19号添加
				 */
				if (shortCutSHMerchantFeeM.getD0Fee() != null)
					shopperbiTempModify.setShortCutSHDoFee(shortCutSHMerchantFeeM.getD0Fee());

				shopperbiTempModify.setB2cShopperbiId(Long.parseLong(shopperID));
				Map<String, String> param = new HashMap<String, String>();
				param.put("shopperID", shopperID);
				List<B2cShopperbiTempModify> list = shopPerbiService
						.findModifyByShopperbiIdList(param);
				Operator user = (Operator) request.getSession().getAttribute(
						"sessionUser");
				if (list.size() < 1 || list == null) {
					shopperbiTempModify.setModifyDetailCreateDate(new Date());
					shopperbiTempModify.setModifyDetailUpdateDate(new Date());
					shopperbiTempModify.setModifyDetailCreateUser(user
							.getUserName());
					shopperbiTempModify.setModifyDetailUpdateUser(user
							.getUserName());
				}

				shopperbiTempModify.setModifyDetailUpdateDate(new Date());
				shopperbiTempModify.setModifyDetailUpdateUser(user
						.getUserName());

				// 证照信息处理
				Map maphoto = saveShopPerbiPhotoUpdate(request,
						b2cShopperbiTemp, mbForm, shopperbiTempModify, pro);

				//获取方案分润百分比
				String merchRatio1 = request.getParameter("merchRatio1");
				String merchRatio21 = request.getParameter("merchRatio2_1");
				String merchRatio22 = request.getParameter("merchRatio2_2");
				String merchRatio31 = request.getParameter("merchRatio3_1");
				String merchRatio32 = request.getParameter("merchRatio3_2");
				String merchRatio33 = request.getParameter("merchRatio3_3");
				b2cShopperbiTemp.setMerchProfitRatio1(merchRatio1);//方案1
				b2cShopperbiTemp.setMerchProfitRatio2(merchRatio21+"|"+merchRatio22);//方案2
				b2cShopperbiTemp.setMerchProfitRatio3(merchRatio31+"|"+merchRatio32+"|"+merchRatio33);//方案3
				// 保存的方法
				shopPerbiService.saveShopPerbiUpdate(shopperbiTempModify, b2cShopperbiTemp, bkshopper ,maphoto, pro, feeMap);

				request.setAttribute(Constants.MESSAGE_KEY, "修改成功!");
				request.setAttribute("url","shopPerbi.htm?method=shopPerbiManageList");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException("商户信息修改失败");
		}
		return "/returnPage";
	}

	/**
	 * 商户预约信息详情，查询
	 * 
	 * @param request
	 * @param mbForm
	 * @return String shopPerbiUpdateAll 进入修改页面
	 * @throws Exception
	 */
	@RequestMapping(params = "method=queryShopPerbiDetails")
	public String queryShopPerbiDetails(HttpServletRequest request,
			ShopPerbiForm mbForm) throws Exception {
		B2cShopperbiTemp b2cShopperbi = null;
		B2cShopperbi b2cShopperbiFormal = null;
		try {
			String shopPerbiregId = request.getParameter("shopperpriId");
			if (StringUtils.isEmpty(shopPerbiregId)) {
				request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
				mbForm.setBelongsAgent(null);
				request.setAttribute("url",
						"shopPerbi.htm?method=shopPerbiCheckList");
			} else {
				b2cShopperbi = shopPerbiService.queryShopPerbi(shopPerbiregId);//查询临时表
				b2cShopperbiFormal = shopPerbiService
						.queryFormalShopPerbi(shopPerbiregId);//查询正式表
			}
			// 获取省
			List<Area> Provincial = shopPerbiService.searchProvince();
			request.setAttribute("Provincial", Provincial);
			// 获取市
			List<Area> list = shopPerbiService.searchArea();
			request.setAttribute("area", list);

			// 行业类型
			List<B2cDict> cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
			request.setAttribute("cillinglist", cillinglist);
			// 代理商列表
			String path = request.getSession().getServletContext()
					.getContextPath();
			request.setAttribute("agentlist", path+ "agent/selectAgentTree.htm");

			if (b2cShopperbi != null) {
				// 获取临时表代理商
				Long shopperId = b2cShopperbi.getShopperidP();
				if (shopperId != null) {
					Agent agent = shopPerbiService.searchAgent(shopperId);
					request.setAttribute("agentName", agent.getScompany());
					request.setAttribute("agentId", agent.getShopperid());
				}
				// 获取银行
				B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi
						.getAccountbankdictval());
				request.setAttribute("bankName", dicbank);
				// 证照
				Long photoid = b2cShopperbi.getPhotoid();
				if (photoid != null) {
					MposPhotoTmp photo = shopPerbiService
							.selectPhotoTmpById(photoid);
					request.setAttribute("photo", photo);
					request.setAttribute("image_get_url", DynamicConfigLoader.getByEnv("imageget.url"));
				}
			}
			if (b2cShopperbiFormal != null) {
				// 获取正式表代理商
				Long shopperIdFormal = b2cShopperbiFormal.getShopperidP();
				if (shopperIdFormal != null) {
					Agent agent = shopPerbiService.searchAgent(shopperIdFormal);
					request.setAttribute("agentNameFormal", agent.getScompany());
					request.setAttribute("agentIdFormal", agent.getShopperid());
				}
				// 获取银行
				B2cDict dicbank = shopPerbiService
						.findBankName(b2cShopperbiFormal
								.getAccountbankdictval());
				request.setAttribute("bankNameFormal", dicbank);
				// 证照
				Long photoid = b2cShopperbiFormal.getPhotoid();
				if (photoid != null) {
					MposPhoto photo = shopPerbiService.selectPhotoById(photoid);
					request.setAttribute("photoFormal", photo);
					request.setAttribute("image_get_urlFormal", DynamicConfigLoader.getByEnv("imageget.url"));
				}
			}
			String shopperTel = null;
			if(b2cShopperbi!=null){
				shopperTel = b2cShopperbi.getStel();
			if(b2cShopperbiFormal!=null&&shopperTel==null){
				shopperTel = b2cShopperbiFormal.getStel();
				}
			}
			// 手续费，临时表
			MposMerchantFee s0creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
			MposMerchantFee s0debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
			
			MposMerchantFee d0creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
			MposMerchantFee d0debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
			
			MposMerchantFee t1creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
			MposMerchantFee t1debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
			
			MposMerchantFee weChatMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId, Constants.FEE_TYPE_WECHAT);
			MposMerchantFee alipayMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId, Constants.FEE_TYPE_ALIPAY);
			MposMerchantFee ylpayMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId,Constants.FEE_TYPE_YLPAY);
			
			MposMerchantFee shortCutMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId, Constants.FEE_TYPE_SHORTCUT);//快捷汇率
			MposMerchantFee shortCutSHMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId, Constants.FEE_TYPE_SHD0);//速惠汇率
			MposMerchantFee  b2cMerchantFeeTemp= shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId, Constants.FEE_TYPE_B2C);//B2C汇率
			//临时表理论上是没数据的是空
			request.setAttribute("shortCutSHMerchantFeeTemp", shortCutSHMerchantFeeTemp);
			request.setAttribute("shortCutMerchantFeeTemp", shortCutMerchantFeeTemp);
			request.setAttribute("b2cMerchantFeeTemp", b2cMerchantFeeTemp);
			  
			request.setAttribute("s0creditMerchantFeeTemp", s0creditMerchantFeeTemp);
			request.setAttribute("s0debitMerchantFeeTemp", s0debitMerchantFeeTemp);
			
			request.setAttribute("d0creditMerchantFeeTemp", d0creditMerchantFeeTemp);
			request.setAttribute("d0debitMerchantFeeTemp", d0debitMerchantFeeTemp);
			
			request.setAttribute("t1creditMerchantFeeTemp", t1creditMerchantFeeTemp);
			request.setAttribute("t1debitMerchantFeeTemp", t1debitMerchantFeeTemp);
			
			request.setAttribute("weChatMerchantFeeTemp", weChatMerchantFeeTemp);
			request.setAttribute("alipayMerchantFeeTemp",  alipayMerchantFeeTemp);
			request.setAttribute("ylpayMerchantFeeTemp",ylpayMerchantFeeTemp);
			// 手续费
			MposMerchantFee s0creditMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
			if(s0creditMerchantFee==null&&shopperTel!=null){
				s0creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
			}
			MposMerchantFee s0debitMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
			if(s0debitMerchantFee==null&&shopperTel!=null){
				s0debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
			}
			
			MposMerchantFee d0creditMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
			if(d0creditMerchantFee==null&&shopperTel!=null){
				d0creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
			}
			MposMerchantFee d0debitMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
			if(d0debitMerchantFee==null&&shopperTel!=null){
				d0debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
			}
			
			MposMerchantFee t1creditMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
			if(t1creditMerchantFee==null&&shopperTel!=null){
				t1creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
			}
			MposMerchantFee t1debitMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
			if(t1debitMerchantFee==null&&shopperTel!=null){
				t1debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
			}
			
			MposMerchantFee weChatMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_WECHAT);
			if(weChatMerchantFee==null&&shopperTel!=null){
				weChatMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_WECHAT);
			}
			MposMerchantFee alipayMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_ALIPAY);
			if(alipayMerchantFee==null&&shopperTel!=null){
				alipayMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_ALIPAY);
			}
			MposMerchantFee ylpayMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId,Constants.FEE_TYPE_YLPAY);
			if(ylpayMerchantFee == null && shopperTel != null){
				ylpayMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_YLPAY);
			}
			//无卡汇率
			MposMerchantFee shortCutMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_SHORTCUT);
			MposMerchantFee shortCutSHMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_SHD0);
			MposMerchantFee b2cMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_B2C);
			request.setAttribute("shortCutSHMerchantFee", shortCutSHMerchantFee);
			request.setAttribute("shortCutMerchantFee", shortCutMerchantFee);
			request.setAttribute("b2cMerchantFee", b2cMerchantFee);
			
			request.setAttribute("s0creditMerchantFee", s0creditMerchantFee);
			request.setAttribute("s0debitMerchantFee", s0debitMerchantFee);
			
			request.setAttribute("d0creditMerchantFee", d0creditMerchantFee);
			request.setAttribute("d0debitMerchantFee", d0debitMerchantFee);
			
			request.setAttribute("t1creditMerchantFee", t1creditMerchantFee);
			request.setAttribute("t1debitMerchantFee", t1debitMerchantFee);
			
			request.setAttribute("weChatMerchantFee", weChatMerchantFee);
			request.setAttribute("alipayMerchantFee",  alipayMerchantFee);
			request.setAttribute("ylpayMerchantFee",ylpayMerchantFee);
			
			request.setAttribute("b2cShopperbi", b2cShopperbi);
			request.setAttribute("b2cShopperbiFormal", b2cShopperbiFormal);
			if (b2cShopperbi.getMerchProfitRatio2()!=null&&b2cShopperbi.getMerchProfitRatio3()!=null) {
				//分润方案2
				String[] split2 = b2cShopperbi.getMerchProfitRatio2().split("\\|");
				//分润方案3
				String[] split3 = b2cShopperbi.getMerchProfitRatio3().split("\\|");
				request.setAttribute("split2", split2);
				request.setAttribute("split3", split3);
			}			

		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取商户信息失败);
		}

		return "merchant/shopPerbiUpdateAllDetails";
	}

	/**
	 * 初审商户信息
	 * 
	 * @param request
	 * @param b2cShopperbi
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=queryShopPerbiCheck")
	@FormToken(save = true)
	public String queryShopPerbiCheck(HttpServletRequest request,B2cShopperbiTemp b2cShopperbi,ShopPerbiForm mbForm) throws Exception {
		B2cShopperbi b2cShopperbiFormal = null;
		try {
			String shopPerbiregId = request.getParameter("shopperpriId");
			if (StringUtils.isEmpty(shopPerbiregId)) {
				request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
				mbForm.setBelongsAgent(null);
				request.setAttribute("url",
						"shopPerbi.htm?method=shopPerbiCheckList");
			} else {
				b2cShopperbi = shopPerbiService.queryShopPerbi(shopPerbiregId);
				b2cShopperbiFormal = shopPerbiService.queryFormalShopPerbi(shopPerbiregId);
			}
			// 获取省
			List<Area> Provincial = shopPerbiService.searchProvince();
			request.setAttribute("Provincial", Provincial);
			// 获取市
			List<Area> list = shopPerbiService.searchArea();
			request.setAttribute("area", list);

			// 行业类型
			List<B2cDict> cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
			request.setAttribute("cillinglist", cillinglist);
			// 代理商列表
			String path = request.getSession().getServletContext()
					.getContextPath();
			request.setAttribute("agentlist", path
					+ "agent/selectAgentTree.htm");

			if (b2cShopperbi != null) {
				// 获取临时表代理商
				Long shopperId = b2cShopperbi.getShopperidP();
				if (shopperId != null) {
					Agent agent = shopPerbiService.searchAgent(shopperId);
					request.setAttribute("agentName", agent.getScompany());
					request.setAttribute("agentId", agent.getShopperid());
				}
				// 获取银行
				B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi
						.getAccountbankdictval());
				request.setAttribute("bankName", dicbank);
				// 证照
				Long photoid = b2cShopperbi.getPhotoid();
				if (photoid != null) {
					MposPhotoTmp photo = shopPerbiService
							.selectPhotoTmpById(photoid);
					request.setAttribute("photo", photo);
					request.setAttribute("image_get_url", DynamicConfigLoader.getByEnv("imageget.url"));
				}
			}
			if (b2cShopperbiFormal != null) {
				// 获取正式表代理商
				Long shopperIdFormal = b2cShopperbiFormal.getShopperidP();
				if (shopperIdFormal != null) {
					Agent agent = shopPerbiService.searchAgent(shopperIdFormal);
					request.setAttribute("agentNameFormal", agent.getScompany());
					request.setAttribute("agentIdFormal", agent.getShopperid());
				}
				// 获取银行
				B2cDict dicbank = shopPerbiService
						.findBankName(b2cShopperbiFormal
								.getAccountbankdictval());
				request.setAttribute("bankNameFormal", dicbank);
				// 证照
				Long photoid = b2cShopperbiFormal.getPhotoid();
				if (photoid != null) {
					MposPhoto photo = shopPerbiService.selectPhotoById(photoid);
					request.setAttribute("photoFormal", photo);
					request.setAttribute("image_get_urlFormal", DynamicConfigLoader.getByEnv("imageget.url"));
				}
			}
			String shopperTel = null;
			if(b2cShopperbi!=null){
				shopperTel = b2cShopperbi.getStel();
			if(b2cShopperbiFormal!=null&&shopperTel==null){
				shopperTel = b2cShopperbiFormal.getStel();
				}
			}
			// 手续费，临时表
			MposMerchantFee s0creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
			MposMerchantFee s0debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
			
			MposMerchantFee d0creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
			MposMerchantFee d0debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
			
			MposMerchantFee t1creditMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
			MposMerchantFee t1debitMerchantFeeTemp = shopPerbiService.findTempFeeTChannelType(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
			
			MposMerchantFee weChatMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId, Constants.FEE_TYPE_WECHAT);
			MposMerchantFee alipayMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId, Constants.FEE_TYPE_ALIPAY);
			MposMerchantFee ylpayMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId,Constants.FEE_TYPE_YLPAY);
			//无卡汇率临时表
			MposMerchantFee shortCutMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId, Constants.FEE_TYPE_SHORTCUT);
			MposMerchantFee b2cMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId, Constants.FEE_TYPE_B2C);
			
			/**
			 * 10月20号添加速惠临时表
			 */
			MposMerchantFee shortCutSHMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopPerbiregId, Constants.FEE_TYPE_SHD0);
			request.setAttribute("shortCutSHMerchantFeeTemp", shortCutSHMerchantFeeTemp);
			
			request.setAttribute("shortCutMerchantFeeTemp", shortCutMerchantFeeTemp);
			request.setAttribute("b2cMerchantFeeTemp", b2cMerchantFeeTemp);
			
			request.setAttribute("s0creditMerchantFeeTemp", s0creditMerchantFeeTemp);
			request.setAttribute("s0debitMerchantFeeTemp", s0debitMerchantFeeTemp);
			
			request.setAttribute("d0creditMerchantFeeTemp", d0creditMerchantFeeTemp);
			request.setAttribute("d0debitMerchantFeeTemp", d0debitMerchantFeeTemp);
			
			request.setAttribute("t1creditMerchantFeeTemp", t1creditMerchantFeeTemp);
			request.setAttribute("t1debitMerchantFeeTemp", t1debitMerchantFeeTemp);
			
			request.setAttribute("weChatMerchantFeeTemp", weChatMerchantFeeTemp);
			request.setAttribute("alipayMerchantFeeTemp",  alipayMerchantFeeTemp);
			request.setAttribute("ylpayMerchantFeeTemp",ylpayMerchantFeeTemp);
			// 手续费
			MposMerchantFee s0creditMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
			if(s0creditMerchantFee==null&&shopperTel!=null){
				s0creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
			}
			MposMerchantFee s0debitMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
			if(s0debitMerchantFee==null&&shopperTel!=null){
				s0debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
			}
			
			MposMerchantFee d0creditMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
			if(d0creditMerchantFee==null&&shopperTel!=null){
				d0creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
			}
			MposMerchantFee d0debitMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
			if(d0debitMerchantFee==null&&shopperTel!=null){
				d0debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
			}
			
			MposMerchantFee t1creditMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
			if(t1creditMerchantFee==null&&shopperTel!=null){
				t1creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
			}
			MposMerchantFee t1debitMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
			if(t1debitMerchantFee==null&&shopperTel!=null){
				t1debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
			}
			
			MposMerchantFee weChatMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_WECHAT);
			if(weChatMerchantFee==null&&shopperTel!=null){
				weChatMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_WECHAT);
			}
			MposMerchantFee alipayMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId, Constants.FEE_TYPE_ALIPAY);
			if(alipayMerchantFee==null&&shopperTel!=null){
				alipayMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_ALIPAY);
			}
			MposMerchantFee ylpayMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId,Constants.FEE_TYPE_YLPAY);
			if(ylpayMerchantFee == null && shopperTel != null){
				ylpayMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_YLPAY);
			}
			//无卡汇率正式表
			MposMerchantFee shortCutMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId,Constants.FEE_TYPE_SHORTCUT);
			MposMerchantFee b2cMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId,Constants.FEE_TYPE_B2C);
			
			
			/**
			 * 10月20号添加速惠费率正式表
			 */
			MposMerchantFee shortCutSHMerchantFee = shopPerbiService.findMposMerchantFee(shopPerbiregId,Constants.FEE_TYPE_SHD0);
			request.setAttribute("shortCutSHMerchantFee", shortCutSHMerchantFee);
			
			request.setAttribute("shortCutMerchantFee", shortCutMerchantFee);
			request.setAttribute("b2cMerchantFee", b2cMerchantFee);
			
			request.setAttribute("s0creditMerchantFee", s0creditMerchantFee);
			request.setAttribute("s0debitMerchantFee", s0debitMerchantFee);
			
			request.setAttribute("d0creditMerchantFee", d0creditMerchantFee);
			request.setAttribute("d0debitMerchantFee", d0debitMerchantFee);
			
			request.setAttribute("t1creditMerchantFee", t1creditMerchantFee);
			request.setAttribute("t1debitMerchantFee", t1debitMerchantFee);
			
			request.setAttribute("weChatMerchantFee", weChatMerchantFee);
			request.setAttribute("alipayMerchantFee",  alipayMerchantFee);
			request.setAttribute("ylpayMerchantFee",ylpayMerchantFee);

			request.setAttribute("b2cShopperbi", b2cShopperbi);
			request.setAttribute("b2cShopperbiFormal", b2cShopperbiFormal);
			if (b2cShopperbi.getMerchProfitRatio2()!=null&&b2cShopperbi.getMerchProfitRatio3()!=null) {
			//分润方案2
			String[] split2 = b2cShopperbi.getMerchProfitRatio2().split("\\|");
			//分润方案3
			String[] split3 = b2cShopperbi.getMerchProfitRatio3().split("\\|");
			request.setAttribute("split2", split2);
			request.setAttribute("split3", split3);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取商户信息失败);
		}
		return "merchant/shopPerbiDetailsNew";
	}

	/**
	 * 初审商户基本信息(保存):
	 * 
	 * @param request
	 * @param response
	 * @param modelMap
	 * @param b2cShopperbi
	 * @param mbForm
	 * @return
	 * @throws IOException
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=saveShopPerbiCheck")
	@FormToken(remove = true)
	public String saveShopPerbiCheck(HttpServletRequest request,
			ModelMap modelMap, B2cShopperbiTemp b2cShopperbi, ShopPerbiForm mbForm)
			throws Exception, BusinessException {
		try {
			String shopperpriIds = request.getParameter("shopperpriIds");
			if (mbForm.getIfvalid() != null && mbForm.getIfvalid().equals("1")) {
				if (mbForm.getWorktime() != null) {
					b2cShopperbi.setWorktime(mbForm.getWorktime());
					b2cShopperbi.setIfvalid(new Short("1"));// 审核通过
					b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
					b2cShopperbi.setIsupdateshopper(new Short("1"));//0表示商户信息未修改，1表示商户信息已经修改
					b2cShopperbi.setPhotoCheckFlag("1");//证照信息初审 0：未审核，1:审核通过，2：审核不通过
					String remark = "审核通过";
					b2cShopperbi.setCheckdate(new Date());
					shopPerbiService.updateCheckShopper(b2cShopperbi,
							Constants.TYPE_2, Constants.TYPE_2, remark);
				} else {
					// 没有修改商户基本信息，
					b2cShopperbi.setIfvalid(new Short("1"));// 审核通过
					b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
					b2cShopperbi.setIsupdateshopper(new Short("0"));
					b2cShopperbi.setOpencheckstatus(new Short("1"));
					b2cShopperbi.setPhotoCheckFlag("1");
					String remark = "审核通过";
					b2cShopperbi.setCheckdate(new Date());
					shopPerbiService.updateCheckShopper(b2cShopperbi,
							Constants.TYPE_1, Constants.TYPE_2, remark);

				}

			} else {
				b2cShopperbi.setIfvalid(new Short("2"));// 审核不通过
				b2cShopperbi.setIsupdateshopper(new Short("0"));// 商户审核不通过
				b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
				b2cShopperbi.setExamineresullt(mbForm.getExamineresullt());
				if (mbForm.getWorktime() != null) {
					String remark = "审核不通过";
					b2cShopperbi.setCheckdate(new Date());
					shopPerbiService.updateCheckShopper(b2cShopperbi,
							Constants.TYPE_2, Constants.TYPE_3, remark);
				} else {
					String remark = "审核不通过";
					b2cShopperbi.setCheckdate(new Date());
					shopPerbiService.updateCheckShopper(b2cShopperbi,
							Constants.TYPE_1, Constants.TYPE_3, remark);

				}
			}
			request.setAttribute(Constants.MESSAGE_KEY, "审核成功!");
			request.setAttribute("url",
					"shopPerbi.htm?method=shopPerbiCheckList");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.审核失败);
		}
		return "/returnPage";

	}

	/**
	 * 初审商户信息，明细
	 * 
	 * @param request
	 * @param b2cShopperbi
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=queryShopPerbiCheckDetails")
	public String queryShopPerbiCheckDetails(HttpServletRequest request,B2cShopperbiTemp b2cShopperbi,
			ShopPerbiForm mbForm) throws Exception {
		B2cShopperbi b2cShopperbiFormal = null;
		try {
			String shopperID = request.getParameter("shopperpriId");
			if (StringUtils.isEmpty(shopperID)) {
				request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
				mbForm.setBelongsAgent(null);
				request.setAttribute("url",
						"shopPerbi.htm?method=shopPerbiCheckList");
			} else {
				b2cShopperbi = shopPerbiService.queryShopPerbi(shopperID);
				b2cShopperbiFormal = shopPerbiService
						.queryFormalShopPerbi(shopperID);
			}
			// 获取省
			List<Area> Provincial = shopPerbiService.searchProvince();
			request.setAttribute("Provincial", Provincial);
			// 获取市
			List<Area> list = shopPerbiService.searchArea();
			request.setAttribute("area", list);

			// 行业类型
			List<B2cDict> cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
			request.setAttribute("cillinglist", cillinglist);
			// 代理商列表
			String path = request.getSession().getServletContext()
					.getContextPath();
			request.setAttribute("agentlist", path
					+ "agent/selectAgentTree.htm");

			if (b2cShopperbi != null) {
				// 获取临时表代理商
				Long shopperId = b2cShopperbi.getShopperidP();
				if (shopperId != null) {
					Agent agent = shopPerbiService.searchAgent(shopperId);
					request.setAttribute("agentName", agent.getScompany());
					request.setAttribute("agentId", agent.getShopperid());
				}
				// 获取银行
				B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi
						.getAccountbankdictval());
				request.setAttribute("bankName", dicbank);
				// 证照
				Long photoid = b2cShopperbi.getPhotoid();
				if (photoid != null) {
					MposPhotoTmp photo = shopPerbiService
							.selectPhotoTmpById(photoid);
					request.setAttribute("photo", photo);
					request.setAttribute("image_get_url", DynamicConfigLoader.getByEnv("imageget.url"));
				}
			}
			if (b2cShopperbiFormal != null) {
				// 获取正式表代理商
				Long shopperIdFormal = b2cShopperbiFormal.getShopperidP();
				if (shopperIdFormal != null) {
					Agent agent = shopPerbiService.searchAgent(shopperIdFormal);
					request.setAttribute("agentNameFormal", agent.getScompany());
					request.setAttribute("agentIdFormal", agent.getShopperid());
				}
				// 获取银行
				B2cDict dicbank = shopPerbiService
						.findBankName(b2cShopperbiFormal
								.getAccountbankdictval());
				request.setAttribute("bankNameFormal", dicbank);
				// 证照
				Long photoid = b2cShopperbiFormal.getPhotoid();
				if (photoid != null) {
					MposPhoto photo = shopPerbiService.selectPhotoById(photoid);
					request.setAttribute("photoFormal", photo);
					request.setAttribute("image_get_urlFormal", DynamicConfigLoader.getByEnv("imageget.url"));
				}
			}
			String shopperTel = null;
			if(b2cShopperbi!=null){
				shopperTel = b2cShopperbi.getStel();
			if(b2cShopperbiFormal!=null&&shopperTel==null){
				shopperTel = b2cShopperbiFormal.getStel();
				}
			}
			// 手续费，临时表
			MposMerchantFee creditMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperID, Constants.FEE_TYPE_CREDIT);
			MposMerchantFee debitMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperID, Constants.FEE_TYPE_DEBIT);
			MposMerchantFee weChatMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperID, Constants.FEE_TYPE_WECHAT);
			MposMerchantFee alipayMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperID, Constants.FEE_TYPE_ALIPAY);
			MposMerchantFee ylpayMerchantFeeTemp = shopPerbiService.findMposMerchantFeeTemp(shopperID, Constants.FEE_TYPE_YLPAY);
			request.setAttribute("creditMerchantFeeTemp", creditMerchantFeeTemp);
			request.setAttribute("debitMerchantFeeTemp", debitMerchantFeeTemp);
			request.setAttribute("weChatMerchantFeeTemp", weChatMerchantFeeTemp);
			request.setAttribute("alipayMerchantFeeTemp",  alipayMerchantFeeTemp);
			request.setAttribute("ylpayMerchantFeeTemp", ylpayMerchantFeeTemp);
			// 手续费
			MposMerchantFee creditMerchantFee = shopPerbiService.findMposMerchantFee(shopperID, Constants.FEE_TYPE_CREDIT);
			if(creditMerchantFee==null&&shopperTel!=null){
				creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_CREDIT);
        	}
			MposMerchantFee debitMerchantFee = shopPerbiService.findMposMerchantFee(shopperID, Constants.FEE_TYPE_DEBIT);
			if(debitMerchantFee==null&&shopperTel!=null){
				debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_DEBIT);
        	}
			MposMerchantFee weChatMerchantFee = shopPerbiService.findMposMerchantFee(shopperID, Constants.FEE_TYPE_WECHAT);
			if(weChatMerchantFee==null&&shopperTel!=null){
				weChatMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_WECHAT);
        	}
			MposMerchantFee alipayMerchantFee = shopPerbiService.findMposMerchantFee(shopperID, Constants.FEE_TYPE_ALIPAY);
			if(alipayMerchantFee==null&&shopperTel!=null){
				alipayMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel,Constants.FEE_TYPE_ALIPAY);
        	}
			MposMerchantFee ylpayMerchantFee = shopPerbiService.findMposMerchantFee(shopperID, Constants.FEE_TYPE_YLPAY);
			if(ylpayMerchantFee == null && shopperTel != null){
				ylpayMerchantFee = shopPerbiService.findMposRemoteFee(shopperTel, Constants.FEE_TYPE_YLPAY);
			}
			request.setAttribute("creditMerchantFee", creditMerchantFee);
			request.setAttribute("debitMerchantFee", debitMerchantFee);
			request.setAttribute("weChatMerchantFee", weChatMerchantFee);
			request.setAttribute("alipayMerchantFee",  alipayMerchantFee);
			request.setAttribute("ylpayMerchantFee", ylpayMerchantFee);

			request.setAttribute("b2cShopperbi", b2cShopperbi);
			request.setAttribute("b2cShopperbiFormal", b2cShopperbiFormal);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取商户信息失败);
		}
		return "merchant/shopPerbiInfoDetailsNew";
	}

	/**
	 * 修改历史列表
	 * 
	 * @param request
	 * @param modelMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=queryShopPerbiUpdateHistoryList")
	public String queryShopPerbiUpdateHistoryList(HttpServletRequest request) throws Exception {
		try {
			String shopperId = request.getParameter("shopperpriId");
			String updateStart = request.getParameter("updateStart");
			String updateEnd = request.getParameter("updateEnd");
			String updateUser = request.getParameter("updateUser");
			Map<String, String> param = new HashMap<String, String>();
			param.put("shopperId", shopperId);
			param.put("updateStart", updateStart);
			param.put("updateEnd", updateEnd);
			param.put("updateUser", updateUser);
			List<B2cShopperbiTempModify> modifies = shopPerbiService
					.findModifyByShopperbiIdList(param);
			request.setAttribute("modifies",modifies);
			request.setAttribute("shopperId", shopperId);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取信息失败);
		}
		return "merchant/shopPerbiDetailsHistoryList";
	}

	/**
	 * 修改明细
	 * 
	 * @param request
	 * @param modelMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=queryShopPerbiUpdateHistoryDetail")
	public String queryShopPerbiUpdateHistoryDetail(HttpServletRequest request) throws Exception {
		try {
			String modefyDetailId = request.getParameter("modefyDetailId");
			B2cShopperbiTempModify modify = shopPerbiService
					.findModifyById(modefyDetailId);
			// 行业类型
			List<B2cDict> cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
			request.setAttribute("cillinglist", cillinglist);
			// 如果代理商变更，获取代理商
			Long shopperId = modify.getShopperidP();
			if (shopperId != null) {
				Agent agent = shopPerbiService.searchAgent(shopperId);
				request.setAttribute("agentName", agent.getScompany());
				request.setAttribute("agentId", agent.getShopperid());
			}
			// 获取银行
			B2cDict dicbank = shopPerbiService.findBankName(modify
					.getAccountBankDictval());
			request.setAttribute("bankName", dicbank);
			request.setAttribute("modify", modify);
			request.setAttribute("image_get_url", DynamicConfigLoader.getByEnv("imageget.url"));
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取信息失败);
		}
		return "merchant/shopPerbiDetailsModify";
	}

	/**
	 * 基本信息修改
	 * */
	private void saveShopPerbiInfoUpdate(HttpServletRequest request,
			B2cShopperbiTemp b2cShopperbiTemp, ShopPerbiForm mbForm)
			throws Exception, BusinessException {

		try {
			// 检查shopperpriIds
			String shopperpriIds = request.getParameter("shopperpriIds");

			// 修改商户所在地省份信息
			if (b2cShopperbiTemp.getProvince() != null) {
				List provincialList = shopPerbiService
						.searchProvincial(b2cShopperbiTemp.getProvince());
				if (provincialList != null && provincialList.size() > 0) {
					Area area = (Area) provincialList.get(0);
					if (area != null) {
						b2cShopperbiTemp.setSprovince(area.getProvincialname());
						b2cShopperbiTemp.setProvince(area.getProvincial());
					}
				}
			}

			// 修改商户所在地城市信息
			if (b2cShopperbiTemp.getCity() != null) {
				List cityList = shopPerbiService.searchCity(b2cShopperbiTemp
						.getCity());
				if (cityList != null && cityList.size() > 0) {
					Area area = (Area) cityList.get(0);
					if (area != null) {
						b2cShopperbiTemp.setScity(area.getCityname());
						b2cShopperbiTemp.setCity(area.getCity());
					}
				}
			}

			// 修改票据信息省份信息
			if (b2cShopperbiTemp.getBillProvinceCode() != null) {
				List provincialList = shopPerbiService
						.searchProvincial(b2cShopperbiTemp
								.getBillProvinceCode());
				if (provincialList != null && provincialList.size() > 0) {
					Area area = (Area) provincialList.get(0);
					if (area != null) {
						b2cShopperbiTemp.setBillProvince(area
								.getProvincialname());
						b2cShopperbiTemp.setBillProvinceCode(area
								.getProvincial());
					}
				}
			}

			// 修改票据信息城市信息
			if (b2cShopperbiTemp.getBillCityCode() != null) {
				List cityList = shopPerbiService.searchCity(b2cShopperbiTemp
						.getBillCityCode());
				if (cityList != null && cityList.size() > 0) {
					Area area = (Area) cityList.get(0);
					if (area != null) {
						b2cShopperbiTemp.setBillCity(area.getCityname());
						b2cShopperbiTemp.setBillCityCode(area.getCity());
					}
				}
			}

			b2cShopperbiTemp.setIfagent(new Long(0));// 0为商户，1为代理商
			b2cShopperbiTemp.setShopperidP(mbForm.getShopperid_p());
			b2cShopperbiTemp.setUpdated(new Date());

			// 修改时修改审核状态
			b2cShopperbiTemp.setIfvalid(Short.valueOf(Constants.CON_NO));// 初审记录，0未审核
			b2cShopperbiTemp.setRecheckmerchantflag(Constants.CON_NO);// 复核，0未审核
			b2cShopperbiTemp.setRecheckmerchantremark("");

			b2cShopperbiTemp.setShopperid(Long.valueOf(shopperpriIds));
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.保存商户修改信息失败);
		}
	}

	/**
	 * 修改商户开户行信息
	 */
	private BackupsShopperInformation saveShopPerbiBankInfoUpdate(
			HttpServletRequest request, B2cShopperbiTemp b2cShopperbiTemp,
			ShopPerbiForm mbForm, BackupsShopperInformation bkshopper)
			throws Exception, BusinessException {
		try {
			String shopperpriIds = request.getParameter("shopperpriIds");
			b2cShopperbiTemp.setShopperid(Long.valueOf(shopperpriIds));
			B2cShopperbiTemp shopper = shopPerbiService
					.queryShopPerbi(shopperpriIds);
			// 根据记录获取代理商
			b2cShopperbiTemp.setShopperidP(shopper.getShopperidP());

			// 修改开户银行地址省份信息
			if (b2cShopperbiTemp.getAccountbankprov() != null) {
				List provinceList = shopPerbiService
						.searchProvincial(b2cShopperbiTemp.getAccountbankprov());
				if (provinceList != null && provinceList.size() > 0) {
					Area area = (Area) provinceList.get(0);
					if (area != null) {
						b2cShopperbiTemp.setAccountbankprov(area
								.getProvincialname());
						b2cShopperbiTemp.setAccountBankProvCode(area
								.getProvincial());
					}
				}
			}

			// 修改开户银行地址城市信息
			if (b2cShopperbiTemp.getAccountBankCity() != null) {
				List cityList = shopPerbiService.searchCity(b2cShopperbiTemp
						.getAccountBankCity());
				if (cityList != null && cityList.size() > 0) {
					Area area = (Area) cityList.get(0);
					if (area != null) {
						b2cShopperbiTemp.setAccountBankCity(area.getCityname());
						b2cShopperbiTemp.setAccountBankCityCode(area.getCity());
					}
				}
			}

			b2cShopperbiTemp.setBankUpdateDate(new Date());

			// 修改时修改审核状态
			b2cShopperbiTemp.setOpencheckstatus(new Short("0"));// 开户信息 初审
			b2cShopperbiTemp.setRecheckaccountflag(Constants.CON_NO);// 开户信息 复核

			if (shopper.getIsformal().toString().equals("1")) {
				b2cShopperbiTemp.setIsupdatebank(new Short("1"));
			}

			
			// 备份开户信息以及手续费信息 如果数据不存在 插入一条数据
				bkshopper.setCreateUser(((Operator) request.getSession()
						.getAttribute(Constants.SESSION_KEY_USER)).getId()
						.toString());
				bkshopper.setCreateDate(new Date());
				bkshopper.setT0fee(new BigDecimal(
						shopper.getT0fee() == null ? "0.0" : shopper.getT0fee().toString()));
				bkshopper.setShopperid(new BigDecimal(
						shopper.getShopperid() == null ? 0.0 : shopper
								.getShopperid()));
				bkshopper.setT0additionfee(new BigDecimal(shopper
						.getT0additionfee() == null ? 0.0 : shopper
						.getT0additionfee()));
				bkshopper.setT0fixedamount(new BigDecimal(shopper
						.getT0fixedamount() == null ? 0.0 : shopper
						.getT0fixedamount()));
				bkshopper.setT0maxamount(new BigDecimal(shopper
						.getT0maxamount() == null ? 0.0 : shopper
						.getT0maxamount()));
				bkshopper.setT0minamount(new BigDecimal(shopper
						.getT0minamount() == null ? 0.0 : shopper
						.getT0minamount()));
				bkshopper.setT0singledaylimit(new BigDecimal(shopper
						.getT0SingleDayLimit() == null ? 0.0 : shopper
						.getT0SingleDayLimit()));
				bkshopper.setAccountBankClientName(shopper
						.getAccountbankclientname() == null ? "" : shopper
						.getAccountbankclientname());
				bkshopper
						.setAccountBankDictval(shopper.getAccountbankdictval() == null ? ""
								: shopper.getAccountbankdictval());
				bkshopper
						.setAccountBankName(shopper.getAccountbankname() == null ? ""
								: shopper.getAccountbankname());
				bkshopper
						.setAccountBankNo(shopper.getAccountbankno() == null ? ""
								: shopper.getAccountbankno());
				bkshopper
						.setAccountBankProv(shopper.getAccountbankprov() == null ? ""
								: shopper.getAccountbankprov());

				

		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.保存商户修改信息失败);
		}
		return bkshopper;
	}

	/**
	 * 向临时表保存修改的手续费信息
	 */
	private Map<String, Object> updateshopPerbiFee(HttpServletRequest request,B2cShopperbiTemp b2cShopperbi, 
			ShopPerbiForm mbForm,MposMerchantFee s0debitMerchantFeeM,MposMerchantFee s0creditMerchantFeeM,MposMerchantFee d0debitMerchantFeeM,MposMerchantFee d0creditMerchantFeeM,MposMerchantFee t1debitMerchantFeeM,
			MposMerchantFee t1creditMerchantFeeM,MposMerchantFee weChatMerchantFeeM,MposMerchantFee alipayMerchantFeeM,MposMerchantFee ylpayMerchantFeeM,MposMerchantFee shortCutMerchantFeeM,
			MposMerchantFee b2cMerchantFeeM, MposMerchantFee shortCutSHMerchantFeeM) throws Exception, BusinessException {
		    Map<String, Object> feeMap = new HashMap<String, Object>();
		try {
			String shopperpriIds = request.getParameter("shopperpriIds");
			B2cShopperbiTemp shopper = shopPerbiService
					.queryShopPerbi(shopperpriIds);
			
			
			//查询原有费率,先查询临时表如果是空就查询正式表
			MposMerchantFee s0creditMerchantFee = shopPerbiService.findTempFeeTChannelType(shopperpriIds,Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
			if(s0creditMerchantFee==null)
				s0creditMerchantFee = shopPerbiService.findMposMerchantFee(shopperpriIds, Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);
			if(s0creditMerchantFee==null)
				s0creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperpriIds, Constants.FEE_TYPE_CREDIT,Constants.S0_CHANNEL_TYPE);

			MposMerchantFee s0debitMerchantFee = shopPerbiService.findTempFeeTChannelType(shopperpriIds,Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
			if(s0debitMerchantFee==null)
				s0debitMerchantFee = shopPerbiService.findMposMerchantFee(shopperpriIds, Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
			if(s0debitMerchantFee==null)
				s0debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperpriIds, Constants.FEE_TYPE_DEBIT,Constants.S0_CHANNEL_TYPE);
			
			MposMerchantFee d0creditMerchantFee = shopPerbiService.findTempFeeTChannelType(shopperpriIds,Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
			if(d0creditMerchantFee==null)
				d0creditMerchantFee = shopPerbiService.findMposMerchantFee(shopperpriIds, Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
			if(d0creditMerchantFee==null)
				d0creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperpriIds, Constants.FEE_TYPE_CREDIT,Constants.D0_CHANNEL_TYPE);
			
			MposMerchantFee d0debitMerchantFee = shopPerbiService.findTempFeeTChannelType(shopperpriIds,Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
			if(d0debitMerchantFee==null)
				d0debitMerchantFee = shopPerbiService.findMposMerchantFee(shopperpriIds, Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
			if(d0debitMerchantFee==null)
				d0debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperpriIds, Constants.FEE_TYPE_DEBIT,Constants.D0_CHANNEL_TYPE);
			
			MposMerchantFee t1creditMerchantFee = shopPerbiService.findTempFeeTChannelType(shopperpriIds,Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
			if(t1creditMerchantFee==null)
				t1creditMerchantFee = shopPerbiService.findMposMerchantFee(shopperpriIds, Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
			if(t1creditMerchantFee==null)
				t1creditMerchantFee = shopPerbiService.findMposRemoteFee(shopperpriIds, Constants.FEE_TYPE_CREDIT,Constants.T1_CHANNEL_TYPE);
			
			
			MposMerchantFee t1debitMerchantFee = shopPerbiService.findTempFeeTChannelType(shopperpriIds,Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
			if(t1debitMerchantFee==null)
				t1debitMerchantFee = shopPerbiService.findMposMerchantFee(shopperpriIds, Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
			if(t1debitMerchantFee==null)
				t1debitMerchantFee = shopPerbiService.findMposRemoteFee(shopperpriIds, Constants.FEE_TYPE_DEBIT,Constants.T1_CHANNEL_TYPE);
			
			
			MposMerchantFee weChatMerchantFee = shopPerbiService.findMposMerchantFeeTemp(shopperpriIds,Constants.FEE_TYPE_WECHAT);
			if(weChatMerchantFee==null)
				weChatMerchantFee = shopPerbiService.findMposMerchantFee(shopperpriIds, Constants.FEE_TYPE_WECHAT);
			if(weChatMerchantFee==null)
				weChatMerchantFee = shopPerbiService.findMposRemoteFee(shopperpriIds, Constants.FEE_TYPE_WECHAT);
			MposMerchantFee alipayMerchantFee = shopPerbiService.findMposMerchantFeeTemp(shopperpriIds,Constants.FEE_TYPE_ALIPAY);
			if(alipayMerchantFee==null)
				alipayMerchantFee = shopPerbiService.findMposMerchantFee(shopperpriIds, Constants.FEE_TYPE_ALIPAY);
			if(alipayMerchantFee==null)
				alipayMerchantFee = shopPerbiService.findMposRemoteFee(shopperpriIds, Constants.FEE_TYPE_ALIPAY);
			MposMerchantFee ylpayMerchantFee = shopPerbiService.findMposMerchantFeeTemp(shopperpriIds,Constants.FEE_TYPE_YLPAY);
			if(ylpayMerchantFee==null)
				ylpayMerchantFee = shopPerbiService.findMposMerchantFee(shopperpriIds,Constants.FEE_TYPE_YLPAY);
			if(ylpayMerchantFee==null)
				ylpayMerchantFee = shopPerbiService.findMposMerchantFee(shopperpriIds,Constants.FEE_TYPE_YLPAY);
			//如果临时表没有无卡汇率取正式表无卡汇率
			MposMerchantFee shortCutMerchantFee = shopPerbiService.findMposMerchantFeeTemp(shopperpriIds,Constants.FEE_TYPE_SHORTCUT);
			if(shortCutMerchantFee==null)
				shortCutMerchantFee = shopPerbiService.findMposMerchantFee(shopperpriIds,Constants.FEE_TYPE_SHORTCUT);
			
			MposMerchantFee b2cMerchantFee = shopPerbiService.findMposMerchantFeeTemp(shopperpriIds,Constants.FEE_TYPE_B2C);
			if(b2cMerchantFee==null)
				b2cMerchantFee = shopPerbiService.findMposMerchantFee(shopperpriIds,Constants.FEE_TYPE_B2C);
		
			/**
			 * 10月19号添加
			 */
			MposMerchantFee shortCutSHMerchantFee = shopPerbiService.findMposMerchantFeeTemp(shopperpriIds,Constants.FEE_TYPE_SHD0);
			if(shortCutSHMerchantFee==null)
				shortCutSHMerchantFee = shopPerbiService.findMposMerchantFee(shopperpriIds,Constants.FEE_TYPE_SHD0);
			

			
			//获取修改的费率
			String s0creditFee = request.getParameter("s0creditFee");//贷记卡
			String s0debitFee = request.getParameter("s0debitFee");//借记卡
			
			String d0creditFee = request.getParameter("d0creditFee");//贷记卡
			String d0debitFee = request.getParameter("d0debitFee");//借记卡
			
			String t1creditFee = request.getParameter("t1creditFee");//贷记卡
			String t1debitFee = request.getParameter("t1debitFee");//借记卡
			
			String s0fixAmount = request.getParameter("s0fixAmount");
			String t0fixAmount = request.getParameter("t0fixAmount");
			
			String weChatFee = request.getParameter("weChatFee");
			String alipayFee = request.getParameter("alipayFee");
			String weChatD0Fee = request.getParameter("weChatD0Fee");
			String alipayD0Fee = request.getParameter("alipayD0Fee");
			String ylpayFee = request.getParameter("ylpayFee");
			String ylpayD0Fee = request.getParameter("ylpayD0Fee");
			//无卡汇率
			String shortCut = request.getParameter("shortCut");
			String shortCutDo = request.getParameter("shortCutDo");
			String shortCutSHDo = request.getParameter("shortCutSHDo");
			String b2c = request.getParameter("b2c");
			String b2cDo = request.getParameter("b2cDo");
			
			//判断费率是否修改s0creditMerchantFee数据库里面的字段,如果都不为空
			if(s0creditFee!=null&&s0creditMerchantFee!=null){
				if(!s0creditFee.equals(s0creditMerchantFee.getFee())){
					s0creditMerchantFeeM.setFee(s0creditFee);
				}
				s0creditMerchantFee.setFee(s0creditFee);
				s0creditMerchantFee.setEachamount(new BigDecimal(s0fixAmount));
				s0creditMerchantFee.setUpdateDate(new Date());
			}
			if(s0debitFee!=null&&s0debitMerchantFee!=null){
				if(!s0debitFee.equals(s0debitMerchantFee.getFee())){
					s0debitMerchantFeeM.setFee(s0debitFee);
				}
				s0debitMerchantFee.setFee(s0debitFee);
				s0debitMerchantFee.setEachamount(new BigDecimal(s0fixAmount));
				s0debitMerchantFee.setUpdateDate(new Date());
			}
			
			if(d0creditFee!=null&&d0creditMerchantFee!=null){
				if(!d0creditFee.equals(d0creditMerchantFee.getFee())){
					d0creditMerchantFeeM.setFee(d0creditFee);
				}
				d0creditMerchantFee.setFee(d0creditFee);
				d0creditMerchantFee.setEachamount(new BigDecimal(t0fixAmount));
				d0creditMerchantFee.setUpdateDate(new Date());
			}
			if(d0debitFee!=null&&d0debitMerchantFee!=null){
				if(!d0debitFee.equals(d0debitMerchantFee.getFee())){
					d0debitMerchantFeeM.setFee(d0debitFee);
				}
				d0debitMerchantFee.setFee(d0debitFee);
				d0debitMerchantFee.setEachamount(new BigDecimal(t0fixAmount));
				d0debitMerchantFee.setUpdateDate(new Date());
			}
			
			if(t1creditFee!=null&&t1creditMerchantFee!=null){
				if(!t1creditFee.equals(t1creditMerchantFee.getFee())){
					t1creditMerchantFeeM.setFee(t1creditFee);
				}
				t1creditMerchantFee.setFee(t1creditFee);
				t1creditMerchantFee.setEachamount(new BigDecimal(0));
				t1creditMerchantFee.setUpdateDate(new Date());
			}
			if(t1debitFee!=null&&t1debitMerchantFee!=null){
				if(!t1debitFee.equals(t1debitMerchantFeeM.getFee())){
					t1debitMerchantFeeM.setFee(t1debitFee);
				}
				t1debitMerchantFee.setFee(t1debitFee);
				t1debitMerchantFee.setEachamount(new BigDecimal(0));
				t1debitMerchantFee.setUpdateDate(new Date());
			}
						
			if(weChatFee!=null&&weChatMerchantFee!=null&&weChatD0Fee!=null){
				if(!weChatFee.equals(weChatMerchantFee.getFee())){
					weChatMerchantFeeM.setFee(weChatFee);
					
				}
				if(!weChatD0Fee.equals(weChatMerchantFee.getD0Fee())){
					weChatMerchantFeeM.setD0Fee(weChatD0Fee);
				}
				weChatMerchantFee.setFee(weChatFee);
				weChatMerchantFee.setD0Fee(weChatD0Fee);
				weChatMerchantFee.setUpdateDate(new Date());
			}
			if(alipayFee!=null&&alipayMerchantFee!=null&&alipayD0Fee!=null){
				if(!alipayFee.equals(alipayMerchantFee.getFee())){
					alipayMerchantFeeM.setFee(alipayFee);
				}
				if(!alipayD0Fee.equals(alipayMerchantFee.getD0Fee())){
					alipayMerchantFeeM.setD0Fee(alipayD0Fee);
				}
				alipayMerchantFee.setFee(alipayFee);
				alipayMerchantFee.setD0Fee(alipayD0Fee);
				alipayMerchantFee.setUpdateDate(new Date());
			}
			if(ylpayFee!=null&&ylpayMerchantFee!=null){
				if(!ylpayFee.equals(ylpayMerchantFee.getFee())){
					ylpayMerchantFeeM.setFee(ylpayFee);
				}
				if (!ylpayD0Fee.equals(ylpayMerchantFee.getD0Fee())) {
					ylpayMerchantFeeM.setD0Fee(ylpayD0Fee);
				}
				ylpayMerchantFee.setD0Fee(ylpayD0Fee);
				ylpayMerchantFee.setFee(ylpayFee);
				ylpayMerchantFee.setUpdateDate(new Date());
			}
			//比较数据库和传入的是否一样,如果不一样就取传入的放入新对象,如果一样就取传入的放入查询的对象
			// shortCutMerchantFeeM, b2cMerchantFeeM
			if(shortCut!=null&&shortCutMerchantFee!=null&&shortCutDo!=null){
				if(!shortCut.equals(shortCutMerchantFee.getFee())){
					shortCutMerchantFeeM.setFee(shortCut);
					
				}
				if(!shortCutDo.equals(shortCutMerchantFee.getD0Fee())){
					shortCutMerchantFeeM.setD0Fee(shortCutDo);
				}
				shortCutMerchantFee.setFee(shortCut);
				shortCutMerchantFee.setD0Fee(shortCutDo);
				shortCutMerchantFee.setUpdateDate(new Date());
			}
			
			/**
			 * 10月19号添加
			 */
			if(shortCutSHDo != null && shortCutSHMerchantFee != null){
				if(!shortCutSHDo.equals(shortCutSHMerchantFee.getD0Fee())){
					shortCutSHMerchantFeeM.setD0Fee(shortCutSHDo);
					shortCutSHMerchantFeeM.setUpdateDate(new Date());
				}
				shortCutSHMerchantFee.setD0Fee(shortCutSHDo);
				shortCutSHMerchantFee.setUpdateDate(new Date());
			}
			
			if(b2c!=null&&b2cMerchantFee!=null&&b2cDo!=null){
				if(!b2c.equals(b2cMerchantFee.getFee())){
					b2cMerchantFeeM.setFee(b2c);
					
				}
				if(!b2cDo.equals(b2cMerchantFee.getD0Fee())){
					b2cMerchantFeeM.setD0Fee(b2cDo);
				}
				b2cMerchantFee.setFee(b2c);
				b2cMerchantFee.setD0Fee(b2cDo);
				b2cMerchantFee.setUpdateDate(new Date());
			}

			/*debitFeeHis.setFeeType(Constants.FEE_TYPE_DEBIT);
			creditFeeHis.setFeeType(Constants.FEE_TYPE_CREDIT);
			weChatFeeHis.setFeeType(Constants.FEE_TYPE_WECHAT);
			alipayFeeHis.setFeeType(Constants.FEE_TYPE_ALIPAY);
			ylpayFeeHis.setFeeType(Constants.FEE_TYPE_YLPAY);*/

			b2cShopperbi.setUpdated(new Date());
			// 新加手续费初审、复审
			b2cShopperbi.setFirstfeecheck("0");
			b2cShopperbi.setFeerecheck("0");
			
			
			feeMap.put("s0debitMerchantFee", s0debitMerchantFee);
			feeMap.put("s0creditMerchantFee", s0creditMerchantFee);
			feeMap.put("d0debitMerchantFee", d0debitMerchantFee);
			feeMap.put("d0creditMerchantFee", d0creditMerchantFee);
			
			feeMap.put("t1debitMerchantFee", t1debitMerchantFee);
			feeMap.put("t1creditMerchantFee", t1creditMerchantFee);
			
			feeMap.put("weChatMerchantFee", weChatMerchantFee);
			feeMap.put("alipayMerchantFee", alipayMerchantFee);
			feeMap.put("ylpayMerchantFee",ylpayMerchantFee);
			feeMap.put("shortCutMerchantFee",shortCutMerchantFee);
			feeMap.put("b2cMerchantFee",b2cMerchantFee);
			feeMap.put("shortCutSHMerchantFee",shortCutSHMerchantFee);

			/*feeMap.put("debitFeeHis", debitFeeHis);
			feeMap.put("creditFeeHis", creditFeeHis);
			feeMap.put("weChatFeeHis", weChatFeeHis);
			feeMap.put("alipayFeeHis", alipayFeeHis);
			feeMap.put("ylpayFeeHis",ylpayFeeHis);*/
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.保存商户修改信息失败);
		}
		return feeMap;
	}

	/**
	 * 保存商户证照变更
	 * 
	 * @param request
	 * @param b2cShopperbi
	 * @param mbForm
	 * @throws IOException
	 * @throws BusinessException
	 */
	private Map saveShopPerbiPhotoUpdate(HttpServletRequest request,
			B2cShopperbiTemp b2cShopperbi, ShopPerbiForm mbForm,
			B2cShopperbiTempModify shopperbiTempModify,
			MposApplicationProgress pro) throws Exception {
		Map hashmap = new HashMap();
		Map maphoto = new HashMap();
		try {
			Long photoid = b2cShopperbi.getPhotoid();
			if (photoid != null) {
				hashmap.put("photoid", photoid.toString());
			}
			hashmap.put("identityId", b2cShopperbi.getIDNo()==null?"":b2cShopperbi.getIDNo().toUpperCase());
			String shopperType = b2cShopperbi.getMerchantType();

			String uploadpath = request.getSession().getServletContext().getRealPath("/");
			String uploadpath1 = uploadpath + "image1.jpg";
			String uploadpath2 = uploadpath + "image2.jpg";
			String uploadpath3 = uploadpath + "image3.jpg";
			String uploadpath4 = uploadpath + "image4.jpg";
			String uploadpath5 = uploadpath + "image5.jpg";
			String uploadpath6 = uploadpath + "image6.jpg";
			String uploadpath7 = uploadpath + "image7.jpg";
			String uploadpath8 = uploadpath + "image8.jpg";
			
			String uploadpath9 = uploadpath + "image9.jpg";

			InputStream input1 = mbForm.getHandidentitycardphoto()
					.getInputStream();
			int inputsize1 = inputsize(input1);

			if (inputsize1 != 0) {
				ImageCompressUtil.saveMinPhoto(input1, uploadpath1, 800, 0.9d);
				InputStream input11 = new FileInputStream(uploadpath1);
				String handIdentityCardPhoto = photoString(input11);
				hashmap.put("handIdentityCardPhoto",handIdentityCardPhoto.replace("+", "%2B"));
			}
			InputStream input2 = mbForm.getFrontidentitycardphoto()
					.getInputStream();
			int inputsize2 = inputsize(input2);
			if (inputsize2 != 0) {
				ImageCompressUtil.saveMinPhoto(input2, uploadpath2, 800, 0.9d);
				InputStream input22 = new FileInputStream(uploadpath2);
				String frontIdentityCardPhoto = photoString(input22);
				hashmap.put("frontIdentityCardPhoto",frontIdentityCardPhoto.replace("+", "%2B"));
			}

			InputStream input3 = mbForm.getReverseidentitycardphoto()
					.getInputStream();
			int inputsize3 = inputsize(input3);
			if (inputsize3 != 0) {
				ImageCompressUtil.saveMinPhoto(input3, uploadpath3, 800, 0.9d);
				InputStream input33 = new FileInputStream(uploadpath3);
				String reverseIdentityCardPhoto = photoString(input33);
				hashmap.put("reverseIdentityCardPhoto",reverseIdentityCardPhoto.replace("+", "%2B"));
			}

			

			InputStream input7 = mbForm.getSignaturephoto().getInputStream();
			int inputsize7 = inputsize(input7);
			if (inputsize7 != 0) {
				ImageCompressUtil.saveMinPhoto(input7, uploadpath5, 800, 0.9d);
				InputStream input77 = new FileInputStream(uploadpath5);
				String signaturePhoto = photoString(input77);
				hashmap.put("signaturePhoto",signaturePhoto.replace("+", "%2B"));
			}

			InputStream input9 = mbForm.getCreditCardPhoto().getInputStream();
			int inputsize9 = inputsize(input9);
			if (inputsize9 != 0) {
				ImageCompressUtil.saveMinPhoto(input9, uploadpath6, 800, 0.9d);
				InputStream input99 = new FileInputStream(uploadpath6);
				String creditCardPhoto = photoString(input99);
				hashmap.put("creditCardPhoto",creditCardPhoto.replace("+", "%2B"));
			}

//			InputStream input10 = mbForm.getSettlementCardPhoto()
//					.getInputStream();
//			int inputsize10 = inputsize(input10);
//			if (inputsize10 != 0) {
//				ImageCompressUtil.saveMinPhoto(input10, uploadpath7, 800, 0.9d);
//				InputStream input1010 = new FileInputStream(uploadpath7);
//				String settlementCardPhoto = photoString(input1010);
//				hashmap.put("settlementCardPhoto",settlementCardPhoto.replace("+", "%2B"));
//			}
			
			InputStream input11 = mbForm.getFixPhoto()
					.getInputStream();
			int inputsize11 = inputsize(input11);
			if (inputsize11 != 0) {
				ImageCompressUtil.saveMinPhoto(input11, uploadpath9, 800, 0.9d);
				InputStream input1111 = new FileInputStream(uploadpath9);
				String fixPhoto = photoString(input1111);
				hashmap.put("fixPhoto",fixPhoto.replace("+", "%2B"));
			}
			
//			0：个人 1企业
			String merchantType=b2cShopperbi.getMerchantType();
			if(merchantType.equals("1")){
				//个人门面店
				InputStream input4 = mbForm.getStorephoto().getInputStream();
				int inputsize4 = inputsize(input4);
				if (inputsize4 != 0) {
					ImageCompressUtil.saveMinPhoto(input4, uploadpath4, 800, 0.9d);
					InputStream input44 = new FileInputStream(uploadpath4);
					String storePhoto = photoString(input44);
					hashmap.put("storePhoto", storePhoto.replace("+", "%2B"));
				}
				//企业照片修改
				InputStream input8 = mbForm.getLicensephoto().getInputStream();
				int inputsize8 = inputsize(input8);
				if (inputsize8 != 0) {
					ImageCompressUtil.saveMinPhoto(input8, uploadpath8, 800, 0.9d);
					InputStream input1010 = new FileInputStream(uploadpath8);
					String licensePhoto = photoString(input1010);
					hashmap.put("licensePhoto",licensePhoto.replace("+", "%2B"));
				}
			
			}
			
			hashmap.put("shopperType", shopperType);
			Map resultMap = HttpClientUtils.postRequestMap(DynamicConfigLoader.getByEnv("update.photo"), hashmap, Map.class);
			// 插入图片，插入一条季度记录
			MposApplicationProgress ap = this.shopPerbiService
					.findMposApplicationProgress(b2cShopperbi.getShopperid()
							.toString(), "5");
			if (ap == null) {
				pro.setShopperid(mbForm.getShopperid());
				pro.setScompany(b2cShopperbi.getScompany());
				pro.setApplicationTheme("变更证照");
				pro.setApplicationType("5");
				pro.setCreateUser(((Operator) request.getSession()
						.getAttribute(Constants.SESSION_KEY_USER)).getId());
				pro.setCreateDate(new Date());
				if(mbForm.getShopperid_p() != null){
					pro.setShopperidP(mbForm.getShopperid_p().toString());
					pro.setAgentName(shopPerbiService.searchAgent(
							Long.valueOf(mbForm.getShopperid_p())).getScompany());
				}
				
				pro.setApplicationStatus("1");
			}
			B2cShopperbiTemp b2cShopperbiTemp = new B2cShopperbiTemp();
			b2cShopperbiTemp.setPhotoRecheckFlag(Constants.CON_NO);
			b2cShopperbiTemp.setPhotoCheckFlag(Constants.CON_NO);
			b2cShopperbiTemp.setShopperid(b2cShopperbi.getShopperid());
			// 返回值得到photo
			JSONObject ob = null;
			ob = JSONObject.fromObject(resultMap);
			maphoto = (Map) ob.get("maphoto");
			// 给modify值
			if (maphoto != null) {
				String s1 = (String) maphoto.get("signaturePhoto");
				String s2 = (String) maphoto.get("handIdentityCardPhoto");
				String s3 = (String) maphoto.get("frontIdentityCardPhoto");
				String s4 = (String) maphoto.get("reverseIdentityCardPhoto");
				String s5 = (String) maphoto.get("storePhoto");
				String s6 = (String) maphoto.get("creditCardPhoto");
				String s7 = (String) maphoto.get("settlementCardPhoto");
				String s8 = (String) maphoto.get("licensePhoto");
				if (s1 != null) {
					shopperbiTempModify.setSignaturePhoto(s1);
				}
				if (s2 != null) {
					shopperbiTempModify.setHandIdentityCardPhoto(s2);
				}
				if (s3 != null) {
					shopperbiTempModify.setFrontIdentityCardPhoto(s3);
				}
				if (s4 != null) {
					shopperbiTempModify.setReverseIdentityCardPhoto(s4);
				}
				if (s5 != null) {
					shopperbiTempModify.setStorePhoto(s5);
				}
				if (s6 != null) {
					shopperbiTempModify.setCreditCardPhoto(s6);
				}
				if (s7 != null) {
					shopperbiTempModify.setSettlementCardPhoto(s7);
				}
				if (s8 != null) {
					shopperbiTempModify.setLicensePhoto(s8);
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.保存商户修改信息失败);
		}
		return maphoto;
	}

	private int inputsize(InputStream input1) throws Exception {
		byte[] by = new byte[1000];
		int size = input1.available();
		if (size == 0) {
			System.out.println("文件为空!!");
			return size;
		}
		return 1;
	}

	private String photoString(InputStream input1) throws IOException {
		byte[] data = null;
		// 读取图片字节数组
		try {
			data = new byte[input1.available()];
			input1.read(data);
			input1.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		String ss = Base64.encode(data);
		return ss;
	}

	private B2cShopperbiTempModify findModify(
			B2cShopperbiTemp shopperbiTempOld, B2cShopperbiTemp shopperbiTempNew) {

		B2cShopperbiTempModify shopperbiTempModify = new B2cShopperbiTempModify();
//old信息部为空那么跟新信息比较是否不相等 就在修改明显对象中添加最新的信息,如果是空,也在详情表里面添加最新的信息
		if (shopperbiTempOld.getAccountBankCity() != null) {
			if (!shopperbiTempOld.getAccountBankCity().equals(
					shopperbiTempNew.getAccountBankCity()))
				shopperbiTempModify.setAccountBankCity(shopperbiTempNew
						.getAccountBankCity());
		} else {
			shopperbiTempModify.setAccountBankCity(shopperbiTempNew
					.getAccountBankCity());
		}
		if (shopperbiTempOld.getAccountBankCityCode() != null) {
			if (!shopperbiTempOld.getAccountBankCityCode().equals(
					shopperbiTempNew.getAccountBankCityCode()))
				shopperbiTempModify.setAccountBankCityCode(shopperbiTempNew
						.getAccountBankCityCode());
		} else {
			shopperbiTempModify.setAccountBankCityCode(shopperbiTempNew
					.getAccountBankCityCode());
		}
		if (shopperbiTempOld.getAccountbankclientname() != null) {
			if (!shopperbiTempOld.getAccountbankclientname().equals(
					shopperbiTempNew.getAccountbankclientname()))
				shopperbiTempModify.setAccountBankClientName(shopperbiTempNew
						.getAccountbankclientname());
		} else {
			shopperbiTempModify.setAccountBankClientName(shopperbiTempNew
					.getAccountbankclientname());
		}
		if (shopperbiTempOld.getAccountbankdictval() != null) {
			if (!shopperbiTempOld.getAccountbankdictval().equals(
					shopperbiTempNew.getAccountbankdictval()))
				shopperbiTempModify.setAccountBankDictval(shopperbiTempNew
						.getAccountbankdictval());
		} else {
			shopperbiTempModify.setAccountBankDictval(shopperbiTempNew
					.getAccountbankdictval());
		}
		if (shopperbiTempOld.getAccountbankname() != null) {
			if (!shopperbiTempOld.getAccountbankname().equals(
					shopperbiTempNew.getAccountbankname()))
				shopperbiTempModify.setAccountBankName(shopperbiTempNew
						.getAccountbankname());
		} else {
			shopperbiTempModify.setAccountBankName(shopperbiTempNew
					.getAccountbankname());
		}
		if (shopperbiTempOld.getAccountbankno() != null) {
			if (!shopperbiTempOld.getAccountbankno().equals(
					shopperbiTempNew.getAccountbankno()))
				shopperbiTempModify.setAccountBankNo(shopperbiTempNew
						.getAccountbankno());
		} else {
			shopperbiTempModify.setAccountBankNo(shopperbiTempNew
					.getAccountbankno());
		}
		if (shopperbiTempOld.getAccountbankprov() != null) {
			if (!shopperbiTempOld.getAccountbankprov().equals(
					shopperbiTempNew.getAccountbankprov()))
				shopperbiTempModify.setAccountBankProv(shopperbiTempNew
						.getAccountbankprov());
		} else {
			shopperbiTempModify.setAccountBankProv(shopperbiTempNew
					.getAccountbankprov());
		}
		if (shopperbiTempOld.getAccountBankProvCode() != null) {
			if (!shopperbiTempOld.getAccountBankProvCode().equals(
					shopperbiTempNew.getAccountBankProvCode()))
				shopperbiTempModify.setAccountBankProvCode(shopperbiTempNew
						.getAccountBankProvCode());
		} else {
			shopperbiTempModify.setAccountBankProvCode(shopperbiTempNew
					.getAccountBankProvCode());
		}
		if (shopperbiTempOld.getB2cShopperbiId() != null) {
			if (!shopperbiTempOld.getB2cShopperbiId().equals(
					shopperbiTempNew.getB2cShopperbiId()))
				shopperbiTempModify.setB2cShopperbiId(shopperbiTempNew
						.getB2cShopperbiId());
		} else {
			shopperbiTempModify.setB2cShopperbiId(shopperbiTempNew
					.getB2cShopperbiId());
		}
		if (shopperbiTempOld.getBillAddress() != null) {
			if (!shopperbiTempOld.getBillAddress().equals(
					shopperbiTempNew.getBillAddress()))
				shopperbiTempModify.setBillAddress(shopperbiTempNew
						.getBillAddress());
		} else {
			shopperbiTempModify.setBillAddress(shopperbiTempNew
					.getBillAddress());
		}
		if (shopperbiTempOld.getBillCity() != null) {
			if (!shopperbiTempOld.getBillCity().equals(
					shopperbiTempNew.getBillCity()))
				shopperbiTempModify.setBillCity(shopperbiTempNew.getBillCity());
		} else {
			shopperbiTempModify.setBillCity(shopperbiTempNew.getBillCity());
		}
		if (shopperbiTempOld.getBillCityCode() != null) {
			if (!shopperbiTempOld.getBillCityCode().equals(
					shopperbiTempNew.getBillCityCode()))
				shopperbiTempModify.setBillCityCode(shopperbiTempNew
						.getBillCityCode());
		} else {
			shopperbiTempModify.setBillCityCode(shopperbiTempNew
					.getBillCityCode());
		}
		if (shopperbiTempOld.getBillName() != null) {
			if (!shopperbiTempOld.getBillName().equals(
					shopperbiTempNew.getBillName()))
				shopperbiTempModify.setBillName(shopperbiTempNew.getBillName());
		} else {
			shopperbiTempModify.setBillName(shopperbiTempNew.getBillName());
		}
		if (shopperbiTempOld.getBillProvince() != null) {
			if (!shopperbiTempOld.getBillProvince().equals(
					shopperbiTempNew.getBillProvince()))
				shopperbiTempModify.setBillProvince(shopperbiTempNew
						.getBillProvince());
		} else {
			shopperbiTempModify.setBillProvince(shopperbiTempNew
					.getBillProvince());
		}
		if (shopperbiTempOld.getBillProvinceCode() != null) {
			if (!shopperbiTempOld.getBillProvinceCode().equals(
					shopperbiTempNew.getBillProvinceCode()))
				shopperbiTempModify.setBillProvinceCode(shopperbiTempNew
						.getBillProvinceCode());
		} else {
			shopperbiTempModify.setBillProvinceCode(shopperbiTempNew
					.getBillProvinceCode());
		}
		if (shopperbiTempOld.getCity() != null) {
			if (!shopperbiTempOld.getCity().equals(shopperbiTempNew.getCity()))
				shopperbiTempModify.setCity(shopperbiTempNew.getCity());
		} else {
			shopperbiTempModify.setCity(shopperbiTempNew.getCity());
		}
		if (shopperbiTempOld.getIndustry() != null) {
			if (!shopperbiTempOld.getIndustry().equals(
					shopperbiTempNew.getIndustry()))
				shopperbiTempModify.setIndustry(shopperbiTempNew.getIndustry());
		} else {
			shopperbiTempModify.setIndustry(shopperbiTempNew.getIndustry());
		}
		if (shopperbiTempOld.getIsSupportT0() != null) {
			if (!shopperbiTempOld.getIsSupportT0().equals(
					shopperbiTempNew.getIsSupportT0()))
				shopperbiTempModify.setIsSupportT0(shopperbiTempNew
						.getIsSupportT0());
		} else {
			shopperbiTempModify.setIsSupportT0(shopperbiTempNew
					.getIsSupportT0());
		}
		if (shopperbiTempOld.getProvince() != null) {
			if (!shopperbiTempOld.getProvince().equals(
					shopperbiTempNew.getProvince()))
				shopperbiTempModify.setProvince(shopperbiTempNew.getProvince());
		} else {
			shopperbiTempModify.setProvince(shopperbiTempNew.getProvince());
		}
		if (shopperbiTempOld.getRemark() != null) {
			if (!shopperbiTempOld.getRemark().equals(
					shopperbiTempNew.getRemark()))
				shopperbiTempModify.setRemark(shopperbiTempNew.getRemark());
		} else {
			shopperbiTempModify.setRemark(shopperbiTempNew.getRemark());
		}
		if (shopperbiTempOld.getSaddress() != null) {
			if (!shopperbiTempOld.getSaddress().equals(
					shopperbiTempNew.getSaddress()))
				shopperbiTempModify.setSaddress(shopperbiTempNew.getSaddress());
		} else {
			shopperbiTempModify.setSaddress(shopperbiTempNew.getSaddress());
		}
		if (shopperbiTempOld.getScity() != null) {
			if (!shopperbiTempOld.getScity()
					.equals(shopperbiTempNew.getScity()))
				shopperbiTempModify.setScity(shopperbiTempNew.getScity());
		} else {
			shopperbiTempModify.setScity(shopperbiTempNew.getScity());
		}
		if (shopperbiTempOld.getScompany() != null) {
			if (!shopperbiTempOld.getScompany().equals(
					shopperbiTempNew.getScompany()))
				shopperbiTempModify.setScompany(shopperbiTempNew.getScompany());
		} else {
			shopperbiTempModify.setScompany(shopperbiTempNew.getScompany());
		}
		if (shopperbiTempOld.getSettlementType() != null) {
			if (!shopperbiTempOld.getSettlementType().equals(
					shopperbiTempNew.getSettlementType()))
				shopperbiTempModify.setSettlementType(shopperbiTempNew
						.getSettlementType());
		} else {
			shopperbiTempModify.setSettlementType(shopperbiTempNew
					.getSettlementType());
		}
		if (shopperbiTempOld.getShopperidP() != null) {
			if (!shopperbiTempOld.getShopperidP().equals(
					shopperbiTempNew.getShopperidP()))
				shopperbiTempModify.setShopperidP(shopperbiTempNew
						.getShopperidP());
		} else {
			shopperbiTempModify.setShopperidP(shopperbiTempNew.getShopperidP());
		}
		if (shopperbiTempOld.getSifpactid() != null) {
			if (!shopperbiTempOld.getSifpactid().equals(
					shopperbiTempNew.getSifpactid()))
				shopperbiTempModify.setSifpactid(shopperbiTempNew
						.getSifpactid());
		} else {
			shopperbiTempModify.setSifpactid(shopperbiTempNew.getSifpactid());
		}
		if (shopperbiTempOld.getSprovince() != null) {
			if (!shopperbiTempOld.getSprovince().equals(
					shopperbiTempNew.getSprovince()))
				shopperbiTempModify.setSprovince(shopperbiTempNew
						.getSprovince());
		} else {
			shopperbiTempModify.setSprovince(shopperbiTempNew.getSprovince());
		}
		if (shopperbiTempOld.getStel() != null) {
			if (!shopperbiTempOld.getStel().equals(shopperbiTempNew.getStel()))
				shopperbiTempModify.setStel(shopperbiTempNew.getStel());
		} else {
			shopperbiTempModify.setStel(shopperbiTempNew.getStel());
		}
		if (Constants.CON_NO.equals(shopperbiTempNew.getIsSupportT0())) {
			if (shopperbiTempOld.getT0fee() != null) {
				if (!shopperbiTempOld.getT0fee().equals(
						shopperbiTempNew.getT0fee()))
					shopperbiTempModify.setT0Fee(shopperbiTempNew.getT0fee());
			} else {
				shopperbiTempModify.setT0Fee(shopperbiTempNew.getT0fee());
			}
			if (shopperbiTempOld.getT0fixedamount() != null) {
				if (!shopperbiTempOld.getT0fixedamount().equals(
						shopperbiTempNew.getT0fixedamount()))
					shopperbiTempModify.setT0FixedAmount(shopperbiTempNew
							.getT0fixedamount());
			} else {
				shopperbiTempModify.setT0FixedAmount(shopperbiTempNew
						.getT0fixedamount());
			}
			if (shopperbiTempOld.getT0maxamount() != null) {
				if (!shopperbiTempOld.getT0maxamount().equals(
						shopperbiTempNew.getT0maxamount()))
					shopperbiTempModify.setT0MaxAmount(shopperbiTempNew
							.getT0maxamount());
			} else {
				shopperbiTempModify.setT0MaxAmount(shopperbiTempNew
						.getT0maxamount());
			}
			if (shopperbiTempOld.getT0minamount() != null) {
				if (!shopperbiTempOld.getT0minamount().equals(
						shopperbiTempNew.getT0minamount()))
					shopperbiTempModify.setT0MinAmount(shopperbiTempNew
							.getT0minamount());
			} else {
				shopperbiTempModify.setT0MinAmount(shopperbiTempNew
						.getT0minamount());
			}
			if (shopperbiTempOld.getT0SingleDayLimit() != null) {
				if (!shopperbiTempOld.getT0SingleDayLimit().equals(
						shopperbiTempNew.getT0SingleDayLimit()))
					shopperbiTempModify.setT0SingleDayLimit(shopperbiTempNew
							.getT0SingleDayLimit());
			} else {
				shopperbiTempModify.setT0SingleDayLimit(shopperbiTempNew
						.getT0SingleDayLimit());
			}
		}
		return shopperbiTempModify;
	}

}
