package com.uns.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class FunctionMerInfo implements Serializable{
	private static final long serialVersionUID = 1L;
	private Long id;
    private String functionCode;
    private String functionValue;
    private String functionUrl;
    private Long status;
    private String functionType;
    private Long pri;
    private Date createDate;
    private Date updateDate;
    private Long version;
    private String description;
    private Long functionId;
	private List<RoleInfo> roleInfo;

	public Long getFunctionId() {
		return functionId;
	}
	public void setFunctionId(Long functionId) {
		this.functionId = functionId;
	}
	public List<RoleInfo> getRoleInfo() {
		return roleInfo;
	}
	public void setRoleInfo(List<RoleInfo> roleInfo) {
		this.roleInfo = roleInfo;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getFunctionCode() {
		return functionCode;
	}
	public void setFunctionCode(String functionCode) {
		this.functionCode = functionCode;
	}
	public String getFunctionValue() {
		return functionValue;
	}
	public void setFunctionValue(String functionValue) {
		this.functionValue = functionValue;
	}
	public String getFunctionUrl() {
		return functionUrl;
	}
	public void setFunctionUrl(String functionUrl) {
		this.functionUrl = functionUrl;
	}
	public Long getStatus() {
		return status;
	}
	public void setStatus(Long status) {
		this.status = status;
	}
	public String getFunctionType() {
		return functionType;
	}
	public void setFunctionType(String functionType) {
		this.functionType = functionType;
	}
	public Long getPri() {
		return pri;
	}
	public void setPri(Long pri) {
		this.pri = pri;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public Long getVersion() {
		return version;
	}
	public void setVersion(Long version) {
		this.version = version;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
   
}