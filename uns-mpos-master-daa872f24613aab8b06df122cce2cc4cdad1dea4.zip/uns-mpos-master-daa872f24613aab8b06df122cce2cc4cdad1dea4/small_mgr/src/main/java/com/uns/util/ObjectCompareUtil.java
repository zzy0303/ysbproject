package com.uns.util;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;


import com.uns.model.B2cShopperbiTemp;

public class ObjectCompareUtil {

	public static <T>Object compare(Object old , Object neuu) throws Exception{
		Class clazz = old.getClass();
		Class clazz2 = neuu.getClass();
		Object objectR = clazz.newInstance();
		   if(clazz == clazz2){
			   Field field[] = clazz.getDeclaredFields();
			   for (Field field2 : field) {
				   PropertyDescriptor descriptor = new PropertyDescriptor(field2.getName(), clazz);
				   PropertyDescriptor descriptor2 = new PropertyDescriptor(field2.getName(), clazz2);
				   Method method = descriptor.getReadMethod();
				   Method method2 = descriptor2.getReadMethod();
				   Method method3 = descriptor2.getWriteMethod();
				   Object object = method.invoke(old);
				   Object object2 = method2.invoke(neuu);
				   Object object3 = method3.invoke(objectR,object2);//第一个是执行方法的对象，后面是方法所需参数
				   if(object==object2&&object!=null&&object2!=null)
				   System.out.println(method.getName());//找到值相同的属性
			}
		   }else{
			   return null;
		   }
		return null;
	}
	
	public static void main(String[] args) {
		B2cShopperbiTemp temp = new B2cShopperbiTemp();
		B2cShopperbiTemp temp2 = new B2cShopperbiTemp();
		temp.setAccountBankCity("123");
		temp2.setAccountBankCity("123");
		
		temp.setAccountBankCityCode("456");
		temp2.setAccountBankCityCode("457");
		try {
			B2cShopperbiTemp temp3 = (B2cShopperbiTemp) compare(temp,temp2);
			System.out.println(temp3.getAccountBankCityCode());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
