package com.uns.web;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.model.Operator;
import com.uns.model.YsbFreeFunds;
import com.uns.service.YsbFreeFundsService;
import com.uns.util.DateUtils;
import com.uns.util.HttpClientUtils;
import com.uns.util.MD5Util;
import com.uns.web.form.YsbFreeFundsForm;

@Controller
@RequestMapping(value = "/ysbFreeFunds.htm")
public class YsbFreeFundsController extends BaseController{
	
	@Autowired
	private YsbFreeFundsService ysbFreeFundsService;

	/**自由资金充值
	 * 查询本地充值历史记录
	 * @param request
	 * @param response
	 * @param tradeForm
	 * @return
	 * @throws BusinessException
	 * @throws Exception
	 */
	@RequestMapping(params = "method=findYsbFreeFundsList")
	public String findYsbFreeFundsList(HttpServletRequest request, HttpServletResponse response,YsbFreeFundsForm mbform)
		throws BusinessException, Exception{
		
		List ysbFreeFundsList=ysbFreeFundsService.findYsbFreeFundsList(mbform);
		request.setAttribute("ysbFreeFundsList", ysbFreeFundsList);
		
		Map ysbFreeFundsMap=ysbFreeFundsMap();
		if(Constants.RESPONSE_CODE.equals(ysbFreeFundsMap.get("rspCode"))){
			request.setAttribute("ysbFreeFundsAmount", ysbFreeFundsMap.get("fundBalance"));
		}else{
			request.setAttribute("ysbFreeFundsAmount", "查询失败");
		}
		
		return "ysbFreeFunds/ysbFreeFundsList";
		
	}

	/**查询平台自有资金余额
	 * @return
	 * @throws Exception 
	 */
	private Map ysbFreeFundsMap() throws Exception {
		Map parmsMap=new HashMap();
		Date dates = new Date();
		String mradom = RandomStringUtils.randomNumeric(6);
		
		String orderId = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss") + mradom;
		String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");	
		String mac=getfundInfoMac(orderId,orderTime);
		
		parmsMap.put("orderId", orderId);
		parmsMap.put("orderTime", orderTime);
		parmsMap.put("mac", mac);
		
        log.info("平台自有资金余额查询："+DynamicConfigLoader.getByEnv("fundinfo.url")+parmsMap.toString());
        Map resultMap =HttpClientUtils.postRequestMap(DynamicConfigLoader.getByEnv("fundinfo.url"),parmsMap,Map.class);
        logger.info("平台自有资金余额返回码:"+resultMap);
		return resultMap;
	}

	
	
	

	/**生成mac
	 * @param orderId
	 * @param orderTime
	 * @return
	 */
	private String getfundInfoMac(String orderId, String orderTime) {
		StringBuffer sb=new StringBuffer();
		sb.append("orderId="+orderId);
		sb.append("&orderTime="+orderTime);
		sb.append("&merchantKey="+DynamicConfigLoader.getByEnv("merchant_key"));
		return MD5Util.getMD5(sb.toString());
	}

	/**去充值页面
	 * @param request
	 * @param modelMap
	 * @param shopperId
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=recharge")
	@FormToken(save=true)
	public String recharge(HttpServletRequest request, HttpServletResponse response,YsbFreeFundsForm mbform)throws Exception {
		Map ysbFreeFundsMap=ysbFreeFundsMap();
		if(Constants.RESPONSE_CODE.equals(ysbFreeFundsMap.get("rspCode"))){
			request.setAttribute("ysbFreeFundsAmount", ysbFreeFundsMap.get("fundBalance"));
		}else{
			request.setAttribute("ysbFreeFundsAmount", "查询失败");
		}
		return "ysbFreeFunds/recharge";
	}
	
	
	/**保存充值记录
	 * 1.调用充值接口
	 * 2.
	 * @param request
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=saveRecharge")
	//@FormToken(remove=true)
	public String saveRecharge(HttpServletRequest request, HttpServletResponse response,YsbFreeFunds ysbFreeFunds)throws Exception {
		try {
			Map parmsMap=new HashMap();
			Date dates = new Date();
			String mradom = RandomStringUtils.randomNumeric(6);
			
			String orderId = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss") + mradom;
			String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");	
			String type=ysbFreeFunds.getType();
			Double amount=ysbFreeFunds.getAmount();
			
			parmsMap.put("orderId", orderId);
			parmsMap.put("orderTime", orderTime);
			if(Constants.TYPE_1.equals(type)){
				parmsMap.put("amount", amount);
			}else{
				parmsMap.put("amount", amount*(-1));
			}
			
			
			Operator operator=(Operator)request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			if(operator!=null){
				String createUser=operator.getUserName();
				ysbFreeFunds.setCreateUser(createUser);
			}
			ysbFreeFunds.setOrderid(orderId);
			ysbFreeFunds.setOrdertime(orderTime);
			ysbFreeFunds.setAmount(amount);
			Map returnMap=recharge(parmsMap);
			ysbFreeFunds.setRspcode(returnMap.get("rspCode")==null?"0500":returnMap.get("rspCode").toString());
			ysbFreeFunds.setRspmsg(returnMap.get("rspMsg")==null?"系统错误":returnMap.get("rspMsg").toString());	
			ysbFreeFundsService.insert(ysbFreeFunds);
			if(Constants.RESPONSE_CODE.equals(returnMap.get("rspCode"))){
				request.setAttribute(Constants.MESSAGE_KEY,"充值成功!");
			}else{
				request.setAttribute(Constants.MESSAGE_KEY,"充值失败!");
			}
			request.setAttribute("url","ysbFreeFunds.htm?method=findYsbFreeFundsList");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.自有资金充值错误);
		}
	
		return "/returnPage";
	}

	/**充值接口
	 * @param parmsMap
	 * @return
	 * @throws Exception 
	 */
	private Map recharge(Map parmsMap) throws Exception {
		String mac=getRechargeMac(parmsMap);
		parmsMap.put("mac", mac);
		log.info("平台自有资金充值："+DynamicConfigLoader.getByEnv("setfund.url")+parmsMap.toString());
	    Map resultMap =HttpClientUtils.postRequestMap(DynamicConfigLoader.getByEnv("setfund.url"),parmsMap,Map.class);
	    logger.info("平台自有资金充值返回码:"+resultMap);
		return resultMap;
	}
	
	
	/**充值的Mac验证失败
	 * @param parmsMap
	 * @return
	 */
	private String getRechargeMac(Map parmsMap) {
		StringBuffer sb=new StringBuffer();
		sb.append("amount="+parmsMap.get("amount"));
		sb.append("&orderId="+parmsMap.get("orderId"));
		sb.append("&orderTime="+parmsMap.get("orderTime"));
		sb.append("&merchantKey="+DynamicConfigLoader.getByEnv("merchant_key"));
		return MD5Util.getMD5(sb.toString());
	}

	/**详情
	 * @param request
	 * @param response
	 * @param mbform
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=ysbFreeFundsDetails")
	public String ysbFreeFundsDetails(HttpServletRequest request, HttpServletResponse response,YsbFreeFundsForm mbform)throws Exception {
		String ysbFreeFundsId=request.getParameter("ysbFreeFundsId");
		YsbFreeFunds ysbFreeFunds=ysbFreeFundsService.findRechargeById(ysbFreeFundsId);
		request.setAttribute("ysbFreeFunds", ysbFreeFunds);
		
		return "ysbFreeFunds/rechargeDetails";
	}
	
}
