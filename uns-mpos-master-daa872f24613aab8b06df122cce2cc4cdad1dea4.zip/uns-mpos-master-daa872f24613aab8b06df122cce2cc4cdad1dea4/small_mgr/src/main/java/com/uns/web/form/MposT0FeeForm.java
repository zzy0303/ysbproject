package com.uns.web.form;

public class MposT0FeeForm {

	private String orderidq;
	private String createdStart;
	private String createdEnd;
	private String  rspcodeq;
	public String getOrderidq() {
		return orderidq;
	}
	public void setOrderidq(String orderidq) {
		this.orderidq = orderidq;
	}
	public String getCreatedStart() {
		return createdStart;
	}
	public void setCreatedStart(String createdStart) {
		this.createdStart = createdStart;
	}
	public String getCreatedEnd() {
		return createdEnd;
	}
	public void setCreatedEnd(String createdEnd) {
		this.createdEnd = createdEnd;
	}
	public String getRspcodeq() {
		return rspcodeq;
	}
	public void setRspcodeq(String rspcodeq) {
		this.rspcodeq = rspcodeq;
	}
	
	
	
	
	
	
}
