package com.uns.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import com.uns.common.ConstantsEnv;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.dao.UsersMapper;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.inf.notify.api.Notify;
import com.uns.inf.notify.request.NotifyResult;
import com.uns.inf.notify.request.SmsNotifyRequest;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.Users;

@Service
public class SendMessageService {
	private Logger log = Logger.getLogger(SendMessageService.class);
	
	@Autowired
	private UsersMapper usersMapper;
	
	@Autowired
	private Notify notify;
	
	/**
	 * 发送短信消息
	 * @param mobile 手机号
	 * @param content 发送内容
	 * @return 
	 * @throws BusinessException
	 */
	public NotifyResult sendSmsMessage(String mobile,String content) throws BusinessException{
		try {
			String serialNumber = System.currentTimeMillis()+RandomStringUtils.randomNumeric(4);
			SmsNotifyRequest smsNotifyRequest = new SmsNotifyRequest();
			smsNotifyRequest.addMobile(mobile);//手机号
			smsNotifyRequest.setSerialNumber(serialNumber);
			smsNotifyRequest.setTemplateId(21000021L);//设置一个已存在的模板，但不会读取模板内容 以Content内容为准
			smsNotifyRequest.setAppid("small_mgr");
			Map<String, String> data = new HashMap<String,String>();
			data.put("content", content);
			smsNotifyRequest.setData(data);
			NotifyResult notifyResult = notify.sendSms(smsNotifyRequest);
			if (null == notifyResult || !"success".equals(notifyResult.getState() + "")) {
				log.info("调用发送短信接口返回失败！"+ notifyResult.toString());
			}else{
				log.info("短信已发送到：" + notifyResult.toString());
			}
			return notifyResult;
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.发送短信失败);
		}
	}
	
	/**
	 * 注册信息审核通过
	 * @param b2cShopperbi
	 * @param password
	 * @param request
	 * @throws BusinessException
	 */
	public void sendMessage(B2cShopperbiTemp b2cShopperbi,String password,HttpServletRequest request) throws BusinessException {
		String content=getContentapp(DynamicConfigLoader.getByEnv("sms.content.url"),b2cShopperbi,password);
		String mobile = b2cShopperbi.getStel();
		sendSmsMessage(mobile, content);
	}


	/**
	 * 发送短信
	 * @param b2cShopperbi
	 */
	public void sendMessageOCR(B2cShopperbiTemp b2cShopperbi) throws BusinessException {
		String content = getContentOCR(ConstantsEnv.SMS_CONTENT_OCR, b2cShopperbi);
		String mobile = b2cShopperbi.getStel();
		sendSmsMessage(mobile, content);
	}

	private String getContentOCR(String smsContent,  B2cShopperbiTemp b2cShopperbi) {
		Map map = getOCRSmsMap(b2cShopperbi);
		return this.replaceValues(smsContent, map);
	}

	private Map<String, String> getOCRSmsMap(B2cShopperbiTemp b2cShopperbi){

		Map<String, String> map = new HashMap<String, String>();
		map.put("${name}", b2cShopperbi.getName() + "");
		return map;
	}
	
	/**商户实名认证审核已通过的信息
	 * @param b2cShopperbi
	 * @param request
	 * @throws Exception
	 */
	public void sendCheckMessage(B2cShopperbiTemp b2cShopperbi,	HttpServletRequest request) throws BusinessException {
		String content=getContentCheckMsg(DynamicConfigLoader.getByEnv("sms_content_activate.url"),b2cShopperbi);
		String mobile = b2cShopperbi.getStel();
		sendSmsMessage(mobile, content);
	}
	
	/**审核不通过的信息
	 * @param b2cShopperbi
	 * @param request
	 * @throws BusinessException 
	 */
	public void sendMessageFail(B2cShopperbiTemp b2cShopperbi,HttpServletRequest request) throws BusinessException {
		String content=getContentNotPassMsg(DynamicConfigLoader.getByEnv("sms_content_not_pass.url"),b2cShopperbi);
		String mobile = b2cShopperbi.getStel();
		sendSmsMessage(mobile, content);
	}

	private String getContentapp(String smsContent,  B2cShopperbiTemp b2cShopperbi,String password) {
		Map map=getMposRemoteInvitationValuesapp(b2cShopperbi,password);
		return this.replaceValues(smsContent, map);
	}
	
	private Map<String, String> getMposRemoteInvitationValuesapp(B2cShopperbiTemp b2cShopperbi,String password) {

		Map<String, String> map = new HashMap<String, String>();
		Map paramMap=new HashMap();
		paramMap.put("merchantid", b2cShopperbi.getShopperidP()==null?"":b2cShopperbi.getShopperidP().toString());
		paramMap.put("isAgent", Constants.CON_YES);
		Users user=usersMapper.selectBymid(paramMap);
		map.put("${salesman}", user.getUserName() + "");
		map.put("${agenttel}",user.getTel()+ "");
		map.put("${password}",password);
		return map;
	}
	
	private String getContentCheckMsg(String smsContent,B2cShopperbiTemp b2cShopperbi) {
		Map map=getCheckMsgValuesapp(b2cShopperbi);
		return this.replaceValues(smsContent, map);
	}

	private Map getCheckMsgValuesapp(B2cShopperbiTemp b2cShopperbi) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("${mercahntName}",b2cShopperbi.getName()+ "");
		return map;
	}

	private String getContentNotPassMsg(String smsContentNotPass,B2cShopperbiTemp b2cShopperbi) {
		Map map=getContentNotPass(b2cShopperbi);
		return this.replaceValues(smsContentNotPass, map);
	}

	private Map getContentNotPass(B2cShopperbiTemp b2cShopperbi) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("${mercahntName}",b2cShopperbi.getName()+ "");
		return map;
	}
	
	private String replaceValues(String mailContent, Map<String, String> values) {
		Set<String> set = values.keySet();
		for (String key : set){
			if(key.indexOf("${") != -1)
				mailContent = mailContent.replace(key, values.get(key) + "");
		}
		return mailContent;
	}
}
