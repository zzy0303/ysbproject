package com.uns.dao;



import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.B2cTempTermBinder;
import com.uns.web.form.ShopPerbiForm;


@Repository
public interface B2cTempTermBinderMapper extends BaseMapper<Object>{

    int insert(B2cTempTermBinder record);
//
//    int insertSelective(B2cTermBinder record);
//
//
//    int deleteByShopperId(String shopperId);
//
	List<HashMap> selectTempBinderList(String shopperId);
	//更加termNo查询绑定表
	List selectByTempBinder(String termNo);
	//修改绑定表中得status
	void updateTermBinder(B2cTempTermBinder record);
	
	void deleteByTermno(String termNo);
	
	void deleteByMerchantNo(String MerchantNo);
	
	List<HashMap> selectNewBinder(String shoppId);
	
	List<HashMap> showdeviceList(ShopPerbiForm mbForm);
	
	
	String selectfirstCount();
	
	String selectlastCount();
	
	B2cTempTermBinder selectbyterm(String termNo);
    
	void updateterm(B2cTempTermBinder term);
}