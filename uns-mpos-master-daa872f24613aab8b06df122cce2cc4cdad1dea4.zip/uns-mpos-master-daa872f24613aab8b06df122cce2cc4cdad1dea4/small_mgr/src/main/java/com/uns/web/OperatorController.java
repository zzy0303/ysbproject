package com.uns.web;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.model.Operator;
import com.uns.model.RoleInfo;
import com.uns.service.OperatorService;
import com.uns.service.RoleService;
import com.uns.util.Md5Encrypt;
import com.uns.util.StringUtils;
import com.uns.web.form.AgentUserForm;

@Controller("OperatorController")
@RequestMapping("/operator.htm")
public class OperatorController extends BaseController {

	@Autowired
	private OperatorService operatorService;
	
	@Autowired
	private RoleService roleService;
	/**操作员管理目录
	 * @param request
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=toUserManageList")
	public String toUserManageList(HttpServletRequest request,@ModelAttribute("mb") AgentUserForm mbForm, ModelMap modelMap) throws BusinessException{
		try {
			List userList = operatorService.selectUsersList(mbForm);
//			List roleInfoList = roleService.selectRoleInfo(Constants.CON_YES);
			modelMap.put("userList",userList );
//			modelMap.put("roleList",roleInfoList);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.操作员列表);
		}
		modelMap.put("mbForm", mbForm);
		return "operator/operatorList";
	}
	
	/**操作员角色页面
	 * @param request
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=operatorUpdate")
	@FormToken(save=true)
	public String operatorUpdate(HttpServletRequest request,@ModelAttribute("mb") AgentUserForm mbForm, ModelMap modelMap) throws BusinessException{
		try {
			String userId=request.getParameter("userId");
			Operator oper = null;
			if(!StringUtils.isEmpty(userId)){
				oper = operatorService.selectOperById(userId);
			}
			List<RoleInfo> roleInfoList;
			roleInfoList = roleService.selectRoleInfo(Constants.CON_YES);
			modelMap.put("user",oper );
			modelMap.put("roleInfoList",roleInfoList );
		} catch (NumberFormatException e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.数字格式化错误);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.操作员角色);
		}
		return "operator/operatorUpdate";
	}
	
	/**保存操作员
	 * @param request
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=saveOperator")
	@FormToken(remove=true)
	public String saveOperator(HttpServletRequest request,@ModelAttribute("mb") AgentUserForm mbForm, ModelMap modelMap) throws BusinessException{
		try {
			String userId=request.getParameter("userId");
			if(!StringUtils.isEmpty(userId)){
				if (!mbForm.getMobile().equals(mbForm.getOldMobile())){
					Operator operator = operatorService.findOperatorByMobile(mbForm.getMobile());
					if (null != operator){
						throw new BusinessException(ExceptionDefine.验证手机号);
					}
				}
				Operator user = operatorService.selectOperById(userId);
				if(mbForm.getUserName()!=null&&!"".equals(mbForm.getUserName())){
				user.setUserName(mbForm.getUserName());
				}
				user.setUsercode(mbForm.getUsercode());
				user.setLoginName(mbForm.getLoginName());
				user.setMobile(mbForm.getMobile());
				user.setEnabled(Short.parseShort(mbForm.getEnabledq()));
				user.setDemo(mbForm.getDemo());
				operatorService.updateOperById(user);
				request.setAttribute(Constants.MESSAGE_KEY,Constants.SAVE_MESSAGE);
			}else{
				throw new BusinessException(ExceptionDefine.空指针异常);
			}
		} catch (NumberFormatException e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.数字格式化错误);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.保存操作员);
		}
	    request.setAttribute("url","operator.htm?method=toUserManageList");
        return "/returnPage";
	}
	
	/**前往操作员新增页面
	 * @param request
	 * @param mbForm
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(params = "method=toAddOperator")
	@FormToken(save=true)
	public String toAddOperator(HttpServletRequest request,@ModelAttribute("mb") AgentUserForm mbForm, ModelMap modelMap){
		List list = null;
		try {
			list= roleService.selectRoleInfo(Constants.CON_YES);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.setAttribute("roleInfoList", list);
		return "operator/operatorAdd";
	}
	

	/**新增操作员
	 * @param request
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=addOperator")
	@FormToken(remove=true)
	public String addOperator(HttpServletRequest request,@ModelAttribute("mb") AgentUserForm mbForm, ModelMap modelMap) throws BusinessException{
		try{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd kk/mm/ss");
			String today = sdf.format(new Date());
			Date date = sdf.parse(today);
			if(mbForm.getUserName()==null||"".equals(mbForm.getUserName())){
				throw new BusinessException(ExceptionDefine.字段不允许为空);
			}
			Map map = new HashMap();
			map.put("username", mbForm.getUserName());
			Operator op = operatorService.findOperatorByCode(map);
			if(op!=null){
				throw new BusinessException(ExceptionDefine.验证用户名);
			}
			op = operatorService.findOperatorByMobile(mbForm.getMobile());
			if (op != null){
				throw new BusinessException(ExceptionDefine.验证手机号);
			}
			if(mbForm.getPassword()==null||"".equals(mbForm.getPassword())){
				throw new BusinessException(ExceptionDefine.字段不允许为空);
			}
			Operator oper = new Operator();
			oper.setId(Long.valueOf("2"));
			oper.setUserName(mbForm.getUserName());
			oper.setPassword(Md5Encrypt.md5(mbForm.getPassword()));
			oper.setLoginName(mbForm.getLoginName());
			oper.setMobile(mbForm.getMobile());
			oper.setCreatedate(date);
			oper.setLastlogindate(date);
			oper.setUsercode(mbForm.getUsercode());
			oper.setEnabled(Short.parseShort(mbForm.getEnabledq()));
			oper.setDemo(mbForm.getDemo());
			operatorService.insert(oper);
		}catch(Exception e){
			e.printStackTrace();
		}
		String message="添加操作员成功";
		request.setAttribute("message", message);
		request.setAttribute("url","operator.htm?method=toUserManageList");
		return "/returnPage";
	}

	/**前往密码修改页面
	 * @param request
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=toUpdateOperPassword")
	@FormToken(save=true)
	public String toUpdateOperPassword(HttpServletRequest request,@ModelAttribute("mb") AgentUserForm mbForm, ModelMap modelMap) throws BusinessException{
	return "operator/updatePassword";
	}
		
	/**修改密码
	 * @param request
	 * @param response
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=updateOperPassword")
	@FormToken(remove=true)
	public String updateOperPassword(HttpServletRequest request,HttpServletResponse response,@ModelAttribute("mb") AgentUserForm mbForm, ModelMap modelMap)throws Exception{
		String pwd = this.reTrim(request.getParameter("password"));
		String newpwd = this.reTrim(request.getParameter("newpassword"));
		if(pwd==null||"".equals(pwd)){
			throw new BusinessException(ExceptionDefine.字段不允许为空);
		}
		if(request.getSession()==null||"".equals(request.getSession())){
			throw new BusinessException(ExceptionDefine.登录失效);
		}
		//获取当前登录的用户ID
		Operator oper = (Operator)request.getSession().getAttribute(Constants.SESSION_KEY_USER);
		if(oper==null||oper.getId()==null||"".equals(oper.getId())){
			throw new BusinessException(ExceptionDefine.重新登录);
		}
		String operid = oper.getId().toString();
		try{
		oper = operatorService.selectOperById(operid);
		}catch(Exception e){
			e.printStackTrace();
		}
		//获取旧的密码,判断输入的原密码是否和数据库中的密码一致
		String password = oper.getPassword();
		if(!password.equals(Md5Encrypt.md5(pwd))){
			throw new BusinessException(ExceptionDefine.密码错);
		}
		//将新密码存入数据库
		oper.setPassword(Md5Encrypt.md5(newpwd));
		try {
			operatorService.updateOperById(oper);
		} catch (Exception e) {
			e.printStackTrace();
		}
		String message ="修改密码成功";
		request.setAttribute("message", message);
		request.setAttribute("url","operator.htm?method=toUserManageList");
		return "/returnPage";
	}
	
	/**冻结操作员
	 * @param request
	 * @param response
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=blockOperator")
	@FormToken(save=true)
	public String blockOperator(HttpServletRequest request,HttpServletResponse response,@ModelAttribute("mb") AgentUserForm mbForm, ModelMap modelMap)throws Exception{
		String userId=request.getParameter("userId");
		if(userId==null||"".equals(userId)){
			throw new BusinessException(ExceptionDefine.空指针异常);
		}
		Operator operator = operatorService.selectOperById(userId);
		operator.setEnabled(new Short("0"));
		operatorService.updateOperById(operator);
		String message = "冻结操作员成功";
		request.setAttribute("message", message);
		request.setAttribute("url", "operator.htm?method=toUserManageList");
	return "returnPage";
	}
	
	
	/**删除操作员
	 * @param request
	 * @param response
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=removeOperator")
	@FormToken(remove=true)
	public String removeOperator(HttpServletRequest request,HttpServletResponse response,@ModelAttribute("mb") AgentUserForm mbForm, ModelMap modelMap)throws Exception{
		String userId=request.getParameter("userId");
		if(userId==null||"".equals(userId)){
			throw new BusinessException(ExceptionDefine.空指针异常);
		}
		operatorService.removeOperator(new BigDecimal(userId));
		String message = "删除操作员成功";
		request.setAttribute("message", message);
		request.setAttribute("url", "operator.htm?method=toUserManageList");
	return "returnPage";
	}
	
	private String reTrim(String str){
		return str.replace(" ","");
	}
}
