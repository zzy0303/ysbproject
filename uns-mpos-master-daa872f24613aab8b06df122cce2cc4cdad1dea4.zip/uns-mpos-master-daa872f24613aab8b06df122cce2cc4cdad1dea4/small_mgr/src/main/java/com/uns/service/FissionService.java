package com.uns.service;

import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.exception.BusinessException;
import com.uns.model.SysConfig;
import com.uns.util.FastJson;
import com.uns.util.HttpClientUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/12/25
 * @Modifyed By:
 */
@Service
public class FissionService {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    public List<SysConfig> querySysConfig(Map<String, Object> param) throws Exception {

        logger.info("查询mpos_qrcode配置请求参数：{}", FastJson.toJson(param));
        Map<String, Object> result = FastJson.fromJson(HttpClientUtils.postRequest(ConstantsEnv.MPOS_QRCODE_QUERY_CONFIG, param));
        logger.info("查询mpos_qrcode配置返回：{}", FastJson.toJson(result));
        if (result != null && Constants.SUCCESS_CODE_0000.equals(result.get("rspCode"))) {
            List<SysConfig> sysConfigs = FastJson.jsonToList(result.get("data").toString(), SysConfig.class);
            return sysConfigs;
        } else {
            throw new BusinessException("1111", "查询mpos_qrcode配置出错");
        }
    }

}
