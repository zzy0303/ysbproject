package com.uns.model;

public class B2cTerminal {
    
    private String terminalid;
    private String merchantid;
    private String num;
    private String name;
    private String time;
    private String type;
    private String flag;
    private String terminallimit;
    private String note;
    private String tertype;
    private String merchantno;
    private String scompany;
    private String agentscompany;
    private String agentid;
    private String status;
    
	public String getTerminalid() {
		return terminalid;
	}
	public void setTerminalid(String terminalid) {
		this.terminalid = terminalid;
	}
	public String getMerchantid() {
		return merchantid;
	}
	public void setMerchantid(String merchantid) {
		this.merchantid = merchantid;
	}
	public String getNum() {
		return num;
	}
	public void setNum(String num) {
		this.num = num;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getTerminallimit() {
		return terminallimit;
	}
	public void setTerminallimit(String terminallimit) {
		this.terminallimit = terminallimit;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getTertype() {
		return tertype;
	}
	public void setTertype(String tertype) {
		this.tertype = tertype;
	}
	public String getMerchantno() {
		return merchantno;
	}
	public void setMerchantno(String merchantno) {
		this.merchantno = merchantno;
	}
	public String getScompany() {
		return scompany;
	}
	public void setScompany(String scompany) {
		this.scompany = scompany;
	}
	public String getAgentscompany() {
		return agentscompany;
	}
	public void setAgentscompany(String agentscompany) {
		this.agentscompany = agentscompany;
	}
	public String getAgentid() {
		return agentid;
	}
	public void setAgentid(String agentid) {
		this.agentid = agentid;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
    
}