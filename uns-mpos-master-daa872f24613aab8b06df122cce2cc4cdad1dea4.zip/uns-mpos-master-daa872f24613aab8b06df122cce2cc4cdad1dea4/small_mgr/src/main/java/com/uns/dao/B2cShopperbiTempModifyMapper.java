package com.uns.dao;

import com.uns.model.B2cShopperbiTempModify;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface B2cShopperbiTempModifyMapper {

    int delete(B2cShopperbiTempModify example);

    int insert(B2cShopperbiTempModify record);

    List<B2cShopperbiTempModify> selectByB2cShopperbiTempModify (B2cShopperbiTempModify example);

    int update(@Param("record") B2cShopperbiTempModify record);

	List<B2cShopperbiTempModify> selectByShopperbiIdList(Map<String, String> param);

	B2cShopperbiTempModify selectById(Long modefyDetailId);


}