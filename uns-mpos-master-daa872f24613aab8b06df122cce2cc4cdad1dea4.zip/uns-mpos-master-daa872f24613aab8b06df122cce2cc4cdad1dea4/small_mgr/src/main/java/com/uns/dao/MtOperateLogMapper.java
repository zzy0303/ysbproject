package com.uns.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.MtOperateLog;
import com.uns.web.form.OperateLogForm;
@Repository
public interface MtOperateLogMapper extends BaseMapper<Object>{

    List<MtOperateLog> selectAccesslogList(OperateLogForm form);

    boolean insert(MtOperateLog record);

    MtOperateLog selectByPrimaryKey(String logid);
}