package com.uns.model;

import java.io.Serializable;

public class MtOperatepermit implements Serializable {
    private String permitid;

    private String url;

    private Short permittype;

    private String description;

    public String getPermitid() {
        return permitid;
    }

    public void setPermitid(String permitid) {
        this.permitid = permitid;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Short getPermittype() {
        return permittype;
    }

    public void setPermittype(Short permittype) {
        this.permittype = permittype;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}