package com.uns.common.interceptor;

import java.lang.reflect.Method;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import org.springside.modules.utils.Reflections;

import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.web.BaseController;

/**
 * 防止表单重复提交的拦截器
 * 注:在进入到表单页面时用@FormToken(save =true)
 *   在进入到表单校验时用@FormToken(remove =true)
 * 参考:http://blog.icoolxue.com/submitted-by-spring-mvc-to-prevent-data-duplication/
 * @author Administrator
 *
 */
public class FormTokenInterceptor extends HandlerInterceptorAdapter {
	 
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
    	if (handler instanceof BaseController) {
        	String methodName = request.getParameter("method");
        	if(StringUtils.isBlank(methodName)){
        		return true;
        	}
            Method method = Reflections.getAccessibleMethodByName(handler, methodName);
            if(method == null){
            	throw new BusinessException(ExceptionDefine.该页面不存在);
            }
            
            FormToken annotation = method.getAnnotation(FormToken.class);
            if (annotation != null) {
                boolean needSaveSession = annotation.save();
                if (needSaveSession) {
                    request.getSession(false).setAttribute("token", UUID.randomUUID().toString());
                }
                boolean needRemoveSession = annotation.remove();
                if (needRemoveSession) {
                    if (isRepeatSubmit(request)) {
                    	throw new BusinessException(ExceptionDefine.不能重复提交数据);
                    }
                    request.getSession(false).removeAttribute("token");
                }
            }
            return true;
        } else {
            return super.preHandle(request, response, handler);
        }
    }
 
    private boolean isRepeatSubmit(HttpServletRequest request) {
        String serverToken = (String) request.getSession(false).getAttribute("token");
        if (serverToken == null) {
            return true;
        }
        String clientToken = request.getParameter("token");
        if (clientToken == null) {
            return true;
        }
        if (!serverToken.equals(clientToken)) {
            return true;
        }
        return false;
    }
}
