package com.uns.web;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.plexus.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.model.Agent;
import com.uns.model.AgentMcc;
import com.uns.model.AgentRatio;
import com.uns.model.AgentSplit;
import com.uns.model.Operator;
import com.uns.service.AgentMccService;
import com.uns.service.AgentService;
import com.uns.service.AgentSplitService;
import com.uns.web.form.AgentForm;
import com.uns.web.form.AgentMccForm;
import com.uns.web.form.AgentRatioForm;
import com.uns.web.form.TradeForm;

/**
 * 收单后台分润设置--迁移
 */
@Controller
@RequestMapping(value = "/agentFee.htm")
public class AgentFeeController extends BaseController {
	
	@Autowired
	private AgentSplitService agentsplitservice;
	
	@Autowired
	private AgentMccService agentMccService;
	
	@Autowired
	private AgentService agentService;
	
	/**代理商分润设置页面
	 * @param request
	 * @param response
	 * @param tradeForm
	 * @return
	 * @throws BusinessException
	 * @throws Exception
	 */
	@RequestMapping(params = "method=findTopShopperFeeList")
	public String findTopShopperFeeList(HttpServletRequest request, HttpServletResponse response)
		throws BusinessException, Exception{
		try {
			Operator operator=(Operator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			if(operator==null) throw new BusinessException(ExceptionDefine.登录失效);
			String agentIds=request.getParameter("agentids");
			List<AgentRatioForm> forms=null;
			if(StringUtils.isNotEmpty(agentIds)){
				forms= agentsplitservice.findB2cAgentFormList(agentIds.trim());
			}else{
				forms= agentsplitservice.findB2cAgentList();
			}
			 
			
			String shopperids="";
			for(int i=0;i<forms.size();i++){
				AgentRatioForm  agentRatioForm=forms.get(i);
				shopperids+=agentRatioForm.getShopperid().toString()+",";
				
			}
			// 获取所有代理商的分润设置
			if(shopperids!=""){
				List<AgentSplit> splits = agentsplitservice.findAgentSplitList(shopperids.substring(0, shopperids.length()-1));
				int size=splits==null?0:splits.size();
				for(int x=0;x<size;x++){
					AgentSplit agentsplit = splits.get(x);
					if(agentsplit!=null){
						List<AgentMcc>  agentmccs = agentsplit.getAgentMccs();
						List<AgentMcc>  agentmccCPs = new ArrayList<AgentMcc>();
						System.out.println("splits:"+splits.get(x).getAgentid()+"x:"+splits.size()+" forms:  "+forms.size());
						for(int y=0;y<agentmccs.size();y++){
							AgentMcc agentmcc = agentmccs.get(y);
							// 获取所有下级代理商的分润规则
							AgentMcc agentmccCP = agentMccService.findAgentMcc(agentmcc.getAmid());
							agentmccCPs.add(agentmccCP);
						}
						
						agentsplit.setAgentMccs(agentmccCPs);
					}
			
					// 将下级代理商的分润规则填充到对应的下级代理商
					for(int k=0;k<forms.size();k++){
						AgentRatioForm  agentRatioForms=forms.get(k);
						if(agentRatioForms.getShopperid().longValue()==agentsplit.getAgentid().longValue()){
							forms.get(k).setAgentSplit(agentsplit);
						}
					}
					
				}
			}
			// 所有下级代理商信息以及分润设置
			request.setAttribute("forms", forms);
			request.setAttribute("agentIds", agentIds);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.代理商分润设置);
		}
		return "agent/agent_ratio_list";
	}
	
	
	/**去修改页面
	 * @param request
	 * @param response
	 * @param tradeForm
	 * @return
	 * @throws BusinessException
	 * @throws Exception
	 */
	
	@RequestMapping(params = "method=searchAgentSplit")
	@FormToken(save=true)
	public String searchAgentSplit(HttpServletRequest request, HttpServletResponse response, AgentForm agentForm)
		throws BusinessException, Exception{
		try {
			Operator operator=(Operator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			if(operator==null) throw new BusinessException(ExceptionDefine.登录失效);
			
			String shopperid=request.getParameter("shopperid");
			String scompany=request.getParameter("scompany");
			
			Agent agentDes = new Agent();
			agentDes.setShopperid(Long.valueOf(shopperid));
			agentDes.setScompany(scompany);
			Long editAgentid = Long.valueOf(shopperid);
			Boolean isSplitTmp = agentsplitservice.isSplitTmp(editAgentid);
			//true这是临时表存在
			if(isSplitTmp){
				List agentSplitDes=agentMccService.findAgentMccTmpBySgentId(editAgentid);
				AgentSplit split=agentsplitservice.getAgentSplitByAgentidTmp(shopperid);
				request.setAttribute("agentSplit", split);
				request.setAttribute("agentSplitDes", agentSplitDes);
			}else{
				List agentSplitDes=agentMccService.findAgentMcc6(editAgentid);
				AgentSplit split=agentsplitservice.getAgentSplitByAgentid(shopperid);
				request.setAttribute("agentSplit", split);
				request.setAttribute("agentSplitDes", agentSplitDes);
			}
			request.setAttribute("agentDes", agentDes);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.代理商分润修改);
		}
		
		return "agent/agent_fee_set";
	}

	/**保存代理商分润
	 * @param request
	 * @param response
	 * @param tradeForm
	 * @return
	 * @throws BusinessException
	 * @throws Exception
	 */
	@FormToken(remove=true)
	@RequestMapping(params = "method=saveAgentRatio")
	public String saveAgentRatio(HttpServletRequest request, HttpServletResponse response, TradeForm tradeForm)
		throws BusinessException, Exception{
		try {
			Operator operator=(Operator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			if(operator==null) throw new BusinessException(ExceptionDefine.登录失效);
		
			String agentidStr = request.getParameter("agentid");
			Long agentid = new Long(agentidStr);
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = new Date();
			String updateDate = format.format(date);
			
			// 分润结算起始值
			String lowestamtStr = request.getParameter("lowestamt");
			String remark = request.getParameter("remark");
			Long lowestamt = StringUtils.isBlank(lowestamtStr)?null:new Long(lowestamtStr);
			// 分润模式
			String modeflag = request.getParameter("modeflag");
			
			log.info("modeflag:"+modeflag);
			if(StringUtils.isBlank(modeflag) && StringUtils.isBlank(agentidStr))
				throw new BusinessException("修改代理商shopperid与分润模式不能为空!");		
			
			List<AgentSplit> agentSplits = agentsplitservice.getAgentSplit(agentid);
			AgentSplit agentSplit = null;
			if(agentSplits!=null&&agentSplits.size()>0){
				agentSplit = agentSplits.get(0);
			}else{
				agentSplit = new AgentSplit();
			}
			if(agentSplit==null ) {
				throw new BusinessException(agentidStr+"的分润数据异常!");
			}
			agentSplit.setAgentid(agentid);
			agentSplit.setLowestamt(lowestamt);
			agentSplit.setModeflag(modeflag);
			agentSplit.setRemark(remark);
			agentSplit.setUpdatemaker(operator.getUserName());
			agentSplit.setUpdatedate(updateDate);
			
			String[] mccids = request.getParameterValues("mccid");
			Integer msize = mccids==null?0:mccids.length;
			if(msize==0)
				throw new BusinessException(agentidStr+"的商户未选mcc分润通道!");
			List<AgentMccForm> agentMccs = new ArrayList<AgentMccForm>();
			for(int x=0;x<msize;x++){
				Long mccid = new Long(mccids[x]);
				String base_cost = request.getParameter("Fbase_cost_"+mccid);
				String ratio = request.getParameter("Fratio_"+mccid);
				String maxFee=request.getParameter("max_fee_"+mccid);
				Long amid = agentMccService.findAgentMccSq();
				AgentMccForm agentMcc = new AgentMccForm();
				agentMcc.setAmid(amid);
				agentMcc.setAgentid(agentid);
				agentMcc.setMccid(mccid);
				agentMcc.setBasecost(base_cost==null?null:Double.parseDouble(base_cost));
				agentMcc.setMaxFee(maxFee==null?null:Double.parseDouble(maxFee));
				
				List<AgentRatio> agentRatios = new ArrayList<AgentRatio>();
				AgentRatio agentRatio = new AgentRatio();
				agentRatio.setAgentid(agentid);
				agentRatio.setModeflag(modeflag);
				agentRatio.setRatio(ratio==null?null:Double.parseDouble(ratio));
				agentRatio.setUpdatedate(updateDate);
				agentRatio.setUpdatemaker(operator.getUserName());
				agentRatio.setAmid(amid);
				
				agentRatios.add(agentRatio);
				agentMcc.setAgentRatios(agentRatios);
				agentMccs.add(agentMcc);
				
			}
			Boolean isSplit = agentsplitservice.isSplit(agentid);
			if(!isSplit){
				agentsplitservice.editRatio(agentMccs,agentSplit);
				request.setAttribute(Constants.MESSAGE_KEY,"添加成功!");
			}
			else{
				agentsplitservice.editRatioTmp(agentMccs,agentSplit);
				request.setAttribute(Constants.MESSAGE_KEY,"修改成功!");
			}
		    request.setAttribute("url","agentFee.htm?method=findTopShopperFeeList");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.代理商分润保存);
		}
	    return "/returnPage";
	}
	
	/**查询临时表
	 * @param request
	 * @param agentRatioForm
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(params="method=findAgentSplitList")
	public String findAgentSplitList(HttpServletRequest request, AgentRatioForm agentRatioForm) throws BusinessException{
		try {
			Operator operator=(Operator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			if(operator==null) throw new BusinessException(ExceptionDefine.登录失效);
			// 获取当前代理商shpperid
			//agentRatioForm.setShopperid_p(Long.parseLong(agent.getShopperid()));
			agentRatioForm.trimUpdateDate(agentRatioForm.getUpdateStart(), agentRatioForm.getUpdateEnd());
			// 获取当前代理下级代理分润设置
			List<Map> forms = agentsplitservice.findAgentSplitList(agentRatioForm);
			List<AgentRatioForm> agentRatioForms = new ArrayList<AgentRatioForm>();
			for(Map map : forms){
				AgentRatioForm ratioForm = new AgentRatioForm();
				ratioForm.setShopperid(Long.parseLong(map.get("SHOPPERID").toString()));
				ratioForm.setLowestamt(map.get("LOWESTAMT")==null?0L:new Long(map.get("LOWESTAMT").toString()));
				ratioForm.setModeflag(map.get("MODEFLAG")==null?null:map.get("MODEFLAG").toString());
				ratioForm.setAgentCount(map.get("AGENTCOUNT")==null?0L:Long.parseLong(map.get("AGENTCOUNT").toString()));
				ratioForm.setScompany(map.get("SCOMPANY")==null?null:map.get("SCOMPANY").toString());
				ratioForm.setUpdatedate(map.get("UPDATEDATE")==null?"":map.get("UPDATEDATE").toString());
				ratioForm.setRemark(map.get("REMARK")==null?"":map.get("REMARK").toString());
				agentRatioForms.add(ratioForm);
			}
			
			request.setAttribute("list", agentRatioForms);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.查询分润信息);
		}
		return "agent/agent_fee_list";
	}
	
	/**
	 * 查看代理商分润明细
	 * @param request
	 * @return
	 */
	@RequestMapping(params="method=getAgentSplit")
	public String getAgentSplit(HttpServletRequest request,String shopperid,String scompany) throws Exception{
		try {
			Operator operator=(Operator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			if(operator==null) throw new BusinessException(ExceptionDefine.登录失效);
			
			Long agentid = new Long(shopperid);
			AgentRatioForm agentRatioForm = new AgentRatioForm();
			agentRatioForm.setShopperid(agentid);
			// 获取当前代理下级代理分润设置
			Map agentSplits = agentsplitservice.getAgentSplitByShoperid(shopperid);
			
			// 获取当前代理下级代理分润设置（临时）
			Map  agentSplitTmps = agentsplitservice.getAgentSplitTmp(agentid);
			request.setAttribute("agent", agentSplits);
			request.setAttribute("agentTmp", agentSplitTmps);
			
			Agent agentDes = new Agent();
			agentDes.setShopperid(agentid);
			agentDes.setScompany(scompany);
			//查询指定下级代理商的分润设置
			AgentSplit agentSplit = agentsplitservice.searchAgentSplit(agentid);
			if(agentSplit!=null){
				List<AgentMcc> agentmccDess = new ArrayList<AgentMcc>();
				for(AgentMcc agentMcc:agentSplit.getAgentMccs()){
					AgentMcc agentmccDes = agentMccService.findAgentMcc(agentMcc.getAmid());
					agentmccDess.add(agentmccDes);
				}
				agentSplit.setAgentMccs(agentmccDess);
			}else{
				agentSplit = new AgentSplit();
				List<AgentMcc> agentMccs = agentMccService.findAgentMccByAgentid(agentid);
				agentSplit.setAgentMccs(agentMccs);
			}
			request.setAttribute("agentSplit", agentSplit);
			
			AgentSplit agentSplitTmp = agentsplitservice.searchAgentSplitTmpCP(new Long(agentDes.getShopperid()));
			if(agentSplitTmp!=null){
				List<AgentMcc> agentmccDess = new ArrayList<AgentMcc>();
				for(AgentMcc agentMcc:agentSplitTmp.getAgentMccs()){
					AgentMcc agentmccDes = agentMccService.findAgentMccTmp(agentMcc.getAmid());
					agentmccDess.add(agentmccDes);
				}
				agentSplitTmp.setAgentMccs(agentmccDess);
			}else{
				agentSplitTmp = new AgentSplit();
				List<AgentMcc> agentMccs = agentMccService.findAgentMccTmpByAgentid(agentid);
				agentSplitTmp.setAgentMccs(agentMccs);
			}
			request.setAttribute("agentSplitTmp", agentSplitTmp);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.查看代理商分润明细);
		}
		
		// TODO 查看代理商分润设置-分润规则
		return "agent/agent_fee_view";
	}
	
}
