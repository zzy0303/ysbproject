package com.uns.web.form;


public class TerminalForm {
	
	private String bactchNoq;
	private String termNoq;
	private String terminal_type_noq;
	private String inventory_statusq;
	private String shopperid_p;
	private String belongsAgent;
	
	private String merchantNoq;
	private String nameq;
	private String stelq;
	private String createdStart;
	private String createdEnd;
	private String statusq;
	private String user_statusq;
	private String termNoqStart;
	private String termNoqEnd;
	
		
	public String getTermNoq() {
		return termNoq;
	}
	public void setTermNoq(String termNoq) {
		this.termNoq = termNoq;
	}
	public String getTermNoqStart() {
		return termNoqStart;
	}
	public void setTermNoqStart(String termNoqStart) {
		this.termNoqStart = termNoqStart;
	}
	public String getTermNoqEnd() {
		return termNoqEnd;
	}
	public void setTermNoqEnd(String termNoqEnd) {
		this.termNoqEnd = termNoqEnd;
	}
	public String getBelongsAgent() {
		return belongsAgent;
	}
	public void setBelongsAgent(String belongsAgent) {
		this.belongsAgent = belongsAgent;
	}
	public String getUser_statusq() {
		return user_statusq;
	}
	public void setUser_statusq(String user_statusq) {
		this.user_statusq = user_statusq==null?"":user_statusq.trim();
	}
	public String getMerchantNoq() {
		return merchantNoq;
	}
	public void setMerchantNoq(String merchantNoq) {
		this.merchantNoq = merchantNoq==null?"":merchantNoq.trim();
	}
	public String getNameq() {
		return nameq;
	}
	public void setNameq(String nameq) {
		this.nameq = nameq==null?"":nameq.trim();
	}
	public String getStelq() {
		return stelq;
	}
	public void setStelq(String stelq) {
		this.stelq = stelq==null?"":stelq.trim();
	}
	public String getCreatedStart() {
		return createdStart;
	}
	public void setCreatedStart(String createdStart) {
		this.createdStart = createdStart==null?"":createdStart.trim();
	}
	public String getCreatedEnd() {
		return createdEnd;
	}
	public void setCreatedEnd(String createdEnd) {
		this.createdEnd = createdEnd==null?"":createdEnd.trim();
	}
	public String getStatusq() {
		return statusq;
	}
	public void setStatusq(String statusq) {
		this.statusq = statusq==null?"":statusq.trim();
	}
	public String getBactchNoq() {
		return bactchNoq;
	}
	public void setBactchNoq(String bactchNoq) {
		this.bactchNoq = bactchNoq==null?"":bactchNoq.trim();
	}
	public String getTerminal_type_noq() {
		return terminal_type_noq;
	}
	public void setTerminal_type_noq(String terminal_type_noq) {
		this.terminal_type_noq = terminal_type_noq==null?"":terminal_type_noq.trim();
	}
	public String getInventory_statusq() {
		return inventory_statusq;
	}
	public void setInventory_statusq(String inventory_statusq) {
		this.inventory_statusq = inventory_statusq==null?"":inventory_statusq.trim();
	}
	public String getShopperid_p() {
		return shopperid_p;
	}
	public void setShopperid_p(String shopperid_p) {
		this.shopperid_p = shopperid_p==null?"":shopperid_p.trim();
	}

}
