package com.uns.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.model.Agent;
import com.uns.model.Area;
import com.uns.model.Operator;
import com.uns.model.Users;
import com.uns.service.AgentService;
import com.uns.service.ShopPerbiService;
import com.uns.util.HttpClientUtils;
import com.uns.util.Md5Encrypt;
import com.uns.util.StringUtils;
import com.uns.web.form.AgentForm;

import net.sf.json.JSONObject;

@Controller
@RequestMapping(value = "/agentmgr.htm")
public class AgentmgrController extends BaseController {
	@Autowired
	private AgentService agentservice;

	@Autowired
	private ShopPerbiService shopPerbiService;

	@RequestMapping(params = "method=toAddAgent")
	@FormToken(save = true)
	public String toAddAgent(HttpServletRequest request, ModelMap modelMap)
			throws Exception {
		try {
			List<Area> Provincial = shopPerbiService.searchProvince();
			request.setAttribute("Provincial", Provincial);
			// 获取市
			List<Area> list = shopPerbiService.searchArea();
			request.setAttribute("area", list);
			

		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.商户注册获取列表失败);
		}
		return "agent/toaddagent";
	}
	
	@RequestMapping(params = "method=ajaxAgentIfLast")
	public @ResponseBody String ajaxAgentIfLast(String shopperidP) throws Exception{
		if(shopperidP != null && !"".equals(shopperidP)){
			Agent cAgent = shopPerbiService.searchAgent(Long.valueOf(shopperidP));
			if(cAgent != null && "1".equals(cAgent.getIflast())){
				return "1";
			}
		}
		return "";
	}
	
	@RequestMapping(params = "method=saveagent")
	@FormToken(remove = true)
	public String saveagent(HttpServletRequest request, ModelMap modelMap,
			Agent agent, Users users, @ModelAttribute("mb") AgentForm mbForm)
			throws Exception {
		//判断上级代理商是否为最末级代理商
		if(mbForm.getShopperid_p() != null && !"".equals(mbForm.getShopperid_p())){
			Agent cAgent = shopPerbiService.searchAgent(Long.valueOf(mbForm.getShopperid_p()));
			if(cAgent != null && "1".equals(cAgent.getIflast())){
				request.setAttribute(Constants.MESSAGE_KEY, "选择的上级代理商为最末级代理商，不做作为上级代理商，添加失败!");
				request.setAttribute("url", "agentmgr.htm?method=toAddAgent");
				return "/returnPage";
			}
		}
		
		try {
			if(mbForm.getShopperid_p()!=null){
			if(mbForm.getShopperid_p().toString().isEmpty()){
			
			}else{
				//如果代理商不是为空将代理商放入代理商bean对象
				agent.setShopperidP(Long.parseLong(mbForm.getShopperid_p()));
			}
			}//生成商户编码
			String shopperid = getPosShopperId(agent.getCity(),Constants.CON_MCC);
			agent.setShopperid(Long.parseLong(shopperid));
			agent.setCreated(new Date());
			agent.setBattalion(Long.parseLong("0"));//集团用户标志
			agent.setIfattend(new Short("0"));//是否参加活动
			agent.setIfagent(Long.parseLong("1"));//是否是代理商1是0不是
			Operator sessionUser = (Operator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			String transactid = agent.getTransactid().toString();//代理商状态
			if (Constants.STATUS0.equals(transactid)) {
				agent.setTransactsub("未开通");
			} else if (Constants.STATUS1.equals(transactid)) {
				agent.setTransactsub("已开通");
			} else if (Constants.STATUS2.equals(transactid)) {
				agent.setTransactsub("已冻结");
			}
			Map<String, Object> param = new HashMap<String, Object>();
			//商户id及费率信息
			param.put("createDate", new Date());
			param.put("updateUser", sessionUser.getUserName());
			param.put("shopperid", agent.getShopperid());
			param.put("updateScompany", sessionUser.getUserName());
			
			
			param.put("skDebitFee", agent.getSkT1Fee());//借记卡充值
			param.put("skCreditFee", agent.getSkT1Fee());//贷记卡充值
			param.put("d0Fee", agent.getSkSecondFee());//d0
			param.put("smWechatT1Fee", agent.getSmWechatT1Fee());
			param.put("smWechatD0Fee", agent.getSmWechatD0Fee());
			param.put("smAlipayT1Fee", agent.getSmAlipayT1Fee());
			param.put("smAlipayD0Fee", agent.getSmAlipayD0Fee());
			param.put("smYlzfT1Fee", agent.getSmYlzfT1Fee());
			param.put("smYlzfD0Fee", agent.getSmYlzfD0Fee());
			param.put("skSecondFee", agent.getSkSecondFee());
			param.put("skImmediateFee", agent.getSkImmediateFee());
			param.put("skT1Fee", agent.getSkT1Fee());
			param.put("smShortCutT1Fee", agent.getSmShortCutT1Fee());
			param.put("smShortCutD0Fee", agent.getSmShortCutD0Fee());
			//速惠收款费率
			param.put("smShortCutSHD0Fee", agent.getSmShortCutSHD0Fee());
			param.put("smB2cT1Fee", agent.getSmB2cT1Fee());
			param.put("smB2cD0Fee", agent.getSmB2cD0Fee());

			//商户版扫码费率
			param.put("merchantWxT1Fee", agent.getMerchantWxT1Fee());
			param.put("merchantZfbT1Fee", agent.getMerchantZfbT1Fee());

			agent.setSkDebitFee(agent.getSkT1Fee());//给T1收款费率不知道干嘛用
			agent.setSkCreditFee(agent.getSkT1Fee());
			agent.setD0Fee(agent.getSkSecondFee());
			//保证城市和省城的正确性
			if (agent.getProvince() != null) {
				List searchProvincialList = shopPerbiService.searchProvincial(agent.getProvince());
				if (searchProvincialList != null&& searchProvincialList.size() > 0) {
					Area spro = (Area) searchProvincialList.get(0);
					if (spro != null) {
						String sprov = spro.getProvincialname();
						agent.setSprovince(sprov);
					}
				}
			}
			if (agent.getCity() != null) {
				List cityList = shopPerbiService.searchCity(agent.getCity());
				if (cityList != null && cityList.size() > 0) {
					Area area = (Area) cityList.get(0);
					if (area != null) {
						String cityName = (String) area.getCityname();
						agent.setScity(cityName);
					}
				}
			}
			
			// 在users表中插入密码用户名等数据
			Users user = newuser(request, shopperid);
			// 调用接口
			String rspCode=requestlimitAdd(shopperid, agent);
			if (Constants.RESPONSE_CODE.equals(rspCode)) {
				//本地数据库添加
				agentservice.addagent(user,agent,param);
				request.setAttribute(Constants.MESSAGE_KEY, "注册成功!");
				request.setAttribute("url", "agentmgr.htm?method=toAddAgent");
			} else {
				request.setAttribute(Constants.MESSAGE_KEY, "注册失败!");
				request.setAttribute("url", "agentmgr.htm?method=toAddAgent");
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.代理商注册失败);
		}
		return "/returnPage";

	}

	/**
	 * 生成编码
	 * 
	 * @param area
	 * @param mcc
	 * @return
	 * @throws Exception
	 */
	public String getPosShopperId(String area, String mcc) throws Exception {
		String organization = "800";
		String areacold = "";
		if (area.length() > 4) {
			areacold = area.substring(0, 4);
		} else {
			areacold = area;
		}
		String mcccold = "";
		if (mcc.length() == 1) {
			mcccold = "000" + mcc;
		} else {
			mcccold = "00" + mcc;
		}
		String merchantRadom = RandomStringUtils.randomNumeric(4);
		String posMerchantId = organization + areacold + mcccold+ merchantRadom;
		Agent b2cShopperbi = agentservice.searchAgentByShopperId(posMerchantId);
		if (b2cShopperbi != null) {
			return getPosShopperId(area, mcc);
		}
		return posMerchantId;
	}

	/**
	 * 是否有重复的电话号码存在
	 * 
	 * @param request
	 * @param response
	 * @throws
	 * @throws IOException
	 */
	@RequestMapping(params = "method=ajaxCheckTel")
	public void ajaxCheckTel(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		try {
			String stel = request.getParameter("stel");

			Agent list = null;
			if (StringUtils.isTrimNotEmpty(stel)) {
				stel = stel.trim();

				list = agentservice.findbytel(stel);
			}
			PrintWriter out = response.getWriter();
			try {
				if ((list != null)) {
					out.write("{\"x\":\"1\"}");
				} else {
					out.write("{\"x\":\"2\"}");
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (out != null) {
					out.flush();
					out.close();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * 是否有重复的代理商企业名称是否存在
	 * 
	 * @param request
	 * @param response
	 * @throws
	 * @throws IOException
	 */
	@RequestMapping(params = "method=ajaxCheckScompany")
	public void ajaxCheckScompany(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		try {
			String scompany = request.getParameter("scompany");

			Agent list = null;
			if (StringUtils.isTrimNotEmpty(scompany)) {
				scompany = scompany.trim();
				list = agentservice.searchAgentByName(scompany);
			}
			PrintWriter out = response.getWriter();
			try {
				if ((list != null)) {
					out.write("{\"x\":\"1\"}");
				} else {
					out.write("{\"x\":\"2\"}");
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (out != null) {
					out.flush();
					out.close();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * 商户查询
	 * 
	 * @param request
	 * @param b2cShopperbiTmp
	 * @param b2cShopperbargainTmp
	 * @param modelMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=selectAgentList")
	public String selectAgentList(HttpServletRequest request, AgentForm mbForm) throws Exception {
		try {

			List<Agent> agentlist = null;
			// 判断商户编号是否为数字
			String shopperIdq = mbForm.getAgentid();
			if (!StringUtils.isEmpty(shopperIdq)) {
				boolean b = shopperIdq.matches("^[-+]?(([0-9]+)([.]([0-9]+))?|([.]([0-9]+))?)$");
				if (!b) {
					mbForm.setAgentid("");
				}
			}
			if (mbForm.getSprovince() != null) {
				List searchProvincialList = shopPerbiService.searchProvincial(mbForm.getSprovince());
				if (searchProvincialList != null&& searchProvincialList.size() > 0) {
					Area spro = (Area) searchProvincialList.get(0);
					if (spro != null) {
						String sprov = spro.getProvincialname();
						mbForm.setSprovince(sprov);
					}
				}
			}
			if (mbForm.getCity() != null) {
				List cityList = shopPerbiService.searchCity(mbForm.getCity());
				if (cityList != null && cityList.size() > 0) {
					Area area = (Area) cityList.get(0);
					if (area != null) {
						String cityName = (String) area.getCityname();
						mbForm.setCity(cityName);
					}
				}
			}
			
		    String  checkAgent=request.getParameter("checkAgent");
			if(StringUtils.isEmpty(checkAgent)){
				mbForm.setCheckAgents(false);
			}else{
				if(checkAgent.equals("true")){
					mbForm.setCheckAgents(true);
				}else{
					mbForm.setCheckAgents(false);
				}
			}

			agentlist = agentservice.selectAgentList(mbForm);
			request.setAttribute("agentlist", agentlist);
			// 获取省
			List<Area> Provincial = shopPerbiService.searchProvince();
			request.setAttribute("Provincial", Provincial);
			// 获取市
			List<Area> list = shopPerbiService.searchArea();
			request.setAttribute("area", list);
			request.setAttribute("belongsAgent", mbForm.getBelongsAgent());
			
		} catch (BusinessException e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.代理商查询失败);
		}
		return "agent/selectagent";
	}

	/**
	 * 查看代理商详情
	 * 
	 * @param request
	 * @param agent
	 * @param modelMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=queryAgentDetails")
	@FormToken(save = true)
	public String queryAgentDetails(HttpServletRequest request,
			ModelMap modelMap, Agent agent,
			@ModelAttribute("mb") AgentForm mbForm) throws Exception {
		try {
			String shopperid = request.getParameter("shopperid");
			if (StringUtils.isEmpty(shopperid)) {
				request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
				mbForm.setBelongsAgent(null);
				request.setAttribute("url", "agentmgr.htm?method=selectAgentList");
			} else {
				Agent agent1 = agentservice.searchAgentByShopperId(shopperid);
				request.setAttribute("agent1", agent1);
			}
			Users users = shopPerbiService.selectByUsersmerchantid(shopperid);
			request.setAttribute("users", users);
			// 获取省
			List<Area> Provincial = shopPerbiService.searchProvince();
			request.setAttribute("Provincial", Provincial);
			// 获取市
			List<Area> list = shopPerbiService.searchArea();
			request.setAttribute("area", list);
			

		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取代理商信息失败);
		}

		return "agent/selectOneAgent";
	}

	/**
	 * 修改代理商信息变更
	 * 
	 * @param request
	 * @param agent
	 * @param modelMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=queryAgentupdate")
	@FormToken(save = true)
	public String queryAgentupdate(HttpServletRequest request,
			ModelMap modelMap, Agent agent,
			@ModelAttribute("mb") AgentForm mbForm) throws Exception {
		try {
			String shopperid = request.getParameter("shopperid");
			if (StringUtils.isEmpty(shopperid)) {
				request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
				mbForm.setBelongsAgent(null);
				request.setAttribute("url", "agentmgr.htm?method=selectAgentList");
			} else {
				agent = this.agentservice.searchAgentByShopperId(shopperid);
			}
			Users users = shopPerbiService.selectByUsersmerchantid(shopperid);
			request.setAttribute("users", users);
			// 获取省
			List<Area> Provincial = shopPerbiService.searchProvince();
			request.setAttribute("Provincial", Provincial);
			// 获取市
			List<Area> list = shopPerbiService.searchArea();
			request.setAttribute("area", list);
			   //代理商
	        String path = request.getSession().getServletContext().getContextPath();
	        request.setAttribute("agentlist",path+"agent/selectAgentTree.htm");
	        if(agent!=null){
	        	//获取代理商
	            Long shopperId= agent.getShopperidP();
	            if(shopperId!=null){
	            	Agent agent1=shopPerbiService.searchAgent(shopperId);
	                modelMap.put("agentName", agent1.getScompany());
	                modelMap.put("agentId", agent1.getShopperid());
	            }
	        }
			modelMap.put("agent", agent);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.获取代理商信息失败);
		}

		return "agent/updateagent";
	}

	/**
	 * 保存代理商修改后的信息
	 * 
	 * @param request
	 * @param response
	 * @param modelMap
	 * @param mbForm
	 * @return
	 * @throws IOException
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=saveAgentUpdate")
	@FormToken(remove = true)
	public String saveAgentUpdate(HttpServletRequest request,
			HttpServletResponse response, ModelMap modelMap, Agent agent,
			@ModelAttribute("mb") AgentForm mbForm) throws Exception,
			BusinessException {
		Operator sessionUser = (Operator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
		//判断上级代理商是否为最末级代理商
		if(mbForm.getShopperid_p() != null && !"".equals(mbForm.getShopperid_p())){
			Agent cAgent = shopPerbiService.searchAgent(Long.valueOf(mbForm.getShopperid_p()));
			if(cAgent != null && "1".equals(cAgent.getIflast())){
				request.setAttribute(Constants.MESSAGE_KEY, "选择的上级代理商为最末级代理商，不做作为上级代理商，添加失败!");
				request.setAttribute("url", "agentmgr.htm?method=toAddAgent");
				return "/returnPage";
			}
		}
		try {
			String rspCode = "";
			String shopperid = request.getParameter("shopperid");
			String password = request.getParameter("agentpassword").trim();
			String stel = request.getParameter("stel").trim();
			String telc = request.getParameter("tel").trim();
			//Limit当日提现限额100
			String limit = request.getParameter("limit") == null ? "100" : request.getParameter("limit");
			if (StringUtils.isEmpty(shopperid)) {
				request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
				mbForm.setBelongsAgent(null);
				request.setAttribute("url","agentmgr.htm?method=selectAgentList");
			} else {
				if (agent.getProvince() != null) {
					List searchProvincialList = shopPerbiService.searchProvincial(agent.getProvince());
					if (searchProvincialList != null
							&& searchProvincialList.size() > 0) {
						Area spro = (Area) searchProvincialList.get(0);
						if (spro != null) {
							String sprov = spro.getProvincialname();
							agent.setSprovince(sprov);
						}
					}
				}
				if (agent.getCity() != null) {
					List cityList = shopPerbiService.searchCity(agent.getCity());
					if (cityList != null && cityList.size() > 0) {
						Area area = (Area) cityList.get(0);
						if (area != null) {
							String cityName = (String) area.getCityname();
							agent.setScity(cityName);
						}
					}
				}
                Agent agent1=agentservice.searchAgentByShopperId(shopperid);//根据商户编号查询Agent

				Users users = shopPerbiService.selectByUsersmerchantid(shopperid);//user
				if (org.apache.commons.lang.StringUtils.isNotEmpty(password)) {
					String Md5pwd = Md5Encrypt.md5(password);
					users.setPassword(Md5pwd);
				}
				users.setUserName(stel);
				if(StringUtils.isEmpty(mbForm.getShopperid_p())){
					
				}else{
					if(mbForm.getShopperid_p().equals(agent1.getShopperid()+"")){
						throw new BusinessException(ExceptionDefine.代理商信息修改失败);
					}else{
						agent.setShopperidP(Long.parseLong(mbForm.getShopperid_p()));
					}
					
				}
             
					agent.setLimit(Double.valueOf(limit));
					//调用接口
					rspCode = requestlimitEdit(agent.getShopperid().toString(),	agent);
					if (Constants.UPADTELIMIT_CODE.equals(rspCode)) {

						agent.setStel(stel);
						users.setTel(stel);
						agentservice.updateuseragent(users, agent,sessionUser.getUserName());
						request.setAttribute(Constants.MESSAGE_KEY, "修改成功!");
					}else{
						request.setAttribute(Constants.MESSAGE_KEY, "修改失败!");
					}
			}
			request.setAttribute("url", "agentmgr.htm?method=selectAgentList");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.代理商信息修改失败);
		}
		return "/returnPage";
	}

	public Users newuser(HttpServletRequest request, String shopperid) {

		String mpassword = request.getParameter("agentpassword");
		String Md5pwd = Md5Encrypt.md5(mpassword);
		String tel = request.getParameter("stel");
		Users user = new Users();
		user.setIsAgent("1");
		user.setMerchantid(Long.parseLong(shopperid));
		user.setUserName(tel);
		user.setPassword(Md5pwd);
		user.setEnabled(new Short("1"));
		user.setTel(tel);
		user.setCreatedate(new Date());
		return user;
	}
	/**
	 * 处理接口参数
	 * @param agent
	 * @param type
	 * @return
	 */
	public List  disposeParam(Agent agent,String type){
		
		   List list=new ArrayList();
		   Map debitMap=new HashMap();
		   debitMap.put("d0Fee", agent.getSkImmediateFee());
		   debitMap.put("feeType", Constants.STATUS0);
		   debitMap.put("t1Fee", agent.getSkT1Fee());
		   debitMap.put("skSecondFee",  agent.getSkSecondFee());//秒到收款
		   debitMap.put("skImmediateFee", agent.getSkImmediateFee());//即时收款
		   debitMap.put("skT1Fee", agent.getSkT1Fee());//T1收款
		   list.add(debitMap);
		   
		   Map creditMap=new HashMap();
		   creditMap.put("d0Fee", agent.getSkImmediateFee());
		   creditMap.put("feeType", Constants.STATUS1);
		   creditMap.put("t1Fee", agent.getSkT1Fee());
		   creditMap.put("skSecondFee",  agent.getSkSecondFee());//秒到收款
		   creditMap.put("skImmediateFee", agent.getSkImmediateFee());  //即时收款
		   creditMap.put("skT1Fee", agent.getSkT1Fee());//T1收款
		   list.add(creditMap);
		 
		   if(Constants.SM.equals(type)) {
			   //微信
			   Map wechatMap=new HashMap();
			   wechatMap.put("d0Fee", agent.getSmWechatD0Fee());
			   wechatMap.put("feeType", Constants.STATUS2);
			   wechatMap.put("t1Fee", agent.getSmWechatT1Fee());
			   list.add(wechatMap);
			   //支付宝
			   Map alipayMap=new HashMap();
			   alipayMap.put("d0Fee", agent.getSmAlipayD0Fee());
			   alipayMap.put("feeType", Constants.STATUS3);
			   alipayMap.put("t1Fee", agent.getSmAlipayT1Fee());
			   list.add(alipayMap);
				//银联参数
		    	Map unionpayMap = new HashMap();
		    	unionpayMap.put("feeType", Constants.STATUS4);
		    	unionpayMap.put("d0Fee", agent.getSmYlzfD0Fee());
		    	unionpayMap.put("t1Fee", agent.getSmYlzfT1Fee());
		    	list.add(unionpayMap);	
		    	//快捷费率
		    	Map shortCutMap = new HashMap();
		    	shortCutMap.put("feeType", Constants.STATUS5);
		    	shortCutMap.put("t1Fee", agent.getSmShortCutT1Fee());
		    	shortCutMap.put("d0Fee",agent.getSmShortCutD0Fee());
		    	list.add(shortCutMap);
		    	//B2C费率
		    	Map b2cMap = new HashMap();
		    	b2cMap.put("feeType", Constants.STATUS6);
		    	b2cMap.put("t1Fee", agent.getSmB2cT1Fee());
		    	b2cMap.put("d0Fee",agent.getSmB2cD0Fee());
		    	list.add(b2cMap);
		    	//快捷速惠费率
		    	Map shortCutSHMap = new HashMap();
		    	shortCutSHMap.put("feeType", Constants.STATUS7);
		    	shortCutSHMap.put("d0Fee", agent.getSmShortCutSHD0Fee());
		    	shortCutSHMap.put("t1Fee", "0");
		    	list.add(shortCutSHMap);

		    	//商户版微信T1费率
		    	Map merchantWxT1Map = new HashMap();
			    merchantWxT1Map.put("feeType", Constants.FEE_TYPE_SWXT1);
			    merchantWxT1Map.put("t1Fee",agent.getMerchantWxT1Fee());
			    merchantWxT1Map.put("d0Fee","0");
			    list.add(merchantWxT1Map);
				//商户版支付宝T1费率
			    Map merchantZfbT1Map = new HashMap();
			    merchantZfbT1Map.put("feeType", Constants.FEE_TYPE_SZFBT1);
			    merchantZfbT1Map.put("t1Fee",agent.getMerchantZfbT1Fee());
			    merchantZfbT1Map.put("d0Fee","0");
			    list.add(merchantZfbT1Map);

		   }
		   
		return list;
	}
	
	/**
	 * 添加代理商,不携带登入密码之类
	 * @param shopperid
	 * @param agent
	 * @return
	 */
	public String requestlimitAdd(String shopperid,Agent agent){
		   String rspCode="";
		   String rspMsg="";
		   String phone = agent.getStel();//代理商电话号
		   Long srcid_p=agent.getShopperidP();//上级代理商编号
		   String scompany = agent.getScompany();//代理商名称
		   
		    Map parmsMap=new HashMap();
			parmsMap.put("orgId", shopperid);
			parmsMap.put("orgType", Constants.ORGTYPE);//'1'
			parmsMap.put("limit", agent.getLimit());
			//parmsMap.put("orgaExts", list);
			parmsMap.put("orgaExts", disposeParam(agent, Constants.Sk));//费率
			parmsMap.put("phone", phone);
			parmsMap.put("srcid_p", srcid_p);
			parmsMap.put("scompany", scompany);
		try {
			//mpos注册接口
			String mposAgentCode=regMposAgent(parmsMap,Constants.ADD);
			
		    if(!Constants.RESPONSE_CODE.equals(mposAgentCode)){
		    	rspCode=Constants.TYPE_0;
		    }else{
		    	parmsMap.put("orgaExts", disposeParam(agent, Constants.SM));//扫码
		    	//调用扫码注册接口
		    	String qrAgentCode=regQrAgent(parmsMap,Constants.ADD);
				if(!Constants.RESPONSE_CODE.equals(qrAgentCode)){
					rspCode=Constants.TYPE_0;
				}else {
					rspCode=Constants.RESPONSE_CODE;
				}
				
		    }
		   
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rspCode;
		
	}
	
	public String requestlimitEdit(String shopperid,Agent agent){
		   String rspCode="";
		   String rspMsg="";
		   String phone = agent.getStel();//代理商电话号
		   Long srcid_p=agent.getShopperidP();//上级代理商编号
		   String scompany = agent.getScompany();//代理商名称
		   
		    Map parmsMap=new HashMap();
			parmsMap.put("orgId", shopperid);
			parmsMap.put("orgType", Constants.ORGTYPE);
			parmsMap.put("limit", agent.getLimit());
			parmsMap.put("orgaExts", disposeParam(agent, Constants.Sk));
			parmsMap.put("phone", phone);
			parmsMap.put("srcid_p", srcid_p);
			parmsMap.put("scompany", scompany);
		try {
			//mpos注册接口
			String mposAgentCode=regMposAgent(parmsMap,Constants.EDIT);
			parmsMap.put("orgaExts",  disposeParam(agent, Constants.SM));
	    	
	    	//调用扫码注册接口
			String qrAgentCode=regQrAgent(parmsMap,Constants.EDIT);
			if(Constants.UPADTELIMIT_CODE.equals(qrAgentCode)&&Constants.RESPONSE_CODE.equals(mposAgentCode)){
				rspCode=Constants.UPADTELIMIT_CODE;
			}else {
				rspCode=Constants.TYPE_0;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return rspCode;
		
	}

	/**
	 * qrcode注册/修改 扫码代理商
	 * @param parmsMap
	 * @return
	 */
	private String regQrAgent(Map parmsMap,String logType ) throws BusinessException {
		JSONObject obs = JSONObject.fromObject(parmsMap);
		String rspCode ="";
		if(logType.equals(Constants.ADD)) {
			//扫码支付 添加代理商
			log.info("扫码支付 添加代理商参数：" + DynamicConfigLoader.getByEnv("qrpay_addlimit.url")+ obs.toString());
			String result = HttpClientUtils.REpostRequestStr(DynamicConfigLoader.getByEnv("qrpay_addlimit.url"), obs.toString());
			JSONObject ob2 = JSONObject.fromObject(result);
		    rspCode = (String) ob2.get("rspCode");
		    log.info("扫码支付 添加代理商返回码：" + result);
		}else{
			log.info("扫码支付 修改代理商参数：" + DynamicConfigLoader.getByEnv("qrpay_addlimit.url")+ obs.toString());
			String result = HttpClientUtils.REpostRequestStr(DynamicConfigLoader.getByEnv("qrpay_addlimit.url"), obs.toString());
			JSONObject ob2 = JSONObject.fromObject(result);
		    rspCode = (String) ob2.get("rspCode");
		    log.info("扫码支付 修改代理商返回码：" + result);
		}
		return rspCode;
		
	}

	/**mpos注册/修改代理商
	 * @param shopperid
	 * @param limit
	 * @return
	 * @throws Exception 
	 */
	private String regMposAgent(Map parmsMap,String logType) throws Exception {
		String result="";
		JSONObject obs = JSONObject.fromObject(parmsMap);
		String rspCode ="";
		if(logType.equals(Constants.ADD)) {
			log.info("MPOS添加代理商接口参数：" + DynamicConfigLoader.getByEnv("addlimit.url")+ obs.toString());
			result = HttpClientUtils.REpostRequestStr(DynamicConfigLoader.getByEnv("addlimit.url"), obs.toString());
			JSONObject ob = JSONObject.fromObject(result);
			rspCode = (String) ob.get("rspCode");
			log.info("MPOS添加代理商返回码：" + result);
		}else{
			log.info("MPOS修改代理商接口参数：" + DynamicConfigLoader.getByEnv("addlimit.url")+ obs.toString());
			result = HttpClientUtils.REpostRequestStr(DynamicConfigLoader.getByEnv("addlimit.url"), obs.toString());
			JSONObject ob = JSONObject.fromObject(result);
			rspCode = (String) ob.get("rspCode");
			log.info("MPOS修改代理商返回码：" + result);
		}
		return rspCode;
	}

	/**
	 * 查询费率修改记录日志
	 */
	@RequestMapping(params = "method=selectLogList")
	public String selectLogList(HttpServletRequest request,String shopperid){
		List<Map<String,Object>> list = agentservice.selectUpdateAgentfeeAlogList(shopperid);
		request.setAttribute("list", list);
		return "agent/updateAgentFeeLogList";
	}
	
}
