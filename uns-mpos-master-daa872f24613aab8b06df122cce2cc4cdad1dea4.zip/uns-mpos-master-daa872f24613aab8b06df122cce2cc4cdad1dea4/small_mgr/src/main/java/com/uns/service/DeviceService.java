package com.uns.service;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.common.page.PageContext;
import com.uns.dao.B2cShopperbiMapper;
import com.uns.dao.B2cTempTermBinderMapper;
import com.uns.dao.B2cTermBinderMapper;
import com.uns.dao.MposMerchantFeeMapper;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.model.B2cShopperbi;
import com.uns.model.B2cTempTermBinder;
import com.uns.model.B2cTermBinder;
import com.uns.web.form.ShopPerbiForm;

import net.sf.json.JSONObject;

@Service
public class DeviceService {
	@Autowired
	private B2cTempTermBinderMapper temptermMapper;
	
	@Autowired
	private B2cTermBinderMapper termMapper;
	
	@Autowired
	private MposMerchantFeeMapper mposMerchantFeeMapper;
	
	@Autowired
	private B2cShopperbiMapper b2cShopperbiMapper;
	
	public List<HashMap> showdeviceList(ShopPerbiForm mbForm) {
		PageContext.initPageSize(20);
		return temptermMapper.showdeviceList(mbForm);
	
	}
	
	
	public List<HashMap> showdeviceListexport(ShopPerbiForm mbForm) {
		PageContext.initPageSize(Constants.EXCEL_SIZE);
		return temptermMapper.showdeviceList(mbForm);
	
	}
	
	/**
	 * 查询商户信息未审核的个数
	 * @return
	 */
	public String selectfirstCount(){
		String ckCount = temptermMapper.selectfirstCount();
		return ckCount!=null&&!"".equals(ckCount)?ckCount:"0";
	}
	
	/**
	 * 查询商户信息未审核的个数
	 * @return
	 */
	public String selectlastsCount(){
		String ckCount = temptermMapper.selectlastCount();
		return ckCount!=null&&!"".equals(ckCount)?ckCount:"0";
	}
	
	
	public B2cTempTermBinder selectterm(String termNo){
		return temptermMapper.selectbyterm(termNo);
	}

	public void updateterm(B2cTempTermBinder term) throws Exception{
		temptermMapper.updateterm(term);
	}
	
	public String updateorinsertterm(B2cTempTermBinder term,B2cTermBinder newterm,String lastVerift,HttpServletRequest request) throws Exception{
		String message="";
		Map returnMap=saveAcquiring(term);
		String returnCode=returnMap.get("returnCode")==null?"":returnMap.get("returnCode").toString();
		String returnMesg=returnMap.get("reason")==null?"":returnMap.get("reason").toString();
		if(Constants.RESPONSE_CODE.equals(returnCode)){
			message="注册收单成功";
			temptermMapper.updateterm(term);
			termMapper.insertSelective(newterm);
			term.setStatus("1");
			term.setLastVerify(lastVerift);
		}else{
			message="注册收单失败;失败原因"+returnMesg;
			term.setRemark(returnMesg);
		}
		temptermMapper.updateterm(term);
		return message;
	}
	
	/**绑定终端
	 * @param b2cShopperbi
	 * @return
	 * @throws Exception 
	 */
	private Map saveAcquiring(B2cTempTermBinder term) throws Exception {
		Map regMap=new HashMap();
		B2cShopperbi b2cShopperbi=b2cShopperbiMapper.selectFormalshoppId(term.getMerchantNo());
		regMap.put("deviceNumber", term.getTermNo());
		regMap.put("scompay", URLEncoder.encode(b2cShopperbi.getScompany(), "GBK"));
		regMap.put("youngMerchant",term.getMerchantNo());
		regMap.put("ysbNo", b2cShopperbi.getYsbNo());
		regMap.put("merchantType", Constants.TYPE_2);//机构为1
		//
		List list=mposMerchantFeeMapper.findMposMerchantFee(term.getMerchantNo());
		regMap.put("fee", list);
		String deviceNo="";
		B2cTermBinder  b2cTermBinder=getDiveceNo(term.getMerchantNo());
		if(b2cTermBinder!=null){
			deviceNo=b2cTermBinder.getTermNo();
		}
		regMap.put("deviceNo", deviceNo);
		
		JSONObject obs = JSONObject.fromObject(regMap);
		String url=DynamicConfigLoader.getByEnv("reg_shoudan_url")+obs.toString()+"";
		org.apache.http.client.HttpClient httpclient=new DefaultHttpClient();
		url=url.replace("\"", "%22");
		url=url.replace("{", "%7B");
		url=url.replace("}", "%7D");
		HttpPost httpget=new HttpPost(url);
		
		HttpResponse httprespone;
		
		httprespone = httpclient.execute(httpget);
		
		String str = EntityUtils.toString(httprespone.getEntity());
		Map map1 = com.uns.util.JsonUtil.jsonStrToMap(str);
		return map1;
	}
	/**
	 * @param merchantNo
	 * @return
	 */
	public B2cTermBinder getDiveceNo(String merchantNo) {
		List list=termMapper.findDiveceNo(merchantNo);
		B2cTermBinder b2cTermBinder=null;
		if(list!=null&&list.size()>0){
			b2cTermBinder=(B2cTermBinder)list.get(0);
		}
		return b2cTermBinder;
	}
	
	
	public List finddevicePageList(ShopPerbiForm mbForm) {
		PageContext.initPageSize(Constants.EXCEL_SIZE);
		List list =temptermMapper.showdeviceList(mbForm);
		if(list!=null && list.size()!=0)
		{
			return list;
		}
		return new ArrayList();
		
	}
	
	
	public void deldevice(String termNo){
		temptermMapper.deleteByTermno(termNo);
		termMapper.deleteByTermno(termNo);
	}
	
	public void deltemp(String terNo){
		temptermMapper.deleteByTermno(terNo);
	}
	
}
