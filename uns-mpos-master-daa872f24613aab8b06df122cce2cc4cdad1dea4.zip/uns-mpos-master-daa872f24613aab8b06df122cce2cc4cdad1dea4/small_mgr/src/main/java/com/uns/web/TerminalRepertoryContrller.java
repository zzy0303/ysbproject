package com.uns.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.activemq.filter.function.inListFunction;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.model.B2cTermBinder;
import com.uns.model.Operator;
import com.uns.model.TerminalHistory;
import com.uns.service.AgentService;
import com.uns.service.TerminalRepertoryService;
import com.uns.util.StringUtils;
import com.uns.web.form.TerminalForm;

/**
 * 库存管理
 *
 */
@Controller("terminalRepertoryContrller")
@RequestMapping("/terminalRepertory.htm")
public class TerminalRepertoryContrller extends BaseController {

	@Autowired
	private TerminalRepertoryService terminalRepertoryService;
	
	
	
	
	/**终端入库查询
	 * @param request
	 * @param response
	 * @param mbForm
	 * @return
	 */
	@RequestMapping(params = "method=findTerminalRepertoryInList")
	@FormToken(save=true)
	public String findTerminalRepertoryInList(HttpServletRequest request,HttpServletResponse response,TerminalForm mbForm) {
		List terminalRepertoryInList=terminalRepertoryService.findTerminalRepertoryInList(mbForm);
		request.setAttribute("terminalRepertoryInList", terminalRepertoryInList);
		request.setAttribute("belongsAgent", mbForm.getBelongsAgent());
		return "terminal/terminalRepertoryInList";
	}
	
	
	/**终端入库
	 * @param request
	 * @param response
	 * @param mbForm
	 * @return
	 */
	@RequestMapping(params = "method=terminalRepertoryIn")
	@FormToken(save=true)
	public String terminalRepertoryIn(HttpServletRequest request,HttpServletResponse response,TerminalForm mbForm) {
		
		return "terminal/terminalRepertoryIn";
	}
	
	/**
	 * 终端移库
	 * @param request
	 * @param response
	 * @param mbForm
	 * @return
	 */
	@RequestMapping(params = "method=terminalRepertoryMove")
	@FormToken(save=true)
	public String terminalRepertoryMove(HttpServletRequest request,HttpServletResponse response,TerminalForm mbForm) {
		
		return "terminal/terminalRepertoryMove";
	}
	
	/**
	 * 模板下载
	 * @param fileName
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/download")
	public void download(HttpServletRequest request,
			HttpServletResponse response) {

		String path = request.getContextPath();
		String basePath = request.getScheme() + "://"
				+ request.getServerName() + ":" + request.getServerPort()
				+ path + "/";
		String filePath =request.getSession().getServletContext().getRealPath("/")+
				"upload"+File.separator+"fixedCode"+File.separator+"templatae.xls" ;
    	String fileName = "";
    	
    	//从文件完整路径中提取文件名，并进行编码转换，防止不能正确显示中文名
    	try {
        	if(filePath.lastIndexOf("/") > 0) {
        		fileName = new String(filePath.substring(filePath.lastIndexOf("/")+1, filePath.length()).getBytes("GB2312"), "ISO8859_1");
        	}else if(filePath.lastIndexOf("\\") > 0) {
        		fileName = new String(filePath.substring(filePath.lastIndexOf("\\")+1, filePath.length()).getBytes("GB2312"), "ISO8859_1");
        	}
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    	//打开指定文件的流信息
    	InputStream fs = null;
    	try {
    		fs = new FileInputStream(new File(filePath));
    		
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    	//设置响应头和保存文件名 
    	response.setCharacterEncoding("ISO-8859-1");
    	response.setContentType("APPLICATION/OCTET-STREAM"); 
    	response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
    	//写出流信息
    	int b = 0;
    	try {
        	PrintWriter out = response.getWriter();
        	while((b=fs.read())!=-1) {
        		out.write(b);
        	}
        	out.flush();
        	fs.close();
        	out.close();
        	System.out.println("文件下载完毕.");
    	}catch(Exception e) {
        	e.printStackTrace();
        	System.out.println("下载文件失败!");
    	}
		
	}
	
	//终端入库
	@RequestMapping(params = "method=saveterminalRepertoryIn")
	@FormToken(remove=true)
	public String saveterminalRepertoryIn(HttpServletRequest request,HttpServletResponse response,TerminalForm mbForm) throws Exception {
		HSSFSheet sheet;
		HSSFRow row;	
		InputStream in =null;
		try {
				MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
				// 获得文件
				MultipartFile file = multipartRequest.getFile("termNosFile");
				// 获取输出流
				in = file.getInputStream();
				
				HSSFWorkbook workbook = new HSSFWorkbook(in);
				sheet = workbook.getSheetAt(0);
			} catch (Exception e) {
				e.printStackTrace();
				throw new BusinessException(ExceptionDefine.库存管理,new String[]{"文件上传失败"});
			}finally {
				in.close();
			}
		
			String batchNo=request.getParameter("batchNo");
			String terminal_type_no=request.getParameter("terminal_type_no");
			String factory_no=request.getParameter("factory_no");
			if (sheet != null) {
				terminalRepertoryService.insertBatchIn(request,batchNo,terminal_type_no,factory_no,sheet);
			
			}
		request.setAttribute("url","terminalRepertory.htm?method=findTerminalRepertoryInList");
		request.setAttribute(Constants.MESSAGE_KEY, "终端入库批次提交成功！");
		
		return "/returnPage";
	}
	
	
	/**
	 * 终端移库
	 * @param request
	 * @param response
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=saveterminalRepertoryMove")
	@FormToken(remove=true)
	public String saveterminalRepertoryMove(HttpServletRequest request,HttpServletResponse response,TerminalForm mbForm) throws Exception {
		HSSFSheet sheet;
		HSSFRow row;	
		InputStream in=null;
		try {
				MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
				// 获得文件
				MultipartFile file = multipartRequest.getFile("termNosFile");
			
				// 获取输出流
				in = file.getInputStream();
		
				HSSFWorkbook workbook = new HSSFWorkbook(in);
			
				sheet = workbook.getSheetAt(0);
			} catch (Exception e) {
				e.printStackTrace();
				throw new BusinessException(ExceptionDefine.库存管理,new String[]{"文件上传失败"});
			}finally {
				in.close();
			}
		
			if (sheet != null) {
				terminalRepertoryService.saveTerminalMove(sheet,mbForm,request);
			
			}
		request.setAttribute("url","terminalRepertory.htm?method=findTerminalRepertoryInList");
		request.setAttribute(Constants.MESSAGE_KEY, "终端移库提交成功！");
		
		return "/returnPage";
	}
	
	
	
	


	/**验证批次号是否存在
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(params="method=ajaxTermBatchNo")
	public void ajaxTermBatchNo(HttpServletRequest request,HttpServletResponse response) throws IOException{
		try {
			String ajaxTermBatchNo=request.getParameter("batchNo");
			List list=null;
			if(StringUtils.isTrimNotEmpty(ajaxTermBatchNo)){
			    list=terminalRepertoryService.findTermBatchNo(ajaxTermBatchNo.trim());
			}
			PrintWriter out=response.getWriter();
			try {
				if(list!=null&&list.size()>0){
					out.write("{\"x\":\"1\"}");
				}else{
					out.write("{\"x\":\"2\"}");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				if(out !=null){
					out.flush();
					out.close();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	/**终端出库管理
	 * @param request
	 * @param response
	 * @param mbForm
	 * @return
	 */
	@RequestMapping(params = "method=findTerminalRepertoryOutList")
	public String findTerminalRepertoryOutList(HttpServletRequest request,HttpServletResponse response,TerminalForm mbForm) {
		List terminalRepertoryOutList=terminalRepertoryService.findTerminalRepertoryOutList(mbForm);
		request.setAttribute("terminalRepertoryOutList", terminalRepertoryOutList);
		request.setAttribute("belongsAgent", mbForm.getBelongsAgent());
		return "terminal/terminalRepertoryOutList";
	}
	
	/**出库页面
	 * @param request
	 * @param response
	 * @param mbForm
	 * @return
	 */
	@RequestMapping(params = "method=terminalRepertoryOut")
	@FormToken(save=true)
	public String terminalRepertoryOut(HttpServletRequest request,HttpServletResponse response,TerminalForm mbForm) {
		
		return "terminal/terminalRepertoryOut";
	}
	
	/**出库保存
	 * @param request
	 * @param response
	 * @param mbForm
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=saveterminalRepertoryOut")
	@FormToken(remove=true)
	public String saveterminalRepertoryOut(HttpServletRequest request,HttpServletResponse response,TerminalForm mbForm) throws Exception {
		HSSFSheet sheet;
		HSSFRow row;
		InputStream in =null;
		try {
				MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
				// 获得文件
				MultipartFile file = multipartRequest.getFile("termNosFile");
			
				// 获取输出流
				in = file.getInputStream();
		
				HSSFWorkbook workbook = new HSSFWorkbook(in);
			
				sheet = workbook.getSheetAt(0);
			} catch (Exception e) {
				e.printStackTrace();
				throw new BusinessException(ExceptionDefine.库存管理,new String[]{"文件上传失败"});
			}finally {
				in.close();
			}
		
			String batchNo=request.getParameter("batchNo");
			String shopperid_p=request.getParameter("shopperid_p");
			if (sheet != null) {
				int i=terminalRepertoryService.updateBatchOut(request,batchNo,shopperid_p,sheet);
				if(i>0){
					request.setAttribute("url","terminalRepertory.htm?method=findTerminalRepertoryOutList");
					request.setAttribute(Constants.MESSAGE_KEY, "终端出库批次提交成功！");
				}else{
					request.setAttribute("url","terminalRepertory.htm?method=findTerminalRepertoryOutList");
					request.setAttribute(Constants.MESSAGE_KEY, "终端出库失败，提交无效数据！");
				}
			}
		
			
			return "/returnPage";
	}
	
}
