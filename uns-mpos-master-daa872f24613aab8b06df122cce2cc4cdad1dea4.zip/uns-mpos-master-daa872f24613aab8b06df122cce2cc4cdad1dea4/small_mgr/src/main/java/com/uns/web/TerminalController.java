package com.uns.web;


import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jxl.SheetSettings;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.model.B2cTermBinder;
import com.uns.service.TerminalService;
import com.uns.web.form.TerminalForm;

/**
 * 终端查询
 *
 */
@Controller("TerminalController")
@RequestMapping("/terminal.htm")
public class TerminalController extends BaseController{
	
	@Autowired
	private TerminalService terminalService;
	
	
	/**终端查询
	 * @param request
	 * @param response
	 * @param mbForm
	 */
	@RequestMapping(params = "method=findTerminalList")
	public String findTerminalList(HttpServletRequest request,HttpServletResponse response,TerminalForm mbForm) {
		List terminalList=terminalService.findTerminalList(mbForm);
		request.setAttribute("terminalList", terminalList);
		return "terminal/terminalList";
	}
	
	@RequestMapping(params = "method=findTermianlHistroyDetails")
	public String findTermianlHistroyDetails(HttpServletRequest request,HttpServletResponse response,TerminalForm mbForm) {
		String termNo=request.getParameter("termNo");
		if(StringUtils.isNotEmpty(termNo)){
			String  ifactivadate=terminalService.findShopperbiByNo(termNo);
			request.setAttribute("ifactivadate", ifactivadate);
			
			List termianlHistroyList= terminalService.findTermianlHistroy(termNo);
			request.setAttribute("termianlHistroyList", termianlHistroyList);
			
			
		}
		return "terminal/termianlHistroyDetails";
	}
	
	
	
	@RequestMapping(params = "method=findTerminalPage")
	public String findTerminalPage(HttpServletRequest request, HttpServletResponse response,
			TerminalForm mbForm)throws Exception {
		Page page  = new Page();
		PageContext context = PageContext.getContext();
		BeanUtils.copyProperties(context, page);
		context.setPagination(true);
		terminalService.findTerminalExcelList(mbForm);
		BeanUtils.copyProperties(page, context);
		request.setAttribute("mbForm",mbForm);
		request.setAttribute("page",page);
		return "terminal/terminalPage";
	}
	
	
	@RequestMapping(params = "method=downTerminalExcel")
	public String downTerminalExcel(HttpServletRequest request, HttpServletResponse response, TerminalForm mbForm)
			throws Exception{
			try{
				String tPage = request.getParameter("page");
				if (StringUtils.isEmpty(tPage) || !org.apache.commons.lang3.StringUtils.isNumeric(tPage)){
					tPage = "1";
				}
				int currentPage = Integer.valueOf(tPage);
				Page page  = new Page();
				PageContext context = PageContext.getContext();
				BeanUtils.copyProperties(context, page);
				context.setPagination(true);
				context.setCurrentPage(currentPage);
			    List excelList = terminalService.findTerminalExcelList(mbForm);
			// 标题
			    Map<String, String> mapField = new LinkedHashMap();
			    mapField.put("MERCHANT_NO","小商户号");              
	        	mapField.put("TERM_NO","终端序列号");          
	        	mapField.put("TERMINAL_TYPE_NO","终端型号");              
	        	mapField.put("SNAME","姓名");             
	        	mapField.put("STEL","联系方式");                
	        	mapField.put("BINDER_DATE","最新绑定时间");          
	        	mapField.put("INVENTORY_STATUS","库存状态");          
	        	mapField.put("PARENT_AGENT_NO","所属代理商");        
	        	mapField.put("STATUS","使用状态");        
	        	mapField.put("USER_STATUS"," 冻结状态");   
	        	mapField.put("IFACTIVADATE","激活时间"); 
	        	
	        	String fileName="终端信息数据导出";
	        	outExcel(excelList, response, mapField, fileName);
		} catch (Exception e) {
			log.info("导出数据有误！");
			e.printStackTrace();
		}
		return null;
	}
	
	private void outExcel(List excelList, HttpServletResponse response, Map<String, String> mapField, String fileNames) throws Exception {

		response.setContentType("application/vnd.ms-excel");
		response.setHeader("content-disposition", "attachment;filename=" + new String(fileNames.getBytes("UTF-8"), "iso8859-1") + ".xls");
		response.setCharacterEncoding("UTF-8");

		OutputStream os = response.getOutputStream();
		WritableWorkbook wwb = Workbook.createWorkbook(os);
		WritableSheet sheet = wwb.createSheet("终端数据", 0);
		SheetSettings ss = sheet.getSettings();
		ss.setVerticalFreeze(1);// 冻结表头

		WritableCellFormat wcf = new WritableCellFormat();
		WritableCellFormat wcf2 = new WritableCellFormat();

		int flag = 0;
		int columnIndex = 0;
		List<String> methodNameList = new ArrayList<String>();

		if (mapField != null && mapField.size() > 0) {
			String key = "";
			// 循环写入表头
			for (Iterator<String> i = mapField.keySet().iterator(); i.hasNext();) {
				key = i.next();
				sheet.addCell(new Label(columnIndex, 0, mapField.get(key), wcf));
				methodNameList.add(key);
				columnIndex++;
			}
			// 判断表中是否有数据
			if (excelList != null && excelList.size() > 0) {
				// 循环写入表中数据
				for (int i = 0; i < excelList.size(); i++) {
					Map<String, Object> map = (Map<String, Object>) excelList.get(i);
					// 循环输出map中的子集：既列值
					int j = 0;
					for (Object o : map.keySet()) {
									
					//第一个参数为列坐标，第二个参数为行坐标，第三个参数为内容	
					sheet.addCell(new Label(0, i+1, String.valueOf(map.get("MERCHANT_NO")==null?"":map.get("MERCHANT_NO")), wcf2));
					sheet.addCell(new Label(1, i+1, String.valueOf(map.get("TERM_NO")==null?"":map.get("TERM_NO")), wcf2));
					sheet.addCell(new Label(2, i+1, String.valueOf(map.get("TERMINAL_TYPE_NO")==null?"":map.get("TERMINAL_TYPE_NO")), wcf2));
					sheet.addCell(new Label(3, i+1, String.valueOf(map.get("SNAME")==null?"":map.get("SNAME")), wcf2));
					sheet.addCell(new Label(4, i+1, String.valueOf(map.get("STEL")==null?"":map.get("STEL")), wcf2));
					sheet.addCell(new Label(5, i+1, String.valueOf(map.get("BINDER_DATE")==null?"":map.get("BINDER_DATE")), wcf2));
					sheet.addCell(new Label(6, i+1, String.valueOf(map.get("INVENTORY_STATUS")==null?"":map.get("INVENTORY_STATUS")), wcf2));
					sheet.addCell(new Label(7, i+1, String.valueOf(map.get("PARENT_AGENT_NO")==null?"":map.get("PARENT_AGENT_NO")), wcf2));
					sheet.addCell(new Label(8, i+1, String.valueOf(map.get("STATUS")==null?"":map.get("STATUS")), wcf2));
					sheet.addCell(new Label(9, i+1, String.valueOf(map.get("USER_STATUS")==null?"":map.get("USER_STATUS")), wcf2));
					sheet.addCell(new Label(10, i+1,String.valueOf(map.get("IFACTIVATED")==null?"":map.get("IFACTIVATED")), wcf2));
					}			
					
				}
			} else {
				flag = -1;
			}
			// 写入Exel工作表
			wwb.write();
			// 关闭Excel工作薄对象
			wwb.close();
			// 关闭流
			os.flush();
			os.close();
			os = null;
		}
	}
	
	/**终端操作查询
	 * @param request
	 * @param response
	 * @param mbForm
	 */
	@RequestMapping(params = "method=findTerminalOperateList")
	public String findTerminalOperateList(HttpServletRequest request,HttpServletResponse response,TerminalForm mbForm) {
		List terminalOperateList=terminalService.findTerminalOperateList(mbForm);
		request.setAttribute("terminalOperateList", terminalOperateList);
		return "terminal/terminalOperateList";
	}
	
	
	
	/**解绑
	 * @param request
	 * @param response
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=toUnBinder")
	public String toUnBinder(HttpServletRequest request,HttpServletResponse response,TerminalForm mbForm) throws Exception {
		try {
			String term_nos=request.getParameter("term_nos");
			if(StringUtils.isNotEmpty(term_nos)){
				B2cTermBinder term=terminalService.findB2cTermBinderByTermNo(term_nos);
				if(term!=null){
					if(Constants.CON_NO.toString().equals(term.getStatus())){
						terminalService.updateUnBinder(request,term);
						request.setAttribute("url","terminal.htm?method=findTerminalOperateList");
						request.setAttribute(Constants.MESSAGE_KEY, "解绑成功！");
					}else{
						request.setAttribute("url","terminal.htm?method=findTerminalOperateList");
						request.setAttribute(Constants.MESSAGE_KEY, "终端未绑定，不能解绑");
					}
				}
			}else{
				request.setAttribute("url","terminal.htm?method=findTerminalOperateList");
				request.setAttribute(Constants.MESSAGE_KEY, "参数为空，请查证！");
			}
			} catch (Exception e) {
				e.printStackTrace();
				throw new BusinessException(ExceptionDefine.终端操作,new String[]{"解绑报错"});
			}
			return "/returnPage";
	}
	
	
	/**冻结
	 * @param request
	 * @param response
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=toFreeze")
	public String toFreeze(HttpServletRequest request,HttpServletResponse response,TerminalForm mbForm) throws Exception {
		try{
		String term_nos=request.getParameter("term_nos");
		if(StringUtils.isNotEmpty(term_nos)){
			B2cTermBinder term=terminalService.findB2cTermBinderByTermNo(term_nos);
			if(term!=null){
				if(Constants.CON_NO.toString().equals(term.getStatus())){
					terminalService.updateFreeze(request,term);
					request.setAttribute("url","terminal.htm?method=findTerminalOperateList");
					request.setAttribute(Constants.MESSAGE_KEY, "冻结成功！");
				}else{
					request.setAttribute("url","terminal.htm?method=findTerminalOperateList");
					request.setAttribute(Constants.MESSAGE_KEY, "请先绑定，再冻结!");
				}
			}
		}else{
			request.setAttribute("url","terminal.htm?method=findTerminalOperateList");
			request.setAttribute(Constants.MESSAGE_KEY, "参数为空，请查证！");
		}
	} catch (Exception e) {
		e.printStackTrace();
		throw new BusinessException(ExceptionDefine.终端操作,new String[]{"冻结出错！"});
	}
		
		return "/returnPage";
	}
	
	
	/**解冻
	 * @param request
	 * @param response
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=toUnfreeze")
	public String toUnfreeze(HttpServletRequest request,HttpServletResponse response,TerminalForm mbForm) throws Exception {
		try {
				String term_nos=request.getParameter("term_nos");
				if(StringUtils.isNotEmpty(term_nos)){
					B2cTermBinder term=terminalService.findB2cTermBinderByTermNo(term_nos);
					if(term!=null){
						if(Constants.CON_NO.toString().equals(term.getStatus())){
							terminalService.updateUnFreeze(request,term);
							request.setAttribute("url","terminal.htm?method=findTerminalOperateList");
							request.setAttribute(Constants.MESSAGE_KEY, "解冻成功！");
						}else{
							request.setAttribute("url","terminal.htm?method=findTerminalOperateList");
							request.setAttribute(Constants.MESSAGE_KEY, "请先绑定，再解结!");
						}
					}
				}else{
					request.setAttribute("url","terminal.htm?method=findTerminalOperateList");
					request.setAttribute(Constants.MESSAGE_KEY, "参数为空，请查证！");
				}
			} catch (Exception e) {
				e.printStackTrace();
				throw new BusinessException(ExceptionDefine.终端操作,new String[]{"解冻报错"});
			}
			return "/returnPage";
	}
	
	
	/**注销
	 * @param request
	 * @param response
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=toCancel")
	public String toCancel(HttpServletRequest request,HttpServletResponse response,TerminalForm mbForm) throws Exception {
		try {
				String term_nos=request.getParameter("term_nos");
				if(StringUtils.isNotEmpty(term_nos)){
					B2cTermBinder term=terminalService.findB2cTermBinderByTermNo(term_nos);
					if(term!=null){
						if(!(Constants.CON_NO.toString().equals(term.getStatus()))){
							term.setInventory_status(Constants.CON_YES);
							terminalService.updateInventoryStatus(request,term);
							request.setAttribute("url","terminal.htm?method=findTerminalOperateList");
							request.setAttribute(Constants.MESSAGE_KEY, "注销成功！");
						}else{
							request.setAttribute("url","terminal.htm?method=findTerminalOperateList");
							request.setAttribute(Constants.MESSAGE_KEY, "请先解绑,再注销!");
						}
					}
				}else{
					request.setAttribute("url","terminal.htm?method=findTerminalOperateList");
					request.setAttribute(Constants.MESSAGE_KEY, "参数为空，请查证！");
				}
			} catch (Exception e) {
				e.printStackTrace();
				throw new BusinessException(ExceptionDefine.终端操作,new String[]{"终端注销报错！"});
			}
			return "/returnPage";
	}
	
}
