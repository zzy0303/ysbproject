package com.uns.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.aspectj.apache.bcel.classfile.Constant;
import org.aspectj.apache.bcel.classfile.ConstantObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Base64;
import com.uns.common.Constants;
import com.uns.common.ConstantsEnv;
import com.uns.common.ImageCompressUtil;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.model.Agent;
import com.uns.model.AgentTopFee;
import com.uns.model.Area;
import com.uns.model.B2cAgentBinder;
import com.uns.model.B2cDict;
import com.uns.model.B2cShopperbargain;
import com.uns.model.B2cShopperbargainTemp;
import com.uns.model.B2cShopperbi;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.B2cTempTermBinder;
import com.uns.model.B2cTermBinder;
import com.uns.model.B2cTerminal;
import com.uns.model.BackupsShopperInformation;
import com.uns.model.FixAmaount;
import com.uns.model.MposApplicationProgress;
import com.uns.model.MposMerchantFee;
import com.uns.model.MposPhotoTmp;
import com.uns.model.Operator;
import com.uns.model.UpdateFeeHistory;
import com.uns.model.Users;
import com.uns.service.AgentMccService;
import com.uns.service.ShopPerbiService;
import com.uns.util.HttpClientUtils;
import com.uns.util.JsonUtil;
import com.uns.util.Md5Encrypt;
import com.uns.util.StringUtils;
import com.uns.util.ToolsUtils;
import com.uns.web.form.ShopPerbiForm;

import jxl.SheetSettings;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import net.sf.json.JSONObject;


@Controller("shopPerbiController")
@RequestMapping("/shopPerbi.htm")
public class ShopPerbiController extends BaseController {

    @Autowired
    private ShopPerbiService shopPerbiService;

    @Autowired
    private AgentMccService agentMccService;


    private String basePath = DynamicConfigLoader.getByEnv("basePath.url");


    /**
     * 下载pdf
     *
     * @param request
     * @param modelMap
     * @param mbForm
     */
    @RequestMapping(params = "method=downloaddata")
    public void downloaddata(HttpServletRequest request, HttpServletResponse response) {
        String filePath = request.getParameter("fileName");
        String fileName = "";
        //从文件完整路径中提取文件名，并进行编码转换，防止不能正确显示中文名
        try {
            if (filePath.lastIndexOf("/") > 0) {
                fileName = new String(filePath.substring(filePath.lastIndexOf("/") + 1, filePath.length()).getBytes("GB2312"), "ISO8859_1");
            } else if (filePath.lastIndexOf("\\") > 0) {
                fileName = new String(filePath.substring(filePath.lastIndexOf("\\") + 1, filePath.length()).getBytes("GB2312"), "ISO8859_1");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        //打开指定文件的流信息
        InputStream fs = null;
        try {
            File file = new File(filePath);
            fs = new FileInputStream(file);
        } catch (Exception e) {
            e.printStackTrace();
        }
        //设置响应头和保存文件名
        response.setCharacterEncoding("ISO-8859-1");
        response.setContentType("APPLICATION/OCTET-STREAM");
        response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
        //写出流信息
        int b = 0;
        try {
            PrintWriter out = response.getWriter();
            while ((b = fs.read()) != -1) {
                out.write(b);
            }
            out.flush();
            fs.close();
            out.close();
            log.debug("文件下载完毕");
        } catch (Exception e) {
            e.printStackTrace();
            log.debug("下载文件失败!");
        }

    }

    /**
     * 下载开户行信息申请单.xls
     *
     * @param request
     * @param modelMap
     * @param mbForm
     */
    @RequestMapping(params = "method=downBkTemplate")
    public void downBkTemplate(HttpServletRequest request, HttpServletResponse response) {
        String fileName = "开户行信息申请单.xls";
        downFile(request, response, fileName);
    }

    /**
     * 下载终端信息变更申请表.doc
     *
     * @param request
     * @param modelMap
     * @param mbForm
     */
    @RequestMapping(params = "method=downTermianlTemplate")
    public void downTermianlTemplate(HttpServletRequest request, HttpServletResponse response) {
        String fileName = "终端信息变更申请表.doc";
        downFile(request, response, fileName);
    }

    /**
     * 是否有重复的用户名存在
     *
     * @param request
     * @param response
     * @throws
     * @throws IOException
     */
    @RequestMapping(params = "method=ajaxaddTermainal")
    public void ajaxaddTermainal(HttpServletRequest request, HttpServletResponse response) throws IOException {
        B2cTempTermBinder tempTermBinder = new B2cTempTermBinder();
        B2cTempTermBinder tempTermBinder2 = new B2cTempTermBinder();
        String terminalid = request.getParameter("terminalid");
        String num = request.getParameter("num");
        String merchantNo = request.getParameter("shopPerbiregId");
        if (StringUtils.isTrimNotEmpty(terminalid)) {
            tempTermBinder2 = shopPerbiService.selectTempTermNo(terminalid);
        }
        List Tershopper = null;
        if (tempTermBinder2 != null) {
            if (tempTermBinder2.getStatus().toString().equals("0")) {
                shopPerbiService.deleteTempTermianl(tempTermBinder2.getTermNo());
            }
        }
        if (tempTermBinder2 == null || tempTermBinder2.getStatus().toString().equals("0")) {
            if (StringUtils.isTrimNotEmpty(merchantNo)) {
                tempTermBinder.setMerchantNo(merchantNo);
            }
            if (StringUtils.isTrimNotEmpty(terminalid)) {
                tempTermBinder.setTermNo(terminalid);
            }
            tempTermBinder.setStatus("0");
            tempTermBinder.setCreateDate(new Date());
            shopPerbiService.addTempBinder(tempTermBinder);
            Tershopper = shopPerbiService.shopperAjaxBinder(merchantNo);
        }
        String str = "无";
        PrintWriter out = null;
        try {
            out = response.getWriter();
            if (Tershopper != null && Tershopper.size() > 0) {
                out.println(JsonUtil.getJsonString4List(Tershopper));
            } else {
                response.getWriter().print(str);
            }

        } catch (Exception e) {
            e.printStackTrace();
            if (out != null) {
                out.flush();
                out.close();
            }
        } finally {
            if (out != null) {
                out.flush();
                out.close();
            }
        }

    }


    /**
     * 是否有重复的用户名存在
     *
     * @param request
     * @param response
     * @throws
     * @throws IOException
     */
    @RequestMapping(params = "method=ajaxfindTermainal")
    public void ajaxfindTermainal(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            String terminalid = request.getParameter("terminalid");
            String agentno = request.getParameter("");
            B2cTerminal b2cterminal = null;
            String shopperbi = null;
            B2cAgentBinder agentBinder = null;
            if (StringUtils.isTrimNotEmpty(terminalid)) {
                terminalid = terminalid.trim();
                b2cterminal = shopPerbiService.findtermainal(terminalid);
                shopperbi = shopPerbiService.selectBindtermainal(terminalid);
                agentBinder = shopPerbiService.selectByTermNo(terminalid);
            }
            StringBuffer str = new StringBuffer("");
            if (b2cterminal == null) {
                throw new BusinessException(ExceptionDefine.空指针异常);
            }
            if (b2cterminal.getNum() != null) {
                str.append(b2cterminal.getNum() + ",");
            } else {
                str.append(null + ",");
            }
            if (b2cterminal.getName() != null) {
                str.append(b2cterminal.getName() + ",");
            } else {
                str.append(null + ",");
            }
            if (shopperbi == null) {
                str.append("无,");
            } else {
                str.append(shopperbi + ",");
            }
            if (b2cterminal.getTerminalid() != null) {
                str.append(b2cterminal.getTerminalid() + ",");
            }
            if (agentBinder != null) {
                str.append(agentBinder.getAgentNo());
            } else {
                str.append("无");
            }
            response.getWriter().print(str);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 是否有重复的用户名存在
     *
     * @param request
     * @param response
     * @throws
     * @throws IOException
     */
    @RequestMapping(params = "method=ajaxCheckName")
    public void ajaxCheckName(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            String userName = request.getParameter("userName");
            List<Users> users = null;
            List list = null;
            if (StringUtils.isTrimNotEmpty(userName)) {
                userName = userName.trim();
                users = shopPerbiService.selectByUsersName(userName);
                list = shopPerbiService.selectByMuserid(userName);
            }
            PrintWriter out = response.getWriter();
            try {
                if ((users != null && users.size() > 0) || (list != null && list.size() > 0)) {
                    out.write("{\"x\":\"1\"}");
                } else {
                    out.write("{\"x\":\"2\"}");
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (out != null) {
                    out.flush();
                    out.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * 审核开户行信息之前需要先审核商户信息
     *
     * @param request
     * @param response
     * @throws
     * @throws IOException
     */
    @RequestMapping(params = "method=ajaxFormalShopper")
    public void ajaxFormalShopper(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            String ShooperId = request.getParameter("ShooperId");
            B2cShopperbi formalShopper = new B2cShopperbi();
            B2cShopperbiTemp shoper = new B2cShopperbiTemp();
            if (!StringUtils.isEmpty(ShooperId)) {
                shoper = shopPerbiService.queryShopPerbi(ShooperId);
            }
            if (!StringUtils.isEmpty(ShooperId)) {
                formalShopper = shopPerbiService.selectFormalShopperId(ShooperId);
            }
            PrintWriter out = response.getWriter();
            try {
                if (formalShopper != null) {
                    out.write("{\"x\":\"1\"}");
                } else if (shoper.getIfvalid().toString().equals("2")) {
                    out.write("{\"x\":\"2\"}");
                } else {
                    out.write("{\"x\":\"3\"}");
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (out != null) {
                    out.flush();
                    out.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * 审核开户行信息之前需要先审核商户信息
     *
     * @param request
     * @param response
     * @throws
     * @throws IOException
     */
    @RequestMapping(params = "method=ajaxTerminalShopper")
    public void ajaxTerminalShopper(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            String ShooperId = request.getParameter("ShooperId");
            B2cShopperbiTemp shoper = new B2cShopperbiTemp();
            if (!StringUtils.isEmpty(ShooperId)) {
                shoper = shopPerbiService.queryShopPerbi(ShooperId);
            }
            PrintWriter out = response.getWriter();
            try {
                if (shoper.getIfvalid().toString().equals("1")) {
                    out.write("{\"x\":\"1\"}");
                } else if (shoper.getIfvalid().toString().equals("2")) {
                    out.write("{\"x\":\"2\"}");
                } else {
                    out.write("{\"x\":\"3\"}");
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (out != null) {
                    out.flush();
                    out.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * 商户查询
     *
     * @param request
     * @param b2cShopperbiTmp
     * @param b2cShopperbargainTmp
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=shopPerbiManageList")
    public String shopPerbiManageList(HttpServletRequest request, ModelMap modelMap,
                                      ShopPerbiForm mbForm) throws Exception {
        try {
            //行业类型
            List cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
            request.setAttribute("cillinglist", cillinglist);
            List<HashMap> shopPerbilist = null;
            //判断商户编号是否为数字
            String shopperIdq = mbForm.getShopperidq();
            if (!StringUtils.isEmpty(shopperIdq)) {
                boolean b = isFigure(shopperIdq);
                if (!b) {
                    mbForm.setShopperidq("");
                }
            }
            if (mbForm.getSprovince() != null) {
                List searchProvincialList = shopPerbiService.searchProvincial(mbForm.getSprovince());
                if (searchProvincialList != null && searchProvincialList.size() > 0) {
                    Area spro = (Area) searchProvincialList.get(0);
                    if (spro != null) {
                        String sprov = spro.getProvincialname();
                        mbForm.setSprovince(sprov);
                    }
                }
            }
            if (mbForm.getCity() != null) {
                List cityList = shopPerbiService.searchCity(mbForm.getCity());
                if (cityList != null && cityList.size() > 0) {
                    Area area = (Area) cityList.get(0);
                    if (area != null) {
                        String cityName = (String) area.getCityname();
                        mbForm.setCity(cityName);
                    }
                }
            }
            shopPerbilist = shopPerbiService.queryShopPerbiManageList(mbForm);
            modelMap.put("shopPerbilist", shopPerbilist);
            //获取省
            List<Area> Provincial = shopPerbiService.searchProvince();
            request.setAttribute("Provincial", Provincial);
            //获取市
            List<Area> list = shopPerbiService.searchArea();
            request.setAttribute("area", list);
            request.setAttribute("belongsAgent", mbForm.getBelongsAgent());
        } catch (BusinessException e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.商户查询失败);
        }
        return "shopPerbi/shopPerbiManage";
    }

    /**
     * 正式商户查询 正式信息导出
     *
     * @param request
     * @param b2cShopperbiTmp
     * @param b2cShopperbargainTmp
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=shopFormalManageList")
    public String shopFormalManageList(HttpServletRequest request,
                                       ShopPerbiForm mbForm) throws Exception {
        try {
            //行业类型
            List cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
            request.setAttribute("cillinglist", cillinglist);
            List<HashMap> shopPerbilist = null;
            //判断商户编号是否为数字
            String shopperIdq = mbForm.getShopperidq();
            if (!StringUtils.isEmpty(shopperIdq)) {
                boolean b = isFigure(shopperIdq);
                if (!b) {
                    mbForm.setShopperidq("");
                }
            }
            if (mbForm.getSprovince() != null) {
                List searchProvincialList = shopPerbiService.searchProvincial(mbForm.getSprovince());
                if (searchProvincialList != null && searchProvincialList.size() > 0) {
                    Area spro = (Area) searchProvincialList.get(0);
                    if (spro != null) {
                        String sprov = spro.getProvincialname();
                        mbForm.setSprovince(sprov);
                    }
                }
            }
            if (mbForm.getCity() != null) {
                List cityList = shopPerbiService.searchCity(mbForm.getCity());
                if (cityList != null && cityList.size() > 0) {
                    Area area = (Area) cityList.get(0);
                    if (area != null) {
                        String cityName = (String) area.getCityname();
                        mbForm.setCity(cityName);
                    }
                }
            }

            //获取省
            List<Area> Provincial = shopPerbiService.searchProvince();
            request.setAttribute("Provincial", Provincial);
            //获取市
            List<Area> list = shopPerbiService.searchArea();
            request.setAttribute("area", list);
            String checkAgent = request.getParameter("checkAgent");
            if (StringUtils.isEmpty(checkAgent)) {
                mbForm.setCheckAgents(false);
            } else {
                if (checkAgent.equals("true")) {
                    mbForm.setCheckAgents(true);
                } else {
                    mbForm.setCheckAgents(false);
                }
            }
            shopPerbilist = shopPerbiService.queryFormalList(mbForm);
            request.setAttribute("shopPerbilist", shopPerbilist);
            request.setAttribute("belongsAgent", mbForm.getBelongsAgent());
        } catch (BusinessException e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.商户查询失败);
        }
        return "shopPerbi/shopFormalPerbiManage";
    }

    /**
     * 商户审核
     *
     * @param request
     * @param b2cShopperbiTmp
     * @param b2cShopperbargainTmp
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=shopPerbiCheckList")
    public String shopPerbiCheckList(HttpServletRequest request, ModelMap modelMap,
                                     ShopPerbiForm mbForm) throws Exception {
        try {
            //行业类型
            List cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
            request.setAttribute("cillinglist", cillinglist);
            List<HashMap> shopPerbilist = null;
            //判断商户编号是否为数字
            String shopperIdq = mbForm.getShopperidq();
            if (!StringUtils.isEmpty(shopperIdq)) {
                boolean b = isFigure(shopperIdq);
                if (!b) {
                    mbForm.setShopperidq("");
                }
            }
            if (mbForm.getSprovince() != null) {
                List searchProvincialList = shopPerbiService.searchProvincial(mbForm.getSprovince());
                if (searchProvincialList != null && searchProvincialList.size() > 0) {
                    Area spro = (Area) searchProvincialList.get(0);
                    if (spro != null) {
                        String sprov = spro.getProvincialname();
                        mbForm.setSprovince(sprov);
                    }
                }
            }
            if (mbForm.getCity() != null) {
                List cityList = shopPerbiService.searchCity(mbForm.getCity());
                if (cityList != null && cityList.size() > 0) {
                    Area area = (Area) cityList.get(0);
                    if (area != null) {
                        String cityName = (String) area.getCityname();
                        mbForm.setCity(cityName);
                    }
                }
            }
            shopPerbilist = shopPerbiService.ShopPerbiCheckList(mbForm);
            modelMap.put("shopPerbilist", shopPerbilist);
            //获取省
            List<Area> Provincial = shopPerbiService.searchProvince();
            request.setAttribute("Provincial", Provincial);
            //获取市
            List<Area> list = shopPerbiService.searchArea();
            request.setAttribute("area", list);
            //获取未审核的商户个数
            String Shoppercount = shopPerbiService.selectCheckCount();
            request.setAttribute("Shoppercount", Shoppercount);

            request.setAttribute("belongsAgent", mbForm.getBelongsAgent());
        } catch (BusinessException e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.商户查询失败);
        }
        return "shopPerbi/shopPerbiCheck";
    }

    /**
     * 查看商户详情
     *
     * @param request
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=selectAgent")
    @FormToken(save = true)
    public String selectAgent(HttpServletRequest request,
                              ModelMap modelMap, ShopPerbiForm mbForm) throws Exception {
        try {
            Agent agent = null;
            String Id = request.getParameter("id");
            if (StringUtils.isEmpty(Id)) {
                request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiManageList");
            } else {
                agent = shopPerbiService.selectAgent(Long.valueOf(Id));
            }
            request.getSession().setAttribute("agent", agent);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }


        return "shopPerbi/shopPerbiAgentDetails";
    }

    /**
     * 查看商户详情
     *
     * @param request
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=findAgent")
    @FormToken(save = true)
    public String findAgent(HttpServletRequest request,
                            ModelMap modelMap, ShopPerbiForm mbForm) throws Exception {
        try {
            Agent agent = null;
            String Id = request.getParameter("id");
            if (StringUtils.isEmpty(Id)) {
                request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiManageList");
            } else {
                agent = shopPerbiService.selectAgent(Long.valueOf(Id));
            }
            request.getSession().setAttribute("agent", agent);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }


        return "shopPerbi/shopPerbiFindAgent";
    }

    /**
     * 商户开户银行的审核
     *
     * @param request
     * @param b2cShopperbiTmp
     * @param b2cShopperbargainTmp
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=shopPerbiBankList")
    public String shopPerbiBankList(HttpServletRequest request, ModelMap modelMap,
                                    ShopPerbiForm mbForm) throws Exception {
        try {
            //行业类型
            List cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
            request.setAttribute("cillinglist", cillinglist);
            List<HashMap> shopPerbilist = null;
            //判断商户编号是否为数字
            String shopperIdq = mbForm.getShopperidq();
            if (!StringUtils.isEmpty(shopperIdq)) {
                boolean b = isFigure(shopperIdq);
                if (!b) {
                    mbForm.setShopperidq("");
                }
            }
            if (mbForm.getSprovince() != null) {
                List searchProvincialList = shopPerbiService.searchProvincial(mbForm.getSprovince());
                if (searchProvincialList != null && searchProvincialList.size() > 0) {
                    Area spro = (Area) searchProvincialList.get(0);
                    if (spro != null) {
                        String sprov = spro.getProvincialname();
                        mbForm.setSprovince(sprov);
                    }
                }
            }
            if (mbForm.getCity() != null) {
                List cityList = shopPerbiService.searchCity(mbForm.getCity());
                if (cityList != null && cityList.size() > 0) {
                    Area area = (Area) cityList.get(0);
                    if (area != null) {
                        String cityName = (String) area.getCityname();
                        mbForm.setCity(cityName);
                    }
                }
            }
            shopPerbilist = shopPerbiService.shopPerbiBankList(mbForm);
            modelMap.put("shopPerbilist", shopPerbilist);
            //获取省
            List<Area> Provincial = shopPerbiService.searchProvince();
            request.setAttribute("Provincial", Provincial);
            //获取市
            List<Area> list = shopPerbiService.searchArea();
            request.setAttribute("area", list);
            //获取未审核的商户开户行信息的个数
            String Bankcount = shopPerbiService.selectCheckBkCount();
            request.setAttribute("Bankcount", Bankcount);

            request.setAttribute("belongsAgent", mbForm.getBelongsAgent());
        } catch (BusinessException e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.商户查询失败);
        }
        return "shopPerbi/shopPerbiCheckBank";
    }

    /**
     * 商户终端的审核
     *
     * @param request
     * @param b2cShopperbiTmp
     * @param b2cShopperbargainTmp
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=shopPerbiTerminalList")
    public String shopPerbiTerminalList(HttpServletRequest request, ModelMap modelMap,
                                        ShopPerbiForm mbForm) throws Exception {
        try {
            //行业类型
            List cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
            request.setAttribute("cillinglist", cillinglist);
            List<HashMap> shopPerbilist = null;
            //判断商户编号是否为数字
            String shopperIdq = mbForm.getShopperidq();
            if (!StringUtils.isEmpty(shopperIdq)) {
                boolean b = isFigure(shopperIdq);
                if (!b) {
                    mbForm.setShopperidq("");
                }
            }
            if (mbForm.getSprovince() != null) {
                List searchProvincialList = shopPerbiService.searchProvincial(mbForm.getSprovince());
                if (searchProvincialList != null && searchProvincialList.size() > 0) {
                    Area spro = (Area) searchProvincialList.get(0);
                    if (spro != null) {
                        String sprov = spro.getProvincialname();
                        mbForm.setSprovince(sprov);
                    }
                }
            }
            if (mbForm.getCity() != null) {
                List cityList = shopPerbiService.searchCity(mbForm.getCity());
                if (cityList != null && cityList.size() > 0) {
                    Area area = (Area) cityList.get(0);
                    if (area != null) {
                        String cityName = (String) area.getCityname();
                        mbForm.setCity(cityName);
                    }
                }
            }
            shopPerbilist = shopPerbiService.shopPerbiTerminalList(mbForm);
            modelMap.put("shopPerbilist", shopPerbilist);
            //获取省
            List<Area> Provincial = shopPerbiService.searchProvince();
            request.setAttribute("Provincial", Provincial);
            //获取市
            List<Area> list = shopPerbiService.searchArea();
            request.setAttribute("area", list);
            //获取未审核的商户开户行信息的个数
            String Tercount = shopPerbiService.selectCheckCount();
            request.setAttribute("Tercount", Tercount);

            request.setAttribute("belongsAgent", mbForm.getBelongsAgent());
        } catch (BusinessException e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.商户查询失败);
        }
        return "shopPerbi/shopPerbiTermianlList";
    }


    /**
     * 商户注册
     *
     * @param request
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param modelMap
     * @return
     * @throws Exception
     * @
     */
    @RequestMapping(params = "method=queryShopPerbireg")
    @FormToken(save = true)
    public String queryShopPerbireg(HttpServletRequest request, ModelMap modelMap) throws Exception {
        try {
            //获取省
            List<Area> Provincial = shopPerbiService.searchProvince();
            request.setAttribute("Provincial", Provincial);
            //获取市
            List<Area> list = shopPerbiService.searchArea();
            request.setAttribute("area", list);
            //获取银行
            List<B2cDict> dicbank = shopPerbiService.searchBank();
            request.setAttribute("bank", dicbank);
            //行业类型
            List cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
            request.setAttribute("cillinglist", cillinglist);

            //结算周期
            List footfreqlist = shopPerbiService.searchFootFreqList();
            request.setAttribute("footfreqlist", footfreqlist);

            //费率下拉框的取值
            List<AgentTopFee> d0creditCardFee = shopPerbiService.findAgentFeeByType(Constants.FEE_TYPE_DEBIT);
            List<AgentTopFee> d0debitCardFee = shopPerbiService.findAgentFeeByType(Constants.FEE_TYPE_CREDIT);

            List<AgentTopFee> s0creditCardFee = shopPerbiService.findAgentFeeByType(Constants.S0_FEE_TYPE_DEBIT);
            List<AgentTopFee> s0debitCardFee = shopPerbiService.findAgentFeeByType(Constants.S0_FEE_TYPE_CREDIT);

            List<AgentTopFee> t1creditCardFee = shopPerbiService.findAgentFeeByType(Constants.T1_FEE_TYPE_DEBIT);
            List<AgentTopFee> t1debitCardFee = shopPerbiService.findAgentFeeByType(Constants.T1_FEE_TYPE_CREDIT);

            request.setAttribute("d0creditCardFee", d0creditCardFee);
            request.setAttribute("d0debitCardFee", d0debitCardFee);

            request.setAttribute("s0creditCardFee", s0creditCardFee);
            request.setAttribute("s0debitCardFee", s0debitCardFee);

            request.setAttribute("t1creditCardFee", t1creditCardFee);
            request.setAttribute("t1debitCardFee", t1debitCardFee);

            List<AgentTopFee> weChatFee = shopPerbiService.findAgentFeeByType(Constants.FEE_TYPE_WECHAT);
            List<AgentTopFee> alipayFee = shopPerbiService.findAgentFeeByType(Constants.FEE_TYPE_ALIPAY);
            List<AgentTopFee> ylpayFee = shopPerbiService.findAgentFeeByType(Constants.FEE_TYPE_YLPAY);
            request.setAttribute("weChatFee", weChatFee);
            request.setAttribute("alipayFee", alipayFee);
            request.setAttribute("ylpayFee", ylpayFee);

            //查询速惠收款费率
            List<AgentTopFee> shd0Fee = shopPerbiService.findAgentFeeByType(Constants.AGENT_TYPE_SHORTCUTSH);
            request.setAttribute("shd0Fee", shd0Fee);

            List<AgentTopFee> shortCut = shopPerbiService.findAgentFeeByType(Constants.AGENT_TYPE_SHORTCUT);
            List<AgentTopFee> b2c = shopPerbiService.findAgentFeeByType(Constants.AGENT_TYPE_B2C);
            request.setAttribute("shortCut", shortCut);
            request.setAttribute("b2c", b2c);
            //t0结算
            request.setAttribute("t0_fee", Constants.T0_FEE);
            request.setAttribute("s0_fix_amount", Constants.S0_FIX_AMOUNT);
            request.setAttribute("t0_fixed_amount", Constants.T0_FIXED_AMOUNT);
            request.setAttribute("t0_min_amount", Constants.T0_MIN_AMOUNT);
            request.setAttribute("t0_max_amount", Constants.T0_MAX_AMOUNT);
            request.setAttribute("t0_singleday_limit", Constants.T0_SINGLEDAY_LIMIT);
            //授信额度默认50000(此为新加字段数据库也得加)
            request.setAttribute("creditLines", Constants.T0_MAX_AMOUNT);
            //代理商分润默认百分比	//商户分润默认百分比1,2,3
            request.setAttribute("agentProfitRatio", ConstantsEnv.AGENT_PROFIT_RATIO);
            request.setAttribute("profitOwner", ConstantsEnv.PROFIT_OWNER);
            request.setAttribute("merchRatio1", ConstantsEnv.MERCH_PROFIT1);
            request.setAttribute("merchRatio2_1", ConstantsEnv.MERCH_RATIO2_1);
            request.setAttribute("merchRatio2_2", ConstantsEnv.MERCH_RATIO2_2);
            request.setAttribute("merchRatio3_1", ConstantsEnv.MERCH_RATIO3_1);
            request.setAttribute("merchRatio3_2", ConstantsEnv.MERCH_RATIO3_2);
            request.setAttribute("merchRatio3_3", ConstantsEnv.MERCH_RATIO3_3);


        } catch (BusinessException e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.商户注册获取列表失败);
        }
        return "shopPerbi/shopPerbireg";


    }


    /**
     * 保存商户注册
     * 1.生成小商户编码
     *
     * @param request
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param modelMap
     * @return
     * @throws IOException
     */


    private static final String sep = File.separator;

    @RequestMapping(params = "method=saveShopPerbiregList")
    @FormToken(remove = true)
    public String saveShopPerbiregList(HttpServletRequest request, ModelMap modelMap,
                                       B2cShopperbiTemp b2cShopperbi, ShopPerbiForm mbForm) throws Exception {
        try {
            String shopperid = getPosShopperId(b2cShopperbi.getCity(), Constants.CON_MCC);
            b2cShopperbi.setShopperid(Long.valueOf(shopperid));

            b2cShopperbi.setIfvalid(Short.valueOf(Constants.STATUS0));//是否审核
            b2cShopperbi.setOpencheckstatus(Short.valueOf(Constants.STATUS0));//开户行信息未审核
            b2cShopperbi.setIsformal(Short.valueOf(Constants.STATUS0));
            b2cShopperbi.setIsupdateshopper(Short.valueOf(Constants.STATUS0));
            b2cShopperbi.setSifpactid(Long.valueOf(Constants.STATUS0));
            b2cShopperbi.setRecheckmerchantflag(Constants.STATUS0);
            b2cShopperbi.setPhotoCheckFlag(Constants.STATUS0);
            b2cShopperbi.setPhotoRecheckFlag(Constants.STATUS0);
            b2cShopperbi.setTransact(Constants.STATUS1);
            b2cShopperbi.setT1type(Constants.STATUS0);
            b2cShopperbi.setT0type(Constants.STATUS0);
            b2cShopperbi.setCardType(Constants.STATUS0);
            b2cShopperbi.setIsIcApplyT0(Constants.STATUS0);
            b2cShopperbi.setMuserid(b2cShopperbi.getStel());//
            b2cShopperbi.setCreated(new Date());
            b2cShopperbi.setRecheckaccountflag(Constants.STATUS0);
            b2cShopperbi.setRecheckterminalflag(Constants.STATUS0);
            b2cShopperbi.setSagentid(mbForm.getShopperid_p());
            b2cShopperbi.setReportResource(Constants.STATUS2);//平台报件
            String password = Md5Encrypt.md5(RandomStringUtils.random(6));
            b2cShopperbi.setMpassword(password);
            b2cShopperbi.setSettlementType(Constants.CON_NO);
            b2cShopperbi.setIsSupportT0(Constants.CON_NO);
            b2cShopperbi.setShopperidP(mbForm.getShopperid_p());
            if (!org.apache.commons.lang3.StringUtils.isNotEmpty(b2cShopperbi.getFixqrcodecustomername())) {
                b2cShopperbi.setFixqrcodecustomername(b2cShopperbi.getScompany());
            }

            //省份，城市
            b2cShopperbi = setCityCode(b2cShopperbi);
            //插入照片
            insertPhoto(request, b2cShopperbi, mbForm);
            //申请进度
            MposApplicationProgress pro = insertProgress(request, b2cShopperbi, mbForm);

            MposPhotoTmp photo1 = this.shopPerbiService.findbsid(b2cShopperbi.getIDNo());
            b2cShopperbi.setPhotoid(photo1.getPhotoId());
            //获取方案分润百分比
            String merchRatio1 = request.getParameter("merchRatio1");
            String merchRatio21 = request.getParameter("merchRatio2_1");
            String merchRatio22 = request.getParameter("merchRatio2_2");
            String merchRatio31 = request.getParameter("merchRatio3_1");
            String merchRatio32 = request.getParameter("merchRatio3_2");
            String merchRatio33 = request.getParameter("merchRatio3_3");
            b2cShopperbi.setMerchProfitRatio1(merchRatio1);//方案1
            b2cShopperbi.setMerchProfitRatio2(merchRatio21 + "|" + merchRatio22);//方案2
            b2cShopperbi.setMerchProfitRatio3(merchRatio31 + "|" + merchRatio32 + "|" + merchRatio33);//方案3
            shopPerbiService.saveReg(b2cShopperbi, pro, mbForm);
            System.out.println("商户ID" + b2cShopperbi.getShopperid().toString());
            request.setAttribute(Constants.MESSAGE_KEY, "注册成功!");
            request.setAttribute("url", "shopPerbi.htm?method=shopPerbiManageList");
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.商户注册失败);
        }
        return "/returnPage";

    }


    private MposApplicationProgress insertProgress(HttpServletRequest request, B2cShopperbiTemp b2cShopperbi, ShopPerbiForm mbForm) {
        MposApplicationProgress pro = new MposApplicationProgress();
        pro.setShopperid(b2cShopperbi.getShopperid().toString());
        pro.setScompany(b2cShopperbi.getScompany());
        pro.setApplicationTheme("商户开通");
        pro.setApplicationType("1");
        pro.setCreateUser(((Operator) request.getSession().getAttribute(Constants.SESSION_KEY_USER)).getId());
        pro.setCreateDate(new Date());
        pro.setShopperidP(mbForm.getShopperid_p().toString());
        pro.setAgentName(mbForm.getBelongsAgent());
        pro.setApplicationStatus("1");
        return pro;
    }

    private void insertPhoto(HttpServletRequest request, B2cShopperbiTemp b2cShopperbi, ShopPerbiForm mbForm) throws Exception {
        Map hashmap = new HashMap();
        String uploadpath = request.getSession().getServletContext().getRealPath("/");
        String uploadpath1 = uploadpath + "image1.jpg";
        String uploadpath2 = uploadpath + "image2.jpg";
        String uploadpath3 = uploadpath + "image3.jpg";
        String uploadpath4 = uploadpath + "image4.jpg";
        String uploadpath6 = uploadpath + "image6.jpg";
        String uploadpath7 = uploadpath + "image7.jpg";
        String uploadpath8 = uploadpath + "image8.jpg";
        String uploadpath9 = uploadpath + "image9.jpg";
        InputStream input1 = mbForm.getHandidentitycardphoto().getInputStream();
        ImageCompressUtil.saveMinPhoto(input1, uploadpath1, 800, 0.9d);
        InputStream input11 = new FileInputStream(uploadpath1);

        InputStream input2 = mbForm.getFrontidentitycardphoto().getInputStream();
        ImageCompressUtil.saveMinPhoto(input2, uploadpath2, 800, 0.9d);
        InputStream input22 = new FileInputStream(uploadpath2);

        InputStream input3 = mbForm.getReverseidentitycardphoto().getInputStream();
        ImageCompressUtil.saveMinPhoto(input3, uploadpath3, 800, 0.9d);
        InputStream input33 = new FileInputStream(uploadpath3);
        if (b2cShopperbi.getMerchantType().equals("1")) {
            InputStream input4 = mbForm.getStorephoto().getInputStream();
            ImageCompressUtil.saveMinPhoto(input4, uploadpath4, 800, 0.9d);
            InputStream input44 = new FileInputStream(uploadpath4);
            String storePhoto = photoString(input44);
            hashmap.put("storePhoto", storePhoto.replace("+", "%2B"));
        }
        if (b2cShopperbi.getMerchantType().equals("1")) {
            InputStream input8 = mbForm.getLicensephoto().getInputStream();
            ImageCompressUtil.saveMinPhoto(input8, uploadpath6, 800, 0.9d);
            InputStream input88 = new FileInputStream(uploadpath6);
            String licensePhoto = photoString(input88);
            hashmap.put("licensePhoto", licensePhoto.replace("+", "%2B"));
        }

        InputStream input7 = mbForm.getSignaturephoto().getInputStream();
        ImageCompressUtil.saveMinPhoto(input7, uploadpath7, 800, 0.9d);
        InputStream input77 = new FileInputStream(uploadpath7);

        InputStream input9 = mbForm.getCreditCardPhoto().getInputStream();
        ImageCompressUtil.saveMinPhoto(input9, uploadpath8, 800, 0.9d);
        InputStream input99 = new FileInputStream(uploadpath8);

//		InputStream input10 = mbForm.getSettlementCardPhoto().getInputStream();
//		ImageCompressUtil.saveMinPhoto(input10, uploadpath9, 800, 0.9d);
//		InputStream input1010 = new FileInputStream(uploadpath9);


        String identityId = b2cShopperbi.getIDNo();//身份证号跟图片绑定
        String shopperType = b2cShopperbi.getMerchantType();

        String handIdentityCardPhoto = photoString(input11);
        String frontIdentityCardPhoto = photoString(input22);
        String reverseIdentityCardPhoto = photoString(input33);

        String signaturePhoto = photoString(input77);
        String creditCardPhoto = photoString(input99);
//		String settlementCardPhoto = photoString(input1010);


        hashmap.put("identityId", identityId);
        hashmap.put("shopperType", shopperType);
        hashmap.put("handIdentityCardPhoto", handIdentityCardPhoto.replace("+", "%2B"));
        hashmap.put("frontIdentityCardPhoto", frontIdentityCardPhoto.replace("+", "%2B"));
        hashmap.put("reverseIdentityCardPhoto", reverseIdentityCardPhoto.replace("+", "%2B"));
        hashmap.put("signaturePhoto", signaturePhoto.replace("+", "%2B"));
        hashmap.put("creditCardPhoto", creditCardPhoto.replace("+", "%2B"));
//		hashmap.put("settlementCardPhoto",settlementCardPhoto.replace("+", "%2B"));

        if (mbForm.getFixPhoto().getSize() > 0) {
            InputStream input111 = mbForm.getFixPhoto().getInputStream();
            ImageCompressUtil.saveMinPhoto(input111, uploadpath9, 800, 0.9d);
            InputStream input1111 = new FileInputStream(uploadpath9);
            String fixPhoto = photoString(input1111);
            hashmap.put("fixPhoto", fixPhoto.replace("+", "%2B"));
        }

        hashmap.put("version", Constants.PHOTO_VERSION);
        log.info("运营后台注册-上传图片:" + ConstantsEnv.INSER_INTO_PHOTO + hashmap.toString());
        Map resultMap = HttpClientUtils.postRequestMap(ConstantsEnv.INSER_INTO_PHOTO, hashmap, Map.class);
        log.info("运营后台注册-上传图片返回结果:" + resultMap.toString());

    }

    private B2cShopperbiTemp setCityCode(B2cShopperbiTemp b2cShopperbi) throws Exception {
        if (b2cShopperbi.getProvince() != null) {
            List searchProvincialList = shopPerbiService.searchProvincial(b2cShopperbi.getProvince());
            if (searchProvincialList != null && searchProvincialList.size() > 0) {
                Area spro = (Area) searchProvincialList.get(0);
                if (spro != null) {
                    String sprov = spro.getProvincialname();
                    b2cShopperbi.setSprovince(sprov);
                }
            }
        }
        if (b2cShopperbi.getCity() != null) {
            List cityList = shopPerbiService.searchCity(b2cShopperbi
                    .getCity());
            if (cityList != null && cityList.size() > 0) {
                Area area = (Area) cityList.get(0);
                if (area != null) {
                    String cityName = (String) area.getCityname();
                    b2cShopperbi.setScity(cityName);
                }
            }
        }
        if (b2cShopperbi.getAccountBankProvCode() != null) {
            List searchProvincialList = shopPerbiService.searchProvincial(b2cShopperbi.getAccountBankProvCode());
            if (searchProvincialList != null && searchProvincialList.size() > 0) {
                Area spro = (Area) searchProvincialList.get(0);
                if (spro != null) {
                    String sprov = spro.getProvincialname();
                    b2cShopperbi.setAccountbankprov(sprov);
                }
            }
        }
        if (b2cShopperbi.getAccountBankCityCode() != null) {
            List cityList = shopPerbiService.searchCity(b2cShopperbi.getAccountBankCityCode());
            if (cityList != null && cityList.size() > 0) {
                Area area = (Area) cityList.get(0);
                if (area != null) {
                    String cityName = (String) area.getCityname();
                    b2cShopperbi.setAccountBankCity(cityName);
                }
            }
        }
        if (b2cShopperbi.getBillProvinceCode() != null) {
            List searchProvincialList = shopPerbiService.searchProvincial(b2cShopperbi.getBillProvinceCode());
            if (searchProvincialList != null && searchProvincialList.size() > 0) {
                Area spro = (Area) searchProvincialList.get(0);
                if (spro != null) {
                    String sprov = spro.getProvincialname();
                    b2cShopperbi.setBillProvince(sprov);
                }
            }
        }
        if (b2cShopperbi.getBillCityCode() != null) {
            List cityList = shopPerbiService.searchCity(b2cShopperbi.getBillCityCode());
            if (cityList != null && cityList.size() > 0) {
                Area area = (Area) cityList.get(0);
                if (area != null) {
                    String cityName = (String) area.getCityname();
                    b2cShopperbi.setBillCity(cityName);
                }
            }
        }

        return b2cShopperbi;
    }

    /**
     * 添加user
     *
     * @param userName
     * @param mpassword
     * @param shopperid
     */
    public Map addUsers(String userName, String mpassword, String shopperid, String locked) {
        String Md5pwd = Md5Encrypt.md5(mpassword);
        HashMap map = new HashMap();
        map.put("userName", userName);
        map.put("pwd", Md5pwd);
        map.put("isagent", new Short("0"));
        map.put("createDate", new Date());
        map.put("merchantid", Long.valueOf(shopperid));
        map.put("locked", locked);
        //表示是否冻结 0 冻结 1 正常
        map.put("enabled", new Short("1"));
        //shopPerbiService.addUser(map);
        return map;
    }

    /**
     * 判断商户号
     *
     * @param userName
     * @param mpassword
     * @param shopperid
     */
    public boolean isFigure(String shopperIdq) {
        boolean b = shopperIdq.matches(Constants.CON_FIGURE);
        return b;
    }

    /**
     * 下载pdf
     *
     * @param request
     * @param modelMap
     * @param mbForm
     */
    public void downFile(HttpServletRequest request, HttpServletResponse response, String filename) {

        String filePath = request.getSession().getServletContext().getRealPath("/") +
                "upload" + File.separator + "BankFiles" + File.separator + filename;

        String fileName = "";
        //从文件完整路径中提取文件名，并进行编码转换，防止不能正确显示中文名
        try {
            if (filePath.lastIndexOf("/") > 0) {
                fileName = new String(filePath.substring(filePath.lastIndexOf("/") + 1, filePath.length()).getBytes("GB2312"), "ISO8859_1");
            } else if (filePath.lastIndexOf("\\") > 0) {
                fileName = new String(filePath.substring(filePath.lastIndexOf("\\") + 1, filePath.length()).getBytes("GB2312"), "ISO8859_1");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        //打开指定文件的流信息
        InputStream fs = null;
        try {
            fs = new FileInputStream(new File(filePath));

        } catch (Exception e) {
            e.printStackTrace();
        }
        //设置响应头和保存文件名
        response.setCharacterEncoding("ISO-8859-1");
        response.setContentType("APPLICATION/OCTET-STREAM");
        response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
        //写出流信息
        int b = 0;
        try {
            PrintWriter out = response.getWriter();
            while ((b = fs.read()) != -1) {
                out.write(b);
            }
            out.flush();
            fs.close();
            out.close();
            log.debug("文件下载完毕");
        } catch (Exception e) {
            e.printStackTrace();
            log.debug("下载文件失败!");
        }

    }

    /**
     * 修改商户信息变更
     *
     * @param request
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=queryShopPerbiupdate")
    @FormToken(save = true)
    public String queryShopPerbiupdate(HttpServletRequest request,
                                       ModelMap modelMap, B2cShopperbiTemp b2cShopperbi,
                                       B2cShopperbargainTemp b2cShopperbargain,
                                       ShopPerbiForm mbForm) throws Exception {
        try {
            String shopPerbiregId = request.getParameter("shopperpriId");
            if (StringUtils.isEmpty(shopPerbiregId)) {
                request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiCheckList");
            } else {
                b2cShopperbi = shopPerbiService.queryShopPerbi(shopPerbiregId);
                /*b2cShopperbargain=shopPerbiService.queryShopPerbargain(shopPerbiregId);*/
            }
            //获取省
            List<Area> Provincial = shopPerbiService.searchProvince();
            request.setAttribute("Provincial", Provincial);
            //获取市
            List<Area> list = shopPerbiService.searchArea();
            request.setAttribute("area", list);
            //行业类型
            List cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
            request.setAttribute("cillinglist", cillinglist);
            //结算周期
            List footfreqlist = shopPerbiService.searchFootFreqList();
            request.setAttribute("footfreqlist", footfreqlist);
            //代理商
            String path = request.getSession().getServletContext().getContextPath();
            request.setAttribute("agentlist", path + "agent/selectAgentTree.htm");

            if (b2cShopperbi != null) {
                //获取代理商
                Long shopperId = b2cShopperbi.getShopperidP();
                if (shopperId != null) {
                    Agent agent = shopPerbiService.searchAgent(shopperId);
                    modelMap.put("agentName", agent.getScompany());
                    modelMap.put("agentId", agent.getShopperid());
                }
            }
            modelMap.put("feeList", shopPerbiService.selectFeeByShopperid1(b2cShopperbi.getShopperid()));
            modelMap.put("b2cShopperbi", b2cShopperbi);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }


        return "shopPerbi/shopPerbiUpdateAll";
    }

    /**
     * 查询商户的开户行信息
     *
     * @param request
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=queryShopPerbiBank")
    @FormToken(save = true)
    public String queryShopPerbiBank(HttpServletRequest request,
                                     ModelMap modelMap, B2cShopperbiTemp b2cShopperbi,
                                     B2cShopperbargainTemp b2cShopperbargain,
                                     ShopPerbiForm mbForm) throws Exception {
        try {
            String shopPerbiregId = request.getParameter("shopperpriId");
            //获取省
            List<Area> Provincial = shopPerbiService.searchProvince();
            request.setAttribute("Provincial", Provincial);

            //获取市
            List<Area> list = shopPerbiService.searchArea();
            request.setAttribute("area", list);

            //获取银行
            List<B2cDict> dicbank = shopPerbiService.searchBank();
            request.setAttribute("bank", dicbank);

            if (StringUtils.isEmpty(shopPerbiregId)) {
                request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiCheckList");
            } else {
                b2cShopperbi = shopPerbiService.queryShopPerbi(shopPerbiregId);

            }
            modelMap.put("b2cShopperbi", b2cShopperbi);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }
        return "shopPerbi/shopPerbiUpdateBank";
    }

    /**
     * 查看商户详情
     *
     * @param request
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=queryShopPerbiTerminal")
    @FormToken(save = true)
    public String queryShopPerbiTerminal(HttpServletRequest request,
                                         ModelMap modelMap, B2cShopperbiTemp b2cShopperbi,
                                         B2cShopperbargain b2cShopperbargain,
                                         ShopPerbiForm mbForm) throws Exception {
        try {
            List<HashMap> Tershopper = null;
            List<HashMap> binderNum = null;
            String shopPerbiregId = request.getParameter("shopperpriId");
            String agentNo = request.getParameter("AgentNO");
            if (!StringUtils.isEmpty(agentNo)) {
                List<HashMap> agentNum = shopPerbiService.selectAgentNum(agentNo);
                modelMap.put("agentNum", agentNum);
            }
            if (shopPerbiregId == null || StringUtils.isEmpty(shopPerbiregId)) {
                shopPerbiregId = b2cShopperbi.getShopperid().toString();
            }
            if (StringUtils.isEmpty(shopPerbiregId)) {
                request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiManageList");
            } else {
                b2cShopperbi = shopPerbiService.queryShopPerbi(shopPerbiregId);
                Tershopper = shopPerbiService.shopperB2cTermBinder(shopPerbiregId);
                binderNum = shopPerbiService.selectBinderNum(shopPerbiregId);
            }
            if (b2cShopperbi != null) {
                //获取代理商
                Long shopperId = b2cShopperbi.getShopperidP();
                if (shopperId != null) {
                    Agent agent = shopPerbiService.searchAgent(shopperId);
                    modelMap.put("agentName", agent.getScompany());
                    modelMap.put("agentId", agent.getShopperid());
                }
            }
            String b2cTermBinderNo = "";
            if (binderNum.size() > 0) {
                for (int i = 0; i < binderNum.size(); i++) {
                    b2cTermBinderNo += binderNum.get(i).get("TERMINALID") + ",";
                }
                b2cTermBinderNo = b2cTermBinderNo.substring(0, b2cTermBinderNo.length() - 1);
            }
            modelMap.put("b2cShopperbi", b2cShopperbi);
            modelMap.put("Tershopper", Tershopper);
            request.getSession().setAttribute(Constants.SESSION_KEY_SHOPPER, b2cTermBinderNo);
            log.debug(request.getSession().getAttribute(Constants.SESSION_KEY_SHOPPER));
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }


        return "shopPerbi/bindTerminal";
    }

    /**
     * 查看商户详情
     *
     * @param request
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=queryShopPerbiDetails")
    @FormToken(save = true)
    public String queryShopPerbiDetails(HttpServletRequest request,
                                        ModelMap modelMap, B2cShopperbiTemp b2cShopperbi,
                                        B2cShopperbargainTemp b2cShopperbargain,
                                        ShopPerbiForm mbForm) throws Exception {
        try {
            String shopPerbiregId = request.getParameter("shopperpriId");
            String terCount = "0";
            if (StringUtils.isEmpty(shopPerbiregId)) {
                request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiManageList");
            } else {
                b2cShopperbi = shopPerbiService.queryShopPerbi(shopPerbiregId);
            }
            //获取当前绑定终端的个数
            terCount = shopPerbiService.selectTerminalCount(shopPerbiregId);
            request.setAttribute("terCount", terCount);
            //获取当前商户绑定的终端
            List<HashMap> terminalInfo = shopPerbiService.shopperB2cTermBinder(shopPerbiregId);
            request.setAttribute("terminalInfo", terminalInfo);
            //获取省
            List<Area> Provincial = shopPerbiService.searchProvince();
            request.setAttribute("Provincial", Provincial);
            //获取市
            List<Area> list = shopPerbiService.searchArea();
            request.setAttribute("area", list);
            //获取银行
            B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval());
            request.setAttribute("bankName", dicbank);

            //代理商
            String path = request.getSession().getServletContext().getContextPath();
            request.setAttribute("agentlist", path + "agent/selectAgentTree.htm");

            if (b2cShopperbi != null) {
                //获取代理商
                Long shopperId = b2cShopperbi.getShopperidP();
                if (shopperId != null) {
                    Agent agent = shopPerbiService.searchAgent(shopperId);
                    modelMap.put("agentName", agent.getScompany());
                    modelMap.put("agentId", agent.getShopperid());
                }
            }

            Long photoid = b2cShopperbi.getPhotoid();
            if (photoid != null) {
                MposPhotoTmp photo = shopPerbiService.selectPhotoTmpById(photoid);
                modelMap.put("photo", photo);
            }
            modelMap.put("image_get_url", DynamicConfigLoader.getByEnv("imageget.url"));
            modelMap.put("feeList", shopPerbiService.selectFeeByShopperid1(b2cShopperbi.getShopperid()));
            modelMap.put("b2cShopperbi", b2cShopperbi);


        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }


        return "shopPerbi/shopPerbiCheckDetails";
    }

    /**
     * 查看商户详情
     *
     * @param request
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=ShopPerbiinfoDetails")
    @FormToken(save = true)
    public String ShopPerbiinfoDetails(HttpServletRequest request,
                                       ModelMap modelMap, B2cShopperbiTemp b2cShopperbi,
                                       B2cShopperbargainTemp b2cShopperbargain,
                                       ShopPerbiForm mbForm) throws Exception {
        try {
            String shopPerbiregId = request.getParameter("shopperpriId");
            String terCount = "0";
            if (StringUtils.isEmpty(shopPerbiregId)) {
                request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiManageList");
            } else {
                b2cShopperbi = shopPerbiService.queryShopPerbi(shopPerbiregId);
            }
            //获取当前绑定终端的个数
            terCount = shopPerbiService.selectTerminalCount(shopPerbiregId);
            request.setAttribute("terCount", terCount);
            //获取当前商户绑定的终端
            List<HashMap> terminalInfo = shopPerbiService.shopperB2cTermBinder(shopPerbiregId);
            request.setAttribute("terminalInfo", terminalInfo);
            //获取省
            List<Area> Provincial = shopPerbiService.searchProvince();
            request.setAttribute("Provincial", Provincial);
            //获取市
            List<Area> list = shopPerbiService.searchArea();
            request.setAttribute("area", list);
            //获取银行
            B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval());
            request.setAttribute("bankName", dicbank);

            //代理商
            String path = request.getSession().getServletContext().getContextPath();
            request.setAttribute("agentlist", path + "agent/selectAgentTree.htm");
            //代理商手续费底价
            String agentMccName = "";
            if (b2cShopperbi != null) {
                //获取代理商
                Long shopperId = b2cShopperbi.getShopperidP();
                if (shopperId != null) {
                    Agent agent = shopPerbiService.searchAgent(shopperId);
                    modelMap.put("agentName", agent.getScompany());
                    modelMap.put("agentId", agent.getShopperid());
                }
            }
            Long photoid = b2cShopperbi.getPhotoid();
            if (photoid != null) {

                MposPhotoTmp photo = shopPerbiService.selectPhotoTmpById(photoid);
                modelMap.put("photo", photo);
                modelMap.put("image_get_url", DynamicConfigLoader.getByEnv("imageget.url"));
            }

            modelMap.put("feeList", shopPerbiService.selectFeeByShopperid1(b2cShopperbi.getShopperid()));
            modelMap.put("agentMccName", agentMccName);
            modelMap.put("b2cShopperbi", b2cShopperbi);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }


        return "shopPerbi/shopPerbiInfoDetails";
    }

    /**
     * 查看商户详情
     *
     * @param request
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=updateShopPerbiDetails")
    @FormToken(save = true)
    public String updateShopPerbiDetails(HttpServletRequest request,
                                         ModelMap modelMap, B2cShopperbiTemp b2cShopperbi,
                                         B2cShopperbargainTemp b2cShopperbargain,
                                         ShopPerbiForm mbForm) throws Exception {
        try {
            String shopPerbiregId = request.getParameter("shopperpriId");
            String terCount = "0";
            if (StringUtils.isEmpty(shopPerbiregId)) {
                request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiManageList");
            } else {
                b2cShopperbi = shopPerbiService.queryShopPerbi(shopPerbiregId);
            }
            //获取当前绑定终端的个数
            terCount = shopPerbiService.selectTerminalCount(shopPerbiregId);
            request.setAttribute("terCount", terCount);
            //获取当前商户绑定的终端
            List<HashMap> terminalInfo = shopPerbiService.shopperB2cTermBinder(shopPerbiregId);
            request.setAttribute("terminalInfo", terminalInfo);
            //获取省
            List<Area> Provincial = shopPerbiService.searchProvince();
            request.setAttribute("Provincial", Provincial);
            //获取市
            List<Area> list = shopPerbiService.searchArea();
            request.setAttribute("area", list);
            //获取银行
            B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval());
            request.setAttribute("bankName", dicbank);

            //代理商
            String path = request.getSession().getServletContext().getContextPath();
            request.setAttribute("agentlist", path + "agent/selectAgentTree.htm");

            if (b2cShopperbi != null) {
                //获取代理商
                Long shopperId = b2cShopperbi.getShopperidP();
                if (shopperId != null) {
                    Agent agent = shopPerbiService.searchAgent(shopperId);
                    modelMap.put("agentName", agent.getScompany());
                    modelMap.put("agentId", agent.getShopperid());
                }
            }

            modelMap.put("b2cShopperbi", b2cShopperbi);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }


        return "shopPerbi/shopPerbiUpdateDetails";
    }

    /**
     * 查看商户详情
     *
     * @param request
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=queryShopPerbiFormalDetails")
    @FormToken(save = true)
    public String queryShopPerbiFormalDetails(HttpServletRequest request,
                                              ModelMap modelMap, B2cShopperbi b2cShopperbi,
                                              B2cShopperbargain b2cShopperbargain,
                                              ShopPerbiForm mbForm) throws Exception {
        try {
            B2cShopperbiTemp Shopperbi = new B2cShopperbiTemp();
            String shopPerbiregId = request.getParameter("shopperpriId");
            String terCount = "0";
            if (StringUtils.isEmpty(shopPerbiregId)) {
                request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiManageList");
            } else {
                b2cShopperbi = shopPerbiService.queryFormalShopPerbi(shopPerbiregId);
                /*b2cShopperbargain=shopPerbiService.queryFormalShopPerbargain(shopPerbiregId);*/
                Shopperbi = shopPerbiService.queryShopPerbi(shopPerbiregId);
            }

            request.setAttribute("Shopperbi", Shopperbi);
            //用户名
            Users users = shopPerbiService.selectByUserId(shopPerbiregId);
            request.setAttribute("merchant", users);
            //获取当前商户绑定的终端
            List<HashMap> terminalInfo = shopPerbiService.shopperB2cTermBinder(shopPerbiregId);
            request.setAttribute("terminalInfo", terminalInfo);
            //获取省
            List<Area> Provincial = shopPerbiService.searchProvince();
            request.setAttribute("Provincial", Provincial);
            //获取市
            List<Area> list = shopPerbiService.searchArea();
            request.setAttribute("area", list);
            //获取银行
            B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval());
            request.setAttribute("bankName", dicbank);

            //代理商
            String path = request.getSession().getServletContext().getContextPath();
            request.setAttribute("agentlist", path + "agent/selectAgentTree.htm");

            if (b2cShopperbi != null) {
                //获取代理商
                Long shopperId = b2cShopperbi.getShopperidP();
                if (shopperId != null) {
                    Agent agent = shopPerbiService.searchAgent(shopperId);
                    modelMap.put("agentName", agent.getScompany());
                    modelMap.put("agentId", agent.getShopperid());
                }
            }

            modelMap.put("b2cShopperbi", b2cShopperbi);
            modelMap.put("feeList", shopPerbiService.selectFeeByShopperid(b2cShopperbi.getShopperid()));

            if (b2cShopperbi.getMerchProfitRatio2() != null && b2cShopperbi.getMerchProfitRatio3() != null) {
                //分润方案2
                String[] split2 = b2cShopperbi.getMerchProfitRatio2().split("\\|");
                //分润方案3
                String[] split3 = b2cShopperbi.getMerchProfitRatio3().split("\\|");
                request.setAttribute("split2", split2);
                request.setAttribute("split3", split3);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }


        return "shopPerbi/shopPerbiFormalDetails";
    }

    /**
     * 审核商户信息变更
     *
     * @param request
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=queryShopPerbiCheck")
    @FormToken(save = true)
    public String queryShopPerbiCheck(HttpServletRequest request,
                                      ModelMap modelMap, B2cShopperbiTemp b2cShopperbi,
                                      B2cShopperbargainTemp b2cShopperbargain,
                                      ShopPerbiForm mbForm) throws Exception {
        try {
            String shopPerbiregId = request.getParameter("shopperpriId");
            if (StringUtils.isEmpty(shopPerbiregId)) {
                request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiCheckList");
            } else {
                b2cShopperbi = shopPerbiService.queryShopPerbi(shopPerbiregId);
            }
            //获取省
            List<Area> Provincial = shopPerbiService.searchProvince();
            request.setAttribute("Provincial", Provincial);
            //获取市
            List<Area> list = shopPerbiService.searchArea();
            request.setAttribute("area", list);
            //获取银行
            B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval());
            request.setAttribute("bankName", dicbank);
            Long photoid = b2cShopperbi.getPhotoid();
            if (photoid != null) {
                MposPhotoTmp photo = shopPerbiService.selectPhotoTmpById(photoid);
                modelMap.put("photo", photo);
                modelMap.put("image_get_url", DynamicConfigLoader.getByEnv("imageget.url"));
            }

            //代理商
            String path = request.getSession().getServletContext().getContextPath();
            request.setAttribute("agentlist", path + "agent/selectAgentTree.htm");

            if (b2cShopperbi != null) {
                //获取代理商
                Long shopperId = b2cShopperbi.getShopperidP();
                if (shopperId != null) {
                    Agent agent = shopPerbiService.searchAgent(shopperId);
                    modelMap.put("agentName", agent.getScompany());
                    modelMap.put("agentId", agent.getShopperid());
                }
            }
            modelMap.put("feeList", shopPerbiService.selectFeeByShopperid1(b2cShopperbi.getShopperid()));
            modelMap.put("b2cShopperbi", b2cShopperbi);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }
        return "shopPerbi/shopPerbiDetails";
    }

    /**
     * 审核商户信息变更
     *
     * @param request
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=updateBankdetails")
    @FormToken(save = true)
    public String updateBankdetails(HttpServletRequest request,
                                    ModelMap modelMap, B2cShopperbiTemp b2cShopperbi,
                                    B2cShopperbargainTemp b2cShopperbargain,
                                    ShopPerbiForm mbForm) throws Exception {
        try {
            String shopPerbiregId = request.getParameter("shopperpriId");
            if (StringUtils.isEmpty(shopPerbiregId)) {
                request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiCheckList");
            } else {
                b2cShopperbi = shopPerbiService.queryShopPerbi(shopPerbiregId);
            }
            //获取省
            List<Area> Provincial = shopPerbiService.searchProvince();
            request.setAttribute("Provincial", Provincial);
            //获取市
            List<Area> list = shopPerbiService.searchArea();
            request.setAttribute("area", list);
            //获取银行
            B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval());
            request.setAttribute("bankName", dicbank);
            //代理商
            String path = request.getSession().getServletContext().getContextPath();
            request.setAttribute("agentlist", path + "agent/selectAgentTree.htm");
            if (b2cShopperbi != null) {
                //获取代理商
                Long shopperId = b2cShopperbi.getShopperidP();
                if (shopperId != null) {
                    Agent agent = shopPerbiService.searchAgent(shopperId);
                    modelMap.put("agentName", agent.getScompany());
                    modelMap.put("agentId", agent.getShopperid());
                }
            }
            modelMap.put("b2cShopperbi", b2cShopperbi);
            /*modelMap.put("b2cShopperbargain", b2cShopperbargain);*/
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }


        return "shopPerbi/shopPerbiBankInfo";
    }

    /**
     * 审核商户信息变更
     *
     * @param request
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=queryCheckBank")
    @FormToken(save = true)
    public String queryCheckBank(HttpServletRequest request,
                                 ModelMap modelMap, B2cShopperbiTemp b2cShopperbi,
                                 B2cShopperbargainTemp b2cShopperbargain,
                                 ShopPerbiForm mbForm) throws Exception {
        try {
            String shopPerbiregId = request.getParameter("shopperpriId");
            if (StringUtils.isEmpty(shopPerbiregId)) {
                request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiCheckList");
            } else {
                b2cShopperbi = shopPerbiService.queryShopPerbi(shopPerbiregId);
            }
            //获取省
            List<Area> Provincial = shopPerbiService.searchProvince();
            request.setAttribute("Provincial", Provincial);
            //获取市
            List<Area> list = shopPerbiService.searchArea();
            request.setAttribute("area", list);
            //获取银行
            B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval());
            request.setAttribute("bankName", dicbank);
            //代理商
            String path = request.getSession().getServletContext().getContextPath();
            request.setAttribute("agentlist", path + "agent/selectAgentTree.htm");
            if (b2cShopperbi != null) {
                //获取代理商
                Long shopperId = b2cShopperbi.getShopperidP();
                if (shopperId != null) {
                    Agent agent = shopPerbiService.searchAgent(shopperId);
                    modelMap.put("agentName", agent.getScompany());
                    modelMap.put("agentId", agent.getShopperid());
                }
            }

            modelMap.put("b2cShopperbi", b2cShopperbi);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }


        return "shopPerbi/shopPerbiBankDetails";
    }

    /**
     * 商户信息开户信息修改后的信息
     *
     * @param request
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=queryBankinfo")
    @FormToken(save = true)
    public String queryBankinfo(HttpServletRequest request,
                                ModelMap modelMap, B2cShopperbi b2cShopperbi,
                                B2cShopperbargain b2cShopperbargain,
                                ShopPerbiForm mbForm) throws Exception {
        try {
            B2cShopperbiTemp shopper = new B2cShopperbiTemp();
            String shopPerbiregId = request.getParameter("shopperpriId");
            if (StringUtils.isEmpty(shopPerbiregId)) {
                request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiCheckList");
            } else {
                b2cShopperbi = shopPerbiService.queryFormalShopPerbi(shopPerbiregId);
                shopper = shopPerbiService.queryShopPerbi(shopPerbiregId);
            }
            request.setAttribute("shopper", shopper);
            //获取省
            List<Area> Provincial = shopPerbiService.searchProvince();
            request.setAttribute("Provincial", Provincial);
            //获取市
            List<Area> list = shopPerbiService.searchArea();
            request.setAttribute("area", list);
            //获取银行
            B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval());
            request.setAttribute("bankName", dicbank);
            //代理商
            String path = request.getSession().getServletContext().getContextPath();
            request.setAttribute("agentlist", path + "agent/selectAgentTree.htm");
            if (b2cShopperbi != null) {
                //获取代理商
                Long shopperId = b2cShopperbi.getShopperidP();
                if (shopperId != null) {
                    Agent agent = shopPerbiService.searchAgent(shopperId);
                    modelMap.put("agentName", agent.getScompany());
                    modelMap.put("agentId", agent.getShopperid());
                }
            }

            modelMap.put("b2cShopperbi", b2cShopperbi);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }


        return "shopPerbi/shopPerbiBkupdateDetails";
    }

    /**
     * 审核终端信息变更
     *
     * @param request
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=queryCheckTerminal")
    @FormToken(save = true)
    public String queryCheckTerminal(HttpServletRequest request,
                                     ModelMap modelMap, B2cShopperbiTemp b2cShopperbi,
                                     B2cShopperbargainTemp b2cShopperbargain,
                                     ShopPerbiForm mbForm) throws Exception {
        try {
            String shopPerbiregId = request.getParameter("shopperpriId");
            if (StringUtils.isEmpty(shopPerbiregId)) {
                request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url", "shopPerbi.htm?method=");
            } else {
                b2cShopperbi = shopPerbiService.queryShopPerbi(shopPerbiregId);
            }

            //获取省
            List<Area> Provincial = shopPerbiService.searchProvince();
            request.setAttribute("Provincial", Provincial);
            //获取市
            List<Area> list = shopPerbiService.searchArea();
            request.setAttribute("area", list);
            //代理商
            String path = request.getSession().getServletContext().getContextPath();
            request.setAttribute("agentlist", path + "agent/selectAgentTree.htm");
            if (b2cShopperbi != null) {
                //获取代理商
                Long shopperId = b2cShopperbi.getShopperidP();
                if (shopperId != null) {
                    Agent agent = shopPerbiService.searchAgent(shopperId);
                    modelMap.put("agentName", agent.getScompany());
                    modelMap.put("agentId", agent.getShopperid());
                }
            }

            modelMap.put("b2cShopperbi", b2cShopperbi);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }
        return "shopPerbi/shopPerbiCheckTerminal";
    }

    /**
     * 保存商户基本信息
     *
     * @param request
     * @param response
     * @param modelMap
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param mbForm
     * @return
     * @throws IOException
     * @throws BusinessException
     */
    @RequestMapping(params = "method=saveShopPerbiupdateList")
    @FormToken(remove = true)
    public String saveShopPerbiupdateList(HttpServletRequest request, B2cShopperbiTemp b2cShopperbi, B2cShopperbargainTemp b2cShopperbargain,
                                          ShopPerbiForm mbForm) throws Exception, BusinessException {
        try {
            String shopperpriIds = request.getParameter("shopperpriIds");

            if (StringUtils.isEmpty(shopperpriIds)) {
                request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiCheckList");
            } else {

                if (b2cShopperbi.getProvince() != null) {
                    List searchProvincialList = shopPerbiService.searchProvincial(b2cShopperbi.getProvince());
                    if (searchProvincialList != null && searchProvincialList.size() > 0) {
                        Area spro = (Area) searchProvincialList.get(0);
                        if (spro != null) {
                            String sprov = spro.getProvincialname();
                            b2cShopperbi.setSprovince(sprov);
                        }
                    }
                }
                if (b2cShopperbi.getCity() != null) {
                    List cityList = shopPerbiService.searchCity(b2cShopperbi.getCity());
                    if (cityList != null && cityList.size() > 0) {
                        Area area = (Area) cityList.get(0);
                        if (area != null) {
                            String cityName = (String) area.getCityname();
                            b2cShopperbi.setScity(cityName);
                        }
                    }
                }


                if (b2cShopperbi.getBillProvinceCode() != null) {
                    List searchProvincialList = shopPerbiService.searchProvincial(b2cShopperbi.getBillProvinceCode());
                    if (searchProvincialList != null && searchProvincialList.size() > 0) {
                        Area spro = (Area) searchProvincialList.get(0);
                        if (spro != null) {
                            String sprov = spro.getProvincialname();
                            b2cShopperbi.setBillProvince(sprov);
                        }
                    }
                }
                if (b2cShopperbi.getBillCityCode() != null) {
                    List cityList = shopPerbiService.searchCity(b2cShopperbi.getBillCityCode());
                    if (cityList != null && cityList.size() > 0) {
                        Area area = (Area) cityList.get(0);
                        if (area != null) {
                            String cityName = (String) area.getCityname();
                            b2cShopperbi.setBillCity(cityName);
                        }
                    }
                }
                String path = DynamicConfigLoader.getByEnv("basePath.url");
                B2cShopperbiTemp shopper = shopPerbiService.queryShopPerbi(shopperpriIds);
                if (shopper.getIsformal().toString().equals("1")) {
                    b2cShopperbi.setIsupdateshopper(new Short("1"));//修改的标准
                }
                b2cShopperbi.setIfagent(new Long(0));//0为商户，1为代理商
                b2cShopperbi.setShopperidP(mbForm.getShopperid_p());
                b2cShopperbi.setUpdated(new Date());
                b2cShopperbi.setIfvalid(new Short("0"));

                //修改时修改审核状态
                b2cShopperbi.setIfvalid(Short.valueOf(Constants.CON_NO));//初审记录
                b2cShopperbi.setRecheckmerchantflag(Constants.CON_NO);//复核
                b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
                //将复核标志改成0
                b2cShopperbi.setRecheckmerchantflag("0");
                b2cShopperbi.setRecheckmerchantremark("");
                //验证用户名密码是否改变
                String pwds = request.getParameter("pwd");
                String passwords = request.getParameter("mpasswordHidden");
                String userName = request.getParameter("uname");
                String hiddenName = request.getParameter("userNameHidden");
                String bAgentId = mbForm.getShopperidq();
                //如果改变代理商，要删除以前绑定的终端 800110000015766

                if (shopper.getShopperidP() != null) {
                    if (bAgentId.equals(b2cShopperbi.getShopperidP().toString())) {
                        shopPerbiService.updateByShopperId(b2cShopperbi);
                    } else {
                        shopPerbiService.updateByB2cShopperId(b2cShopperbi, b2cShopperbargain, shopperpriIds);
                    }
                }
                if (shopper.getOrgNo() != null) {
                    shopPerbiService.updateByShopperId(b2cShopperbi);
                }

            }
            mbForm.setBelongsAgent(null);
            request.setAttribute(Constants.MESSAGE_KEY, "修改成功!");
            request.setAttribute("url", "shopPerbi.htm?method=shopPerbiManageList");
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.保存商户修改信息失败);
        }

        return "/returnPage";
    }

    /**
     * 修改商户开户行信息
     *
     * @param request
     * @param response
     * @param modelMap
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param mbForm
     * @return
     * @throws IOException
     * @throws BusinessException
     */
    @RequestMapping(params = "method=UpdateBankInfo")
    @FormToken(remove = true)
    public String UpdateBankInfo(HttpServletRequest request,
                                 HttpServletResponse response, ModelMap modelMap,
                                 B2cShopperbiTemp b2cShopperbi, B2cShopperbargainTemp b2cShopperbargain,
                                 ShopPerbiForm mbForm) throws Exception, BusinessException {
        try {

            String shopperpriIds = request.getParameter("shopperpriIds");
            b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
            B2cShopperbiTemp shopper = shopPerbiService.queryShopPerbi(shopperpriIds);
            //根据记录获取代理商
            b2cShopperbi.setShopperidP(shopper.getShopperidP());
            b2cShopperbi.setScompany(shopper.getScompany());
			/*Area ares=shopPerbiService.searchBankProvincial(b2cShopperbi.getAccountbankprov());
			if(ares!=null){
				b2cShopperbi.setAccountbankprov(ares.getProvincialname());
			}*/

            //修改开户银行地址省份信息
            if (b2cShopperbi.getAccountbankprov() != null) {
                List provinceList = shopPerbiService.searchProvincial(b2cShopperbi.getAccountbankprov());
                if (provinceList != null && provinceList.size() > 0) {
                    Area area = (Area) provinceList.get(0);
                    if (area != null) {
                        b2cShopperbi.setAccountbankprov(area.getProvincialname());
                        b2cShopperbi.setAccountBankProvCode(area.getProvincial());
                    }
                }
            }

            //修改开户银行地址城市信息
            if (b2cShopperbi.getAccountBankCity() != null) {
                List cityList = shopPerbiService.searchCity(b2cShopperbi.getAccountBankCity());
                if (cityList != null && cityList.size() > 0) {
                    Area area = (Area) cityList.get(0);
                    if (area != null) {
                        b2cShopperbi.setAccountBankCity(area.getCityname());
                        b2cShopperbi.setAccountBankCityCode(area.getCity());
                    }
                }
            }

            b2cShopperbi.setBankUpdateDate(new Date());

            //修改时修改审核状态
            b2cShopperbi.setOpencheckstatus(new Short("0"));//开户信息 初审
            b2cShopperbi.setRecheckaccountflag(Constants.CON_NO);//开户信息 复核

            //b2cShopperbi.setIfvalid(Short.valueOf(Constants.CON_NO));//初审记录
            //b2cShopperbi.setRecheckmerchantflag(Constants.CON_NO);//复核

            if (shopper.getIsformal().toString().equals("1")) {
                b2cShopperbi.setIsupdatebank(new Short("1"));
            }
            //修改之前备份数据
            BackupsShopperInformation bk = shopPerbiService.findbkshopper(new BigDecimal(shopperpriIds));
            BackupsShopperInformation bkshopper = new BackupsShopperInformation();
            MposMerchantFee merchantfee = this.shopPerbiService.querymerchantfee(shopperpriIds);
            //备份开户信息以及手续费信息 如果数据不存在 插入一条数据
            if (bk == null) {
                bkshopper.setCreateUser(((Operator) request.getSession().getAttribute(Constants.SESSION_KEY_USER)).getId().toString());
                bkshopper.setCreateDate(new Date());
                bkshopper.setT0fee(new BigDecimal(shopper.getT0fee() == null ? 0.0 : shopper.getT0fee()));
                bkshopper.setT0topamount(new BigDecimal(shopper.getT0topamount() == null ? 0.0 : shopper.getT0topamount()));
                bkshopper.setShopperid(new BigDecimal(shopper.getShopperid() == null ? 0.0 : shopper.getShopperid()));
                bkshopper.setT0additionfee(new BigDecimal(shopper.getT0additionfee() == null ? 0.0 : shopper.getT0additionfee()));
                bkshopper.setT0fixedamount(new BigDecimal(shopper.getT0fixedamount() == null ? 0.0 : shopper.getT0fixedamount()));
                bkshopper.setT0maxamount(new BigDecimal(shopper.getT0maxamount() == null ? 0.0 : shopper.getT0maxamount()));
                bkshopper.setT0minamount(new BigDecimal(shopper.getT0minamount() == null ? 0.0 : shopper.getT0minamount()));
                bkshopper.setT0singledaylimit(new BigDecimal(shopper.getT0SingleDayLimit() == null ? 0.0 : shopper.getT0SingleDayLimit()));
                bkshopper.setT0type(shopper.getT0type() == null ? "" : shopper.getT0type());
                bkshopper.setAccountBankClientName(shopper.getAccountbankclientname() == null ? "" : shopper.getAccountbankclientname());
                bkshopper.setAccountBankDictval(shopper.getAccountbankdictval() == null ? "" : shopper.getAccountbankdictval());
                bkshopper.setAccountBankName(shopper.getAccountbankname() == null ? "" : shopper.getAccountbankname());
                bkshopper.setAccountBankNo(shopper.getAccountbankno() == null ? "" : shopper.getAccountbankno());
                bkshopper.setAccountBankProv(shopper.getAccountbankprov() == null ? "" : shopper.getAccountbankprov());
                bkshopper.setCardtype(shopper.getCardType() == null ? "" : shopper.getCardType());
                if (merchantfee.getFee() == null || merchantfee.getFee() == "") {
                    bkshopper.setFee(new BigDecimal(0.0));
                } else {
                    bkshopper.setFee(new BigDecimal(merchantfee.getFee()));
                }

                if (merchantfee.getTopAmount() == null || merchantfee.getTopAmount() == "") {
                    bkshopper.setTopAmount(new BigDecimal(0.0));
                } else {
                    bkshopper.setTopAmount(new BigDecimal(merchantfee.getTopAmount()));
                }

            }


            shopPerbiService.updateBankInfo(b2cShopperbi, bkshopper);
            request.setAttribute(Constants.MESSAGE_KEY, "修改成功!");
            request.setAttribute("url", "shopPerbi.htm?method=shopPerbiManageList");
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.保存商户修改信息失败);
        }
        return "/returnPage";
    }

    /**
     * 审核商户基本信息(保存):
     *
     * @param request
     * @param response
     * @param modelMap
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param mbForm
     * @return
     * @throws IOException
     * @throws BusinessException
     */
    @RequestMapping(params = "method=saveShopPerbiCheck")
    @FormToken(remove = true)
    public String saveShopPerbiCheck(HttpServletRequest request, ModelMap modelMap,
                                     B2cShopperbiTemp b2cShopperbi, B2cShopperbargainTemp b2cShopperbargain,
                                     ShopPerbiForm mbForm) throws Exception, BusinessException {
        try {
            String shopperpriIds = request.getParameter("shopperpriIds");
            if (mbForm.getIfvalid() != null && mbForm.getIfvalid().equals("1")) {
                if (mbForm.getWorktime() != null) {
                    b2cShopperbi.setWorktime(mbForm.getWorktime());
                    b2cShopperbi.setIfvalid(new Short("1"));//审核通过
                    b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
//					b2cShopperbi.setIsformal(new Short("1"));
                    b2cShopperbi.setIsupdateshopper(new Short("1"));
                    b2cShopperbi.setPhotoCheckFlag("1");
                    String remark = "审核通过";
                    b2cShopperbi.setCheckdate(new Date());
                    shopPerbiService.updateCheckShopper(b2cShopperbi, Constants.TYPE_2, Constants.TYPE_2, remark);
					/*B2cShopperbiTemp shopperbi=shopPerbiService.queryShopPerbi(shopperpriIds);
					shopPerbiService.updateShoppbi(shopperbi);*/
/*					String remark="审核通过";
					shopPerbiService.updateProgress(shopperpriIds,Constants.TYPE_2,Constants.TYPE_2,remark);*/
                } else {
                    //没有修改商户基本信息，
                    b2cShopperbi.setIfvalid(new Short("1"));//审核通过
                    b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
//					b2cShopperbi.setIsformal(new Short("1"));
                    b2cShopperbi.setIsupdateshopper(new Short("0"));
                    b2cShopperbi.setOpencheckstatus(new Short("1"));//开户行信息审核通过
                    b2cShopperbi.setPhotoCheckFlag("1");
                    String remark = "审核通过";
                    b2cShopperbi.setCheckdate(new Date());
                    shopPerbiService.updateCheckShopper(b2cShopperbi, Constants.TYPE_1, Constants.TYPE_2, remark);

//					shopPerbiService.updateProgress(shopperpriIds,Constants.TYPE_1,Constants.TYPE_2,remark);
					/*B2cShopperbiTemp shopperbi=shopPerbiService.queryShopPerbi(shopperpriIds);
					shopPerbiService.insertFormalB2cShopperbi(shopperbi);
					B2cShopperbargainTemp shopperbargian=shopPerbiService.queryShopPerbargain(shopperpriIds);
					shopPerbiService.insertFormalB2cShopperbargain(shopperbargian);*/
                }

            } else {
                b2cShopperbi.setIfvalid(new Short("2"));//审核不通过
                b2cShopperbi.setIsupdateshopper(new Short("0"));//商户审核不通过
                b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
                b2cShopperbi.setExamineresullt(mbForm.getExamineresullt());
                if (mbForm.getWorktime() != null) {
                    String remark = "审核不通过";
                    b2cShopperbi.setCheckdate(new Date());
                    shopPerbiService.updateCheckShopper(b2cShopperbi, Constants.TYPE_2, Constants.TYPE_3, remark);
//					shopPerbiService.updateProgress(shopperpriIds,Constants.TYPE_2,Constants.TYPE_3,remark);
                } else {
                    String remark = "审核不通过";
                    b2cShopperbi.setCheckdate(new Date());
                    shopPerbiService.updateCheckShopper(b2cShopperbi, Constants.TYPE_1, Constants.TYPE_3, remark);
//					shopPerbiService.updateProgress(shopperpriIds,Constants.TYPE_1,Constants.TYPE_3,remark);

                }
            }
            request.setAttribute(Constants.MESSAGE_KEY, "审核成功!");
            request.setAttribute("url", "shopPerbi.htm?method=shopPerbiCheckList");
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.审核失败);
        }
        return "/returnPage";

    }

    /**
     * 审核商户开户银行基本信息
     *
     * @param request
     * @param response
     * @param modelMap
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param mbForm
     * @return
     * @throws IOException
     * @throws BusinessException
     */
    @RequestMapping(params = "method=saveCheckBank")
    @FormToken(remove = true)
    public String saveCheckBank(HttpServletRequest request,
                                HttpServletResponse response, ModelMap modelMap,
                                B2cShopperbiTemp b2cShopperbi, B2cShopperbargainTemp b2cShopperbargain,
                                ShopPerbiForm mbForm) throws Exception, BusinessException {
        try {
            String openCheck = mbForm.getOpencheckstatus();
            if (openCheck.equals("1")) {
                String shopperpriIds = request.getParameter("shopperpriIds");
                b2cShopperbi.setOpencheckstatus(new Short("1"));//审核通过
                b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
                b2cShopperbi.setIsupdatebank(new Short("0"));
                b2cShopperbi.setRecheckaccountflag("0");
                String remark = "审核通过";
                shopPerbiService.updateCheckShopper(b2cShopperbi, Constants.TYPE_3, Constants.TYPE_2, remark);
//				shopPerbiService.updateCheckShopper(b2cShopperbi);
				/*String remark="审核通过";
				shopPerbiService.updateProgress(shopperpriIds,Constants.TYPE_3,Constants.TYPE_2,remark);
*/

				/*B2cShopperbiTemp shopper=shopPerbiService.queryShopPerbi(shopperpriIds);
				shopper.setOpencheckstatus(new Short("1"));
				shopPerbiService.updateFormalBank(shopper);*/

                request.setAttribute(Constants.MESSAGE_KEY, "审核成功!");
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiBankList");
            } else {
                String shopperpriIds = request.getParameter("shopperpriIds");
                b2cShopperbi.setOpencheckstatus(new Short(openCheck));//审核不通过
                b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
                b2cShopperbi.setIsupdatebank(new Short("0"));
                b2cShopperbi.setRecheckaccountflag("0");
                String remark = "审核不通过";
                //审核不通过数据还原
                BackupsShopperInformation bkshopper = shopPerbiService.findbkshopper(new BigDecimal(shopperpriIds));
                b2cShopperbi.setAccountbankclientname(bkshopper.getAccountBankClientName());
                b2cShopperbi.setAccountbankdictval(bkshopper.getAccountBankDictval());
                b2cShopperbi.setAccountbankprov(bkshopper.getAccountBankProv());
                b2cShopperbi.setAccountbankname(bkshopper.getAccountBankName());
                b2cShopperbi.setAccountbankno(bkshopper.getAccountBankNo());

                shopPerbiService.updateCheckShopper(b2cShopperbi, Constants.TYPE_3, Constants.TYPE_3, remark);
				/*shopPerbiService.updateCheckShopper(b2cShopperbi);

				shopPerbiService.updateProgress(shopperpriIds,Constants.TYPE_3,Constants.TYPE_3,remark);
*/

                request.setAttribute(Constants.MESSAGE_KEY, "审核成功!");
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiBankList");
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.审核失败);
        }

        return "/returnPage";

    }


    /**
     * 审核终端信息
     *
     * @param request
     * @param response
     * @param modelMap
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param mbForm
     * @return
     * @throws IOException
     * @throws BusinessException
     */
    @RequestMapping(params = "method=saveCheckTermianl")
    @FormToken(remove = true)
    public String saveCheckTermianl(HttpServletRequest request,
                                    HttpServletResponse response, ModelMap modelMap,
                                    B2cShopperbiTemp b2cShopperbi, B2cShopperbargainTemp b2cShopperbargain,
                                    ShopPerbiForm mbForm) throws Exception, BusinessException {
        try {
            String shopperpriIds = request.getParameter("shopperpriIds");
            b2cShopperbi.setTermianlstatus(mbForm.getTermianlstatus());//审核通过,或者不通过
            b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
            shopPerbiService.updateTermianl(b2cShopperbi, shopperpriIds, mbForm.getTermianlstatus());
            request.setAttribute(Constants.MESSAGE_KEY, "审核成功!");
            request.setAttribute("url", "shopPerbi.htm?method=shopPerbiTerminalList");
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.审核失败);
        }

        return "/returnPage";

    }

    /**
     * 验证企业全称是否存在
     *
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping(params = "method=ajaxCheckScompany")
    public void ajaxCheckScompany(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            String scompany = request.getParameter("scompany");
            if (StringUtils.isTrimNotEmpty(scompany)) {
                scompany = scompany.trim();
            }
            B2cShopperbiTemp b2cShopperbi = shopPerbiService.findB2cShopperbiScompany(scompany);
            PrintWriter out = response.getWriter();
            try {
                if (b2cShopperbi != null) {
                    out.write("{\"x\":\"1\"}");
                } else {
                    out.write("{\"x\":\"2\"}");
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (out != null) {
                    out.flush();
                    out.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * 绑定终端
     *
     * @param request
     * @param modelMap
     * @param mbForm
     * @return
     * @throws BusinessException
     */
    @RequestMapping(params = "method=bindTerminal")
    @FormToken(save = true)
    public String bindTerminal(HttpServletRequest request, ModelMap modelMap, ShopPerbiForm mbForm) throws BusinessException {
        try {
            String shopperId = request.getParameter("shopperpriId");
            if (StringUtils.isEmpty(shopperId)) {
                modelMap.put("errorMsg", "id为空！");
                mbForm.setBelongsAgent(null);
                return shopPerbiManageList(request, modelMap, mbForm);
            } else {
                B2cShopperbiTemp b2cShopperbi = shopPerbiService.queryShopPerbi(shopperId);
                List<B2cTermBinder> list = null;
                List<B2cTermBinder> b2cTermBinderList = null;
                String b2cTermBinderNo = "";
                if (b2cShopperbi != null) {
                    //获取代理商
                    Long agentId = b2cShopperbi.getShopperidP();
                    if (shopperId != null) {
                        Agent agent = shopPerbiService.searchAgent(agentId);
                        modelMap.put("agentName", agent.getScompany());
                        modelMap.put("agentId", agent.getShopperid());
                    }
                    //查询出该代理商下面没有被挂载的pos终端
                    list = shopPerbiService.selectByB2cTermBinder(shopperId, b2cShopperbi.getShopperidP().toString());
                    b2cTermBinderList = shopPerbiService.selectByB2cTermBinderList(shopperId);
                    if (b2cTermBinderList.size() > 0) {
                        for (int i = 0; i < b2cTermBinderList.size(); i++) {
                            B2cTermBinder b2cTermBinders = b2cTermBinderList.get(i);
                            b2cTermBinderNo += b2cTermBinders.getTermNo() + ",";
                        }
                        b2cTermBinderNo = b2cTermBinderNo.substring(0, b2cTermBinderNo.length() - 1);
                    }
                }
                modelMap.put("b2cShopperbi", b2cShopperbi);
                modelMap.put("list", list);
                modelMap.put("b2cTermBinderNo", b2cTermBinderNo);
                return "shopPerbi/bindTerminal";
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户终端信息失败);
        }

    }

    /**
     * 保存商户--终端
     * 1.根据商户删除以前的终端，再添加现在的终端！
     *
     * @param request
     * @param modelMap
     * @param mbForm
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=saveBindTerminal")
    @FormToken(remove = true)
    public String saveBindTerminal(HttpServletRequest request, ModelMap modelMap, ShopPerbiForm mbForm) throws Exception {
        try {
            String shopperid = mbForm.getShopperidq();
            String bindTerminal = mbForm.getTerminalNum();
            if (StringUtils.isEmpty(shopperid) || StringUtils.isEmpty(bindTerminal)) {
                request.setAttribute(Constants.MESSAGE_KEY, "绑定失败，请重新绑定!");
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiManageList");
            } else {
                shopPerbiService.insertBindTerminal(shopperid, bindTerminal);
                request.setAttribute(Constants.MESSAGE_KEY, "绑定成功!");
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiManageList");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.商户终端信息绑定失败);
        }
        return "/returnPage";
    }

    /**
     * 保存商户--终端
     * 1.根据商户删除以前的终端，再添加现在的终端！
     *
     * @param request
     * @param modelMap
     * @param mbForm
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=saveTerminal")
    @FormToken(remove = true)
    public String saveTerminal(HttpServletRequest request, B2cShopperbargain b2cShopperbargain, ModelMap modelMap, ShopPerbiForm mbForm) throws Exception {
        try {
            String bindTerminal = mbForm.getTerminalNum();
            String hiddNum = mbForm.getHiddenNum();
            String shopPerbiregId = request.getParameter("shopPerbiregId");
            B2cShopperbiTemp shopperbi = new B2cShopperbiTemp();
            B2cShopperbiTemp shopper = shopPerbiService.queryShopPerbi(shopPerbiregId);
            List<HashMap> Tershopper = shopPerbiService.shopperB2cTermBinder(shopPerbiregId);
            if (StringUtils.isEmpty(bindTerminal) && StringUtils.isEmpty(shopPerbiregId)) {
                request.setAttribute(Constants.MESSAGE_KEY, "绑定失败，请重新绑定!");
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiManageList");
            } else {
                shopperbi.setShopperid(Long.valueOf(shopPerbiregId));
                shopperbi.setTermianlstatus("0");
                shopperbi.setRecheckterminalflag("0");
                shopperbi.setShopperidP(shopper.getShopperidP());
                shopperbi.setScompany(shopper.getScompany());
                shopPerbiService.updateTerminal(bindTerminal, hiddNum, shopperbi);

                request.setAttribute(Constants.MESSAGE_KEY, "绑定成功!");
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiManageList");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.商户终端信息绑定失败);
        }
        return "/returnPage";
    }


    /**
     * 生成编码
     *
     * @param area
     * @param mcc
     * @return
     * @throws Exception
     */
    public String getPosShopperId(String area, String mcc) throws Exception {
//        String organization="800";
        String organization = Constants.ORGANIZATION;
        String areacold = "";
        if (area.length() > 4) {
            areacold = area.substring(0, 4);
        } else {
            areacold = area;
        }
        String mcccold = "";
        if (mcc.length() == 1) {
            mcccold = "000" + mcc;
        } else {
            mcccold = "00" + mcc;
        }
        String merchantRadom = RandomStringUtils.randomNumeric(4);
        String posMerchantId = organization + areacold + mcccold + merchantRadom;
        B2cShopperbiTemp b2cShopperbi = shopPerbiService.queryShopPerbi(posMerchantId);
        if (b2cShopperbi != null) {
            return getPosShopperId(area, mcc);
        }
        return posMerchantId;
    }

    /**
     * 根据商户shopperid查询，代理商手续费底价（mcc）
     *
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping(params = "method=ajaxBaseCost")
    public void ajaxBaseCost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String shopperId = request.getParameter("shopperId");
        List list = agentMccService.searchAgentMccList(shopperId);
        PrintWriter out = null;
        try {
            out = response.getWriter();
            if (list != null && list.size() > 0) {
                out.println(JsonUtil.getJsonString4List(list));
            } else {
                out.println();
            }

        } catch (Exception e) {
            e.printStackTrace();
            if (out != null) {
                out.flush();
                out.close();
            }
        } finally {
            if (out != null) {
                out.flush();
                out.close();
            }
        }
    }

    /**
     * 查询商户的证照信息
     */
    @RequestMapping(params = "method=queryShopPerbiLicensePhoto")
    @FormToken(save = true)
    public String queryShopPerbiLicensePhoto(HttpServletRequest request,
                                             ModelMap modelMap, B2cShopperbiTemp b2cShopperbi) throws Exception {
        try {
            String shopPerbiregId = request.getParameter("shopperpriId");

            if (StringUtils.isEmpty(shopPerbiregId)) {
                request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiCheckList");
            } else {

                b2cShopperbi = shopPerbiService.queryShopPerbi(shopPerbiregId);
                Long photoid = b2cShopperbi.getPhotoid();
                MposPhotoTmp photo = shopPerbiService.selectPhotoTmpById(photoid);
                modelMap.put("photo", photo);
                modelMap.put("image_get_url", DynamicConfigLoader.getByEnv("imageget.url"));
            }
            modelMap.put("b2cShopperbi", b2cShopperbi);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }
        return "shopPerbi/shopPerbiUpdateLicensePhoto";
    }

    /**
     * 保存商户证照变更
     */
    @RequestMapping(params = "method=saveShopPerbiLicensePhoto")
    @FormToken(remove = true)
    public String saveShopPerbiLicensePhoto(HttpServletRequest request,
                                            ModelMap modelMap, B2cShopperbiTemp b2cShopperbi,
                                            ShopPerbiForm mbForm) throws Exception {
        String path = basePath;
        Map hashmap = new HashMap();
        try {

            String photoid = b2cShopperbi.getPhotoid().toString();
            if (photoid != null) {
                hashmap.put("photoid", photoid);
            }

            String shopperType = b2cShopperbi.getMerchantType();

            String uploadpath = request.getSession().getServletContext().getRealPath("/");
            String uploadpath1 = uploadpath + "image1.jpg";
            String uploadpath2 = uploadpath + "image2.jpg";
            String uploadpath3 = uploadpath + "image3.jpg";
            String uploadpath4 = uploadpath + "image4.jpg";
            String uploadpath5 = uploadpath + "image5.jpg";
            String uploadpath6 = uploadpath + "image6.jpg";
            String uploadpath7 = uploadpath + "image7.jpg";
            String uploadpath8 = uploadpath + "image8.jpg";
            String uploadpath9 = uploadpath + "image9.jpg";
			/*InputStream input1 = mbForm.getHandidentitycardphoto().getInputStream();
			ImageCompressUtil.saveMinPhoto(input1, uploadpath1, 800, 0.9d);
			InputStream input11 = new FileInputStream(uploadpath1);*/


            InputStream input1 = mbForm.getHandidentitycardphoto().getInputStream();
            int inputsize1 = inputsize(input1);

            if (inputsize1 != 0) {
                ImageCompressUtil.saveMinPhoto(input1, uploadpath1, 800, 0.9d);
                InputStream input11 = new FileInputStream(uploadpath1);
                String handIdentityCardPhoto = photoString(input11);
                hashmap.put("handIdentityCardPhoto", handIdentityCardPhoto.replace("+", "%2B"));
            }
            InputStream input2 = mbForm.getFrontidentitycardphoto().getInputStream();
            int inputsize2 = inputsize(input2);
            if (inputsize2 != 0) {
                ImageCompressUtil.saveMinPhoto(input2, uploadpath2, 800, 0.9d);
                InputStream input22 = new FileInputStream(uploadpath2);
                String frontIdentityCardPhoto = photoString(input22);
                hashmap.put("frontIdentityCardPhoto", frontIdentityCardPhoto.replace("+", "%2B"));
            }


            InputStream input3 = mbForm.getReverseidentitycardphoto().getInputStream();
            int inputsize3 = inputsize(input3);
            if (inputsize3 != 0) {
                ImageCompressUtil.saveMinPhoto(input3, uploadpath3, 800, 0.9d);
                InputStream input33 = new FileInputStream(uploadpath3);
                String reverseIdentityCardPhoto = photoString(input33);
                hashmap.put("reverseIdentityCardPhoto", reverseIdentityCardPhoto.replace("+", "%2B"));
            }


            InputStream input4 = mbForm.getStorephoto().getInputStream();
            int inputsize4 = inputsize(input4);
            if (inputsize4 != 0) {
                ImageCompressUtil.saveMinPhoto(input4, uploadpath4, 800, 0.9d);
                InputStream input44 = new FileInputStream(uploadpath4);
                String storePhoto = photoString(input44);
                hashmap.put("storePhoto", storePhoto.replace("+", "%2B"));
            }


            InputStream input7 = mbForm.getSignaturephoto().getInputStream();
            int inputsize7 = inputsize(input7);
            if (inputsize7 != 0) {
                ImageCompressUtil.saveMinPhoto(input7, uploadpath5, 800, 0.9d);
                InputStream input77 = new FileInputStream(uploadpath5);
                String signaturePhoto = photoString(input77);
                hashmap.put("signaturePhoto", signaturePhoto.replace("+", "%2B"));
            }


            InputStream input9 = mbForm.getCreditCardPhoto().getInputStream();
            int inputsize9 = inputsize(input9);
            if (inputsize9 != 0) {
                ImageCompressUtil.saveMinPhoto(input9, uploadpath6, 800, 0.9d);
                InputStream input99 = new FileInputStream(uploadpath6);
                String creditCardPhoto = photoString(input99);
                hashmap.put("creditCardPhoto", creditCardPhoto.replace("+", "%2B"));

            }

            InputStream input10 = mbForm.getSettlementCardPhoto().getInputStream();
            int inputsize10 = inputsize(input10);
            if (inputsize10 != 0) {
                ImageCompressUtil.saveMinPhoto(input10, uploadpath7, 800, 0.9d);
                InputStream input1010 = new FileInputStream(uploadpath7);
                String settlementCardPhoto = photoString(input1010);
                hashmap.put("settlementCardPhoto", settlementCardPhoto.replace("+", "%2B"));
            }


            InputStream input5 = mbForm.getInstorephoto() == null ? null : mbForm.getInstorephoto().getInputStream();

            if (input5 != null) {
                int inputsize5 = inputsize(input5);
                if (inputsize5 != 0) {
                    ImageCompressUtil.saveMinPhoto(input5, uploadpath8, 800, 0.9d);
                    InputStream input55 = new FileInputStream(uploadpath8);
                    String instorePhoto = photoString(input55);
                    hashmap.put("instorePhoto", instorePhoto.replace("+", "%2B"));
                }
            }


            InputStream input8 = mbForm.getLicensephoto().getInputStream();
            int inputsize8 = inputsize(input8);
            if (inputsize8 != 0) {
                ImageCompressUtil.saveMinPhoto(input8, uploadpath9, 800, 0.9d);
                InputStream input88 = new FileInputStream(uploadpath9);
                String licensePhoto = photoString(input88);
                hashmap.put("licensePhoto", licensePhoto.replace("+", "%2B"));
            }

            hashmap.put("photoid", photoid);
            hashmap.put("shopperType", shopperType);
            Map resultMap = HttpClientUtils.postRequestMap(DynamicConfigLoader.getByEnv("update.photo"), hashmap, Map.class);
            //插入图片，插入一条季度记录
            MposApplicationProgress ap = this.shopPerbiService.findMposApplicationProgress(b2cShopperbi.getShopperid().toString(), "5");
            MposApplicationProgress pro = new MposApplicationProgress();
            if (ap == null) {
                pro.setShopperid(mbForm.getShopperid());
                pro.setScompany(b2cShopperbi.getScompany());
                pro.setApplicationTheme("变更证照");
                pro.setApplicationType("5");
                pro.setCreateUser(((Operator) request.getSession().getAttribute(Constants.SESSION_KEY_USER)).getId());
                pro.setCreateDate(new Date());
                pro.setShopperidP(mbForm.getShopperid_p().toString());
                pro.setAgentName(shopPerbiService.searchAgent(Long.valueOf(mbForm.getShopperid_p())).getScompany());
                pro.setApplicationStatus("1");
                //b2cShopperbi.setIfvalid(Short.valueOf(Constants.CON_NO));//初审记录
                //b2cShopperbi.setRecheckmerchantflag(Constants.CON_NO);//复核
            }

            b2cShopperbi.setPhotoRecheckFlag(Constants.CON_NO);
            b2cShopperbi.setPhotoCheckFlag(Constants.CON_NO);
            //返回值得到photo
            JSONObject ob = null;
            ob = JSONObject.fromObject(resultMap);
            Map maphoto = (Map) ob.get("maphoto");
            shopPerbiService.updatePhoto1(maphoto, pro, b2cShopperbi, photoid);
            modelMap.put(Constants.MESSAGE_KEY, "修改成功!");
            modelMap.put("url", "shopPerbi.htm?method=shopPerbiManageList");
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.保存商户修改信息失败);
        }
        return "returnPage";
    }

    /**
     * 商户证照信息审核列表
     *
     * @param request
     * @param b2cShopperbiTmp
     * @param b2cShopperbargainTmp
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=shopPerbiPhotoList")
    public String shopPerbiPhotoList(HttpServletRequest request, ModelMap modelMap,
                                     ShopPerbiForm mbForm) throws Exception {
        try {
            //行业类型
            List cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
            request.setAttribute("cillinglist", cillinglist);
            List<HashMap> shopPerbilist = null;
            //判断商户编号是否为数字
            String shopperIdq = mbForm.getShopperidq();
            if (!StringUtils.isEmpty(shopperIdq)) {
                boolean b = isFigure(shopperIdq);
                if (!b) {
                    mbForm.setShopperidq("");
                }
            }
            if (mbForm.getSprovince() != null) {
                List searchProvincialList = shopPerbiService.searchProvincial(mbForm.getSprovince());
                if (searchProvincialList != null && searchProvincialList.size() > 0) {
                    Area spro = (Area) searchProvincialList.get(0);
                    if (spro != null) {
                        String sprov = spro.getProvincialname();
                        mbForm.setSprovince(sprov);
                    }
                }
            }
            if (mbForm.getCity() != null) {
                List cityList = shopPerbiService.searchCity(mbForm.getCity());
                if (cityList != null && cityList.size() > 0) {
                    Area area = (Area) cityList.get(0);
                    if (area != null) {
                        String cityName = (String) area.getCityname();
                        mbForm.setCity(cityName);
                    }
                }
            }
            shopPerbilist = shopPerbiService.ShopPerbiPhotoList(mbForm);
            modelMap.put("shopPerbilist", shopPerbilist);
            //获取省
            List<Area> Provincial = shopPerbiService.searchProvince();
            request.setAttribute("Provincial", Provincial);
            //获取市
            List<Area> list = shopPerbiService.searchArea();
            request.setAttribute("area", list);
            //获取未审核的商户个数
            String Shoppercount = shopPerbiService.selectCheckCount();
            request.setAttribute("Shoppercount", Shoppercount);

            request.setAttribute("belongsAgent", mbForm.getBelongsAgent());
        } catch (BusinessException e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.商户查询失败);
        }
        return "shopPerbi/shopPerbiPhoto";
    }

    /**
     * 审核证照信息信息变更
     *
     * @param request
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=queryShopPerbiPhoto")
    @FormToken(save = true)
    public String queryShopPerbiPhoto(HttpServletRequest request,
                                      ModelMap modelMap, B2cShopperbiTemp b2cShopperbi,
                                      B2cShopperbargainTemp b2cShopperbargain,
                                      ShopPerbiForm mbForm) throws Exception {
        try {
            String shopPerbiregId = request.getParameter("shopperpriId");
            if (StringUtils.isEmpty(shopPerbiregId)) {
                request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiCheckList");
            } else {
                b2cShopperbi = shopPerbiService.queryShopPerbi(shopPerbiregId);
            }
            MposPhotoTmp photo = shopPerbiService.selectPhotoTmpById(b2cShopperbi.getPhotoid());
            modelMap.put("photo", photo);
            modelMap.put("image_get_url", DynamicConfigLoader.getByEnv("imageget.url"));
            modelMap.put("b2cShopperbi", b2cShopperbi);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }
        return "shopPerbi/shopPerbiPhotoDetails";
    }

    /**
     * 审核证照信息信息变更
     *
     * @param request
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=ShopPerbiPhotoinfoDetails")
    @FormToken(save = true)
    public String ShopPerbiPhotoinfoDetails(HttpServletRequest request,
                                            ModelMap modelMap, B2cShopperbiTemp b2cShopperbi,
                                            B2cShopperbargainTemp b2cShopperbargain,
                                            ShopPerbiForm mbForm) throws Exception {
        try {
            String shopPerbiregId = request.getParameter("shopperpriId");
            if (StringUtils.isEmpty(shopPerbiregId)) {
                request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiCheckList");
            } else {
                b2cShopperbi = shopPerbiService.queryShopPerbi(shopPerbiregId);
            }
            MposPhotoTmp photo = shopPerbiService.selectPhotoTmpById(b2cShopperbi.getPhotoid());
            modelMap.put("photo", photo);
            modelMap.put("image_get_url", DynamicConfigLoader.getByEnv("imageget.url"));
            modelMap.put("b2cShopperbi", b2cShopperbi);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }
        return "shopPerbi/shopPerbiPhotoInfoDetails";
    }

    /**
     * 审核照片信息(保存):
     */
    @RequestMapping(params = "method=saveShopPerbiPhoto")
    @FormToken(remove = true)
    public String saveShopPerbiPhoto(HttpServletRequest request, ModelMap modelMap,
                                     B2cShopperbiTemp b2cShopperbi, B2cShopperbargainTemp b2cShopperbargain,
                                     ShopPerbiForm mbForm) throws Exception, BusinessException {
        try {
            String shopperpriIds = request.getParameter("shopperpriIds");
            b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
            if (b2cShopperbi.getPhotoCheckFlag() != null && "1".equals(b2cShopperbi.getPhotoCheckFlag())) {
                b2cShopperbi.setPhotoCheckFlag("1");
                String remark = "审核通过";
                shopPerbiService.updatephotoShopper(b2cShopperbi, Constants.TYPE_5, Constants.TYPE_2, remark);

            } else {
                b2cShopperbi.setPhotoCheckFlag("2");
                String remark = "审核不通过";
                shopPerbiService.updatephotoShopper(b2cShopperbi, Constants.TYPE_5, Constants.TYPE_3, remark);

            }
//			shopPerbiService.updateCheckShopper(b2cShopperbi);
            request.setAttribute(Constants.MESSAGE_KEY, "审核成功!");
            request.setAttribute("url", "shopPerbi.htm?method=shopPerbiCheckList");
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.审核失败);
        }
        return "/returnPage";

    }


    /**
     * 审核商户基本信息(保存):
     *
     * @param request
     * @param response
     * @param modelMap
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param mbForm
     * @return
     * @throws IOException
     * @throws BusinessException
     */
    @RequestMapping(params = "method=savedevicenum")
    @FormToken(remove = true)
    public String savedevicenum(HttpServletRequest request, ModelMap modelMap,
                                B2cShopperbiTemp b2cShopperbi, B2cShopperbargainTemp b2cShopperbargain,
                                ShopPerbiForm mbForm) throws Exception, BusinessException {
        try {
            String shopperpriIds = request.getParameter("shopperpriIds");
            if (mbForm.getIfvalid() != null && mbForm.getIfvalid().equals("1")) {
                b2cShopperbi.setIfvalid(new Short("1"));//审核通过
                b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
                b2cShopperbi.setIsupdateshopper(new Short("0"));
                b2cShopperbi.setOpencheckstatus(new Short("1"));//开户行信息审核通过
                String remark = "审核通过";
                shopPerbiService.updateCheckShopper(b2cShopperbi, Constants.TYPE_4, Constants.TYPE_2, remark);
            } else {
                b2cShopperbi.setIfvalid(new Short("2"));//审核不通过
                b2cShopperbi.setIsupdateshopper(new Short("0"));//商户审核不通过
                b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
                String remark = "审核不通过";
                shopPerbiService.updateCheckShopper(b2cShopperbi, Constants.TYPE_4, Constants.TYPE_3, remark);
            }
            request.setAttribute(Constants.MESSAGE_KEY, "审核成功!");
            request.setAttribute("url", "shopPerbi.htm?method=shopPerbiTerminalList");
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.审核失败);
        }
        return "/returnPage";

    }


    /**
     * 是否有重复的电话号码存在
     *
     * @param request
     * @param response
     * @throws
     * @throws IOException
     */
    @RequestMapping(params = "method=ajaxCheckTel")
    public void ajaxCheckTel(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            String stel = request.getParameter("stel");

            List list = null;
            if (StringUtils.isTrimNotEmpty(stel)) {
                stel = stel.trim();

                list = shopPerbiService.findbytel(stel);
            }
            PrintWriter out = response.getWriter();
            try {
                if ((list != null && list.size() > 0)) {
                    out.write("{\"x\":\"1\"}");
                } else {
                    out.write("{\"x\":\"2\"}");
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (out != null) {
                    out.flush();
                    out.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    /**
     * 验证 身份证是否有存在的
     *
     * @param request
     * @param response
     * @throws
     * @throws IOException
     */
    @RequestMapping(params = "method=ajaxsid")
    public void ajaxsid(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            String IDNo = request.getParameter("IDNo");

            List list = null;
            if (StringUtils.isTrimNotEmpty(IDNo)) {
                IDNo = IDNo.trim();

                list = shopPerbiService.findbysid(IDNo);
            }
            PrintWriter out = response.getWriter();
            try {
                if ((list != null && list.size() > 0)) {
                    out.write("{\"x\":\"1\"}");
                } else {
                    out.write("{\"x\":\"2\"}");
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (out != null) {
                    out.flush();
                    out.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    public String photoString(InputStream input1) throws IOException {
        byte[] data = null;
        // 读取图片字节数组
        try {
            data = new byte[input1.available()];
            input1.read(data);
            input1.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        String ss = Base64.encode(data);
        return ss;
    }

    /**
     * 复核未通过的记录删除
     * 1.删除商户临时表
     * 2.将远程邀请表，邀请数据撤回
     *
     * @param request
     * @param modelMap
     * @param mbForm
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=deleteShopperbi")
    public String deleteShopperbi(HttpServletRequest request, ModelMap modelMap,
                                  ShopPerbiForm mbForm, B2cShopperbiTemp b2cShopperbi) throws Exception {
        try {
            String shopperpriId = request.getParameter("shopperpriId");
            String delresult = request.getParameter("ysbScompany");


            if (org.apache.commons.lang.StringUtils.isNotEmpty(shopperpriId)) {
                B2cShopperbiTemp b2cShopperbiTemp = shopPerbiService.queryShopPerbi(shopperpriId);
                b2cShopperbiTemp.setYsbScompany(delresult);
                if (b2cShopperbiTemp != null) {
                    shopPerbiService.deleteShopperbi(b2cShopperbiTemp);
                    request.setAttribute(Constants.MESSAGE_KEY, "删除成功!");
                } else {
                    request.setAttribute(Constants.MESSAGE_KEY, "记录不存在!");
                }
            } else {
                request.setAttribute(Constants.MESSAGE_KEY, "id为空!");

            }
            request.setAttribute("url", "shopPerbi.htm?method=shopPerbiManageList");
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.删除用户失败);
        }
        return "/returnPage";
    }


    public int inputsize(InputStream input1) throws Exception {
        byte[] by = new byte[1000];
        int size = input1.available();
        if (size == 0) {
            System.out.println("文件为空!!");
            return size;
        }
        return 1;
    }


    /**
     * 删除信息
     *
     * @param request
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=delshopper")
    @FormToken(save = true)
    public String delshopper(HttpServletRequest request,
                             ModelMap modelMap, B2cShopperbiTemp b2cShopperbi,
                             B2cShopperbargainTemp b2cShopperbargain,
                             ShopPerbiForm mbForm) throws Exception {
        try {
            String shopPerbiregId = request.getParameter("shopperpriId");
            if (StringUtils.isEmpty(shopPerbiregId)) {
                request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiCheckList");
            } else {
                b2cShopperbi = shopPerbiService.queryShopPerbi(shopPerbiregId);
                /*b2cShopperbargain=shopPerbiService.queryShopPerbargain(shopPerbiregId);*/
            }
            //获取省
            List<Area> Provincial = shopPerbiService.searchProvince();
            request.setAttribute("Provincial", Provincial);
            //获取市
            List<Area> list = shopPerbiService.searchArea();
            request.setAttribute("area", list);
            //获取银行
            B2cDict dicbank = shopPerbiService.findBankName(b2cShopperbi.getAccountbankdictval());
            request.setAttribute("bankName", dicbank);
            Long photoid = b2cShopperbi.getPhotoid();
            if (photoid != null) {
                MposPhotoTmp photo = shopPerbiService.selectPhotoTmpById(photoid);
                modelMap.put("photo", photo);
                modelMap.put("image_get_url", DynamicConfigLoader.getByEnv("imageget.url"));
            }

            //代理商
            String path = request.getSession().getServletContext().getContextPath();
            request.setAttribute("agentlist", path + "agent/selectAgentTree.htm");

            if (b2cShopperbi != null) {
                //获取代理商
                Long shopperId = b2cShopperbi.getShopperidP();
                if (shopperId != null) {
                    Agent agent = shopPerbiService.searchAgent(shopperId);
                    modelMap.put("agentName", agent.getScompany());
                    modelMap.put("agentId", agent.getShopperid());
                }
            }
		      /*  //代理商手续费底价
		        String agentMccName="";
		        Long baseCostId=b2cShopperbargain.getBasecost();
		        if(baseCostId!=null){
			    	Map agentMccList=(HashMap)agentMccService.searchAgentMccById(baseCostId);
			        if(agentMccList!=null&&agentMccList.size()>0){
			            agentMccName=agentMccList.get("MCC_FEE").toString()+"	"+agentMccList.get("FIRM_NAME").toString()+"	底价	"+agentMccList.get("BASE_COST").toString();
			        }
		        }
		        if(b2cShopperbi!=null){
		        	//获取代理商
		            Long shopperId= b2cShopperbi.getShopperidP();
		            if(shopperId!=null){
		            	Agent agent=shopPerbiService.searchAgent(shopperId);
		                modelMap.put("agentName", agent.getScompany());
		                modelMap.put("agentId", agent.getShopperid());
		            }
		        }
		        modelMap.put("agentMccName", agentMccName);*/
            modelMap.put("feeList", shopPerbiService.selectFeeByShopperid1(b2cShopperbi.getShopperid()));
            modelMap.put("b2cShopperbi", b2cShopperbi);
            /* modelMap.put("b2cShopperbargain", b2cShopperbargain);*/
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }
        return "shopPerbi/delresult";
    }


    /**
     * 交易手续费T0手续费修改 zt
     *
     * @param request
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=transactionFeeUpdate")
    @FormToken(save = true)
    public String transactionFeeUpdate(HttpServletRequest request,
                                       ModelMap modelMap, B2cShopperbiTemp b2cShopperbi,
                                       B2cShopperbargainTemp b2cShopperbargain,
                                       ShopPerbiForm mbForm) throws Exception {
        try {
            String shopPerbiregId = request.getParameter("shopperpriId");
            UpdateFeeHistory feehis = null;

            if (StringUtils.isEmpty(shopPerbiregId)) {
                request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiCheckList");
            } else {
                b2cShopperbi = shopPerbiService.queryShopPerbi(shopPerbiregId);
                feehis = shopPerbiService.selectByfeeshopperid(Long.valueOf(shopPerbiregId));

            }
            if (feehis != null) {
                modelMap.put("feehis", "1");
            }
            MposMerchantFee mposMerchantFee = shopPerbiService.querymerchantfee(b2cShopperbi.getShopperid().toString());
            if (Constants.CON_NO.equals(b2cShopperbi.getCardType())) {
                request.setAttribute("fees", mposMerchantFee.getFee());
            } else {
                request.setAttribute("fees1", mposMerchantFee.getFee() + "-" + mposMerchantFee.getTopAmount());
            }
            request.setAttribute("b2cShopperbi", b2cShopperbi);


        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }
        return "shopPerbi/transactionFeeUpdate";
    }


    /**
     * 保存修改的手续费信息
     *
     * @param request
     * @param response
     * @param modelMap
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param mbForm
     * @return
     * @throws IOException
     * @throws BusinessException
     */
    @RequestMapping(params = "method=Updatefee")
    @FormToken(remove = true)
    public String Updatefee(HttpServletRequest request,
                            HttpServletResponse response, ModelMap modelMap,
                            B2cShopperbiTemp b2cShopperbi, B2cShopperbargainTemp b2cShopperbargain,
                            ShopPerbiForm mbForm) throws Exception, BusinessException {
        try {
            String shopperpriIds = request.getParameter("shopperpriIds");
            B2cShopperbiTemp shopper = shopPerbiService.queryShopPerbi(shopperpriIds);
            MposMerchantFee merchantfee = this.shopPerbiService.querymerchantfee(shopperpriIds);
            BackupsShopperInformation bk = shopPerbiService.findbkshopper(new BigDecimal(shopperpriIds));
            BackupsShopperInformation bkshopper = new BackupsShopperInformation();
            UpdateFeeHistory feehis1 = new UpdateFeeHistory();
            //备份开户信息以及手续费信息 如果数据不存在 插入一条数据
            if (bk == null) {
                bkshopper.setCreateUser(((Operator) request.getSession().getAttribute(Constants.SESSION_KEY_USER)).getId().toString());
                bkshopper.setCreateDate(new Date());
                bkshopper.setT0fee(new BigDecimal(shopper.getT0fee() == null ? 0.0 : shopper.getT0fee()));
                bkshopper.setT0topamount(new BigDecimal(shopper.getT0topamount() == null ? 0.0 : shopper.getT0topamount()));
                bkshopper.setShopperid(shopper.getShopperid() == null ? null : new BigDecimal(shopper.getShopperid()));
                bkshopper.setT0additionfee(new BigDecimal(shopper.getT0additionfee() == null ? 0.0 : shopper.getT0additionfee()));
                bkshopper.setT0fixedamount(new BigDecimal(shopper.getT0fixedamount() == null ? 0.0 : shopper.getT0fixedamount()));
                bkshopper.setT0maxamount(new BigDecimal(shopper.getT0maxamount() == null ? 0.0 : shopper.getT0maxamount()));
                bkshopper.setT0minamount(new BigDecimal(shopper.getT0minamount() == null ? 0.0 : shopper.getT0minamount()));
                bkshopper.setT0singledaylimit(new BigDecimal(shopper.getT0SingleDayLimit() == null ? 0.0 : shopper.getT0SingleDayLimit()));
                bkshopper.setT0type(shopper.getT0type() == null ? "" : shopper.getT0type());
                bkshopper.setAccountBankClientName(shopper.getAccountbankclientname() == null ? "" : shopper.getAccountbankclientname());
                bkshopper.setAccountBankDictval(shopper.getAccountbankdictval() == null ? "" : shopper.getAccountbankdictval());
                bkshopper.setAccountBankName(shopper.getAccountbankname() == null ? "" : shopper.getAccountbankname());
                bkshopper.setAccountBankNo(shopper.getAccountbankno() == null ? "" : shopper.getAccountbankno());
                bkshopper.setAccountBankProv(shopper.getAccountbankprov() == null ? "" : shopper.getAccountbankprov());
                bkshopper.setCardtype(shopper.getCardType() == null ? "" : shopper.getCardType());

                feehis1.setUpdateUser(((Operator) request.getSession().getAttribute(Constants.SESSION_KEY_USER)).getId().toString());
                feehis1.setT0fee(new BigDecimal(shopper.getT0fee() == null ? 0.0 : shopper.getT0fee()));
                feehis1.setT0type(shopper.getT0type() == null ? "" : shopper.getT0type());
                feehis1.setT0fixedamount(shopper.getT0fixedamount() == null ? null : new BigDecimal(shopper.getT0fixedamount()));
                feehis1.setT0maxamount(shopper.getT0maxamount() == null ? null : new BigDecimal(shopper.getT0maxamount()));
                feehis1.setT0minamount(shopper.getT0minamount() == null ? null : new BigDecimal(shopper.getT0minamount()));
                feehis1.setT0SingleDayLimit(shopper.getT0SingleDayLimit() == null ? null : new BigDecimal(shopper.getT0SingleDayLimit()));
                feehis1.setT0additionfee(new BigDecimal(shopper.getT0additionfee() == null ? 0.0 : shopper.getT0additionfee()));
                feehis1.setShopperid(shopper.getShopperid() == null ? null : new Long(shopper.getShopperid()));
                feehis1.setT0topamount(shopper.getT0topamount() == null ? null : new BigDecimal(shopper.getT0topamount()));
                feehis1.setT0additionfee(shopper.getT0additionfee() == null ? null : new BigDecimal(shopper.getT0additionfee()));
                feehis1.setCardtype(shopper.getCardType() == null ? "" : shopper.getCardType());
                feehis1.setUpdateDate(shopper.getCreated());
                feehis1.setIssupportt0(shopper.getIsSupportT0());

                if (merchantfee.getFee() == null || merchantfee.getFee() == "") {
                    bkshopper.setFee(new BigDecimal(0.0));
                    feehis1.setFee(new BigDecimal(0.0));
                } else {
                    bkshopper.setFee(new BigDecimal(merchantfee.getFee()));
                    feehis1.setFee(new BigDecimal(merchantfee.getFee()));
                }

                if (merchantfee.getTopAmount() == null || merchantfee.getTopAmount() == "") {
                    bkshopper.setTopAmount(new BigDecimal(0.0));
                    feehis1.setTopAmount(new BigDecimal(0.0));
                } else {
                    bkshopper.setTopAmount(new BigDecimal(merchantfee.getTopAmount()));
                    feehis1.setTopAmount(new BigDecimal(merchantfee.getTopAmount()));
                }
            }
            //每修改一次手续费历史表中增加一条
            UpdateFeeHistory feehis = new UpdateFeeHistory();
            feehis.setUpdateDate(new Date());
            feehis.setUpdateUser(((Operator) request.getSession().getAttribute(Constants.SESSION_KEY_USER)).getId().toString());
            feehis.setShopperid(shopper.getShopperid());

            shopper.setUpdated(new Date());
            //新加手续费初审、复审
            shopper.setFirstfeecheck("0");
            shopper.setFeerecheck("0");
            //修改t0手续费
            String cardType = request.getParameter("cardType");
            String T0fee = request.getParameter("T0fee");
            String t0fixedamount = request.getParameter("t0fixedamount");
            String t0minamount = request.getParameter("t0minamount");
            String t0maxamount = request.getParameter("t0maxamount");
            String T0SingleDayLimit = request.getParameter("T0SingleDayLimit");
            String isSupportT0 = request.getParameter("isSupportT0");
            if (Constants.CON_NO.equals(isSupportT0)) {
                double d1 = Double.parseDouble(T0fee);
                String t0fee = ToolsUtils.div(d1, 100, 4);
                shopper.setT0fee(Double.parseDouble(t0fee));
                shopper.setT0fixedamount(Double.parseDouble(t0fixedamount));
                shopper.setT0maxamount(Double.parseDouble(t0maxamount));
                shopper.setT0minamount(Double.parseDouble(t0minamount));
                shopper.setT0SingleDayLimit(Double.parseDouble(T0SingleDayLimit));

                feehis.setT0fee(new BigDecimal(t0fee));
                feehis.setT0fixedamount(new BigDecimal(t0fixedamount));
                feehis.setT0maxamount(new BigDecimal(t0maxamount));
                feehis.setT0minamount(new BigDecimal(t0minamount));
                feehis.setT0SingleDayLimit(new BigDecimal(T0SingleDayLimit));
            }

            shopper.setCardType(cardType);
            shopper.setT0type(Constants.STATUS0);
            feehis.setCardtype(cardType);
            feehis.setT0type(Constants.STATUS0);
            shopper.setIsSupportT0(isSupportT0);
            feehis.setIssupportt0(isSupportT0);
            //0费率商户 1封顶商户
            if (Constants.STATUS0.equals(cardType.trim())) {
                String fees = request.getParameter("fees");
                merchantfee.setFee(fees);
                feehis.setFee(new BigDecimal(fees));
                merchantfee.setTopAmount("");
            } else {
                String fees1 = request.getParameter("fees1");
                if (org.apache.commons.lang.StringUtils.isNotEmpty(fees1)) {
                    String[] fee = fees1.split("-");
                    merchantfee.setFee(fee[0]);
                    feehis.setFee(new BigDecimal(fee[0]));
                    merchantfee.setTopAmount(fee[1]);
                    feehis.setTopAmount(new BigDecimal(fee[1]));
                }

            }
            merchantfee.setUpdateDate(new Date());
            shopPerbiService.updatefee(shopper, merchantfee, bkshopper, feehis, feehis1);
            request.setAttribute(Constants.MESSAGE_KEY, "修改成功!");
            request.setAttribute("url", "shopPerbi.htm?method=shopPerbiManageList");
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.保存商户修改信息失败);
        }
        return "/returnPage";
    }

    /**
     * 商户手续费的审核
     *
     * @param request
     * @param b2cShopperbiTmp
     * @param b2cShopperbargainTmp
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=shopPerbiFeeList")
    public String shopPerbiFeeList(HttpServletRequest request, ModelMap modelMap,
                                   ShopPerbiForm mbForm) throws Exception {
        try {
            //行业类型
            List cillinglist = shopPerbiService.searchDictCls(Constants.CON_DICTCLS_CALLING);
            request.setAttribute("cillinglist", cillinglist);
            List<HashMap> shopPerbilist = null;
            //判断商户编号是否为数字
            String shopperIdq = mbForm.getShopperidq();
            if (!StringUtils.isEmpty(shopperIdq)) {
                boolean b = isFigure(shopperIdq);
                if (!b) {
                    mbForm.setShopperidq("");
                }
            }
            if (mbForm.getSprovince() != null) {
                List searchProvincialList = shopPerbiService.searchProvincial(mbForm.getSprovince());
                if (searchProvincialList != null && searchProvincialList.size() > 0) {
                    Area spro = (Area) searchProvincialList.get(0);
                    if (spro != null) {
                        String sprov = spro.getProvincialname();
                        mbForm.setSprovince(sprov);
                    }
                }
            }
            if (mbForm.getCity() != null) {
                List cityList = shopPerbiService.searchCity(mbForm.getCity());
                if (cityList != null && cityList.size() > 0) {
                    Area area = (Area) cityList.get(0);
                    if (area != null) {
                        String cityName = (String) area.getCityname();
                        mbForm.setCity(cityName);
                    }
                }
            }
            shopPerbilist = shopPerbiService.shopPerbiFeeList(mbForm);
            modelMap.put("shopPerbilist", shopPerbilist);
            //获取省
            List<Area> Provincial = shopPerbiService.searchProvince();
            request.setAttribute("Provincial", Provincial);
            //获取市
            List<Area> list = shopPerbiService.searchArea();
            request.setAttribute("area", list);
            //获取未审核的商户手续费信息的个数
            String Feecount = shopPerbiService.selectCheckFeeCount();
            request.setAttribute("Feecount", Feecount);

            request.setAttribute("belongsAgent", mbForm.getBelongsAgent());
        } catch (BusinessException e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.商户查询失败);
        }
        return "shopPerbi/shopPerbiCheckFee";
    }


    /**
     * 审核商户信息手续费信息
     *
     * @param request
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=queryCheckfee")
    @FormToken(save = true)
    public String queryCheckfee(HttpServletRequest request,
                                ModelMap modelMap, B2cShopperbiTemp b2cShopperbi,
                                B2cShopperbargainTemp b2cShopperbargain,
                                ShopPerbiForm mbForm) throws Exception {
        try {
            String shopPerbiregId = request.getParameter("shopperpriId");


            if (StringUtils.isEmpty(shopPerbiregId)) {
                request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiCheckList");
            } else {
                b2cShopperbi = shopPerbiService.queryShopPerbi(shopPerbiregId);

            }
            modelMap.put("b2cShopperbi", b2cShopperbi);
            modelMap.put("feeList", shopPerbiService.selectFeeByShopperid(b2cShopperbi.getShopperid()));
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取商户信息失败);
        }


        return "shopPerbi/checkfee";
    }


    /**
     * 审核商户手续费信息
     *
     * @param request
     * @param response
     * @param modelMap
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param mbForm
     * @return
     * @throws IOException
     * @throws BusinessException
     */
    @RequestMapping(params = "method=saveCheckFee")
    @FormToken(remove = true)
    public String saveCheckFee(HttpServletRequest request,
                               HttpServletResponse response, ModelMap modelMap,
                               B2cShopperbiTemp b2cShopperbi, B2cShopperbargainTemp b2cShopperbargain,
                               ShopPerbiForm mbForm) throws Exception, BusinessException {
        try {
            String firstCheck = mbForm.getFirstfeecheck();
            String firstresult = request.getParameter("firstfeecheckresult");
            if (firstCheck.equals("1")) {
                String shopperpriIds = request.getParameter("shopperpriIds");
                b2cShopperbi.setFirstfeecheck("1");//审核通过
                b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
                String remark = "审核通过";
                b2cShopperbi.setFirstfeecheckresult(remark);
                //shopPerbiService.updateCheckShopper(b2cShopperbi,Constants.TYPE_3,Constants.TYPE_2,remark);
                shopPerbiService.updatecheckfeeY(b2cShopperbi);
                request.setAttribute(Constants.MESSAGE_KEY, "审核成功!");
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiFeeList");
            } else {
                String shopperpriIds = request.getParameter("shopperpriIds");
                //审核不通过数据还原
                BackupsShopperInformation bkshopper = shopPerbiService.findbkshopper(new BigDecimal(shopperpriIds));
                b2cShopperbi.setFirstfeecheck(firstCheck);//审核不通过
                b2cShopperbi.setShopperid(Long.valueOf(shopperpriIds));
                b2cShopperbi.setFirstfeecheckresult(firstresult);
                b2cShopperbi.setT0additionfee(bkshopper.getT0additionfee() == null ? null : bkshopper.getT0additionfee().doubleValue());
                b2cShopperbi.setT0fee(bkshopper.getT0fee() == null ? null : bkshopper.getT0fee().doubleValue());
                b2cShopperbi.setT0fixedamount(bkshopper.getT0fixedamount() == null ? null : bkshopper.getT0fixedamount().doubleValue());
                b2cShopperbi.setT0maxamount(bkshopper.getT0maxamount() == null ? null : bkshopper.getT0maxamount().doubleValue());
                b2cShopperbi.setT0minamount(bkshopper.getT0minamount() == null ? null : bkshopper.getT0minamount().doubleValue());
                b2cShopperbi.setT0SingleDayLimit(bkshopper.getT0singledaylimit() == null ? null : bkshopper.getT0singledaylimit().doubleValue());
                b2cShopperbi.setT0topamount(bkshopper.getT0topamount() == null ? null : bkshopper.getT0topamount().doubleValue());
                b2cShopperbi.setT0type(bkshopper.getT0type());
                MposMerchantFee mfee = this.shopPerbiService.querymerchantfee(shopperpriIds);
                mfee.setFee(bkshopper.getFee().toString());
                mfee.setTopAmount(bkshopper.getTopAmount() == null ? null : bkshopper.getTopAmount().toString());

                shopPerbiService.updatecheckfeeN(b2cShopperbi, mfee);

                request.setAttribute(Constants.MESSAGE_KEY, "审核成功!");
                request.setAttribute("url", "shopPerbi.htm?method=shopPerbiFeeList");
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.审核失败);
        }

        return "/returnPage";

    }

    /**
     * @param request
     * @param modelMap
     * @param mbForm
     * @return
     * @throws Exception 代理商封顶费率显示列表
     */
    @RequestMapping(params = "method=toAgentfeeList")
    public String toAgentfeeList(HttpServletRequest request, ModelMap modelMap,
                                 ShopPerbiForm mbForm) throws Exception {
        try {
            List topfee = shopPerbiService.finagentfeeList();

            request.setAttribute("topfee", topfee);

        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.查询失败);
        }
        return "shopPerbi/agenttopfeelist";
    }


    /**
     * 显示修改代理商封顶手续费
     *
     * @param request
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=queryUpdateagentfee")
    @FormToken(save = true)
    public String queryUpdateagentfee(HttpServletRequest request,
                                      ModelMap modelMap, AgentTopFee agenttopfee) throws Exception {
        try {
            String Id = request.getParameter("id");


            if (StringUtils.isEmpty(Id)) {
                request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");

                request.setAttribute("url", "shopPerbi.htm?method=toAgentfeeList");
            } else {
                AgentTopFee topfee = shopPerbiService.selectById(Long.parseLong(Id));
                request.setAttribute("topfee", topfee);
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取信息失败);
        }


        return "shopPerbi/updatetopfee";
    }


    /**
     * 保存修改的代理商封顶手续费
     *
     * @param request
     * @param response
     * @param modelMap
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param mbForm
     * @return
     * @throws IOException
     * @throws BusinessException
     */
    @RequestMapping(params = "method=saveUpdateTopFee")
    @FormToken(remove = true)
    public String saveUpdateTopFee(HttpServletRequest request,
                                   HttpServletResponse response, ModelMap modelMap,
                                   AgentTopFee topfee) throws Exception, BusinessException {
        try {
            //相关费率位数转换
            String agentfee = request.getParameter("agentFee");
            String agentfee1 = ToolsUtils.div(Double.parseDouble(agentfee), 100, 4);
            String agentFeeMin = request.getParameter("agentFeeMin");
            if (agentFeeMin != null)
                agentFeeMin = ToolsUtils.div(Double.parseDouble(agentFeeMin), 100, 4);
            String sumFee = request.getParameter("sumFee");
            sumFee = ToolsUtils.div(Double.parseDouble(sumFee), 100, 4);
            String t0Fee = request.getParameter("t0Fee");
            t0Fee = ToolsUtils.div(Double.parseDouble(t0Fee), 100, 4);
            //更新
            topfee.setSumFee(sumFee);
            topfee.setT0Fee(t0Fee);
            topfee.setAgentFeeMin(agentFeeMin);
            topfee.setAgentFee(agentfee1);
            topfee.setUpdateDate(new Date());
            topfee.setUpdateUser(((Operator) request.getSession().getAttribute(Constants.SESSION_KEY_USER)).getId().toString());
            shopPerbiService.updateagentfee(topfee);
            request.setAttribute(Constants.MESSAGE_KEY, "修改成功!");
            request.setAttribute("url", "shopPerbi.htm?method=toAgentfeeList");

        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.修改失败);
        }

        return "/returnPage";

    }


    /**
     * @param request
     * @param response
     * @param mbForm
     * @return
     * @throws Exception zt
     */
    @RequestMapping(params = "method=findshopperPage")
    public String findshopperPage(HttpServletRequest request, HttpServletResponse response,
                                  ShopPerbiForm mbForm) throws Exception {

        if (mbForm.getSprovince() != null) {
            List searchProvincialList = shopPerbiService.searchProvincial(mbForm.getSprovince());
            if (searchProvincialList != null && searchProvincialList.size() > 0) {
                Area spro = (Area) searchProvincialList.get(0);
                if (spro != null) {
                    String sprov = spro.getProvincialname();
                    mbForm.setSprovince(sprov);
                }
            }
        }
        if (mbForm.getCity() != null) {
            List cityList = shopPerbiService.searchCity(mbForm.getCity());
            if (cityList != null && cityList.size() > 0) {
                Area area = (Area) cityList.get(0);
                if (area != null) {
                    String cityName = (String) area.getCityname();
                    mbForm.setCity(cityName);
                }
            }
        }
        String checkAgent = request.getParameter("checkAgent");
        if (StringUtils.isEmpty(checkAgent)) {
            mbForm.setCheckAgents(false);
        } else {
            if (checkAgent.equals("true")) {
                mbForm.setCheckAgents(true);
            } else {
                mbForm.setCheckAgents(false);
            }
        }
        Page page = new Page();
        page.setPageSize(Constants.EXCEL_SIZE);
        PageContext context = PageContext.getContext();
        BeanUtils.copyProperties(context, page);
        context.setPagination(true);
        shopPerbiService.queryFormalListexport(mbForm);
        BeanUtils.copyProperties(page, context);
        request.setAttribute("mbForm", mbForm);
        request.setAttribute("page", page);
        request.setAttribute("checkAgent", checkAgent);

        return "shopPerbi/exportShopperPage";
    }


    @RequestMapping(params = "method=downshopperExcel")
    public String downshopperExcel(HttpServletRequest request, HttpServletResponse response, ShopPerbiForm form)
            throws BusinessException, Exception {
        try {
            String checkAgent = request.getParameter("checkAgent");
            if (StringUtils.isEmpty(checkAgent)) {
                form.setCheckAgents(false);
            } else {
                if (checkAgent.equals("true")) {
                    form.setCheckAgents(true);
                } else {
                    form.setCheckAgents(false);
                }
            }
            String tPage = request.getParameter("page");
            if (StringUtils.isEmpty(tPage) || !org.apache.commons.lang3.StringUtils.isNumeric(tPage)) {
                tPage = "1";
            }
            int currentPage = Integer.valueOf(tPage);
            Page page = new Page();
            page.setPageSize(Constants.EXCEL_SIZE);
            PageContext context = PageContext.getContext();
            BeanUtils.copyProperties(context, page);
            context.setPagination(true);
            context.setCurrentPage(currentPage);
            List excelList = shopPerbiService.queryFormalListexport(form);
            //标题
            Map<String, String> mapField = new LinkedHashMap();
            mapField.put("SHOPPERID", "商户编号");
            mapField.put("SPROVINCE", "商户地区(省份)");
            mapField.put("SCITY", "商户地区(城市)");
            mapField.put("SCOMPANY", "商户名称");
            mapField.put("STEL", "商户手机号");
            mapField.put("AGENTNAME", "代理商名称");
            mapField.put("AGENTTEL", "代理商编号");
            mapField.put("PAGENTNAME", "所属一级代理商编号");
            mapField.put("PAGENTTEL", "所属一级代理商名称");
            mapField.put("ACCOUNT_BANK_NO", " 结算卡号");
            mapField.put("DICT", "结算银行");
            mapField.put("ACCOUNT_BANK_PROV", "开户地区(省份)");
            mapField.put("ACCOUNT_BANK_CITY", "开户地区(城市)");
            mapField.put("ACCOUNT_BANK_NAME", "支行信息");
            mapField.put("FEE", "交易手续费");
            mapField.put("T0_FEE", "D0手续费");
            mapField.put("T0_SINGLE_DAY_LIMIT", "D0限额");
            mapField.put("CREATED", "申请时间");
            mapField.put("CHECK_DATE", "审核时间");
            mapField.put("RECHECK_DATE", "复审时间");
            mapField.put("CHECKSHOPPER", "初审结果");
            mapField.put("RECHECKSHOPPER", "复审结果");
            mapField.put("SIFPACTID", "商户状态");
            mapField.put("IFACTIVATED", "激活状态");
            mapField.put("IFACTIVADATE", "激活时间");
            mapField.put("OPEN_MPOS_CREATE_DATE", "开通时间");
            mapField.put("HAVE_INVITE_CODE_P", "是否裂变商户");

            String fileName = "MPOS商户注册信息数据导出";
            outExcel(excelList, response, mapField, fileName);
        } catch (Exception e) {
            log.info("导出数据有误！");
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 导出excel
     *
     * @param excelList
     * @param response
     * @param mapField
     * @throws Exception
     */
    private void outExcel(List excelList, HttpServletResponse response, Map<String, String> mapField, String fileNames) throws Exception {

        response.setContentType("application/vnd.ms-excel");
        response.setHeader("content-disposition", "attachment;filename=" + new String(fileNames.getBytes("UTF-8"), "iso8859-1") + ".xls");
        response.setCharacterEncoding("UTF-8");

        OutputStream os = response.getOutputStream();
        WritableWorkbook wwb = Workbook.createWorkbook(os);
        WritableSheet sheet = wwb.createSheet("商户注册信息", 0);
        SheetSettings ss = sheet.getSettings();
        ss.setVerticalFreeze(1);// 冻结表头

        WritableCellFormat wcf = new WritableCellFormat();
        WritableCellFormat wcf2 = new WritableCellFormat();

        int flag = 0;
        int columnIndex = 0;
        List<String> methodNameList = new ArrayList<String>();

        if (mapField != null && mapField.size() > 0) {
            String key = "";
            // 循环写入表头
            for (Iterator<String> i = mapField.keySet().iterator(); i.hasNext(); ) {
                key = i.next();
                sheet.addCell(new Label(columnIndex, 0, mapField.get(key), wcf));
                methodNameList.add(key);
                columnIndex++;
            }
            // 判断表中是否有数据
            if (excelList != null && excelList.size() > 0) {
                // 循环写入表中数据
                for (int i = 0; i < excelList.size(); i++) {
                    Map<String, Object> map = (Map<String, Object>) excelList.get(i);
                    // 循环输出map中的子集：既列值
                    int j = 0;
                    for (Object o : map.keySet()) {

                        //第一个参数为列坐标，第二个参数为行坐标，第三个参数为内容
                        sheet.addCell(new Label(0, i + 1, String.valueOf(map.get("SHOPPERID") == null ? "" : map.get("SHOPPERID")), wcf2));
                        sheet.addCell(new Label(1, i + 1, String.valueOf(map.get("SPROVINCE") == null ? "" : map.get("SPROVINCE")), wcf2));
                        sheet.addCell(new Label(2, i + 1, String.valueOf(map.get("SCITY") == null ? "" : map.get("SCITY")), wcf2));
                        sheet.addCell(new Label(3, i + 1, String.valueOf(map.get("SCOMPANY") == null ? "" : map.get("SCOMPANY")), wcf2));
                        sheet.addCell(new Label(4, i + 1, String.valueOf(map.get("STEL") == null ? "" : map.get("STEL")), wcf2));
                        sheet.addCell(new Label(5, i + 1, String.valueOf(map.get("SAGENTID") == null ? "" : map.get("SAGENTID")), wcf2));
                        sheet.addCell(new Label(6, i + 1, String.valueOf(map.get("SHOPPERBIID") == null ? "" : map.get("SHOPPERBIID")), wcf2));
                        sheet.addCell(new Label(7, i + 1, String.valueOf(map.get("PAGENTID") == null ? "" : map.get("PAGENTID")), wcf2));
                        sheet.addCell(new Label(8, i + 1, String.valueOf(map.get("PAGENTNAME") == null ? "" : map.get("PAGENTNAME")), wcf2));
                        sheet.addCell(new Label(9, i + 1, String.valueOf(map.get("ACCOUNT_BANK_NO") == null ? "" : map.get("ACCOUNT_BANK_NO")), wcf2));
                        sheet.addCell(new Label(10, i + 1, String.valueOf(map.get("DICT") == null ? "" : map.get("DICT")), wcf2));
                        sheet.addCell(new Label(11, i + 1, String.valueOf(map.get("ACCOUNT_BANK_PROV") == null ? "" : map.get("ACCOUNT_BANK_PROV")), wcf2));
                        sheet.addCell(new Label(12, i + 1, String.valueOf(map.get("ACCOUNT_BANK_CITY") == null ? "" : map.get("ACCOUNT_BANK_CITY")), wcf2));
                        sheet.addCell(new Label(13, i + 1, String.valueOf(map.get("ACCOUNT_BANK_NAME") == null ? "" : map.get("ACCOUNT_BANK_NAME")), wcf2));
                        sheet.addCell(new Label(14, i + 1, String.valueOf(map.get("FEE") == null ? "" : map.get("FEE")), wcf2));
                        sheet.addCell(new Label(15, i + 1, String.valueOf(map.get("T0_FEE") == null ? "" : map.get("T0_FEE")), wcf2));
                        sheet.addCell(new Label(16, i + 1, String.valueOf(map.get("T0_SINGLE_DAY_LIMIT") == null ? "" : map.get("T0_SINGLE_DAY_LIMIT")), wcf2));
                        sheet.addCell(new Label(17, i + 1, String.valueOf(map.get("CREATED") == null ? "" : map.get("CREATED")), wcf2));
                        sheet.addCell(new Label(18, i + 1, String.valueOf(map.get("CHECK_DATE") == null ? "" : map.get("CHECK_DATE")), wcf2));
                        sheet.addCell(new Label(19, i + 1, String.valueOf(map.get("RECHECK_DATE") == null ? "" : map.get("RECHECK_DATE")), wcf2));
                        sheet.addCell(new Label(20, i + 1, String.valueOf(map.get("CHECKSHOPPER") == null ? "" : map.get("CHECKSHOPPER")), wcf2));
                        sheet.addCell(new Label(21, i + 1, String.valueOf(map.get("RECHECKSHOPPER") == null ? "" : map.get("RECHECKSHOPPER")), wcf2));
                        String status = "";
                        if (Constants.CON_NO.equals(String.valueOf(map.get("SIFPACTID")))) {
                            status = "正常";
                        } else if (Constants.CON_YES.equals(String.valueOf(map.get("SIFPACTID")))) {
                            status = "冻结";
                        } else {
                            status = "注销";
                        }
                        sheet.addCell(new Label(22, i + 1, status, wcf2));
                        sheet.addCell(new Label(23, i + 1, Constants.CON_YES.equals(map.get("IFACTIVATED")) ? "已激活" : "暂未", wcf2));
                        sheet.addCell(new Label(24, i + 1, String.valueOf(map.get("IFACTIVADATE") == null ? "" : map.get("IFACTIVADATE")), wcf2));
                        sheet.addCell(new Label(25, i + 1, String.valueOf(map.get("OPEN_MPOS_CREATE_DATE") == null ? "" : map.get("OPEN_MPOS_CREATE_DATE")), wcf2));
                        sheet.addCell(new Label(26, i + 1, String.valueOf(map.get("HAVE_INVITE_CODE_P") == null ? "" : map.get("HAVE_INVITE_CODE_P")), wcf2));

                    }

                }
            } else {
                flag = -1;
            }
            // 写入Exel工作表
            wwb.write();
            // 关闭Excel工作薄对象
            wwb.close();
            // 关闭流
            os.flush();
            os.close();
            os = null;
        }
    }

    /**
     * 显示照片
     */
    @RequestMapping(params = "method=showPhoto")
    public String showPhoto(HttpServletRequest request, ModelMap model, B2cShopperbiTemp b2cShopperbi, ShopPerbiForm spForm) throws Exception {
        try {
            String photo = request.getParameter("photo");
            model.put("photo", photo);
            model.put("image_get_url", DynamicConfigLoader.getByEnv("imageget.url"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "shopPerbi/showPhotoPage";

    }


    /**
     * @param request
     * @param modelMap
     * @param mbForm
     * @return
     * @throws Exception 交易风控金额显示列表
     */
    @RequestMapping(params = "method=toFixamountList")
    public String toFixamountList(HttpServletRequest request, ModelMap modelMap,
                                  ShopPerbiForm mbForm) throws Exception {
        try {
            List amount = shopPerbiService.findfixamountList();

            request.setAttribute("amount", amount);

        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.查询失败);
        }
        return "shopPerbi/fixamountlist";
    }


    /**
     * 交易风控金额
     *
     * @param request
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=updateFixamount")
    @FormToken(save = true)
    public String updateFixamount(HttpServletRequest request,
                                  ModelMap modelMap, FixAmaount fixamount) throws Exception {
        try {
            String Id = request.getParameter("id");


            if (StringUtils.isEmpty(Id)) {
                request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");

                request.setAttribute("url", "shopPerbi.htm?method=toFixamountList");
            } else {
                FixAmaount amount = shopPerbiService.selectByfixamount(Long.parseLong(Id));
                request.setAttribute("amount", amount);
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取信息失败);
        }


        return "shopPerbi/updatefixamount";
    }


    /**
     * 保存修改的交易风控金额
     *
     * @param request
     * @param response
     * @param modelMap
     * @param b2cShopperbi
     * @param b2cShopperbargain
     * @param mbForm
     * @return
     * @throws IOException
     * @throws BusinessException
     */
    @RequestMapping(params = "method=saveUpdatefixamount")
    @FormToken(remove = true)
    public String saveUpdatefixamount(HttpServletRequest request,
                                      HttpServletResponse response, ModelMap modelMap,
                                      FixAmaount amount) throws Exception, BusinessException {
        try {
            String fixamountt = request.getParameter("fixamount");
            amount.setFixamaount(fixamountt);
            amount.setUpdateDate(new Date());
            amount.setUpdateUser(((Operator) request.getSession().getAttribute(Constants.SESSION_KEY_USER)).getId().toString());
            shopPerbiService.updatefixamount(amount);
            request.setAttribute(Constants.MESSAGE_KEY, "修改成功!");
            request.setAttribute("url", "shopPerbi.htm?method=toFixamountList");


        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.修改失败);
        }

        return "/returnPage";

    }


    /**
     * @param request
     * @param modelMap
     * @param mbForm
     * @return
     * @throws Exception 商户手续费修改历史记录
     */
    @RequestMapping(params = "method=showfeeList")
    public String showfeeList(HttpServletRequest request, ModelMap modelMap,
                              ShopPerbiForm mbForm) throws Exception {
        try {
            String shopperid = request.getParameter("shopperid");
            List feehis = shopPerbiService.showfeeList(shopperid);

            request.setAttribute("feehis", feehis);

        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.查询失败);
        }
        return "shopPerbi/feehistoryList";
    }

    /**
     * 交易风控金额
     *
     * @param request
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(params = "method=queryfeehis")
    @FormToken(save = true)
    public String queryfeehis(HttpServletRequest request,
                              ModelMap modelMap, FixAmaount fixamount) throws Exception {
        try {
            String Id = request.getParameter("id");


            if (StringUtils.isEmpty(Id)) {
                request.setAttribute(Constants.MESSAGE_KEY, "请检查，id为空！");

                request.setAttribute("url", "shopPerbi.htm?method=queryfeehis");
            } else {
                UpdateFeeHistory feehis = shopPerbiService.selectByfeehis(Long.parseLong(Id));
                request.setAttribute("feehis", feehis);
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ExceptionDefine.获取信息失败);
        }


        return "shopPerbi/queryfeehis";
    }
}
