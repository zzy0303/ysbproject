package com.uns.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.AgentTopFee;
@Repository
public interface AgentTopFeeMapper {


    int insert(AgentTopFee record);

    int insertSelective(AgentTopFee record);
    
    void updateById(AgentTopFee agenttopfee);
    
    List findbyidList();
    
    AgentTopFee selectById(Long id);

	List<AgentTopFee> findAgentFeeByType(String fee_type);


}