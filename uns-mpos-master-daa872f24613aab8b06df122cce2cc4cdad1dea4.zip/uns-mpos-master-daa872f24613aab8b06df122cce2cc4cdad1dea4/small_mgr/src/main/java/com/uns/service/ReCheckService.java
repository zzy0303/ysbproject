package com.uns.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.uns.common.Constants;
import com.uns.common.page.PageContext;
import com.uns.dao.B2cShopperbargainMapper;
import com.uns.dao.B2cShopperbargainTempMapper;
import com.uns.dao.B2cShopperbiMapper;
import com.uns.dao.B2cShopperbiTempMapper;
import com.uns.dao.B2cTermBinderMapper;
import com.uns.dao.BackupsShopperInformationMapper;
import com.uns.dao.MposApplicationProgressMapper;
import com.uns.dao.MposMerchantFeeMapper;
import com.uns.dao.MposPhotoMapper;
import com.uns.dao.UsersMapper;
import com.uns.model.B2cShopperbi;
import com.uns.model.B2cShopperbiTemp;
import com.uns.model.BackupsShopperInformation;
import com.uns.model.MposApplicationProgress;
import com.uns.model.MposMerchantFee;
import com.uns.model.MposPhoto;
import com.uns.model.Users;
import com.uns.web.form.ShopPerbiForm;

@Component
	
public class ReCheckService {
	@Autowired
	private B2cShopperbiMapper b2cShopperbiMapper;

	@Autowired
	private B2cShopperbiTempMapper b2cShopperbiTempMapper;
	
	@Autowired
	private UsersMapper usersMapper;
	
	@Autowired
	private B2cTermBinderMapper b2cTermBinderMapper;
	
	@Autowired
	private MposApplicationProgressMapper  progressmapper;
	
	@Autowired
	private B2cShopperbargainTempMapper b2cShopperbargainTempMapper;
	
	@Autowired
	private B2cShopperbargainMapper b2cShopperbargainMapper;
	
	@Autowired
	private MposMerchantFeeMapper  mposMerchantFeeMapper;
	 
	@Autowired
	private BackupsShopperInformationMapper bkshoppermapper;
	 
	@Autowired
	private MposPhotoMapper mposPhotoMapper;
	
	/**
	 * @param mbForm
	 * @return
	 */
	public List getReCheckList(ShopPerbiForm mbForm)throws Exception {
		PageContext.initPageSize(20);
		return b2cShopperbiTempMapper.getReCheckList(mbForm);
	}
	public List getReCheck1List(ShopPerbiForm mbForm)throws Exception {
		PageContext.initPageSize(20);
		return b2cShopperbiTempMapper.getReCheck1List(mbForm);
	}
	
	

	/**
	 * @return
	 */
	public String getReCheckMerchantCount()throws Exception {
		return b2cShopperbiTempMapper.getReCheckMerchantCount();
	}

	/**
	 * @param b2cShopperbi
	 * @throws Exception
	 */
	public void update(B2cShopperbiTemp b2cShopperbi)throws Exception {
		b2cShopperbiTempMapper.updateByShopperId(b2cShopperbi);
		
	}
	
	public void updateN(B2cShopperbiTemp b2cShopperbi,MposMerchantFee mfee)throws Exception {
		b2cShopperbiTempMapper.updateByShopperId(b2cShopperbi);
		mposMerchantFeeMapper.updateByShopperId(mfee);
	}

	/**
	 * @param b2cShopperbi
	 * @param user
	 * @throws Exception
	 */
	public void updates(B2cShopperbiTemp b2cShopperbi) throws Exception {
		update(b2cShopperbi);
	}
	
	/**
	 * @param user
	 * @throws Exception
	 */
	public void insert(Users user)throws Exception {
		usersMapper.insertUsers(user);
	}

	/**
	 * @return
	 */
	public String getBankCount() {
		return b2cShopperbiTempMapper.getBankCount();
	}

	
	/**
	 * @param b2cShopperbi
	 * @throws Exception 
	 */
	public void updateBankInfo(B2cShopperbiTemp b2cShopperbi) throws Exception {
		update(b2cShopperbi);
		b2cShopperbiMapper.updateFormalBankInfo(b2cShopperbi);
	}

	public String getTerminalCount() {
		return b2cShopperbiTempMapper.getTerminalCount();
	}
	
	public void updateTerminal(String status, B2cShopperbiTemp b2cShopperbi) throws Exception {
		update(b2cShopperbi);
		updateTerminals(status,b2cShopperbi.getShopperid().toString());
	}

	private void updateTerminals(String status,String shopperId) {
		Map map=new HashMap();
		map.put("status", status);
		map.put("shopperId", shopperId);
		b2cTermBinderMapper.updateTerminalStatus(map);
	}

	public Users getUsersByMerchantId(String shopperid) {
		
		return usersMapper.selectByUserId(shopperid);
	}

	public void updateU(B2cShopperbiTemp b2cShopperbi, Users user) throws Exception {
		update(b2cShopperbi);
		updateUsers(user);
	}

	private void updateUsers(Users user) {
		user.setIsAgent(Constants.CON_NO); 
		usersMapper.updateByUsresId(user);
	}

	/**复核修改时
	 * @param b2cShopperbi
	 * @throws Exception
	 */
	public void updateReCheckMerchant(B2cShopperbiTemp b2cShopperbi) throws Exception {
		/*//根据商户号，查询用户名密码。
		Users user=getUsersByMerchantId(b2cShopperbi.getShopperid().toString());
		Users usres=saveUsers(user,b2cShopperbi);
		
		updateU(b2cShopperbi,usres);*/
		Users user=getUsersByMerchantId(b2cShopperbi.getShopperid().toString());
		if(user!=null){
			 user.setTel(b2cShopperbi.getStel());
			 user.setUserName(b2cShopperbi.getStel());
			 user.setIsAgent(Constants.CON_NO); 
			 this.usersMapper.updateByUsresId(user);
		}
	   
		b2cShopperbiTempMapper.updateByShopperId(b2cShopperbi);
		
		//在正式表中生成数据
		B2cShopperbiTemp b2cShopperbis=b2cShopperbiTempMapper.selectByshopperId(b2cShopperbi.getShopperid());
		b2cShopperbis.setStel(b2cShopperbi.getStel());
		b2cShopperbis.setShopperidP(b2cShopperbi.getShopperidP()); //复审成功修改代理商编号和临时表中一致
		b2cShopperbiMapper.updateShoppbiTemp(b2cShopperbis);
		//修改进度表进度
		updateProgress(b2cShopperbi.getShopperid().toString(),
				Constants.TYPE_1,Constants.TYPE_4,b2cShopperbi.getRecheckmerchantremark());
	}
	
	public void updateReCheckMerchant2(B2cShopperbiTemp b2cShopperbi) throws Exception {
		/*//根据商户号，查询用户名密码。
		Users user=getUsersByMerchantId(b2cShopperbi.getShopperid().toString());
		Users usres=saveUsers(user,b2cShopperbi);
		
		updateU(b2cShopperbi,usres);*/
		Users user=getUsersByMerchantId(b2cShopperbi.getShopperid().toString());
		if(user!=null){
			 user.setTel(b2cShopperbi.getStel());
			 user.setUserName(b2cShopperbi.getStel());
			 user.setIsAgent(Constants.CON_NO); 
			 this.usersMapper.updateByUsresId(user);
		}
	   
		b2cShopperbiTempMapper.updateByShopperId(b2cShopperbi);
		
		//在正式表中生成数据
		B2cShopperbiTemp b2cShopperbis=b2cShopperbiTempMapper.selectByshopperId(b2cShopperbi.getShopperid());
		b2cShopperbis.setStel(b2cShopperbi.getStel());
		b2cShopperbis.setShopperidP(b2cShopperbi.getShopperidP()); //复审成功修改代理商编号和临时表中一致
		b2cShopperbiMapper.updateShoppbiTemp(b2cShopperbis);
		//修改进度表进度
		updateProgress(b2cShopperbi.getShopperid().toString(),
				Constants.TYPE_2,Constants.TYPE_4,b2cShopperbi.getRecheckmerchantremark());
		
	}

	
	/**保存用户名密码
	 * @param user
	 * @param b2cShopperbi
	 * @return
	 */
	private Users saveUsers(Users user, B2cShopperbiTemp b2cShopperbi) {
		user.setMerchantid(b2cShopperbi.getShopperid());
		user.setUserName(b2cShopperbi.getMuserid());
		user.setPassword(b2cShopperbi.getMpassword());
		user.setTel(b2cShopperbi.getStel());
		user.setEnabled(Short.valueOf(Constants.CON_YES));
		user.setCreatedate(new Date());
		user.setLocked(Short.valueOf(b2cShopperbi.getSifpactid()==null?Constants.CON_NO:b2cShopperbi.getSifpactid().toString()));
		user.setIsAgent(Constants.CON_NO);
		return user;
	}
	
	
	
	/**根据商户编号与主题查询记录
	 * @param shopperid
	 * @param type1
	 * @return
	 */
	public MposApplicationProgress findMposApplicationProgress(
			String shopperid, String type1) {
		Map map=new HashMap();
		map.put("shopperid",shopperid);
		map.put("applicationType", type1);
		return progressmapper.findMposApplicationProgress(map);
	}
	
	/**报错进度
	 * @param alp
	 */
	public void updateMposApplicationProgress(MposApplicationProgress alp) {
		progressmapper.updateSelective(alp);
	}
	/**修改进度
	 * @param shopperid
	 * @param type
	 * @param status
	 * @param remark
	 * updateProgress(b2cShopperbi.getShopperid().toString(),
				Constants.TYPE_2,Constants.TYPE_4,b2cShopperbi.getRecheckmerchantremark());
	 * 
	 */
	public void updateProgress(String shopperid, String type,String status,String remark) {
		MposApplicationProgress  alp=findMposApplicationProgress(shopperid,type);
		if(alp!=null){
			alp.setApplicationStatus(status);
			alp.setApplicationRemark(remark);
			updateMposApplicationProgress(alp);
		}
		
	}

	/**创建账户
	 * @param b2cShopperbi
	 * @return
	 * @throws Exception 
	 */
	public void saveMerchant(B2cShopperbiTemp b2cShopperbi) throws Exception {
		if(StringUtils.isNotEmpty(b2cShopperbi.getMuserid())){
			Users user=new Users();
			Users usres=saveUsers(user,b2cShopperbi);
			updates(b2cShopperbi);
			insert(usres);
		}else{
			update(b2cShopperbi);
		}
		//正式表
		b2cShopperbiMapper.insert(b2cShopperbi);
	//	B2cShopperbargainTemp shopperbargian=b2cShopperbargainTempMapper.selectByShopperbiId(b2cShopperbi.getShopperid());
	//	b2cShopperbargainMapper.insert(shopperbargian);
		
		//修改进度表进度
		updateProgress(b2cShopperbi.getShopperid().toString(),
				Constants.TYPE_1,Constants.TYPE_4,b2cShopperbi.getRecheckmerchantremark());
	}
	/**
	 * 审核未通过
	 * @throws Exception 
	 */
	public void updateNOtCheck(B2cShopperbiTemp b2cShopperbi,B2cShopperbi b2cShopperbis) throws Exception {
		updateProgress(b2cShopperbi.getShopperid().toString(),
					Constants.TYPE_1,Constants.TYPE_5,b2cShopperbi.getRecheckmerchantremark());
		update(b2cShopperbi);
	}

	/**审核开户行信息
	 * @param b2cShopperbi
	 * @param shopper
	 * @throws Exception
	 */
	public void updateReCheckBank(B2cShopperbiTemp b2cShopperbi,
			B2cShopperbiTemp shopper) throws Exception {
		b2cShopperbiMapper.updateFormalBankInfo(shopper);
		updateBankInfo(b2cShopperbi);
		updateProgress(b2cShopperbi.getShopperid().toString(),
				Constants.TYPE_3,Constants.TYPE_4,b2cShopperbi.getRecheckaccountremark());
	}
	
	public void updateReCheckBankY(B2cShopperbiTemp b2cShopperbi,
			B2cShopperbiTemp shopper,BackupsShopperInformation bkshopper) throws Exception {
		b2cShopperbiMapper.updateFormalBankInfo(shopper);
		bkshoppermapper.updateByShopperId(bkshopper);
		updateBankInfo(b2cShopperbi);
		updateProgress(b2cShopperbi.getShopperid().toString(),
				Constants.TYPE_3,Constants.TYPE_4,b2cShopperbi.getRecheckaccountremark());
	}

	/**审核开户信不通过
	 * @param b2cShopperbi
	 * @throws Exception
	 */
	public void updateNotReCheckBank(B2cShopperbiTemp b2cShopperbi) throws Exception {
		b2cShopperbiTempMapper.updateBankInfo(b2cShopperbi);
		//update(b2cShopperbi);
		updateProgress(b2cShopperbi.getShopperid().toString(),
				Constants.TYPE_3,Constants.TYPE_5,b2cShopperbi.getRecheckaccountremark());
		
	}

	/**审核终端信息
	 * @param b2cShopperbi
	 * @throws Exception 
	 */
	public void updateReCheckTerminal(B2cShopperbiTemp b2cShopperbi) throws Exception {
		updateTerminal(Constants.CON_NO,b2cShopperbi);
		updateProgress(b2cShopperbi.getShopperid().toString(),
				Constants.TYPE_4,Constants.TYPE_4,b2cShopperbi.getRecheckterminalremark());
	}

	/**
	 * 审核终端不通过
	 * @throws Exception 
	 */
	public void updateNotReCheckTerminal(B2cShopperbiTemp b2cShopperbi) throws Exception {
		update(b2cShopperbi);
		updateTerminal(Constants.CON_NO,b2cShopperbi);
		updateProgress(b2cShopperbi.getShopperid().toString(),
				Constants.TYPE_4,Constants.TYPE_5,b2cShopperbi.getRecheckterminalremark());
	}

	/**审核终端信息
	 * @param b2cShopperbi
	 * @throws Exception 
	 */
	public void updateReCheckPhoto(B2cShopperbiTemp b2cShopperbi) throws Exception {
		updateTerminal(Constants.CON_NO,b2cShopperbi);
		updateProgress(b2cShopperbi.getShopperid().toString(),
				Constants.TYPE_4,Constants.TYPE_4,b2cShopperbi.getRecheckterminalremark());
	}

	/**
	 * 审核终端不通过
	 * @throws Exception 
	 */
	public void updateNotReCheckPhoto(B2cShopperbiTemp b2cShopperbi) throws Exception {
		update(b2cShopperbi);
		updateTerminal(Constants.CON_NO,b2cShopperbi);
		updateProgress(b2cShopperbi.getShopperid().toString(),
				Constants.TYPE_4,Constants.TYPE_5,b2cShopperbi.getRecheckterminalremark());
	}

	/**根据商户号查询商户费率
	 * @param shopperid
	 * @return
	 */
	public List findMposMerchantFee(String shopperid) {
		return mposMerchantFeeMapper.findMposMerchantFee(shopperid);
	}

	/**
	 * @param b2cShopperbi
	 * @throws Exception
	 */
	public void saveChildMerchant(B2cShopperbiTemp b2cShopperbi) throws Exception {
		update(b2cShopperbi);
		//在正式表中生成数据
		B2cShopperbiTemp b2cShopperbis=b2cShopperbiTempMapper.selectByshopperId(b2cShopperbi.getShopperid());
		b2cShopperbiMapper.insert(b2cShopperbis);
		//B2cShopperbargainTemp shopperbargian=b2cShopperbargainTempMapper.selectByShopperbiId(b2cShopperbi.getShopperid());
		//b2cShopperbargainMapper.insert(shopperbargian);
		//修改进度表进度
		updateProgress(b2cShopperbi.getShopperid().toString(),
				Constants.TYPE_4,Constants.TYPE_4,b2cShopperbi.getRecheckmerchantremark());
		 
	}

	/**子商户审核不通过
	 * @param b2cShopperbi
	 * @throws Exception
	 */
	public void updateNOtCheckChildMerchants(B2cShopperbiTemp b2cShopperbi) throws Exception {
		updateProgress(b2cShopperbi.getShopperid().toString(),
				Constants.TYPE_4,Constants.TYPE_5,b2cShopperbi.getRecheckmerchantremark());
		update(b2cShopperbi);
	}
	
	
	/**手续费为复审数量
	 * @return
	 */
	public String getFeeCount() {
		return b2cShopperbiTempMapper.getfeecount();
	}
	
	/**手续费审核信息
	 * @param mbForm
	 * @return
	 */
	public List<HashMap> reCheckFeeList(ShopPerbiForm mbForm) {
		PageContext.initPageSize(20);
		return b2cShopperbiTempMapper.reCheckFeeList(mbForm);
	}
	
	
	/**复审手续费信息
	 * @param b2cShopperbi
	 * @param shopper
	 * @param mfee 
	 * @throws Exception
	 */
	public void updateReCheckFee(B2cShopperbiTemp b2cShopperbi,B2cShopperbi shopper,BackupsShopperInformation bkshopper) throws Exception {
		b2cShopperbiMapper.updateByShopperId(shopper);
		b2cShopperbiTempMapper.updateByShopperId(b2cShopperbi);
		bkshoppermapper.updateByShopperId(bkshopper);
		//	update(b2cShopperbi);
		
	}
	public void updateMerchant(B2cShopperbiTemp b2cShopperbi, MposPhoto photoTmp) throws Exception{
		//查询更新正式表有无费率信息
		updateMposMerchantFee(b2cShopperbi);
		
		
		//查询证照正式表有无信息
		MposPhoto mposPhoto = mposPhotoMapper.selectByPrimaryKey(b2cShopperbi.getPhotoid());
		if(mposPhoto!=null){
			mposPhotoMapper.updateByPrimaryKeySelective(photoTmp);
		}else{
			mposPhotoMapper.insertSelective(photoTmp);
		}
		b2cShopperbiTempMapper.updateByShopperId(b2cShopperbi);
		b2cShopperbiMapper.updateMerchant(b2cShopperbi);
	}
	private void updateMposMerchantFee(B2cShopperbiTemp b2cShopperbi) {
		
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("shopperId",b2cShopperbi.getShopperid().toString());
		paramMap.put("feeType", Constants.FEE_TYPE_DEBIT);
		paramMap.put("channelType", Constants.S0_CHANNEL_TYPE);
		MposMerchantFee s0debitMerchantFeeList = mposMerchantFeeMapper.findTempFeeTChannelType(paramMap);//查询临时表
		MposMerchantFee s0debitMerchantFee = mposMerchantFeeMapper.findMerchantFeeTChannelType(paramMap);//查询正式表
		if(s0debitMerchantFeeList!=null){
			mposMerchantFeeMapper.updateByShopperIdFee(s0debitMerchantFeeList);//更新正式表
			if(s0debitMerchantFee==null){
				mposMerchantFeeMapper.insertSelective(s0debitMerchantFeeList);//插入正式表
			}
		}else{
			if(s0debitMerchantFee!=null){
				mposMerchantFeeMapper.insertSelectiveTemp(s0debitMerchantFee);//插入临时表
			}
		}
		
		paramMap.put("feeType", Constants.FEE_TYPE_CREDIT);
		paramMap.put("channelType", Constants.S0_CHANNEL_TYPE);
		MposMerchantFee s0creditMerchantFeeList = mposMerchantFeeMapper.findTempFeeTChannelType(paramMap);
		MposMerchantFee s0creditMerchantFee = mposMerchantFeeMapper.findMerchantFeeTChannelType(paramMap);
		if(s0creditMerchantFeeList!=null){
			mposMerchantFeeMapper.updateByShopperIdFee(s0creditMerchantFeeList);
			if(s0creditMerchantFee==null){
				mposMerchantFeeMapper.insertSelective(s0creditMerchantFeeList);
			}
		}else{
			if(s0creditMerchantFee!=null){
				mposMerchantFeeMapper.insertSelectiveTemp(s0creditMerchantFee);
			}
		}
		
		paramMap.put("feeType", Constants.FEE_TYPE_DEBIT);
		paramMap.put("channelType", Constants.D0_CHANNEL_TYPE);
		MposMerchantFee d0debitMerchantFeeList = mposMerchantFeeMapper.findTempFeeTChannelType(paramMap);
		MposMerchantFee d0debitMerchantFee = mposMerchantFeeMapper.findMerchantFeeTChannelType(paramMap);
		if(d0debitMerchantFeeList!=null){
			mposMerchantFeeMapper.updateByShopperIdFee(d0debitMerchantFeeList);
			if(d0debitMerchantFee==null){
				mposMerchantFeeMapper.insertSelective(d0debitMerchantFeeList);
			}
		}else{
			if(d0debitMerchantFee!=null){
				mposMerchantFeeMapper.insertSelectiveTemp(d0debitMerchantFee);
			}
			
		}
		
		paramMap.put("feeType", Constants.FEE_TYPE_CREDIT);
		paramMap.put("channelType", Constants.D0_CHANNEL_TYPE);
		MposMerchantFee d0creditMerchantFeeList = mposMerchantFeeMapper.findTempFeeTChannelType(paramMap);
		MposMerchantFee d0creditMerchantFee = mposMerchantFeeMapper.findMerchantFeeTChannelType(paramMap);
		if(d0creditMerchantFeeList!=null){
			mposMerchantFeeMapper.updateByShopperIdFee(d0creditMerchantFeeList);
			if(d0creditMerchantFee==null){
				mposMerchantFeeMapper.insertSelective(d0creditMerchantFeeList);
			}
		}else{
			if(d0creditMerchantFee!=null){
				mposMerchantFeeMapper.insertSelectiveTemp(d0creditMerchantFee);
			}
			
		}
		
		paramMap.put("feeType", Constants.FEE_TYPE_DEBIT);
		paramMap.put("channelType", Constants.T1_CHANNEL_TYPE);
		MposMerchantFee t1debitMerchantFeeList = mposMerchantFeeMapper.findTempFeeTChannelType(paramMap);
		MposMerchantFee t1debitMerchantFee = mposMerchantFeeMapper.findMerchantFeeTChannelType(paramMap);
			if(t1debitMerchantFeeList!=null){
				mposMerchantFeeMapper.updateByShopperIdFee(t1debitMerchantFeeList);
				if(t1debitMerchantFee==null){
					mposMerchantFeeMapper.insertSelective(t1debitMerchantFeeList);
				}
			}else{
				if(t1debitMerchantFee!=null){
					mposMerchantFeeMapper.insertSelectiveTemp(t1debitMerchantFee);
				}
			}
		paramMap.put("feeType", Constants.FEE_TYPE_CREDIT);
		paramMap.put("channelType", Constants.T1_CHANNEL_TYPE);
		MposMerchantFee t1creditMerchantFeeList = mposMerchantFeeMapper.findTempFeeTChannelType(paramMap);
		MposMerchantFee t1creditMerchantFee = mposMerchantFeeMapper.findMerchantFeeTChannelType(paramMap);
		if(t1creditMerchantFeeList!=null){
			mposMerchantFeeMapper.updateByShopperIdFee(t1creditMerchantFeeList);
			if(t1creditMerchantFee==null){
				mposMerchantFeeMapper.insertSelective(t1creditMerchantFeeList);
			}
		}else{
			if(t1creditMerchantFee!=null){
				mposMerchantFeeMapper.insertSelectiveTemp(t1creditMerchantFee);
			}
			
		}
		
		paramMap.put("feeType", Constants.STATUS2);
		List<MposMerchantFee> weChatMerchantFeeList = mposMerchantFeeMapper.findMposMerchantFeeTempByType(paramMap);
		List<MposMerchantFee> weChatMerchantFee = mposMerchantFeeMapper.findMposMerchantFeeByType(paramMap);
		if(weChatMerchantFeeList!=null&&weChatMerchantFeeList.size()>0){
			mposMerchantFeeMapper.updateByShopperId(weChatMerchantFeeList.get(0));
			if(weChatMerchantFee==null){
				mposMerchantFeeMapper.insertSelective(weChatMerchantFeeList.get(0));
			}
		}else{
			if(weChatMerchantFee!=null&&weChatMerchantFee.size()>0){
				mposMerchantFeeMapper.insertSelectiveTemp(weChatMerchantFee.get(0));
			}
		}
		
		paramMap.put("feeType", Constants.STATUS3);
		List<MposMerchantFee> alipayMerchantFeeList = mposMerchantFeeMapper.findMposMerchantFeeTempByType(paramMap);
		List<MposMerchantFee> alipayMerchantFee = mposMerchantFeeMapper.findMposMerchantFeeByType(paramMap);
		if(alipayMerchantFeeList!=null&&alipayMerchantFeeList.size()>0){
			mposMerchantFeeMapper.updateByShopperId(alipayMerchantFeeList.get(0));
			if(alipayMerchantFee==null){
				mposMerchantFeeMapper.insertSelective(alipayMerchantFeeList.get(0));
			}
		}else{
			if(alipayMerchantFee!=null&alipayMerchantFee.size()>0){
				mposMerchantFeeMapper.insertSelectiveTemp(alipayMerchantFee.get(0));
			}
		}
		
		paramMap.put("feeType", Constants.STATUS4);
		List<MposMerchantFee> ylpayMerchantFeeList = mposMerchantFeeMapper.findMposMerchantFeeTempByType(paramMap);
		List<MposMerchantFee> ylpayMerchantFee = mposMerchantFeeMapper.findMposMerchantFeeByType(paramMap);
		if(ylpayMerchantFeeList != null && ylpayMerchantFeeList.size() > 0){
			mposMerchantFeeMapper.updateByShopperId(ylpayMerchantFeeList.get(0));
			if(ylpayMerchantFee==null){
				mposMerchantFeeMapper.insertSelective(ylpayMerchantFeeList.get(0));	
			}
		}else{
			if(ylpayMerchantFee!=null&&ylpayMerchantFee.size()>0){
				mposMerchantFeeMapper.insertSelectiveTemp(ylpayMerchantFee.get(0));	
			}
			
		}
		
		//快捷汇率信息更新插入
		paramMap.put("feeType", Constants.FEE_TYPE_SHORTCUT);
		List<MposMerchantFee> shortCutMerchantFeeList = mposMerchantFeeMapper.findMposMerchantFeeTempByType(paramMap);//查询临时表
		List<MposMerchantFee> shortCutMerchantFee = mposMerchantFeeMapper.findMposMerchantFeeByType(paramMap);//查询正式表
		if(shortCutMerchantFeeList!=null&&shortCutMerchantFeeList.size()>0){
			mposMerchantFeeMapper.updateByShopperId(shortCutMerchantFeeList.get(0));//更新正式表
			if(shortCutMerchantFee==null){
				mposMerchantFeeMapper.insertSelective(shortCutMerchantFeeList.get(0));//插入正式表
			}
		}else{
			if(shortCutMerchantFee!=null&&shortCutMerchantFee.size()>0){
				mposMerchantFeeMapper.insertSelectiveTemp(shortCutMerchantFee.get(0));//插入临时表
			}
		}
		
		//快捷汇率信息更新插入
		paramMap.put("feeType", Constants.FEE_TYPE_SHD0);
		List<MposMerchantFee> shortCutSHMerchantFeeList = mposMerchantFeeMapper.findMposMerchantFeeTempByType(paramMap);//查询临时表
		List<MposMerchantFee> shortCutSHMerchantFee = mposMerchantFeeMapper.findMposMerchantFeeByType(paramMap);//查询正式表
		if(shortCutSHMerchantFeeList!=null&&shortCutSHMerchantFeeList.size()>0){
			mposMerchantFeeMapper.updateByShopperId(shortCutSHMerchantFeeList.get(0));//更新正式表
			if(shortCutSHMerchantFee==null){
				mposMerchantFeeMapper.insertSelective(shortCutSHMerchantFeeList.get(0));//插入正式表
			}
		}else{
			if(shortCutSHMerchantFee!=null&&shortCutSHMerchantFee.size()>0){
				mposMerchantFeeMapper.insertSelectiveTemp(shortCutSHMerchantFee.get(0));//插入临时表
			}
		}
		
		//B2C汇率信息更新插入
		paramMap.put("feeType", Constants.FEE_TYPE_B2C);
		List<MposMerchantFee> b2cMerchantFeeList = mposMerchantFeeMapper.findMposMerchantFeeTempByType(paramMap);
		List<MposMerchantFee> b2cMerchantFee = mposMerchantFeeMapper.findMposMerchantFeeByType(paramMap);
		if(b2cMerchantFeeList!=null&&b2cMerchantFeeList.size()>0){
			mposMerchantFeeMapper.updateByShopperId(b2cMerchantFeeList.get(0));
			if(b2cMerchantFee==null){
				mposMerchantFeeMapper.insertSelective(b2cMerchantFeeList.get(0));
			}
		}else{
			if(b2cMerchantFee!=null&&b2cMerchantFee.size()>0){
				mposMerchantFeeMapper.insertSelectiveTemp(b2cMerchantFee.get(0));
			}
		}
		
	}
	public void updateB2cshopper(B2cShopperbiTemp b2cShopperbi) {
		Map map=new HashMap();
		map.put("qrPayNo", b2cShopperbi.getQrPayNo());
		map.put("qrpayMerchantkey", b2cShopperbi.getQrpayMerchantkey());
		map.put("merchantNo", b2cShopperbi.getShopperid());
		map.put("settleType", b2cShopperbi.getSettleType());
		map.put("creditLines", b2cShopperbi.getCreditLines());
		b2cShopperbiMapper.updateQrPayCode(map);
		b2cShopperbiTempMapper.updateQrPayCode(map);
		
	}
}
