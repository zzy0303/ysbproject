package com.uns.model;

public class AgentRatio{
	//key
	private java.lang.Long phyid;
	
	// fields
	private java.lang.Long agentid;
	private java.lang.Double rangeamt;
	private java.lang.Double ratio;
	private java.lang.String updatedate;
	private java.lang.String updatemaker;
	private java.lang.String modeflag;
	private java.lang.Long amid;
	
	public java.lang.Long getAmid() {
		return amid;
	}
	public void setAmid(java.lang.Long amid) {
		this.amid = amid;
	}
	public java.lang.Long getPhyid() {
		return phyid;
	}
	public void setPhyid(java.lang.Long phyid) {
		this.phyid = phyid;
	}
	public java.lang.Double getRangeamt() {
		return rangeamt;
	}
	public void setRangeamt(java.lang.Double rangeamt) {
		this.rangeamt = rangeamt;
	}
	public java.lang.String getModeflag() {
		return modeflag;
	}
	public void setModeflag(java.lang.String modeflag) {
		this.modeflag = modeflag;
	}
	public java.lang.Long getAgentid() {
		return agentid;
	}
	public void setAgentid(java.lang.Long agentid) {
		this.agentid = agentid;
	}
	
	public java.lang.Double getRatio() {
		return ratio;
	}
	public void setRatio(java.lang.Double ratio) {
		this.ratio = ratio;
	}
	public java.lang.String getUpdatedate() {
		return updatedate;
	}
	public void setUpdatedate(java.lang.String updatedate) {
		this.updatedate = updatedate;
	}
	public java.lang.String getUpdatemaker() {
		return updatemaker;
	}
	public void setUpdatemaker(java.lang.String updatemaker) {
		this.updatemaker = updatemaker;
	}
}