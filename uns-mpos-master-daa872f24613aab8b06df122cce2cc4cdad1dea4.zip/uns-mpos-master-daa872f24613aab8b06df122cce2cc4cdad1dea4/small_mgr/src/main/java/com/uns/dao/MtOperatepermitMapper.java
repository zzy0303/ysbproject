package com.uns.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.MtOperatepermit;
@Repository
public interface MtOperatepermitMapper extends BaseMapper<Object>{

    List<MtOperatepermit> selectAllPermitTypeList();
}