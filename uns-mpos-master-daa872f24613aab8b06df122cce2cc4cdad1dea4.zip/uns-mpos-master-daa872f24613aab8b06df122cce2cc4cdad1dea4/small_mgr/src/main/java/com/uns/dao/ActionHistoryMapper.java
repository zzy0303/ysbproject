package com.uns.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.ActionHistory;
import com.uns.web.form.TerminalForm;

@Repository
public interface ActionHistoryMapper extends BaseMapper<Object>{

    int deleteByPrimaryKey(Short id);

    int insert(ActionHistory record);

    int insertSelective(ActionHistory record);

    ActionHistory selectByPrimaryKey(Short id);

    int updateByPrimaryKeySelective(ActionHistory record);

    int updateByPrimaryKey(ActionHistory record);
    
    List<ActionHistory> selectAgentBinderList(TerminalForm form);
    
    int selectAgentBinderCount();      //查询所有变更类型为1,审核状态为2的总数
    
    ActionHistory selectAllByPrimaryKey(Short id);
}