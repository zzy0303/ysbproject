package com.uns.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.model.FunctionMerInfo;
import com.uns.model.Operator;
import com.uns.model.RoleMerInfo;
import com.uns.service.RoleMerService;
import com.uns.util.StringUtils;
import com.uns.web.form.RoleForm;

@Controller("RoleMerController")
@RequestMapping("/roleMer.htm")
public class RoleMerController extends BaseController{
	
	@Autowired
	private RoleMerService roleMerService;
	
	/**代理商角色管理
	 * @param request
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(params = "method=toRoleMerManageList")
	public String toRoleMerManageList(HttpServletRequest request,@ModelAttribute("mb") RoleForm mbForm, ModelMap modelMap) throws BusinessException{
		try {
			List roleManagerList=roleMerService.selectRoleMerList(mbForm);
			modelMap.put("rolePageList",roleManagerList );
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.权限列表页面出错);
		}
		return "role/roleMerList";
	}
	
	/**增加代理商角色
	 * @param request
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=roleMerAdd")
	@FormToken(save=true)
	public String roleMerAdd(HttpServletRequest request, ModelMap modelMap) throws Exception {
		try {
			Operator operator = (Operator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			if(operator==null) throw new BusinessException(ExceptionDefine.登录失效);
			List listFuncSelect = new ArrayList();
			request.setAttribute("funcSelect", listFuncSelect);
			// 查询返回功能树
			Map map = roleMerService.findAllFunction();
			request.setAttribute("functionTree", map);
			modelMap.put("operator", operator);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.增加代理商角色);
		}
		
		return "role/roleMerAdd";
	}
	
	/**保存代理商角色
	 * @param request
	 * @param modelMap
	 * @param mbForm
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=saveRoleMer")
	@FormToken(remove=true)
	public String saveRoleMer(HttpServletRequest request, ModelMap modelMap,@ModelAttribute("mb") RoleForm mbForm) throws Exception {
		Operator operator = (Operator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
		if(operator==null) throw new BusinessException(ExceptionDefine.登录失效);
		try{
			RoleMerInfo roleInfo=new RoleMerInfo();
			String roleName = mbForm.getRoleName();
			String remark = mbForm.getRemark();
			roleInfo.setRoleName(roleName);
			roleInfo.setRemark(remark);
			roleInfo.setCreateUser(operator.getId());
			roleInfo.setCreateDate(new Date());
			roleInfo.setStatus(Long.valueOf(Constants.CON_YES));
			Long[] ids = mbForm.getIds();
	
			roleMerService.insert(roleInfo, ids);
			request.setAttribute(Constants.MESSAGE_KEY, "角色添加成功!");
			request.setAttribute("url", "roleMer.htm?method=toRoleMerManageList");
		}catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.保存代理商角色);
		}
		return "/returnPage";
	}
	
	
	/**去修改页面
	 * @param request
	 * @param modelMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=updateRoleMer")
	@FormToken(save=true)
	public String updateRoleMer(HttpServletRequest request, ModelMap modelMap) throws Exception {
		try{
			String id = request.getParameter("roleId");
			Operator operator = null;
			RoleMerInfo roleInfo = null;
			List listFuncSelect = new ArrayList();
			if (org.apache.commons.lang.StringUtils.isNotEmpty(id)) {
				operator = (Operator) request.getSession().getAttribute(Constants.SESSION_KEY_USER);
				roleInfo = roleMerService.selectByRoleId(id);
				List listFunction = new ArrayList(roleMerService.selectById(id));
				for (Iterator iter = listFunction.iterator(); iter.hasNext();) {
					FunctionMerInfo func = (FunctionMerInfo) iter.next();
					listFuncSelect.add(func.getId());
				}
			}
			request.setAttribute("funcSelect", listFuncSelect);

			// 查询返回功能树
			Map map = roleMerService.findAllFunction();
			request.setAttribute("functionTree", map);
			modelMap.put("roleInfo", roleInfo);
			modelMap.put("operator", operator);
		}catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.代理商角色修改);
		}
		return "role/roleMerUpdate";
	}
	
	/**保存修改信息
	 * @param request
	 * @param modelMap
	 * @param mbForm
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=saveUpdateRoleMer")
	@FormToken(remove=true)
	public String saveUpdateRoleMer(HttpServletRequest request, ModelMap modelMap,@ModelAttribute("mb") RoleForm mbForm) throws Exception {
		try {
			RoleMerInfo roleInfo=new RoleMerInfo();
			Long operatorId=mbForm.getOperatorId();
			Long roleId = mbForm.getRoleId();
			String roleName=mbForm.getRoleName();
			String remark=mbForm.getRemark();
			roleInfo.setId(roleId);
			roleInfo.setRoleName(roleName);
			roleInfo.setRemark(remark);
			roleInfo.setUpdateUser(operatorId);
			roleInfo.setUpdateDate(new Date());
			roleInfo.setStatus(Long.valueOf(Constants.CON_YES));
			Long[] ids=mbForm.getIds();
			roleMerService.update(roleInfo,ids);
			
			request.setAttribute(Constants.MESSAGE_KEY,"修改成功!");
			request.setAttribute("url", "roleMer.htm?method=toRoleMerManageList");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.保存代理商角色);
		}
		
		return "/returnPage";
	}
	
	/**删除角色和权限
	 * @param request
	 * @param mbForm
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=toDeleteRoleMer")
	public String toDeleteRoleMer(HttpServletRequest request,@ModelAttribute("mb") RoleForm mbForm, ModelMap modelMap) throws Exception{
		
		Long roleId = mbForm.getRoleId();
		if(roleId!=null){
			roleMerService.delete(roleId);
			request.setAttribute(Constants.MESSAGE_KEY,"删除成功!");
			request.setAttribute("url", "roleMer.htm?method=toRoleMerManageList");
		}else{
			request.setAttribute(Constants.MESSAGE_KEY,"删除失败!");
			request.setAttribute("url", "roleMer.htm?method=toRoleMerManageList");
		}
		return "/returnPage";
	}
	
	/**利用Ajax判断角色名是否已存在
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(params = "method=ajaxRoleName")
	public String ajaxRoleName(HttpServletRequest request,HttpServletResponse response) throws Exception{
		PrintWriter out = null;
		try {
			String operatorId=request.getParameter("operatorId");
			String roleName = request.getParameter("roleName").trim();
			List<RoleMerInfo> roleInfoList=null;
			if(!StringUtils.isEmpty(roleName)){
				roleInfoList = roleMerService.getRoleInfoByName(roleName,
						operatorId);
			}
			boolean isExist = false;
			if(roleInfoList!=null&&roleInfoList.size()>0){
				isExist = true;
			}
			out = response.getWriter();
			out.println("{isExist:"+isExist+"}");
		} catch (IOException e) {
			e.printStackTrace();
			if(out !=null ){
				out.flush();
				out.close();
			}
			throw new BusinessException(ExceptionDefine.验证用户名);
		}finally{
			if(out !=null){
				out.flush();
				out.close();
			}
		}
		return null;
	}
}
