package com.uns.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.TerminalHistory;
@Repository
public interface TerminalHistoryMapper {

    int insert(TerminalHistory record);

    int insertSelective(TerminalHistory record);

	List findTermianlHistroy(String termNo);

}