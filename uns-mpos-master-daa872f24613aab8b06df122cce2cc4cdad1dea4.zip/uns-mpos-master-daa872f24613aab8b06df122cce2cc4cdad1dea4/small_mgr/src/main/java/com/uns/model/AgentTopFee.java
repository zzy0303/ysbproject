package com.uns.model;

import java.math.BigDecimal;
import java.util.Date;

public class AgentTopFee {
    private Long id;

    private String topamountMin;

    private String topamountMax;

    private String agentFee;

    private Date createDate;

    private Date updateDate;

    private String createUser;

    private String updateUser;
    
    private String sumFee;
    
    private String agentFeeMin;
    
    private String t0Fee;
    
    private String actionType;


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTopamountMin() {
        return topamountMin;
    }

    public void setTopamountMin(String topamountMin) {
        this.topamountMin = topamountMin == null ? null : topamountMin.trim();
    }

    public String getTopamountMax() {
        return topamountMax;
    }

    public void setTopamountMax(String topamountMax) {
        this.topamountMax = topamountMax == null ? null : topamountMax.trim();
    }

    public String getAgentFee() {
        return agentFee;
    }

    public void setAgentFee(String agentFee) {
        this.agentFee = agentFee == null ? null : agentFee.trim();
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser == null ? null : createUser.trim();
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser == null ? null : updateUser.trim();
    }

	public String getSumFee() {
		return sumFee;
	}

	public void setSumFee(String sumFee) {
		this.sumFee = sumFee;
	}

	public String getAgentFeeMin() {
		return agentFeeMin;
	}

	public void setAgentFeeMin(String agentFeeMin) {
		this.agentFeeMin = agentFeeMin;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public String getT0Fee() {
		return t0Fee;
	}

	public void setT0Fee(String t0Fee) {
		this.t0Fee = t0Fee;
	}

}