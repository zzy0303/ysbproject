package com.uns.web.form;

import org.springframework.web.multipart.MultipartFile;

public class BatchForm {
	 private MultipartFile  batchfile;

	public MultipartFile getBatchfile() {
		return batchfile;
	}

	public void setBatchfile(MultipartFile batchfile) {
		this.batchfile = batchfile;
	}
	 

}
