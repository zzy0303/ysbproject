package com.uns.web.form;

public class AgentSplitFeeForm {
	
	private String shopperids;
	private String tranidNo;
	private String settdateStart;
	private String settdateEnd;
	private String amountStart;
	private String amountEnd;
	
	public String getShopperids() {
		return shopperids;
	}
	public void setShopperids(String shopperids) {
		this.shopperids = shopperids;
	}
	public String getTranidNo() {
		return tranidNo;
	}
	public void setTranidNo(String tranidNo) {
		this.tranidNo = tranidNo;
	}
	public String getSettdateStart() {
		return settdateStart;
	}
	public void setSettdateStart(String settdateStart) {
		this.settdateStart = settdateStart;
	}
	public String getSettdateEnd() {
		return settdateEnd;
	}
	public void setSettdateEnd(String settdateEnd) {
		this.settdateEnd = settdateEnd;
	}
	public String getAmountStart() {
		return amountStart;
	}
	public void setAmountStart(String amountStart) {
		this.amountStart = amountStart;
	}
	public String getAmountEnd() {
		return amountEnd;
	}
	public void setAmountEnd(String amountEnd) {
		this.amountEnd = amountEnd;
	}
	
	

}
