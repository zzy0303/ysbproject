package com.uns.util;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 文件操作类
 * @author yang.liu01
 *
 */
public class FileOperateUtil {

	
	/**
	 * 文件下载
	 * @param dir 文件目录
	 * @param fileName 文件名称
	 * @param response
	 * @param request
	 */
	public static void downloadTemplate(String dir,String fileName,HttpServletResponse response,
			HttpServletRequest request) {
		String path = request.getContextPath();
		String basePath = request.getScheme() + "://"
				+ request.getServerName() + ":" + request.getServerPort()
				+ path + "/";
		String filePath =request.getSession().getServletContext().getRealPath("/")+
				"upload"+File.separator+dir+File.separator+fileName ;
    	String file = "";
    	
    	System.out.println("文件路径："+filePath);
    	
    	//从文件完整路径中提取文件名，并进行编码转换，防止不能正确显示中文名
    	try {
        	if(filePath.lastIndexOf("/") > 0) {
        		file = new String(filePath.substring(filePath.lastIndexOf("/")+1, filePath.length()).getBytes("GB2312"), "ISO8859_1");
        	}else if(filePath.lastIndexOf("\\") > 0) {
        		file = new String(filePath.substring(filePath.lastIndexOf("\\")+1, filePath.length()).getBytes("GB2312"), "ISO8859_1");
        	}
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    	//打开指定文件的流信息
    	InputStream fs = null;
    	try {
    		fs = new FileInputStream(new File(filePath));
    		
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    	//设置响应头和保存文件名 
    	response.setCharacterEncoding("ISO-8859-1");
    	response.setContentType("APPLICATION/OCTET-STREAM"); 
    	response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
    	//写出流信息
    	int b = 0;
    	try {
        	PrintWriter out = response.getWriter();
        	while((b=fs.read())!=-1) {
        		out.write(b);
        	}
        	out.flush();
        	fs.close();
        	out.close();
        	System.out.println("文件下载完毕.");
    	}catch(Exception e) {
        	e.printStackTrace();
        	System.out.println("下载文件失败!");
    	}
	}
}
