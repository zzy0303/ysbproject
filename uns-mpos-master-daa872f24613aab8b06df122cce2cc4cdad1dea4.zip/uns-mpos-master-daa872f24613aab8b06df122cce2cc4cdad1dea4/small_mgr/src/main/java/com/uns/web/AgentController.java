package com.uns.web;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.model.Agent;
import com.uns.service.AgentService;
import com.uns.web.form.ShopPerbiForm;

@Controller
@RequestMapping(value = "/agent.htm")
public class AgentController extends BaseController{
	@Autowired
	private AgentService agentservice;

	/**
	 * @param request
	 * @return
	 */
	@RequestMapping(params="method=selectAgentTree")
	public String selectAgentTree(HttpServletRequest request){
		List list = agentservice.searchAgentTree();
		Map mapReturn = new HashMap();
		//循环遍历所有功能，放入map中，key为parentId_Id (上级功能Id和Id)
		for(Iterator iter = list.iterator(); iter.hasNext();){
			Agent agent = (Agent)iter.next();
			String strParentId="1";
			if(agent.getShopperidP()!=null){
				strParentId=agent.getShopperidP().toString();
			}
			String strId = String.valueOf(agent.getShopperid());         //角色编号
			String strKey = strParentId + "_" + strId;
			mapReturn.put(strKey, agent);
		}
		request.setAttribute("mapTree", mapReturn);
		return "agent/agent_tree";
	}
	
	
	
	
	@RequestMapping(params="method=selectAgentTree_t")
	public String selectAgentTree_t(HttpServletRequest request){
	    Agent agent = new Agent();
	    List list = agentservice.findAgentByMerchantId();
	    Map mapReturn = new HashMap();
		//循环遍历所有功能，放入map中，key为parentId_Id (上级功能Id和Id)
		for(int i=0;i<list.size();i++){
			agent = (Agent)list.get(i);
			String strParentId="1";
	
			if(agent.getShopperidP()!=null){
				strParentId=agent.getShopperidP().toString();
			}
			String strId = String.valueOf(agent.getShopperid());         //角色编号
			String strKey = strParentId + "_" + strId;
			mapReturn.put(strKey, agent);
		}
		request.setAttribute("mapTree", mapReturn);
	
		return "agent/agent_trees_t";
		//return "agent/agent_tree";
		  
	}
	
	/**代理商修改时，查询上级代理商为临时表
	 * @param request
	 * @return
	 */
	@RequestMapping(params="method=updateAgentTreeByCode")
	public String updateAgentTreeByCode(HttpServletRequest request){
		Agent agent = (Agent)request.getSession().getAttribute("agent");
		String merchantId=agent.getShopperid()==null?"":agent.getShopperid().toString();
		String shopperId=request.getParameter("shopperId");
		
		List list = agentservice.updateAgentByMerchantId(merchantId,shopperId);
		Map mapReturn = new HashMap();
		//循环遍历所有功能，放入map中，key为parentId_Id (上级功能Id和Id)
		for(int i=0;i<list.size();i++){
			agent = (Agent)list.get(i);
			String strParentId="1";
	
			if(agent.getShopperidP()!=null&&!merchantId.equals(agent.getShopperid().toString())){
				strParentId=agent.getShopperidP().toString();
			}
			String strId = String.valueOf(agent.getShopperid());         //角色编号
			String strKey = strParentId + "_" + strId;
			mapReturn.put(strKey, agent);
		}
		request.setAttribute("mapTree", mapReturn);
		return "agent/agent_tree";
	}
	@RequestMapping(params="method=selectAgentTreeByCode")
	public String selectAgentTreeByCode(HttpServletRequest request){
		String scompany=request.getParameter("scompany");
	    Agent agent = new Agent();
	    List list = agentservice.findAgentByMerchantId1(scompany);
	    Map mapReturn = new HashMap();
		//循环遍历所有功能，放入map中，key为parentId_Id (上级功能Id和Id)
		for(int i=0;i<list.size();i++){
			agent = (Agent)list.get(i);
			String strParentId="1";
	
			if(agent.getShopperidP()!=null){
				strParentId=agent.getShopperidP().toString();
			}
			String strId = String.valueOf(agent.getShopperid());         //角色编号
			String strKey = strParentId + "_" + strId;
			mapReturn.put(strKey, agent);
		}
		request.setAttribute("mapTree", mapReturn);
	
		return "agent/agent_trees";
		//return "agent/agent_tree";
		  
	}
	
	@RequestMapping(params="method=findAgentTreeByScompany")
	public String findAgentTreeByScompany(HttpServletRequest request){
		String scompany=request.getParameter("scompany");
	    Agent agent = new Agent();
	    List list = agentservice.findAgentByMerchantId1(scompany);
	    Map mapReturn = new HashMap();
		//循环遍历所有功能，放入map中，key为parentId_Id (上级功能Id和Id)
		for(int i=0;i<list.size();i++){
			agent = (Agent)list.get(i);
			String strParentId="1";
	
			if(agent.getShopperidP()!=null){
				strParentId=agent.getShopperidP().toString();
			}
			String strId = String.valueOf(agent.getShopperid());         //角色编号
			String strKey = strParentId + "_" + strId;
			mapReturn.put(strKey, agent);
		}
		request.setAttribute("mapTree", mapReturn);
	
		return "agent/agent_trees_check";
	}
	
	
	@RequestMapping(params="method=selectAgentTreeByShopperId")
	public String selectAgentTreeByShopperId(HttpServletRequest request){
		Agent agent = new Agent();
	    List list = agentservice.findAgentByMerchantId();
	    Map mapReturn = new HashMap();
		//循环遍历所有功能，放入map中，key为parentId_Id (上级功能Id和Id)
		for(int i=0;i<list.size();i++){
			agent = (Agent)list.get(i);
			String strParentId="1";
	
			if(agent.getShopperidP()!=null){
				strParentId=agent.getShopperidP().toString();
			}
			String strId = String.valueOf(agent.getShopperid());         //角色编号
			String strKey = strParentId + "_" + strId;
			mapReturn.put(strKey, agent);
		}
		request.setAttribute("mapTree", mapReturn);
	
		return "agent/agent_trees";
	}
	
	@RequestMapping(params = "method=findAgent")
	@FormToken(save=true)
	public String findAgent(HttpServletRequest request, 
			ModelMap modelMap,ShopPerbiForm mbForm) throws Exception {
		try {
			Agent agent=null;
			String Id=request.getParameter("id");
			if(StringUtils.isEmpty(Id)){
			    request.setAttribute(Constants.MESSAGE_KEY,"");
                mbForm.setBelongsAgent(null);
                request.setAttribute("url","shopPerbi.htm?method=shopPerbiManageList");
			}else{
				agent=agentservice.searchAgentByShopperId(Id);
			}
			request.getSession().setAttribute("agent", agent);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.代理商编码不能为空);
		}
		
        
		return "shopPerbi/shopPerbiFindAgent";
	}
	
	
	
	
	
	/**查询一级代理商
	 * @param request
	 * @return
	 */
	@RequestMapping(params="method=findfirstAgent")
	public String findfirstAgent(HttpServletRequest request){
		String scompany=request.getParameter("scompany");
	    List list = agentservice.findfirstAgent(scompany);
	    Map mapReturn = new HashMap();
		//循环遍历所有功能，放入map中，key为parentId_Id (上级功能Id和Id)
		for(int i=0;i<list.size();i++){
			Agent agent = (Agent)list.get(i);
			String strParentId="1";
	
			if(agent.getShopperidP()!=null){
				strParentId=agent.getShopperidP().toString();
			}
			String strId = String.valueOf(agent.getShopperid());         //角色编号
			String strKey = strParentId + "_" + strId;
			mapReturn.put(strKey, agent);
		}
		request.setAttribute("mapTree", mapReturn);
	
		return "agent/agent_tree";
		  
	}
	
	/**查询一级代理商
	 * @param request
	 * @return
	 */
	@RequestMapping(params="method=findfirstAgent2")
	public String findfirstAgent2(HttpServletRequest request){
		//String scompany=request.getParameter("scompany");
	    List list = agentservice.findfirstAgent2();
	    Map mapReturn = new HashMap();
		//循环遍历所有功能，放入map中，key为parentId_Id (上级功能Id和Id)
		for(int i=0;i<list.size();i++){
			Agent agent = (Agent)list.get(i);
			String strParentId="1";
	
			if(agent.getShopperidP()!=null){
				strParentId=agent.getShopperidP().toString();
			}
			String strId = String.valueOf(agent.getShopperid());         //角色编号
			String strKey = strParentId + "_" + strId;
			mapReturn.put(strKey, agent);
		}
		request.setAttribute("mapTree", mapReturn);
	
		return "agent/agent_tree";
		  
	}
	
	
	/**查询代理商，并将代理商的mcc付给底价通道
	 * @param request
	 * @return
	 
	@RequestMapping(params="method=selectAgentTreeByShopperId")
	public String selectAgentTreeByShopperId(HttpServletRequest request){
		Agent agent = (Agent)request.getSession().getAttribute("agent");
		String merchantId=agent.getShopperid()==null?"":agent.getShopperid().toString();
		
		List list = agentservice.findAgentByMerchantId();
		Map mapReturn = new HashMap();
		//循环遍历所有功能，放入map中，key为parentId_Id (上级功能Id和Id)
		for(int i=0;i<list.size();i++){
			agent = (Agent)list.get(i);
			String strParentId="1";
			if(agent.getShopperidP()!=null&&!merchantId.equals(agent.getShopperid().toString())){
				strParentId=agent.getShopperidP().toString();
			}
			String strId = String.valueOf(agent.getShopperid());         //角色编号
			String strKey = strParentId + "_" + strId;
			mapReturn.put(strKey, agent);
		}
		request.setAttribute("mapTree", mapReturn);
		return "agent/agent_trees";
	}
	*/
	
	
	 // 获取下月第一天  
    public String getFirstDayOfNextMonth() {  
        String strFirstDay = "";  
        SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyyMMdd");  
          
        Calendar calendar = Calendar.getInstance();  
        calendar.add(Calendar.MONTH, 1);    // 加一个月  
        calendar.set(Calendar.DATE, 1);     // 设置当前月第一天  
          
        strFirstDay = sDateFormat.format(calendar.getTime());  
        return strFirstDay;  
    }  
   
}
