package com.uns.model;

import java.math.BigDecimal;
import java.util.Date;

public class BackupsShopperInformation {
    private BigDecimal id;

    private BigDecimal shopperid;

    private String accountBankDictval;

    private String accountBankProv;

    private String accountBankName;

    private String accountBankClientName;

    private String accountBankNo;

    private String cardtype;//无效字段

    private BigDecimal fee;

    private BigDecimal topAmount;//无效字段

    private BigDecimal t0fee;

    private String t0type;//无效字段

    private BigDecimal t0fixedamount;

    private BigDecimal t0topamount;

    private BigDecimal t0additionfee;

    private BigDecimal t0minamount;

    private BigDecimal t0maxamount;

    private Date createDate;

    private String createUser;
    
    private BigDecimal t0singledaylimit;
    
    private BigDecimal creditFee;
    
    private BigDecimal debitFee;
    
    public BigDecimal getT0singledaylimit() {
		return t0singledaylimit;
	}

	public void setT0singledaylimit(BigDecimal t0singledaylimit) {
		this.t0singledaylimit = t0singledaylimit;
	}

	public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public BigDecimal getShopperid() {
        return shopperid;
    }

    public void setShopperid(BigDecimal shopperid) {
        this.shopperid = shopperid;
    }

    public String getAccountBankDictval() {
        return accountBankDictval;
    }

    public void setAccountBankDictval(String accountBankDictval) {
        this.accountBankDictval = accountBankDictval == null ? null : accountBankDictval.trim();
    }

    public String getAccountBankProv() {
        return accountBankProv;
    }

    public void setAccountBankProv(String accountBankProv) {
        this.accountBankProv = accountBankProv == null ? null : accountBankProv.trim();
    }

    public String getAccountBankName() {
        return accountBankName;
    }

    public void setAccountBankName(String accountBankName) {
        this.accountBankName = accountBankName == null ? null : accountBankName.trim();
    }

    public String getAccountBankClientName() {
        return accountBankClientName;
    }

    public void setAccountBankClientName(String accountBankClientName) {
        this.accountBankClientName = accountBankClientName == null ? null : accountBankClientName.trim();
    }

    public String getAccountBankNo() {
        return accountBankNo;
    }

    public void setAccountBankNo(String accountBankNo) {
        this.accountBankNo = accountBankNo == null ? null : accountBankNo.trim();
    }

    public String getCardtype() {
        return cardtype;
    }

    public void setCardtype(String cardtype) {
        this.cardtype = cardtype == null ? null : cardtype.trim();
    }

    public BigDecimal getFee() {
        return fee;
    }

    public void setFee(BigDecimal fee) {
        this.fee = fee;
    }

    public BigDecimal getTopAmount() {
        return topAmount;
    }

    public void setTopAmount(BigDecimal topAmount) {
        this.topAmount = topAmount;
    }

    public BigDecimal getT0fee() {
        return t0fee;
    }

    public void setT0fee(BigDecimal t0fee) {
        this.t0fee = t0fee;
    }

    public String getT0type() {
        return t0type;
    }

    public void setT0type(String t0type) {
        this.t0type = t0type == null ? null : t0type.trim();
    }

    public BigDecimal getT0fixedamount() {
        return t0fixedamount;
    }

    public void setT0fixedamount(BigDecimal t0fixedamount) {
        this.t0fixedamount = t0fixedamount;
    }

    public BigDecimal getT0topamount() {
        return t0topamount;
    }

    public void setT0topamount(BigDecimal t0topamount) {
        this.t0topamount = t0topamount;
    }

    public BigDecimal getT0additionfee() {
        return t0additionfee;
    }

    public void setT0additionfee(BigDecimal t0additionfee) {
        this.t0additionfee = t0additionfee;
    }

    public BigDecimal getT0minamount() {
        return t0minamount;
    }

    public void setT0minamount(BigDecimal t0minamount) {
        this.t0minamount = t0minamount;
    }

    public BigDecimal getT0maxamount() {
        return t0maxamount;
    }

    public void setT0maxamount(BigDecimal t0maxamount) {
        this.t0maxamount = t0maxamount;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser == null ? null : createUser.trim();
    }

	public BigDecimal getCreditFee() {
		return creditFee;
	}

	public void setCreditFee(BigDecimal creditFee) {
		this.creditFee = creditFee;
	}

	public BigDecimal getDebitFee() {
		return debitFee;
	}

	public void setDebitFee(BigDecimal debitFee) {
		this.debitFee = debitFee;
	}
    
}