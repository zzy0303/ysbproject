package com.uns.model;

import java.math.BigDecimal;
import java.util.Date;

public class OrderInfo {
	private BigDecimal id;

	private Short actionType;

	private Long customerid;

	private Date orderTime;

	private BigDecimal amount;

	private String status;

	private String reserv1;

	private String reserv2;

	private String reserv3;

	private BigDecimal commission;

	private String outtradeNo;

	private String outtradeTime;

	private String commissionOrderNo;

	private String bankCode;

	private BigDecimal arrivalAmount;
	
	private Long shopperid;
	
	private String scompany;
	
	private String terminalNo;

	public String getTerminalNo() {
		return terminalNo;
	}

	public void setTerminalNo(String terminalNo) {
		this.terminalNo = terminalNo;
	}

	public Long getShopperid() {
		return shopperid;
	}

	public void setShopperid(Long shopperid) {
		this.shopperid = shopperid;
	}

	public String getScompany() {
		return scompany;
	}

	public void setScompany(String scompany) {
		this.scompany = scompany;
	}

	public BigDecimal getArrivalAmount() {
		return arrivalAmount;
	}

	public void setArrivalAmount(BigDecimal arrivalAmount) {
		this.arrivalAmount = arrivalAmount;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getCommissionOrderNo() {
		return commissionOrderNo;
	}

	public void setCommissionOrderNo(String commissionOrderNo) {
		this.commissionOrderNo = commissionOrderNo;
	}

	public String getOuttradeNo() {
		return outtradeNo;
	}

	public void setOuttradeNo(String outtradeNo) {
		this.outtradeNo = outtradeNo;
	}

	public String getOuttradeTime() {
		return outtradeTime;
	}

	public void setOuttradeTime(String outtradeTime) {
		this.outtradeTime = outtradeTime;
	}

	public BigDecimal getCommission() {
		return commission;
	}

	public void setCommission(BigDecimal commission) {
		this.commission = commission;
	}

	public BigDecimal getId() {
		return id;
	}

	public void setId(BigDecimal id) {
		this.id = id;
	}

	public Short getActionType() {
		return actionType;
	}

	public void setActionType(Short actionType) {
		this.actionType = actionType;
	}

	public Long getCustomerid() {
		return customerid;
	}

	public void setCustomerid(Long customerid) {
		this.customerid = customerid;
	}

	public Date getOrderTime() {
		return orderTime;
	}

	public void setOrderTime(Date orderTime) {
		this.orderTime = orderTime;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status == null ? null : status.trim();
	}

	public String getReserv1() {
		return reserv1;
	}

	public void setReserv1(String reserv1) {
		this.reserv1 = reserv1 == null ? null : reserv1.trim();
	}

	public String getReserv2() {
		return reserv2;
	}

	public void setReserv2(String reserv2) {
		this.reserv2 = reserv2 == null ? null : reserv2.trim();
	}

	public String getReserv3() {
		return reserv3;
	}

	public void setReserv3(String reserv3) {
		this.reserv3 = reserv3 == null ? null : reserv3.trim();
	}
}