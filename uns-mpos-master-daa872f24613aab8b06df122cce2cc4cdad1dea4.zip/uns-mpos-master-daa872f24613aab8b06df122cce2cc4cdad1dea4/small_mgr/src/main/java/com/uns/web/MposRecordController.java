package com.uns.web;

import java.io.OutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.page.Page;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.model.B2cShopperbi;
import com.uns.model.OrderInfo;
import com.uns.service.OrderInfoService;
import com.uns.service.ShopPerbiService;
import com.uns.util.HttpClientUtils;
import com.uns.util.Md5Encrypt;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import net.sf.json.JSONObject;

@Controller
@RequestMapping(value = "/mposRecordController.htm")
public class MposRecordController  extends BaseController{
	
	@Autowired
	private ShopPerbiService shopPerbiService;
	@Autowired
	private OrderInfoService orderInfoService;
	
	@InitBinder
    public void initBinder(HttpServletRequest request, ServletRequestDataBinder binder) throws Exception {
        binder.registerCustomEditor(Date.class, new CustomDateEditor(new SimpleDateFormat("yyyy-MM-dd"), true));
    }
	
	SimpleDateFormat sf = new SimpleDateFormat("yyyyMMddHHmmss");
	SimpleDateFormat sf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	SimpleDateFormat sf2 = new SimpleDateFormat("yyyy-MM-dd");
	SimpleDateFormat sf3 = new SimpleDateFormat("yyyyMMdd");
	
	static Map<String, String> mapStatus = new HashMap<String, String>();
	static{
		mapStatus.put("0", "冻结");
		mapStatus.put("1", "成功");
		mapStatus.put("2", "手续费成功");
		mapStatus.put("3", "手续费失败");
		mapStatus.put("4", "失败");
		mapStatus.put("5", "冻结取消");
	}
	
	/**
	 * 当日充值记录
	 * @throws BusinessException 
	 */
	@RequestMapping(params = "method=todayRechargeList")
	public String todayRechargeList(HttpServletRequest request,HttpServletResponse response,String flag,
			String minAmount,String maxAmount,String merchantId,String status) throws BusinessException {
		request.setAttribute("merchantId", merchantId);
		request.setAttribute("minAmount", minAmount);
		request.setAttribute("maxAmount", maxAmount);
		request.setAttribute("status", status);
		request.setAttribute("flag", flag);
		B2cShopperbi b2cShopperbi = null;
		String userId = null;
		if(!val(merchantId)){
			try {
				b2cShopperbi = shopPerbiService.selectFormalShopperId(merchantId);
			} catch (Exception e1) {
				request.setAttribute("rspMsg","查询异常！" );
				return "mpos/todayRechargeList";
			}
			if(b2cShopperbi==null){
				request.setAttribute("rspMsg",Constants.mapReturnMsg.get("11110005") );
				return "mpos/todayRechargeList";
			}
			//如果查到的商户没有银生宝账号
			userId = b2cShopperbi.getYsbNo();
			if(val(userId)){
				request.setAttribute("rspMsg",Constants.mapReturnMsg.get("11110010") );
				return "mpos/todayRechargeList";
			}
		}
		
		Calendar calendar = Calendar.getInstance();
	    calendar.setTime(new Date());
	    calendar.set(Calendar.HOUR_OF_DAY, 0);
	    calendar.set(Calendar.MINUTE, 0);
	    calendar.set(Calendar.SECOND, 0);
	     
	    Date start = calendar.getTime();
	 
	    calendar.add(Calendar.DAY_OF_MONTH, 1);
	    calendar.add(Calendar.SECOND, -1);
	     
	    Date end = calendar.getTime();
		
		Map<String, Object> qp = new HashMap<String, Object>();
		qp.put("customerid", userId);
		qp.put("startDate", sf.format(start));
		qp.put("endDate", sf.format(end));
		qp.put("minAmount", minAmount);
		qp.put("maxAmount", maxAmount);
 		qp.put("actionType", 1);
 		qp.put("status", "-1".equals(status)?null:status);
		try {
			List<OrderInfo> records = orderInfoService.selectOrderInfoList(qp);
			if(records.size() == 0){
				request.setAttribute("rspCode", "2222");
				request.setAttribute("rspMsg", "没有记录");
				return "mpos/todayRechargeList";
			}
			//根据订单号查询终端号
			List<String> orderList = new ArrayList<String>();
			for(int i=0;i<records.size();i++){
				orderList.add(records.get(i).getOuttradeNo());
			}
			List<Map<String, String>> terminalList = orderInfoService.selectTerminalNoCur(orderList);
			for(int i=0;i<records.size();i++){
				String orderNo = records.get(i).getOuttradeNo();
				for(int j=0;j<terminalList.size();j++){
					if(orderNo.equals(terminalList.get(j).get("TRANNO"))){
						records.get(i).setTerminalNo(terminalList.get(j).get("NUM"));
						break;
					}
				}
			}
			
			request.setAttribute("list", records);
			if("2".equals(flag)){
				Map<String, String> sum = orderInfoService.selectSum(qp);
				request.setAttribute("sum", sum);
			}
		} catch (Exception e) {
			request.setAttribute("rspMsg","查询异常！" );
			return "mpos/todayRechargeList";
		}
			
		request.setAttribute("rspCode", "0000");
		return "mpos/todayRechargeList";
	}
	
	/**
	 * 历史充值记录
	 * @throws BusinessException 
	 * @throws ParseException 
	 */
	@RequestMapping(params = "method=historyRechargeList")
	public String historyRechargeList(HttpServletRequest request,HttpServletResponse response,String minAmount,String maxAmount,
			String merchantId,Date startTime,Date endTime,String status,String flag) throws BusinessException, ParseException {
		request.setAttribute("merchantId", merchantId);
		request.setAttribute("minAmount", minAmount);
		request.setAttribute("maxAmount", maxAmount);
		request.setAttribute("status", status);
		request.setAttribute("flag", flag);
		request.setAttribute("startTime", startTime==null?null:sf2.format(startTime));
		request.setAttribute("endTime", endTime==null?null:sf2.format(endTime));

		B2cShopperbi b2cShopperbi = null;
		String userId = null;
		if(!val(merchantId)){
			try {
				b2cShopperbi = shopPerbiService.selectFormalShopperId(merchantId);
			} catch (Exception e1) {
				request.setAttribute("rspMsg","查询异常！" );
				return "mpos/historyRechargeList";
			}
			if(b2cShopperbi==null){
				request.setAttribute("rspMsg",Constants.mapReturnMsg.get("11110005") );
				return "mpos/historyRechargeList";
			}
			//如果查到的商户没有银生宝账号
			userId = b2cShopperbi.getYsbNo();
			if(val(userId)){
				request.setAttribute("rspMsg",Constants.mapReturnMsg.get("11110010") );
				return "mpos/historyRechargeList";
			}
		}
		
		Calendar calendar = Calendar.getInstance();
	    calendar.setTime(new Date());
	    calendar.set(Calendar.HOUR_OF_DAY, 0);
	    calendar.set(Calendar.MINUTE, 0);
	    calendar.set(Calendar.SECOND, 0);
	    calendar.add(Calendar.SECOND, -1);
	    Date start = calendar.getTime();
		if(endTime==null){
			endTime = start;
		}else if(start.before(endTime)){
			endTime =start;
		}
	    
		Map<String, Object> qp = new HashMap<String, Object>();
		qp.put("customerid", userId);
		qp.put("startDate", startTime==null?null:sf.format(startTime));
		qp.put("endDate", valDate(endTime));
		qp.put("minAmount", minAmount);
		qp.put("maxAmount", maxAmount);
		qp.put("actionType", 1);
		qp.put("status", "-1".equals(status)?null:status);

		try {
			List<OrderInfo> records = orderInfoService.selectOrderInfoList(qp);
			if(records.size() == 0){
				request.setAttribute("rspCode", "2222");
				request.setAttribute("rspMsg", "没有记录");
				return "mpos/historyRechargeList";
			}
			//根据订单号查询终端号
			List<String> orderList = new ArrayList<String>();
			for(int i=0;i<records.size();i++){
				orderList.add(records.get(i).getOuttradeNo());
			}
			List<Map<String, String>> terminalList = orderInfoService.selectTerminalNoHis(orderList);
			for(int i=0;i<records.size();i++){
				String orderNo = records.get(i).getOuttradeNo();
				for(int j=0;j<terminalList.size();j++){
					if(orderNo.equals(terminalList.get(j).get("TRANNO"))){
						records.get(i).setTerminalNo(terminalList.get(j).get("NUM"));
						break;
					}
				}
			}
			request.setAttribute("list", records);
			if("2".equals(flag)){
				Map<String, String> sum = orderInfoService.selectSum(qp);
				request.setAttribute("sum", sum);
			}
		} catch (Exception e) {
			request.setAttribute("rspMsg","查询异常！" );
			return "mpos/historyRechargeList";
		}
	
		request.setAttribute("rspCode", "0000");
		return "mpos/historyRechargeList";
	}
	
	/**
	 * 用户充值记录查询记录
	 * @throws BusinessException 
	 * @throws ParseException 
	 */
	@RequestMapping(params = "method=allList")
	public String allList(HttpServletRequest request,HttpServletResponse response,String minAmount,String maxAmount,
			String merchantId,Date startTime,Date endTime,String status,String type) throws BusinessException, ParseException {
		request.setAttribute("merchantId", merchantId);
		request.setAttribute("minAmount", minAmount);
		request.setAttribute("maxAmount", maxAmount);
		request.setAttribute("type", type);
		request.setAttribute("startTime", startTime==null?null:sf2.format(startTime));
		request.setAttribute("endTime", endTime==null?null:sf2.format(endTime));

		B2cShopperbi b2cShopperbi = null;
		String userId = null;
		if(!val(merchantId)){
			try {
				b2cShopperbi = shopPerbiService.selectFormalShopperId(merchantId);
			} catch (Exception e1) {
				request.setAttribute("rspMsg","查询异常！" );
				return "mpos/allList";
			}
			if(b2cShopperbi==null){
				request.setAttribute("rspMsg",Constants.mapReturnMsg.get("11110005") );
				return "mpos/allList";
			}
			//如果查到的商户没有银生宝账号
			userId = b2cShopperbi.getYsbNo();
			if(val(userId)){
				request.setAttribute("rspMsg",Constants.mapReturnMsg.get("11110010") );
				return "mpos/allList";
			}
		}
		
		Map<String, Object> qp = new HashMap<String, Object>();
		qp.put("customerid", userId);
		qp.put("startDate", startTime==null?null:sf.format(startTime));
		qp.put("endDate", valDate(endTime));
		qp.put("minAmount", minAmount);
		qp.put("maxAmount", maxAmount);
		qp.put("type", type==null?"-1":type);

		try {
			List<Map<String, String>> records = orderInfoService.selectAllList(qp);
			if(records.size() == 0){
				request.setAttribute("rspCode", "2222");
				request.setAttribute("rspMsg", "没有记录");
				return "mpos/allList";
			}
			request.setAttribute("list", records);
		} catch (Exception e) {
			request.setAttribute("rspMsg","查询异常！" );
			return "mpos/allList";
		}
	
		request.setAttribute("rspCode", "0000");
		return "mpos/allList";
	}
	
	/**
	 * T+0提现纪录
	 * @throws BusinessException 
	 * @throws ParseException 
	 */
	@RequestMapping(params = "method=t0withdrawRecordList")
	public String t0withdrawRecordList(HttpServletRequest request,HttpServletResponse response,String minAmount,String maxAmount,
			String merchantId,Date startTime,Date endTime,String status,String flag) throws BusinessException, ParseException {
		request.setAttribute("merchantId", merchantId);
		request.setAttribute("minAmount", minAmount);
		request.setAttribute("maxAmount", maxAmount);
		request.setAttribute("status", status);
		request.setAttribute("flag", flag);
		request.setAttribute("startTime", startTime==null?null:sf2.format(startTime));
		request.setAttribute("endTime", endTime==null?null:sf2.format(endTime));
		
		B2cShopperbi b2cShopperbi = null;
		String userId = null;
		if(!val(merchantId)){
			try {
				b2cShopperbi = shopPerbiService.selectFormalShopperId(merchantId);
			} catch (Exception e1) {
				request.setAttribute("rspMsg","查询异常！" );
				return "mpos/t0withdrawRecordList";
			}
			if(b2cShopperbi==null){
				request.setAttribute("rspMsg",Constants.mapReturnMsg.get("11110005") );
				return "mpos/t0withdrawRecordList";
			}
			//如果查到的商户没有银生宝账号
			userId = b2cShopperbi.getYsbNo();
			if(val(userId)){
				request.setAttribute("rspMsg",Constants.mapReturnMsg.get("11110010") );
				return "mpos/t0withdrawRecordList";
			}
		}
		
		Map<String, Object> qp = new HashMap<String, Object>();
		qp.put("customerid", userId);
		qp.put("startDate", startTime==null?null:sf.format(startTime));
		qp.put("endDate", valDate(endTime));
		qp.put("minAmount", minAmount);
		qp.put("maxAmount", maxAmount);
		qp.put("actionType", 2);
		if("2".equals(status)){
			qp.put("status", "2");
		}
		else if("1".equals(status)){
			qp.put("statusflag", "2");
		}
		
		try {
			List<OrderInfo> records = orderInfoService.selectOrderInfoList(qp);
			if(records.size() == 0){
				request.setAttribute("rspCode", "2222");
				request.setAttribute("rspMsg", "没有记录");
				return "mpos/t0withdrawRecordList";
			}
			request.setAttribute("list", records);
			
			if("2".equals(flag)){
				Map<String, String> sum = orderInfoService.selectSum(qp);
				request.setAttribute("sum", sum);
			}
		} catch (Exception e) {
			request.setAttribute("rspMsg","查询异常！" );
			return "mpos/t0withdrawRecordList";
		}

		request.setAttribute("rspCode", "0000");
		return "mpos/t0withdrawRecordList";
	}
	
	/**
	 * 商户资金信息
	 * @throws BusinessException 
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(params = "method=immediatelyMoney")
	public String immediatelyMoney(HttpServletRequest request,HttpServletResponse response,String merchantId) throws BusinessException {
		request.setAttribute("merchantId", merchantId);
		
		if(val(merchantId)){
			return "mpos/immediatelyMoneyList";
		}
		
		Page page = new Page();
		page.setPageSize(Constants.page_size);
		
		if(request.getParameter("page")!=null && request.getParameter("page")!=""){
			page.setCurrentPage(Integer.valueOf(request.getParameter("page").toString()));
		}
		
		String str = "&page=" + page.getCurrentPage() + val("pageSize",Constants.page_size+"");
	
		String record = null;
		B2cShopperbi b2cShopperbi = null;
		try {
			b2cShopperbi = shopPerbiService.selectFormalShopperId(merchantId);
		} catch (Exception e1) {
			request.setAttribute("rspMsg","查询异常！" );
			return "mpos/todayRechargeList";
		}
		if(b2cShopperbi==null){
			request.setAttribute("rspMsg",Constants.mapReturnMsg.get("11110006") );
			return "mpos/immediatelyMoneyList";
		}
		//如果查到的商户没有银生宝账号
		String userId = b2cShopperbi.getFactoringno();
		if(val(userId)){
			request.setAttribute("rspMsg",Constants.mapReturnMsg.get("11110010") );
			return "mpos/immediatelyMoneyList";
		}
		try {
			String param = macBLZH(userId, str);
			log.info("mgr后台查询当日充值记录：");
			log.info("请求：" + DynamicConfigLoader.getByEnv("immediately_money.url") + "   " + param);
			record = HttpClientUtils.RE1postRequestStr(DynamicConfigLoader.getByEnv("immediately_money.url") ,param);
			log.info("响应：" + record);
			
			JSONObject  jasonObject = JSONObject.fromObject(record);
			Map map = (Map)jasonObject;
			if(Constants.convertCode.containsKey(map.get("rspCode"))){
				map.put("rspCode", Constants.convertCode.get(map.get("rspCode")));
			}
				
			if(Constants.mapReturnMsg.containsKey(map.get("rspCode"))){
				map.put("rspMsg", Constants.mapReturnMsg.get(map.get("rspCode")));
			}
			request.setAttribute("rspMsg", map.get("rspMsg"));
			List<Map<String, String>> list = new ArrayList<Map<String,String>>();
			if("0000".equals(map.get("rspCode"))){
				request.setAttribute("rspCode", "0000");
				request.setAttribute("amount", map.get("amount"));
				request.setAttribute("limitperday", map.get("limitperday"));
				request.setAttribute("availableAmount", map.get("availableAmount"));
				list = (List<Map<String, String>>) map.get("recordList");
				if(list.size()==0){
					request.setAttribute("rspMsg1", "当日没有提现记录");
				}else{
					int totalRows = map.get("total")==null?0:Integer.valueOf(map.get("total").toString());
					page.setTotalRows(totalRows);
					if(totalRows%Constants.page_size==0){
						page.setTotalPages(totalRows/Constants.page_size);
					}else{
						page.setTotalPages(totalRows/Constants.page_size + 1);
					}
				}
			}else{
				request.setAttribute("rspCode", "2222");
			}
			
			request.setAttribute("list", list);
			request.setAttribute("page", page);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "mpos/immediatelyMoneyList";
	}
	
	/**导出t0提现记录
	 * @param financingProductInfo
	 * @param request
	 * @param response18016881145
	 * @param modelMap
	 * @return
	 * @throws ParseException 
	 * @throws Exception
	 */
	@RequestMapping(params = "method=downloadT0")
	public String downloadT0(HttpServletRequest request, HttpServletResponse response,String status,
			String minAmount,String maxAmount,String merchantId,Date startTime,Date endTime) throws ParseException {
		request.setAttribute("merchantId", merchantId);
		request.setAttribute("minAmount", minAmount);
		request.setAttribute("maxAmount", maxAmount);
		request.setAttribute("status", status);
		request.setAttribute("startTime", startTime==null?null:sf2.format(startTime));
		request.setAttribute("endTime", endTime==null?null:sf2.format(endTime));
		List<OrderInfo> records = null;
		B2cShopperbi b2cShopperbi = null;
		String userId = null;
		if(!val(merchantId)){
			try {
				b2cShopperbi = shopPerbiService.selectFormalShopperId(merchantId);
			} catch (Exception e1) {
				request.setAttribute("rspMsg","导出异常！" );
				return "mpos/t0withdrawRecordList";
			}
			if(b2cShopperbi==null){
				request.setAttribute("rspMsg",Constants.mapReturnMsg.get("11110005") );
				return "mpos/t0withdrawRecordList";
			}
			//如果查到的商户没有银生宝账号
			userId = b2cShopperbi.getYsbNo();
			if(val(userId)){
				request.setAttribute("rspMsg",Constants.mapReturnMsg.get("11110010") );
				return "mpos/t0withdrawRecordList";
			}
		}
		
		Map<String, Object> qp = new HashMap<String, Object>();
		qp.put("customerid", userId);
		qp.put("startDate", startTime==null?null:sf.format(startTime));
		qp.put("endDate", valDate(endTime));
		qp.put("minAmount", minAmount);
		qp.put("maxAmount", maxAmount);
		qp.put("actionType", 2);
		if("2".equals(status)){
			qp.put("status", "2");
		}
		else if("1".equals(status)){
			qp.put("statusflag", "2");
		}
		try {
			records = orderInfoService.selectOrderInfoList(qp);
			if(records.size() == 0){
				request.setAttribute("rspCode", "2222");
				request.setAttribute("rspMsg", "没有记录");
				return "mpos/t0withdrawRecordList";
			}
		} catch (Exception e) {
			request.setAttribute("rspMsg","导出异常！" );
			return "mpos/t0withdrawRecordList";
		}
		
		try{
			outExcel(records,response,"T0提现记录",records.size());
		}catch (Exception e) {
			log.info("导出数据有误！");
			e.printStackTrace();
		}
		return null;
	}
	
	/**导出excel
	 * @param excelList T0/T1提现记录list
	 * @param response 
	 * @throws Exception
	 */
	private void outExcel(List<OrderInfo> excelList, HttpServletResponse response,String fileNames,
			int totalRows) throws Exception {
		
		response.setContentType("application/vnd.ms-excel");
		response.setHeader("content-disposition", "attachment;filename="+new String(fileNames.getBytes("GBK"),"iso8859-1")+".xls");
		response.setCharacterEncoding("UTF-8");
		
        OutputStream os = response.getOutputStream(); 
		WritableWorkbook wwb=Workbook.createWorkbook(os);
		WritableSheet sheet0 = wwb.createSheet("提现记录",0);
		sheet0.addCell(new Label(0,0, "总记录数"));
		sheet0.addCell(new Label(1,0, String.valueOf(totalRows)));
		sheet0.addCell(new Label(0,1, "商户号"));
		sheet0.addCell(new Label(1,1, "商户名称"));
		sheet0.addCell(new Label(2,1, "提现记录状态"));
        sheet0.addCell(new Label(3,1, "提现时间"));
        sheet0.addCell(new Label(4,1, "提现金额/元"));
        sheet0.addCell(new Label(5,1, "手续费/元"));
        sheet0.addCell(new Label(6,1, "到账金额/元"));
        sheet0.addCell(new Label(7,1, "订单号"));
        
        for (int i = 0; i < excelList.size(); i++) {  
            //转换成map集合{activyName:测试功能,count:2}  
        	OrderInfo info = (OrderInfo)excelList.get(i);  
            //循环输出map中的子集：既列值  
            sheet0.addCell(new Label(0,i+2, info.getShopperid()==null?null:info.getShopperid().toString()));
            sheet0.addCell(new Label(1,i+2, info.getScompany()));
            sheet0.addCell(new Label(2,i+2, "2".equals(info.getStatus())?"提现成功":"提现失败"));
            sheet0.addCell(new Label(3,i+2, info.getOrderTime()==null?null:sf1.format(info.getOrderTime())));
            sheet0.addCell(new Label(4,i+2, info.getAmount().toString()));
            sheet0.addCell(new Label(5,i+2, info.getCommission()==null?null:info.getCommission().toString()));
            sheet0.addCell(new Label(6,i+2, info.getArrivalAmount()==null?null:info.getArrivalAmount().toString()));
            sheet0.addCell(new Label(7,i+2, info.getOuttradeNo()));
        }
        //写入Exel工作表  
        wwb.write();  
        //关闭Excel工作薄对象   
        wwb.close();  
        //关闭流  
        os.flush();  
        os.close();  
          
        os =null;  
       
	}
	
	/**导出excel
	 * @param excelList 当日/历史充值记录
	 * @param response 
	 * @throws Exception
	 */
	private void outExcelRecharge(List<OrderInfo> excelList, HttpServletResponse response,String fileNames,
			int totalRows) throws Exception {
		
		response.setContentType("application/vnd.ms-excel");
		response.setHeader("content-disposition", "attachment;filename="+new String(fileNames.getBytes("GBK"),"iso8859-1")+".xls");
		response.setCharacterEncoding("UTF-8");
		
        OutputStream os = response.getOutputStream(); 
		WritableWorkbook wwb=Workbook.createWorkbook(os);
		WritableSheet sheet0 = wwb.createSheet("充值记录",0);
		sheet0.addCell(new Label(0,0, "总记录数"));
		sheet0.addCell(new Label(1,0, String.valueOf(totalRows)));
		sheet0.addCell(new Label(0,1, "商户号"));
		sheet0.addCell(new Label(1,1, "商户名称"));
		sheet0.addCell(new Label(2,1, "终端号"));
		sheet0.addCell(new Label(3,1, "提现记录状态"));
        sheet0.addCell(new Label(4,1, "充值时间"));
        sheet0.addCell(new Label(5,1, "充值金额/元"));
        sheet0.addCell(new Label(6,1, "手续费/元"));
        sheet0.addCell(new Label(7,1, "到账金额/元"));
        sheet0.addCell(new Label(8,1, "订单号"));
        
        for (int i = 0; i < excelList.size(); i++) {  
            //转换成map集合{activyName:测试功能,count:2}  
        	OrderInfo info = (OrderInfo)excelList.get(i);  
            //循环输出map中的子集：既列值  
            sheet0.addCell(new Label(0,i+2, info.getShopperid()==null?null:info.getShopperid().toString()));
            sheet0.addCell(new Label(1,i+2, info.getScompany()));
            sheet0.addCell(new Label(2,i+2, info.getTerminalNo()));
            sheet0.addCell(new Label(3,i+2, mapStatus.get(info.getStatus())));
            sheet0.addCell(new Label(4,i+2, info.getOrderTime()==null?null:sf1.format(info.getOrderTime())));
            sheet0.addCell(new Label(5,i+2, info.getAmount()==null?null:info.getAmount().toString()));
            sheet0.addCell(new Label(6,i+2, info.getCommission()==null?null:info.getCommission().toString()));
            sheet0.addCell(new Label(7,i+2, info.getArrivalAmount()==null?null:info.getArrivalAmount().toString()));
            sheet0.addCell(new Label(8,i+2, info.getOuttradeNo()==null?null:info.getOuttradeNo()));
        }
        //写入Exel工作表  
        wwb.write();  
        //关闭Excel工作薄对象   
        wwb.close();  
        //关闭流  
        os.flush();  
        os.close();  
          
        os =null;  
       
	}
	
	/**
	 * 导出充值提现记录
	 */
	private void outExcelAll(List<Map<String,String>> excelList, HttpServletResponse response,String fileNames) throws Exception {
		
		response.setContentType("application/vnd.ms-excel");
		response.setHeader("content-disposition", "attachment;filename="+new String(fileNames.getBytes("GBK"),"iso8859-1")+".xls");
		response.setCharacterEncoding("UTF-8");
		
        OutputStream os = response.getOutputStream(); 
		WritableWorkbook wwb=Workbook.createWorkbook(os);
		WritableSheet sheet0 = wwb.createSheet("记录",0);
		sheet0.addCell(new Label(0,0, "商户号"));
		sheet0.addCell(new Label(1,0, "类型"));
		sheet0.addCell(new Label(2,0, "笔数"));
        sheet0.addCell(new Label(3,0, "总金额/元"));
        sheet0.addCell(new Label(4,0, "手续费/元"));
        
        for (int i = 0; i < excelList.size(); i++) {  
            //转换成map集合{activyName:测试功能,count:2}  
        	Map<String,String> map = (Map<String,String>)excelList.get(i);  
            //循环输出map中的子集：既列值  
            sheet0.addCell(new Label(0,i+1, String.valueOf(map.get("SHOPPERID"))));
            sheet0.addCell(new Label(1,i+1, String.valueOf(map.get("ACTIONTYPE"))));
            sheet0.addCell(new Label(2,i+1, String.valueOf(map.get("COUNTNUM"))));
            sheet0.addCell(new Label(3,i+1, String.valueOf(map.get("SUMNUM"))));
            sheet0.addCell(new Label(4,i+1, String.valueOf(map.get("COMMISSION"))));
        }
        //写入Exel工作表  
        wwb.write();  
        //关闭Excel工作薄对象   
        wwb.close();  
        //关闭流  
        os.flush();  
        os.close();  
          
        os =null;  
       
	}
	
	/**
	 * 页面查询T+1提现纪录
	 * @throws BusinessException 
	 * @throws ParseException 
	 */
	@RequestMapping(params = "method=t1withdrawRecordList")
	public String t1withdrawRecordList(HttpServletRequest request,HttpServletResponse response,String minAmount,String maxAmount,
			String merchantId,Date startTime,Date endTime,String status,String flag) throws BusinessException, ParseException {
		request.setAttribute("merchantId", merchantId);
		request.setAttribute("minAmount", minAmount);
		request.setAttribute("maxAmount", maxAmount);
		request.setAttribute("status", status);
		request.setAttribute("flag", flag);
		request.setAttribute("startTime", startTime==null?null:sf2.format(startTime));
		request.setAttribute("endTime", endTime==null?null:sf2.format(endTime));

		B2cShopperbi b2cShopperbi = null;
		String userId = null;
		if(!val(merchantId)){
			try {
				b2cShopperbi = shopPerbiService.selectFormalShopperId(merchantId);
			} catch (Exception e1) {
				request.setAttribute("rspMsg","查询异常！" );
				return "mpos/t1withdrawRecordList";
			}
			if(b2cShopperbi==null){
				request.setAttribute("rspMsg",Constants.mapReturnMsg.get("11110005") );
				return "mpos/t1withdrawRecordList";
			}
			//如果查到的商户没有银生宝账号
			userId = b2cShopperbi.getYsbNo();
			if(val(userId)){
				request.setAttribute("rspMsg",Constants.mapReturnMsg.get("11110010") );
				return "mpos/t1withdrawRecordList";
			}
		}
		Map<String, Object> qp = new HashMap<String, Object>();
		qp.put("customerid", userId);
		qp.put("startDate", startTime==null?null:sf.format(startTime));
		qp.put("endDate", valDate(endTime));
		qp.put("minAmount", minAmount);
		qp.put("maxAmount", maxAmount);
		qp.put("actionType", 3);
		if("2".equals(status)){
			qp.put("status", "2");
		}
		else if("1".equals(status)){
			qp.put("statusflag", "2");
		}
		try {
			List<OrderInfo> records = orderInfoService.selectOrderInfoList(qp);
			if(records.size() == 0){
				request.setAttribute("rspCode", "2222");
				request.setAttribute("rspMsg", "没有记录");
				return "mpos/t1withdrawRecordList";
			}
			request.setAttribute("list", records);
			if("2".equals(flag)){
				Map<String, String> sum = orderInfoService.selectSum(qp);
				request.setAttribute("sum", sum);
			}
		} catch (Exception e) {
			request.setAttribute("rspMsg","查询异常！" );
			return "mpos/t1withdrawRecordList";
		}
		
		request.setAttribute("rspCode", "0000");
		return "mpos/t1withdrawRecordList";
	}
	
	/**导出t1提现记录
	 * @param financingProductInfo
	 * @param request
	 * @param response18016881145
	 * @param modelMap
	 * @return
	 * @throws ParseException 
	 * @throws Exception
	 */
	@RequestMapping(params = "method=downloadT1")
	public String downloadT1(HttpServletRequest request, HttpServletResponse response,String status,
			String minAmount,String maxAmount,String merchantId,Date startTime,Date endTime) throws ParseException {
		request.setAttribute("merchantId", merchantId);
		request.setAttribute("minAmount", minAmount);
		request.setAttribute("maxAmount", maxAmount);
		request.setAttribute("status", status);
		request.setAttribute("startTime", startTime==null?null:sf2.format(startTime));
		request.setAttribute("endTime", endTime==null?null:sf2.format(endTime));
		B2cShopperbi b2cShopperbi = null;
		String userId = null;
		List<OrderInfo> records = null;
		if(!val(merchantId)){
			try {
				b2cShopperbi = shopPerbiService.selectFormalShopperId(merchantId);
			} catch (Exception e1) {
				request.setAttribute("rspMsg","导出异常！" );
				return "mpos/t1withdrawRecordList";
			}
			if(b2cShopperbi==null){
				request.setAttribute("rspMsg",Constants.mapReturnMsg.get("11110005") );
				return "mpos/t1withdrawRecordList";
			}
			//如果查到的商户没有银生宝账号
			userId = b2cShopperbi.getYsbNo();
			if(val(userId)){
				request.setAttribute("rspMsg",Constants.mapReturnMsg.get("11110010") );
				return "mpos/t1withdrawRecordList";
			}
		}
		Map<String, Object> qp = new HashMap<String, Object>();
		qp.put("customerid", userId);
		qp.put("startDate", startTime==null?null:sf.format(startTime));
		qp.put("endDate", valDate(endTime));
		qp.put("minAmount", minAmount);
		qp.put("maxAmount", maxAmount);
		qp.put("actionType", 3);
		if("2".equals(status)){
			qp.put("status", "2");
		}
		else if("1".equals(status)){
			qp.put("statusflag", "2");
		}
		try {
			records = orderInfoService.selectOrderInfoList(qp);
			if(records.size() == 0){
				request.setAttribute("rspCode", "2222");
				request.setAttribute("rspMsg", "没有记录");
				return "mpos/t1withdrawRecordList";
			}
		} catch (Exception e) {
			request.setAttribute("rspMsg","导出异常！" );
			return "mpos/t1withdrawRecordList";
		}
		
		try{
		    String fileName="T1提现记录";
		    outExcel(records,response,fileName,records.size());
		}catch (Exception e) {
			log.info("导出数据有误！");
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 导出当日充值记录
	 */
	@RequestMapping(params = "method=downloadToday")
	public String downloadToday(HttpServletRequest request,HttpServletResponse response,
			String minAmount,String maxAmount,String merchantId,String status) {
		request.setAttribute("merchantId", merchantId);
		request.setAttribute("minAmount", minAmount);
		request.setAttribute("maxAmount", maxAmount);
		request.setAttribute("status", status);
		
		List<OrderInfo> records = null;
		B2cShopperbi b2cShopperbi = null;
		String userId = null;
		if(!val(merchantId)){
			try {
				b2cShopperbi = shopPerbiService.selectFormalShopperId(merchantId);
			} catch (Exception e1) {
				request.setAttribute("rspMsg","查询异常！" );
				return "mpos/todayRechargeList";
			}
			if(b2cShopperbi==null){
				request.setAttribute("rspMsg",Constants.mapReturnMsg.get("11110005") );
				return "mpos/todayRechargeList";
			}
			//如果查到的商户没有银生宝账号
			userId = b2cShopperbi.getYsbNo();
			if(val(userId)){
				request.setAttribute("rspMsg",Constants.mapReturnMsg.get("11110010") );
				return "mpos/todayRechargeList";
			}
		}
		
		Calendar calendar = Calendar.getInstance();
	    calendar.setTime(new Date());
	    calendar.set(Calendar.HOUR_OF_DAY, 0);
	    calendar.set(Calendar.MINUTE, 0);
	    calendar.set(Calendar.SECOND, 0);
	     
	    Date start = calendar.getTime();
	 
	    calendar.add(Calendar.DAY_OF_MONTH, 1);
	    calendar.add(Calendar.SECOND, -1);
	     
	    Date end = calendar.getTime();
		
		Map<String, Object> qp = new HashMap<String, Object>();
		qp.put("customerid", userId);
		qp.put("startDate", sf.format(start));
		qp.put("endDate", sf.format(end));
		qp.put("minAmount", minAmount);
		qp.put("maxAmount", maxAmount);
 		qp.put("actionType", 1);
 		qp.put("status", "-1".equals(status)?null:status);
		try {
			records = orderInfoService.selectOrderInfoList(qp);
			if(records.size() == 0){
				request.setAttribute("rspCode", "2222");
				request.setAttribute("rspMsg", "没有记录");
				return "mpos/todayRechargeList";
			}
			//根据订单号查询终端号
			List<String> orderList = new ArrayList<String>();
			for(int i=0;i<records.size();i++){
				orderList.add(records.get(i).getOuttradeNo());
			}
			List<Map<String, String>> terminalList = orderInfoService.selectTerminalNoCur(orderList);
			for(int i=0;i<records.size();i++){
				String orderNo = records.get(i).getOuttradeNo();
				for(int j=0;j<terminalList.size();j++){
					if(orderNo.equals(terminalList.get(j).get("TRANNO"))){
						records.get(i).setTerminalNo(terminalList.get(j).get("NUM"));
						break;
					}
				}
			}
		} catch (Exception e) {
			request.setAttribute("rspMsg","下载异常！" );
			return "mpos/todayRechargeList";
		}
		try{
			outExcelRecharge(records,response,"T0提现记录",records.size());
		}catch (Exception e) {
			log.info("导出数据有误！");
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 导出历史充值记录
	 * @throws ParseException 
	 */
	@RequestMapping(params = "method=downloadHistory")
	public String downloadHistory(HttpServletRequest request,HttpServletResponse response,String minAmount,String maxAmount,
			String merchantId,Date startTime,Date endTime,String status) throws ParseException {
		request.setAttribute("merchantId", merchantId);
		request.setAttribute("minAmount", minAmount);
		request.setAttribute("maxAmount", maxAmount);
		request.setAttribute("status", status);
		request.setAttribute("startTime", startTime==null?null:sf2.format(startTime));
		request.setAttribute("endTime", endTime==null?null:sf2.format(endTime));
		List<OrderInfo> records = null;
		B2cShopperbi b2cShopperbi = null;
		String userId = null;
		if(!val(merchantId)){
			try {
				b2cShopperbi = shopPerbiService.selectFormalShopperId(merchantId);
			} catch (Exception e1) {
				request.setAttribute("rspMsg","导出异常！" );
				return "mpos/historyRechargeList";
			}
			if(b2cShopperbi==null){
				request.setAttribute("rspMsg",Constants.mapReturnMsg.get("11110005") );
				return "mpos/historyRechargeList";
			}
			//如果查到的商户没有银生宝账号
			userId = b2cShopperbi.getYsbNo();
			if(val(userId)){
				request.setAttribute("rspMsg",Constants.mapReturnMsg.get("11110010") );
				return "mpos/historyRechargeList";
			}
		}
		
		Calendar calendar = Calendar.getInstance();
	    calendar.setTime(new Date());
	    calendar.set(Calendar.HOUR_OF_DAY, 0);
	    calendar.set(Calendar.MINUTE, 0);
	    calendar.set(Calendar.SECOND, 0);
	    calendar.add(Calendar.SECOND, -1);
	    Date start = calendar.getTime();
		if(endTime==null){
			endTime = start;
		}else if(start.before(endTime)){
			endTime =start;
		}
		
		Map<String, Object> qp = new HashMap<String, Object>();
		qp.put("customerid", userId);
		qp.put("startDate", startTime==null?null:sf.format(startTime));
		qp.put("endDate", valDate(endTime));
		qp.put("minAmount", minAmount);
		qp.put("maxAmount", maxAmount);
		qp.put("actionType", 1);
		qp.put("status", "-1".equals(status)?null:status);

		try {
			records = orderInfoService.selectOrderInfoList(qp);
			if(records.size() == 0){
				request.setAttribute("rspCode", "2222");
				request.setAttribute("rspMsg", "没有记录");
				return "mpos/historyRechargeList";
			}
			//根据订单号查询终端号
			List<String> orderList = new ArrayList<String>();
			for(int i=0;i<records.size();i++){
				orderList.add(records.get(i).getOuttradeNo());
			}
			List<Map<String, String>> terminalList = orderInfoService.selectTerminalNoHis(orderList);
			for(int i=0;i<records.size();i++){
				String orderNo = records.get(i).getOuttradeNo();
				for(int j=0;j<terminalList.size();j++){
					if(orderNo.equals(terminalList.get(j).get("TRANNO"))){
						records.get(i).setTerminalNo(terminalList.get(j).get("NUM"));
						break;
					}
				}
			}
		} catch (Exception e) {
			request.setAttribute("rspMsg","导出异常！" );
			return "mpos/historyRechargeList";
		}
		try{
			outExcelRecharge(records,response,"T0提现记录",records.size());
		}catch (Exception e) {
			log.info("导出数据有误！");
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 导出充值提现统计记录
	 * @throws ParseException 
	 */
	@RequestMapping(params = "method=downloadAll")
	public String downloadAll(HttpServletRequest request,HttpServletResponse response,String minAmount,String maxAmount,
			String merchantId,Date startTime,Date endTime,String type) throws ParseException {
		request.setAttribute("merchantId", merchantId);
		request.setAttribute("minAmount", minAmount);
		request.setAttribute("maxAmount", maxAmount);
		request.setAttribute("type", type);
		request.setAttribute("startTime", startTime==null?null:sf2.format(startTime));
		request.setAttribute("endTime", endTime==null?null:sf2.format(endTime));
		List<Map<String,String>> records = null;
		B2cShopperbi b2cShopperbi = null;
		String userId = null;
		if(!val(merchantId)){
			try {
				b2cShopperbi = shopPerbiService.selectFormalShopperId(merchantId);
			} catch (Exception e1) {
				request.setAttribute("rspMsg","导出异常！" );
				return "mpos/allList";
			}
			if(b2cShopperbi==null){
				request.setAttribute("rspMsg",Constants.mapReturnMsg.get("11110005") );
				return "mpos/allList";
			}
			//如果查到的商户没有银生宝账号
			userId = b2cShopperbi.getYsbNo();
			if(val(userId)){
				request.setAttribute("rspMsg",Constants.mapReturnMsg.get("11110010") );
				return "mpos/allList";
			}
		}
		
		Map<String, Object> qp = new HashMap<String, Object>();
		qp.put("customerid", userId);
		qp.put("startDate", startTime==null?null:sf.format(startTime));
		qp.put("endDate", valDate(endTime));
		qp.put("minAmount", minAmount);
		qp.put("maxAmount", maxAmount);
		qp.put("type", type==null?"-1":type);
		try {
			records = orderInfoService.selectAllList(qp);
			if(records.size() == 0){
				request.setAttribute("rspCode", "2222");
				request.setAttribute("rspMsg", "没有记录");
				return "mpos/allList";
			}
		} catch (Exception e) {
			request.setAttribute("rspMsg","导出异常！" );
			return "mpos/allList";
		}
		try{
			outExcelAll(records,response,"T0提现记录");
		}catch (Exception e) {
			log.info("导出数据有误！");
			e.printStackTrace();
		}
		return null;
	}
	
	public String macGNZH(String userId,String str){
		return "userId=" + userId + str + "&mac=" + Md5Encrypt.md5("userId=" + userId + str + "&merchantKey=" + DynamicConfigLoader.getByEnv("gnzh_key")).toLowerCase();
	}
	
	public String macBLZH(String userId,String str){
		return "userId=" + userId + str + "&mac=" + Md5Encrypt.md5("userId=" + userId + str + "&merchantKey=" + DynamicConfigLoader.getByEnv("blzh_key")).toLowerCase();
	}
	
	/**
	 * 拼接参数
	 * @param paramName 参数名
	 * @param param 参数值
	 * @return
	 */
	public String val(String paramName,String param){
		if(param != null && param != ""){
			return "&" + paramName + "=" + param ;
		}
		return "";
	}
	
	/**
	 * 验证非空
	 */
	public boolean val(String param){
		if(param == null || param == ""){
			return true;
		}
		return false;
	}
	
	/**
	 * 时间处理
	 * @throws ParseException 
	 */
	public String valDate(Date date) throws ParseException{
		if(date == null){
			return null;
		}else{
			return sf3.format(date) + "235959";
		}
	}
}
