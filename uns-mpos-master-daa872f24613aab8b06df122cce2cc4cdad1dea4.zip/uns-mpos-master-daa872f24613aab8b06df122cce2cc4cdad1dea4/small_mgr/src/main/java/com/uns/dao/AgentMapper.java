package com.uns.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.uns.model.Agent;
import com.uns.web.form.AgentForm;
import com.uns.web.form.AgentRatioForm;

@Repository
public interface AgentMapper extends BaseMapper<Object>{
	/**
	 * 添加代理商操作
	 * 
	 * @param agent
	 */
	public void addAgent(Agent agent);

	/**
	 * 查询代理商
	 * 
	 * @param agent
	 * @return
	 */
	public List<Agent> searchAgentList(AgentForm agentForm);
	
	/**
	 * 查询代理商树
	 */
	public List<Agent> searchAgentTree();

	public Agent searchAgentById(String id);
	
	public Agent searchAgentByShopperid(String shopperId);
	
	public Agent searchAgentByName(String scompany);
	
	public List<Agent>findAgentByMerchantId();
	
	public Long searchUserByNameAndShopperid(Map params);
	
	public void updateAgent(Agent agent);

	public List findAgentByMerchantIdMap(String merchantId);

	public List updateAgentByMerchantId(Map map);
	//查出所有代理商
	public List<AgentRatioForm> findB2cAgentList();

	public List<AgentRatioForm> findB2cAgentFormList(String agentId);
	
	
	public List findbytel(String tel);
	
	public List<Agent> selectAgentList(AgentForm agentForm);
	
	public List<Agent> findAgentByMerchantId1(String scompany);
	
	public void insertUpdateAgentfeeAlog(Map<String,Object> param);
	
	public List<Map<String,Object>> selectUpdateAgentfeeAlogList(String shopperid);

	public List findfirstAgent(String scompany);

	public List findfirstAgent2();
	/**
	 * 递归查询一级代理商
	 * @param shopperid
	 * @return
	 */
	public String findFisrtAgentByNo(String shopperid);
	
	public String findFisrtParma(String shopperid);
}