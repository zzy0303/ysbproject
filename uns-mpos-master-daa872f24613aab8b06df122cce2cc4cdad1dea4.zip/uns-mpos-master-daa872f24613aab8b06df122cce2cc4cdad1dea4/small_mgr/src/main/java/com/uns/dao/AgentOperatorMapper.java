package com.uns.dao;

import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.Users;
import com.uns.web.form.AgentUserForm;

@Repository
public interface AgentOperatorMapper extends BaseMapper<Object>{

	List selectByUsersList(AgentUserForm mbForm);

	Users selectUsersById(Long userId);

	void update(Users user);
	
	List<HashMap> selectByUsersListB(AgentUserForm mbForm);
	
}
