package com.uns.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.jpos.iso.BaseChannel;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOUtil;
import org.jpos.iso.channel.PostChannel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.common.page.Page;
import com.uns.common.page.PageContext;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.service.ShopPerbiService;
import com.uns.util.HkUtils;
import com.uns.util.ISO8583Packager;
import com.uns.util.ToolsUtils;

@Controller("hkBatchUpdateMerchantController")
@RequestMapping("/hkBatchUpdateMerchant.htm")
public class HkBatchUpdateMerchantController extends BaseController {

	@Autowired
	private ShopPerbiService shopPerbiService;
	
	private ISO8583Packager pack = new ISO8583Packager();
	
	/**去批量下载页面
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=toHkBatchUpdate")
	public String toHkBatchUpdate(HttpServletRequest request) throws Exception {
		Integer count=shopPerbiService.findUploadHkCount();
		request.setAttribute("UPLOAD_SIZE", Constants.UPLOAD_SIZE-1);
		request.setAttribute("count",count);
		return "hk/toHkBatchUpdate";
	}
	
	
	/**下载海科批量修改商户结算信息模板
	 * @param request
	 * @param response
	 */
	@RequestMapping(params = "method=downHkBatchUpdateFile")
	public void downHkBatchUpdateFile(HttpServletRequest request,HttpServletResponse response) {
		String filename="hk.xls";
		String filePath =request.getSession().getServletContext().getRealPath("/")+
				"upload"+File.separator+filename ;
    	String fileName = "";
    	//从文件完整路径中提取文件名，并进行编码转换，防止不能正确显示中文名
    	try {
        	if(filePath.lastIndexOf("/") > 0) {
        		fileName = new String(filePath.substring(filePath.lastIndexOf("/")+1, filePath.length()).getBytes("GB2312"), "ISO8859_1");
        	}else if(filePath.lastIndexOf("\\") > 0) {
        		fileName = new String(filePath.substring(filePath.lastIndexOf("\\")+1, filePath.length()).getBytes("GB2312"), "ISO8859_1");
        	}
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    	//打开指定文件的流信息
    	InputStream fs = null;
    	try {
    		fs = new FileInputStream(new File(filePath));
    		
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    	//设置响应头和保存文件名 
    	response.setCharacterEncoding("ISO-8859-1");
    	response.setContentType("APPLICATION/OCTET-STREAM"); 
    	response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
    	//写出流信息
    	int b = 0;
    	try {
        	PrintWriter out = response.getWriter();
        	while((b=fs.read())!=-1) {
        		out.write(b);
        	}
        	out.flush();
        	fs.close();
        	out.close();
        	log.debug("文件下载完毕");
    	}catch(Exception e) {
        	e.printStackTrace();
        	log.debug("下载文件失败!");
    	}
		
	}
	@RequestMapping("/uploadHkBatchUpdateFile")
	public String uploadHkBatchUpdateFile(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HSSFSheet sheet;
		HSSFRow row;		
		try {
				MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
				// 获得文件
				MultipartFile file = multipartRequest.getFile("hkBatchUpdateFile");
				// 获得文件名：
				String filename = file.getOriginalFilename();
				// 获取输出流
				InputStream in = file.getInputStream();
		
				HSSFWorkbook workbook = new HSSFWorkbook(in);
				// 得到工作表的个数
				int numsheet = workbook.getNumberOfSheets();
				
				Map<String, String> map = new HashMap<String, String>();
				sheet = workbook.getSheetAt(0);
			} catch (Exception e) {
				e.printStackTrace();
				throw new BusinessException(ExceptionDefine.海科修改小商户失败,new String[]{"文件上传失败"});
			}
		
			if (sheet != null) {
				//sheet.getPhysicalNumberOfRows()
				for (int i = 1; i < Constants.UPLOAD_SIZE; i++) {
					try{
						row = sheet.getRow(i);
						if (row != null) {
							updateHkMerchantPort(row,i);
							Thread.sleep(5000);
						}
					} catch (Exception e) {
						e.printStackTrace();
						throw new BusinessException(ExceptionDefine.海科修改小商户失败,new String[]{"第"+i+"条修改失败！"});
					}
				}
			}
			request.setAttribute("url","hkBatchUpdateMerchant.htm?method=toHkBatchUpdate");
			request.setAttribute(Constants.MESSAGE_KEY, "批量上传成功！");
			return "/returnPage";
	}


	/**
	 * 修改商户结算信息批量上传
	 * @throws Exception 
	 */
	private void updateHkMerchantPort(HSSFRow row,int i) throws Exception {
		ISOMsg reqMsg = new ISOMsg();
		BaseChannel channel = new PostChannel(DynamicConfigLoader.getByEnv("hk_erverip"), Constants.HK_SERVERPORT, pack);
		channel.setTimeout(60000);
		channel.setHeader(DynamicConfigLoader.getByEnv("hk_header"));
	
		ISOMsg resMsg = send(buildMsgUpdate(reqMsg,row),channel);
		if(null == resMsg)
			throw new BusinessException(ExceptionDefine.海科修改小商户失败,new String[]{"第"+i+"条发送失败！"});
		
		resMsg.setPackager(pack);
		String code = resMsg.getString(39);
		log.info("海科修改商户查询响应码:" + code);
		setResult(resMsg);
		String rspMsg=new String((byte[])resMsg.getValue(61),"UTF-8");
		if("00".equals(code)){
			String resMac = resMsg.getString(64);
			if(null != resMac){
				HkUtils.macCalc(resMsg, DynamicConfigLoader.getByEnv("hk_merkey"));
				String localMac = resMsg.getString(64);
				if(!resMac.equals(localMac)){
					throw new BusinessException(ExceptionDefine.海科修改小商户失败,new String[]{"第"+i+"条秘钥验证出错失败！"});
				}else{
					if(Constants.UPDATE_RS_PMSG.equals(rspMsg)){
						log.info("第"+i+"条修改成功！");
					}else{
						throw new BusinessException(ExceptionDefine.海科修改小商户失败,new String[]{"第"+i+"条修改失败！"});
					}
				}
			}else if("S2".equals(code)){
				 resMsg = send(buildMsgadd(reqMsg,row),channel);
				 resMsg.setPackager(pack);
				 code = resMsg.getString(39);
				 log.info("海科修改商户查询响应码:" + code);
			}else{
				throw new BusinessException(ExceptionDefine.海科修改小商户失败,new String[]{"第"+i+"条修改失败！！"});
			}
		}else{
			throw new BusinessException(ExceptionDefine.海科修改小商户失败,new String[]{"第"+i+"条修改失败！！！"});
		}
		
	}
	private ISOMsg buildMsgadd(ISOMsg reqMsg, HSSFRow row) throws Exception {
		reqMsg.setDirection(ISOMsg.OUTGOING);//位元表
		reqMsg.setPackager(pack);
		try {
			reqMsg.set(0, "0600");
			reqMsg.set(2,  row.getCell(9).toString()+ "");//提现卡号（与报备小商户号结算账号校验） BCD
			reqMsg.set(38, row.getCell(3).toString().getBytes("UTF-8"));//银行开户名 BCD
			
			reqMsg.set(44, DynamicConfigLoader.getByEnv("hk_channelid"));//附加响应数据  渠道ID
			reqMsg.set(48, row.getCell(0).toString()+"");//小商户号 BCD
			
			
			reqMsg.set(54,row.getCell(14).toString().getBytes("UTF-8"));//开户银行 
			reqMsg.set(57,row.getCell(11).toString().getBytes("UTF-8"));//开户行省份
			reqMsg.set(58,row.getCell(12).toString().getBytes("UTF-8"));//开户行城市
			reqMsg.set(59,row.getCell(12).toString().getBytes("UTF-8"));//开户行县区
			String bankName=row.getCell(10).toString()+row.getCell(12).toString()+row.getCell(13).toString();
			reqMsg.set(61,bankName.getBytes("UTF-8"));//开户行网点
			reqMsg.set(63,"10B");//清算银行账户类型
			
			HkUtils.macCalc(reqMsg, DynamicConfigLoader.getByEnv("hk_merkey"));//MAC
			log.info("添加小商户信息组装    2:"+row.getCell(9).toString()+"	38:"+row.getCell(3).toString()+
					"	44:"+DynamicConfigLoader.getByEnv("hk_channelid")+"	48:"+row.getCell(0).toString()+"	54:"+row.getCell(10).toString()+
					"	57:"+row.getCell(11).toString()
					+"	58:"+row.getCell(12).toString()+"	59:"+row.getCell(12).toString()+
					"	61:"+(bankName)
					+"	63:"+"10B");
			reqMsg.set(63,"10B");//清算银行账户类型
			
			HkUtils.macCalc(reqMsg, DynamicConfigLoader.getByEnv("hk_merkey"));//MAC
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.海科修改小商户失败,new String[]{"组装添加商户结算信息失败！"});
		}
		return reqMsg;
	}


	/**商户修改信息组装
	 * @param reqMsg
	 * @param row
	 * @return
	 * @throws BusinessException
	 */
	private ISOMsg buildMsgUpdate(ISOMsg reqMsg, HSSFRow row) throws BusinessException {
		reqMsg.setDirection(ISOMsg.OUTGOING);//位元表
		reqMsg.setPackager(pack);
		try {
			reqMsg.set(0, "0700");
			reqMsg.set(2,  row.getCell(9).toString()+ "");//提现卡号（与报备小商户号结算账号校验） BCD
			reqMsg.set(38, row.getCell(3).toString().getBytes("UTF-8"));//银行开户名 BCD
			
			reqMsg.set(44, DynamicConfigLoader.getByEnv("hk_channelid"));//附加响应数据  渠道ID
			reqMsg.set(48, row.getCell(0).toString()+"");//小商户号 BCD
			
			
			reqMsg.set(54,row.getCell(14).toString().getBytes("UTF-8"));//开户银行 
			reqMsg.set(57,row.getCell(11).toString().getBytes("UTF-8"));//开户行省份
			reqMsg.set(58,row.getCell(12).toString().getBytes("UTF-8"));//开户行城市
			reqMsg.set(59,row.getCell(12).toString().getBytes("UTF-8"));//开户行县区
			String bankName=row.getCell(10).toString()+row.getCell(12).toString()+row.getCell(13).toString();
			reqMsg.set(61,bankName.getBytes("UTF-8"));//开户行网点
			reqMsg.set(63,"10B");//清算银行账户类型
			
			HkUtils.macCalc(reqMsg, DynamicConfigLoader.getByEnv("hk_merkey"));//MAC
			log.info("修改小商户信息组装    2:"+row.getCell(9).toString()+"	38:"+row.getCell(3).toString()+
					"	44:"+DynamicConfigLoader.getByEnv("hk_channelid")+"	48:"+row.getCell(0).toString()+"	54:"+row.getCell(10).toString()+
					"	57:"+row.getCell(11).toString()
					+"	58:"+row.getCell(12).toString()+"	59:"+row.getCell(12).toString()+
					"	61:"+(bankName)
					+"	63:"+"10B");
			reqMsg.set(63,"10B");//清算银行账户类型
			
			HkUtils.macCalc(reqMsg, DynamicConfigLoader.getByEnv("hk_merkey"));//MAC
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.海科修改小商户失败,new String[]{"组装修改商户结算信息失败！"});
		}
		return reqMsg;
	}
	
	/**发送信息到海科
	 * @param reqMsg
	 * @param channel
	 * @return
	 * @throws Exception
	 */
	public ISOMsg send(ISOMsg reqMsg,BaseChannel channel) throws Exception {
		try {
			channel.connect();
			log.info("查询请求报文：" + ISOUtil.hexString(reqMsg.pack()));
			channel.send(reqMsg);
			ISOMsg retMsg = channel.receive();
			log.info("海科代付查询响应报文：" + ISOUtil.hexString(retMsg.pack()));
			channel.disconnect();
			return retMsg;
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.海科增加小商户失败,new String[]{"海科批量修改小商户失败，数据转换异常！"});
		}
	}
	
	
	/**返回结果解析
	 * @param resMsg
	 * @return
	 * @throws Exception
	 */
	private Map<String, Object>  setResult(ISOMsg resMsg) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("2:", resMsg.getString(2));
		map.put("34:", resMsg.getString(34));
		map.put("39:", resMsg.getString(39));
		map.put("44:", resMsg.getString(44));
		map.put("48:", resMsg.getString(48));
		map.put("54:", new String((byte[])resMsg.getValue(54),"UTF-8"));
		map.put("57:", new String((byte[])resMsg.getValue(57),"UTF-8"));
		map.put("58:", new String((byte[])resMsg.getValue(58),"UTF-8"));
		map.put("59:", new String((byte[])resMsg.getValue(59),"UTF-8"));
		map.put("61:", new String((byte[])resMsg.getValue(61),"UTF-8"));
		map.put("63:", resMsg.getString(63));
		log.info("海科新增小商户查询响应报文map:" + map);
		return map;
	}
	
	
	/**
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=toAllUpload")
	public String toAllUpload(HttpServletRequest request) throws Exception {
		Integer count=shopPerbiService.findUploadHkCount();
		String msg="";
		int m=ToolsUtils.Counts(count, Constants.UPLOAD_HK_SIZE);
		int x=0;
		int y=0;
		int z=0;
		for(int i=0;i<m;i++){
			
			int currentPage = Integer.valueOf(i+1);
			Page page  = new Page();
			page.setPageSize(currentPage*Constants.UPLOAD_HK_SIZE);
			PageContext context = PageContext.getContext();
			BeanUtils.copyProperties(context, page);
			context.setPagination(true);
			context.setCurrentPage(currentPage);
			
			List hkList=shopPerbiService.findhkList();
			if(hkList.size()>0&&hkList!=null){
				for(int j=0;j<hkList.size();j++){
					log.info("第"+(i+1)+"批:"+"第"+(j+1)+"条");
					Map map=(Map)hkList.get(j);
					String reSmg=updateAllHk(map);
					if("00".equals(reSmg)){
						x++;
					}else if("S2".equals(reSmg)){
						addAllHk(map);
						y++;
					}else{
						z++;
					}
					Thread.sleep(3000);
					if(j>Constants.UPLOAD_HK_SIZE){
						break;
					}
				}
			}
		}
		msg="修改成功"+x+"条;添加成功"+y+"条;失败"+z+"条";
		log.info("#####################"+msg+"######################");
		request.setAttribute("url","hkBatchUpdateMerchant.htm?method=toHkBatchUpdate");
		request.setAttribute(Constants.MESSAGE_KEY, msg);
		return "/returnPage";
	}


	private String addAllHk(Map map) {
		ISOMsg reqMsg = new ISOMsg();
		BaseChannel channel = new PostChannel(DynamicConfigLoader.getByEnv("hk_erverip"), Constants.HK_SERVERPORT, pack);
		try {
			channel.setTimeout(60000);
			
			channel.setHeader(DynamicConfigLoader.getByEnv("hk_header"));
		
			ISOMsg resMsg = send(buildMsgAddAll(reqMsg,map),channel);
			if(null == resMsg)
	//			throw new BusinessException(ExceptionDefine.海科修改小商户失败,new String[]{"第"+i+"条发送失败！"});
			
			resMsg.setPackager(pack);
			String code = resMsg.getString(39);
			log.info("海科修改商户查询响应码:" + code);
			setResult(resMsg);
			return code;
		} catch (Exception e) {
			e.printStackTrace();
			return "error";
		}
		
		
	}


	private ISOMsg buildMsgAddAll(ISOMsg reqMsg, Map map) {
		reqMsg.setDirection(ISOMsg.OUTGOING);//位元表
		reqMsg.setPackager(pack);
		try {
			reqMsg.set(0, "0600");
			reqMsg.set(2,  map.get("ACCOUNT_BANK_NO").toString()+ "");//提现卡号（与报备小商户号结算账号校验） BCD
			reqMsg.set(38, map.get("NAME").toString().getBytes("UTF-8"));//银行开户名 BCD
			
			reqMsg.set(44, DynamicConfigLoader.getByEnv("hk_channelid"));//附加响应数据  渠道ID
			reqMsg.set(48, map.get("SHOPPERID").toString()+"");//小商户号 BCD
			
			
			reqMsg.set(54,map.get("DICTCLS").toString().getBytes("UTF-8"));//开户银行 
			reqMsg.set(57,map.get("ACCOUNT_BANK_PROV").toString().getBytes("UTF-8"));//开户行省份
			reqMsg.set(58,map.get("ACCOUNT_BANK_CITY").toString().getBytes("UTF-8"));//开户行城市
			reqMsg.set(59,map.get("ACCOUNT_BANK_CITY").toString().getBytes("UTF-8"));//开户行县区
			String bankNames=map.get("DICT").toString();
			String bankName=bankNames+map.get("ACCOUNT_BANK_CITY").toString()+map.get("ACCOUNT_BANK_NAME").toString();
			reqMsg.set(61,bankName.getBytes("UTF-8"));//开户行网点
			reqMsg.set(63,"10B");//清算银行账户类型
			
			HkUtils.macCalc(reqMsg, DynamicConfigLoader.getByEnv("hk_merkey"));//MAC
			log.info("增加小商户信息组装    2:"+map.get("ACCOUNT_BANK_NO").toString()+"	38:"+map.get("NAME").toString()+
					"	44:"+DynamicConfigLoader.getByEnv("hk_channelid")+"	48:"+map.get("SHOPPERID").toString()+
					"	54:"+map.get("DICTCLS").toString()+
					"	57:"+map.get("ACCOUNT_BANK_PROV").toString()+
					"	58:"+map.get("ACCOUNT_BANK_CITY").toString()+
					"	59:"+map.get("ACCOUNT_BANK_CITY").toString()+
					"	61:"+(bankName)
					+"	63:"+"10B");
			reqMsg.set(63,"10B");//清算银行账户类型
			
			HkUtils.macCalc(reqMsg, DynamicConfigLoader.getByEnv("hk_merkey"));//MAC
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		return reqMsg;
	}


	private String updateAllHk(Map map) {
		try {
			ISOMsg reqMsg = new ISOMsg();
			BaseChannel channel = new PostChannel(DynamicConfigLoader.getByEnv("hk_erverip"), Constants.HK_SERVERPORT, pack);
			channel.setTimeout(60000);
			
			channel.setHeader(DynamicConfigLoader.getByEnv("hk_header"));
		
			ISOMsg resMsg = send(buildMsgUpdateAll(reqMsg,map),channel);
			if(null == resMsg)
	//			throw new BusinessException(ExceptionDefine.海科修改小商户失败,new String[]{"第"+i+"条发送失败！"});
			
			resMsg.setPackager(pack);
			String code = resMsg.getString(39);
			log.info("海科修改商户查询响应码:" + code);
			setResult(resMsg);
			return code;
		} catch (Exception e) {
			e.printStackTrace();
			return "error";
		}
		
	}


	private ISOMsg buildMsgUpdateAll(ISOMsg reqMsg, Map map) {
		reqMsg.setDirection(ISOMsg.OUTGOING);//位元表
		reqMsg.setPackager(pack);
		try {
			reqMsg.set(0, "0700");
			reqMsg.set(2,  map.get("ACCOUNT_BANK_NO").toString()+ "");//提现卡号（与报备小商户号结算账号校验） BCD
			reqMsg.set(38, map.get("NAME").toString().getBytes("UTF-8"));//银行开户名 BCD
			
			reqMsg.set(44, DynamicConfigLoader.getByEnv("hk_channelid"));//附加响应数据  渠道ID
			reqMsg.set(48, map.get("SHOPPERID").toString()+"");//小商户号 BCD
			
			
			reqMsg.set(54,map.get("DICTCLS").toString().getBytes("UTF-8"));//开户银行 
			reqMsg.set(57,map.get("ACCOUNT_BANK_PROV").toString().getBytes("UTF-8"));//开户行省份
			reqMsg.set(58,map.get("ACCOUNT_BANK_CITY").toString().getBytes("UTF-8"));//开户行城市
			reqMsg.set(59,map.get("ACCOUNT_BANK_CITY").toString().getBytes("UTF-8"));//开户行县区
			String bankNames=map.get("DICT").toString();
			String bankName=bankNames+map.get("ACCOUNT_BANK_CITY").toString()+map.get("ACCOUNT_BANK_NAME").toString();
			reqMsg.set(61,bankName.getBytes("UTF-8"));//开户行网点
			reqMsg.set(63,"10B");//清算银行账户类型
			
			HkUtils.macCalc(reqMsg, DynamicConfigLoader.getByEnv("hk_merkey"));//MAC
			log.info("修改小商户信息组装    2:"+map.get("ACCOUNT_BANK_NO").toString()+"	38:"+map.get("NAME").toString()+
					"	44:"+DynamicConfigLoader.getByEnv("hk_channelid")+"	48:"+map.get("SHOPPERID").toString()+
					"	54:"+map.get("DICTCLS").toString()+
					"	57:"+map.get("ACCOUNT_BANK_PROV").toString()+
					"	58:"+map.get("ACCOUNT_BANK_CITY").toString()+
					"	59:"+map.get("ACCOUNT_BANK_CITY").toString()+
					"	61:"+(bankName)
					+"	63:"+"10B");
			reqMsg.set(63,"10B");//清算银行账户类型
			
			HkUtils.macCalc(reqMsg, DynamicConfigLoader.getByEnv("hk_merkey"));//MAC
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		return reqMsg;
	
	}
	
}
