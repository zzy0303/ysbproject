package com.uns.service;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.common.Constants;
import com.uns.common.exception.BusinessException;
import com.uns.dao.B2cDictMapper;
import com.uns.model.B2cDict;
import com.uns.web.form.SudokuForm;

@Service
public class SudokuService {

	
	@Autowired
	private B2cDictMapper b2cDictMapper;
	
	
	public String findDictType(String dictType) throws BusinessException {
		List<B2cDict> list=b2cDictMapper.searchDictCls(dictType);
		String b2cDictType="";
		for(int i=0;i<list.size();i++){
			b2cDictType+=list.get(i).getB2cDictId()+",";
		}
		return b2cDictType;
	}
	
	
	public void updateAppSudoku(SudokuForm sudokuForm) {
		updateAppTopSudoku(sudokuForm);//首页
		updateAppMposTranTypeSudoku(sudokuForm);//mpos支付方式
		updateAppSmTranTypeSudoku(sudokuForm);//扫码支付方式
		updateAppSmPayFlagSudoku(sudokuForm);//扫码收款方式
		if(Constants.TYPE_0.equals(sudokuForm.getMerchant_type())){
			updateAppKjPayFlagSudoku(sudokuForm);//快捷收款方式
		}

	}

	/**
	 * 快捷
	 * @param sudokuForm
	 */
	private void updateAppKjPayFlagSudoku(SudokuForm sudokuForm) {
		b2cDictMapper.updateB2cDict(Constants.APP_KJ_PAY_FLAG);
		String[] sudokus=sudokuForm.getKj_pay_flag();
		if(sudokus!=null){
			for(int i=0;i<sudokus.length;i++){
				String sudoku=sudokus[i];
				if(StringUtils.isNotEmpty(sudoku)){
					b2cDictMapper.updateB2cDictById(sudoku);
				}
			}
		}
	}


	/**
	 * 扫码收款方式
	 * @param sudokuForm
	 */
	private void updateAppSmPayFlagSudoku(SudokuForm sudokuForm) {
		if(Constants.TYPE_2.equals(sudokuForm.getMerchant_type())){
			b2cDictMapper.updateB2cDict(Constants.APP_MER_SM_TRAN_FLAG);
		} else {
			b2cDictMapper.updateB2cDict(Constants.APP_SM_PAY_FLAG);
		}
		String[] sudokus=sudokuForm.getSm_pay_flag();
		if(sudokus!=null){
			for(int i=0;i<sudokus.length;i++){
				String sudoku=sudokus[i];
				if(StringUtils.isNotEmpty(sudoku)){
					b2cDictMapper.updateB2cDictById(sudoku);
				}
			}
		}
	}


	/**
	 * 扫码支付方式
	 * @param sudokuForm
	 */
	private void updateAppSmTranTypeSudoku(SudokuForm sudokuForm) {
		String[] sudokus= null;
		if(Constants.TYPE_2.equals(sudokuForm.getMerchant_type())){
			b2cDictMapper.updateB2cDict(Constants.APP_MER_SM_PAY_FLAG); //商户扫码支付-微信、支付宝
			sudokus=sudokuForm.getMer_sm_tran_type();
		} else {
			b2cDictMapper.updateB2cDict(Constants.APP_SM_TRAN_TYPE);
			sudokus=sudokuForm.getSm_tran_type();
		}
		if(sudokus!=null){
			for(int i=0;i<sudokus.length;i++){
				String sudoku=sudokus[i];
				if(StringUtils.isNotEmpty(sudoku)){
					b2cDictMapper.updateB2cDictById(sudoku);
				}
			}
		}
		
	}


	/**
	 * mpos支付方式
	 * @param sudokuForm
	 */
	private void updateAppMposTranTypeSudoku(SudokuForm sudokuForm) {
		if(Constants.TYPE_2.equals(sudokuForm.getMerchant_type())){
			b2cDictMapper.updateB2cDict(Constants.APP_MER_SM_TRAN_TYPE);
		} else {
			b2cDictMapper.updateB2cDict(Constants.APP_MPOS_TRAN_TYPE);
		}
		String[] sudokus=sudokuForm.getMpos_tran_type();
		if(sudokus!=null){
			for(int i=0;i<sudokus.length;i++){
				String sudoku=sudokus[i];
				if(StringUtils.isNotEmpty(sudoku)){
					b2cDictMapper.updateB2cDictById(sudoku);
				}
			}
		}
		
	}


	/**
	 * 修改 app 首页
	 * 
	 */
	private void updateAppTopSudoku(SudokuForm sudokuForm) {
		//商户APP
		if(sudokuForm.getMerchant_type().equals(Constants.TYPE_2)){
			b2cDictMapper.updateB2cDict(Constants.APP_MER_SUDOKU);
		} else {
			b2cDictMapper.updateB2cDict(Constants.APP_TOP_SUDOKU);
		}
		String[] topSudokus=sudokuForm.getTop_sudoku();
		if(topSudokus!=null){
		for(int i=0;i<topSudokus.length;i++){
				String topSudoku=topSudokus[i];
				if(StringUtils.isNotEmpty(topSudoku)){
					b2cDictMapper.updateB2cDictById(topSudoku);
				}
			}
		}
	}


	public void updateMerSudoku(SudokuForm sudokuForm) {
		updateMerSudokus(sudokuForm);//商户平台
		updateMerSmTranTypeSudoku(sudokuForm);//扫码支付方式
		updateMerSmPayFlagSudoku(sudokuForm);//扫码收款方式
		
	}


	private void updateMerSmPayFlagSudoku(SudokuForm sudokuForm) {
		b2cDictMapper.updateB2cDict(Constants.MER_SM_PAY_FLAG);
		String[] sudokus=sudokuForm.getMer_sm_pay_flag();
		if(sudokus!=null){
			for(int i=0;i<sudokus.length;i++){
				String sudoku=sudokus[i];
				if(StringUtils.isNotEmpty(sudoku)){
					b2cDictMapper.updateB2cDictById(sudoku);
				}
			}
		}
	}


	private void updateMerSmTranTypeSudoku(SudokuForm sudokuForm) {
		b2cDictMapper.updateB2cDict(Constants.MER_SM_TRAN_TYPE);
		String[] sudokus=sudokuForm.getMer_sm_tran_type();
		if(sudokus!=null){
			for(int i=0;i<sudokus.length;i++){
				String sudoku=sudokus[i];
				if(StringUtils.isNotEmpty(sudoku)){
					b2cDictMapper.updateB2cDictById(sudoku);
				}
			}
		}
	}


	private void updateMerSudokus(SudokuForm sudokuForm) {
		b2cDictMapper.updateB2cDict(Constants.MER_SUDOKU);
		String[] sudokus=sudokuForm.getMer_sudoku();
		if(sudokus!=null){
			for(int i=0;i<sudokus.length;i++){
				String sudoku=sudokus[i];
				if(StringUtils.isNotEmpty(sudoku)){
					b2cDictMapper.updateB2cDictById(sudoku);
				}
			}
		}
		
	}


}
