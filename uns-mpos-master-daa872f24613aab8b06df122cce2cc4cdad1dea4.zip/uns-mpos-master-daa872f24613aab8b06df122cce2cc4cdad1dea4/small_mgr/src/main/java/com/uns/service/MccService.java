package com.uns.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.dao.MccMapper;
import com.uns.model.Mcc;

@Service
public class MccService {
	@Autowired
	private MccMapper mccMapper;

	/*
	 * 遍历mcc
	 */
	public List<Mcc> searchMcc() {
		return mccMapper.searchMcc();
	}
	
}
