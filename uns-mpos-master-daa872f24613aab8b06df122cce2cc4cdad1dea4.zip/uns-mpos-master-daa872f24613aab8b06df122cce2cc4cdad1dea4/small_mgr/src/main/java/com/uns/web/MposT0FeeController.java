package com.uns.web;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.common.Constants;
import com.uns.common.annotation.FormToken;
import com.uns.common.exception.BusinessException;
import com.uns.common.exception.ExceptionDefine;
import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.model.MposT0Fee;
import com.uns.model.Operator;
import com.uns.service.MposT0FeeService;
import com.uns.util.DateUtils;
import com.uns.util.HttpClientUtils;
import com.uns.util.MD5Util;
import com.uns.util.ToolsUtils;
import com.uns.web.form.MposT0FeeForm;
import com.uns.web.form.YsbFreeFundsForm;

/**
 * 设置t0手续费
 *
 */
@Controller
@RequestMapping(value = "/mposT0Fee.htm")
public class MposT0FeeController extends BaseController {

	
	@Autowired
	private MposT0FeeService mposT0FeeService;
	
	
	
	/**查询t0手续费设置
	 * @param request
	 * @param response
	 * @param mbform
	 * @return
	 * @throws BusinessException
	 * @throws Exception
	 */
	@RequestMapping(params = "method=findMposT0FeeList")
	public String findMposT0FeeList(HttpServletRequest request, HttpServletResponse response,MposT0FeeForm mbform)
		throws BusinessException, Exception{
		try {
			List mposT0FeeList=mposT0FeeService.findMposT0FeeList(mbform);
			request.setAttribute("mposT0FeeList", mposT0FeeList);
			
			Map mposT0FeeMap=queryT0feeMap();
			if(Constants.RESPONSE_CODE.equals(mposT0FeeMap.get("rspCode"))){
				request.setAttribute("t0fee", mposT0FeeMap.get("t0fee"));
				request.setAttribute("t0FixedFee", mposT0FeeMap.get("t0FixedFee"));
			}else{
				request.setAttribute("t0fee", "查询失败");
				request.setAttribute("t0FixedFee", "查询失败");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.查询T0记录失败);
		}
		return "t0fee/t0feeList";
		
	}

	@RequestMapping(params = "method=findMposT0Details")
	@FormToken(save=true)
	public String findMposT0Details(HttpServletRequest request, HttpServletResponse response,YsbFreeFundsForm mbform)throws Exception {
		String t0feeId=request.getParameter("t0feeId");
		if(StringUtils.isNotEmpty(t0feeId)){
			MposT0Fee mposT0Fee=mposT0FeeService.findMposT0ById(t0feeId);
		    request.setAttribute("mposT0Fee", mposT0Fee);
		}
		return "t0fee/t0feeDetails";
	}


	/**
	 * 查询t0手续费设置
	 * @throws Exception 
	 */
	private Map queryT0feeMap() throws Exception {
		Map parmsMap=new HashMap();
		Date dates = new Date();
		String mradom = RandomStringUtils.randomNumeric(6);
		
		String orderId = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss") + mradom;
		String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");	
		String mac=queryT0feeMapMac(orderId,orderTime);
		
		parmsMap.put("orderId", orderId);
		parmsMap.put("orderTime", orderTime);
		parmsMap.put("mac", mac);
		
	    logger.info("T0手续费查询："+DynamicConfigLoader.getByEnv("query_t0fee_url")+parmsMap.toString());
        Map resultMap =HttpClientUtils.postRequestMap(DynamicConfigLoader.getByEnv("query_t0fee_url"),parmsMap,Map.class);
        logger.info("T0手续费查询返回码:"+resultMap);
	    return resultMap;
	}

	
	
	


	private String queryT0feeMapMac(String orderId, String orderTime) {
		StringBuffer sb=new StringBuffer();
		sb.append("orderId="+orderId);
		sb.append("&orderTime="+orderTime);
		sb.append("&merchantKey="+DynamicConfigLoader.getByEnv("merchant_key"));
		return MD5Util.getMD5(sb.toString());
	}
	
	
	/**
	 * @param request
	 * @param response
	 * @param mbform
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=setT0fee")
	@FormToken(save=true)
	public String setT0fee(HttpServletRequest request, HttpServletResponse response,YsbFreeFundsForm mbform)throws Exception {
		Map mposT0FeeMap=queryT0feeMap();
		if(Constants.RESPONSE_CODE.equals(mposT0FeeMap.get("rspCode"))){
			request.setAttribute("t0fee", mposT0FeeMap.get("t0fee"));
			request.setAttribute("t0FixedFee", mposT0FeeMap.get("t0FixedFee"));
		}else{
			request.setAttribute("t0fee", "查询失败");
			request.setAttribute("t0FixedFee", "查询失败");
		}
		return "t0fee/t0fee";
	}
	
	
	/**保存t0手续费设置
	 * @param request
	 * @param response
	 * @param mposT0Fee
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=saveT0fee")
	@FormToken(remove=true)
	public String saveT0fee(HttpServletRequest request, HttpServletResponse response,MposT0Fee mposT0Fee)throws Exception {
		try {
			Map parmsMap=new HashMap();
			Date dates = new Date();
			String mradom = RandomStringUtils.randomNumeric(6);
			
			String orderId = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss") + mradom;
			String orderTime = DateUtils.getTypeDate(dates, "yyyyMMddhhmmss");	
			
			parmsMap.put("orderId", orderId);
			parmsMap.put("orderTime", orderTime);
			
			parmsMap.put("t0fee", ToolsUtils.div(mposT0Fee.getT0fee(), 100.00, 4));
			parmsMap.put("t0FixedFee", mposT0Fee.getT0fixedfee());
			
			
			Operator operator=(Operator)request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			if(operator!=null){
				String createUser=operator.getUserName();
				mposT0Fee.setCareateuser(createUser);
			}
			mposT0Fee.setOrderid(orderId);
			mposT0Fee.setOrdertime(orderTime);
			
			
			Map returnMap=setT0fee(parmsMap);
			mposT0Fee.setRspcode(returnMap.get("rspCode")==null?"0500":returnMap.get("rspCode").toString());
			mposT0Fee.setRspmsg(returnMap.get("rspMsg")==null?"系统错误":returnMap.get("rspMsg").toString());	
			mposT0FeeService.insert(mposT0Fee);
			if(Constants.RESPONSE_CODE.equals(returnMap.get("rspCode"))){
				request.setAttribute(Constants.MESSAGE_KEY,"T0手续费设置成功!");
			}else{
				request.setAttribute(Constants.MESSAGE_KEY,"T0手续费设置失败!");
			}
			request.setAttribute("url","mposT0Fee.htm?method=findMposT0FeeList");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionDefine.T0手续费设置错误);
		}
	
		return "/returnPage";
	}



	/**设置T0手续费
	 * @param parmsMap
	 * @return
	 * @throws Exception 
	 */
	private Map setT0fee(Map parmsMap) throws Exception {
		logger.info("T0手续费设置："+DynamicConfigLoader.getByEnv("set_t0fee_url")+parmsMap.toString());
	    Map resultMap =HttpClientUtils.postRequestMap(DynamicConfigLoader.getByEnv("set_t0fee_url"),parmsMap,Map.class);
	    logger.info("T0手续费设置返回码:"+resultMap);
		return resultMap;
	}
	
	
	
	
}
