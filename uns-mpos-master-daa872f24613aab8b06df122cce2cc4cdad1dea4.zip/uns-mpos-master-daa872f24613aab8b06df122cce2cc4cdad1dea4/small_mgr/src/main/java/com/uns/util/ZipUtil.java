package com.uns.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import com.uns.common.exception.BusinessException;

public class ZipUtil {
	  /** 
	    * 压缩文件 
	    *  
	    * @param srcfile File[] 需要压缩的文件列表 
	    * @param zipfile File 压缩后的文件 
	 * @throws BusinessException 
	    */  
	public static void zipFiles(String oneFileNames,List<File> srcfile,HttpServletResponse response) throws BusinessException {  
	    byte[] buf = new byte[1024];  
	    try {  
	    	ServletOutputStream ou = response.getOutputStream();
			response.setHeader("content-disposition", "attachment;filename="+new String(oneFileNames.getBytes("UTF-8"),"iso8859-1")+".zip");
			response.setCharacterEncoding("UTF-8");
	        ZipOutputStream out = new ZipOutputStream(ou);  
	        for (int i = 0; i < srcfile.size(); i++) {  
	            File file = srcfile.get(i);  
	            FileInputStream in = new FileInputStream(file); 
	            out.putNextEntry(new ZipEntry(file.getName())); 
	            int len;  
	            while ((len = in.read(buf)) > 0) {  
	                out.write(buf, 0, len);  
	            }  
	            out.closeEntry();  
	            in.close();  
	        } 
	        out.close();  
	    } catch (IOException e){
	    	e.printStackTrace();
	    	//throw new  BusinessException(ExceptionDefine.将生成文档打成压缩包);
	    }  
	}  

	public static void main(String[] args) {

		List<File> srcfile=new ArrayList<File>();  
		
		srcfile.add(new File("d:\\a.png"));
	    srcfile.add(new File("d:\\aa.png"));
		srcfile.add(new File("d:\\aaa.png"));
		srcfile.add(new File("d:\\b.png"));
		srcfile.add(new File("d:\\c.png"));
		srcfile.add(new File("d:\\d.png"));
	}
			

}