package com.uns.dao;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.uns.model.MposT0Fee;
import com.uns.web.form.MposT0FeeForm;
@Repository
public interface MposT0FeeMapper {


    int deleteByPrimaryKey(BigDecimal id);

    int insert(MposT0Fee record);

    int insertSelective(MposT0Fee record);

    MposT0Fee selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(MposT0Fee record);

    int updateByPrimaryKey(MposT0Fee record);

	List findMposT0FeeList(MposT0FeeForm mbform);
}