package com.uns.web;

import com.uns.common.Constants;
import com.uns.common.Global;
import com.uns.common.annotation.FormToken;
import com.uns.model.MposSystemInformation;
import com.uns.model.Operator;
import com.uns.service.InformationService;
import com.uns.web.form.InformationForm;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * 消息模块
 * 
 */
@Controller("InformationController")
@RequestMapping("/information.htm")
public class InformationController extends BaseController {

	@Autowired
	public  InformationService informationService;
	
	/**消息管理查询模块
	 * @param request
	 * @param mbform
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=findInformationList")
	public String findInformationList(HttpServletRequest request,
			InformationForm mbform) throws Exception {
		List informationList=informationService.findInformationList(mbform);
		request.setAttribute("informationList", informationList);
		return "information/informationList";
	}
	
	/**服务商消息管理查询模块
	 * @param request
	 * @param mbform
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=findInformationAgentList")
	public String findInformationAgentList(HttpServletRequest request,InformationForm mbForm) throws Exception{
		mbForm.setIfagent(Constants.IS_AGENT);
		List informationAgentList=informationService.findInformationAgentList(mbForm);
		request.setAttribute("informationAgentList", informationAgentList);
		return "information/findInformationAgentList";
	}
	
	/**固码消息
	 * @param request
	 * @param mbform  
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=findFixedCodeMessageList")
	public String findFixedCodeMessageList(HttpServletRequest request,InformationForm mbForm) throws Exception{
		mbForm.setIfagent(Constants.IS_QRCODE);
		List informationAgentList=informationService.findInformationAgentList(mbForm);
		request.setAttribute("informationQrcodeList", informationAgentList);
		return "information/findInformationQrcodeList";
	}
	
	
	/**添加系统消息
	 * @param request
	 * @param mbform
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=addInformation")
	@FormToken(save=true)
	public String addInformation(HttpServletRequest request,
			InformationForm mbform) throws Exception {

		return "information/addinformation";
	}
	/**服务商添加消息
	 * @param request
	 * @param mbform
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=addAgentInformation")
	@FormToken(save=true)
	public String addAgentInformation(HttpServletRequest request,
			InformationForm mbform) throws Exception {

		return "information/addAgentInformation";
	}
	
	/**固码添加消息
	 * @param request
	 * @param mbform
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=addQrcodeInformation")
	@FormToken(save=true)
	public String addQrcodeInformation(HttpServletRequest request,
			InformationForm mbform) throws Exception {

		return "information/addQrcodeInformation";
	}
	
	/**固码添加信息
	 * @param request
	 * @param mbform
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=insertQrcodeInformation")
	@FormToken(remove=true)
	public String insertQrcodeInformation(HttpServletRequest request,
			InformationForm mbform,MposSystemInformation systemInformation) throws Exception {
		Operator operator=(Operator)request.getSession().getAttribute(Constants.SESSION_KEY_USER);
		systemInformation.setCreateuser(operator.getUserName());
		
		//先关闭之前的固码消息，然后在重新生产一条新的消息
		informationService.updateQrcodeInformation(Constants.IS_QRCODE);
		
		Calendar calendar = Calendar.getInstance();
        Date date = new Date();
        calendar.setTime(date);
        systemInformation.setValidstartdate(calendar.getTime());
        calendar.add(Calendar.YEAR, +Constants.ONE);//当前时间往后增加一年
        systemInformation.setValidenddate(calendar.getTime());
		systemInformation.setCreatedate(new Date());
		systemInformation.setUpdatedate(new Date());
		systemInformation.setStatus(Constants.CON_YES);
		systemInformation.setIfagent(Constants.IS_QRCODE);
		informationService.insertQrcodeInformation(systemInformation);
		request.setAttribute(Constants.MESSAGE_KEY, "消息添加成功！");
		request.setAttribute("url", "information.htm?method=findFixedCodeMessageList");
		
		return "/returnPage";
	}
	
	
	/**保存添加信息
	 * @param request
	 * @param mbform
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=insertInformation")
	@FormToken(remove=true)
	public String insertInformation(HttpServletRequest request,
			InformationForm mbform,MposSystemInformation systemInformation) throws Exception {
		Operator operator=(Operator)request.getSession().getAttribute(Constants.SESSION_KEY_USER);
		systemInformation.setCreateuser(operator.getUserName());
		systemInformation.setCreatedate(new Date());
		systemInformation.setUpdatedate(new Date());
		systemInformation.setStatus(Constants.CON_YES);
		informationService.insertSystemInformation(systemInformation);


		log.info("#########################批量插入完成##########################");
		request.setAttribute(Constants.MESSAGE_KEY, "消息添加成功！");
		request.setAttribute("url", "information.htm?method=findInformationList");
		
		return "/returnPage";
	}
	
	/**服务商保存添加信息
	 * @param request
	 * @param mbform
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=insertAgentInformation")
	@FormToken(remove=true)
	public String insertAgentInformation(HttpServletRequest request,
			InformationForm mbform,MposSystemInformation systemInformation) throws Exception {
		Operator operator=(Operator)request.getSession().getAttribute(Constants.SESSION_KEY_USER);
		systemInformation.setCreateuser(operator.getUserName());
		systemInformation.setCreatedate(new Date());
		systemInformation.setUpdatedate(new Date());
		systemInformation.setStatus(Constants.CON_YES);
		systemInformation.setIfagent(Constants.IS_AGENT);
		informationService.insertAgentInformation(systemInformation);

		log.info("#########################批量插入完成##########################");
		request.setAttribute(Constants.MESSAGE_KEY, "消息添加成功！");
		request.setAttribute("url", "information.htm?method=findInformationAgentList");
		
		return "/returnPage";
	}

	
	/**编辑消息
	 * @param request
	 * @param mbform
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=toModifyInformation")
	@FormToken(save=true)
	public String toModifyInformation(HttpServletRequest request,
			InformationForm mbform) throws Exception {
		String informationId=request.getParameter("informationId");
		if(StringUtils.isNotEmpty(informationId)){
			MposSystemInformation mposSystemInformation=informationService.findInformationById(informationId);
			request.setAttribute("mposSystemInformation", mposSystemInformation);
		}
		return "information/modifyinformation";
	}
	
	
	/**服务商编辑消息
	 * @param request
	 * @param mbform
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=toModifyAgentInformation")
	@FormToken(save=true)
	public String toModifyAgentInformation(HttpServletRequest request,
			InformationForm mbform) throws Exception {
		String informationId=request.getParameter("informationId");
		if(StringUtils.isNotEmpty(informationId)){
			MposSystemInformation mposSystemInformation=informationService.findInformationById(informationId);
			request.setAttribute("mposSystemInformation", mposSystemInformation);
		}
		return "information/modifyAgentInformation";
	}
	
	
	
	/**保存编辑消息
	 * @param request
	 * @param mbform
	 * @param systemInformation
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=updateInformation")
	@FormToken(remove=true)
	public String updateInformation(HttpServletRequest request,
			InformationForm mbform,MposSystemInformation systemInformation) throws Exception {
		String informationId=request.getParameter("informationId");
		Operator operator=(Operator)request.getSession().getAttribute(Constants.SESSION_KEY_USER);
		systemInformation.setId(Long.valueOf(informationId));
		systemInformation.setUpdatedate(new Date());
		systemInformation.setUpdateuser(operator.getUserName());
		systemInformation.setStatus(Constants.CON_YES);
		informationService.updateSystemInformation(systemInformation);
		request.setAttribute(Constants.MESSAGE_KEY, "消息修改成功！");
		request.setAttribute("url", "information.htm?method=findInformationList");
		
		return "/returnPage";
	}
	/**保存服务商编辑消息
	 * @param request
	 * @param mbform
	 * @param systemInformation
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=updateAgentInformation")
	@FormToken(remove=true)
	public String updateAgentInformation(HttpServletRequest request,
			InformationForm mbform,MposSystemInformation systemInformation) throws Exception {
		String informationId=request.getParameter("informationId");
		Operator operator=(Operator)request.getSession().getAttribute(Constants.SESSION_KEY_USER);
		systemInformation.setId(Long.valueOf(informationId));
		systemInformation.setUpdatedate(new Date());
		systemInformation.setUpdateuser(operator.getUserName());
		systemInformation.setStatus(Constants.CON_YES);
		informationService.updateSystemInformation(systemInformation);
		request.setAttribute(Constants.MESSAGE_KEY, "消息修改成功！");
		request.setAttribute("url", "information.htm?method=findInformationAgentList");
		
		return "/returnPage";
	}
	/**关闭消息
	 * @param request
	 * @param mbform
	 * @param systemInformation
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=toCloseInformation")
	public String toCloseInformation(HttpServletRequest request,
			InformationForm mbform,MposSystemInformation systemInformation) throws Exception {
		String informationId=request.getParameter("informationId");
		Operator operator=(Operator)request.getSession().getAttribute(Constants.SESSION_KEY_USER);
		systemInformation.setId(Long.valueOf(informationId));
		systemInformation.setUpdatedate(new Date());
		systemInformation.setUpdateuser(operator.getUserName());
		systemInformation.setStatus(Constants.TYPE_2);
		informationService.updateCloseSystemInformation(systemInformation);
		request.setAttribute(Constants.MESSAGE_KEY, "消息关闭成功！");
		request.setAttribute("url", "information.htm?method=findInformationList");
		
		return "/returnPage";
	}
	
	@RequestMapping(params="method=ajaxCloseInformation")
	@ResponseBody
	public String ajaxCloseInformation(HttpServletRequest request,
			HttpServletResponse response ) {
		MposSystemInformation systemInformation = new MposSystemInformation();
		String informationId=request.getParameter("informationId");
		try {
			Operator operator=(Operator)request.getSession().getAttribute(Constants.SESSION_KEY_USER);
			systemInformation.setId(Long.valueOf(informationId));
			systemInformation.setUpdatedate(new Date());
			systemInformation.setUpdateuser(operator.getUserName());
			systemInformation.setStatus(Constants.TYPE_2);
			informationService.updateCloseSystemInformation(systemInformation);
			return "1";
		} catch (Exception e) {
			e.printStackTrace();
			return "0";
		}
		
	}
	
	/**服务商关闭消息
	 * @param request
	 * @param mbform
	 * @param systemInformation
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(params = "method=toCloseAgentInformation")
	public String toCloseAgentInformation(HttpServletRequest request,
			InformationForm mbform,MposSystemInformation systemInformation) throws Exception {
		String informationId=request.getParameter("informationId");
		Operator operator=(Operator)request.getSession().getAttribute(Constants.SESSION_KEY_USER);
		systemInformation.setId(Long.valueOf(informationId));
		systemInformation.setUpdatedate(new Date());
		systemInformation.setUpdateuser(operator.getUserName());
		systemInformation.setStatus(Constants.TYPE_2);
		informationService.updateSystemInformation(systemInformation);
		request.setAttribute(Constants.MESSAGE_KEY, "消息关闭成功！");
		request.setAttribute("url", "information.htm?method=findInformationAgentList");
		
		return "/returnPage";
	}
	
	
	
	/**查看详情
	 * @param request
	 * @param mbform
	 * @return 
	 * @throws Exception
	 */
	@RequestMapping(params = "method=tofindinformationDetails")
	public String tofindinformationDetails(HttpServletRequest request,
			InformationForm mbform) throws Exception {
		String informationId=request.getParameter("informationId");
		if(StringUtils.isNotEmpty(informationId)){
			MposSystemInformation mposSystemInformation=informationService.findInformationById(informationId);
			request.setAttribute("mposSystemInformation", mposSystemInformation);
		}
		return "information/informationDetails";
	}
	
	
	

    /**定时任务，将公告自动置为关闭
     * @param args
     * @throws Exception
     */
    public  static void run(String[] args) throws Exception {
    	InformationService serv = (InformationService) Global.getSpringContext().getBean("informationService");
    	serv.updateinformationCrontab();
     }

	
}
