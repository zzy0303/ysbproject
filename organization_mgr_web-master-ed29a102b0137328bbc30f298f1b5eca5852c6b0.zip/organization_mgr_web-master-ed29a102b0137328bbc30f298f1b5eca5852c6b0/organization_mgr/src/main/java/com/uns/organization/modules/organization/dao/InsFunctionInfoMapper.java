package com.uns.organization.modules.organization.dao;

import java.math.BigDecimal;

import com.uns.organization.common.persistence.annotation.MyBatisDao;
import com.uns.organization.modules.organization.entity.InsFunctionInfo;
@MyBatisDao
public interface InsFunctionInfoMapper {


    int deleteByPrimaryKey(BigDecimal id);

    int insert(InsFunctionInfo record);

    int insertSelective(InsFunctionInfo record);

    InsFunctionInfo selectByPrimaryKey(BigDecimal id);

    int updateByPrimaryKeySelective(InsFunctionInfo record);

    int updateByPrimaryKey(InsFunctionInfo record);
}