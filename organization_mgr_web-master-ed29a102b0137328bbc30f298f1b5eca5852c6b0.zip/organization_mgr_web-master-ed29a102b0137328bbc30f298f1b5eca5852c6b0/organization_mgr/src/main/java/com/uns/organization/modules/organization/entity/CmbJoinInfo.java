package com.uns.organization.modules.organization.entity;

public class CmbJoinInfo {
    private Long infoId;

    private String feeRateId;

    private String payFeeRateNoWx;

    private String feeRateWx;

    private String payFeeRateNoZfb;

    private String feeRateZfb;

    private String accountName;

    private String accountNo;

    private String accountProp;

    private String provinceCodeJs;

    private String cityCodeJs;

    private String bankBranchNo;

    private String bankName;

    private String bankBranch;

    private String idCardNo;

    private String aliStatus;

    private String wxStatus;

    public Long getInfoId() {
        return infoId;
    }

    public void setInfoId(Long infoId) {
        this.infoId = infoId;
    }

    public String getFeeRateId() {
        return feeRateId;
    }

    public void setFeeRateId(String feeRateId) {
        this.feeRateId = feeRateId == null ? null : feeRateId.trim();
    }

    public String getPayFeeRateNoWx() {
        return payFeeRateNoWx;
    }

    public void setPayFeeRateNoWx(String payFeeRateNoWx) {
        this.payFeeRateNoWx = payFeeRateNoWx == null ? null : payFeeRateNoWx.trim();
    }

    public String getFeeRateWx() {
        return feeRateWx;
    }

    public void setFeeRateWx(String feeRateWx) {
        this.feeRateWx = feeRateWx == null ? null : feeRateWx.trim();
    }

    public String getPayFeeRateNoZfb() {
        return payFeeRateNoZfb;
    }

    public void setPayFeeRateNoZfb(String payFeeRateNoZfb) {
        this.payFeeRateNoZfb = payFeeRateNoZfb == null ? null : payFeeRateNoZfb.trim();
    }

    public String getFeeRateZfb() {
        return feeRateZfb;
    }

    public void setFeeRateZfb(String feeRateZfb) {
        this.feeRateZfb = feeRateZfb == null ? null : feeRateZfb.trim();
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName == null ? null : accountName.trim();
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo == null ? null : accountNo.trim();
    }

    public String getAccountProp() {
        return accountProp;
    }

    public void setAccountProp(String accountProp) {
        this.accountProp = accountProp == null ? null : accountProp.trim();
    }

    public String getProvinceCodeJs() {
        return provinceCodeJs;
    }

    public void setProvinceCodeJs(String provinceCodeJs) {
        this.provinceCodeJs = provinceCodeJs == null ? null : provinceCodeJs.trim();
    }

    public String getCityCodeJs() {
        return cityCodeJs;
    }

    public void setCityCodeJs(String cityCodeJs) {
        this.cityCodeJs = cityCodeJs == null ? null : cityCodeJs.trim();
    }

    public String getBankBranchNo() {
        return bankBranchNo;
    }

    public void setBankBranchNo(String bankBranchNo) {
        this.bankBranchNo = bankBranchNo == null ? null : bankBranchNo.trim();
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName == null ? null : bankName.trim();
    }

    public String getBankBranch() {
        return bankBranch;
    }

    public void setBankBranch(String bankBranch) {
        this.bankBranch = bankBranch == null ? null : bankBranch.trim();
    }

    public String getIdCardNo() {
        return idCardNo;
    }

    public void setIdCardNo(String idCardNo) {
        this.idCardNo = idCardNo == null ? null : idCardNo.trim();
    }

    public String getAliStatus() {
        return aliStatus;
    }

    public void setAliStatus(String aliStatus) {
        this.aliStatus = aliStatus == null ? null : aliStatus.trim();
    }

    public String getWxStatus() {
        return wxStatus;
    }

    public void setWxStatus(String wxStatus) {
        this.wxStatus = wxStatus == null ? null : wxStatus.trim();
    }
}