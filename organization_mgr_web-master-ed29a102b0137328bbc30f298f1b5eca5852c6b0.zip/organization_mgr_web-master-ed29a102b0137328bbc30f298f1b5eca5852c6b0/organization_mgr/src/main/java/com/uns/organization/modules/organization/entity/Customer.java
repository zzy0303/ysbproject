package com.uns.organization.modules.organization.entity;


import java.math.BigDecimal;
import java.util.Date;

import com.uns.organization.common.persistence.DataEntity;


public class Customer extends DataEntity<Customer>{
    private Long customerid;

    private String smallMerchNo;

    private String scompany;

    private String shortName;

    private String payType;

    private String province;

    private String city;

    private String merchAddress;

    private String phone;

    private String servicePhone;

    private String zfbCategory;

    private String wxCategory;

    private String businessLicenseNo;

    private Short status;

    private Short activestatus;

    private String insNo;

    private String linkman;

    private String linkmanType;

    private String certId;

    private String certType;

    private Long insCommission;

    private String industry;

    private String industryType;

    private String provincecode;

    private String citycode;

    private String countycode;

    private String billProvince;

    private String billCity;

    private String billAddress;

    private String remark;

    private String bankName;

    private String provinceName;

    private String cityName;

    private String openingBankName;

    private String name;

    private String bankcardno;

    private Long ysbuserid;

    private Long cascustomid;

    private Long accountBankId;

    private Short customertype;

    private Short dynCodeType;

    private Short fixCodeType;

    private BigDecimal creditLines;

    private Short feever;

    private Date createdate;

    private Date updatedate;
    
    private String checkstatus;
    
    private String reasonOfNotPass;
    private Date checkdate;
    
    
	//非实体类字段
    private String insName;
    private String provincialname;
    private String cityname;
    
    private String auditStatus;//商户报件状态
    private String aliAuditStatus;//支付宝报件状态
    private String wxAuditStatus;//微信报件状态
    private String cstatus;//商户状态中文字符串
    private String checkstatusstr;//商户审核状态中文字符串
    
    private String openingBankProvince;//开户行省份名称
    private String openingBankCity;//开户行城市名称

    private String billName;
    private Long photoId;
    private String protocolNum;

    public String getBillName() {
        return billName;
    }

    public void setBillName(String billName) {
        this.billName = billName;
    }

    public Long getPhotoId() {
        return photoId;
    }

    public void setPhotoId(Long photoId) {
        this.photoId = photoId;
    }

    public String getProtocolNum() {
        return protocolNum;
    }

    public void setProtocolNum(String protocolNum) {
        this.protocolNum = protocolNum;
    }

    public String getOpeningBankProvince() {
		return openingBankProvince;
	}

	public void setOpeningBankProvince(String openingBankProvince) {
		this.openingBankProvince = openingBankProvince;
	}

	public String getOpeningBankCity() {
		return openingBankCity;
	}

	public void setOpeningBankCity(String openingBankCity) {
		this.openingBankCity = openingBankCity;
	}

	public String getCheckstatusstr() {
		return checkstatusstr;
	}

	public void setCheckstatusstr(String checkstatusstr) {
		this.checkstatusstr = checkstatusstr;
	}

	public String getCstatus() {
		return cstatus;
	}

	public void setCstatus(String cstatus) {
		this.cstatus = cstatus;
	}

	public String getReasonOfNotPass() {
		return reasonOfNotPass;
	}

	public void setReasonOfNotPass(String reasonOfNotPass) {
		this.reasonOfNotPass = reasonOfNotPass;
	}




	public String getAuditStatus() {
		return auditStatus;
	}

	public void setAuditStatus(String auditStatus) {
		this.auditStatus = auditStatus;
	}

	public String getAliAuditStatus() {
		return aliAuditStatus;
	}

	public void setAliAuditStatus(String aliAuditStatus) {
		this.aliAuditStatus = aliAuditStatus;
	}

	public String getWxAuditStatus() {
		return wxAuditStatus;
	}

	public void setWxAuditStatus(String wxAuditStatus) {
		this.wxAuditStatus = wxAuditStatus;
	}

	public String getProvincialname() {
		return provincialname;
	}

	public void setProvincialname(String provincialname) {
		this.provincialname = provincialname;
	}

	public String getCityname() {
		return cityname;
	}

	public void setCityname(String cityname) {
		this.cityname = cityname;
	}

	public String getCheckstatus() {
    	return checkstatus;
    }
    
    public void setCheckstatus(String checkstatus) {
    	this.checkstatus = checkstatus;
    }
    public String getInsName() {
		return insName;
	}

	public void setInsName(String insName) {
		this.insName = insName;
	}

	public Long getCustomerid() {
        return customerid;
    }

    public void setCustomerid(Long customerid) {
        this.customerid = customerid;
    }

    public String getSmallMerchNo() {
        return smallMerchNo;
    }

    public void setSmallMerchNo(String smallMerchNo) {
        this.smallMerchNo = smallMerchNo == null ? null : smallMerchNo.trim();
    }

    public String getScompany() {
        return scompany;
    }

    public void setScompany(String scompany) {
        this.scompany = scompany == null ? null : scompany.trim();
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName == null ? null : shortName.trim();
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType == null ? null : payType.trim();
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province == null ? null : province.trim();
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city == null ? null : city.trim();
    }

    public String getMerchAddress() {
        return merchAddress;
    }

    public void setMerchAddress(String merchAddress) {
        this.merchAddress = merchAddress == null ? null : merchAddress.trim();
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    public String getServicePhone() {
        return servicePhone;
    }

    public void setServicePhone(String servicePhone) {
        this.servicePhone = servicePhone == null ? null : servicePhone.trim();
    }

    public String getZfbCategory() {
        return zfbCategory;
    }

    public void setZfbCategory(String zfbCategory) {
        this.zfbCategory = zfbCategory == null ? null : zfbCategory.trim();
    }

    public String getWxCategory() {
        return wxCategory;
    }

    public void setWxCategory(String wxCategory) {
        this.wxCategory = wxCategory == null ? null : wxCategory.trim();
    }

    public String getBusinessLicenseNo() {
        return businessLicenseNo;
    }

    public void setBusinessLicenseNo(String businessLicenseNo) {
        this.businessLicenseNo = businessLicenseNo == null ? null : businessLicenseNo.trim();
    }

    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    public Short getActivestatus() {
        return activestatus;
    }

    public void setActivestatus(Short activestatus) {
        this.activestatus = activestatus;
    }

    public String getInsNo() {
        return insNo;
    }

    public void setInsNo(String insNo) {
        this.insNo = insNo == null ? null : insNo.trim();
    }

    public String getLinkman() {
        return linkman;
    }

    public void setLinkman(String linkman) {
        this.linkman = linkman == null ? null : linkman.trim();
    }

    public String getLinkmanType() {
        return linkmanType;
    }

    public void setLinkmanType(String linkmanType) {
        this.linkmanType = linkmanType == null ? null : linkmanType.trim();
    }

    public String getCertId() {
        return certId;
    }

    public void setCertId(String certId) {
        this.certId = certId == null ? null : certId.trim();
    }

    public String getCertType() {
        return certType;
    }

    public void setCertType(String certType) {
        this.certType = certType == null ? null : certType.trim();
    }

    public Long getInsCommission() {
        return insCommission;
    }

    public void setInsCommission(Long insCommission) {
        this.insCommission = insCommission;
    }

    public String getIndustry() {
        return industry;
    }

    public void setIndustry(String industry) {
        this.industry = industry == null ? null : industry.trim();
    }

    public String getIndustryType() {
        return industryType;
    }

    public void setIndustryType(String industryType) {
        this.industryType = industryType == null ? null : industryType.trim();
    }

    public String getProvincecode() {
        return provincecode;
    }

    public void setProvincecode(String provincecode) {
        this.provincecode = provincecode == null ? null : provincecode.trim();
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode == null ? null : citycode.trim();
    }

    public String getCountycode() {
        return countycode;
    }

    public void setCountycode(String countycode) {
        this.countycode = countycode == null ? null : countycode.trim();
    }

    public String getBillProvince() {
        return billProvince;
    }

    public void setBillProvince(String billProvince) {
        this.billProvince = billProvince == null ? null : billProvince.trim();
    }

    public String getBillCity() {
        return billCity;
    }

    public void setBillCity(String billCity) {
        this.billCity = billCity == null ? null : billCity.trim();
    }

    public String getBillAddress() {
        return billAddress;
    }

    public void setBillAddress(String billAddress) {
        this.billAddress = billAddress == null ? null : billAddress.trim();
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName == null ? null : bankName.trim();
    }

    public String getProvinceName() {
        return provinceName;
    }

    public void setProvinceName(String provinceName) {
        this.provinceName = provinceName == null ? null : provinceName.trim();
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName == null ? null : cityName.trim();
    }

    public String getOpeningBankName() {
        return openingBankName;
    }

    public void setOpeningBankName(String openingBankName) {
        this.openingBankName = openingBankName == null ? null : openingBankName.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getBankcardno() {
        return bankcardno;
    }

    public void setBankcardno(String bankcardno) {
        this.bankcardno = bankcardno == null ? null : bankcardno.trim();
    }

    public Long getYsbuserid() {
        return ysbuserid;
    }

    public void setYsbuserid(Long ysbuserid) {
        this.ysbuserid = ysbuserid;
    }

    public Long getCascustomid() {
        return cascustomid;
    }

    public void setCascustomid(Long cascustomid) {
        this.cascustomid = cascustomid;
    }

    public Long getAccountBankId() {
        return accountBankId;
    }

    public void setAccountBankId(Long accountBankId) {
        this.accountBankId = accountBankId;
    }

    public Short getCustomertype() {
        return customertype;
    }

    public void setCustomertype(Short customertype) {
        this.customertype = customertype;
    }

    public Short getDynCodeType() {
        return dynCodeType;
    }

    public void setDynCodeType(Short dynCodeType) {
        this.dynCodeType = dynCodeType;
    }

    public Short getFixCodeType() {
        return fixCodeType;
    }

    public void setFixCodeType(Short fixCodeType) {
        this.fixCodeType = fixCodeType;
    }

    public BigDecimal getCreditLines() {
        return creditLines;
    }

    public void setCreditLines(BigDecimal creditLines) {
        this.creditLines = creditLines;
    }

    public Short getFeever() {
        return feever;
    }

	public void setFeever(Short feever) {
        this.feever = feever;
    }

	public Date getCreatedate() {
		return createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}

	public Date getUpdatedate() {
		return updatedate;
	}

	public void setUpdatedate(Date updatedate) {
		this.updatedate = updatedate;
	}

	public Date getCheckdate() {
		return checkdate;
	}

	public void setCheckdate(Date checkdate) {
		this.checkdate = checkdate;
	}

}