package com.uns.organization.modules.organization.entity;

public class InsCommissionType {
    private String insNo; //机构号

    private String commissionName;  //费率名称

    private String cardType; //费率类型

    private String commissionRate; //T1费率区间

    private String d0CommissionRate; //D0费率区间

    private String fixedRate; //T1固定费率区间

    private String d0FixedRate; //D0固定费率区间

    public String getInsNo() {
        return insNo;
    }

    public void setInsNo(String insNo) {
        this.insNo = insNo;
    }

    public String getCommissionName() {
        return commissionName;
    }

    public void setCommissionName(String commissionName) {
        this.commissionName = commissionName;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getCommissionRate() {
        return commissionRate;
    }

    public void setCommissionRate(String commissionRate) {
        this.commissionRate = commissionRate;
    }

    public String getD0CommissionRate() {
        return d0CommissionRate;
    }

    public void setD0CommissionRate(String d0CommissionRate) {
        this.d0CommissionRate = d0CommissionRate;
    }

    public String getFixedRate() {
        return fixedRate;
    }

    public void setFixedRate(String fixedRate) {
        this.fixedRate = fixedRate;
    }

    public String getD0FixedRate() {
        return d0FixedRate;
    }

    public void setD0FixedRate(String d0FixedRate) {
        this.d0FixedRate = d0FixedRate;
    }
}
