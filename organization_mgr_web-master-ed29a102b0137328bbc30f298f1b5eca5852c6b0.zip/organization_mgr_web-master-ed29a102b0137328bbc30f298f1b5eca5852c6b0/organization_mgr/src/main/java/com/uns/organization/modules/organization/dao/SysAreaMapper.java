package com.uns.organization.modules.organization.dao;

import java.util.List;

import com.uns.organization.common.persistence.annotation.MyBatisDao;
import com.uns.organization.modules.organization.entity.Customer;
import com.uns.organization.modules.organization.entity.SysArea;
@MyBatisDao
public interface SysAreaMapper {

    int insert(SysArea record);

    int insertSelective(SysArea record);

	List<SysArea> findAllProvince();

	List<SysArea> provinceAllCity(String province);
	
	List<SysArea> findAllCity();
	
	SysArea findAreaNameByYsb(Customer customer);

}