package com.uns.organization.modules.organization.dao;

import java.util.List;

import com.uns.organization.common.persistence.annotation.MyBatisDao;
import com.uns.organization.modules.organization.entity.Commissionpolicy;
import com.uns.organization.modules.organization.entity.CommissionpolicyHis;
@MyBatisDao
public interface CommissionpolicyMapper {


    int insert(Commissionpolicy record);

    int insertSelective(Commissionpolicy record);

    List findCommissionpolicy(Long thisCustomerId);

}