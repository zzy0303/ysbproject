package com.uns.organization.modules.organization.dao;

import com.uns.organization.common.persistence.annotation.MyBatisDao;
import com.uns.organization.modules.organization.entity.CustomerHis;
@MyBatisDao
public interface CustomerHisMapper {


    int deleteByPrimaryKey(Long customerId);

    int insert(CustomerHis record);

    int insertSelective(CustomerHis record);

    CustomerHis selectByPrimaryKey(Long customerId);

    int updateByPrimaryKeySelective(CustomerHis record);

    int updateByPrimaryKey(CustomerHis record);
    
    CustomerHis findCustomerHisDetails(Long customerid);
}