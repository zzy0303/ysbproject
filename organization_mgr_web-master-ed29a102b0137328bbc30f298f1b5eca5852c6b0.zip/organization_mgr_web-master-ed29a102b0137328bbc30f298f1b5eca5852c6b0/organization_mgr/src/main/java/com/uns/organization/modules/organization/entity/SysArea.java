package com.uns.organization.modules.organization.entity;

public class SysArea {
	private Long id;
	
    private String provincial;

    private String provincialname;

    private String city;

    private String cityname;
    
    private String ysbCity;
    
    private String ysbProv;

    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getYsbCity() {
		return ysbCity;
	}

	public void setYsbCity(String ysbCity) {
		this.ysbCity = ysbCity;
	}

	public String getYsbProv() {
		return ysbProv;
	}

	public void setYsbProv(String ysbProv) {
		this.ysbProv = ysbProv;
	}

	public String getProvincial() {
        return provincial;
    }

    public void setProvincial(String provincial) {
        this.provincial = provincial == null ? null : provincial.trim();
    }

    public String getProvincialname() {
        return provincialname;
    }

    public void setProvincialname(String provincialname) {
        this.provincialname = provincialname == null ? null : provincialname.trim();
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city == null ? null : city.trim();
    }

    public String getCityname() {
        return cityname;
    }

    public void setCityname(String cityname) {
        this.cityname = cityname == null ? null : cityname.trim();
    }
}