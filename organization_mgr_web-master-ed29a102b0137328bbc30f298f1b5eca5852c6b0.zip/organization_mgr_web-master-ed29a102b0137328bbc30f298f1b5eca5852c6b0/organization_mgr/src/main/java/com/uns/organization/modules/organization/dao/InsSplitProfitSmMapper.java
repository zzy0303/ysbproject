package com.uns.organization.modules.organization.dao;

import com.uns.organization.common.persistence.annotation.MyBatisDao;
import com.uns.organization.modules.organization.entity.InsSplitProfitSm;
import java.math.BigDecimal;
import java.util.List;

@MyBatisDao
public interface InsSplitProfitSmMapper {

    int deleteByPrimaryKey(BigDecimal id);

    int insert(InsSplitProfitSm record);

    int insertSelective(InsSplitProfitSm record);

    InsSplitProfitSm selectByPrimaryKey(BigDecimal id);

    int updateByPrimaryKeySelective(InsSplitProfitSm record);

    int updateByPrimaryKey(InsSplitProfitSm record);

    List<InsSplitProfitSm> querySplitProfitList(InsSplitProfitSm insSplitProfitSm);
}