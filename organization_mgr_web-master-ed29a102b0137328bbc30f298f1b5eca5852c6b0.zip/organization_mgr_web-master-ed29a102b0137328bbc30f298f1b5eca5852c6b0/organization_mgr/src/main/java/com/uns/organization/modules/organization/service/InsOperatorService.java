package com.uns.organization.modules.organization.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.organization.common.persistence.Page;
import com.uns.organization.common.service.BaseService;
import com.uns.organization.common.utils.Constants;
import com.uns.organization.modules.organization.dao.InsOperatorMapper;
import com.uns.organization.modules.organization.entity.InsOperator;
import com.uns.organization.modules.organization.entity.InsRoleInfo;
import com.uns.organization.modules.sys.utils.UserUtils;

@Service
public class InsOperatorService extends BaseService{
	
	@Autowired
	private InsOperatorMapper insOperatorMapper;
	
	public Page<InsOperator> findInstitutionList(Page<InsOperator> page, InsOperator insOperator) {
		// 设置分页参数
		insOperator.setPage(page);
		// 执行分页查询
		page.setList(insOperatorMapper.findInsOperatorList(insOperator));
		return page;
	}

	public InsOperator findInsOperatorByOperatorId(BigDecimal operatorId) {
		return insOperatorMapper.findInsOperatorByOperatorId(operatorId);
	}

	/**
	 * 查询机构所有角色
	 */
	public List<InsRoleInfo> findAllInsRole() {
		return insOperatorMapper.findAllInsRole();
	}

	/**
	 * 修改机构操作员账号信息
	 * @param insOperator
	 */
	public void saveInsOperatorEdit(InsOperator insOperator) {
		insOperator.setUpdateUser(UserUtils.getUser().getId());
		insOperator.setUpdateDate(new Date());
		insOperatorMapper.updateByPrimaryKeySelective(insOperator);
	}

	/**
	 * 机构操作员冻结
	 * @param operatorId
	 */
	public void updateInsOperatorStatus(BigDecimal operatorId,String status) {
		InsOperator insOperator = new InsOperator();
		insOperator.setOperatorId(operatorId);
		insOperator.setStatus(status);//修改状态
		insOperator.setUpdateUser(UserUtils.getUser().getId());
		insOperator.setUpdateDate(new Date());
		insOperatorMapper.updateByPrimaryKeySelective(insOperator);
	}
	
}
