package com.uns.organization.modules.organization.dao;

import java.math.BigDecimal;
import java.util.List;

import com.uns.organization.common.persistence.annotation.MyBatisDao;
import com.uns.organization.modules.organization.entity.InsCommissionType;
import com.uns.organization.modules.organization.entity.InstitutionFee;
@MyBatisDao
public interface InstitutionFeeMapper {


    int deleteByPrimaryKey(BigDecimal insFeeId);

    int deleteByInsNo(String insNo);
    
    int insert(InstitutionFee record);

    int insertSelective(InstitutionFee record);

    InstitutionFee selectByPrimaryKey(BigDecimal insFeeId);

    int updateByPrimaryKeySelective(InstitutionFee record);

    int updateByPrimaryKey(InstitutionFee record);

    List<InstitutionFee> findInsFeeList(String insNo);

    List<InsCommissionType> findInsCommissionType(String insNo);

    int deleteByComRange(String insNo);
}