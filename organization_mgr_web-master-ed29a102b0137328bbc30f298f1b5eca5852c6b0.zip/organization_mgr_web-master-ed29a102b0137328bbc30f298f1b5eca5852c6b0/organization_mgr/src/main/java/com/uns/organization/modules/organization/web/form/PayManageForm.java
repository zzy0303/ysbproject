package com.uns.organization.modules.organization.web.form;

public class PayManageForm {
    private String dynamicT1AmountStart;
    private String dynamicT1AmountEnd;
    private String dynamicT1AmountStartTime;
    private String dynamicT1AmountEndTime;
    private String dynamicD0AmountStart;
    private String dynamicD0AmountEnd;
    private String dynamicD0AmountStartTime;
    private String dynamicD0AmountEndTime;

    private String fixT1AmountStart;
    private String fixT1AmountEnd;
    private String fixT1AmountStartTime;
    private String fixT1AmountEndTime;
    private String fixD0AmountStart;
    private String fixD0AmountEnd;
    private String fixD0AmountStartTime;
    private String fixD0AmountEndTime;

    private String quickT1AmountStart;
    private String quickT1AmountEnd;
    private String quickT1AmountStartTime;
    private String quickT1AmountEndTime;
    private String quickD0AmountStart;
    private String quickD0AmountEnd;
    private String quickD0AmountStartTime;
    private String quickD0AmountEndTime;

    //快捷速惠D0
    private String quickSHD0AmountStart;
    private String quickSHD0AmountEnd;
    private String quickSHD0AmountStartTime;
    private String quickSHD0AmountEndTime;

    public String getQuickSHD0AmountStart() {
        return quickSHD0AmountStart;
    }

    public void setQuickSHD0AmountStart(String quickSHD0AmountStart) {
        this.quickSHD0AmountStart = quickSHD0AmountStart;
    }

    public String getQuickSHD0AmountEnd() {
        return quickSHD0AmountEnd;
    }

    public void setQuickSHD0AmountEnd(String quickSHD0AmountEnd) {
        this.quickSHD0AmountEnd = quickSHD0AmountEnd;
    }

    public String getQuickSHD0AmountStartTime() {
        return quickSHD0AmountStartTime;
    }

    public void setQuickSHD0AmountStartTime(String quickSHD0AmountStartTime) {
        this.quickSHD0AmountStartTime = quickSHD0AmountStartTime;
    }

    public String getQuickSHD0AmountEndTime() {
        return quickSHD0AmountEndTime;
    }

    public void setQuickSHD0AmountEndTime(String quickSHD0AmountEndTime) {
        this.quickSHD0AmountEndTime = quickSHD0AmountEndTime;
    }

    public String getQuickT1AmountStart() {
        return quickT1AmountStart;
    }

    public void setQuickT1AmountStart(String quickT1AmountStart) {
        this.quickT1AmountStart = quickT1AmountStart;
    }

    public String getQuickT1AmountEnd() {
        return quickT1AmountEnd;
    }

    public void setQuickT1AmountEnd(String quickT1AmountEnd) {
        this.quickT1AmountEnd = quickT1AmountEnd;
    }

    public String getQuickT1AmountStartTime() {
        return quickT1AmountStartTime;
    }

    public void setQuickT1AmountStartTime(String quickT1AmountStartTime) {
        this.quickT1AmountStartTime = quickT1AmountStartTime;
    }

    public String getQuickT1AmountEndTime() {
        return quickT1AmountEndTime;
    }

    public void setQuickT1AmountEndTime(String quickT1AmountEndTime) {
        this.quickT1AmountEndTime = quickT1AmountEndTime;
    }

    public String getQuickD0AmountStart() {
        return quickD0AmountStart;
    }

    public void setQuickD0AmountStart(String quickD0AmountStart) {
        this.quickD0AmountStart = quickD0AmountStart;
    }

    public String getQuickD0AmountEnd() {
        return quickD0AmountEnd;
    }

    public void setQuickD0AmountEnd(String quickD0AmountEnd) {
        this.quickD0AmountEnd = quickD0AmountEnd;
    }

    public String getQuickD0AmountStartTime() {
        return quickD0AmountStartTime;
    }

    public void setQuickD0AmountStartTime(String quickD0AmountStartTime) {
        this.quickD0AmountStartTime = quickD0AmountStartTime;
    }

    public String getQuickD0AmountEndTime() {
        return quickD0AmountEndTime;
    }

    public void setQuickD0AmountEndTime(String quickD0AmountEndTime) {
        this.quickD0AmountEndTime = quickD0AmountEndTime;
    }

    public String getDynamicT1AmountStart() {
        return dynamicT1AmountStart;
    }

    public void setDynamicT1AmountStart(String dynamicT1AmountStart) {
        this.dynamicT1AmountStart = dynamicT1AmountStart;
    }

    public String getDynamicT1AmountEnd() {
        return dynamicT1AmountEnd;
    }

    public void setDynamicT1AmountEnd(String dynamicT1AmountEnd) {
        this.dynamicT1AmountEnd = dynamicT1AmountEnd;
    }

    public String getDynamicT1AmountStartTime() {
        return dynamicT1AmountStartTime;
    }

    public void setDynamicT1AmountStartTime(String dynamicT1AmountStartTime) {
        this.dynamicT1AmountStartTime = dynamicT1AmountStartTime;
    }

    public String getDynamicT1AmountEndTime() {
        return dynamicT1AmountEndTime;
    }

    public void setDynamicT1AmountEndTime(String dynamicT1AmountEndTime) {
        this.dynamicT1AmountEndTime = dynamicT1AmountEndTime;
    }

    public String getDynamicD0AmountStart() {
        return dynamicD0AmountStart;
    }

    public void setDynamicD0AmountStart(String dynamicD0AmountStart) {
        this.dynamicD0AmountStart = dynamicD0AmountStart;
    }

    public String getDynamicD0AmountEnd() {
        return dynamicD0AmountEnd;
    }

    public void setDynamicD0AmountEnd(String dynamicD0AmountEnd) {
        this.dynamicD0AmountEnd = dynamicD0AmountEnd;
    }

    public String getDynamicD0AmountStartTime() {
        return dynamicD0AmountStartTime;
    }

    public void setDynamicD0AmountStartTime(String dynamicD0AmountStartTime) {
        this.dynamicD0AmountStartTime = dynamicD0AmountStartTime;
    }

    public String getDynamicD0AmountEndTime() {
        return dynamicD0AmountEndTime;
    }

    public void setDynamicD0AmountEndTime(String dynamicD0AmountEndTime) {
        this.dynamicD0AmountEndTime = dynamicD0AmountEndTime;
    }

    public String getFixT1AmountStart() {
        return fixT1AmountStart;
    }

    public void setFixT1AmountStart(String fixT1AmountStart) {
        this.fixT1AmountStart = fixT1AmountStart;
    }

    public String getFixT1AmountEnd() {
        return fixT1AmountEnd;
    }

    public void setFixT1AmountEnd(String fixT1AmountEnd) {
        this.fixT1AmountEnd = fixT1AmountEnd;
    }

    public String getFixT1AmountStartTime() {
        return fixT1AmountStartTime;
    }

    public void setFixT1AmountStartTime(String fixT1AmountStartTime) {
        this.fixT1AmountStartTime = fixT1AmountStartTime;
    }

    public String getFixT1AmountEndTime() {
        return fixT1AmountEndTime;
    }

    public void setFixT1AmountEndTime(String fixT1AmountEndTime) {
        this.fixT1AmountEndTime = fixT1AmountEndTime;
    }

    public String getFixD0AmountStart() {
        return fixD0AmountStart;
    }

    public void setFixD0AmountStart(String fixD0AmountStart) {
        this.fixD0AmountStart = fixD0AmountStart;
    }

    public String getFixD0AmountEnd() {
        return fixD0AmountEnd;
    }

    public void setFixD0AmountEnd(String fixD0AmountEnd) {
        this.fixD0AmountEnd = fixD0AmountEnd;
    }

    public String getFixD0AmountStartTime() {
        return fixD0AmountStartTime;
    }

    public void setFixD0AmountStartTime(String fixD0AmountStartTime) {
        this.fixD0AmountStartTime = fixD0AmountStartTime;
    }

    public String getFixD0AmountEndTime() {
        return fixD0AmountEndTime;
    }

    public void setFixD0AmountEndTime(String fixD0AmountEndTime) {
        this.fixD0AmountEndTime = fixD0AmountEndTime;
    }
}
