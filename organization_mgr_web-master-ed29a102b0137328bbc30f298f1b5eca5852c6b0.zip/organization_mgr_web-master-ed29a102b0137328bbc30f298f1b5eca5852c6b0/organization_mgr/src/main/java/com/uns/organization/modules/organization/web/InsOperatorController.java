package com.uns.organization.modules.organization.web;

import java.math.BigDecimal;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.uns.organization.common.persistence.Page;
import com.uns.organization.common.utils.Constants;
import com.uns.organization.common.web.BaseController;
import com.uns.organization.modules.organization.entity.InsOperator;
import com.uns.organization.modules.organization.entity.InsRoleInfo;
import com.uns.organization.modules.organization.service.InsOperatorService;

/**
 * 机构操作账号管理
 * @author yang.cheng
 *
 */
@Controller
@RequestMapping(value = "${adminPath}/ins/insOperator")
public class InsOperatorController extends BaseController{
	
	@Autowired
	InsOperatorService insOperatorService;
	
	@RequestMapping(value = {"list", ""})
	public String list(InsOperator insOperator,HttpServletRequest request, HttpServletResponse response, Model model) {
		try {
			Page<InsOperator> page = insOperatorService.findInstitutionList(new Page<InsOperator>(request, response), insOperator);
			model.addAttribute("page", page);
		} catch (Exception e) {
			logger.error("查询机构账号列表异常！",e);
			addMessage(model, "查询机构账号列表失败！"+e.getMessage());
		}
		return "modules/insOperator/insOperatorList";
	}
	
	/**
	 * 跳转到机构账号修改页面
	 * @param operatorId
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@RequiresPermissions("ins:insOperator:edit")
	@RequestMapping(value ="insOperatorEdit")
	public String insOperatorEdit(BigDecimal operatorId,HttpServletRequest request, HttpServletResponse response, Model model,RedirectAttributes redirectAttributes){
		try {
			InsOperator insOperator = insOperatorService.findInsOperatorByOperatorId(operatorId);
			List<InsRoleInfo> allInsRole = insOperatorService.findAllInsRole();
			model.addAttribute("allInsRole", allInsRole);
			model.addAttribute("insOperator", insOperator);
			return "modules/insOperator/insOperatorEdit";
		} catch (Exception e) {
			logger.error("跳转到机构修改页面异常！", e);
			addMessage(redirectAttributes, "跳转到机构修改页面失败！"+e.getMessage());
			return "redirect:" + adminPath + "/ins/insOperator/list?repage";
		}
	}
	
	/**
	 * 保存机构账号修改信息
	 * @param insOperator
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@RequiresPermissions("ins:insOperator:edit")
	@RequestMapping(value ="saveInsOperatorEdit")
	public String saveInsOperatorEdit(InsOperator insOperator,HttpServletRequest request, HttpServletResponse response, RedirectAttributes redirectAttributes){
		try {
			insOperatorService.saveInsOperatorEdit(insOperator);
			addMessage(redirectAttributes, "修改机构账号成功！");
		} catch (Exception e) {
			logger.error("修改机构账户信息异常！", e);
			addMessage(redirectAttributes, "修改机构账号失败！"+e.getMessage());
		}
		return "redirect:" + adminPath + "/ins/insOperator/list?repage";
	}
	
	/**
	 * 冻结机构操作员账号
	 * @param operatorId
	 * @return
	 */
	@RequiresPermissions("ins:insOperator:forzen")
	@RequestMapping(value ="forzenInsOperator")
	public String forzenInsOperator(BigDecimal operatorId,HttpServletRequest request, HttpServletResponse response, Model model,RedirectAttributes redirectAttributes){
		try {
			insOperatorService.updateInsOperatorStatus(operatorId, Constants.INS_OPERATOR_STATUS_2);//冻结状态
			addMessage(redirectAttributes,"机构操作员冻结成功！");
		} catch (Exception e) {
			logger.error("机构操作员冻结异常！", e);
			addMessage(redirectAttributes, "机构操作员冻结失败！"+e.getMessage());
		}
		return "redirect:" + adminPath + "/ins/insOperator/list?repage";
	}
	
	/**
	 * 解冻机构操作员账号
	 * @param operatorId
	 * @return
	 */
	@RequiresPermissions("ins:insOperator:forzen")
	@RequestMapping(value ="thawInsOperator")
	public String thawInsOperator(BigDecimal operatorId,HttpServletRequest request, HttpServletResponse response, Model model,RedirectAttributes redirectAttributes){
		try {
			insOperatorService.updateInsOperatorStatus(operatorId, Constants.INS_OPERATOR_STATUS_0);//正常状态
			addMessage(redirectAttributes,"机构操作员解冻成功！");
		} catch (Exception e) {
			logger.error("机构操作员解冻异常！", e);
			addMessage(redirectAttributes, "机构操作员解冻失败！"+e.getMessage());
		}
		return "redirect:" + adminPath + "/ins/insOperator/list?repage";
	}
}
