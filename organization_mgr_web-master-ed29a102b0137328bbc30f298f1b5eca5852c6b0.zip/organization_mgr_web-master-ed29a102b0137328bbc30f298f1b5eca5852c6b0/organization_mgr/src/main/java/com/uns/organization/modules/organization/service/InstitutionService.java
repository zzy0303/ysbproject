package com.uns.organization.modules.organization.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.uns.organization.common.exception.ExceptionEnum;
import com.uns.organization.modules.organization.entity.*;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.ibatis.annotations.Case;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.uns.organization.common.exception.BusinessException;
import com.uns.organization.common.persistence.Page;
import com.uns.organization.common.service.BaseService;
import com.uns.organization.common.utils.Constants;
import com.uns.organization.common.utils.HttpRequestUtils;
import com.uns.organization.common.utils.ParamPlatfrom;
import com.uns.organization.modules.organization.dao.InsOperatorMapper;
import com.uns.organization.modules.organization.dao.InstitutionFeeHisMapper;
import com.uns.organization.modules.organization.dao.InstitutionFeeMapper;
import com.uns.organization.modules.organization.dao.InstitutionHisMapper;
import com.uns.organization.modules.organization.dao.InstitutionMapper;
import com.uns.organization.modules.organization.entity.InsOperator;
import com.uns.organization.modules.organization.entity.Institution;
import com.uns.organization.modules.organization.entity.InstitutionFee;
import com.uns.organization.modules.organization.entity.InstitutionFeeHis;
import com.uns.organization.modules.sys.utils.UserUtils;

import net.sf.json.JSONObject;

@Service
public class InstitutionService extends BaseService{
	
	@Autowired
	private InstitutionMapper institutionMapper;
	@Autowired
	private InstitutionHisMapper institutionHisMapper;
	@Autowired
	private InsOperatorMapper insOperatorMapper;
	@Autowired
	private InstitutionFeeMapper institutionFeeMapper;
	@Autowired
	private InstitutionFeeHisMapper institutionFeeHisMapper;
	
	public Page<Institution> findInstitutionList(Page<Institution> page, Institution institution) {
		// 设置分页参数
		institution.setPage(page);
		// 执行分页查询
		page.setList(institutionMapper.findInstitutionList(institution));
		return page;
	}

	/**
	 * 新增，修改机构信息
	 * @param institution
	 */
	public void saveInstitution(Institution institution) throws Exception{
		Date now = new Date();
		institution.setUpdateTime(now);
		if(institution.getInsId()==null){//新增
			if (Constants.STATUS_1.equals(institution.getSettleType())){
				//调用机构个人入驻接口
				registerInstitutionP(institution);
			} else{
				//调用机构企业入驻接口
				registerInstitutionC(institution);
			}
			insertInstitutionInfo(institution);
		}else{//修改
			if (Constants.STATUS_1.equals(institution.getSettleType())){
				//机构个人信息修改接口调用
				updateInstitutionP(institution);
			} else {
				//机构企业信息修改接口调用
				updateInstitutionC(institution);
			}
			updateInstitutionInfo(institution);
		}
	}
	
	/**
	 * 机构添加相关信息
	 * @param institution
	 */
	@Transactional
	private void insertInstitutionInfo(Institution institution)throws Exception{
		institution.setInsNo(createInstitutionNo(institution.getInsCity()));//设置机构编号
		//保存机构基本信息
		institution.setCreateTime(new Date());
		institution.setUpdateTime(new Date());
		institutionMapper.insertSelective(institution);
		institutionHisMapper.insertByInstitution(institution.getInsId());//保存机构基本信息历史记录
		saveInstitutionFee(institution,false);//保存机构费率以及历史记录
        saveMerFeeRange(institution,false); //保存商户扫码费率区间
		createDefaultInsOperator(institution);//添加机构登录平台默认登录账号
	}
	
	/**
	 * 机构修改相关信息
	 * @param institution
	 */
	@Transactional
	private void updateInstitutionInfo(Institution institution)throws Exception{
		//更新机构基本信息
		institution.setUpdateTime(new Date());
		institutionMapper.updateByPrimaryKeySelective(institution);
		//保存机构基本信息历史记录
		institutionHisMapper.insertByInstitution(institution.getInsId());
		//if(institution.isEditFee()){//是否修改费率
		saveInstitutionFee(institution,true);
        saveMerFeeRange(institution,true);
	}
	
	
	/**
	 * 保存费率
	 * @param institution
	 */
	private void saveInstitutionFee(Institution institution,Boolean update) throws Exception{
		String insNo = institution.getInsNo();
		//更新费率时，需要删除之前的机构费率信息，在保存更新后的费率信息
		if(update){
			institutionFeeMapper.deleteByInsNo(insNo);
		}
		String businessType = institution.getBusinessType();//业务类型
		List<String> typeList = Arrays.asList(businessType.split(","));
		List<InstitutionFee> feeList = new ArrayList<>();
		if(typeList.indexOf(Constants.INS_BUSINESS_TYPE_0)!=-1){//扫码费率
            List commissionTypes = Arrays.asList(institution.getCommissionType().split(","));
            if(commissionTypes.contains(Constants.INS_FEE_TYPE_2)){
                //微信二维码
                InstitutionFee wxFee =  createInstitutionFee(insNo,Constants.INS_FEE_TYPE_2, institution.getWxFee(), institution.getWxD0Fee(), institution.getWxT1Fixation() ,institution.getWxD0Fixation());
                feeList.add(wxFee);
            }
            if(commissionTypes.contains(Constants.INS_FEE_TYPE_15)){
                //微信APP
                InstitutionFee wxAppFee = createInstitutionFee(insNo,Constants.INS_FEE_TYPE_15, institution.getWxAppFee(),institution.getWxAppD0Fee(),institution.getWxAppT1Fixation(),institution.getWxAppD0Fixation());
                feeList.add(wxAppFee);
            }
            if(commissionTypes.contains(Constants.INS_FEE_TYPE_16)){
                //微信公众号
                InstitutionFee wxGzhFee = createInstitutionFee(insNo,Constants.INS_FEE_TYPE_16, institution.getWxGzhFee(),institution.getWxGzhD0Fee(),institution.getWxGzhT1Fixation(),institution.getWxGzhD0Fixation());
                feeList.add(wxGzhFee);
            }
            if(commissionTypes.contains(Constants.INS_FEE_TYPE_3)){
                //支付宝二维码
                InstitutionFee zfbFee =  createInstitutionFee(insNo,Constants.INS_FEE_TYPE_3, institution.getZfbFee(), institution.getZfbD0Fee(), institution.getZfbT1ixation(),institution.getZfbD0Fixation());
                feeList.add(zfbFee);
            }
            if(commissionTypes.contains(Constants.INS_FEE_TYPE_13)){
                //支付宝APP
                InstitutionFee zfbAppFee =  createInstitutionFee(insNo,Constants.INS_FEE_TYPE_13, institution.getZfbAppFee(), institution.getZfbAppD0Fee(), institution.getZfbAppT1ixation(),institution.getZfbAppD0Fixation());
                feeList.add(zfbAppFee);
            }
            if(commissionTypes.contains(Constants.INS_FEE_TYPE_14)){
                //支付宝H5
                InstitutionFee zfbH5Fee =  createInstitutionFee(insNo,Constants.INS_FEE_TYPE_14, institution.getZfbH5Fee(), institution.getZfbH5D0Fee(), institution.getZfbH5T1ixation(),institution.getZfbH5D0Fixation());
                feeList.add(zfbH5Fee);
            }
		}
		if(typeList.indexOf(Constants.INS_BUSINESS_TYPE_1)!=-1){//无卡费率
			//快捷速惠
			InstitutionFee shFee= createInstitutionFee(insNo, Constants.INS_FEE_TYPE_7, null, institution.getShD0Fee(),null ,institution.getShFixation());
			feeList.add(shFee);
			//快捷
			InstitutionFee kjFee= createInstitutionFee(insNo, Constants.INS_FEE_TYPE_5, institution.getKjT1Fee(), institution.getKjD0Fee(), institution.getKjT1Fixation(),institution.getKjD0Fixation());
			feeList.add(kjFee);
			//b2c
			InstitutionFee b2cFee= createInstitutionFee(insNo, Constants.INS_FEE_TYPE_6, institution.getB2cT1Fee(), institution.getB2cD0Fee(), institution.getB2cT1Fixation(), institution.getB2cD0Fixation());
			feeList.add(b2cFee);
		}
		if(typeList.indexOf(Constants.INS_BUSINESS_TYPE_2)!=-1){//刷卡费率
			//秒到
			InstitutionFee mdFee= createInstitutionFee(insNo, Constants.INS_FEE_TYPE_8, institution.getMdDjFee(), institution.getMdJjFee(), institution.getMdFixFee(), institution.getMdJjFixFee());
			feeList.add(mdFee);  //秒到借记卡属于机构D0固定费率
			//即时
			InstitutionFee jsFee= createInstitutionFee(insNo, Constants.INS_FEE_TYPE_9, institution.getJsDjFee(), institution.getJsJjFee(), institution.getJsFixFee(), institution.getJsJjFixFee());
			feeList.add(jsFee); //即时借记卡属于机构D0固定费率
		}
		for (InstitutionFee institutionFee : feeList) {
			institutionFeeMapper.insertSelective(institutionFee);
			//保存历史记录
			institutionFeeHisMapper.insertByInstitutionFee(institutionFee.getInsFeeId());
		}
	}
	
	/**
	 * 创建机构费率
	 * @param InsNo:机构编号
	 * @param insFeeType：费率类型
	 * @param fee：T1费率
	 * @param D0Fee：D0费率
	 * @param fixFee：固定
	 * @return
	 */
	private InstitutionFee createInstitutionFee(String InsNo,String insFeeType,String fee,String D0Fee,BigDecimal fixFee,BigDecimal d0FixFee){
		InstitutionFee insFee = new InstitutionFee();
		insFee.setInsNo(InsNo);
		insFee.setInsFeeType(insFeeType);
		insFee.setFee(fee);
		insFee.setD0Fee(D0Fee);
		insFee.setFixFee(fixFee);
		insFee.setD0FixFee(d0FixFee);
		insFee.setCreateDate(new Date());
		insFee.setUpdateDate(new Date());
		insFee.setCreateUser(UserUtils.getUser().getId());
		insFee.setUpdateUser(UserUtils.getUser().getId());
		return insFee;
	}

    /**
     * 创建商户扫码费率区间
     * @param insNo:机构编号
     * @param cardType:费率类型
     * @param feeRange: T1费率区间
     * @param d0FeeRange: D0费率区间
     * @param fixFeeRange: T1固定值区间
     * @param d0FixFeeRange:D0固定值
     * @return
     */
	private CommissionRange createComFeeRange(String insNo,String cardType,String feeRange,String d0FeeRange,String fixFeeRange,String d0FixFeeRange){
	    CommissionRange comRange = new CommissionRange();
	    comRange.setInsNo(insNo);
	    comRange.setCardtype(cardType);
	    comRange.setCommissionRate(feeRange);
	    comRange.setD0CommissionRate(d0FeeRange);
	    comRange.setFixedRate(fixFeeRange);
	    comRange.setD0FixedRate(d0FixFeeRange);
	    return comRange;
    }

	/**
	 * 机构添加时，创建机构登录平台默认登录账号
	 * 登录名为：机构联系电话  初始登录密码为：123456
	 */
	private void createDefaultInsOperator(Institution institution) throws Exception{
		InsOperator insOperator = new InsOperator();
		Date now = new Date();
		String userId = UserUtils.getUser().getId();
		insOperator.setInsNo(new BigDecimal(institution.getInsNo()));//机构编号
		insOperator.setUsername(institution.getInsName());
		insOperator.setPassword(Constants.INS_OPERATOR_INIT_PASSWORD);//加密后的 123456
		insOperator.setLoginname(institution.getInsTel());//手机号
		insOperator.setInsRoleSeq(Constants.INS_OPERATOR_INIT_ROLE);//操作员角色  1   默认
		insOperator.setStatus(Constants.INS_OPERATOR_INIT_STATUS);//0 正常
		insOperator.setDefaultOperator(Constants.INS_OPERATOR_DEFAULT);
		insOperator.setRemark("机构注册时自动创建");
		insOperator.setCreateDate(now);
		insOperator.setCreateUser(userId);
		insOperator.setUpdateDate(now);
		insOperator.setUpdateUser(userId);
		insOperatorMapper.insertSelective(insOperator);
	}

	/**
	 * 保存商户扫码费率区间
	 */
	private void saveMerFeeRange(Institution institution,boolean update){
		String insNo = institution.getInsNo();
		if(update){
		    institutionFeeMapper.deleteByComRange(insNo);
        }
        String businessType = institution.getBusinessType();//业务类型
        List<CommissionRange> rangeList = new ArrayList<>();
        //是否设置扫码费率类型
        if(businessType.contains(Constants.INS_BUSINESS_TYPE_0)){
            String commissionType = institution.getCommissionType();
            List<String> comTypeList = Arrays.asList(commissionType.split(","));
            //微信二维码费率区间
            if(comTypeList.indexOf(Constants.INS_FEE_TYPE_2) != -1){
                String wxRange = institution.getWxRangeLow() + "," + institution.getWxRangeUpp();
                String wxD0Range = institution.getWxD0RangeLow() + "," + institution.getWxD0RangeUpp();
                String wxFixRange = institution.getWxFixRangeLow() + "," + institution.getWxFixRangeUpp();
                String wxD0FixRange = institution.getWxD0FixRangeLow() + "," + institution.getWxD0FixRangeUpp();
                CommissionRange comRange = createComFeeRange(insNo,Constants.INS_FEE_TYPE_2,wxRange,wxD0Range,wxFixRange,wxD0FixRange);
                rangeList.add(comRange);
            }
            //支付宝二维码费率区间
            if(comTypeList.indexOf(Constants.INS_FEE_TYPE_3) != -1){
                String zfbRange = institution.getZfbRangeLow() + "," + institution.getZfbRangeUpp();
                String zfbD0Range = institution.getZfbD0RangeLow() + "," + institution.getZfbD0RangeUpp();
                String zfbFixRange = institution.getZfbFixRangeLow() + "," + institution.getZfbFixRangeUpp();
                String zfbD0FixRange = institution.getZfbD0FixRangeLow() + "," + institution.getZfbD0FixRangeUpp();
                CommissionRange comRange = createComFeeRange(insNo,Constants.INS_FEE_TYPE_3,zfbRange,zfbD0Range,zfbFixRange,zfbD0FixRange);
                rangeList.add(comRange);
            }
            //支付宝APP费率区间
            if(comTypeList.indexOf(Constants.INS_FEE_TYPE_13) != -1){
                String zfbAppRange = institution.getZfbAppRangeLow() + "," + institution.getZfbAppRangeUpp();
                String zfbAppD0Range = institution.getZfbAppD0RangeLow() + "," + institution.getZfbAppD0RangeUpp();
                String zfbAppFixRange = institution.getZfbAppFixRangeLow() + "," + institution.getZfbAppFixRangeUpp();
                String zfbAppD0FixRange = institution.getZfbAppD0FixRangeLow() + "," + institution.getZfbAppD0FixRangeUpp();
                CommissionRange comRange = createComFeeRange(insNo,Constants.INS_FEE_TYPE_13,zfbAppRange,zfbAppD0Range,zfbAppFixRange,zfbAppD0FixRange);
                rangeList.add(comRange);
            }
            //支付宝H5费率区间
            if(comTypeList.indexOf(Constants.INS_FEE_TYPE_14) != -1){
                String zfbH5Range = institution.getZfbH5RangeLow() + "," + institution.getZfbH5RangeUpp();
                String zfbH5D0Range = institution.getZfbH5D0RangeLow() + "," + institution.getZfbH5D0RangeUpp();
                String zfbH5FixRange = institution.getZfbH5FixRangeLow() + "," + institution.getZfbH5FixRangeUpp();
                String zfbH5D0FixRange = institution.getZfbH5D0FixRangeLow() + "," + institution.getZfbH5D0FixRangeUpp();
                CommissionRange comRange = createComFeeRange(insNo,Constants.INS_FEE_TYPE_14,zfbH5Range,zfbH5D0Range,zfbH5FixRange,zfbH5D0FixRange);
                rangeList.add(comRange);
            }
            //微信APP费率区间
            if(comTypeList.indexOf(Constants.INS_FEE_TYPE_15) != -1){
                String wxAppRange = institution.getWxAppRangeLow() + "," + institution.getWxAppRangeUpp();
                String wxAppD0Range = institution.getWxAppD0RangeLow() + "," + institution.getWxAppD0RangeUpp();
                String wxAppFixRange = institution.getWxAppFixRangeLow() + "," + institution.getWxAppFixRangeUpp();
                String wxAppD0FixRange = institution.getWxAppD0FixRangeLow() + "," + institution.getWxAppD0FixRangeUpp();
                CommissionRange comRange = createComFeeRange(insNo,Constants.INS_FEE_TYPE_15,wxAppRange,wxAppD0Range,wxAppFixRange,wxAppD0FixRange);
                rangeList.add(comRange);
            }
            //微信公众号费率区间
            if(comTypeList.indexOf(Constants.INS_FEE_TYPE_16) != -1){
                String wxGzhRange = institution.getWxGzhRangeLow() + "," + institution.getWxGzhRangeUpp();
                String wxGzhD0Range = institution.getWxGzhD0RangeLow() + "," + institution.getWxGzhD0RangeUpp();
                String wxGzhFixRange = institution.getWxGzhFixRangeLow() + "," + institution.getWxGzhFixRangeUpp();
                String wxGzhD0FixRange = institution.getWxGzhD0FixRangeLow() + "," + institution.getWxGzhD0FixRangeUpp();
                CommissionRange comRange = createComFeeRange(insNo,Constants.INS_FEE_TYPE_16,wxGzhRange,wxGzhD0Range,wxGzhFixRange,wxGzhD0FixRange);
                rangeList.add(comRange);
            }
            //保存商户费率区间
            for(CommissionRange commissionRange : rangeList){
                institutionMapper.insertComRange(commissionRange);
            }
        }
	}

	/**
	 * 通过id查询机构信息
	 * @param insId
	 * @return
	 */
	public Institution findInstitutionById(Long insId) {
		return institutionMapper.selectByPrimaryKey(insId);
	}

    /**
     * 区分上下限
     */
    public Institution merRateRange(Institution institution){
        //区分商户费率区间上下限
        String mrr = institution.getMerRateRange();
        if(mrr != null){
            institution.setMerRateRange(mrr.substring(0,mrr.indexOf(",")));
            institution.setMerRateRangeUp(mrr.substring(mrr.indexOf(",") + 1));
        }
        return institution;
    }
	/**
	 * 创建唯一机构编号
	 * 100 330300 00 1111
	 * @return
	 */
	private String createInstitutionNo(String area) throws Exception{
		if(area.length()>6){
			area = area.substring(0,6);
		}
		String random = RandomStringUtils.randomNumeric(6);
		String InstitutionNo = Constants.INS_START_NO+area+random;
		if(institutionMapper.selectByInsNo(InstitutionNo)!=null){
			return createInstitutionNo(area);
		}
		return InstitutionNo;
	}

	/**
	 * 调用机构企业入驻接口
	 * @param institution
	 * @return
	 * @throws Exception
	 */
	private Institution registerInstitutionC(Institution institution) throws Exception{
		JSONObject result= new JSONObject();
		JSONObject param = new JSONObject();
		param.put("userType", Constants.REGISTER_INSTITUTION_USERTYPE_C);
		param.put("idNum", institution.getIdcardNo());
		param.put("bankNo", institution.getInsBankCardNo());
		param.put("bankCode", institution.getInsBankCode());
		param.put("bankName", institution.getInsSubBankName());
		param.put("prov", institution.getInsProvince());
		param.put("city", institution.getInsCity());
		param.put("register_corpTel", institution.getInsTel());
		param.put("register_prinName", institution.getInsBankClientName());
		param.put("register_corpFinanceName", institution.getInsBankClientName());
		param.put("linkman", institution.getInsBankClientName());
		param.put("register_corpLicenceNo", institution.getInsYnum());
		param.put("register_corpName", institution.getInsName());
		param.put("register_email", institution.getInsEmail());
		param.put("register_corpAccountLicenceNo", institution.getInsYnum());
		param.put("register_corpOrganizeNo", institution.getInsYnum());
		param.put("register_corpTaxId", institution.getInsYnum());
		param.put("register_corpAddr", institution.getInsAddress());
		param.put("register_corpZip", institution.getInsZip());

		String url = ParamPlatfrom.REGISTER_COMPANY_INSTITUTION_URL;
		try {
			logger.info("机构企业入驻接口请求参数：url="+url+"   param="+param);
			result = HttpRequestUtils.httpPost(url, param);
			logger.info("机构企业入驻接口返回：result="+result);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionEnum.调用机构入驻接口异常);
		}
		//respCode 网关code
		if(null == result || !Constants.RESULT_SUCCESS.equals(result.getString("rspCode"))){
			throw new BusinessException(ExceptionEnum.调用机构入驻接口返回失败);
		}
		String accountBankId =result.getString("accountBankId");//机构结算卡id
		String ysbUserId =result.getString("ysbUserId");//银生宝userid
		String userId = result.getString("userId");//托管账户id
		institution.setAccountBankId(Long.parseLong(accountBankId));
		institution.setYsbuserid(Long.parseLong(ysbUserId));
		institution.setCascustomid(Long.parseLong(userId));
		return institution;
	}

	/**
	 * 调用机构个人入驻接口
	 * @param institution
	 * @return
	 * @throws Exception 
	 */
	private Institution registerInstitutionP(Institution institution) throws Exception{
		JSONObject result= new JSONObject();
		JSONObject param = new JSONObject();
		param.put("name", institution.getInsBankClientName());//开户人名称，需三要素鉴权，name，idNum，mobilePhoneNum
		param.put("idNum", institution.getIdcardNo());
		param.put("mobilePhoneNum", institution.getInsTel());
		param.put("bankNo", institution.getInsBankCardNo());
		param.put("bankCode", institution.getInsBankCode());
		param.put("bankName", institution.getInsSubBankName());
		param.put("prov", institution.getInsProvince());
		param.put("city", institution.getInsCity());
		param.put("userType", Constants.REGISTER_INSTITUTION_USERTYPE_P);
		String url = ParamPlatfrom.REGISTER_INSTITUTION_URL;
		try {
			logger.info("机构入驻接口请求参数：url="+url+"   param="+param);
			result = HttpRequestUtils.httpPost(url, param);
			logger.info("机构入驻接口返回：result="+result);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionEnum.调用机构入驻接口异常);
		}
		//respCode 网关code
		if(null == result || !Constants.RESULT_SUCCESS.equals(result.getString("rspCode"))){
			throw new BusinessException(ExceptionEnum.调用机构入驻接口返回失败);
		}	
		String accountBankId =result.getString("accountBankId");//机构结算卡id
		String ysbUserId =result.getString("ysbUserId");//银生宝userid
		String userId = result.getString("userId");//托管账户id  
		institution.setAccountBankId(Long.parseLong(accountBankId));
		institution.setYsbuserid(Long.parseLong(ysbUserId));
		institution.setCascustomid(Long.parseLong(userId));
		return institution;
	}
	
	/**
	 * 调用机构个人信息修改接口
	 * @param institution
	 * @return
	 * @throws Exception 
	 */
	private Institution updateInstitutionP(Institution institution) throws Exception{
		JSONObject result= new JSONObject();
		JSONObject param = new JSONObject();
		param.put("accountBankId", institution.getAccountBankId());
		param.put("idNum", institution.getIdcardNo());
		param.put("bankNo", institution.getInsBankCardNo());
		param.put("bankCode", institution.getInsBankCode());
		param.put("bankName", institution.getInsSubBankName());
		param.put("prov", institution.getInsProvince());
		param.put("city", institution.getInsCity());
		String url = ParamPlatfrom.UPDATE_INSTITUTION_URL;
		try {
			logger.info("机构信息修改接口请求参数：url="+url+"   param="+param);
			result = HttpRequestUtils.httpPost(url, param);
			logger.info("机构信息修改接口返回：result="+result);
		} catch (Exception e) {
			logger.error("机构信息修改接口异常！",e);
			throw new BusinessException(ExceptionEnum.机构信息修改接口异常);
		}
		//respCode 网关code
		if(null == result || !Constants.RESULT_SUCCESS.equals(result.getString("respCode"))){
			throw new BusinessException(ExceptionEnum.机构信息修改接口返回失败);
		}
		String accountBankId =result.getString("accountBankId");//机构结算卡id
		institution.setAccountBankId(Long.parseLong(accountBankId));
		return institution;
	}

	/**
	 * 调用机构企业信息修改接口
	 * @param institution
	 * @return
	 * @throws Exception
	 */
	private Institution updateInstitutionC(Institution institution) throws Exception{
		JSONObject result= new JSONObject();
		JSONObject param = new JSONObject();
		param.put("accountBankId", institution.getAccountBankId());
		param.put("idNum", institution.getIdcardNo());
		param.put("bankNo", institution.getInsBankCardNo());
		param.put("bankCode", institution.getInsBankCode());
		param.put("bankName", institution.getInsSubBankName());
		param.put("prov", institution.getInsProvince());
		param.put("city", institution.getInsCity());
		String url = ParamPlatfrom.UPDATE_INSTITUTION_URL;
		try {
			logger.info("机构信息修改接口请求参数：url="+url+"   param="+param);
			result = HttpRequestUtils.httpPost(url, param);
			logger.info("机构信息修改接口返回：result="+result);
		} catch (Exception e) {
			logger.error("机构信息修改接口异常！",e);
			throw new BusinessException(ExceptionEnum.机构信息修改接口异常);
		}
		//respCode 网关code
		if(null == result || !Constants.RESULT_SUCCESS.equals(result.getString("respCode"))){
			throw new BusinessException(ExceptionEnum.机构信息修改接口返回失败);
		}
		String accountBankId =result.getString("accountBankId");//机构结算卡id
		institution.setAccountBankId(Long.parseLong(accountBankId));
		return institution;
	}
	
	/**
	 * 将机构费率封装到机构实体类里
	 * @param ins
	 * @param feeList
	 * @return
	 */
	public Institution setInstitutionFee(Institution ins,List<InstitutionFee> feeList){
		for (InstitutionFee fee : feeList) {
			if(Constants.INS_FEE_TYPE_3.equals(fee.getInsFeeType())){//支付宝费率
				ins.setZfbFee(fee.getFee());
                ins.setZfbD0Fee(fee.getD0Fee());
                ins.setZfbT1ixation(fee.getFixFee());
                ins.setZfbD0Fixation(fee.getD0FixFee());
            }else if(Constants.INS_FEE_TYPE_2.equals(fee.getInsFeeType())){//微信费率
				ins.setWxFee(fee.getFee());
				ins.setWxD0Fee(fee.getD0Fee());
				ins.setWxT1Fixation(fee.getFixFee());
				ins.setWxD0Fixation(fee.getD0FixFee());
			}else if(Constants.INS_FEE_TYPE_5.equals(fee.getInsFeeType())){//快捷
				ins.setKjT1Fee(fee.getFee());
				ins.setKjD0Fee(fee.getD0Fee());
				ins.setKjT1Fixation(fee.getFixFee());
				ins.setKjD0Fixation(fee.getD0FixFee());
			}else if(Constants.INS_FEE_TYPE_6.equals(fee.getInsFeeType())){//b2c
				ins.setB2cT1Fee(fee.getFee());
				ins.setB2cD0Fee(fee.getD0Fee());
				ins.setB2cT1Fixation(fee.getFixFee());
				ins.setB2cD0Fixation(fee.getD0FixFee());
			}else if(Constants.INS_FEE_TYPE_7.equals(fee.getInsFeeType())){//速惠
				ins.setShD0Fee(fee.getD0Fee());
				ins.setShFixation(fee.getD0FixFee());
			}else if(Constants.INS_FEE_TYPE_8.equals(fee.getInsFeeType())){//秒到
				ins.setMdDjFee(fee.getFee());//贷记卡
				ins.setMdJjFee(fee.getD0Fee());//借记卡
				ins.setMdFixFee(fee.getFixFee());//贷记卡固定
				ins.setMdJjFixFee(fee.getD0FixFee());//借记卡固定
			}else if(Constants.INS_FEE_TYPE_9.equals(fee.getInsFeeType())){//即时
				ins.setJsDjFee(fee.getFee());
				ins.setJsJjFee(fee.getD0Fee());
				ins.setJsFixFee(fee.getFixFee());
				ins.setJsJjFixFee(fee.getD0FixFee());//即时借记卡固定费率
			}else if(Constants.INS_FEE_TYPE_13.equals(fee.getInsFeeType())){ //支付宝App
                ins.setZfbAppFee(fee.getFee());
                ins.setZfbAppD0Fee(fee.getD0Fee());
                ins.setZfbAppT1ixation(fee.getFixFee());
                ins.setZfbAppD0Fixation(fee.getD0FixFee());
            }else if(Constants.INS_FEE_TYPE_14.equals(fee.getInsFeeType())){ //支付宝H5
                ins.setZfbH5Fee(fee.getFee());
                ins.setZfbH5D0Fee(fee.getD0Fee());
                ins.setZfbH5T1ixation(fee.getFixFee());
                ins.setZfbH5D0Fixation(fee.getD0FixFee());
            }else if(Constants.INS_FEE_TYPE_15.equals(fee.getInsFeeType())){ //微信APP
                ins.setWxAppFee(fee.getFee());
                ins.setWxAppD0Fee(fee.getD0Fee());
                ins.setWxAppT1Fixation(fee.getFixFee());
                ins.setWxAppD0Fixation(fee.getD0FixFee());
            }else if(Constants.INS_FEE_TYPE_16.equals(fee.getInsFeeType())){ //微信公众号
                ins.setWxGzhFee(fee.getFee());
                ins.setWxGzhD0Fee(fee.getD0Fee());
                ins.setWxGzhT1Fixation(fee.getFixFee());
                ins.setWxGzhD0Fixation(fee.getD0FixFee());
            }

		}
		return ins;
	}

	/**
	 * 费率历史修改记录分页
	 * @param page
	 * @param feeHis
	 * @return
	 */
	public Page<InstitutionFeeHis> findInstitutionFeeHisList(Page<InstitutionFeeHis> page, InstitutionFeeHis feeHis) {
		// 设置分页参数
		feeHis.setPage(page);
		// 执行分页查询
		page.setList(institutionFeeHisMapper.findFeeHisList(feeHis));
		return page;
	}

	/**
	 * 查询机构费率列表
	 * @param insNo
	 * @return
	 */
	public List<InstitutionFee> findInsFeeList(String insNo) {
	    List<InstitutionFee> institution = institutionFeeMapper.findInsFeeList(insNo);
		return institution;
	}

    /**
     * 设置费率类型显示
     * @return
     */
	public List<InstitutionFee> settleCommissionType(List<InstitutionFee> insFee,List<InsCommissionType> comTypes, String commissionType){
        String[] ct = commissionType.split(",");
        String[] notSmFee = Constants.NOT_SMFEE_TYPE.split(",");
	    for(int i = 0; i < insFee.size();i++){
	        String feeType = insFee.get(i).getInsFeeType();
	        //扫码费率未选中的不显示
            if(!Arrays.asList(ct).contains(feeType) && !Arrays.asList(notSmFee).contains(feeType)){
                insFee.remove(i);
                i--;
            }
        }
        for(int i = 0;i < comTypes.size(); i++){
	        String comRange = comTypes.get(i).getCardType();
	        if(!Arrays.asList(ct).contains(comRange)){
	            comTypes.remove(i);
	            i--;
            }
        }
	    return insFee;
    }

    /**
     * 查询商户扫码费率区间列表
     * @param insNo
     * @return
     */
    public List<InsCommissionType> findInsComType(String insNo){
	    List<InsCommissionType> insComType = institutionFeeMapper.findInsCommissionType(insNo);
	    return insComType;
    }

    /**
     * 商户扫码费率区间放入实体类
     * @return
     */
    public Institution splitInsComType(Institution ins,List<InsCommissionType> insComTypeList){
        for(InsCommissionType ict : insComTypeList){
            String[] comFeeRate = ict.getCommissionRate().split(",");
            String[] comD0FeeRate = ict.getD0CommissionRate().split(",");
            String[] comFixdRate = ict.getFixedRate().split(",");
            String[] comD0FixdRate = ict.getD0FixedRate().split(",");
            switch (ict.getCardType()){
                //微信二维码
                case Constants.INS_FEE_TYPE_2:
                    ins.setWxRangeLow(new BigDecimal(comFeeRate[0]));
                    ins.setWxRangeUpp(new BigDecimal(comFeeRate[1]));
                    ins.setWxD0RangeLow(new BigDecimal(comD0FeeRate[0]));
                    ins.setWxD0RangeUpp(new BigDecimal(comD0FeeRate[1]));
                    ins.setWxFixRangeLow(new BigDecimal(comFixdRate[0]));
                    ins.setWxFixRangeUpp(new BigDecimal(comFixdRate[1]));
                    ins.setWxD0FixRangeLow(new BigDecimal(comD0FixdRate[0]));
                    ins.setWxD0FixRangeUpp(new BigDecimal(comD0FixdRate[1]));
                    break;
                //支付宝二维码
                case Constants.INS_FEE_TYPE_3:
                    ins.setZfbRangeLow(new BigDecimal(comFeeRate[0]));
                    ins.setZfbRangeUpp(new BigDecimal(comFeeRate[1]));
                    ins.setZfbD0RangeLow(new BigDecimal(comD0FeeRate[0]));
                    ins.setZfbD0RangeUpp(new BigDecimal(comD0FeeRate[1]));
                    ins.setZfbFixRangeLow(new BigDecimal(comFixdRate[0]));
                    ins.setZfbFixRangeUpp(new BigDecimal(comFixdRate[1]));
                    ins.setZfbD0FixRangeLow(new BigDecimal(comD0FixdRate[0]));
                    ins.setZfbD0FixRangeUpp(new BigDecimal(comD0FixdRate[1]));
                    break;
                //支付宝App
                case Constants.INS_FEE_TYPE_13:
                    ins.setZfbAppRangeLow(new BigDecimal(comFeeRate[0]));
                    ins.setZfbAppRangeUpp(new BigDecimal(comFeeRate[1]));
                    ins.setZfbAppD0RangeLow(new BigDecimal(comD0FeeRate[0]));
                    ins.setZfbAppD0RangeUpp(new BigDecimal(comD0FeeRate[1]));
                    ins.setZfbAppFixRangeLow(new BigDecimal(comFixdRate[0]));
                    ins.setZfbAppFixRangeUpp(new BigDecimal(comFixdRate[1]));
                    ins.setZfbAppD0FixRangeLow(new BigDecimal(comD0FixdRate[0]));
                    ins.setZfbAppD0FixRangeUpp(new BigDecimal(comD0FixdRate[1]));
                    break;
                //支付宝H5
                case Constants.INS_FEE_TYPE_14:
                    ins.setZfbH5RangeLow(new BigDecimal(comFeeRate[0]));
                    ins.setZfbH5RangeUpp(new BigDecimal(comFeeRate[1]));
                    ins.setZfbH5D0RangeLow(new BigDecimal(comD0FeeRate[0]));
                    ins.setZfbH5D0RangeUpp(new BigDecimal(comD0FeeRate[1]));
                    ins.setZfbH5FixRangeLow(new BigDecimal(comFixdRate[0]));
                    ins.setZfbH5FixRangeUpp(new BigDecimal(comFixdRate[1]));
                    ins.setZfbH5D0FixRangeLow(new BigDecimal(comD0FixdRate[0]));
                    ins.setZfbH5D0FixRangeUpp(new BigDecimal(comD0FixdRate[1]));
                    break;
                //微信App
                case Constants.INS_FEE_TYPE_15:
                    ins.setWxAppRangeLow(new BigDecimal(comFeeRate[0]));
                    ins.setWxAppRangeUpp(new BigDecimal(comFeeRate[1]));
                    ins.setWxAppD0RangeLow(new BigDecimal(comD0FeeRate[0]));
                    ins.setWxAppD0RangeUpp(new BigDecimal(comD0FeeRate[1]));
                    ins.setWxAppFixRangeLow(new BigDecimal(comFixdRate[0]));
                    ins.setWxAppFixRangeUpp(new BigDecimal(comFixdRate[1]));
                    ins.setWxAppD0FixRangeLow(new BigDecimal(comD0FixdRate[0]));
                    ins.setWxAppD0FixRangeUpp(new BigDecimal(comD0FixdRate[1]));
                    break;
                //微信公众号
                case Constants.INS_FEE_TYPE_16:
                    ins.setWxGzhRangeLow(new BigDecimal(comFeeRate[0]));
                    ins.setWxGzhRangeUpp(new BigDecimal(comFeeRate[1]));
                    ins.setWxGzhD0RangeLow(new BigDecimal(comD0FeeRate[0]));
                    ins.setWxGzhD0RangeUpp(new BigDecimal(comD0FeeRate[1]));
                    ins.setWxGzhFixRangeLow(new BigDecimal(comFixdRate[0]));
                    ins.setWxGzhFixRangeUpp(new BigDecimal(comFixdRate[1]));
                    ins.setWxGzhD0FixRangeLow(new BigDecimal(comD0FixdRate[0]));
                    ins.setWxGzhD0FixRangeUpp(new BigDecimal(comD0FixdRate[1]));
                    break;
                default:
                    break;

            }
        }
        return ins;
    }

    /**
     * 查询商户费率区间
     * @return
     */
    public List<InsCommissionType> findComRange(String insNo){
        List<InsCommissionType> comTypeList =  institutionFeeMapper.findInsCommissionType(insNo);
        for(int i = 0;i<comTypeList.size();i++){
            comTypeList.get(i).setCommissionRate(comTypeList.get(i).getCommissionRate().replaceAll(",","%——"));
            comTypeList.get(i).setD0CommissionRate(comTypeList.get(i).getD0CommissionRate().replaceAll(",","%——"));
            comTypeList.get(i).setFixedRate(comTypeList.get(i).getFixedRate().replaceAll(",","——"));
            comTypeList.get(i).setD0FixedRate(comTypeList.get(i).getD0FixedRate().replaceAll(",","——"));
        }
        return comTypeList;
    }

	public List<Institution> findAllIns(){
		return institutionMapper.findAllIns();
	}

	public int getCountByInstel(String insTel) {
		return institutionMapper.getCountByInstel(insTel);
	}

    public List<Institution> findInstitutionByIdCardNo(String thisIdCardNo){
        return institutionMapper.findInstitutionByIdCardNo(thisIdCardNo);
    }
}
