package com.uns.organization.modules.sys.utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.uns.organization.common.utils.CacheUtils;
import com.uns.organization.common.utils.SpringContextHolder;
import com.uns.organization.common.utils.StringUtils;
import com.uns.organization.modules.organization.dao.SysAreaMapper;
import com.uns.organization.modules.organization.entity.SysArea;
import com.uns.organization.modules.sys.entity.User;

/**
 * 地区工具类
 * @author yang.cheng
 *
 */
public class SysAreaUtils {
	private static SysAreaMapper sysAreaMapper = SpringContextHolder.getBean(SysAreaMapper.class);
	
	public static final String SYS_AREA_PROV_MAP = "SYS_AREA_PROV_MAP";
	public static final String SYS_AREA_CITY_MAP = "SYS_AREA_CITY_MAP";
	
	@SuppressWarnings("unchecked")
	public static String getProvName(String provCode,String defualt){
		String provName =null;
		Map<String, String> provMap = (Map<String, String>) CacheUtils.get(SYS_AREA_PROV_MAP);
		if(provMap==null){
			provMap = new HashMap<String,String>();
			List<SysArea> allProvince = sysAreaMapper.findAllProvince();
			for (SysArea sysArea : allProvince) {
				provMap.put(sysArea.getYsbProv(), sysArea.getProvincialname());
			}
			CacheUtils.put(SYS_AREA_PROV_MAP, provMap);
			provName = provMap.get(provCode);
		}else{
			provName = provMap.get(provCode);
		}
		return StringUtils.isBlank(provName)?defualt:provName;
	}
	
	@SuppressWarnings("unchecked")
	public static String getCityName(String cityCode,String defualt){
		String cityName = null;
		Map<String, String> cityMap = (Map<String, String>) CacheUtils.get(SYS_AREA_CITY_MAP);
		if(cityMap==null){
			cityMap = new HashMap<String,String>();
			List<SysArea> allCity = sysAreaMapper.findAllCity();
			for (SysArea sysArea : allCity) {
				cityMap.put(sysArea.getYsbCity(), sysArea.getCityname());
			}
			CacheUtils.put(SYS_AREA_CITY_MAP, cityMap);
			cityName =  cityMap.get(cityCode);
		}else{
			cityName =  cityMap.get(cityCode);
		}
		return StringUtils.isBlank(cityName)?defualt:cityName;
	}
}
