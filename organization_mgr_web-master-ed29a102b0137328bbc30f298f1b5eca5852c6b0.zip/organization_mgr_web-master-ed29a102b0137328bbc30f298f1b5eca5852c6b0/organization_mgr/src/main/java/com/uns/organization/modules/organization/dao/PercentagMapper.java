package com.uns.organization.modules.organization.dao;

import java.util.List;
import java.util.Map;

import com.uns.organization.common.persistence.annotation.MyBatisDao;
import com.uns.organization.modules.organization.entity.Percentag;
import com.uns.organization.modules.organization.entity.PercentagTx;
@MyBatisDao
public interface PercentagMapper {
	List<Percentag> findPercentagList(Percentag percentag);

	List<PercentagTx> findPercentagTxList(PercentagTx percentagTx);

	String findSumAmount(Map<String,String> param);
}