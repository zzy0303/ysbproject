package com.uns.organization.modules.organization.web.form;

import java.util.Date;

import org.apache.commons.lang3.StringUtils;

import com.uns.organization.common.persistence.DataEntity;
import com.uns.organization.modules.organization.entity.ZhaoshangJoin;


public class ReportForm extends DataEntity<ZhaoshangJoin>{
	private Long zsjid;
	private String smallMerchantNo;
	private String name;
	private String insNo;
	private String insName;
	private String reportChannel;
	private String payType;
	private String auditStatus;
	private String createTimeStart;
	private String createTimeEnd;
	
	private String aliasName;
	private String address;
	private String lxrName;
	private String lxrType;
	private String idCardNo;
	private String phone;
	private String provinceCode;
	private String cityCode;
	private String districtCode;
	private String aliCategoryId;
	private String wxCategoryId;
	private String servicePhone;
	private String wxAppId;
	private String wxAppSecret;
	
	public String getSmallMerchantNo() {
		return smallMerchantNo;
	}
	public void setSmallMerchantNo(String smallMerchantNo) {
		this.smallMerchantNo = StringUtils.trim(smallMerchantNo);
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = StringUtils.trim(name);
	}
	public String getInsNo() {
		return insNo;
	}
	public void setInsNo(String insNo) {
		this.insNo = insNo;
	}
	public String getReportChannel() {
		return reportChannel;
	}
	public void setReportChannel(String reportChannel) {
		this.reportChannel = reportChannel;
	}
	public String getPayType() {
		return payType;
	}
	public void setPayType(String payType) {
		this.payType = payType;
	}
	public String getAuditStatus() {
		return auditStatus;
	}
	public void setAuditStatus(String auditStatus) {
		this.auditStatus = auditStatus;
	}
	public String getCreateTimeStart() {
		return createTimeStart;
	}
	public void setCreateTimeStart(String createTimeStart) {
		this.createTimeStart = createTimeStart;
	}
	public String getCreateTimeEnd() {
		return createTimeEnd;
	}
	public void setCreateTimeEnd(String createTimeEnd) {
		this.createTimeEnd = createTimeEnd;
	}
	public Long getZsjid() {
		return zsjid;
	}
	public void setZsjid(Long zsjid) {
		this.zsjid = zsjid;
	}
	public String getInsName() {
		return insName;
	}
	public void setInsName(String insName) {
		this.insName = insName;
	}
	public String getAliasName() {
		return aliasName;
	}
	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getLxrName() {
		return lxrName;
	}
	public void setLxrName(String lxrName) {
		this.lxrName = lxrName;
	}
	public String getLxrType() {
		return lxrType;
	}
	public void setLxrType(String lxrType) {
		this.lxrType = lxrType;
	}
	public String getIdCardNo() {
		return idCardNo;
	}
	public void setIdCardNo(String idCardNo) {
		this.idCardNo = idCardNo;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getProvinceCode() {
		return provinceCode;
	}
	public void setProvinceCode(String provinceCode) {
		this.provinceCode = provinceCode;
	}
	public String getCityCode() {
		return cityCode;
	}
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}
	public String getDistrictCode() {
		return districtCode;
	}
	public void setDistrictCode(String districtCode) {
		this.districtCode = districtCode;
	}
	public String getAliCategoryId() {
		return aliCategoryId;
	}
	public void setAliCategoryId(String aliCategoryId) {
		this.aliCategoryId = aliCategoryId;
	}
	public String getWxCategoryId() {
		return wxCategoryId;
	}
	public void setWxCategoryId(String wxCategoryId) {
		this.wxCategoryId = wxCategoryId;
	}
	public String getServicePhone() {
		return servicePhone;
	}
	public void setServicePhone(String servicePhone) {
		this.servicePhone = servicePhone;
	}
	public String getWxAppId() {
		return wxAppId;
	}
	public void setWxAppId(String wxAppId) {
		this.wxAppId = wxAppId;
	}
	public String getWxAppSecret() {
		return wxAppSecret;
	}
	public void setWxAppSecret(String wxAppSecret) {
		this.wxAppSecret = wxAppSecret;
	}
	
}
