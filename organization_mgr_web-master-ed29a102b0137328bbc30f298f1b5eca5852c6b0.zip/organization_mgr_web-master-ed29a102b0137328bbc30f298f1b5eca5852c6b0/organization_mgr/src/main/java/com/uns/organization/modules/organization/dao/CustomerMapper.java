package com.uns.organization.modules.organization.dao;

import java.util.List;

import com.uns.organization.common.persistence.annotation.MyBatisDao;
import com.uns.organization.modules.organization.entity.Customer;
import com.uns.organization.modules.organization.entity.CustomerHis;
import com.uns.organization.modules.organization.web.form.CustomerForm;
import com.uns.organization.modules.organization.web.form.ReportForm;
@MyBatisDao
public interface CustomerMapper {


    int deleteByPrimaryKey(Long customerid);

    int insert(Customer record);

    int insertSelective(Customer record);

    Customer selectByPrimaryKey(Long customerid);

    int updateByPrimaryKeySelective(Customer record);

    int updateByPrimaryKey(Customer record);
    
    List findCustomerList(CustomerForm customer);
    
    Customer findCustomerDetails(CustomerForm customer);
    
    List findCheckCustomerList(CustomerForm customerForm);
    
    void updateCheckstatusBySmallMerchNo(Customer customer);
    
}