package com.uns.organization.modules.sys.security;


import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;



/**
 * @Author: KaiFeng
 * @Description: 单点登录系统安全认证实现类
 * @Date: 2018/4/16
 * @Modifyed By:
 */
@Service
public class SsoAuthorizingRealm extends SystemAuthorizingRealm{

    private Logger logger = LoggerFactory.getLogger(getClass());

    /**
     * 重写token校验方法  跳过密码校验
     * @param token
     * @param info
     * @throws AuthenticationException
     */
    protected void assertCredentialsMatch(AuthenticationToken token, AuthenticationInfo info) throws AuthenticationException {
        logger.info("sso登录,跳过密码校验");
    }
}
