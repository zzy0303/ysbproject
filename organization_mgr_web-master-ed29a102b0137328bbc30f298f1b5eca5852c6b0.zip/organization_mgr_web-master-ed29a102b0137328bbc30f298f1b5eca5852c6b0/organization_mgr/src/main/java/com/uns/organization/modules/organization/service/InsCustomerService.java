package com.uns.organization.modules.organization.service;

import java.math.BigDecimal;
import java.util.List;

import com.uns.organization.modules.organization.dao.*;
import com.uns.organization.modules.organization.entity.*;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.organization.common.persistence.Page;
import com.uns.organization.common.service.BaseService;
import com.uns.organization.modules.organization.web.form.CustomerForm;
import com.uns.organization.modules.organization.web.form.ReportForm;


@Service
public class InsCustomerService extends BaseService{

	@Autowired
	CustomerMapper customerMapper;
	
	@Autowired
	CommissionpolicyHisMapper commissionpolicyHisMapper;

	@Autowired
	CommissionpolicyMapper commissionpolicyMapper;
	
	@Autowired
	CustomerHisMapper customerHisMapper;

	@Autowired
	MposPhotoTmpMapper mposPhotoTmpMapper;
	/**
	 * 查询商户列表
	 * @param page
	 * @param customerForm
	 * @return
	 */
	public Page<Customer> findCustomerList(Page<Customer> page, CustomerForm customerForm) {
		customerForm.getSqlMap().put("dsf", dataScopeFilter(customerForm.getCurrentUser(), "o", "a"));
		// 设置分页参数
		customerForm.setPage(page);
		// 执行分页查询
		page.setList(customerMapper.findCustomerList(customerForm));
		return page;
	}

	
	/**
	 * 查询商户详情
	 * @param page
	 * @param customerForm
	 * @return
	 */
	public Customer findCustomerDetails(CustomerForm customerForm){
		return customerMapper.findCustomerDetails(customerForm);
	}
	
	
	
	/**
	 * 查询商户费率
	 * @param commissionpolicytmp
	 * @return
	 */
	public List findCommissionpolicy(Long thisCustomerId){
		return commissionpolicyMapper.findCommissionpolicy(thisCustomerId);
	}
	
	/**
	 * 查询审核商户列表
	 * @param customerForm
	 * @return
	 */
	public Page<Customer> findCheckCustomerList(Page<Customer> page, CustomerForm customerForm){
		customerForm.getSqlMap().put("dsf", dataScopeFilter(customerForm.getCurrentUser(), "o", "a"));
		// 设置分页参数
		customerForm.setPage(page);
		// 执行分页查询
		page.setList(customerMapper.findCheckCustomerList(customerForm));
		return page;
	}
	
	/**
	 * 通过不定数据更新customer
	 */
	public void updateByPrimaryKeySelective(Customer customerTmp){
		customerMapper.updateByPrimaryKeySelective(customerTmp);
	}
	
	
	/**
	 * 通过customerid查询customerhis(带decode)
	 * @param customerid
	 * @return
	 */
	public CustomerHis findCustomerHisById(Long customerid){
		return customerHisMapper.findCustomerHisDetails(customerid);
	}
	
	/**
	 * 通过商户号更新数据
	 */
	public void updateCheckstatusBySmallMerchNo(Customer customer){
		customerMapper.updateCheckstatusBySmallMerchNo(customer);
	}

	public MposPhotoTmp findInsPhoto(Long photoId) {
		return mposPhotoTmpMapper.selectByPrimaryKey(new BigDecimal(photoId));
	}
}
