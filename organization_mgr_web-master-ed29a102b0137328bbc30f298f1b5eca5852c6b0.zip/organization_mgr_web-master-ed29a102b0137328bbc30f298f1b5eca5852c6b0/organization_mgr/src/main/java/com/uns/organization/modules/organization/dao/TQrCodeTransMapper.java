package com.uns.organization.modules.organization.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.uns.organization.common.persistence.annotation.MyBatisDao;
import com.uns.organization.modules.organization.entity.TQrCodeTrans;
import com.uns.organization.modules.organization.entity.TQrCodeTransWithdrawExcel;
import com.uns.organization.modules.organization.web.form.TransForm;
import com.uns.organization.modules.organization.web.form.TransFormForExcelWithdraw;
@MyBatisDao
public interface TQrCodeTransMapper {


    int deleteByPrimaryKey(Long id);

    int insert(TQrCodeTrans record);

    int insertSelective(TQrCodeTrans record);

    TQrCodeTrans selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TQrCodeTrans record);

    int updateByPrimaryKey(TQrCodeTrans record);
    
    List findTransList(TransForm transForm);
    
    List findExcelTransList(TransForm transForm);
    
    TQrCodeTrans findTransDetails(TransForm transForm);
    
    List findWithdrawList(TransForm transForm);
    
    TQrCodeTrans findWithdrawDetails(TransForm transForm);
    
    List findExcelWithdrawList(TransFormForExcelWithdraw transFormForExcelWithdraw);

    List<TQrCodeTrans> findT1WithdrawList(TransForm transForm);

    List<TQrCodeTransWithdrawExcel> findExcelT1WithdrawList(TransFormForExcelWithdraw transFormForExcelWithdraw);

    Map<String,Object> findSumAmountList(TransForm transForm);

    String findArrivalAmount(TransForm transForm);

    Map<String,Object> findT1SumAmount(TransForm transForm);

    Map<String,Object> findD0SumAmount(TransForm transForm);

}