package com.uns.organization.common.utils;

import com.uns.inf.acms.client.DynamicConfigLoader;

/**
 * 参数平台调用类，所有引用参数平台数据在此定义
 * @author yang.cheng
 *
 */
public class ParamPlatfrom {
	/**
	 * 机构个人入驻接口
	 */
	public static final String REGISTER_INSTITUTION_URL= DynamicConfigLoader.getByEnv("REGISTER_INSTITUTION_URL");
	/**
	 * 机构企业入驻接口
	 */
	public static final String REGISTER_COMPANY_INSTITUTION_URL= DynamicConfigLoader.getByEnv("REGISTER_COMPANY_INSTITUTION_URL");

	/**
	 * 机构修改接口
	 */
	public static final String UPDATE_INSTITUTION_URL=DynamicConfigLoader.getByEnv("UPDATE_INSTITUTION_URL");
	
	/**
	 * 商户创建接口
	 */
	public static final String REGISTER_CUSTOMER_URL = DynamicConfigLoader.getByEnv("REGISTER_CUSTOMER_URL");
	
	/**
	 * 银行入驻接口
	 */
	public static final String BANK_JOIN_URL = DynamicConfigLoader.getByEnv("BANK_JOIN_URL");
	
	/**
	 * 银行异步通知url
	 */
	public static final String CMB_JOIN_ASYN_RESPONSE_URL = DynamicConfigLoader.getByEnv("CMB_JOIN_ASYN_RESPONSE_URL");
}
