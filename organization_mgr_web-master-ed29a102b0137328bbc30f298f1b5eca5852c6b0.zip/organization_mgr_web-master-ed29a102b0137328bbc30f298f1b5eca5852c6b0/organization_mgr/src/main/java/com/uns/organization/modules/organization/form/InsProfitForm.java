package com.uns.organization.modules.organization.form;

import com.uns.organization.common.persistence.DataEntity;

import java.math.BigDecimal;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/11/22
 * @Modifyed By:
 */
public class InsProfitForm extends DataEntity<InsProfitForm> {
    private String ids;
    private String insNo;
    private String insName;
    private String batchNo;
    private String beginDate;
    private String endDate;
    private String status;
    private Integer sumCount;
    private BigDecimal sumAmount;
    private BigDecimal sumProfit;
    private String wxT1Fee;
    private String wxD0Fee;
    private String zfbT1Fee;
    private String zfbD0Fee;

    public String getIds() {
        return ids;
    }

    public void setIds(String ids) {
        this.ids = ids;
    }

    public String getInsNo() {
        return insNo;
    }

    public void setInsNo(String insNo) {
        this.insNo = insNo;
    }

    public String getInsName() {
        return insName;
    }

    public void setInsName(String insName) {
        this.insName = insName;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public String getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(String beginDate) {
        this.beginDate = beginDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getSumCount() {
        return sumCount;
    }

    public void setSumCount(Integer sumCount) {
        this.sumCount = sumCount;
    }

    public BigDecimal getSumAmount() {
        return sumAmount;
    }

    public void setSumAmount(BigDecimal sumAmount) {
        this.sumAmount = sumAmount;
    }

    public BigDecimal getSumProfit() {
        return sumProfit;
    }

    public void setSumProfit(BigDecimal sumProfit) {
        this.sumProfit = sumProfit;
    }

    public String getWxT1Fee() {
        return wxT1Fee;
    }

    public void setWxT1Fee(String wxT1Fee) {
        this.wxT1Fee = wxT1Fee;
    }

    public String getWxD0Fee() {
        return wxD0Fee;
    }

    public void setWxD0Fee(String wxD0Fee) {
        this.wxD0Fee = wxD0Fee;
    }

    public String getZfbT1Fee() {
        return zfbT1Fee;
    }

    public void setZfbT1Fee(String zfbT1Fee) {
        this.zfbT1Fee = zfbT1Fee;
    }

    public String getZfbD0Fee() {
        return zfbD0Fee;
    }

    public void setZfbD0Fee(String zfbD0Fee) {
        this.zfbD0Fee = zfbD0Fee;
    }
}
