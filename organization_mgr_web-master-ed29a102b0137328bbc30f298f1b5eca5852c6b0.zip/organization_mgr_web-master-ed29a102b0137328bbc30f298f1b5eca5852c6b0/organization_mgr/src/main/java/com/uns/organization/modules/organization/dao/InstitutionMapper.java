package com.uns.organization.modules.organization.dao;

import java.util.List;

import com.uns.organization.common.persistence.annotation.MyBatisDao;
import com.uns.organization.modules.organization.entity.CommissionRange;
import com.uns.organization.modules.organization.entity.Institution;
@MyBatisDao
public interface InstitutionMapper {
	
	Institution selectByPrimaryKey(Long insId);
	
	Institution selectByInsNo(String insNo);

    int insert(Institution record);

    int insertSelective(Institution record);

    int updateByPrimaryKey(Institution record);
    
    int updateByPrimaryKeySelective(Institution record);

	List<Institution> findInstitutionList(Institution institution);
	
	List<Institution> findAllIns();

	int getCountByInstel(String insTel);

    List<Institution> findInstitutionByIdCardNo(String thisIdCardNo);

    void insertComRange(CommissionRange record);
}