package com.uns.organization.modules.organization.entity;

import java.math.BigDecimal;
import java.util.Date;

import com.uns.organization.common.persistence.DataEntity;

public class InsOperator extends DataEntity<InsOperator>{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private BigDecimal operatorId;

	private BigDecimal insNo;

    private String username;

    private String password;

    private String loginname;

    private String insRoleSeq;

    private String status;

    private String remark;

    private Date createDate;

    private String createUser;

    private Date updateDate;

    private String updateUser;

    private Date lastLoginDate;
    
    private String defaultOperator;//1 为机构默认操作员
    
    private String createDateStart;
    private String createDateEnd;
    
    private String insTel;
    
    private String businessSwitch;
    
    private String insName;

	public String getDefaultOperator() {
		return defaultOperator;
	}

	public void setDefaultOperator(String defaultOperator) {
		this.defaultOperator = defaultOperator;
	}

	public String getCreateDateStart() {
		return createDateStart;
	}

	public void setCreateDateStart(String createDateStart) {
		this.createDateStart = createDateStart;
	}

	public String getCreateDateEnd() {
		return createDateEnd;
	}

	public void setCreateDateEnd(String createDateEnd) {
		this.createDateEnd = createDateEnd;
	}

	public String getInsTel() {
		return insTel;
	}

	public void setInsTel(String insTel) {
		this.insTel = insTel;
	}

	public String getBusinessSwitch() {
		return businessSwitch;
	}

	public void setBusinessSwitch(String businessSwitch) {
		this.businessSwitch = businessSwitch;
	}

	public String getInsName() {
		return insName;
	}

	public void setInsName(String insName) {
		this.insName = insName;
	}

	public BigDecimal getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(BigDecimal operatorId) {
		this.operatorId = operatorId;
	}

	public BigDecimal getInsNo() {
        return insNo;
    }

    public void setInsNo(BigDecimal insNo) {
        this.insNo = insNo;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username == null ? null : username.trim();
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }

    public String getLoginname() {
        return loginname;
    }

    public void setLoginname(String loginname) {
        this.loginname = loginname == null ? null : loginname.trim();
    }

    public String getInsRoleSeq() {
        return insRoleSeq;
    }

    public void setInsRoleSeq(String insRoleSeq) {
        this.insRoleSeq = insRoleSeq == null ? null : insRoleSeq.trim();
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser == null ? null : createUser.trim();
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser == null ? null : updateUser.trim();
    }

    public Date getLastLoginDate() {
        return lastLoginDate;
    }

    public void setLastLoginDate(Date lastLoginDate) {
        this.lastLoginDate = lastLoginDate;
    }
}