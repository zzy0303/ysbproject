package com.uns.organization.modules.organization.dao;

import java.math.BigDecimal;
import java.util.List;

import com.uns.organization.common.persistence.annotation.MyBatisDao;
import com.uns.organization.modules.organization.entity.InsOperator;
import com.uns.organization.modules.organization.entity.InsRoleInfo;
@MyBatisDao
public interface InsOperatorMapper {
	
    int deleteByPrimaryKey(BigDecimal id);

    int insert(InsOperator record);

    int insertSelective(InsOperator record);

    InsOperator selectByPrimaryKey(BigDecimal id);

    int updateByPrimaryKeySelective(InsOperator record);

    int updateByPrimaryKey(InsOperator record);

	List<InsOperator> findInsOperatorList(InsOperator insOperator);
	
	InsOperator findInsOperatorByOperatorId(BigDecimal operatorId);
	
	List<InsRoleInfo>findAllInsRole();
}