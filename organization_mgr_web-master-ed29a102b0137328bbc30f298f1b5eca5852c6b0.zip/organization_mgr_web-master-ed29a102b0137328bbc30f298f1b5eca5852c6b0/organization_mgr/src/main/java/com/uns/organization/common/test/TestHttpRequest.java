package com.uns.organization.common.test;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.RandomStringUtils;

import com.uns.organization.common.utils.DateUtils;
import com.uns.organization.common.utils.HttpRequestUtils;

import net.sf.json.JSONObject;

public class TestHttpRequest {


	public void test() throws Exception{
		//{"orderId":"20171121133156153912395","orderTime":"20171121133156","name":"车市商户002","idNum":"421181198912017032",
		//"mobilePhoneNum":"15618385407","bankNo":"6228480404312727316","bankCode":"6228480404312727316","bankName":"农业银行",
		//"prov":"310000","city":"310100","userType":"P"}
		String url ="http://172.22.200.104:8080/insQrcode/proxy/registerInstitution";
		JSONObject param = new JSONObject();
		/*param.put("orderId", DateUtils.getDateDetail() +RandomStringUtils.randomNumeric(6));
		param.put("orderTime", DateUtils.getTimeStamp());*/
		param.put("name", "车市商户003");
		param.put("idNum", "421181198912017031");
		param.put("mobilePhoneNum", "15618385406");
		param.put("bankNo", "6228480404312727315");
		param.put("bankCode", "6228480404312727315");
		param.put("bankName", "农业银行");
		param.put("prov", "310000");
		param.put("city", "310100");
		param.put("userType", "P");
		
		JSONObject result = HttpRequestUtils.httpPost(url, param);
		System.out.println(result);
	}
	
	public void testUpdate() throws Exception{
		
		String url ="http://172.22.200.104:8080/insQrcode/proxy/updateInstitution";
		JSONObject param = new JSONObject();
		param.put("accountBankId", "82535");
		param.put("idNum", "360423199405222213");
		param.put("bankNo", "6228480404316727313");
		param.put("bankCode", "2");
		param.put("bankName", "中国农业银行北京宏福分理处");
		param.put("prov", "10");
		param.put("city", "1010");
		JSONObject result = HttpRequestUtils.httpPost(url, param);
		System.out.println(result);
	}
	
	
	public static void main(String[] args) throws Exception {
		/*String str = "20171119010000";
		String reg = "(\\d{4})(\\d{2})(\\d{2})(\\d{2})(\\d{2})(\\d{2})";
		str = str.replaceAll(reg, "$1-$2-$3 $4:$5:$6");
		System.out.println(str);*/
		
		
		String url ="http://172.22.200.104:8080/insQrcode/proxy/registerInstitution";
		JSONObject param = new JSONObject();
		/*param.put("orderId", DateUtils.getDateDetail() +RandomStringUtils.randomNumeric(6));
		param.put("orderTime", DateUtils.getTimeStamp());*/
		param.put("name", "测试2");
		param.put("idNum", "360423199405222210");
		param.put("mobilePhoneNum", "15921309900");
		param.put("bankNo", "6228480404316727310");
		param.put("bankCode", "2");
		param.put("bankName", "中国农业银行北京宏福分理处");
		param.put("prov", "10");
		param.put("city", "1010");
		param.put("userType", "P");
		System.out.println("param:"+param);
		JSONObject result = HttpRequestUtils.httpPost(url, param);
		System.out.println(result);
	}
	
	public void testDateUtils() throws ParseException{
		/*String str = "	20171119010000";
		SimpleDateFormat sdf =new SimpleDateFormat("yyyyMMddHHmmss");
		//Date date = sdf.parse(str);
		sdf.format(new Date());
		
		System.out.println(sdf.format(new Date()));
		*/
		
		/*String str ="20171119010000";
		String reg = "(\\d{4})(\\d{2})(\\d{2})(\\d{2})(\\d{2})(\\d{2})";
		date = date.replaceAll(reg, "$1-$2-$3 $4:$5:$6");*/
		String str = "20151101095440";
		String reg = "(\\d{4})(\\d{2})(\\d{2})(\\d{2})(\\d{2})(\\d{2})";
		str = str.replaceAll(reg, "$1-$2-$3 $4:$5:$6");
		System.out.println(str);
	}
}
