package com.uns.organization.modules.organization.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.organization.common.persistence.Page;
import com.uns.organization.common.service.BaseService;
import com.uns.organization.modules.organization.dao.TQrCodeTransMapper;
import com.uns.organization.modules.organization.entity.TQrCodeTrans;
import com.uns.organization.modules.organization.entity.TQrCodeTransWithdrawExcel;
import com.uns.organization.modules.organization.web.form.TransForm;
import com.uns.organization.modules.organization.web.form.TransFormForExcelWithdraw;


@Service
public class InsTransService  extends BaseService{
	@Autowired
	TQrCodeTransMapper tQrCodeTransMapper;
	
	/**
	 * 查询充值交易列表
	 * @param transForm
	 * @param page
	 * @return
	 */
	public Page<TQrCodeTrans> findTransList(TransForm transForm, Page<TQrCodeTrans> page){
		transForm.getSqlMap().put("dsf", dataScopeFilter(transForm.getCurrentUser(), "o", "a"));
		// 设置分页参数
		transForm.setPage(page);
		// 执行分页查询
		page.setList(tQrCodeTransMapper.findTransList(transForm));
		return page;
	}

    /**
     * 统计汇总金额、笔数
     * @param transForm
     * @return
     */
	public Map<String,Object> findSumAmount(TransForm transForm){
        Map<String,Object> countMap = new HashMap<>();
        //充值总金额 总笔数
        Map<String,Object> sumMap = tQrCodeTransMapper.findSumAmountList(transForm);
        //扣除总金额
        String minusAmount = tQrCodeTransMapper.findArrivalAmount(transForm);
        if(sumMap.get("SUMAMOUNT") != null){
			countMap.put("sumAmount",new BigDecimal(sumMap.get("SUMAMOUNT").toString()));
		}
		if(minusAmount != null){
			countMap.put("minusAmount",new BigDecimal(minusAmount));
		}
		countMap.put("sCount",sumMap.get("SCOUNT"));
	    return countMap;
    }
	/**
	 * 查询导出excel交易列表
	 * @param transForm
	 * @param page
	 * @return
	 */
	public Page<TQrCodeTrans> findExecelTransList(TransForm transForm, Page<TQrCodeTrans> page){
		transForm.getSqlMap().put("dsf", dataScopeFilter(transForm.getCurrentUser(), "o", "a"));
		// 设置分页参数
		transForm.setPage(page);
		// 执行分页查询
		page.setList(tQrCodeTransMapper.findExcelTransList(transForm));
		return page;
	}
	
	public TQrCodeTrans findTransDetails(TransForm transForm){
		return tQrCodeTransMapper.findTransDetails(transForm);
	}
	
	public Page<TQrCodeTrans> findWithdrawList(TransForm transForm, Page<TQrCodeTrans> page){
		transForm.getSqlMap().put("dsf", dataScopeFilter(transForm.getCurrentUser(), "o", "a"));
		// 设置分页参数
		transForm.setPage(page);
		// 执行分页查询
		page.setList(tQrCodeTransMapper.findWithdrawList(transForm));
		return page;
	}
	
	public TQrCodeTrans findWithdrawDetails(TransForm transForm){
		return tQrCodeTransMapper.findWithdrawDetails(transForm);
	}
	
	
	public Page<TQrCodeTransWithdrawExcel> findExecelWithdrawList(TransFormForExcelWithdraw transFormForExcelWithdraw, Page<TQrCodeTransWithdrawExcel> page){
		transFormForExcelWithdraw.getSqlMap().put("dsf", dataScopeFilter(transFormForExcelWithdraw.getCurrentUser(), "o", "a"));
		// 设置分页参数
		transFormForExcelWithdraw.setPage(page);
		// 执行分页查询
		page.setList(tQrCodeTransMapper.findExcelWithdrawList(transFormForExcelWithdraw));
		return page;
	}
	public Page<TQrCodeTrans> findT1WithdrawList(TransForm transForm, Page<TQrCodeTrans> tQrCodeTransPage) {
		transForm.setPage(tQrCodeTransPage);
		tQrCodeTransPage.setList(tQrCodeTransMapper.findT1WithdrawList(transForm));
		return tQrCodeTransPage;
	}

    /**
     * T1提现记录汇总金额、笔数
     * @return
     */
	public Map<String,Object> findT1WithdSumAmount(TransForm transForm){
        Map<String,Object> sumAmount = tQrCodeTransMapper.findT1SumAmount(transForm);
	    return sumAmount;
    }

    /**
     * D0提现记录汇总
     * @param transForm
     * @return
     */
    public Map<String,Object> findD0WithdSumAmount(TransForm transForm){
        Map<String,Object> sumAmount = tQrCodeTransMapper.findD0SumAmount(transForm);
        return sumAmount;
    }
	public TQrCodeTrans findT1WithdrawDetails(TransForm transForm) {
		return tQrCodeTransMapper.findWithdrawDetails(transForm);
	}

	public Page<TQrCodeTransWithdrawExcel> findExecelT1WithdrawList(TransFormForExcelWithdraw transFormForExcelWithdraw, Page<TQrCodeTransWithdrawExcel> tQrCodeTransWithdrawExcelPage) {
		// 设置分页参数
		transFormForExcelWithdraw.setPage(tQrCodeTransWithdrawExcelPage);
		// 执行分页查询
		tQrCodeTransWithdrawExcelPage.setList(tQrCodeTransMapper.findExcelT1WithdrawList(transFormForExcelWithdraw));
		return tQrCodeTransWithdrawExcelPage;
	}
}
