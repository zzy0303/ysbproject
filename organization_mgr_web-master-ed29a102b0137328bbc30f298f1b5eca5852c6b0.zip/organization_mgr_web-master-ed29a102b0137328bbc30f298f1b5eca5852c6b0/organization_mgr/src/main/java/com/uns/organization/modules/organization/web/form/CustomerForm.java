package com.uns.organization.modules.organization.web.form;


import java.util.Date;

import com.uns.organization.common.persistence.DataEntity;
import com.uns.organization.common.utils.StringUtils;
import com.uns.organization.modules.organization.entity.Customer;


public class CustomerForm  extends DataEntity<Customer>{
	private String customerid;
	private String smallMerchNo;//商户编号
	private String insNo;//机构编号
	private String scompany;//商户名称
	private String insName;//所属机构名称
	private String status;//商户状态
	private String province;//省
	private String city;//市
	private String checkstatus;//审核状态
	private String industryType;//行业类型
	
	//审核
	private String createdateStart;//创建时间下限
	private String createdateEnd;//创建时间上限
	private String reasonOfNotPass;//不通过原因
	private String checkflag;//跳转页面用
	
	private String ysbProv;
	private String ysbCity;
	
	public String getCheckflag() {
		return checkflag;
	}
	public void setCheckflag(String checkflag) {
		this.checkflag = checkflag;
	}
	public String getReasonOfNotPass() {
		return reasonOfNotPass;
	}
	public void setReasonOfNotPass(String reasonOfNotPass) {
		this.reasonOfNotPass = reasonOfNotPass;
	}
	public String getCreatedateStart() {
		return createdateStart;
	}
	public void setCreatedateStart(String createdateStart) {
		this.createdateStart = createdateStart;
	}
	public String getCreatedateEnd() {
		return createdateEnd;
	}
	public void setCreatedateEnd(String createdateEnd) {
		this.createdateEnd = createdateEnd;
	}
	
	public String getSmallMerchNo() {
		return smallMerchNo;
	}
	public String getCustomerid() {
		return customerid;
	}
	public void setCustomerid(String customerid) {
		this.customerid = customerid;
	}
	public void setSmallMerchNo(String smallMerchNo) {
		this.smallMerchNo = StringUtils.trim(smallMerchNo);
	}
	public String getInsNo() {
		return insNo;
	}
	public void setInsNo(String insNo) {
		this.insNo = StringUtils.trim(insNo);
	}
	public String getScompany() {
		return scompany;
	}
	public void setScompany(String scompany) {
		this.scompany = StringUtils.trim(scompany);
	}
	public String getInsName() {
		return insName;
	}
	public void setInsName(String insName) {
		this.insName = insName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCheckstatus() {
		return checkstatus;
	}
	public void setCheckstatus(String checkstatus) {
		this.checkstatus = checkstatus;
	}
	public String getIndustryType() {
		return industryType;
	}
	public void setIndustryType(String industryType) {
		this.industryType = industryType;
	}
	public String getYsbProv() {
		return ysbProv;
	}
	public void setYsbProv(String ysbProv) {
		this.ysbProv = ysbProv;
	}
	public String getYsbCity() {
		return ysbCity;
	}
	public void setYsbCity(String ysbCity) {
		this.ysbCity = ysbCity;
	}
}
