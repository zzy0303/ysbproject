package com.uns.organization.modules.organization.entity;

import com.uns.organization.common.persistence.DataEntity;
import com.uns.organization.common.utils.excel.annotation.ExcelField;
import com.uns.organization.modules.sys.utils.DictUtils;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class InsSplitBatchSm extends DataEntity<InsSplitBatchSm> implements Serializable {

    private String beginDate;

    private String endDate;

    private String transType;

    private String batchNo;

    private String batchNos;

    private String[] batchNoArr;

    private String insNo;

    private String insName;

    private BigDecimal sumCount;

    private BigDecimal sumAmount;

    private BigDecimal sumProfit;

    private String wxT1Fee;
    private String wxD0Fee;
    private String zfbT1Fee;
    private String zfbD0Fee;

    private String status;

    private String statusType;

    private Date createDate;

    private Date settleDate;

    public String getStatusType() {
        return statusType;
    }

    public void setStatusType(String statusType) {
        this.statusType = statusType;
    }

    public Date getSettleDate() {
        return settleDate;
    }

    public void setSettleDate(Date settleDate) {
        this.settleDate = settleDate;
    }

    public String[] getBatchNoArr() {
        return batchNoArr;
    }

    public void setBatchNoArr(String[] batchNoArr) {
        this.batchNoArr = batchNoArr;
    }

    public String getBatchNos() {
        return batchNos;
    }

    public void setBatchNos(String batchNos) {
        this.batchNos = batchNos;
    }

    public void setInsName(String insName) {
        this.insName = insName;
    }

    public String getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(String beginDate) {
        this.beginDate = beginDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getTransType() {
        return transType;
    }

    public void setTransType(String transType) {
        this.transType = transType == null ? null : transType.trim();
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo == null ? null : batchNo.trim();
    }

    public void setInsNo(String insNo) {
        this.insNo = insNo == null ? null : insNo.trim();
    }

    public void setSumCount(BigDecimal sumCount) {
        this.sumCount = sumCount;
    }

    public void setSumAmount(BigDecimal sumAmount) {
        this.sumAmount = sumAmount;
    }

    public void setSumProfit(BigDecimal sumProfit) {
        this.sumProfit = sumProfit;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    public void setWxT1Fee(String wxT1Fee) {
        this.wxT1Fee = wxT1Fee;
    }

    public void setWxD0Fee(String wxD0Fee) {
        this.wxD0Fee = wxD0Fee;
    }

    public void setZfbT1Fee(String zfbT1Fee) {
        this.zfbT1Fee = zfbT1Fee;
    }

    public void setZfbD0Fee(String zfbD0Fee) {
        this.zfbD0Fee = zfbD0Fee;
    }

    @Override
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getStatusStr(String status) {
        return DictUtils.getDictLabel(status, "PROFIT_STATUS", "");
    }

    @ExcelField(title="批次编号", align=1, sort=1)
    public String getBatchNo() {
        return batchNo;
    }

    @Override
    @ExcelField(title="批次生成时间", align=1, sort=2)
    public Date getCreateDate() {
        return createDate;
    }

    @ExcelField(title="机构编号   ", align=1, sort=3)
    public String getInsNo() {
        return insNo;
    }

    @ExcelField(title="机构名称", align=1, sort=4)
    public String getInsName() {
        return insName;
    }

    @ExcelField(title="交易笔数", align=1, sort=5)
    public BigDecimal getSumCount() {
        return sumCount;
    }

    @ExcelField(title="交易总金额", align=1, sort=6)
    public BigDecimal getSumAmount() {
        return sumAmount;
    }

    @ExcelField(title="分润总金额", align=1, sort=7)
    public BigDecimal getSumProfit() {
        return sumProfit;
    }

    public String getWxT1Fee() {
        return wxT1Fee;
    }

    public String getWxD0Fee() {
        return wxD0Fee;
    }

    public String getZfbT1Fee() {
        return zfbT1Fee;
    }

    public String getZfbD0Fee() {
        return zfbD0Fee;
    }

    @ExcelField(title="分润状态", align=1, sort=8)
    public String getStatusStr() {
        return DictUtils.getDictLabel(this.status, "PROFIT_STATUS", "");
    }

}