package com.uns.organization.modules.organization.dao;

import com.uns.organization.common.persistence.annotation.MyBatisDao;
import com.uns.organization.modules.organization.entity.InstitutionHis;
@MyBatisDao
public interface InstitutionHisMapper {

    int insert(InstitutionHis record);

    int insertSelective(InstitutionHis record);
    
    int insertByInstitution(Long insId);

}