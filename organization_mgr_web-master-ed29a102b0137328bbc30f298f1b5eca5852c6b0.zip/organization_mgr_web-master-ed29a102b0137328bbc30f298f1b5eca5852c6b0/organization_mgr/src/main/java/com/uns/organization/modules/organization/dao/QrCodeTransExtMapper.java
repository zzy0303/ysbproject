package com.uns.organization.modules.organization.dao;

import com.uns.organization.common.persistence.annotation.MyBatisDao;
import com.uns.organization.modules.organization.entity.QrCodeTransExt;
@MyBatisDao
public interface QrCodeTransExtMapper {


    int deleteByPrimaryKey(Long id);

    int insert(QrCodeTransExt record);

    int insertSelective(QrCodeTransExt record);

    QrCodeTransExt selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(QrCodeTransExt record);

    int updateByPrimaryKey(QrCodeTransExt record);
}