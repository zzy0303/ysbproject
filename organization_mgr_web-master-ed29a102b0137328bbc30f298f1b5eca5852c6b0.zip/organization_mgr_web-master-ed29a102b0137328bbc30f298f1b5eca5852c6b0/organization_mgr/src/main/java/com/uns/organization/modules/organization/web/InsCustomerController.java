package com.uns.organization.modules.organization.web;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uns.inf.acms.client.DynamicConfigLoader;
import com.uns.organization.modules.organization.entity.*;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.organization.common.exception.BusinessException;
import com.uns.organization.common.exception.ExceptionDefine;
import com.uns.organization.common.persistence.Page;
import com.uns.organization.common.utils.Constants;
import com.uns.organization.modules.organization.service.InsCustomerService;
import com.uns.organization.modules.organization.service.InsSysAreaService;
import com.uns.organization.modules.organization.service.InstitutionService;
import com.uns.organization.modules.organization.service.SysAreaService;
import com.uns.organization.modules.organization.web.form.CustomerForm;
import com.uns.organization.common.web.BaseController;;

/**
 * 商户信息管理
 * @author Administrator
 *
 */
@Controller
@RequestMapping(value = "${adminPath}/ins/customer")
public class InsCustomerController extends BaseController{

	@Autowired
	InsCustomerService insCustomerService;

	@Autowired
	SysAreaService sysAreaService;
	
	@Autowired
	InstitutionService institutionService;
	
	@Autowired
	InsSysAreaService insSysAreaService;
	/**
	 * 商户信息查询
	 * @param customerForm
	 * @param model
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(value = "list")
	public String list(CustomerForm customerForm,HttpServletRequest request, HttpServletResponse response, Model model) throws BusinessException {
		try {
			Page<Customer> page = insCustomerService.findCustomerList(new Page<Customer>(request, response), customerForm);
			List<SysArea> allProvince = sysAreaService.findAllProvince();// 查询所有省
			List<Institution> allIns = institutionService.findAllIns();
			model.addAttribute("page", page);
			model.addAttribute("allIns", allIns);
			model.addAttribute("allProvince", allProvince);
		} catch (Exception e) {
			e.printStackTrace();
			addMessage(model, "商户信息列表查询出错");
		}
		return "modules/customer/customerList";
	}


	/**
	 * 商户信息详情
	 * @param customerForm
	 * @param model
	 * @return
	 * @throws BusinessException 
	 */
	@RequestMapping(value = "details")
	public String details(CustomerForm customerForm,HttpServletRequest request, HttpServletResponse response, Model model) throws BusinessException {
		try {
			Customer customer = insCustomerService.findCustomerDetails(customerForm);
			Long photoId = customer.getPhotoId();
			if (null != photoId){
				MposPhotoTmp mposPhotoTmp = insCustomerService.findInsPhoto(photoId);
				model.addAttribute("photo", mposPhotoTmp);
				model.addAttribute("image_get_url", DynamicConfigLoader.getByEnv("showInsImage_url"));
			}

			//查询开户行地址
			SysArea openingBankArea = insSysAreaService.findAreaNameByYsb(customer);
			customer.setOpeningBankProvince(openingBankArea.getProvincialname());
			customer.setOpeningBankCity(openingBankArea.getCityname());
			//查询商户费率(从历史表中)
			List commissionpolicyList = insCustomerService.findCommissionpolicy(Long.valueOf(customerForm.getCustomerid()));//支付宝
			model.addAttribute("commissionpolicyList", commissionpolicyList);
			model.addAttribute("customer", customer);
		} catch (Exception e) {
			e.printStackTrace();
			addMessage(model, "商户信息详情查询出错");
		}
		return "modules/customer/customerDetails";
	}


}
