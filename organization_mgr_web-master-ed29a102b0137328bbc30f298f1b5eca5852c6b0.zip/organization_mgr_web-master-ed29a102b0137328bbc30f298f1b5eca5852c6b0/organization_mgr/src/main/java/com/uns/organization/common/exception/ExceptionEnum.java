package com.uns.organization.common.exception;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/11/22
 * @Modifyed By:
 */
public enum  ExceptionEnum {

    调用机构入驻接口异常("1001","调用机构入驻接口异常!"),
    调用机构入驻接口返回失败("1002","调用机构入驻接口返回失败！"),
    机构信息修改接口异常("1003","机构信息修改接口异常！"),
    机构信息修改接口返回失败("1004","机构信息修改接口返回失败！"),
    
    调用商户创建接口异常("2001", "调用商户创建接口异常"),
    调用商户创建接口失败("2002","调用商户创建接口失败"),
    商户创建失败("2003","商户创建失败"),
    
    调用银行入驻接口异常("3001","调用银行入驻接口异常"),
    调用银行入驻接口失败("3002","调用银行入驻接口失败"),
    银行入驻失败("3003","银行入驻失败"),
    扫码支付业务配置失败("3004","扫码支付业务配置失败"),
    快捷支付业务配置失败("3005","快捷支付业务配置失败")
    ;


    private String code;
    private String text;

    private ExceptionEnum(String code, String text) {
        this.code = code;
        this.text = text;
    }

    public String getCode() {
        return code;
    }

    public String getText() {
        return text;
    }

}
