package com.uns.organization.modules.organization.entity;

public class CommissionRange {
    private String insNo;

    private String commissionname;

    private String cardtype;

    private String commissionRate;

    private String d0CommissionRate;

    private String fixedRate;

    private String d0FixedRate;

    private String status;

    public String getInsNo() {
        return insNo;
    }

    public void setInsNo(String insNo) {
        this.insNo = insNo;
    }

    public String getCommissionname() {
        return commissionname;
    }

    public void setCommissionname(String commissionname) {
        this.commissionname = commissionname;
    }

    public String getCardtype() {
        return cardtype;
    }

    public void setCardtype(String cardtype) {
        this.cardtype = cardtype;
    }

    public String getCommissionRate() {
        return commissionRate;
    }

    public void setCommissionRate(String commissionRate) {
        this.commissionRate = commissionRate;
    }

    public String getD0CommissionRate() {
        return d0CommissionRate;
    }

    public void setD0CommissionRate(String d0CommissionRate) {
        this.d0CommissionRate = d0CommissionRate;
    }

    public String getFixedRate() {
        return fixedRate;
    }

    public void setFixedRate(String fixedRate) {
        this.fixedRate = fixedRate;
    }

    public String getD0FixedRate() {
        return d0FixedRate;
    }

    public void setD0FixedRate(String d0FixedRate) {
        this.d0FixedRate = d0FixedRate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
