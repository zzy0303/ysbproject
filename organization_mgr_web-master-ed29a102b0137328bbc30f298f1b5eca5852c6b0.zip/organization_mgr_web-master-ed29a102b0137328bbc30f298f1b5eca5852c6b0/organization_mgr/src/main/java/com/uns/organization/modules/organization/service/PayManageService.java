package com.uns.organization.modules.organization.service;

import com.uns.organization.common.service.BaseService;
import com.uns.organization.common.utils.Constants;
import com.uns.organization.common.utils.StringUtils;
import com.uns.organization.modules.organization.dao.PayManageMapper;
import com.uns.organization.modules.organization.web.form.PayManageForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class PayManageService extends BaseService{

    @Autowired
    private PayManageMapper payManageMapper;

    /**
     * 查询扫码支付业务
     * @return
     */
    public Map findSmPayManage() throws Exception{
        List smPayment = payManageMapper.smPayment();
        Map map = setSmPayManage(smPayment);
        return map;
    }

    private Map setSmPayManage(List smPayment) throws Exception{
        Map map = new HashMap<>();
        for(int i=0;i<smPayment.size();i++){
            Map smPaymentMap = (Map) smPayment.get(i);
            //动态码
            String keyDynamicT1Amount = (String) smPaymentMap.get(Constants.KEY_NAME);
            if(StringUtils.isNotEmpty(keyDynamicT1Amount) && Constants.DYNAMICT1AMOUNT.equals(keyDynamicT1Amount)){
                String dynamicT1Amount=(String)smPaymentMap.get(Constants.KEY_VALUE);
                String[] dynamicT1Amounts=dynamicT1Amount.split("-");
                String dynamicT1Amountstart=dynamicT1Amounts[0];
                String dynamicT1AmountEnd=dynamicT1Amounts[1];
                map.put("dynamicT1AmountStart", dynamicT1Amountstart);
                map.put("dynamicT1AmountEnd", dynamicT1AmountEnd);
            }

            //动态码T1时间
            String keyDynamicT1AmountTime=(String)smPaymentMap.get(Constants.KEY_NAME);
            if(StringUtils.isNotEmpty(keyDynamicT1AmountTime)&&Constants.DYNAMICT1TIME.equals(keyDynamicT1AmountTime)){
                String dynamicT1AmountTime=(String)smPaymentMap.get(Constants.KEY_VALUE);
                String[] dynamicT1AmountTimes=dynamicT1AmountTime.split("-");
                String dynamicT1AmountStartTime=dynamicT1AmountTimes[0];
                String dynamicT1AmountEndTime=dynamicT1AmountTimes[1];
                map.put("dynamicT1AmountStartTime", dynamicT1AmountStartTime);
                map.put("dynamicT1AmountEndTime", dynamicT1AmountEndTime);
            }

            //动态码D0交易金额
            String keyDynamicD0Amount=(String)smPaymentMap.get(Constants.KEY_NAME);
            if(StringUtils.isNotEmpty(keyDynamicD0Amount)&&Constants.DYNAMICD0AMOUNT.equals(keyDynamicD0Amount)){
                String dynamicD0Amount=(String)smPaymentMap.get(Constants.KEY_VALUE);
                String[] dynamicD0Amounts=dynamicD0Amount.split("-");
                String dynamicD0AmountStart=dynamicD0Amounts[0];
                String dynamicD0AmountEnd=dynamicD0Amounts[1];
                map.put("dynamicD0AmountStart", dynamicD0AmountStart);
                map.put("dynamicD0AmountEnd", dynamicD0AmountEnd);
            }

            //动态码D0时间
            String keydynamicD0Time=(String)smPaymentMap.get(Constants.KEY_NAME);
            if(StringUtils.isNotEmpty(keydynamicD0Time)&&Constants.DYNAMICD0TIME.equals(keydynamicD0Time)){
                String dynamicD0Time=(String)smPaymentMap.get(Constants.KEY_VALUE);
                String[] dynamicD0Times=dynamicD0Time.split("-");
                String dynamicD0AmountStartTime=dynamicD0Times[0];
                String dynamicD0AmountEndTime=dynamicD0Times[1];
                map.put("dynamicD0AmountStartTime", dynamicD0AmountStartTime);
                map.put("dynamicD0AmountEndTime", dynamicD0AmountEndTime);
            }

            //固定码T1交易金额
            String keyfixedT1Amount=(String)smPaymentMap.get(Constants.KEY_NAME);
            if(StringUtils.isNotEmpty(keyfixedT1Amount)&&Constants.FIXEDT1AMOUNT.equals(keyfixedT1Amount)){
                String fixedT1Amount=(String)smPaymentMap.get(Constants.KEY_VALUE);
                String[] fixedT1Amounts=fixedT1Amount.split("-");
                String fixT1AmountStart=fixedT1Amounts[0];
                String fixT1AmountEnd=fixedT1Amounts[1];
                map.put("fixT1AmountStart", fixT1AmountStart);
                map.put("fixT1AmountEnd", fixT1AmountEnd);
            }

            //固定码T1交易时间
            String keyfixedT1Time=(String)smPaymentMap.get(Constants.KEY_NAME);
            if(StringUtils.isNotEmpty(keyfixedT1Time)&&Constants.FIXEDT1TIME.equals(keyfixedT1Time)){
                String fixedT1Time=(String)smPaymentMap.get(Constants.KEY_VALUE);
                String[] fixedT1Times=fixedT1Time.split("-");
                String fixT1AmountStartTime=fixedT1Times[0];
                String fixT1AmountEndTime=fixedT1Times[1];
                map.put("fixT1AmountStartTime", fixT1AmountStartTime);
                map.put("fixT1AmountEndTime", fixT1AmountEndTime);
            }

            //固定码D0交易金额
            String keyfixedD0Amount=(String)smPaymentMap.get(Constants.KEY_NAME);
            if(StringUtils.isNotEmpty(keyfixedD0Amount)&&Constants.FIXEDD0AMOUNT.equals(keyfixedD0Amount)){
                String fixedD0Amount=(String)smPaymentMap.get(Constants.KEY_VALUE);
                String[] fixedD0Amounts=fixedD0Amount.split("-");
                String fixD0AmountStart=fixedD0Amounts[0];
                String fixD0AmountEnd=fixedD0Amounts[1];
                map.put("fixD0AmountStart", fixD0AmountStart);
                map.put("fixD0AmountEnd", fixD0AmountEnd);
            }

            //固定码D0交易时间
            String keyfixedD0Time=(String)smPaymentMap.get(Constants.KEY_NAME);
            if(StringUtils.isNotEmpty(keyfixedD0Time)&&Constants.FIXEDD0TIME.equals(keyfixedD0Time)){
                String fixedD0Time=(String)smPaymentMap.get(Constants.KEY_VALUE);
                String[] fixedD0Times=fixedD0Time.split("-");
                String fixD0AmountStartTime=fixedD0Times[0];
                String fixD0AmountEndTime=fixedD0Times[1];
                map.put("fixD0AmountStartTime", fixD0AmountStartTime);
                map.put("fixD0AmountEndTime", fixD0AmountEndTime);
            }
        }
        return map;
    }

    /**
     * 修改扫码支付业务
     * @param payManageForm
     */
    public void updatePaySm(PayManageForm payManageForm) throws Exception{
        //动态码T1交易金额
        Map<String,String> dynamicT1AmountMap=new HashMap<String,String>();
        String dynamicT1Amount=payManageForm.getDynamicT1AmountStart()+"-"+payManageForm.getDynamicT1AmountEnd();
        dynamicT1AmountMap.put(Constants.KEY_VALUE, dynamicT1Amount);
        dynamicT1AmountMap.put(Constants.KEY_NAME, Constants.DYNAMICT1AMOUNT);
        payManageMapper.updateSmPayment(dynamicT1AmountMap);
        //动态码T1交易时间
        Map<String,String> dynamicT1TimeMap=new HashMap<String,String>();
        String dynamicT1Time=payManageForm.getDynamicT1AmountStartTime()+"-"+payManageForm.getDynamicT1AmountEndTime();
        dynamicT1TimeMap.put(Constants.KEY_VALUE, dynamicT1Time);
        dynamicT1TimeMap.put(Constants.KEY_NAME, Constants.DYNAMICT1TIME);
        payManageMapper.updateSmPayment(dynamicT1TimeMap);
        //动态码D0交易金额
        Map<String,String> dynamicD0AmountMap=new HashMap<String,String>();
        String dynamicD0Amount=payManageForm.getDynamicD0AmountStart()+"-"+payManageForm.getDynamicD0AmountEnd();
        dynamicD0AmountMap.put(Constants.KEY_VALUE, dynamicD0Amount);
        dynamicD0AmountMap.put(Constants.KEY_NAME, Constants.DYNAMICD0AMOUNT);
        payManageMapper.updateSmPayment(dynamicD0AmountMap);
        //动态码D0交易时间
        Map<String,String> dynamicD0TimeMap=new HashMap<String,String>();
        String dynamicD0Time=payManageForm.getDynamicD0AmountStartTime()+"-"+payManageForm.getDynamicD0AmountEndTime();
        dynamicD0TimeMap.put(Constants.KEY_VALUE, dynamicD0Time);
        dynamicD0TimeMap.put(Constants.KEY_NAME, Constants.DYNAMICD0TIME);
        payManageMapper.updateSmPayment(dynamicD0TimeMap);

        //固定码T1交易金额
        Map<String,String> fixedT1AmountMap=new HashMap<String,String>();
        String fixedT1Amount=payManageForm.getFixT1AmountStart()+"-"+payManageForm.getFixT1AmountEnd();
        fixedT1AmountMap.put(Constants.KEY_VALUE, fixedT1Amount);
        fixedT1AmountMap.put(Constants.KEY_NAME, Constants.FIXEDT1AMOUNT);
        payManageMapper.updateSmPayment(fixedT1AmountMap);
        //固定码T1交易时间
        Map<String,String> fixedT1TimeMap=new HashMap<String,String>();
        String fixedT1Time=payManageForm.getFixT1AmountStartTime()+"-"+payManageForm.getFixT1AmountEndTime();
        fixedT1TimeMap.put(Constants.KEY_VALUE, fixedT1Time);
        fixedT1TimeMap.put(Constants.KEY_NAME, Constants.FIXEDT1TIME);
        payManageMapper.updateSmPayment(fixedT1TimeMap);

        //固定码D0交易金额
        Map<String,String> fixedD0AmountMap=new HashMap<String,String>();
        String fixedD0Amount=payManageForm.getFixD0AmountStart()+"-"+payManageForm.getFixD0AmountEnd();
        fixedD0AmountMap.put(Constants.KEY_VALUE, fixedD0Amount);
        fixedD0AmountMap.put(Constants.KEY_NAME, Constants.FIXEDD0AMOUNT);
        payManageMapper.updateSmPayment(fixedD0AmountMap);
        //固定码D0交易时间
        Map<String,String> fixedD0TimeMap=new HashMap<String,String>();
        String fixedD0Time=payManageForm.getFixD0AmountStartTime()+"-"+payManageForm.getFixD0AmountEndTime();
        fixedD0TimeMap.put(Constants.KEY_VALUE, fixedD0Time);
        fixedD0TimeMap.put(Constants.KEY_NAME, Constants.FIXEDD0TIME);
        payManageMapper.updateSmPayment(fixedD0TimeMap);
    }

    /**
     * 查询快捷支付业务
     * @return
     * @throws Exception
     */
    public Map findKjPayManage() throws Exception{
        List kjPayment = payManageMapper.smPayment();
        Map map = setKjPayManage(kjPayment);
        return map;
    }

    /**
     * 设置快捷
     * @param kjPayment
     * @return
     */
    public Map setKjPayManage(List kjPayment){
        Map<String,String> map=new HashMap<String,String>();
        for(int i=0;i<kjPayment.size();i++){
            Map sysConfigSmMap=(Map)kjPayment.get(i);
            //快捷T1
            String keyquickT1Amount=(String)sysConfigSmMap.get(Constants.KEY_NAME);
            if(org.apache.commons.lang.StringUtils.isNotEmpty(keyquickT1Amount)&&Constants.QUICKT1AMOUNT.equals(keyquickT1Amount)){
                String quickT1Amount=(String)sysConfigSmMap.get(Constants.KEY_VALUE);
                String[] quickT1Amounts=quickT1Amount.split("-");
                String quickT1AmountStart=quickT1Amounts[0];
                String quickT1AmountEnd=quickT1Amounts[1];
                map.put("quickT1AmountStart", quickT1AmountStart);
                map.put("quickT1AmountEnd", quickT1AmountEnd);
            }

            //快捷T1 时间
            String keyquickT1AmountTime=(String)sysConfigSmMap.get(Constants.KEY_NAME);
            if(org.apache.commons.lang.StringUtils.isNotEmpty(keyquickT1AmountTime)&&Constants.QUICKT1TIME.equals(keyquickT1AmountTime)){
                String quickT1AmountTime=(String)sysConfigSmMap.get(Constants.KEY_VALUE);
                String[] quickT1AmountTimes=quickT1AmountTime.split("-");
                String quickT1AmountStartTime=quickT1AmountTimes[0];
                String quickT1AmountEndTime=quickT1AmountTimes[1];
                map.put("quickT1AmountStartTime", quickT1AmountStartTime);
                map.put("quickT1AmountEndTime", quickT1AmountEndTime);
            }

            //快捷D0交易金额
            String keyquickD0Amount=(String)sysConfigSmMap.get(Constants.KEY_NAME);
            if(org.apache.commons.lang.StringUtils.isNotEmpty(keyquickD0Amount)&&Constants.QUICKD0AMOUNT.equals(keyquickD0Amount)){
                String dynamicD0Amount=(String)sysConfigSmMap.get(Constants.KEY_VALUE);
                String[] quickD0Amounts=dynamicD0Amount.split("-");
                String quickD0AmountStart=quickD0Amounts[0];
                String quickD0AmountEnd=quickD0Amounts[1];
                map.put("quickD0AmountStart", quickD0AmountStart);
                map.put("quickD0AmountEnd", quickD0AmountEnd);
            }

            //快捷D0时间
            String keyquickD0Time=(String)sysConfigSmMap.get(Constants.KEY_NAME);
            if(org.apache.commons.lang.StringUtils.isNotEmpty(keyquickD0Time)&&Constants.QUICKD0TIME.equals(keyquickD0Time)){
                String quickD0Time=(String)sysConfigSmMap.get(Constants.KEY_VALUE);
                String[] quickD0Times=quickD0Time.split("-");
                String quickD0AmountStartTime=quickD0Times[0];
                String quickD0AmountEndTime=quickD0Times[1];
                map.put("quickD0AmountStartTime", quickD0AmountStartTime);
                map.put("quickD0AmountEndTime", quickD0AmountEndTime);
            }

            //快捷SH-D0交易金额
            String keyquickSHD0Amount=(String)sysConfigSmMap.get(Constants.KEY_NAME);
            if(org.apache.commons.lang.StringUtils.isNotEmpty(keyquickSHD0Amount)&&Constants.QUICKSHD0AMOUNT.equals(keyquickSHD0Amount)){
                String quickSHD0Amount=(String)sysConfigSmMap.get(Constants.KEY_VALUE);
                String[] quickSHD0Amounts=quickSHD0Amount.split("-");
                String quickSHD0AmountStart=quickSHD0Amounts[0];
                String quickSHD0AmountEnd=quickSHD0Amounts[1];
                map.put("quickSHD0AmountStart", quickSHD0AmountStart);
                map.put("quickSHD0AmountEnd", quickSHD0AmountEnd);
            }
            //快捷SH-D0时间
            String keyquickSHD0Time=(String)sysConfigSmMap.get(Constants.KEY_NAME);
            if(org.apache.commons.lang.StringUtils.isNotEmpty(keyquickD0Time)&&Constants.QUICKSHD0TIME.equals(keyquickSHD0Time)){
                String quickSHD0Time=(String)sysConfigSmMap.get(Constants.KEY_VALUE);
                String[] quickSHD0Times=quickSHD0Time.split("-");
                String quickSHD0AmountStartTime=quickSHD0Times[0];
                String quickSHD0AmountEndTime=quickSHD0Times[1];
                map.put("quickSHD0AmountStartTime", quickSHD0AmountStartTime);
                map.put("quickSHD0AmountEndTime", quickSHD0AmountEndTime);
            }
        }
        return map;
    }

    /**
     * 修改快捷支付配置
     */
    public void updatePayKj(PayManageForm payManageForm) throws Exception{
        //快捷T1交易金额
        Map<String,String> quickT1AmountMap=new HashMap<String,String>();
        String quickT1Amount=payManageForm.getQuickT1AmountStart()+"-"+payManageForm.getQuickT1AmountEnd();
        quickT1AmountMap.put(Constants.KEY_VALUE, quickT1Amount);
        quickT1AmountMap.put(Constants.KEY_NAME, Constants.QUICKT1AMOUNT);
        payManageMapper.updateSmPayment(quickT1AmountMap);
        //快捷T1交易时间
        Map<String,String> quickT1TimeMap=new HashMap<String,String>();
        String quickT1Time=payManageForm.getQuickT1AmountStartTime()+"-"+payManageForm.getQuickT1AmountEndTime();
        quickT1TimeMap.put(Constants.KEY_VALUE, quickT1Time);
        quickT1TimeMap.put(Constants.KEY_NAME, Constants.QUICKT1TIME);
        payManageMapper.updateSmPayment(quickT1TimeMap);
        //快捷D0交易金额
        Map<String,String> quickD0AmountMap=new HashMap<String,String>();
        String quickD0Amount=payManageForm.getQuickD0AmountStart()+"-"+payManageForm.getQuickD0AmountEnd();
        quickD0AmountMap.put(Constants.KEY_VALUE, quickD0Amount);
        quickD0AmountMap.put(Constants.KEY_NAME, Constants.QUICKD0AMOUNT);
        payManageMapper.updateSmPayment(quickD0AmountMap);
        //快捷D0交易时间
        Map<String,String> quickD0TimeMap=new HashMap<String,String>();
        String quickD0Time=payManageForm.getQuickD0AmountStartTime()+"-"+payManageForm.getQuickD0AmountEndTime();
        quickD0TimeMap.put(Constants.KEY_VALUE, quickD0Time);
        quickD0TimeMap.put(Constants.KEY_NAME, Constants.QUICKD0TIME);
        payManageMapper.updateSmPayment(quickD0TimeMap);
        //快捷SH-D0交易金额
        Map<String,String> quickSHD0AmountMap=new HashMap<String,String>();
        String quickSHD0Amount=payManageForm.getQuickSHD0AmountStart()+"-"+payManageForm.getQuickSHD0AmountEnd();
        quickSHD0AmountMap.put(Constants.KEY_VALUE, quickSHD0Amount);
        quickSHD0AmountMap.put(Constants.KEY_NAME, Constants.QUICKSHD0AMOUNT);
        payManageMapper.updateSmPayment(quickSHD0AmountMap);
        //快捷SH-D0交易时间
        Map<String,String> quickSHD0TimeMap=new HashMap<String,String>();
        String quickSHD0Time=payManageForm.getQuickSHD0AmountStartTime()+"-"+payManageForm.getQuickSHD0AmountEndTime();
        quickSHD0TimeMap.put(Constants.KEY_VALUE, quickSHD0Time);
        quickSHD0TimeMap.put(Constants.KEY_NAME, Constants.QUICKSHD0TIME);
        payManageMapper.updateSmPayment(quickSHD0TimeMap);
    }

}
