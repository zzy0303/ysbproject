package com.uns.organization.modules.organization.web;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.uns.organization.common.persistence.Page;
import com.uns.organization.common.utils.Constants;
import com.uns.organization.common.utils.StringUtils;
import com.uns.organization.common.web.BaseController;
import com.uns.organization.modules.organization.entity.InsRoleInfo;
import com.uns.organization.modules.organization.service.InsRoleService;
import com.uns.organization.modules.sys.entity.Menu;
import com.uns.organization.modules.sys.service.SystemService;

/**
 * 机构角色管理
 * @author yang.cheng
 *
 */
@Controller
@RequestMapping(value = "${adminPath}/ins/insRole")
public class InsRoleController extends BaseController{
	
	@Autowired
	private InsRoleService insRoleService;
	
	/**
	 * 角色查询页面
	 * @param role
	 * @param model
	 * @return
	 */
	@RequiresPermissions("sys:role:view")
	@RequestMapping(value = {"list", ""})
	public String list(InsRoleInfo insRoleInfo, Model model,HttpServletRequest request, HttpServletResponse response) {
		Page<InsRoleInfo> page =  insRoleService.findInsRoleList(new Page<InsRoleInfo>(request, response), insRoleInfo);
		model.addAttribute("page", page);
		return "modules/InsRole/insRoleList";
	}
	
	
	/**
	 * 角色添加，修改页面
	 * @param role
	 * @param model
	 * @return
	 */
	@RequiresPermissions("ins:insRole:edit")
	@RequestMapping(value = "form")
	public String form(InsRoleInfo insRoleInfo, Model model,RedirectAttributes redirectAttributes) {
		try {
			if(StringUtils.isNotBlank(insRoleInfo.getId())){
				insRoleInfo = insRoleService.getInsRoleInfoById(insRoleInfo.getId());
				//查询角色权限
				String[] functionIds = insRoleService.getFunctionByInsRole(insRoleInfo.getId());
				insRoleInfo.setFunctionIds(functionIds);
			}
			List<Menu> menuList = insRoleService.findAllMenu();
			model.addAttribute("insRoleInfo", insRoleInfo);
			model.addAttribute("menuList", menuList);
			return "modules/InsRole/insRoleForm";
		} catch (Exception e) {
			logger.error("跳转角色添加，修改页面异常！", e);
			addMessage(redirectAttributes, "跳转角色添加，修改页面失败！"+e.getMessage());
			return "redirect:" + adminPath + "/ins/insRole/list?repage";
		}
	}
	
	/**
	 * 角色保存/修改
	 * @param role
	 * @param model
	 * @param redirectAttributes
	 * @return
	 */
	@RequiresPermissions("ins:insRole:edit")
	@RequestMapping(value = "save")
	public String save(InsRoleInfo insRoleInfo, Model model, RedirectAttributes redirectAttributes) {
		try {
			insRoleService.saveInsRoleInfo(insRoleInfo);
			addMessage(redirectAttributes, "保存角色'" + insRoleInfo.getRoleName() + "'成功");
			return "redirect:" + adminPath + "/ins/insRole/list?repage";
		} catch (Exception e) {
			logger.error("保存角色信息异常！",e);
			addMessage(redirectAttributes, "保存角色失败！"+e.getMessage());
			return "redirect:" + adminPath + "/ins/insRole/list?repage";
		}
	}
	
	
	/**
	 * 删除角色
	 * @param role
	 * @param redirectAttributes
	 * @return
	 */
	@RequiresPermissions("ins:insRole:edit1")
	@RequestMapping(value = "delete")
	public String delete(String id, RedirectAttributes redirectAttributes) {
		if(StringUtils.isBlank(id)){
			addMessage(redirectAttributes, "角色删除失败！id不能为空！");
			return "redirect:" + adminPath + "/ins/insRole/list?repage";
		}
		if(Constants.INS_OPERATOR_INIT_ROLE.equals(id)){
			addMessage(redirectAttributes, "角色删除失败！机构默认角色不允许删除！");
			return "redirect:" + adminPath + "/ins/insRole/list?repage";
		}
		try {
			insRoleService.deleteInsRoleInfo(id);
			addMessage(redirectAttributes, "删除角色成功");
			return "redirect:" + adminPath + "/ins/insRole/list?repage";
		} catch (Exception e) {
			logger.error("删除角色异常！",e);
			addMessage(redirectAttributes, "删除角色失败！"+e.getMessage());
			return "redirect:" + adminPath + "/ins/insRole/list?repage";
		}
	}
	
	/**
	 * 验证角色名是否有效
	 * @param oldName
	 * @param name
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "checkRoleName")
	public String checkRoleName(String oldName, String roleName) {
		if (roleName!=null && roleName.equals(oldName)) {
			return "true";
		} else if (roleName!=null && insRoleService.getRoleByRoleName(roleName) == null) {
			return "true";
		}
		return "false";
	}
}
