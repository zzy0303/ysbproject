package com.uns.organization.modules.organization.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.organization.common.persistence.Page;
import com.uns.organization.common.service.BaseService;
import com.uns.organization.modules.organization.dao.PercentagMapper;
import com.uns.organization.modules.organization.entity.Percentag;
import com.uns.organization.modules.organization.entity.PercentagTx;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 抽成service
 * @author yang.cheng
 *
 */
@Service
public class PercentagService extends BaseService{
	
	@Autowired
	private PercentagMapper percentagMapper;
	
	/**
	 * 抽成分页查询
	 * @param page
	 * @param percentag
	 * @return
	 */
	public Page<Percentag> findPercentagList(Page<Percentag> page, Percentag percentag) {
		// 设置分页参数
		percentag.setPage(page);
		// 执行分页查询
		page.setList(percentagMapper.findPercentagList(percentag));
		return page;
	}

	/**
	 * 抽成提现分页查询
	 * @param page
	 * @param percentagTx
	 * @return
	 */
	public Page<PercentagTx> findPercentagTxList(Page<PercentagTx> page, PercentagTx percentagTx){
		// 设置分页参数
		percentagTx.setPage(page);
		try {
            // 执行分页查询
            List<PercentagTx> percentagList = percentagMapper.findPercentagTxList(percentagTx);
            for (int i = 0;i < percentagList.size();i++) {
                String insNo = percentagList.get(i).getInsNo();
                String transTime = percentagList.get(i).getTranTime();
                Map<String,String> param = new HashMap<>();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
                Date date = sdf.parse(transTime);
                Calendar calendar = Calendar.getInstance();
                calendar.setTime(date);
                calendar.add(calendar.DAY_OF_MONTH, -1); //取日期前一天
                sdf = new SimpleDateFormat("yyyy-MM-dd");
                param.put("insNo",insNo);
                param.put("transTime",sdf.format(calendar.getTime()));
                //获取抽成总金额
                String amountStr = percentagMapper.findSumAmount(param);
                percentagList.get(i).setSumAmount(amountStr);
            }
            page.setList(percentagList);
        } catch (Exception e){
            e.printStackTrace();
        }
		return page;
	}
}
