package com.uns.organization.modules.organization.entity;

import java.util.Date;

public class ZhaoshangJoin {
    private Long id;

    private String isCommon;

    private String appId;

    private String timestamp;

    private String version;

    private String outMerchantId;

    private String mchAppId;

    private String smallMerchantNo;

    private String insNo;

    private String name;

    private String aliasName;

    private String loginId;

    private String password;

    private String mobileNo;

    private String servicePhone;

    private String industryCategoryId;

    private String wxCategoryId;

    private String wxCategoryName;

    private String aliCategoryId;

    private String aliCategoryName;

    private String email;

    private String businessLicense;

    private String businessLicenseType;

    private String merchantLicense;

    private String lxrName;

    private String lxrType;

    private String idCardNo;

    private String phone;

    private String provinceCode;

    private String cityCode;

    private String districtCode;

    private String address;

    private String remark;

    private String extend1;

    private String extend2;

    private String extend3;

    private String auditStatus;

    private String joinAppId;

    private String joinTimestamp;

    private String bankAppId;

    private String feeRateId;

    private String payFeeRateNoWx;

    private String feeRateWx;

    private String payFeeRateNoZfb;

    private String feeRateZfb;

    private String accountName;

    private String accountNo;

    private String accountProp;

    private String provinceCodeJs;

    private String cityCodeJs;

    private String bankBranchNo;

    private String bankName;

    private String bankBranch;

    private String idCardNoJs;

    private String aliStatus;

    private String wxStatus;

    private String aliAuditStatus;

    private String wxAuditStatus;

    private String responseUrl;

    private String tranceNo;
    
    private String wxAppId;
    
    private String wxAppSecret;

    private Date createTime;
    
	private Date updateTime;
    
    private String creator;
    
    private String updator;
    
    
    //非实体类字段
    private String payType;
    private String insName;

    
    public String getWxAppId() {
		return wxAppId;
	}

	public void setWxAppId(String wxAppId) {
		this.wxAppId = wxAppId;
	}

	public String getWxAppSecret() {
		return wxAppSecret;
	}

	public void setWxAppSecret(String wxAppSecret) {
		this.wxAppSecret = wxAppSecret;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getUpdator() {
		return updator;
	}

	public void setUpdator(String updator) {
		this.updator = updator;
	}

	public String getPayType() {
		return payType;
	}

	public void setPayType(String payType) {
		this.payType = payType;
	}

	public String getInsName() {
		return insName;
	}

	public void setInsName(String insName) {
		this.insName = insName;
	}

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getIsCommon() {
        return isCommon;
    }

    public void setIsCommon(String isCommon) {
        this.isCommon = isCommon == null ? null : isCommon.trim();
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId == null ? null : appId.trim();
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp == null ? null : timestamp.trim();
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version == null ? null : version.trim();
    }

    public String getOutMerchantId() {
        return outMerchantId;
    }

    public void setOutMerchantId(String outMerchantId) {
        this.outMerchantId = outMerchantId == null ? null : outMerchantId.trim();
    }

    public String getMchAppId() {
        return mchAppId;
    }

    public void setMchAppId(String mchAppId) {
        this.mchAppId = mchAppId == null ? null : mchAppId.trim();
    }

    public String getSmallMerchantNo() {
        return smallMerchantNo;
    }

    public void setSmallMerchantNo(String smallMerchantNo) {
        this.smallMerchantNo = smallMerchantNo == null ? null : smallMerchantNo.trim();
    }

    public String getInsNo() {
        return insNo;
    }

    public void setInsNo(String insNo) {
        this.insNo = insNo == null ? null : insNo.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getAliasName() {
        return aliasName;
    }

    public void setAliasName(String aliasName) {
        this.aliasName = aliasName == null ? null : aliasName.trim();
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId == null ? null : loginId.trim();
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo == null ? null : mobileNo.trim();
    }

    public String getServicePhone() {
        return servicePhone;
    }

    public void setServicePhone(String servicePhone) {
        this.servicePhone = servicePhone == null ? null : servicePhone.trim();
    }

    public String getIndustryCategoryId() {
        return industryCategoryId;
    }

    public void setIndustryCategoryId(String industryCategoryId) {
        this.industryCategoryId = industryCategoryId == null ? null : industryCategoryId.trim();
    }

    public String getWxCategoryId() {
        return wxCategoryId;
    }

    public void setWxCategoryId(String wxCategoryId) {
        this.wxCategoryId = wxCategoryId == null ? null : wxCategoryId.trim();
    }

    public String getWxCategoryName() {
        return wxCategoryName;
    }

    public void setWxCategoryName(String wxCategoryName) {
        this.wxCategoryName = wxCategoryName == null ? null : wxCategoryName.trim();
    }

    public String getAliCategoryId() {
        return aliCategoryId;
    }

    public void setAliCategoryId(String aliCategoryId) {
        this.aliCategoryId = aliCategoryId == null ? null : aliCategoryId.trim();
    }

    public String getAliCategoryName() {
        return aliCategoryName;
    }

    public void setAliCategoryName(String aliCategoryName) {
        this.aliCategoryName = aliCategoryName == null ? null : aliCategoryName.trim();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    public String getBusinessLicense() {
        return businessLicense;
    }

    public void setBusinessLicense(String businessLicense) {
        this.businessLicense = businessLicense == null ? null : businessLicense.trim();
    }

    public String getBusinessLicenseType() {
        return businessLicenseType;
    }

    public void setBusinessLicenseType(String businessLicenseType) {
        this.businessLicenseType = businessLicenseType == null ? null : businessLicenseType.trim();
    }

    public String getMerchantLicense() {
        return merchantLicense;
    }

    public void setMerchantLicense(String merchantLicense) {
        this.merchantLicense = merchantLicense == null ? null : merchantLicense.trim();
    }

    public String getLxrName() {
        return lxrName;
    }

    public void setLxrName(String lxrName) {
        this.lxrName = lxrName == null ? null : lxrName.trim();
    }

    public String getLxrType() {
        return lxrType;
    }

    public void setLxrType(String lxrType) {
        this.lxrType = lxrType == null ? null : lxrType.trim();
    }

    public String getIdCardNo() {
        return idCardNo;
    }

    public void setIdCardNo(String idCardNo) {
        this.idCardNo = idCardNo == null ? null : idCardNo.trim();
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    public String getProvinceCode() {
        return provinceCode;
    }

    public void setProvinceCode(String provinceCode) {
        this.provinceCode = provinceCode == null ? null : provinceCode.trim();
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode == null ? null : cityCode.trim();
    }

    public String getDistrictCode() {
        return districtCode;
    }

    public void setDistrictCode(String districtCode) {
        this.districtCode = districtCode == null ? null : districtCode.trim();
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getExtend1() {
        return extend1;
    }

    public void setExtend1(String extend1) {
        this.extend1 = extend1 == null ? null : extend1.trim();
    }

    public String getExtend2() {
        return extend2;
    }

    public void setExtend2(String extend2) {
        this.extend2 = extend2 == null ? null : extend2.trim();
    }

    public String getExtend3() {
        return extend3;
    }

    public void setExtend3(String extend3) {
        this.extend3 = extend3 == null ? null : extend3.trim();
    }

    public String getAuditStatus() {
        return auditStatus;
    }

    public void setAuditStatus(String auditStatus) {
        this.auditStatus = auditStatus == null ? null : auditStatus.trim();
    }

    public String getJoinAppId() {
        return joinAppId;
    }

    public void setJoinAppId(String joinAppId) {
        this.joinAppId = joinAppId == null ? null : joinAppId.trim();
    }

    public String getJoinTimestamp() {
        return joinTimestamp;
    }

    public void setJoinTimestamp(String joinTimestamp) {
        this.joinTimestamp = joinTimestamp == null ? null : joinTimestamp.trim();
    }

    public String getBankAppId() {
        return bankAppId;
    }

    public void setBankAppId(String bankAppId) {
        this.bankAppId = bankAppId == null ? null : bankAppId.trim();
    }

    public String getFeeRateId() {
        return feeRateId;
    }

    public void setFeeRateId(String feeRateId) {
        this.feeRateId = feeRateId == null ? null : feeRateId.trim();
    }

    public String getPayFeeRateNoWx() {
        return payFeeRateNoWx;
    }

    public void setPayFeeRateNoWx(String payFeeRateNoWx) {
        this.payFeeRateNoWx = payFeeRateNoWx == null ? null : payFeeRateNoWx.trim();
    }

    public String getFeeRateWx() {
        return feeRateWx;
    }

    public void setFeeRateWx(String feeRateWx) {
        this.feeRateWx = feeRateWx == null ? null : feeRateWx.trim();
    }

    public String getPayFeeRateNoZfb() {
        return payFeeRateNoZfb;
    }

    public void setPayFeeRateNoZfb(String payFeeRateNoZfb) {
        this.payFeeRateNoZfb = payFeeRateNoZfb == null ? null : payFeeRateNoZfb.trim();
    }

    public String getFeeRateZfb() {
        return feeRateZfb;
    }

    public void setFeeRateZfb(String feeRateZfb) {
        this.feeRateZfb = feeRateZfb == null ? null : feeRateZfb.trim();
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName == null ? null : accountName.trim();
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo == null ? null : accountNo.trim();
    }

    public String getAccountProp() {
        return accountProp;
    }

    public void setAccountProp(String accountProp) {
        this.accountProp = accountProp == null ? null : accountProp.trim();
    }

    public String getProvinceCodeJs() {
        return provinceCodeJs;
    }

    public void setProvinceCodeJs(String provinceCodeJs) {
        this.provinceCodeJs = provinceCodeJs == null ? null : provinceCodeJs.trim();
    }

    public String getCityCodeJs() {
        return cityCodeJs;
    }

    public void setCityCodeJs(String cityCodeJs) {
        this.cityCodeJs = cityCodeJs == null ? null : cityCodeJs.trim();
    }

    public String getBankBranchNo() {
        return bankBranchNo;
    }

    public void setBankBranchNo(String bankBranchNo) {
        this.bankBranchNo = bankBranchNo == null ? null : bankBranchNo.trim();
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName == null ? null : bankName.trim();
    }

    public String getBankBranch() {
        return bankBranch;
    }

    public void setBankBranch(String bankBranch) {
        this.bankBranch = bankBranch == null ? null : bankBranch.trim();
    }

    public String getIdCardNoJs() {
        return idCardNoJs;
    }

    public void setIdCardNoJs(String idCardNoJs) {
        this.idCardNoJs = idCardNoJs == null ? null : idCardNoJs.trim();
    }

    public String getAliStatus() {
        return aliStatus;
    }

    public void setAliStatus(String aliStatus) {
        this.aliStatus = aliStatus == null ? null : aliStatus.trim();
    }

    public String getWxStatus() {
        return wxStatus;
    }

    public void setWxStatus(String wxStatus) {
        this.wxStatus = wxStatus == null ? null : wxStatus.trim();
    }

    public String getAliAuditStatus() {
        return aliAuditStatus;
    }

    public void setAliAuditStatus(String aliAuditStatus) {
        this.aliAuditStatus = aliAuditStatus == null ? null : aliAuditStatus.trim();
    }

    public String getWxAuditStatus() {
        return wxAuditStatus;
    }

    public void setWxAuditStatus(String wxAuditStatus) {
        this.wxAuditStatus = wxAuditStatus == null ? null : wxAuditStatus.trim();
    }

    public String getResponseUrl() {
        return responseUrl;
    }

    public void setResponseUrl(String responseUrl) {
        this.responseUrl = responseUrl == null ? null : responseUrl.trim();
    }

    public String getTranceNo() {
        return tranceNo;
    }

    public void setTranceNo(String tranceNo) {
        this.tranceNo = tranceNo == null ? null : tranceNo.trim();
    }
}