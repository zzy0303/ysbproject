package com.uns.organization.modules.organization.web;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uns.organization.common.exception.BusinessException;
import com.uns.organization.modules.organization.entity.*;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.alibaba.fastjson.JSONArray;
import com.uns.organization.common.persistence.Page;
import com.uns.organization.common.utils.Constants;
import com.uns.organization.common.web.BaseController;
import com.uns.organization.modules.organization.service.InstitutionService;
import com.uns.organization.modules.organization.service.SysAreaService;
/**
 * 机构管理Controller
 * @author yang.cheng
 *
 */
@Controller
@RequestMapping(value = "${adminPath}/ins/institution")
public class InstitutionController extends BaseController {

	@Autowired
	InstitutionService institutionService;

	@Autowired
	SysAreaService sysAreaService;

	/**
	 * 机构查询管理
	 * @param institution
	 * @param model
	 * @return
	 */
	@RequestMapping(value = {"list", ""})
	public String list(Institution institution,HttpServletRequest request, HttpServletResponse response, Model model) {
		try {
			Page<Institution> page = institutionService.findInstitutionList(new Page<Institution>(request, response), institution);
	        model.addAttribute("page", page);
	        List<SysArea> allProvince = sysAreaService.findAllProvince();// 查询所有省
	        model.addAttribute("allProvince", allProvince);
		} catch (Exception e) {
			logger.error("机构查询异常！"+e);
			addMessage(model, "机构查询失败！"+e.getMessage());
		}
		return "modules/institution/institutionList";
	}

	/**
	 * 添加或修改,页面
	 * @param institution
	 * @param model
	 * @return
	 */
	@RequiresPermissions("ins:institution:add")
	@RequestMapping(value = "form")
	public String form(Institution institution, Model model,RedirectAttributes redirectAttributes) {
		try {
			if(institution.getInsId()!=null){
				institution = institutionService.findInstitutionById(institution.getInsId());
				List<InstitutionFee> InstitutionFeeList = institutionService.findInsFeeList(institution.getInsNo());
				institution = institutionService.setInstitutionFee(institution, InstitutionFeeList);
				//查询商户扫码费率区间
				List<InsCommissionType> insCommissionTypeList = institutionService.findInsComType(institution.getInsNo());
				institution = institutionService.splitInsComType(institution,insCommissionTypeList);
			}
			List<SysArea> allProvince = sysAreaService.findAllProvince();// 查询所有省
			model.addAttribute("allProvince", allProvince);
			model.addAttribute("institution", institution);
			return "modules/institution/institutionForm";
		} catch (Exception e) {
			logger.error("跳转添加，修改页面异常", e);
			addMessage(redirectAttributes, "跳转添加，修改页面失败！"+e.getMessage());
			return "redirect:" + adminPath + "/ins/institution/list?repage";
		 }

	}

	/**
	 * 跳转到机构详情页
	 * @param insId
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "details")
	public String institutionDetails(Long insId,Model model) {
		try {
			Institution institution = institutionService.findInstitutionById(insId);
            /*//区分商户费率区间上下限
            institutionService.merRateRange(institution);*/
			institution.setBusinessTypeList(Arrays.asList(institution.getBusinessType().split(",")));
			List<InstitutionFee> InstitutionFeeList = institutionService.findInsFeeList(institution.getInsNo());
			List<InsCommissionType> commissionRange = institutionService.findComRange(institution.getInsNo());
			//控制费率类型
			institutionService.settleCommissionType(InstitutionFeeList,commissionRange,institution.getCommissionType());
			model.addAttribute("institution", institution);
			model.addAttribute("InstitutionFeeList", InstitutionFeeList);
			model.addAttribute("commissionRange", commissionRange);
		} catch (Exception e) {
			logger.error("查询机构详情异常", e);
			addMessage(model, "查询机构详情失败！"+e.getMessage());
		}
		return "modules/institution/institutionDetails";
	}

	/**
	 * 保存机构信息，添加/修改
	 * @param institution
	 * @param model
	 * @return
	 */
	@RequiresPermissions("ins:institution:add")
	@RequestMapping(value = "save")
	public String save(Institution institution, Model model,RedirectAttributes redirectAttributes) {
		try {
			institutionService.saveInstitution(institution);
			addMessage(redirectAttributes, "保存机构信息成功！");
		} catch (BusinessException be) {
			addMessage(redirectAttributes,"保存机构信息失败！"+ be.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			addMessage(redirectAttributes, "保存机构信息失败！"+e.getMessage());
		}
		return "redirect:" + adminPath + "/ins/institution/list?repage";
	}

	/**
	 * 查询省的下属市
	 * @param level
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "selectProvinceAllCity")
	@ResponseBody
	public String selectProvinceAllCity(HttpServletRequest request, HttpServletResponse response, String level) {
		List<SysArea> allCity = sysAreaService.provinceAllCity(level);// 异步联动查询城市
		request.setAttribute("allProvince", allCity);
		try {
			response.setContentType("UTF-8");
			String city = JSONArray.toJSONString(allCity);// jsong转换String
			return  city;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 查询费率修改历史
	 * @param institutionFeeHis
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "feeHisList")
	public String feeHisList(InstitutionFeeHis institutionFeeHis,HttpServletRequest request, HttpServletResponse response,Model model){
		try {
			Page<InstitutionFeeHis> page = institutionService.findInstitutionFeeHisList(new Page<InstitutionFeeHis>(request, response), institutionFeeHis);
			model.addAttribute("insFeeHis",institutionFeeHis);
			model.addAttribute("page", page);
		} catch (Exception e) {
			logger.error("查询费率历史异常！", e);
			addMessage(model, "查询费率历史失败！"+e.getMessage());
		}
		return "modules/institution/institutionFeeHisList";
	}

	/**
	 * 验证机构手机号是否有效
	 * @param oldInsTel
	 * @param insTel
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "checkInsTel")
	public String checkInsTel(String oldInsTel, String insTel) {
		if (insTel !=null && insTel.equals(oldInsTel)) {
			return "true";
		} else if (insTel !=null && institutionService.getCountByInstel(insTel)==0) {
			return "true";
		}
		return "false";
	}

	/**
	 * 查询机构注册身份证号是否存在
	 * @param thisIdCardNo
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "isIdCardExist")
	public String isIdCardExist(String thisIdCardNo){
		List<Institution> Ins = institutionService.findInstitutionByIdCardNo(thisIdCardNo);
		if(Ins.isEmpty()){
			return "notExist";
		}else{
			return "exist";
		}
	}
}
