package com.uns.organization.modules.organization.dao;

import com.uns.organization.common.persistence.annotation.MyBatisDao;
import com.uns.organization.modules.organization.entity.CmbJoinInfo;

import java.util.List;

import org.apache.ibatis.annotations.Param;

@MyBatisDao
public interface CmbJoinInfoMapper {
    int deleteByPrimaryKey(Long infoId);

    int insert(CmbJoinInfo record);

    int insertSelective(CmbJoinInfo record);

    CmbJoinInfo selectByPrimaryKey(Long infoId);

    int updateByPrimaryKeySelective(CmbJoinInfo record);

    int updateByPrimaryKey(CmbJoinInfo record);
}