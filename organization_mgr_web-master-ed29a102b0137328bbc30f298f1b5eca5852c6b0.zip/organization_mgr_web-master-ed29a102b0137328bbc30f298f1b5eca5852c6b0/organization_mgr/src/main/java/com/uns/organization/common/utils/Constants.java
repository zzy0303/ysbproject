package com.uns.organization.common.utils;
/**
 * 常量
 * @author yang.cheng
 *
 */
public class Constants {
	/**
	 * 机构编码开始3位
	 */
	public static final String INS_START_NO ="100";
	/**
	 * 机构费率类型
	 * 2 微信二维码 3支付宝二维码  4 银联 5 快键 6 b2c  7 速惠  8秒到 9即时 10 T1 13 支付宝APP 14 支付宝H5 15 微信APP 16 微信公众号
     */
	public static final String INS_FEE_TYPE_2="2";
	public static final String INS_FEE_TYPE_3="3";
	public static final String INS_FEE_TYPE_4="4";
	public static final String INS_FEE_TYPE_5="5";
	public static final String INS_FEE_TYPE_6="6";
	public static final String INS_FEE_TYPE_7="7";
	public static final String INS_FEE_TYPE_8="8";
	public static final String INS_FEE_TYPE_9="9";
	public static final String INS_FEE_TYPE_10="10";
	public static final String INS_FEE_TYPE_13="13";
	public static final String INS_FEE_TYPE_14="14";
	public static final String INS_FEE_TYPE_15="15";
	public static final String INS_FEE_TYPE_16="16";
	public static final String NOT_SMFEE_TYPE = "4,5,6,7,8,9,10";

	/**
	 * 接口返回成功code
	 */
	public static final String RESULT_SUCCESS="0000";
	
	/**
	 * 创建默认机构操作账号的初始密码 123456
	 */
	public static final String INS_OPERATOR_INIT_PASSWORD="E10ADC3949BA59ABBE56E057F20F883E";
	/**
	 * 创建默认机构操作账号的默认角色
	 */
	public static final String INS_OPERATOR_INIT_ROLE="1";
	/**
	 * 机构默认操作账号
	 */
	public static final String INS_OPERATOR_DEFAULT="1";
	/**
	 * 创建默认机构操作账号的默认状态：0  正常
	 */
	public static final String INS_OPERATOR_INIT_STATUS="0";
	/**
	 * 机构入驻接口userType ：P:个人  ，C:企业
	 */
	public static final String REGISTER_INSTITUTION_USERTYPE_P="P";
	public static final String REGISTER_INSTITUTION_USERTYPE_C="C";
	
	//验证码
	public static final String SESSION_VERIFY_CODE="sessionVerifycode";
	//成功信息
	public static final String MESSAGE_KEY="message";
	//错误消息
	public static final String ERROR_MESSAGE = "errMsg";
	//操作员个人信息Session
	public static final String SESSION_KEY_USER="sessionUser";
	//时间格式
	public static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd";

	public static final String STATUS_0 = "0";
	public static final String STATUS_1 = "1";
	public static final String STATUS_2 = "2";
	public static final String STATUS_3 = "3";
	public static final String STATUS_4 = "4";
	//查询 页面条数
	public static final int FIND_PAGE_LIST = 20;
	//错误
	public static final String SMALL_MERCH_NO_NOT_EXIST = "商户号不存在";
	
	/**
	 * 交易流水导出excel,每页50000行
	 */
	public static  int EXCEL_SIZE=50000;
	public static final String CON_YES = "1";
	public static final String CON_NO = "0";
	
	//审核状态
	public static final String CHECKSTATUS_NO_CHECK = "0";
	public static final String CHECKSTATUS_PASS = "1";
	public static final String CHECKSTATUS_NOT_PASS = "2";
	public static final String STRING_NULL = "";
	
	/**
	 * 机构操作员状态,0:正常，1：注销，2：冻结，3：锁定
	 */
	public static final String INS_OPERATOR_STATUS_0 = "0";
	public static final String INS_OPERATOR_STATUS_1 = "1";
	public static final String INS_OPERATOR_STATUS_2 = "2";
	public static final String INS_OPERATOR_STATUS_3 = "3";
	

	public static final Long LONG_ONE = 1L;
	
	public static final String PORT_RESULT_STATUS = "status";
	public static final String PORT_RESULT_STATUS_ERROR = "error";
	public static final String PORT_RESULT_MCH_APP_ID = "mch_app_id";
	public static final String PORT_RESULT_BANK_APP_ID = "bank_app_id";
	
	
	/**
	 * 接口调用完毕，但是异步通知没有收到，此时商户的报件审核状态应该为待确认
	 */
	public static final String AUDIT_STATUS_7 = "7";
	public static final String AUDIT_STATUS_6 = "6";

	/**
	 * 机构业务类型，0：扫码，1：快捷，2：无卡
	 */
	public static final String INS_BUSINESS_TYPE_0 = "0";
	public static final String INS_BUSINESS_TYPE_1 = "1";
	public static final String INS_BUSINESS_TYPE_2 = "2";
	
	/**
	 * 机构角色状态，1：有效，2：无效
	 */
	public static final String INS_ROLE_STATUS_1 = "1";
	public static final String INS_ROLE_STATUS_2 = "2";
	
	/**
	 *机构角色版本，1：运营后台添加的角色
	 */
	public static final String INS_ROLE_VERSION_1 = "1";

	public static final String DYNAMICT1AMOUNT = "insDynamicT1Amount";//动态码T1 交易限额

	public static final String DYNAMICT1TIME = "insDynamicT1Time";//动态码 T1 交易时间

	public static final String DYNAMICD0AMOUNT="insDynamicD0Amount";//动态码D0 交易金额

	public static final String DYNAMICD0TIME = "insDynamicD0Time";//动态码D0 交易时间

	public static final String FIXEDT1AMOUNT = "insFixedT1Amount";//固定码T1交易金额

	public static final String FIXEDT1TIME = "insFixedT1Time";//固定码T1交易时间

	public static final String FIXEDD0AMOUNT = "insFixedD0Amount";//固定码D0交易金额

	public static final String FIXEDD0TIME = "insFixedD0Time";//固定码D0交易时间

	public static final String QUICKT1AMOUNT = "insShQuickPayT1Amount";//快捷T1交易金额

    public static final String QUICKT1TIME = "insShQuickPayT1Time"; //快捷T1交易时间

    public static final String QUICKD0AMOUNT = "insShQuickPayD0Amount"; //快捷D0单笔限额

    public static final String QUICKD0TIME = "insShQuickPayD0Time"; //快捷D0交易时间

    public static final String QUICKSHD0AMOUNT = "shQuickPayD0Amount";//速惠快捷D0单笔限额

    public static final String QUICKSHD0TIME = "shQuickPayD0Time";//速惠快捷D0交易时间

    public static final String KEY_NAME = "KEY_NAME";

    public static final String KEY_VALUE = "KEY_VALUE";

}
