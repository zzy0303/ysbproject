package com.uns.organization.modules.organization.dao;

import java.util.List;

import com.uns.organization.common.persistence.annotation.MyBatisDao;
import com.uns.organization.modules.organization.entity.InsRoleInfo;
import com.uns.organization.modules.sys.entity.Menu;
@MyBatisDao
public interface InsRoleInfoMapper {

    int deleteByPrimaryKey(String id);

    int insert(InsRoleInfo record);

    int insertSelective(InsRoleInfo record);

    InsRoleInfo selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(InsRoleInfo record);

    int updateByPrimaryKey(InsRoleInfo record);

	List<InsRoleInfo> findInsRoleFunftionList(InsRoleInfo insRoleInfo);
	
	List<InsRoleInfo> findInsRoleList(InsRoleInfo insRoleInfo);

	List<Menu> findAllMenu();
	
	int deleteRoleFunction(String roleId);
	
	int insertRoleFunction(InsRoleInfo insRoleInfo);

	String[] findFunctionByInsRole(String insRoleId);

	InsRoleInfo findInsRoleByRoleName(String roleName);
}