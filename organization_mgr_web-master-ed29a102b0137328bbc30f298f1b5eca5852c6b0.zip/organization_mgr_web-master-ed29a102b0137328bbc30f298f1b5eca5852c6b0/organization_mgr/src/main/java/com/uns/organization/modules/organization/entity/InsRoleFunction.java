package com.uns.organization.modules.organization.entity;

import java.math.BigDecimal;

public class InsRoleFunction {
    private BigDecimal functionId;

    private BigDecimal roleId;

    public BigDecimal getFunctionId() {
        return functionId;
    }

    public void setFunctionId(BigDecimal functionId) {
        this.functionId = functionId;
    }

    public BigDecimal getRoleId() {
        return roleId;
    }

    public void setRoleId(BigDecimal roleId) {
        this.roleId = roleId;
    }
}