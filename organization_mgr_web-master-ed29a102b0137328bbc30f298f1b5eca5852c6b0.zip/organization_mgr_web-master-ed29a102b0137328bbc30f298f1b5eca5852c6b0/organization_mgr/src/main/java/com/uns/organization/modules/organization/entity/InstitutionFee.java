package com.uns.organization.modules.organization.entity;

import java.math.BigDecimal;
import java.util.Date;

public class InstitutionFee {
    private BigDecimal insFeeId;

    private String insNo;

    private Date createDate;

    private Date updateDate;

    private String insFeeType;

    private String fee;

    private String d0Fee;

    private String createUser;

    private String updateUser;
    
    private BigDecimal fixFee;

    private BigDecimal d0FixFee;

    public BigDecimal getD0FixFee() {
        return d0FixFee;
    }

    public void setD0FixFee(BigDecimal d0FixFee) {
        this.d0FixFee = d0FixFee;
    }

    public BigDecimal getFixFee() {
		return fixFee;
	}

	public void setFixFee(BigDecimal fixFee) {
		this.fixFee = fixFee;
	}

	public BigDecimal getInsFeeId() {
        return insFeeId;
    }

    public void setInsFeeId(BigDecimal insFeeId) {
        this.insFeeId = insFeeId;
    }

    public String getInsNo() {
        return insNo;
    }

    public void setInsNo(String insNo) {
        this.insNo = insNo;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getInsFeeType() {
        return insFeeType;
    }

    public void setInsFeeType(String insFeeType) {
        this.insFeeType = insFeeType == null ? null : insFeeType.trim();
    }

    public String getFee() {
        return fee;
    }

    public void setFee(String fee) {
        this.fee = fee == null ? null : fee.trim();
    }

    public String getD0Fee() {
        return d0Fee;
    }

    public void setD0Fee(String d0Fee) {
        this.d0Fee = d0Fee == null ? null : d0Fee.trim();
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser == null ? null : createUser.trim();
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser == null ? null : updateUser.trim();
    }
}