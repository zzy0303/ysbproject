package com.uns.organization.modules.organization.entity;

import com.uns.organization.common.persistence.DataEntity;
import com.uns.organization.common.utils.excel.annotation.ExcelField;
import com.uns.organization.modules.sys.utils.DictUtils;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class InsSplitProfitSm extends DataEntity<InsSplitProfitSm> implements Serializable {

    private Date setDate;

    private String channelType;

    private String feeType;

    private String outtradeno;

    private String outtradetime;

    private BigDecimal amount;

    private BigDecimal commission;

    private BigDecimal arrivalamount;

    private String insNo;

    private String insName;

    private BigDecimal smFee;

    private BigDecimal profit;

    private String batchNo;

    private BigDecimal customerid;

    private BigDecimal commissionid;

    private String feever;

    private String remark;

    private String shopperid;

    private String smallMerchNo;

    private String shopperName;

    private String beginDate;
    private String endDate;

    private String scompany;

    private Date createDate;
    private BigDecimal insFee;

    private String oriOrderId;

    private BigDecimal cusFixFee;
    private BigDecimal cusD0FixFee;
    private BigDecimal insFixFee;
    private BigDecimal insD0FixFee;



    public void setCusFixFee(BigDecimal cusFixFee) {
        this.cusFixFee = cusFixFee;
    }

    public BigDecimal getCusD0FixFee() {
        return cusD0FixFee;
    }

    public void setCusD0FixFee(BigDecimal cusD0FixFee) {
        this.cusD0FixFee = cusD0FixFee;
    }

    public void setInsFixFee(BigDecimal insFixFee) {
        this.insFixFee = insFixFee;
    }

    public BigDecimal getInsD0FixFee() {
        return insD0FixFee;
    }

    public void setInsD0FixFee(BigDecimal insD0FixFee) {
        this.insD0FixFee = insD0FixFee;
    }

    public void setInsFee(BigDecimal insFee) {
		this.insFee = insFee;
	}

	public String getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(String beginDate) {
        this.beginDate = beginDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public Date getSetDate() {
        return setDate;
    }

    public void setSetDate(Date setDate) {
        this.setDate = setDate;
    }

    public String getChannelType() {
        return channelType;
    }

    public void setChannelType(String channelType) {
        this.channelType = channelType == null ? null : channelType.trim();
    }

    public void setFeeType(String feeType) {
        this.feeType = feeType == null ? null : feeType.trim();
    }

    public void setOuttradeno(String outtradeno) {
        this.outtradeno = outtradeno == null ? null : outtradeno.trim();
    }

    public String getOuttradetime() {
        return outtradetime;
    }

    public void setOuttradetime(String outtradetime) {
        this.outtradetime = outtradetime == null ? null : outtradetime.trim();
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public void setCommission(BigDecimal commission) {
        this.commission = commission;
    }

    public void setArrivalamount(BigDecimal arrivalamount) {
        this.arrivalamount = arrivalamount;
    }

    public void setInsNo(String insNo) {
        this.insNo = insNo == null ? null : insNo.trim();
    }

    public void setSmFee(BigDecimal smFee) {
        this.smFee = smFee;
    }

    public void setProfit(BigDecimal profit) {
        this.profit = profit;
    }


    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo == null ? null : batchNo.trim();
    }

    public BigDecimal getCustomerid() {
        return customerid;
    }

    public void setCustomerid(BigDecimal customerid) {
        this.customerid = customerid;
    }

    public BigDecimal getCommissionid() {
        return commissionid;
    }

    public void setCommissionid(BigDecimal commissionid) {
        this.commissionid = commissionid;
    }

    public String getFeever() {
        return feever;
    }

    public void setFeever(String feever) {
        this.feever = feever == null ? null : feever.trim();
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getShopperid() {
        return shopperid;
    }

    public void setShopperid(String shopperid) {
        this.shopperid = shopperid == null ? null : shopperid.trim();
    }

    public void setInsName(String insName) {
        this.insName = insName;
    }

    public String getShopperName() {
        return shopperName;
    }

    public void setShopperName(String shopperName) {
        this.shopperName = shopperName;
    }

    public void setSmallMerchNo(String smallMerchNo) {
        this.smallMerchNo = smallMerchNo;
    }

    public void setScompany(String scompany) {
        this.scompany = scompany;
    }

    @Override
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    @ExcelField(title="订单编号   ", align=1, sort=1)
    public String getOriOrderId() {
        return oriOrderId;
    }
    public String getOuttradeno() {
        return outtradeno;
    }

    @ExcelField(title="机构编号   ", align=1, sort=2)
    public String getInsNo() {
        return insNo;
    }

    @ExcelField(title="机构名称   ", align=1, sort=3)
    public String getInsName() {
        return insName;
    }

    @ExcelField(title="商户编号   ", align=1, sort=4)
    public String getSmallMerchNo() {
        return smallMerchNo;
    }

    @ExcelField(title="商户名称   ", align=1, sort=5)
    public String getScompany() {
        return scompany;
    }

    @Override
    @ExcelField(title="交易时间   ", align=1, sort=6)
    public Date getCreateDate() {
        return createDate;
    }

    @ExcelField(title="收款方式", align=1, sort=7)
    public String getChannelTypeStr() {
        return DictUtils.getDictLabel(this.channelType, "CHANNEL_TYPE", "");
    }

    @ExcelField(title="费率类型", align=1, sort=8)
    public String getFeeType() {
        return feeType;
    }

    @ExcelField(title="商户费率%", align=1, sort=9)
    public BigDecimal getSmFee() {
        return smFee;
    }

    @ExcelField(title = "商户固定值",align = 1,sort = 10)
    public BigDecimal getCusFixFee() {
        if(getFeeType() != null ){
            if(getFeeType().toString().equals("T1")){
                return this.cusFixFee =  cusFixFee;
            } else{
                return this.cusFixFee =  cusD0FixFee;
            }
        }
        return cusFixFee;
    }
    @ExcelField(title="机构底价费率", align=1, sort=11)
    public BigDecimal getInsFee() {
		return insFee;
	}

	@ExcelField(title = "机构固定值", align = 1,sort = 12)
    public BigDecimal getInsFixFee() {
        if(getFeeType() != null ){
            if(getFeeType().toString().equals("T1")){
                return this.insFixFee = insFixFee;
            } else{
                return this.insFixFee = insD0FixFee;
            }
        }
        return insFixFee;
    }
    @ExcelField(title="收款金额", align=1, sort=13)
    public BigDecimal getAmount() {
        return amount;
    }

    @ExcelField(title="手续费", align=1, sort=14)
    public BigDecimal getCommission() {
        return commission;
    }

    @ExcelField(title="到账金额", align=1, sort=15)
    public BigDecimal getArrivalamount() {
        return arrivalamount;
    }

    @ExcelField(title="分润金额", align=1, sort=16)
    public BigDecimal getProfit() {
        return profit;
    }



    public void setOriOrderId(String oriOrderId) {
        this.oriOrderId = oriOrderId;
    }
}