package com.uns.organization.modules.organization.entity;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.uns.organization.common.persistence.DataEntity;

public class Institution extends DataEntity<Institution>{

	private static final long serialVersionUID = 1L;

	private Long insId;

    private String insNo;

    private String insName;

    private String insPubKey;

    private Long accountBankId;

    private Date createTime;

    private Date updateTime;

    private String businessSwitch;

    private String supportD0Switch;

    private String zfbAppId;

    private String zfbPubKey;

    private String zfbPriKey;

    private String wxAppId;

    private String wxAppSecret;

    private String insShortName;

    private String insTel;

    private String insProvince;

    private String insProvinceName;

    private String insCity;

    private String insCityName;

    private String insSrelation;

    private String insFax;

    private String insEmail;

    private String insZip;

    private String insAddress;

    private String insYnum;

    private String insBankCode;

    private String insBankName;

    private String insSubBankName;

    private String insBankClientName;

    private String insBankCardNo;

    private Long ysbuserid;

    private Long cascustomid;
    
    private String businessType;

    private List<String> businessTypeList;

    private String idcardNo;
    private String openProvince;
    private String openCity;
    private String settleType;

    //是否修改费率
    private boolean editFee=false;

    //商户结算周期
    private String merSettleCycle;
    //商户费率区间
    private String merRateRange;
    private String merRateRangeUp;

    //扫码费率信息
    private String wxFee;//微信二维码T1签约费率
    private String wxD0Fee;//微信二维码D0签约费率
    private String wxAppFee;//微信App D0签约费率
    private String wxAppD0Fee;//微信App D0签约费率
    private String wxGzhFee;//微信公众号 T1签约费率
    private String wxGzhD0Fee;//微信公众号 D0签约费率
    private String zfbFee;//支付宝二维码T1签约费率
    private String zfbD0Fee;//支付宝二维码D0签约费率
    private String zfbAppFee;//支付宝App T1签约费率
    private String zfbAppD0Fee;//支付宝App D0签约费率
    private String zfbH5Fee;//支付宝H5 T1签约费率
    private String zfbH5D0Fee;//支付宝H5 D0签约费率

    //刷卡费率'
    private String mdDjFee;//秒到收款贷记卡费率
    private String mdJjFee;//秒到收款借记卡费率
    private BigDecimal mdFixFee;//秒到收款固定金额
    private BigDecimal mdJjFixFee;//秒到收款借记卡固定金额
    private String jsDjFee;//即时收款贷记卡费率
    private String jsJjFee;//即时收款借记卡费率
    private BigDecimal jsFixFee;//即时收款固定金额
    private BigDecimal jsJjFixFee;//即时收款借记卡固定金额

    //无卡费率
    private String shD0Fee;//快捷速惠D0费率
    private String ysD0Fee;//快捷优速D0费率
    private String kjD0Fee;//快捷D0费率
    private String kjT1Fee;//快捷T1费率
    private String b2cD0Fee;//B2C D0费率
    private String b2cT1Fee;//B2C T1费率

    //固定费率
    private BigDecimal wxT1Fixation;//微信T1固定金额
    private BigDecimal wxD0Fixation;//微信D0固定金额
    private BigDecimal wxAppT1Fixation;//微信App T1固定金额
    private BigDecimal wxAppD0Fixation;//微信App D0固定金额
    private BigDecimal wxGzhT1Fixation;//微信公众号T1固定金额
    private BigDecimal wxGzhD0Fixation;//微信公众号D0固定金额
    private BigDecimal zfbT1ixation;//支付宝T1固定金额
    private BigDecimal zfbD0Fixation;//支付宝D0固定金额
    private BigDecimal zfbAppT1ixation;//支付宝App T1固定金额
    private BigDecimal zfbAppD0Fixation;//支付宝App D0固定金额
    private BigDecimal zfbH5T1ixation;//支付宝H5 T1固定金额
    private BigDecimal zfbH5D0Fixation;//支付宝H5 D0固定金额
    private BigDecimal shFixation; //快捷速惠D0固定金额
    private BigDecimal kjD0Fixation;//快捷D0固定金额
    private BigDecimal kjT1Fixation;//快捷T1固定金额
    private BigDecimal b2cD0Fixation;//B2C D0固定金额
    private BigDecimal b2cT1Fixation;//B2C T1固定金额

    private String commissionType; //费率类型

    //商户扫码费率区间
    private BigDecimal zfbRangeLow; //支付宝二维码T1下限
    private BigDecimal zfbRangeUpp; //支付宝二维码T1上限
    private BigDecimal zfbFixRangeLow; //支付宝二维码T1固定值上限
    private BigDecimal zfbFixRangeUpp; //支付宝二维码T1固定值下限
    private BigDecimal zfbD0RangeLow; //支付宝二维码D0下限
    private BigDecimal zfbD0RangeUpp; //支付宝二维码D0上限
    private BigDecimal zfbD0FixRangeLow; //支付宝二维码D0固定值上限
    private BigDecimal zfbD0FixRangeUpp; //支付宝二维码D0固定值下限

    private BigDecimal wxRangeLow; //微信二维码T1上限
    private BigDecimal wxRangeUpp; //微信二维码T1下限
    private BigDecimal wxFixRangeLow; //微信二维码T1上限
    private BigDecimal wxFixRangeUpp; //微信二维码T1下限
    private BigDecimal wxD0RangeLow; //微信二维码D0上限
    private BigDecimal wxD0RangeUpp; //微信二维码D0下限
    private BigDecimal wxD0FixRangeLow; //微信二维码D0上限
    private BigDecimal wxD0FixRangeUpp; //微信二维码D0下限
    private BigDecimal zfbAppRangeLow; //支付宝AppT1下限
    private BigDecimal zfbAppRangeUpp; //支付宝AppT1上限
    private BigDecimal zfbAppFixRangeLow; //支付宝AppT1固定值上限
    private BigDecimal zfbAppFixRangeUpp; //支付宝AppT1固定值下限
    private BigDecimal zfbAppD0RangeLow; //支付宝AppD0下限
    private BigDecimal zfbAppD0RangeUpp; //支付宝AppD0上限
    private BigDecimal zfbAppD0FixRangeLow; //支付宝AppD0固定值上限
    private BigDecimal zfbAppD0FixRangeUpp; //支付宝AppD0固定值下限
    private BigDecimal wxAppRangeLow; //微信AppT1上限
    private BigDecimal wxAppRangeUpp; //微信AppT1下限
    private BigDecimal wxAppFixRangeLow; //微信AppT1上限
    private BigDecimal wxAppFixRangeUpp; //微信AppT1下限
    private BigDecimal wxAppD0RangeLow; //微信AppD0上限
    private BigDecimal wxAppD0RangeUpp; //微信AppD0下限
    private BigDecimal wxAppD0FixRangeLow; //微信AppD0上限
    private BigDecimal wxAppD0FixRangeUpp; //微信AppD0下限
    private BigDecimal zfbH5RangeLow; //支付宝H5T1下限
    private BigDecimal zfbH5RangeUpp; //支付宝H5T1上限
    private BigDecimal zfbH5FixRangeLow; //支付宝H5T1固定值上限
    private BigDecimal zfbH5FixRangeUpp; //支付宝H5T1固定值下限
    private BigDecimal zfbH5D0RangeLow; //支付宝H5D0下限
    private BigDecimal zfbH5D0RangeUpp; //支付宝H5D0上限
    private BigDecimal zfbH5D0FixRangeLow; //支付宝H5D0固定值上限
    private BigDecimal zfbH5D0FixRangeUpp; //支付宝H5D0固定值下限
    private BigDecimal wxGzhRangeLow; //微信GzhT1上限
    private BigDecimal wxGzhRangeUpp; //微信GzhT1下限
    private BigDecimal wxGzhFixRangeLow; //微信GzhT1上限
    private BigDecimal wxGzhFixRangeUpp; //微信GzhT1下限
    private BigDecimal wxGzhD0RangeLow; //微信GzhD0固定值上限
    private BigDecimal wxGzhD0RangeUpp; //微信GzhD0固定值下限
    private BigDecimal wxGzhD0FixRangeLow; //微信GzhD0固定值上限
    private BigDecimal wxGzhD0FixRangeUpp; //微信GzhD0固定值下限

    public BigDecimal getZfbRangeUpp() {
        return zfbRangeUpp;
    }

    public void setZfbRangeUpp(BigDecimal zfbRangeUpp) {
        this.zfbRangeUpp = zfbRangeUpp;
    }

    public BigDecimal getZfbFixRangeLow() {
        return zfbFixRangeLow;
    }

    public void setZfbFixRangeLow(BigDecimal zfbFixRangeLow) {
        this.zfbFixRangeLow = zfbFixRangeLow;
    }

    public BigDecimal getZfbFixRangeUpp() {
        return zfbFixRangeUpp;
    }

    public void setZfbFixRangeUpp(BigDecimal zfbFixRangeUpp) {
        this.zfbFixRangeUpp = zfbFixRangeUpp;
    }

    public BigDecimal getZfbD0RangeLow() {
        return zfbD0RangeLow;
    }

    public void setZfbD0RangeLow(BigDecimal zfbD0RangeLow) {
        this.zfbD0RangeLow = zfbD0RangeLow;
    }

    public BigDecimal getZfbD0RangeUpp() {
        return zfbD0RangeUpp;
    }

    public void setZfbD0RangeUpp(BigDecimal zfbD0RangeUpp) {
        this.zfbD0RangeUpp = zfbD0RangeUpp;
    }

    public BigDecimal getZfbD0FixRangeLow() {
        return zfbD0FixRangeLow;
    }

    public void setZfbD0FixRangeLow(BigDecimal zfbD0FixRangeLow) {
        this.zfbD0FixRangeLow = zfbD0FixRangeLow;
    }

    public BigDecimal getZfbD0FixRangeUpp() {
        return zfbD0FixRangeUpp;
    }

    public void setZfbD0FixRangeUpp(BigDecimal zfbD0FixRangeUpp) {
        this.zfbD0FixRangeUpp = zfbD0FixRangeUpp;
    }

    public BigDecimal getWxRangeLow() {
        return wxRangeLow;
    }

    public void setWxRangeLow(BigDecimal wxRangeLow) {
        this.wxRangeLow = wxRangeLow;
    }

    public BigDecimal getWxRangeUpp() {
        return wxRangeUpp;
    }

    public void setWxRangeUpp(BigDecimal wxRangeUpp) {
        this.wxRangeUpp = wxRangeUpp;
    }

    public BigDecimal getWxFixRangeLow() {
        return wxFixRangeLow;
    }

    public void setWxFixRangeLow(BigDecimal wxFixRangeLow) {
        this.wxFixRangeLow = wxFixRangeLow;
    }

    public BigDecimal getWxFixRangeUpp() {
        return wxFixRangeUpp;
    }

    public void setWxFixRangeUpp(BigDecimal wxFixRangeUpp) {
        this.wxFixRangeUpp = wxFixRangeUpp;
    }

    public BigDecimal getWxD0RangeLow() {
        return wxD0RangeLow;
    }

    public void setWxD0RangeLow(BigDecimal wxD0RangeLow) {
        this.wxD0RangeLow = wxD0RangeLow;
    }

    public BigDecimal getWxD0RangeUpp() {
        return wxD0RangeUpp;
    }

    public void setWxD0RangeUpp(BigDecimal wxD0RangeUpp) {
        this.wxD0RangeUpp = wxD0RangeUpp;
    }

    public BigDecimal getWxD0FixRangeLow() {
        return wxD0FixRangeLow;
    }

    public void setWxD0FixRangeLow(BigDecimal wxD0FixRangeLow) {
        this.wxD0FixRangeLow = wxD0FixRangeLow;
    }

    public BigDecimal getWxD0FixRangeUpp() {
        return wxD0FixRangeUpp;
    }

    public void setWxD0FixRangeUpp(BigDecimal wxD0FixRangeUpp) {
        this.wxD0FixRangeUpp = wxD0FixRangeUpp;
    }

    public BigDecimal getZfbAppRangeLow() {
        return zfbAppRangeLow;
    }

    public void setZfbAppRangeLow(BigDecimal zfbAppRangeLow) {
        this.zfbAppRangeLow = zfbAppRangeLow;
    }

    public BigDecimal getZfbAppRangeUpp() {
        return zfbAppRangeUpp;
    }

    public void setZfbAppRangeUpp(BigDecimal zfbAppRangeUpp) {
        this.zfbAppRangeUpp = zfbAppRangeUpp;
    }

    public BigDecimal getZfbAppFixRangeLow() {
        return zfbAppFixRangeLow;
    }

    public void setZfbAppFixRangeLow(BigDecimal zfbAppFixRangeLow) {
        this.zfbAppFixRangeLow = zfbAppFixRangeLow;
    }

    public BigDecimal getZfbAppFixRangeUpp() {
        return zfbAppFixRangeUpp;
    }

    public void setZfbAppFixRangeUpp(BigDecimal zfbAppFixRangeUpp) {
        this.zfbAppFixRangeUpp = zfbAppFixRangeUpp;
    }

    public BigDecimal getZfbAppD0RangeLow() {
        return zfbAppD0RangeLow;
    }

    public void setZfbAppD0RangeLow(BigDecimal zfbAppD0RangeLow) {
        this.zfbAppD0RangeLow = zfbAppD0RangeLow;
    }

    public BigDecimal getZfbAppD0RangeUpp() {
        return zfbAppD0RangeUpp;
    }

    public void setZfbAppD0RangeUpp(BigDecimal zfbAppD0RangeUpp) {
        this.zfbAppD0RangeUpp = zfbAppD0RangeUpp;
    }

    public BigDecimal getZfbAppD0FixRangeLow() {
        return zfbAppD0FixRangeLow;
    }

    public void setZfbAppD0FixRangeLow(BigDecimal zfbAppD0FixRangeLow) {
        this.zfbAppD0FixRangeLow = zfbAppD0FixRangeLow;
    }

    public BigDecimal getZfbAppD0FixRangeUpp() {
        return zfbAppD0FixRangeUpp;
    }

    public void setZfbAppD0FixRangeUpp(BigDecimal zfbAppD0FixRangeUpp) {
        this.zfbAppD0FixRangeUpp = zfbAppD0FixRangeUpp;
    }

    public BigDecimal getWxAppRangeLow() {
        return wxAppRangeLow;
    }

    public void setWxAppRangeLow(BigDecimal wxAppRangeLow) {
        this.wxAppRangeLow = wxAppRangeLow;
    }

    public BigDecimal getWxAppRangeUpp() {
        return wxAppRangeUpp;
    }

    public void setWxAppRangeUpp(BigDecimal wxAppRangeUpp) {
        this.wxAppRangeUpp = wxAppRangeUpp;
    }

    public BigDecimal getWxAppFixRangeLow() {
        return wxAppFixRangeLow;
    }

    public void setWxAppFixRangeLow(BigDecimal wxAppFixRangeLow) {
        this.wxAppFixRangeLow = wxAppFixRangeLow;
    }

    public BigDecimal getWxAppFixRangeUpp() {
        return wxAppFixRangeUpp;
    }

    public void setWxAppFixRangeUpp(BigDecimal wxAppFixRangeUpp) {
        this.wxAppFixRangeUpp = wxAppFixRangeUpp;
    }

    public BigDecimal getWxAppD0RangeLow() {
        return wxAppD0RangeLow;
    }

    public void setWxAppD0RangeLow(BigDecimal wxAppD0RangeLow) {
        this.wxAppD0RangeLow = wxAppD0RangeLow;
    }

    public BigDecimal getWxAppD0RangeUpp() {
        return wxAppD0RangeUpp;
    }

    public void setWxAppD0RangeUpp(BigDecimal wxAppD0RangeUpp) {
        this.wxAppD0RangeUpp = wxAppD0RangeUpp;
    }

    public BigDecimal getWxAppD0FixRangeLow() {
        return wxAppD0FixRangeLow;
    }

    public void setWxAppD0FixRangeLow(BigDecimal wxAppD0FixRangeLow) {
        this.wxAppD0FixRangeLow = wxAppD0FixRangeLow;
    }

    public BigDecimal getWxAppD0FixRangeUpp() {
        return wxAppD0FixRangeUpp;
    }

    public void setWxAppD0FixRangeUpp(BigDecimal wxAppD0FixRangeUpp) {
        this.wxAppD0FixRangeUpp = wxAppD0FixRangeUpp;
    }

    public BigDecimal getZfbH5RangeLow() {
        return zfbH5RangeLow;
    }

    public void setZfbH5RangeLow(BigDecimal zfbH5RangeLow) {
        this.zfbH5RangeLow = zfbH5RangeLow;
    }

    public BigDecimal getZfbH5RangeUpp() {
        return zfbH5RangeUpp;
    }

    public void setZfbH5RangeUpp(BigDecimal zfbH5RangeUpp) {
        this.zfbH5RangeUpp = zfbH5RangeUpp;
    }

    public BigDecimal getZfbH5FixRangeLow() {
        return zfbH5FixRangeLow;
    }

    public void setZfbH5FixRangeLow(BigDecimal zfbH5FixRangeLow) {
        this.zfbH5FixRangeLow = zfbH5FixRangeLow;
    }

    public BigDecimal getZfbH5FixRangeUpp() {
        return zfbH5FixRangeUpp;
    }

    public void setZfbH5FixRangeUpp(BigDecimal zfbH5FixRangeUpp) {
        this.zfbH5FixRangeUpp = zfbH5FixRangeUpp;
    }

    public BigDecimal getZfbH5D0RangeLow() {
        return zfbH5D0RangeLow;
    }

    public void setZfbH5D0RangeLow(BigDecimal zfbH5D0RangeLow) {
        this.zfbH5D0RangeLow = zfbH5D0RangeLow;
    }

    public BigDecimal getZfbH5D0RangeUpp() {
        return zfbH5D0RangeUpp;
    }

    public void setZfbH5D0RangeUpp(BigDecimal zfbH5D0RangeUpp) {
        this.zfbH5D0RangeUpp = zfbH5D0RangeUpp;
    }

    public BigDecimal getZfbH5D0FixRangeLow() {
        return zfbH5D0FixRangeLow;
    }

    public void setZfbH5D0FixRangeLow(BigDecimal zfbH5D0FixRangeLow) {
        this.zfbH5D0FixRangeLow = zfbH5D0FixRangeLow;
    }

    public BigDecimal getZfbH5D0FixRangeUpp() {
        return zfbH5D0FixRangeUpp;
    }

    public void setZfbH5D0FixRangeUpp(BigDecimal zfbH5D0FixRangeUpp) {
        this.zfbH5D0FixRangeUpp = zfbH5D0FixRangeUpp;
    }

    public BigDecimal getWxGzhRangeLow() {
        return wxGzhRangeLow;
    }

    public void setWxGzhRangeLow(BigDecimal wxGzhRangeLow) {
        this.wxGzhRangeLow = wxGzhRangeLow;
    }

    public BigDecimal getWxGzhRangeUpp() {
        return wxGzhRangeUpp;
    }

    public void setWxGzhRangeUpp(BigDecimal wxGzhRangeUpp) {
        this.wxGzhRangeUpp = wxGzhRangeUpp;
    }

    public BigDecimal getWxGzhFixRangeLow() {
        return wxGzhFixRangeLow;
    }

    public void setWxGzhFixRangeLow(BigDecimal wxGzhFixRangeLow) {
        this.wxGzhFixRangeLow = wxGzhFixRangeLow;
    }

    public BigDecimal getWxGzhFixRangeUpp() {
        return wxGzhFixRangeUpp;
    }

    public void setWxGzhFixRangeUpp(BigDecimal wxGzhFixRangeUpp) {
        this.wxGzhFixRangeUpp = wxGzhFixRangeUpp;
    }

    public BigDecimal getWxGzhD0RangeLow() {
        return wxGzhD0RangeLow;
    }

    public void setWxGzhD0RangeLow(BigDecimal wxGzhD0RangeLow) {
        this.wxGzhD0RangeLow = wxGzhD0RangeLow;
    }

    public BigDecimal getWxGzhD0RangeUpp() {
        return wxGzhD0RangeUpp;
    }

    public void setWxGzhD0RangeUpp(BigDecimal wxGzhD0RangeUpp) {
        this.wxGzhD0RangeUpp = wxGzhD0RangeUpp;
    }

    public BigDecimal getWxGzhD0FixRangeLow() {
        return wxGzhD0FixRangeLow;
    }

    public void setWxGzhD0FixRangeLow(BigDecimal wxGzhD0FixRangeLow) {
        this.wxGzhD0FixRangeLow = wxGzhD0FixRangeLow;
    }

    public BigDecimal getWxGzhD0FixRangeUpp() {
        return wxGzhD0FixRangeUpp;
    }

    public void setWxGzhD0FixRangeUpp(BigDecimal wxGzhD0FixRangeUpp) {
        this.wxGzhD0FixRangeUpp = wxGzhD0FixRangeUpp;
    }

    public BigDecimal getZfbRangeLow() {
        return zfbRangeLow;
    }

    public void setZfbRangeLow(BigDecimal zfbRangeLow) {
        this.zfbRangeLow = zfbRangeLow;
    }

    public String getCommissionType() {
        return commissionType;
    }

    public void setCommissionType(String commissionType) {
        this.commissionType = commissionType;
    }

    public String getWxAppFee() {
        return wxAppFee;
    }

    public void setWxAppFee(String wxAppFee) {
        this.wxAppFee = wxAppFee;
    }

    public String getWxAppD0Fee() {
        return wxAppD0Fee;
    }

    public void setWxAppD0Fee(String wxAppD0Fee) {
        this.wxAppD0Fee = wxAppD0Fee;
    }

    public String getWxGzhFee() {
        return wxGzhFee;
    }

    public void setWxGzhFee(String wxGzhFee) {
        this.wxGzhFee = wxGzhFee;
    }

    public String getWxGzhD0Fee() {
        return wxGzhD0Fee;
    }

    public void setWxGzhD0Fee(String wxGzhD0Fee) {
        this.wxGzhD0Fee = wxGzhD0Fee;
    }

    public String getZfbAppFee() {
        return zfbAppFee;
    }

    public void setZfbAppFee(String zfbAppFee) {
        this.zfbAppFee = zfbAppFee;
    }

    public String getZfbAppD0Fee() {
        return zfbAppD0Fee;
    }

    public void setZfbAppD0Fee(String zfbAppD0Fee) {
        this.zfbAppD0Fee = zfbAppD0Fee;
    }

    public String getZfbH5Fee() {
        return zfbH5Fee;
    }

    public void setZfbH5Fee(String zfbH5Fee) {
        this.zfbH5Fee = zfbH5Fee;
    }

    public String getZfbH5D0Fee() {
        return zfbH5D0Fee;
    }

    public void setZfbH5D0Fee(String zfbH5D0Fee) {
        this.zfbH5D0Fee = zfbH5D0Fee;
    }

    public BigDecimal getWxAppT1Fixation() {
        return wxAppT1Fixation;
    }

    public void setWxAppT1Fixation(BigDecimal wxAppT1Fixation) {
        this.wxAppT1Fixation = wxAppT1Fixation;
    }

    public BigDecimal getWxAppD0Fixation() {
        return wxAppD0Fixation;
    }

    public void setWxAppD0Fixation(BigDecimal wxAppD0Fixation) {
        this.wxAppD0Fixation = wxAppD0Fixation;
    }

    public BigDecimal getWxGzhT1Fixation() {
        return wxGzhT1Fixation;
    }

    public void setWxGzhT1Fixation(BigDecimal wxGzhT1Fixation) {
        this.wxGzhT1Fixation = wxGzhT1Fixation;
    }

    public BigDecimal getWxGzhD0Fixation() {
        return wxGzhD0Fixation;
    }

    public void setWxGzhD0Fixation(BigDecimal wxGzhD0Fixation) {
        this.wxGzhD0Fixation = wxGzhD0Fixation;
    }

    public BigDecimal getZfbAppT1ixation() {
        return zfbAppT1ixation;
    }

    public void setZfbAppT1ixation(BigDecimal zfbAppT1ixation) {
        this.zfbAppT1ixation = zfbAppT1ixation;
    }

    public BigDecimal getZfbAppD0Fixation() {
        return zfbAppD0Fixation;
    }

    public void setZfbAppD0Fixation(BigDecimal zfbAppD0Fixation) {
        this.zfbAppD0Fixation = zfbAppD0Fixation;
    }

    public BigDecimal getZfbH5T1ixation() {
        return zfbH5T1ixation;
    }

    public void setZfbH5T1ixation(BigDecimal zfbH5T1ixation) {
        this.zfbH5T1ixation = zfbH5T1ixation;
    }

    public BigDecimal getZfbH5D0Fixation() {
        return zfbH5D0Fixation;
    }

    public void setZfbH5D0Fixation(BigDecimal zfbH5D0Fixation) {
        this.zfbH5D0Fixation = zfbH5D0Fixation;
    }

    public BigDecimal getMdJjFixFee() {
        return mdJjFixFee;
    }

    public void setMdJjFixFee(BigDecimal mdJjFixFee) {
        this.mdJjFixFee = mdJjFixFee;
    }

    public BigDecimal getJsJjFixFee() {
        return jsJjFixFee;
    }

    public void setJsJjFixFee(BigDecimal jsJjFixFee) {
        this.jsJjFixFee = jsJjFixFee;
    }

    public String getMerRateRangeUp() {
        return merRateRangeUp;
    }

    public void setMerRateRangeUp(String merRateRangeUp) {
        this.merRateRangeUp = merRateRangeUp;
    }

    public BigDecimal getWxT1Fixation() {
        return wxT1Fixation;
    }

    public void setWxT1Fixation(BigDecimal wxT1Fixation) {
        this.wxT1Fixation = wxT1Fixation;
    }

    public BigDecimal getWxD0Fixation() {
        return wxD0Fixation;
    }

    public void setWxD0Fixation(BigDecimal wxD0Fixation) {
        this.wxD0Fixation = wxD0Fixation;
    }

    public BigDecimal getZfbT1ixation() {
        return zfbT1ixation;
    }

    public void setZfbT1ixation(BigDecimal zfbT1ixation) {
        this.zfbT1ixation = zfbT1ixation;
    }

    public BigDecimal getZfbD0Fixation() {
        return zfbD0Fixation;
    }

    public void setZfbD0Fixation(BigDecimal zfbD0Fixation) {
        this.zfbD0Fixation = zfbD0Fixation;
    }

    public BigDecimal getShFixation() {
        return shFixation;
    }

    public void setShFixation(BigDecimal shFixation) {
        this.shFixation = shFixation;
    }

    public BigDecimal getKjD0Fixation() {
        return kjD0Fixation;
    }

    public void setKjD0Fixation(BigDecimal kjD0Fixation) {
        this.kjD0Fixation = kjD0Fixation;
    }

    public BigDecimal getKjT1Fixation() {
        return kjT1Fixation;
    }

    public void setKjT1Fixation(BigDecimal kjT1Fixation) {
        this.kjT1Fixation = kjT1Fixation;
    }

    public BigDecimal getB2cD0Fixation() {
        return b2cD0Fixation;
    }

    public void setB2cD0Fixation(BigDecimal b2cD0Fixation) {
        this.b2cD0Fixation = b2cD0Fixation;
    }

    public BigDecimal getB2cT1Fixation() {
        return b2cT1Fixation;
    }

    public void setB2cT1Fixation(BigDecimal b2cT1Fixation) {
        this.b2cT1Fixation = b2cT1Fixation;
    }

    public String getMerSettleCycle() {
        return merSettleCycle;
    }

    public void setMerSettleCycle(String merSettleCycle) {
        this.merSettleCycle = merSettleCycle;
    }

    public String getMerRateRange() {
        return merRateRange;
    }

    public void setMerRateRange(String merRateRange) {
        this.merRateRange = merRateRange;
    }
    public String getSettleType() {
        return settleType;
    }

    public void setSettleType(String settleType) {
        this.settleType = settleType;
    }

    public List<String> getBusinessTypeList() {
        return businessTypeList;
    }

    public void setBusinessTypeList(List<String> businessTypeList) {
        this.businessTypeList = businessTypeList;
    }

    public String getYsD0Fee() {
        return ysD0Fee;
    }

    public void setYsD0Fee(String ysD0Fee) {
        this.ysD0Fee = ysD0Fee;
    }

    public String getMdDjFee() {
		return mdDjFee;
	}

	public void setMdDjFee(String mdDjFee) {
		this.mdDjFee = mdDjFee;
	}

	public String getMdJjFee() {
		return mdJjFee;
	}

	public void setMdJjFee(String mdJjFee) {
		this.mdJjFee = mdJjFee;
	}

	public BigDecimal getMdFixFee() {
		return mdFixFee;
	}

	public void setMdFixFee(BigDecimal mdFixFee) {
		this.mdFixFee = mdFixFee;
	}

	public BigDecimal getJsFixFee() {
		return jsFixFee;
	}

	public void setJsFixFee(BigDecimal jsFixFee) {
		this.jsFixFee = jsFixFee;
	}

	public String getJsDjFee() {
		return jsDjFee;
	}

	public void setJsDjFee(String jsDjFee) {
		this.jsDjFee = jsDjFee;
	}

	public String getJsJjFee() {
		return jsJjFee;
	}

	public void setJsJjFee(String jsJjFee) {
		this.jsJjFee = jsJjFee;
	}

	public String getShD0Fee() {
		return shD0Fee;
	}

	public void setShD0Fee(String shD0Fee) {
		this.shD0Fee = shD0Fee;
	}

	public String getKjD0Fee() {
		return kjD0Fee;
	}

	public void setKjD0Fee(String kjD0Fee) {
		this.kjD0Fee = kjD0Fee;
	}

	public String getKjT1Fee() {
		return kjT1Fee;
	}

	public void setKjT1Fee(String kjT1Fee) {
		this.kjT1Fee = kjT1Fee;
	}

	public String getB2cD0Fee() {
		return b2cD0Fee;
	}

	public void setB2cD0Fee(String b2cD0Fee) {
		this.b2cD0Fee = b2cD0Fee;
	}

	public String getB2cT1Fee() {
		return b2cT1Fee;
	}

	public void setB2cT1Fee(String b2cT1Fee) {
		this.b2cT1Fee = b2cT1Fee;
	}

	public boolean isEditFee() {
		return editFee;
	}

	public void setEditFee(boolean editFee) {
		this.editFee = editFee;
	}

	public String getIdcardNo() {
		return idcardNo;
	}

	public void setIdcardNo(String idcardNo) {
		this.idcardNo = idcardNo;
	}

	public String getOpenProvince() {
		return openProvince;
	}

	public void setOpenProvince(String openProvince) {
		this.openProvince = openProvince;
	}

	public String getOpenCity() {
		return openCity;
	}

	public void setOpenCity(String openCity) {
		this.openCity = openCity;
	}

	public String getWxFee() {
		return wxFee;
	}

	public void setWxFee(String wxFee) {
		this.wxFee = wxFee;
	}

	public String getWxD0Fee() {
		return wxD0Fee;
	}

	public void setWxD0Fee(String wxD0Fee) {
		this.wxD0Fee = wxD0Fee;
	}

	public String getZfbFee() {
		return zfbFee;
	}

	public void setZfbFee(String zfbFee) {
		this.zfbFee = zfbFee;
	}

	public String getZfbD0Fee() {
		return zfbD0Fee;
	}

	public void setZfbD0Fee(String zfbD0Fee) {
		this.zfbD0Fee = zfbD0Fee;
	}

	public Long getInsId() {
        return insId;
    }

    public void setInsId(Long insId) {
        this.insId = insId;
    }

    public String getInsNo() {
        return insNo;
    }

    public void setInsNo(String insNo) {
        this.insNo = insNo == null ? null : insNo.trim();
    }

    public String getInsName() {
        return insName;
    }

    public void setInsName(String insName) {
        this.insName = insName == null ? null : insName.trim();
    }

    public String getInsPubKey() {
        return insPubKey;
    }

    public void setInsPubKey(String insPubKey) {
        this.insPubKey = insPubKey == null ? null : insPubKey.trim();
    }

    public Long getAccountBankId() {
        return accountBankId;
    }

    public void setAccountBankId(Long accountBankId) {
        this.accountBankId = accountBankId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getBusinessSwitch() {
        return businessSwitch;
    }

    public void setBusinessSwitch(String businessSwitch) {
        this.businessSwitch = businessSwitch == null ? null : businessSwitch.trim();
    }

    public String getSupportD0Switch() {
        return supportD0Switch;
    }

    public void setSupportD0Switch(String supportD0Switch) {
        this.supportD0Switch = supportD0Switch == null ? null : supportD0Switch.trim();
    }

    public String getZfbAppId() {
        return zfbAppId;
    }

    public void setZfbAppId(String zfbAppId) {
        this.zfbAppId = zfbAppId == null ? null : zfbAppId.trim();
    }

    public String getZfbPubKey() {
        return zfbPubKey;
    }

    public void setZfbPubKey(String zfbPubKey) {
        this.zfbPubKey = zfbPubKey == null ? null : zfbPubKey.trim();
    }

    public String getZfbPriKey() {
        return zfbPriKey;
    }

    public void setZfbPriKey(String zfbPriKey) {
        this.zfbPriKey = zfbPriKey == null ? null : zfbPriKey.trim();
    }

    public String getWxAppId() {
        return wxAppId;
    }

    public void setWxAppId(String wxAppId) {
        this.wxAppId = wxAppId == null ? null : wxAppId.trim();
    }

    public String getWxAppSecret() {
        return wxAppSecret;
    }

    public void setWxAppSecret(String wxAppSecret) {
        this.wxAppSecret = wxAppSecret == null ? null : wxAppSecret.trim();
    }

    public String getInsShortName() {
        return insShortName;
    }

    public void setInsShortName(String insShortName) {
        this.insShortName = insShortName == null ? null : insShortName.trim();
    }

    public String getInsTel() {
        return insTel;
    }

    public void setInsTel(String insTel) {
        this.insTel = insTel == null ? null : insTel.trim();
    }

    public String getInsProvince() {
        return insProvince;
    }

    public void setInsProvince(String insProvince) {
        this.insProvince = insProvince == null ? null : insProvince.trim();
    }

    public String getInsProvinceName() {
        return insProvinceName;
    }

    public void setInsProvinceName(String insProvinceName) {
        this.insProvinceName = insProvinceName == null ? null : insProvinceName.trim();
    }

    public String getInsCity() {
        return insCity;
    }

    public void setInsCity(String insCity) {
        this.insCity = insCity == null ? null : insCity.trim();
    }

    public String getInsCityName() {
        return insCityName;
    }

    public void setInsCityName(String insCityName) {
        this.insCityName = insCityName == null ? null : insCityName.trim();
    }

    public String getInsSrelation() {
        return insSrelation;
    }

    public void setInsSrelation(String insSrelation) {
        this.insSrelation = insSrelation == null ? null : insSrelation.trim();
    }

    public String getInsFax() {
        return insFax;
    }

    public void setInsFax(String insFax) {
        this.insFax = insFax == null ? null : insFax.trim();
    }

    public String getInsEmail() {
        return insEmail;
    }

    public void setInsEmail(String insEmail) {
        this.insEmail = insEmail == null ? null : insEmail.trim();
    }

    public String getInsZip() {
        return insZip;
    }

    public void setInsZip(String insZip) {
        this.insZip = insZip == null ? null : insZip.trim();
    }

    public String getInsAddress() {
        return insAddress;
    }

    public void setInsAddress(String insAddress) {
        this.insAddress = insAddress == null ? null : insAddress.trim();
    }

    public String getInsYnum() {
        return insYnum;
    }

    public void setInsYnum(String insYnum) {
        this.insYnum = insYnum == null ? null : insYnum.trim();
    }

    public String getInsBankCode() {
        return insBankCode;
    }

    public void setInsBankCode(String insBankCode) {
        this.insBankCode = insBankCode == null ? null : insBankCode.trim();
    }

    public String getInsBankName() {
        return insBankName;
    }

    public void setInsBankName(String insBankName) {
        this.insBankName = insBankName == null ? null : insBankName.trim();
    }

    public String getInsSubBankName() {
        return insSubBankName;
    }

    public void setInsSubBankName(String insSubBankName) {
        this.insSubBankName = insSubBankName == null ? null : insSubBankName.trim();
    }

    public String getInsBankClientName() {
        return insBankClientName;
    }

    public void setInsBankClientName(String insBankClientName) {
        this.insBankClientName = insBankClientName == null ? null : insBankClientName.trim();
    }

    public String getInsBankCardNo() {
        return insBankCardNo;
    }

    public void setInsBankCardNo(String insBankCardNo) {
        this.insBankCardNo = insBankCardNo == null ? null : insBankCardNo.trim();
    }


    public Long getYsbuserid() {
        return ysbuserid;
    }

    public void setYsbuserid(Long ysbuserid) {
        this.ysbuserid = ysbuserid;
    }

    public Long getCascustomid() {
        return cascustomid;
    }

    public void setCascustomid(Long cascustomid) {
        this.cascustomid = cascustomid;
    }

	public String getBusinessType() {
		return businessType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}


}