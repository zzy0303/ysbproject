package com.uns.organization.modules.organization.entity;

import java.math.BigDecimal;
import java.util.Date;

import com.uns.organization.common.persistence.DataEntity;
import com.uns.organization.common.utils.DateUtils;
import com.uns.organization.common.utils.StringUtils;
import com.uns.organization.common.utils.excel.annotation.ExcelField;
import com.uns.organization.modules.sys.utils.DictUtils;

/**
 * 抽成
 * @author yang.cheng
 *
 */
public class Percentag extends DataEntity<Percentag>{

	private static final long serialVersionUID = 1L;
    
    private String customerNo;//商户编号
    
	private String scompany;//商户名称
	
	private String insNo;//机构编号
	
	private String insName;//机构名称
	
	private String orderId;//订单编号
	
	private BigDecimal amount;//交易金额
	
	private BigDecimal percentag;//抽成比例
	
	private BigDecimal percentagAmount;//抽成金额
	
	private String cardType;//收款方式
	
	private String tranTime;//交易时间
	
	private String tranType;//交易类型
	
	private String beginDate;//开始时间
	private String endDate;//结束时间
	
	private String percentageTime;//抽成批次时间
	public String getBeginDate() {
		return beginDate;
	}
	public void setBeginDate(String beginDate) {
		this.beginDate = beginDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	
	
	public void setCustomerNo(String customerNo) {
		this.customerNo = customerNo;
	}
	
	public void setScompany(String scompany) {
		this.scompany = scompany;
	}
	
	public void setInsNo(String insNo) {
		this.insNo = insNo;
	}
	
	public void setInsName(String insName) {
		this.insName = insName;
	}
	
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	
	public void setPercentagAmount(BigDecimal percentagAmount) {
		this.percentagAmount = percentagAmount;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public String getTranTime() {
		return tranTime;
	}
	
	
	
	public void setTranTime(String tranTime) {
		this.tranTime = tranTime;
	}
	
	public String getTranType() {
		return tranType;
	}
	public void setTranType(String tranType) {
		this.tranType = tranType;
	}
	
	public void setPercentag(BigDecimal percentag) {
		this.percentag = percentag;
	}

	@ExcelField(title="商户编号", type=1, align=1, sort=1)
	public String getCustomerNo() {
		return customerNo;
	}
	@ExcelField(title="商户名称", type=1, align=1, sort=2)
	public String getScompany() {
		return scompany;
	}
	@ExcelField(title="	机构编号	", type=1, align=1, sort=3)
	public String getInsNo() {
		return insNo;
	}
	@ExcelField(title="机构名称", type=1, align=1, sort=4)
	public String getInsName() {
		return insName;
	}
	@ExcelField(title="	订单编号	", type=1, align=1, sort=5)
	public String getOrderId() {
		return orderId;
	}
	@ExcelField(title="交易金额", type=1, align=1, sort=6)
	public BigDecimal getAmount() {
		return amount;
	}
	@ExcelField(title="抽成比例(%)", type=1, align=1, sort=7)
	public BigDecimal getPercentag() {
		return percentag;
	}
	@ExcelField(title="抽成金额", type=1, align=1, sort=8)
	public BigDecimal getPercentagAmount() {
		return percentagAmount;
	}
	@ExcelField(title="收款方式", type=1, align=1, sort=9)
	public String getCardTypeStr() {
		return DictUtils.getDictLabel(cardType, "TRANS_CARD_TYPE", cardType);
	}
	
	//获取交易时间类型
	@ExcelField(title="	交易时间	", type=1, align=1, sort=10)
	public String getTranTimeStr() {
		return StringUtils.isBlank(tranTime)?"":StringUtils.parseDateString(tranTime);
	}
	public String getPercentageTime() {
		return percentageTime;
	}
	public void setPercentageTime(String percentageTime) {
		this.percentageTime = percentageTime;
	}
}
