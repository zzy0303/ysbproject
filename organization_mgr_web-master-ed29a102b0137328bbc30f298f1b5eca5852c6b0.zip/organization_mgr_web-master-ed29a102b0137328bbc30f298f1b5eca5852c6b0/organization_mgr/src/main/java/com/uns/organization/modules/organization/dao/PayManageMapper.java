package com.uns.organization.modules.organization.dao;

import com.uns.organization.common.persistence.annotation.MyBatisDao;

import java.util.List;
import java.util.Map;

@MyBatisDao
public interface PayManageMapper {
    List smPayment();

    void updateSmPayment(Map<String,String> map);
}
