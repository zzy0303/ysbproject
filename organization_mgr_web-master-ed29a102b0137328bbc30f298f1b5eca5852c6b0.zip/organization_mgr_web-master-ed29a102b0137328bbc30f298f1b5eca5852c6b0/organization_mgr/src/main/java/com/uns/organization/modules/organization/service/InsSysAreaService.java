package com.uns.organization.modules.organization.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.organization.modules.organization.dao.SysAreaMapper;
import com.uns.organization.modules.organization.entity.Customer;
import com.uns.organization.modules.organization.entity.SysArea;

@Service
public class InsSysAreaService {
	
	@Autowired
	SysAreaMapper sysAreaMapper;
	
	public SysArea findAreaNameByYsb(Customer customer){
		return sysAreaMapper.findAreaNameByYsb(customer);
	}
}
