package com.uns.organization.modules.organization.web;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.uns.organization.common.exception.BusinessException;
import com.uns.organization.common.persistence.Page;
import com.uns.organization.common.utils.Constants;
import com.uns.organization.common.web.BaseController;
import com.uns.organization.modules.organization.entity.CmbJoinInfo;
import com.uns.organization.modules.organization.entity.Customer;
import com.uns.organization.modules.organization.entity.Institution;
import com.uns.organization.modules.organization.entity.ZhaoshangJoin;
import com.uns.organization.modules.organization.service.InsCustomerReportService;
import com.uns.organization.modules.organization.service.InsCustomerService;
import com.uns.organization.modules.organization.service.InstitutionService;
import com.uns.organization.modules.organization.web.form.ReportForm;

/**
 * 商户报件Controller
 * @author Administrator
 *
 */
@Controller
@RequestMapping(value = "${adminPath}/ins/customerReport")
public class InsCustomerReportController extends BaseController{
	
	@Autowired
	InsCustomerReportService insCustomerReportService;
	
	@Autowired
	InstitutionService institutionService;
	
	@Autowired
	InsCustomerService insCustomerService;
	
	/**
	 * 商户报件查询列表
	 * @param request
	 * @param response
	 * @param model
	 * @param reportForm
	 * @return
	 */
	@RequestMapping(value = "reportList")
	public String reportList(HttpServletRequest request, HttpServletResponse response, Model model, RedirectAttributes redirectAttributes, ReportForm reportForm){
		try {
			//查询报件列表
			Page<ZhaoshangJoin> page = insCustomerReportService.findReportList(new Page(request, response), reportForm);
			//查询机构列表
			List<Institution> allIns = institutionService.findAllIns();
			model.addAttribute("allIns", allIns);
			model.addAttribute("page", page);
		} catch (Exception e) {
			e.printStackTrace();
			addMessage(redirectAttributes, "商户报件列表查询错误！");
		}
		return "modules/customerReport/customerReportList";
	}
	
	/**
	 * 商户报件详情
	 * @param request
	 * @param response
	 * @param model
	 * @param redirectAttributes
	 * @param reportForm
	 * @return
	 */
	@RequestMapping(value = "reportDetails")
	public String reportDetails(HttpServletRequest request, HttpServletResponse response, Model model, RedirectAttributes redirectAttributes, ReportForm reportForm){
		try {
			ZhaoshangJoin zhaoshangJoin = insCustomerReportService.findReportDetails(reportForm);
			model.addAttribute("reportDetails", zhaoshangJoin);
		} catch (Exception e) {
			e.printStackTrace();
			addMessage(redirectAttributes, "商户报件详情查询错误！");
		}
		return "modules/customerReport/customerReportDetails";
	}
	
	/**
	 * 编辑商户报件详情 
	 * @param request
	 * @param response
	 * @param model
	 * @param redirectAttributes
	 * @param reportForm
	 * @return
	 */
	@RequiresPermissions(value="ins:customerReport:editCustomerReport")
	@RequestMapping(value = "editCustomerReport")
	public String editCustomerReport(HttpServletRequest request, HttpServletResponse response, Model model, RedirectAttributes redirectAttributes, ReportForm reportForm){
		try {
			ZhaoshangJoin zhaoshangJoin = insCustomerReportService.findReportDetails(reportForm);
			model.addAttribute("reportDetails", zhaoshangJoin);
		} catch (Exception e) {
			e.printStackTrace();
			addMessage(redirectAttributes, "商户报件信息修改错误！");
		}
		return "modules/customerReport/editCustomerReport";
	}
	
	/**
	 * 保存商户报件
	 * @param request
	 * @param response
	 * @param redirectAttributes
	 * @param reportForm
	 * @return
	 */
	@RequestMapping(value = "saveCustomerReport")
	public String saveCustomerReport(HttpServletRequest request, HttpServletResponse response, 
			RedirectAttributes redirectAttributes, ReportForm reportForm){
		try {
			ZhaoshangJoin oldZhaoshangJoin = insCustomerReportService.findReportDetails(reportForm);
			insCustomerReportService.copyZhaoshangJoinRecord(oldZhaoshangJoin, reportForm);
			CmbJoinInfo cmbJoinInfo = insCustomerReportService.findCmbJoinDetails();
			//调用接口（商户创建和银行入驻）
			insCustomerReportService.invokeCustomerCreateport(oldZhaoshangJoin, cmbJoinInfo);
			insCustomerReportService.invokeBankJoinPort(oldZhaoshangJoin, cmbJoinInfo);
			//更新报件信息（等待异步通知所以设置为待确认）
			oldZhaoshangJoin.setAuditStatus(Constants.AUDIT_STATUS_7);
			insCustomerReportService.updateCustomerReport(oldZhaoshangJoin);
			//更新商户审核状态
			Customer customer = new Customer();
			customer.setSmallMerchNo(oldZhaoshangJoin.getSmallMerchantNo());
			customer.setCheckstatus(Constants.CHECKSTATUS_NO_CHECK);
			insCustomerService.updateCheckstatusBySmallMerchNo(customer);
			
		}catch(BusinessException be){
			be.printStackTrace();
			reportForm.setAuditStatus(Constants.AUDIT_STATUS_6);
			insCustomerReportService.updateAuditStatus(reportForm);
			addMessage(redirectAttributes, "接口调用出错！错误消息："+ be.getMessage());
			return "redirect:" + adminPath + "/ins/customerReport/reportList?repage";
		}catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
			addMessage(redirectAttributes, "保存商户报件修改错误！");
			return "redirect:" + adminPath + "/ins/customerReport/reportList?repage";
		}
		addMessage(redirectAttributes, "商户报件修改成功！");
		return "redirect:" + adminPath + "/ins/customerReport/reportList?repage";
	}
}
