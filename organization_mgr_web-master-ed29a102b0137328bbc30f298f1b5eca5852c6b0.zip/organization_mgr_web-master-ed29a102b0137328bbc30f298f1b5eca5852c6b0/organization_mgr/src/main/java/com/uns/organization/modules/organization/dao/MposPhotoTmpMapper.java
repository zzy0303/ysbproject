package com.uns.organization.modules.organization.dao;

import com.uns.organization.common.persistence.annotation.MyBatisDao;
import com.uns.organization.modules.organization.entity.MposPhotoTmp;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.Map;

@MyBatisDao
public interface MposPhotoTmpMapper {

    int deleteByPrimaryKey(BigDecimal photoId);

    int insert(MposPhotoTmp record);

    int insertSelective(MposPhotoTmp record);

    MposPhotoTmp selectByPrimaryKey(BigDecimal photoId);

    int updateByPrimaryKeySelective(MposPhotoTmp record);

    int updateByPrimaryKey(MposPhotoTmp record);

    String getUUID();

    void deleteByParam(Map<String, String> map);
}