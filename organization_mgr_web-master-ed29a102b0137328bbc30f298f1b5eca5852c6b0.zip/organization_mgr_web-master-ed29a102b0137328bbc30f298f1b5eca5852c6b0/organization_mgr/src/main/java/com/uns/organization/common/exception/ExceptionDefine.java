package com.uns.organization.common.exception;

/**
 * 错误定义可以用中文来定义
 * 通常异常定义应包含三要素:谓语(动词),宾语(名词),补语(具体情况/状态的说明)
 * @author Administrator
 *
 */
public enum ExceptionDefine {

	商户信息列表查询出错("1000"),
	商户信息详情查询出错("1001"),
	审核结果保存出错("1002");

	private String errorCode;
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	ExceptionDefine(String errorCode){
		this.errorCode = errorCode;
	}

	public String getErrorCode(){
		return this.errorCode;
	}
}
