package com.uns.organization.modules.organization.dao;

import com.uns.organization.common.persistence.annotation.MyBatisDao;
import com.uns.organization.modules.organization.entity.InsRoleFunction;
@MyBatisDao
public interface InsRoleFunctionMapper {

    int insert(InsRoleFunction record);

    int insertSelective(InsRoleFunction record);

}