package com.uns.organization.modules.organization.web;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.uns.organization.common.persistence.Page;
import com.uns.organization.common.utils.DateUtils;
import com.uns.organization.common.utils.excel.ExportExcel;
import com.uns.organization.common.web.BaseController;
import com.uns.organization.modules.organization.entity.Percentag;
import com.uns.organization.modules.organization.entity.PercentagTx;
import com.uns.organization.modules.organization.service.PercentagService;

/**
 * 抽成管理
 * @author yang.cheng
 *
 */
@Controller
@RequestMapping(value = "${adminPath}/ins/percentag")
public class PercentagController extends BaseController{

	@Autowired
	private PercentagService percentagService;

	@RequestMapping(value = {"list", ""})
	public String list(Percentag percentag,HttpServletRequest request, HttpServletResponse response, Model model) throws ParseException {
		if(null != percentag.getPercentageTime()){
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			Date date = sdf.parse(percentag.getPercentageTime());
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);
			calendar.add(calendar.DAY_OF_MONTH, -1);
			sdf = new SimpleDateFormat("yyyy-MM-dd");
			percentag.setBeginDate(sdf.format(calendar.getTime()));
			percentag.setEndDate(sdf.format(calendar.getTime()));
		}
		Page<Percentag> page = percentagService.findPercentagList(new Page<Percentag>(request, response), percentag);
		model.addAttribute("page", page);
		return "modules/percentag/percentagList";
	}

	@RequestMapping(value="export",method=RequestMethod.POST)
	public String export(Percentag percentag,HttpServletRequest request, HttpServletResponse response, Model model,RedirectAttributes redirectAttributes) {
		try {
			String fileName = "机构抽成数据"+DateUtils.getDate("yyyyMMddHHmmss")+".xlsx";
			Page<Percentag> page = percentagService.findPercentagList(new Page<Percentag>(request, response, -1), percentag);
    		new ExportExcel("用户数据", Percentag.class).setDataList(page.getList()).write(response, fileName).dispose();
    		return null;
		} catch (Exception e) {
			logger.error("导出机构抽成数据异常！",e);
			addMessage(redirectAttributes, "导出机构抽成数据失败！失败信息："+e.getMessage());
		}
		return "redirect:" + adminPath + "/ins/percentag/list?repage";
	}
	
	/**
	 * 抽成提现查询
	 * @param percentagTx
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 * @throws ParseException 
	 */
	@RequestMapping(value = "txList")
	public String txList(PercentagTx percentagTx,HttpServletRequest request, HttpServletResponse response, Model model) throws ParseException {
			Page<PercentagTx> page = percentagService.findPercentagTxList(new Page<PercentagTx>(request, response), percentagTx);
			model.addAttribute("page", page);
			return "modules/percentag/percentagTxList";
	}

	/**
	 * 抽成提现导出
	 * @param percentagTx
	 * @param request
	 * @param response
	 * @param model
	 * @param redirectAttributes
	 * @return
	 */
	@RequestMapping(value="exportTx",method=RequestMethod.POST)
	public String exportTx(PercentagTx percentagTx,HttpServletRequest request, HttpServletResponse response, Model model,RedirectAttributes redirectAttributes) {
		try {
			String fileName = "机构抽成提现数据"+DateUtils.getDate("yyyyMMddHHmmss")+".xlsx";
			Page<PercentagTx> page = percentagService.findPercentagTxList(new Page<PercentagTx>(request, response, -1), percentagTx);
    		new ExportExcel("用户数据", PercentagTx.class).setDataList(page.getList()).write(response, fileName).dispose();
    		return null;
		} catch (Exception e) {
			logger.error("导出机构抽成提现数据异常！",e);
			addMessage(redirectAttributes, "导出机构抽成提现数据失败！失败信息："+e.getMessage());
		}
		return "redirect:" + adminPath + "/ins/percentag/txList?repage";
	}
}
