package com.uns.organization.modules.organization.entity;

import java.math.BigDecimal;

public class QrCodeTransExt {
    private Long id;

    private String orderId;

    private String oriOrderid;

    private String tranTime;

    private String tranType;

    private String tranFlag;

    private BigDecimal amount;

    private BigDecimal fee;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId == null ? null : orderId.trim();
    }

    public String getOriOrderid() {
        return oriOrderid;
    }

    public void setOriOrderid(String oriOrderid) {
        this.oriOrderid = oriOrderid == null ? null : oriOrderid.trim();
    }

    public String getTranTime() {
        return tranTime;
    }

    public void setTranTime(String tranTime) {
        this.tranTime = tranTime == null ? null : tranTime.trim();
    }

    public String getTranType() {
        return tranType;
    }

    public void setTranType(String tranType) {
        this.tranType = tranType == null ? null : tranType.trim();
    }

    public String getTranFlag() {
        return tranFlag;
    }

    public void setTranFlag(String tranFlag) {
        this.tranFlag = tranFlag == null ? null : tranFlag.trim();
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getFee() {
        return fee;
    }

    public void setFee(BigDecimal fee) {
        this.fee = fee;
    }
}