package com.uns.organization.modules.organization.web;

import com.uns.organization.common.exception.BusinessException;
import com.uns.organization.common.exception.ExceptionEnum;
import com.uns.organization.modules.organization.service.PayManageService;
import com.uns.organization.modules.organization.web.form.PayManageForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

@Controller
@RequestMapping(value = "${adminPath}/ins/payMange")
public class PayManageController extends BaseController{

    @Autowired
    private PayManageService payManageService;

    /**
     * 扫码支付管理查询
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "smPayment")
    public String smPayment(HttpServletRequest request, HttpServletResponse response,RedirectAttributes redirectAttributes) throws Exception{
        try {
            Map smPayment = payManageService.findSmPayManage();
            request.setAttribute("smPayment", smPayment);
        } catch (Exception e) {
            e.printStackTrace();
            addMessage(redirectAttributes,"扫码支付业务查询失败" + e.getMessage());
        }
        return "modules/paymentManage/smPayment";
    }

    /**
     * 快捷支付管理查询
     * @param request
     * @param response
     * @param redirectAttributes
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "kjPayment")
    public String kjPayment(HttpServletRequest request, HttpServletResponse response,RedirectAttributes redirectAttributes) throws Exception{
        try {
            Map kjPayment = payManageService.findKjPayManage();
            request.setAttribute("kjPayment",kjPayment);
        } catch (Exception e){
            e.printStackTrace();
            addMessage(redirectAttributes,"快捷支付业务查询失败" + e.getMessage());
        }
        return "modules/paymentManage/kjPayment";
    }

    /**
     * 扫码业务管理修改
     * @param request
     * @param payManageForm
     * @param redirectAttributes
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "updateSmPayment")
    public String updateSmPayment(HttpServletRequest request, PayManageForm payManageForm ,RedirectAttributes redirectAttributes) throws Exception {
        try {
            payManageService.updatePaySm(payManageForm);
            addMessage(redirectAttributes,"扫码支付业务管理配置成功!");

        } catch (Exception e){
            e.printStackTrace();
            throw new BusinessException(ExceptionEnum.扫码支付业务配置失败);
        }
        return "redirect:" + adminPath + "/ins/payMange/smPayment";
    }

    /**
     * 快捷业务管理修改
     * @param request
     * @param payManageForm
     * @param redirectAttributes
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "updateKjPayment")
    public String updateKjPayment(HttpServletRequest request, PayManageForm payManageForm, RedirectAttributes redirectAttributes) throws Exception {
        try {
            payManageService.updatePayKj(payManageForm);
            addMessage(redirectAttributes,"快捷支付业务管理配置成功！");
        } catch (Exception e){
            e.printStackTrace();
            throw new BusinessException(ExceptionEnum.快捷支付业务配置失败);
        }
        return "redirect:" + adminPath + "/ins/payMange/kjPayment";
    }
}
