package com.uns.organization.modules.organization.service;

import com.uns.organization.common.persistence.Page;
import com.uns.organization.modules.organization.dao.InsSplitBatchSmMapper;
import com.uns.organization.modules.organization.dao.InsSplitProfitSmMapper;
import com.uns.organization.modules.organization.entity.InsSplitBatchSm;
import com.uns.organization.modules.organization.entity.InsSplitProfitSm;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author: KaiFeng
 * @Description:
 * @Date: 2017/11/22
 * @Modifyed By:
 */
@Service
public class InsProfitService {

    @Autowired
    private InsSplitBatchSmMapper insSplitBatchSmMapper;

    @Autowired
    private InsSplitProfitSmMapper insSplitProfitSmMapper;

    public Page<InsSplitBatchSm> queryProfitBatchList(Page<InsSplitBatchSm> insSplitBatchSmPage, InsSplitBatchSm insSplitBatchSm) throws Exception {
        insSplitBatchSm.setPage(insSplitBatchSmPage);
        insSplitBatchSmPage.setList(insSplitBatchSmMapper.queryProfitBatchList(insSplitBatchSm));
        return insSplitBatchSmPage;
    }

    public InsSplitBatchSm querySplitBatch(String batchNo) throws Exception {
        return insSplitBatchSmMapper.querySplitBatch(batchNo);
    }

    public Page<InsSplitProfitSm> querySplitProfitList(Page<InsSplitProfitSm> insSplitProfitSmPage, InsSplitProfitSm insSplitProfitSm) {
        insSplitProfitSm.setPage(insSplitProfitSmPage);
        insSplitProfitSmPage.setList(insSplitProfitSmMapper.querySplitProfitList(insSplitProfitSm));
        return insSplitProfitSmPage;
    }

    public void profitAudit(InsSplitBatchSm insSplitBatchSm) throws Exception {
        insSplitBatchSm.setBatchNoArr(insSplitBatchSm.getBatchNos().split(","));
        insSplitBatchSmMapper.profitAudit(insSplitBatchSm);
    }
}
