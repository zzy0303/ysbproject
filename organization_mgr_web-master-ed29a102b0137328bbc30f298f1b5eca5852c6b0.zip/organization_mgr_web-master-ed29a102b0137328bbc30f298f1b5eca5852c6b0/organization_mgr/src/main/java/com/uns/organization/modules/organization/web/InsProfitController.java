package com.uns.organization.modules.organization.web;

import com.uns.organization.common.persistence.Page;
import com.uns.organization.common.utils.Constants;
import com.uns.organization.common.utils.DateUtils;
import com.uns.organization.common.utils.excel.ExportExcel;
import com.uns.organization.modules.organization.entity.InsSplitBatchSm;
import com.uns.organization.modules.organization.entity.InsSplitProfitSm;
import com.uns.organization.modules.organization.service.InsProfitService;
import org.apache.commons.lang.StringUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;

/**
 * @author: KaiFeng
 * @description: 机构分润
 * @date: 2017/11/22
 * @modifyed By:
 */
@Controller
@RequestMapping(value = "${adminPath}/ins/profit")
public class InsProfitController extends BaseController {

    @Autowired
    private InsProfitService insProfitService;

    /**
     * 查询机构分润批次列表
     *
     * @param insSplitBatchSm
     * @param request
     * @param response
     * @param model
     * @return
     */
    @RequestMapping(value = "queryProfitBatchList")
    public String queryProfitBatchList(InsSplitBatchSm insSplitBatchSm, HttpServletRequest request, HttpServletResponse response, Model model) {
        try {
            //运营
            insSplitBatchSm.setStatusType(Constants.STATUS_0);
            Page<InsSplitBatchSm> page = insProfitService.queryProfitBatchList(new Page<InsSplitBatchSm>(request, response), insSplitBatchSm);
            model.addAttribute("page", page);
        } catch (Exception e) {
            addMessage(model, e.getMessage());
            e.printStackTrace();
        }
        return "modules/insprofit/insProfitBatchList";
    }

    /**
     * 导出机构分润批次列表
     * @param insSplitBatchSm
     * @param request
     * @param response
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value = "exportProfitBatchList")
    public String exportProfitBatchList(InsSplitBatchSm insSplitBatchSm, HttpServletRequest request, HttpServletResponse response, RedirectAttributes redirectAttributes) {
        try {
            //运营
            insSplitBatchSm.setStatusType(Constants.STATUS_0);
            String fileName = "机构分润批次" + DateUtils.getDate("yyyyMMddHHmmss")+".xlsx";
            Page<InsSplitBatchSm> page = insProfitService.queryProfitBatchList(new Page<InsSplitBatchSm>(request, response, -1), insSplitBatchSm);
            new ExportExcel("机构分润批次数据", InsSplitBatchSm.class).setDataList(page.getList()).write(response, fileName).dispose();
        } catch (Exception e) {
            e.printStackTrace();
            addMessage(redirectAttributes, "导出数据失败！");
            return "redirect:" + adminPath + "/ins/profit/queryProfitBatchList";
        }
        return null;
    }

    /**
     * 查询机构分润详情
     *
     * @param insSplitProfitSm
     * @param request
     * @param response
     * @param model
     * @return
     */
    @RequestMapping(value = "queryProfitBatchInfo")
    public String queryProfitBatchInfo(InsSplitProfitSm insSplitProfitSm, HttpServletRequest request, HttpServletResponse response, Model model) {
        try {
            InsSplitBatchSm insSplitBatchSm = insProfitService.querySplitBatch(insSplitProfitSm.getBatchNo());
            Page<InsSplitProfitSm> page = insProfitService.querySplitProfitList(new Page<InsSplitProfitSm>(request, response), insSplitProfitSm);
            model.addAttribute("insSplitBatchSm", insSplitBatchSm);
            model.addAttribute("page", page);
        } catch (Exception e) {
            addMessage(model, e.getMessage());
            e.printStackTrace();
        }
        return "modules/insprofit/insProfitBatchInfo";
    }

    /**
     * 导出机构分润详情列表
     * @param insSplitProfitSm
     * @param request
     * @param response
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value = "exportProfitBatchInfo")
    public String exportProfitBatchInfo(InsSplitProfitSm insSplitProfitSm, HttpServletRequest request, HttpServletResponse response, RedirectAttributes redirectAttributes) {
        try {
            String fileName = "机构分润详情" + DateUtils.getDate("yyyyMMddHHmmss")+".xlsx";
            Page<InsSplitProfitSm> page = insProfitService.querySplitProfitList(new Page<InsSplitProfitSm>(request, response, -1), insSplitProfitSm);
            new ExportExcel("机构分润详情数据", InsSplitProfitSm.class).setDataList(page.getList()).write(response, fileName).dispose();
        } catch (Exception e) {
            e.printStackTrace();
            addMessage(redirectAttributes, "导出数据失败！");
            return "redirect:" + adminPath + "/ins/profit/queryProfitBatchInfo?batchNo=" + insSplitProfitSm.getBatchNo();
        }
        return null;
    }

    /**
     * 机构分润审核
     * @param insSplitBatchSm
     * @param redirectAttributes
     * @return
     */
    @RequiresPermissions("ins:profit:profitAudit")
    @RequestMapping(value = "profitAudit")
    public String profitAudit(InsSplitBatchSm insSplitBatchSm, RedirectAttributes redirectAttributes) {
        try {
            insProfitService.profitAudit(insSplitBatchSm);
            addMessage(redirectAttributes, "操作成功");
        } catch (Exception e) {
            addMessage(redirectAttributes, "系统错误");
            e.printStackTrace();
        }
        return "redirect:" + adminPath + "/ins/profit/queryProfitBatchList";
    }

    /**
     * 查询结算机构分润批次列表
     *
     * @param insSplitBatchSm
     * @param request
     * @param response
     * @param model
     * @return
     */
    @RequestMapping(value = "queryJsProfitBatchList")
    public String queryJsProfitBatchList(InsSplitBatchSm insSplitBatchSm, HttpServletRequest request, HttpServletResponse response, Model model) {
        try {
            //结算
            insSplitBatchSm.setStatusType(Constants.STATUS_1);
            Page<InsSplitBatchSm> page = insProfitService.queryProfitBatchList(new Page<InsSplitBatchSm>(request, response), insSplitBatchSm);
            model.addAttribute("page", page);
        } catch (Exception e) {
            addMessage(model, e.getMessage());
            e.printStackTrace();
        }
        return "modules/insprofit/insProfitBatchListJs";
    }

    /**
     * 导出结算机构分润批次列表
     * @param insSplitBatchSm
     * @param request
     * @param response
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value = "exportJsProfitBatchList")
    public String exportJsProfitBatchList(InsSplitBatchSm insSplitBatchSm, HttpServletRequest request, HttpServletResponse response, RedirectAttributes redirectAttributes) {
        try {
            //结算
            insSplitBatchSm.setStatusType(Constants.STATUS_1);
            String fileName = "机构分润批次" + DateUtils.getDate("yyyyMMddHHmmss")+".xlsx";
            Page<InsSplitBatchSm> page = insProfitService.queryProfitBatchList(new Page<InsSplitBatchSm>(request, response, -1), insSplitBatchSm);
            new ExportExcel("机构分润批次数据", InsSplitBatchSm.class).setDataList(page.getList()).write(response, fileName).dispose();
        } catch (Exception e) {
            e.printStackTrace();
            addMessage(redirectAttributes, "导出数据失败！");
            return "redirect:" + adminPath + "/ins/profit/queryProfitBatchList";
        }
        return null;
    }

    /**
     * 查询结算机构分润详情
     *
     * @param insSplitProfitSm
     * @param request
     * @param response
     * @param model
     * @return
     */
    @RequestMapping(value = "queryJsProfitBatchInfo")
    public String queryJsProfitBatchInfo(InsSplitProfitSm insSplitProfitSm, HttpServletRequest request, HttpServletResponse response, Model model) {
        try {
            InsSplitBatchSm insSplitBatchSm = insProfitService.querySplitBatch(insSplitProfitSm.getBatchNo());
            Page<InsSplitProfitSm> page = insProfitService.querySplitProfitList(new Page<InsSplitProfitSm>(request, response), insSplitProfitSm);
            model.addAttribute("insSplitBatchSm", insSplitBatchSm);
            model.addAttribute("page", page);
        } catch (Exception e) {
            addMessage(model, e.getMessage());
            e.printStackTrace();
        }
        return "modules/insprofit/insProfitBatchInfoJs";
    }

    /**
     * 机构分润结算审核
     * @param insSplitBatchSm
     * @param redirectAttributes
     * @return
     */
    @RequiresPermissions("ins:profit:profitJsAudit")
    @RequestMapping(value = "profitJsAudit")
    public String profitJsAudit(InsSplitBatchSm insSplitBatchSm, RedirectAttributes redirectAttributes) {
        try {
            insSplitBatchSm.setSettleDate(new Date());
            insProfitService.profitAudit(insSplitBatchSm);
            addMessage(redirectAttributes, "操作成功");
        } catch (Exception e) {
            addMessage(redirectAttributes, "系统错误");
            e.printStackTrace();
        }
        return "redirect:" + adminPath + "/ins/profit/queryJsProfitBatchList";
    }

}
