package com.uns.organization.modules.organization.web.form;

import com.uns.organization.common.persistence.DataEntity;
import com.uns.organization.common.utils.StringUtils;
import com.uns.organization.modules.organization.entity.TQrCodeTrans;




/**
 * 交易Form
 * @author Administrator
 *
 */
public class TransForm extends DataEntity<TQrCodeTrans>{
	private String smallMerchNo;//商户编号
	private String customerNo;//商户id
	private String insNo;//所属机构编号
	private String customername;//商户姓名
	private String insName;//所属机构名称
	private String orderId;//交易编号
	private String d0Flag;//结算类型
	private String qorderid;//充值编号
	private String qtranflag;//充值状态（成功、失败）
	private String qtrantimeStart;//充值（提现）时间下限
	private String qtrantimeEnd;//充值（提现）时间上限
	//收款方式
	private String collectWay;//业务类型
	private String payWay;//卡类型
	
	//提现交易
	private String trandateStart;//交易时间下限
	private String trandateEnd;//交易时间上限
	public String getCustomerNo() {
		return customerNo;
	}
	public String getTrandateStart() {
		return trandateStart;
	}
	public void setTrandateStart(String trandateStart) {
		this.trandateStart = trandateStart;
	}
	public String getTrandateEnd() {
		return trandateEnd;
	}
	public void setTrandateEnd(String trandateEnd) {
		this.trandateEnd = trandateEnd;
	}
	public void setCustomerNo(String customerNo) {
		this.customerNo = customerNo;
	}
	public String getInsNo() {
		return insNo;
	}
	public String getSmallMerchNo() {
		return smallMerchNo;
	}
	public void setSmallMerchNo(String smallMerchNo) {
		this.smallMerchNo = StringUtils.trim(smallMerchNo);
	}
	public void setInsNo(String insNo) {
		this.insNo = StringUtils.trim(insNo);
	}
	public String getCustomername() {
		return customername;
	}
	public void setCustomername(String customername) {
		this.customername = StringUtils.trim(customername);
	}
	public String getInsName() {
		return insName;
	}
	public void setInsName(String insName) {
		this.insName = insName;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = StringUtils.trim(orderId);
	}
	public String getD0Flag() {
		return d0Flag;
	}
	public void setD0Flag(String d0Flag) {
		this.d0Flag = d0Flag;
	}
	public String getQorderid() {
		return qorderid;
	}
	public void setQorderid(String qorderid) {
		this.qorderid = StringUtils.trim(qorderid);
	}
	public String getQtranflag() {
		return qtranflag;
	}
	public void setQtranflag(String qtranflag) {
		this.qtranflag = qtranflag;
	}
	public String getQtrantimeStart() {
		return qtrantimeStart;
	}
	public void setQtrantimeStart(String qtrantimeStart) {
		this.qtrantimeStart = qtrantimeStart;
	}
	public String getQtrantimeEnd() {
		return qtrantimeEnd;
	}
	public void setQtrantimeEnd(String qtrantimeEnd) {
		this.qtrantimeEnd = qtrantimeEnd;
	}
	public String getCollectWay() {
		return collectWay;
	}
	public void setCollectWay(String collectWay) {
		this.collectWay = collectWay;
	}
	public String getPayWay() {
		return payWay;
	}
	public void setPayWay(String payWay) {
		this.payWay = payWay;
	}
}
