package com.uns.organization.modules.organization.web;


import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.organization.common.persistence.Page;
import com.uns.organization.common.utils.DateUtils;
import com.uns.organization.common.utils.excel.ExportExcel;
import com.uns.organization.modules.organization.entity.Institution;
import com.uns.organization.modules.organization.entity.TQrCodeTrans;
import com.uns.organization.modules.organization.service.InsTransService;
import com.uns.organization.modules.organization.service.InstitutionService;
import com.uns.organization.modules.organization.web.form.TransForm;
import com.uns.organization.common.web.BaseController;



/**
 * 充值记录Controller
 * @author Administrator
 *
 */
@Controller
@RequestMapping(value = "${adminPath}/ins/trans")
public class InsTransController extends BaseController{
	
	@Autowired
	InsTransService insTransService;
	
	@Autowired
	InstitutionService institutionService;
	/**
	 * 去往充值交易列表
	 * @return
	 */
	@RequestMapping(value = "transList")
	public String transList(TransForm transForm, HttpServletRequest request, HttpServletResponse response, Model model){
		try {
            // 统计汇总显示
            Map<String,Object> countMap = insTransService.findSumAmount(transForm);
            //查询交易列表
            Page<TQrCodeTrans> page = insTransService.findTransList(transForm, new Page<TQrCodeTrans>(request, response));
            //查询所有机构
            List<Institution> allIns = institutionService.findAllIns();
			model.addAttribute("allIns", allIns);
			model.addAttribute("page", page);
			model.addAttribute("countMap",countMap);
		} catch (Exception e) {
			e.printStackTrace();
			addMessage(model, "充值交易列表查询失败！");
		}
		return "modules/trans/transList";
	}
	
	/**
	 * 去往充值交易详情
	 * @return
	 */
	@RequestMapping(value = "transDetails")
	public String transDetails(TransForm transForm, HttpServletRequest request, HttpServletResponse response, Model model){
		try {
			//查询交易列表
			TQrCodeTrans tQrCodeTrans = insTransService.findTransDetails(transForm);
			model.addAttribute("tran", tQrCodeTrans);
		} catch (Exception e) {
			e.printStackTrace();
			addMessage(model, "充值交易详情查询失败！");
		}
		return "modules/trans/transDetails";
	}
	
	/**
	 * 导出
	 * @return
	 */
	@RequestMapping(value = "exportTransList")
	public String exportTransList(TransForm transForm, HttpServletRequest request, HttpServletResponse response, Model model){
		try {
			String fileName = "商户交易列表"+DateUtils.getDate("yyyyMMddHHmmss")+".xlsx";
			Page<TQrCodeTrans> page = insTransService.findExecelTransList(transForm, new Page<TQrCodeTrans>(request, response, -1));
    		new ExportExcel("交易数据", TQrCodeTrans.class).setDataList(page.getList()).write(response, fileName).dispose();
    		return null;
		} catch (Exception e) {
			e.printStackTrace();
			addMessage(model, "导出充值交易数据失败！");
		}
		return "redirect:" + adminPath + "/ins/trans/transList?repage";
	}
}
