package com.uns.organization.modules.organization.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.organization.common.service.BaseService;
import com.uns.organization.modules.organization.dao.SysAreaMapper;
import com.uns.organization.modules.organization.entity.SysArea;

@Service
public class SysAreaService extends BaseService{

	@Autowired
	private SysAreaMapper sysAreaMapper;

	public List<SysArea> findAllProvince() {
		return sysAreaMapper.findAllProvince();
	}

	public List<SysArea> provinceAllCity(String province) {
		return sysAreaMapper.provinceAllCity(province);
	}
	
	
	
	
	
}
