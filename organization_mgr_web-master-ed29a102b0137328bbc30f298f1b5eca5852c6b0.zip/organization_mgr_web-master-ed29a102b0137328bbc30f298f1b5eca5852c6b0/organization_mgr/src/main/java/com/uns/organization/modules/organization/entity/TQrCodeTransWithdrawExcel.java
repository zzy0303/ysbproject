package com.uns.organization.modules.organization.entity;

import java.math.BigDecimal;
import java.util.Date;

import com.uns.organization.common.utils.excel.annotation.ExcelField;

public class TQrCodeTransWithdrawExcel {
    private Long id;

    private String proVer;

    private String msgType;

    private String orderId;

    private String payWay;

    private String orderStatus;

    private String traceNo;

    private String subject;

    private String merchantCode;

    private String smzfMsgId;

    private String qrCode;

    private BigDecimal fee;

    private String reqDate;

    private Date tranDate;

    private String bankDate;

    private String smallMerchNo;

    private String customerNo;

    private String commitionId;

    private BigDecimal amount;

    private String d0Flag;

    private String settleDate;

    private String orderDesc;

    private String operatorId;

    private String storeId;

    private String terminalId;

    private String limitPay;

    private String respType;

    private String respCode;

    private String respMsg;

    private BigDecimal buyerPayamount;

    private BigDecimal pointAmount;

    private String buyerId;

    private String buyerAccount;

    private String isclearorcancel;

    private String extend1;

    private String extend2;

    private String extend3;

    private BigDecimal arrivalAmount;

    private String chargeStatus;

    private String withdrawStatus;

    private BigDecimal d0Fee;

    private Short cardType;

    private String bankId;

    private String feever;

    private String tranType;

    private String bankCode;

    private String payCardType;

    private String insNo;

    private String callbackUrl;

    private String settleKey;

    private String voucherNum;

    private String withDrawD0flag;

    private Short auditStatus;

    private String merchantUrl;
    
	private BigDecimal profitFee;
    
    //非实体类字段
    private String customername;//商户名称
    private String qorderid;//充值交易编号
    private Date qtrantime;//充值交易时间
	private String qtranflag;//充值交易状态
	private String qamount;//交易行为金额
	private String cpD0CommissionRate;//d0费率
	private String qfee;//提现费率
	private String minusamount;//扣除金额

    private String collectwaystr;//收款方式字符串
    private String qamountstr;
    private String amountstr;//交易金额

    @ExcelField(title="交易金额", type=1, align=1, sort=8)
    public String getAmountstr() {
        return amountstr;
    }

    public void setAmountstr(String amountstr) {
        this.amountstr = amountstr;
    }

    @ExcelField(title="实际到账金额", type=1, align=1, sort=9)
	public String getQamountstr() {
		return qamountstr;
	}

	public void setQamountstr(String qamountstr) {
		this.qamountstr = qamountstr;
	}

	@ExcelField(title="收款方式", type=1, align=1, sort=7)
	public String getCollectwaystr() {
		return collectwaystr;
	}

	public void setCollectwaystr(String collectwaystr) {
		this.collectwaystr = collectwaystr;
	}

	public String getMinusamount() {
		return minusamount;
	}

	public void setMinusamount(String minusamount) {
		this.minusamount = minusamount;
	}

	public BigDecimal getProfitFee() {
		return profitFee;
	}
	
	public void setProfitFee(BigDecimal profitFee) {
		this.profitFee = profitFee;
	}
	private String insCommission;//抽成比例
	
	private String insName;//机构名称

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProVer() {
        return proVer;
    }

    public void setProVer(String proVer) {
        this.proVer = proVer == null ? null : proVer.trim();
    }

    public String getMsgType() {
        return msgType;
    }

    public void setMsgType(String msgType) {
        this.msgType = msgType == null ? null : msgType.trim();
    }
    @ExcelField(title="订单编号", type=1, align=1, sort=5)
    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId == null ? null : orderId.trim();
    }

    public String getPayWay() {
        return payWay;
    }

    public void setPayWay(String payWay) {
        this.payWay = payWay == null ? null : payWay.trim();
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus == null ? null : orderStatus.trim();
    }

    public String getTraceNo() {
        return traceNo;
    }

    public void setTraceNo(String traceNo) {
        this.traceNo = traceNo == null ? null : traceNo.trim();
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject == null ? null : subject.trim();
    }

    public String getMerchantCode() {
        return merchantCode;
    }

    public void setMerchantCode(String merchantCode) {
        this.merchantCode = merchantCode == null ? null : merchantCode.trim();
    }

    public String getSmzfMsgId() {
        return smzfMsgId;
    }

    public void setSmzfMsgId(String smzfMsgId) {
        this.smzfMsgId = smzfMsgId == null ? null : smzfMsgId.trim();
    }

    public String getQrCode() {
        return qrCode;
    }

    public void setQrCode(String qrCode) {
        this.qrCode = qrCode == null ? null : qrCode.trim();
    }

    public BigDecimal getFee() {
        return fee;
    }

    public void setFee(BigDecimal fee) {
        this.fee = fee;
    }

    public String getReqDate() {
        return reqDate;
    }

    public void setReqDate(String reqDate) {
        this.reqDate = reqDate == null ? null : reqDate.trim();
    }
    
    @ExcelField(title="交易时间", type=1, align=1, sort=11)
    public Date getTranDate() {
		return tranDate;
	}

	public void setTranDate(Date tranDate) {
		this.tranDate = tranDate;
	}

	public String getBankDate() {
        return bankDate;
    }

    public void setBankDate(String bankDate) {
        this.bankDate = bankDate == null ? null : bankDate.trim();
    }
    
	@ExcelField(title="商户编号", type=1, align=1, sort=1)
    public String getSmallMerchNo() {
        return smallMerchNo;
    }

    public void setSmallMerchNo(String smallMerchNo) {
        this.smallMerchNo = smallMerchNo == null ? null : smallMerchNo.trim();
    }

    public String getCustomerNo() {
        return customerNo;
    }

    public void setCustomerNo(String customerNo) {
        this.customerNo = customerNo == null ? null : customerNo.trim();
    }

    public String getCommitionId() {
        return commitionId;
    }

    public void setCommitionId(String commitionId) {
        this.commitionId = commitionId == null ? null : commitionId.trim();
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
    public String getD0Flag() {
        return d0Flag;
    }

    public void setD0Flag(String d0Flag) {
        this.d0Flag = d0Flag == null ? null : d0Flag.trim();
    }

    public String getSettleDate() {
        return settleDate;
    }

    public void setSettleDate(String settleDate) {
        this.settleDate = settleDate == null ? null : settleDate.trim();
    }

    public String getOrderDesc() {
        return orderDesc;
    }

    public void setOrderDesc(String orderDesc) {
        this.orderDesc = orderDesc == null ? null : orderDesc.trim();
    }

    public String getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(String operatorId) {
        this.operatorId = operatorId == null ? null : operatorId.trim();
    }

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId == null ? null : storeId.trim();
    }

    public String getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId == null ? null : terminalId.trim();
    }

    public String getLimitPay() {
        return limitPay;
    }

    public void setLimitPay(String limitPay) {
        this.limitPay = limitPay == null ? null : limitPay.trim();
    }

    public String getRespType() {
        return respType;
    }

    public void setRespType(String respType) {
        this.respType = respType == null ? null : respType.trim();
    }

    public String getRespCode() {
        return respCode;
    }

    public void setRespCode(String respCode) {
        this.respCode = respCode == null ? null : respCode.trim();
    }

    public String getRespMsg() {
        return respMsg;
    }

    public void setRespMsg(String respMsg) {
        this.respMsg = respMsg == null ? null : respMsg.trim();
    }

    public BigDecimal getBuyerPayamount() {
        return buyerPayamount;
    }

    public void setBuyerPayamount(BigDecimal buyerPayamount) {
        this.buyerPayamount = buyerPayamount;
    }

    public BigDecimal getPointAmount() {
        return pointAmount;
    }

    public void setPointAmount(BigDecimal pointAmount) {
        this.pointAmount = pointAmount;
    }

    public String getBuyerId() {
        return buyerId;
    }

    public void setBuyerId(String buyerId) {
        this.buyerId = buyerId == null ? null : buyerId.trim();
    }

    public String getBuyerAccount() {
        return buyerAccount;
    }

    public void setBuyerAccount(String buyerAccount) {
        this.buyerAccount = buyerAccount == null ? null : buyerAccount.trim();
    }

    public String getIsclearorcancel() {
        return isclearorcancel;
    }

    public void setIsclearorcancel(String isclearorcancel) {
        this.isclearorcancel = isclearorcancel == null ? null : isclearorcancel.trim();
    }

    public String getExtend1() {
        return extend1;
    }

    public void setExtend1(String extend1) {
        this.extend1 = extend1 == null ? null : extend1.trim();
    }

    public String getExtend2() {
        return extend2;
    }

    public void setExtend2(String extend2) {
        this.extend2 = extend2 == null ? null : extend2.trim();
    }

    public String getExtend3() {
        return extend3;
    }

    public void setExtend3(String extend3) {
        this.extend3 = extend3 == null ? null : extend3.trim();
    }
    
    public BigDecimal getArrivalAmount() {
        return arrivalAmount;
    }

    public void setArrivalAmount(BigDecimal arrivalAmount) {
        this.arrivalAmount = arrivalAmount;
    }

    public String getChargeStatus() {
        return chargeStatus;
    }

    public void setChargeStatus(String chargeStatus) {
        this.chargeStatus = chargeStatus == null ? null : chargeStatus.trim();
    }

    public String getWithdrawStatus() {
        return withdrawStatus;
    }

    public void setWithdrawStatus(String withdrawStatus) {
        this.withdrawStatus = withdrawStatus == null ? null : withdrawStatus.trim();
    }

    public BigDecimal getD0Fee() {
        return d0Fee;
    }

    public void setD0Fee(BigDecimal d0Fee) {
        this.d0Fee = d0Fee;
    }
    
    public Short getCardType() {
        return cardType;
    }

    public void setCardType(Short cardType) {
        this.cardType = cardType;
    }

    public String getBankId() {
        return bankId;
    }

    public void setBankId(String bankId) {
        this.bankId = bankId == null ? null : bankId.trim();
    }

    public String getFeever() {
        return feever;
    }

    public void setFeever(String feever) {
        this.feever = feever == null ? null : feever.trim();
    }

    public String getTranType() {
        return tranType;
    }

    public void setTranType(String tranType) {
        this.tranType = tranType == null ? null : tranType.trim();
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode == null ? null : bankCode.trim();
    }

    public String getPayCardType() {
        return payCardType;
    }

    public void setPayCardType(String payCardType) {
        this.payCardType = payCardType == null ? null : payCardType.trim();
    }
    @ExcelField(title="机构编号", type=1, align=1, sort=4)
    public String getInsNo() {
        return insNo;
    }

    public void setInsNo(String insNo) {
        this.insNo = insNo == null ? null : insNo.trim();
    }

    public String getCallbackUrl() {
        return callbackUrl;
    }

    public void setCallbackUrl(String callbackUrl) {
        this.callbackUrl = callbackUrl == null ? null : callbackUrl.trim();
    }

    public String getSettleKey() {
        return settleKey;
    }

    public void setSettleKey(String settleKey) {
        this.settleKey = settleKey == null ? null : settleKey.trim();
    }

    public String getVoucherNum() {
        return voucherNum;
    }

    public void setVoucherNum(String voucherNum) {
        this.voucherNum = voucherNum == null ? null : voucherNum.trim();
    }

    public String getWithDrawD0flag() {
        return withDrawD0flag;
    }

    public void setWithDrawD0flag(String withDrawD0flag) {
        this.withDrawD0flag = withDrawD0flag == null ? null : withDrawD0flag.trim();
    }

    public Short getAuditStatus() {
        return auditStatus;
    }

    public void setAuditStatus(Short auditStatus) {
        this.auditStatus = auditStatus;
    }

    public String getMerchantUrl() {
        return merchantUrl;
    }

    public void setMerchantUrl(String merchantUrl) {
        this.merchantUrl = merchantUrl == null ? null : merchantUrl.trim();
    }
    @ExcelField(title="商户名称", type=1, align=1, sort=2)
	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}
	@ExcelField(title="提现编号", type=1, align=1, sort=6)
	public String getQorderid() {
		return qorderid;
	}

	public void setQorderid(String qorderid) {
		this.qorderid = qorderid;
	}
	@ExcelField(title="提现日期", type=1, align=1, sort=12)
	public Date getQtrantime() {
		return qtrantime;
	}

	public void setQtrantime(Date qtrantime) {
		this.qtrantime = qtrantime;
	}

	@ExcelField(title="提现状态", type=1, align=1, sort=10)
	public String getQtranflag() {
		return qtranflag;
	}

	public void setQtranflag(String qtranflag) {
		this.qtranflag = qtranflag;
	}
	
	public String getQamount() {
		return qamount;
	}

	public void setQamount(String qamount) {
		this.qamount = qamount;
	}

	public String getCpD0CommissionRate() {
		return cpD0CommissionRate;
	}

	public void setCpD0CommissionRate(String cpD0CommissionRate) {
		this.cpD0CommissionRate = cpD0CommissionRate;
	}

	public String getQfee() {
		return qfee;
	}

	public void setQfee(String qfee) {
		this.qfee = qfee;
	}

	public String getInsCommission() {
		return insCommission;
	}

	public void setInsCommission(String insCommission) {
		this.insCommission = insCommission;
	}
	@ExcelField(title="所属机构", type=1, align=1, sort=3)
	public String getInsName() {
		return insName;
	}

	public void setInsName(String insName) {
		this.insName = insName;
	}
}