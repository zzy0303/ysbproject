package com.uns.organization.modules.organization.web;


import java.util.List;
import java.util.Map;

import com.uns.organization.common.utils.DateUtils;
import com.uns.organization.common.utils.excel.ExportExcel;
import com.uns.organization.common.web.BaseController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uns.organization.common.persistence.Page;
import com.uns.organization.modules.organization.entity.Institution;
import com.uns.organization.modules.organization.entity.TQrCodeTrans;
import com.uns.organization.modules.organization.entity.TQrCodeTransWithdrawExcel;
import com.uns.organization.modules.organization.service.InsTransService;
import com.uns.organization.modules.organization.service.InstitutionService;
import com.uns.organization.modules.organization.web.form.TransForm;
import com.uns.organization.modules.organization.web.form.TransFormForExcelWithdraw;


/**
 * 提现交易Controller
 * @author Administrator
 *
 */
@Controller
@RequestMapping(value = "${adminPath}/ins/withdraw")
public class InsWithdrawController extends BaseController{
	
	@Autowired
	InsTransService insTransService;
	@Autowired
	InstitutionService institutionService;

	/**
	 * T1提现交易列表
	 * @param request
	 * @param response
	 * @param transForm
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "t1WithdrawList")
	public String findT1WithdrawList(HttpServletRequest request, HttpServletResponse response, TransForm transForm, Model model) {
		try {
            // 统计汇总显示
            Map<String,Object> countMap = insTransService.findT1WithdSumAmount(transForm);
            Page<TQrCodeTrans> page = insTransService.findT1WithdrawList(transForm, new Page<TQrCodeTrans>(request, response));
            //查询所有机构
            List<Institution> allIns = institutionService.findAllIns();
			model.addAttribute("countMap",countMap);
			model.addAttribute("allIns", allIns);
			model.addAttribute("page", page);
		} catch (Exception e) {
			e.printStackTrace();
			addMessage(model, "t1提现交易列表查询失败！");
		}
		return "modules/withdraw/t1WithdrawList";
	}

	/**
	 * 提现交易列表
	 * @param request
	 * @param response
	 * @param transForm
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "withdrawList")
	public String withdrawList(HttpServletRequest request, HttpServletResponse response, TransForm transForm, Model model){
		try {
            // 统计汇总显示
            Map<String,Object> countMap = insTransService.findD0WithdSumAmount(transForm);
            //查询提现交易列表
            Page<TQrCodeTrans> page = insTransService.findWithdrawList(transForm, new Page<TQrCodeTrans>(request, response));
            //查询所有机构
            List<Institution> allIns = institutionService.findAllIns();
            model.addAttribute("countMap", countMap);
			model.addAttribute("allIns", allIns);
			model.addAttribute("page", page);
		} catch (Exception e) {
			e.printStackTrace();
			addMessage(model, "d0提现交易列表查询失败！");
		}
		return "modules/withdraw/withdrawList";
	}
	
	/**
	 * 去往提现交易详情
	 * @return
	 */
	@RequestMapping(value = "withdrawDetails")
	public String withdrawDetails(TransForm transForm,HttpServletRequest request, HttpServletResponse response, Model model){
		try {
			//查询交易列表
			TQrCodeTrans tQrCodeTrans = insTransService.findWithdrawDetails(transForm);
			model.addAttribute("tran", tQrCodeTrans);
		} catch (Exception e) {
			e.printStackTrace();
			addMessage(model, "d0提现交易详情查询失败！");
		}
		return "modules/withdraw/withdrawDetails";
	}
	/**
	 * 去往T1提现交易详情
	 * @return
	 */
	@RequestMapping(value = "t1WithdrawDetails")
	public String t1WithdrawDetails(TransForm transForm,HttpServletRequest request, HttpServletResponse response, Model model){
		try {
			//查询交易列表
			TQrCodeTrans tQrCodeTrans = insTransService.findT1WithdrawDetails(transForm);
			model.addAttribute("tran", tQrCodeTrans);
		} catch (Exception e) {
			e.printStackTrace();
			addMessage(model, "t1提现交易详情查询失败！");
		}
		return "modules/withdraw/t1WithdrawDetails";
	}
	
	/**
	 * 导出提现交易列表
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "exportWithdrawList")
	public String exportWithdrawList(TransFormForExcelWithdraw transFormForExcelWithdraw, HttpServletRequest request, HttpServletResponse response, Model model){
		try {
			String fileName = "商户提现列表"+DateUtils.getDate("yyyyMMddHHmmss")+".xlsx";
			Page<TQrCodeTransWithdrawExcel> page = insTransService.findExecelWithdrawList(transFormForExcelWithdraw, new Page<TQrCodeTransWithdrawExcel>(request, response, -1));
    		new ExportExcel("提现数据", TQrCodeTransWithdrawExcel.class).setDataList(page.getList()).write(response, fileName).dispose();
    		return null;
		} catch (Exception e) {
			e.printStackTrace();
			addMessage(model, "导出提现交易数据失败！");
		}
		return "redirect:" + adminPath + "/ins/withdraw/withdrawList?repage";
	}

	/**
	 * 导出T1提现交易列表
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "exportT1WithdrawList")
	public String exportT1WithdrawList(TransFormForExcelWithdraw transFormForExcelWithdraw, HttpServletRequest request, HttpServletResponse response, Model model){
		try {
			String fileName = "商户提现列表"+DateUtils.getDate("yyyyMMddHHmmss")+".xlsx";
			Page<TQrCodeTransWithdrawExcel> page = insTransService.findExecelT1WithdrawList(transFormForExcelWithdraw, new Page<TQrCodeTransWithdrawExcel>(request, response, -1));
			new ExportExcel("提现数据", TQrCodeTransWithdrawExcel.class).setDataList(page.getList()).write(response, fileName).dispose();
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			addMessage(model, "导出提现交易数据失败！");
		}
		return "redirect:" + adminPath + "/ins/withdraw/t1WithdrawList?repage";
	}



}
