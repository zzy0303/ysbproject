package com.uns.organization.modules.organization.entity;

import com.uns.organization.common.persistence.DataEntity;
import com.uns.organization.common.utils.StringUtils;
import com.uns.organization.common.utils.excel.annotation.ExcelField;
import com.uns.organization.modules.sys.utils.DictUtils;

/**
 * 抽成提现
 * @author yang.cheng
 *
 */
public class PercentagTx extends DataEntity<PercentagTx>{
	
	private static final long serialVersionUID = 1L;

	private String batchNo;//批次号
	
	private String tranTime;//批次生成时间
	
	private String insNo;//机构编号
	
	private String insName;//机构名称
	
	private String tranFlag;//批次状态

	private String sumAmount;//抽成总金额

	private String beginDate;//批次开始时间

	private String endDate; //批次结束时间

    public String getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(String beginDate) {
        this.beginDate = beginDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public void setSumAmount(String sumAmount) {
		this.sumAmount = sumAmount == null ? "0" : sumAmount;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}
	
	public void setTranTime(String tranTime) {
		this.tranTime = tranTime;
	}
	
	public void setInsNo(String insNo) {
		this.insNo = insNo;
	}
	
	public void setInsName(String insName) {
		this.insName = insName;
	}
	
	public void setTranFlag(String tranFlag) {
		this.tranFlag = tranFlag;
	}
	
	@ExcelField(title="	批次号	", type=1, align=1, sort=1)
	public String getBatchNo() {
		return batchNo;
	}
	public String getTranTime() {
		return tranTime;
	}
	@ExcelField(title="批次生成时间", type=1, align=1, sort=2)
	public String getTranTimeStr() {
		return StringUtils.isBlank(tranTime)?"":StringUtils.parseDateString(tranTime);
	}
	@ExcelField(title="	机构编号	", type=1, align=1, sort=3)
	public String getInsNo() {
		return insNo;
	}
	@ExcelField(title="机构名称", type=1, align=1, sort=4)
	public String getInsName() {
		return insName;
	}
	public String getTranFlag() {
		return tranFlag;
	}
    @ExcelField(title="批次状态", type=1, align=1, sort=5)
	public String getTranFlagStr() {
		return DictUtils.getDictLabel(tranFlag, "QR_TRAN_FALG", tranFlag);
	}
    @ExcelField(title = "抽成总金额",type=1, align = 1,sort = 6)
    public String getSumAmount() {
        return sumAmount;
    }
}
