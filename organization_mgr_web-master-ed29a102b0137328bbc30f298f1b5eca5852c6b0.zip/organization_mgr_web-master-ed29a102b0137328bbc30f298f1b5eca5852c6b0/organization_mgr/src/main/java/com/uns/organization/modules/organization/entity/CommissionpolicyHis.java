package com.uns.organization.modules.organization.entity;

import java.util.Date;

public class CommissionpolicyHis {
    private Long commissionid;

    private String commissionname;

    private Long commissionRate;

    private Long topfee;

    private Long customerid;

    private Short commissiontype;

    private String feever;

    private Date archDate;

    private Short cardtype;

    private Long d0CommissionRate;

    public Long getCommissionid() {
        return commissionid;
    }

    public void setCommissionid(Long commissionid) {
        this.commissionid = commissionid;
    }

    public String getCommissionname() {
        return commissionname;
    }

    public void setCommissionname(String commissionname) {
        this.commissionname = commissionname == null ? null : commissionname.trim();
    }

    public Long getCommissionRate() {
        return commissionRate;
    }

    public void setCommissionRate(Long commissionRate) {
        this.commissionRate = commissionRate;
    }

    public Long getTopfee() {
        return topfee;
    }

    public void setTopfee(Long topfee) {
        this.topfee = topfee;
    }

    public Long getCustomerid() {
        return customerid;
    }

    public void setCustomerid(Long customerid) {
        this.customerid = customerid;
    }

    public Short getCommissiontype() {
        return commissiontype;
    }

    public void setCommissiontype(Short commissiontype) {
        this.commissiontype = commissiontype;
    }

    public String getFeever() {
        return feever;
    }

    public void setFeever(String feever) {
        this.feever = feever == null ? null : feever.trim();
    }

    public Date getArchDate() {
        return archDate;
    }

    public void setArchDate(Date archDate) {
        this.archDate = archDate;
    }

    public Short getCardtype() {
        return cardtype;
    }

    public void setCardtype(Short cardtype) {
        this.cardtype = cardtype;
    }

    public Long getD0CommissionRate() {
        return d0CommissionRate;
    }

    public void setD0CommissionRate(Long d0CommissionRate) {
        this.d0CommissionRate = d0CommissionRate;
    }
}