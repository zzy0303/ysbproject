package com.uns.organization.modules.organization.dao;

import java.util.List;

import com.uns.organization.common.persistence.annotation.MyBatisDao;
import com.uns.organization.modules.organization.entity.ZhaoshangJoin;
import com.uns.organization.modules.organization.web.form.ReportForm;
@MyBatisDao
public interface ZhaoshangJoinMapper {

    int deleteByPrimaryKey(Long id);

    int insert(ZhaoshangJoin record);

    int insertSelective(ZhaoshangJoin record);

    ZhaoshangJoin selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(ZhaoshangJoin record);

    int updateByPrimaryKey(ZhaoshangJoin record);
    
    List<ZhaoshangJoin> findCustomerReportList(ReportForm reportForm);
    
    ZhaoshangJoin findCustomerReportDetails(ReportForm reportForm);
    
    int updateAuditStatus(ReportForm reportForm);
}