package com.uns.organization.modules.organization.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.organization.common.persistence.Page;
import com.uns.organization.common.service.BaseService;
import com.uns.organization.common.utils.Constants;
import com.uns.organization.common.utils.StringUtils;
import com.uns.organization.modules.organization.dao.InsRoleInfoMapper;
import com.uns.organization.modules.organization.entity.InsRoleInfo;
import com.uns.organization.modules.sys.entity.Menu;
import com.uns.organization.modules.sys.utils.UserUtils;

@Service
public class InsRoleService extends BaseService{

	@Autowired
	private InsRoleInfoMapper insRoleInfoMapper;
	
	/**
	 * 查询机构角色列表
	 * @param page
	 * @param insRoleInfo
	 * @return
	 */
	public Page<InsRoleInfo> findInsRoleList(Page<InsRoleInfo> page, InsRoleInfo insRoleInfo) {
		// 设置分页参数
		insRoleInfo.setPage(page);
		// 执行分页查询
		page.setList(insRoleInfoMapper.findInsRoleList(insRoleInfo));
		return page;
	}

	/**
	 * 查询所有权限
	 * @return
	 */
	public List<Menu> findAllMenu() {
		return insRoleInfoMapper.findAllMenu();
	}

	/**
	 * 保存机构角色信息
	 * @param insRoleInfo
	 */
	public void saveInsRoleInfo(InsRoleInfo insRoleInfo) {
		Date now = new Date();
		BigDecimal userId = new BigDecimal(UserUtils.getUser().getId());
		insRoleInfo.setUpdateDate(now);
		insRoleInfo.setUpdateUser(userId);
		if(StringUtils.isBlank(insRoleInfo.getId())){//添加
			insRoleInfo.setStatus(new BigDecimal(Constants.INS_ROLE_STATUS_1));//有效
			insRoleInfo.setVersion(new BigDecimal(Constants.INS_ROLE_VERSION_1));//机构运营平台添加
			insRoleInfo.setCreateUser(userId);
			insRoleInfo.setCreateDate(now);
			insRoleInfoMapper.insertSelective(insRoleInfo);
			//保存角色权限
			if(insRoleInfo.getFunctionIds()!=null && insRoleInfo.getFunctionIds().length>0){
				insRoleInfoMapper.insertRoleFunction(insRoleInfo);
			}
		}else{//修改
			insRoleInfoMapper.updateByPrimaryKeySelective(insRoleInfo);
			//修改角色权限,
			insRoleInfoMapper.deleteRoleFunction(insRoleInfo.getId());
			insRoleInfoMapper.insertRoleFunction(insRoleInfo);
		}
	}
	
	/**
	 * 通过id查询角色
	 * @param id
	 * @return
	 */
	public InsRoleInfo getInsRoleInfoById(String id){
		return insRoleInfoMapper.selectByPrimaryKey(id);
	}

	/**
	 * 查询角色权限
	 * @param insRoleId
	 * @return
	 */
	public String[] getFunctionByInsRole(String insRoleId) {
		return insRoleInfoMapper.findFunctionByInsRole(insRoleId);
	}

	/**
	 * 通过角色名查询角色
	 * @param roleName
	 * @return
	 */
	public InsRoleInfo getRoleByRoleName(String roleName) {
		return insRoleInfoMapper.findInsRoleByRoleName(roleName);
	}

	
	/**
	 * 删除机构角色
	 * @param roleId
	 */
	public void deleteInsRoleInfo(String roleId) {
		insRoleInfoMapper.deleteByPrimaryKey(roleId);
	}
}
