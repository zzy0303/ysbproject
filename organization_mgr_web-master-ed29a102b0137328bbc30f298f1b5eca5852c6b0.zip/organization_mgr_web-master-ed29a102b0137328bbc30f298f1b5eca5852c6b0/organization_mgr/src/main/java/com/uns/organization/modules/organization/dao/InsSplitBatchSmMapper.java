package com.uns.organization.modules.organization.dao;

import com.uns.organization.common.persistence.annotation.MyBatisDao;
import com.uns.organization.modules.organization.entity.InsSplitBatchSm;

import java.math.BigDecimal;
import java.util.List;

@MyBatisDao
public interface InsSplitBatchSmMapper {

    int deleteByPrimaryKey(BigDecimal id);

    int insert(InsSplitBatchSm record);

    int insertSelective(InsSplitBatchSm record);

    InsSplitBatchSm selectByPrimaryKey(BigDecimal id);

    int updateByPrimaryKeySelective(InsSplitBatchSm record);

    int updateByPrimaryKey(InsSplitBatchSm record);

    List<InsSplitBatchSm> queryProfitBatchList(InsSplitBatchSm insSplitBatchSm);

    InsSplitBatchSm querySplitBatch(String batchNo);

    void profitAudit(InsSplitBatchSm insSplitBatchSm);
}