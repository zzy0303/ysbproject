package com.uns.organization.modules.organization.dao;

import java.math.BigDecimal;
import java.util.List;

import com.uns.organization.common.persistence.annotation.MyBatisDao;
import com.uns.organization.modules.organization.entity.InstitutionFeeHis;
@MyBatisDao
public interface InstitutionFeeHisMapper {


    int deleteByPrimaryKey(BigDecimal institutionFeeHisId);

    int insert(InstitutionFeeHis record);

    int insertSelective(InstitutionFeeHis record);
    
    int insertByInstitutionFee(BigDecimal insFeeId);

    InstitutionFeeHis selectByPrimaryKey(BigDecimal institutionFeeHisId);

    int updateByPrimaryKeySelective(InstitutionFeeHis record);

    int updateByPrimaryKey(InstitutionFeeHis record);

	List<InstitutionFeeHis> findFeeHisList(InstitutionFeeHis feeHis);
}