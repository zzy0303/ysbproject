package com.uns.organization.modules.organization.service;

import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import net.sf.json.JSONObject;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uns.organization.common.exception.BusinessException;
import com.uns.organization.common.exception.ExceptionEnum;
import com.uns.organization.common.persistence.Page;
import com.uns.organization.common.service.BaseService;
import com.uns.organization.common.utils.Constants;
import com.uns.organization.common.utils.HttpRequestUtils;
import com.uns.organization.common.utils.ParamPlatfrom;
import com.uns.organization.modules.organization.dao.CmbJoinInfoMapper;
import com.uns.organization.modules.organization.dao.CustomerMapper;
import com.uns.organization.modules.organization.dao.ZhaoshangJoinMapper;
import com.uns.organization.modules.organization.entity.CmbJoinInfo;
import com.uns.organization.modules.organization.entity.ZhaoshangJoin;
import com.uns.organization.modules.organization.web.form.ReportForm;

@Service
public class InsCustomerReportService extends BaseService{
	@Autowired
	ZhaoshangJoinMapper zhaoshangJoinMapper;
	
	@Autowired
	CmbJoinInfoMapper cmbJoinInfoMapper;
	
	/**
	 * 查询商户报件列表
	 * @param reportForm
	 * @return
	 */
	public Page<ZhaoshangJoin> findReportList(Page<ZhaoshangJoin> page, ReportForm reportForm){
		reportForm.getSqlMap().put("dsf", dataScopeFilter(reportForm.getCurrentUser(), "o", "a"));
		// 设置分页参数
		reportForm.setPage(page);
		// 执行分页查询
		page.setList(zhaoshangJoinMapper.findCustomerReportList(reportForm));
		return page;
	}
	
	
	/**
	 * 查询商户报件详情
	 * @param reportForm
	 * @return
	 */
	public ZhaoshangJoin findReportDetails(ReportForm reportForm){
		return zhaoshangJoinMapper.findCustomerReportDetails(reportForm);
	}
	
	
	/**
	 * 查询cmb公共信息
	 * @return
	 */
	public CmbJoinInfo findCmbJoinDetails(){
		return cmbJoinInfoMapper.selectByPrimaryKey(Constants.LONG_ONE);
	}
	
	public void copyZhaoshangJoinRecord(ZhaoshangJoin zhaoshangJoin, ReportForm reportForm) throws IllegalAccessException, InvocationTargetException{
		BeanUtils.copyProperties(reportForm, zhaoshangJoin);
	}
	
	/**
	 * 调用商户创建接口
	 * @throws Exception 
	 */
	public void invokeCustomerCreateport(ZhaoshangJoin zhaoshangJoin, CmbJoinInfo cmbJoinInfo) throws BusinessException{
		JSONObject result = null;
		JSONObject param = null;
		try {
			param = new JSONObject();
			setCustomerCreateReqParam(param, zhaoshangJoin, cmbJoinInfo);
			String url = ParamPlatfrom.REGISTER_CUSTOMER_URL;
			logger.info("商户创建接口请求参数：url="+url+"   param="+param);
			result = HttpRequestUtils.httpPost(url, param);
			logger.info("商户创建接口返回：result="+result);
		} catch (Exception e) {
			logger.info(e.getMessage());
			throw new BusinessException(ExceptionEnum.调用商户创建接口异常);
		}
		if(null == result){
			throw new BusinessException(ExceptionEnum.调用商户创建接口失败);
		}
		if(result.has(Constants.PORT_RESULT_STATUS) && Constants.PORT_RESULT_STATUS_ERROR.equals(result.getString(Constants.PORT_RESULT_STATUS))){
			throw new BusinessException(ExceptionEnum.商户创建失败);
		}
		zhaoshangJoin.setMchAppId(result.getString(Constants.PORT_RESULT_MCH_APP_ID));
	}
	
	
	/**
	 * 调用银行入驻接口
	 * @param zhaoshangJoin
	 * @param cmbJoinInfo
	 * @throws BusinessException 
	 * @throws ParseException 
	 * @throws Exception 
	 */
	public void invokeBankJoinPort(ZhaoshangJoin zhaoshangJoin, CmbJoinInfo cmbJoinInfo) throws BusinessException {
		JSONObject result = null;
		JSONObject param = null;
		try {
			param = new JSONObject();
			setBankJoinReqParam(param, zhaoshangJoin, cmbJoinInfo);
			String url = ParamPlatfrom.BANK_JOIN_URL;
			logger.info("银行入驻接口请求参数：url="+url+"   param="+param);
			result = HttpRequestUtils.httpPost(url, param);
			logger.info("银行入驻接口返回：result="+result);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ExceptionEnum.调用银行入驻接口异常);
		}
		if(null == result){
			throw new BusinessException(ExceptionEnum.调用银行入驻接口失败);
		}
		if(result.has(Constants.PORT_RESULT_STATUS) && Constants.PORT_RESULT_STATUS_ERROR.equals(result.getString(Constants.PORT_RESULT_STATUS))){
			throw new BusinessException(ExceptionEnum.银行入驻失败);
		}
		zhaoshangJoin.setBankAppId(result.getString(Constants.PORT_RESULT_BANK_APP_ID));
	}
	
	/**
	 * 设置商户创建接口需要的参数
	 * @param param
	 * @param zhaoshangJoin
	 * @param cmbJoinInfo
	 * @throws ParseException 
	 */
	private void setCustomerCreateReqParam(JSONObject param, ZhaoshangJoin zhaoshangJoin, CmbJoinInfo cmbJoinInfo) throws ParseException{
		zhaoshangJoin.setTimestamp(getUnixTimestamp());
		param.put("timestamp", zhaoshangJoin.getTimestamp());
		zhaoshangJoin.setOutMerchantId(getRandomStr());
		param.put("outMerchantId", zhaoshangJoin.getOutMerchantId());
		zhaoshangJoin.setLoginId(getRandomStr());
		param.put("loginId", zhaoshangJoin.getLoginId());
		
		param.put("mchAppId", zhaoshangJoin.getMchAppId());
		param.put("smallMerchantNo", zhaoshangJoin.getSmallMerchantNo());
		param.put("insNo", zhaoshangJoin.getInsNo());
		param.put("name", zhaoshangJoin.getName());
		param.put("aliasName", zhaoshangJoin.getAliasName());
		param.put("password", zhaoshangJoin.getPassword());
		param.put("mobileNo", zhaoshangJoin.getMobileNo());
		param.put("servicePhone", zhaoshangJoin.getServicePhone());
		param.put("industryCategoryId", zhaoshangJoin.getIndustryCategoryId());
		param.put("wxCategoryId", zhaoshangJoin.getWxCategoryId());
		param.put("wxCategoryName", zhaoshangJoin.getWxCategoryName());
		param.put("aliCategoryId", zhaoshangJoin.getAliCategoryId());
		param.put("aliCategoryName", zhaoshangJoin.getAliCategoryName());
		param.put("email", zhaoshangJoin.getEmail());
		param.put("businessLicense", zhaoshangJoin.getBusinessLicense());
		param.put("businessLicenseType", zhaoshangJoin.getBusinessLicenseType());
		param.put("merchantLicense", zhaoshangJoin.getMerchantLicense());
		param.put("lxrName", zhaoshangJoin.getLxrName());
		param.put("lxrType", zhaoshangJoin.getLxrType());
		param.put("idCardNo", zhaoshangJoin.getIdCardNo());
		param.put("phone", zhaoshangJoin.getPhone());
		param.put("provinceCode", zhaoshangJoin.getProvinceCode());
		param.put("cityCode", zhaoshangJoin.getCityCode());
		param.put("districtCode", zhaoshangJoin.getDistrictCode());
		param.put("address", zhaoshangJoin.getAddress());
		param.put("remark", zhaoshangJoin.getRemark());
		param.put("extend1", zhaoshangJoin.getExtend1());
		param.put("extend2", zhaoshangJoin.getExtend2());
		param.put("extend3", zhaoshangJoin.getExtend3());
	}
	
	/**
	 * 设置银行入驻接口需要的参数
	 * @param param
	 * @param cmbJoinInfo
	 * @throws ParseException
	 */
	public void setBankJoinReqParam(JSONObject param, ZhaoshangJoin zhaoshangJoin, CmbJoinInfo cmbJoinInfo) throws ParseException{
		param.put("mchAppId", zhaoshangJoin.getMchAppId());
		param.put("outMerchantId", zhaoshangJoin.getOutMerchantId());
		param.put("joinTimestamp", getUnixTimestamp());
		param.put("feeRateId", cmbJoinInfo.getFeeRateId());
		param.put("payFeeRateNoWx", cmbJoinInfo.getPayFeeRateNoWx());
		param.put("feeRateWx", cmbJoinInfo.getFeeRateWx());
		param.put("payFeeRateNoZfb", cmbJoinInfo.getPayFeeRateNoZfb());
		param.put("feeRateZfb", cmbJoinInfo.getFeeRateZfb());
		param.put("accountName", cmbJoinInfo.getAccountName());
		param.put("accountNo", cmbJoinInfo.getAccountNo());
		param.put("accountProp", cmbJoinInfo.getAccountProp());
		param.put("provinceCodeJs", cmbJoinInfo.getProvinceCodeJs());
		param.put("cityCodeJs", cmbJoinInfo.getCityCodeJs());
		param.put("bankBranchNo", cmbJoinInfo.getBankBranchNo());
		param.put("bankName", cmbJoinInfo.getBankName());
		param.put("bankBranch", cmbJoinInfo.getBankBranch());
		param.put("idCardNoJs", cmbJoinInfo.getIdCardNo());//Warning
		param.put("aliStatus", cmbJoinInfo.getAliStatus());
		param.put("wxStatus", cmbJoinInfo.getWxStatus());
		param.put("responseUrl", ParamPlatfrom.CMB_JOIN_ASYN_RESPONSE_URL);
	}
	
	/**
	 * 获取20位随机数
	 * @return
	 */
	public String getRandomStr(){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		String datestr = sdf.format(new Date());
		String numstr = getRandomNumeric();
		return datestr + numstr;
	}
	
	/**
	 * 获取6位随机数
	 * @return
	 */
	public String getRandomNumeric(){
		return RandomStringUtils.randomNumeric(6);
	}
	/**
	 * 获取当前Unix时间戳
	 * @return
	 * @throws ParseException
	 */
	public static String getUnixTimestamp() throws ParseException{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		return String.valueOf(sdf.parse(sdf.format(new Date())).getTime() / 1000);
	}
	
	
	/**
	 * 更新老报件信息
	 * @param zhaoshangJoin
	 */
	public void updateCustomerReport(ZhaoshangJoin zhaoshangJoin){
		zhaoshangJoinMapper.updateByPrimaryKeySelective(zhaoshangJoin);
	}
	
	/**
	 * 更新商户报件审核状态
	 * @param reportForm
	 */
	public void updateAuditStatus(ReportForm reportForm){
		zhaoshangJoinMapper.updateAuditStatus(reportForm);
	}
}
